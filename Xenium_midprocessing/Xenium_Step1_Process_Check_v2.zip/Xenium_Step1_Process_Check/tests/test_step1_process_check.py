"""Focused v2 regression tests: full-file checks and fresh-process isolation.

No scientific packages are imported by this test process. Child fixtures are
small temporary modules; all data-like fixtures and generated logs are temporary.
"""
from __future__ import annotations

import builtins
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import importlib.util
from importlib import metadata
import io
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import time
import unittest
from types import ModuleType, SimpleNamespace
from unittest import mock

# Support running from analysis/, beside the scripts, or from a bundled tests/ directory.
_HERE = Path(__file__).resolve().parent
SCRIPT = next((candidate for parent in [_HERE, *_HERE.parents]
               for candidate in (parent / "step1_process_check.py",
                                 parent / "deliverables" / "Xenium_Step1_Process_Check" / "step1_process_check.py")
               if candidate.is_file()), None)
if SCRIPT is None:
    raise RuntimeError("Place this test beside the Step1 process-check bundle or in its tests/ directory.")
_spec = importlib.util.spec_from_file_location("step1_process_check_under_test", SCRIPT)
check = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(check)


class _ReaderProxy:
    def __init__(self, stream, read):
        self.stream = stream
        self._read = read

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.stream.close()

    def fileno(self):
        return self.stream.fileno()

    def read(self, size=-1):
        return self._read(self.stream, size)


class FullSourceProbeTests(unittest.TestCase):
    def test_full_read_hashes_include_bytes_beyond_the_old_64_byte_prefix(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            content = b"# synthetic source\n" + b"x" * 1024 + b"\nTAIL = 42\n"
            source.write_bytes(content)
            result = check.probe_source(source)
            for mode in ("ordinary_read", "code_read"):
                self.assertTrue(result[mode]["ok"], result)
                self.assertEqual(result[mode]["stage"], "complete")
                self.assertEqual(result[mode]["bytes_read"], len(content))
                self.assertEqual(result[mode]["sha256"], hashlib.sha256(content).hexdigest())
                self.assertNotEqual(result[mode]["sha256"], hashlib.sha256(content[:64]).hexdigest())
            self.assertTrue(result["read_hashes_match"])
            self.assertFalse(result["changed_during_probe"])

    def test_successful_prefix_read_does_not_mask_full_code_read_denial(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            source.write_bytes(b"#" * 1000)
            original = io.open_code

            def limited_read(stream, size):
                if size < 0 or stream.tell() + size > 64:
                    raise PermissionError(1, "Full-file read denied", str(source))
                return stream.read(size)

            def opener(path):
                return _ReaderProxy(original(path), limited_read)

            with opener(str(source)) as stream:
                self.assertEqual(len(stream.read(64)), 64)  # The old check passes.
            with mock.patch.object(check.io, "open_code", side_effect=opener):
                result = check.probe_source(source)
            self.assertTrue(result["ordinary_read"]["ok"])
            self.assertFalse(result["code_read"]["ok"])
            self.assertEqual(result["code_read"]["stage"], "read")
            self.assertEqual(result["code_read"]["error"]["errno"], 1)
            self.assertFalse(result["ok"])
            self.assertIsNone(result["read_hashes_match"])

    def test_short_read_is_inconclusive_even_without_an_io_exception(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            content = b"x" * 1000
            source.write_bytes(content)
            original = io.open_code
            with mock.patch.object(check.io, "open_code", side_effect=lambda path: _ReaderProxy(original(path), lambda stream, size: stream.read(64))):
                result = check.probe_source(source)
            short = result["code_read"]
            self.assertFalse(short["ok"])
            self.assertEqual(short["stage"], "length_check")
            self.assertEqual(short["bytes_expected"], len(content))
            self.assertEqual(short["bytes_read"], 64)
            self.assertFalse(short["size_matches_open_stat"])
            self.assertEqual(short["error"]["type"], "SourceLengthMismatch")
            self.assertFalse(result["ok"])

    def test_different_ordinary_and_code_bytes_are_recorded_without_stat_change(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            content = b"VALUE = 1\n" * 100
            changed = b"VALUE = 2\n" * 100
            source.write_bytes(content)
            original = io.open_code

            def opener(path):
                return _ReaderProxy(original(path), lambda stream, size: changed)

            with mock.patch.object(check.io, "open_code", side_effect=opener):
                result = check.probe_source(source)
            self.assertTrue(result["ordinary_read"]["ok"])
            self.assertTrue(result["code_read"]["ok"])
            self.assertFalse(result["read_hashes_match"])
            self.assertFalse(result["changed_during_probe"])
            self.assertEqual(result["ordinary_read"]["sha256"], hashlib.sha256(content).hexdigest())
            self.assertEqual(result["code_read"]["sha256"], hashlib.sha256(changed).hexdigest())
            self.assertEqual(source.read_bytes(), content)

    def test_between_snapshot_hash_and_metadata_changes_are_distinguished(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            source.write_bytes(b"x" * 1000)
            before = check.probe_source(source)
            stamp = source.stat()
            source.write_bytes(b"y" * 1000)
            os.utime(source, ns=(stamp.st_atime_ns, stamp.st_mtime_ns + 1_000_000_000))
            after = check.probe_source(source)
            changes = check.compare_probes([before], [after])[str(source)]
            self.assertTrue(changes["hashes_changed"])
            self.assertTrue(changes["stat_changed"])
            self.assertFalse(changes["readability_changed"])
            self.assertFalse(before["changed_during_probe"])
            self.assertFalse(after["changed_during_probe"])

    def test_unavailable_stat_is_unknown_not_a_confirmed_file_change(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            source.write_bytes(b"VALUE = 1\n")
            with mock.patch.object(check, "_stat", side_effect=PermissionError(1, "stat denied", str(source))):
                before = check.probe_source(source)
                after = check.probe_source(source)
            self.assertIsNone(before["changed_during_probe"])
            self.assertIsNone(after["changed_during_probe"])
            changes = check.compare_probes([before], [after])[str(source)]
            self.assertIsNone(changes["stat_changed"])
            self.assertFalse(changes["hashes_changed"])
            self.assertFalse(changes["readability_changed"])

    def test_size_guard_prevents_a_full_read_of_an_oversized_source(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            source.write_bytes(b"x" * 1000)
            result = check.probe_source(source, max_bytes=64)
            for mode in ("ordinary_read", "code_read"):
                self.assertFalse(result[mode]["ok"])
                self.assertEqual(result[mode]["stage"], "limit")
                self.assertNotIn("sha256", result[mode])


class ProcessIsolationTests(unittest.TestCase):
    def _fixture(self, td):
        root = Path(td) / "project with spaces"
        report_root = Path(td) / "reports"
        output_root = Path(td) / "data outputs"
        root.mkdir()
        report_root.mkdir()
        # Tiny package-file fixtures: locating these must not execute __init__.
        for package in ("datashader", "matplotlib"):
            folder = root / package
            folder.mkdir()
            (folder / "__init__.py").write_text("raise AssertionError('source discovery imported a package')\n")
        (root / "datashader" / "resampling.py").write_text("# source probe fixture\nVALUE = 1\n")
        store = output_root / "zarr" / "sample.zarr"
        store.mkdir(parents=True)
        (store / ".zattrs").write_bytes(b'{"test":"immutable"}\n')
        (store / "raw_counts.bin").write_bytes(b"\x00\x01\x02raw-count-sentinel")
        (root / "workflow_config.json").write_text(json.dumps({"output_root": str(output_root)}))
        return root, report_root, store

    def _run(self, root, report_root, modules, timeout=10):
        before = set(report_root.glob("step1_check_*"))
        printed, errors = io.StringIO(), io.StringIO()
        with redirect_stdout(printed), redirect_stderr(errors):
            result = check.main(["check", "--project-root", str(root), "--report-root", str(report_root),
                                 "--timeout", str(timeout), "--modules", *modules])
        created = set(report_root.glob("step1_check_*")) - before
        self.assertEqual(len(created), 1, (printed.getvalue(), errors.getvalue()))
        report_dir = created.pop()
        summary = json.loads((report_dir / "summary.json").read_text())
        return result, summary, printed.getvalue(), errors.getvalue()

    def test_failure_logs_survive_child_open_denial_and_next_worker_is_fresh(self):
        with tempfile.TemporaryDirectory() as td:
            root, report_root, store = self._fixture(td)
            baseline = {p.name: (p.read_bytes(), p.stat().st_mtime_ns) for p in store.iterdir()}
            scientific = {name: sys.modules.get(name) for name in ("numpy", "pandas", "matplotlib", "datashader", "spatialdata", "cudf")}
            poison_key = "_xenium_process_test_poison"
            environment_key = "XENIUM_PROCESS_TEST_POISON"
            previous_environment = os.environ.get(environment_key)
            (root / "step1_test_poison.py").write_text(
                "import builtins, io, os\n"
                f"builtins.{poison_key} = True\n"
                f"os.environ[{environment_key!r}] = 'child-only'\n"
                "print('SYNTHETIC_CHILD_DENIAL', flush=True)\n"
                "def deny_new_open(*args, **kwargs):\n"
                "    raise PermissionError(1, 'new-file opens denied in this child', str(args[0]) if args else '')\n"
                "builtins.open = deny_new_open\n"
                "io.open = deny_new_open\n"
                "io.open_code = deny_new_open\n"
                "os.open = deny_new_open\n"
                "raise PermissionError(1, 'synthetic import denial', '/synthetic/datashader/resampling.py')\n"
            )
            (root / "step1_test_clean.py").write_text(
                "import builtins, os\nfrom pathlib import Path\n"
                f"assert not hasattr(builtins, {poison_key!r})\n"
                f"assert os.environ.get({environment_key!r}) == {previous_environment!r}\n"
                "assert Path(__file__).read_text()\n"
                "print('SYNTHETIC_FRESH_WORKER', flush=True)\n"
            )
            code, summary, printed, errors = self._run(root, report_root, ["step1_test_poison", "step1_test_clean"])
            self.assertEqual(code, 1)
            self.assertEqual(summary["python_executable"], sys.executable)
            failed, healthy = summary["workers"]
            self.assertEqual([failed["status"], healthy["status"]], ["failed", "success"])
            self.assertNotEqual(failed["pid"], healthy["pid"])
            for worker in (failed, healthy):
                self.assertNotEqual(worker["pid"], os.getpid())
                self.assertIsNotNone(worker["returncode"])
                payload = worker["worker_result"]
                self.assertEqual(payload["before"]["process"]["python_executable"], sys.executable)
                self.assertEqual(payload["before"]["process"]["sys_prefix"], sys.prefix)
                self.assertEqual(json.loads(Path(worker["result_path"]).read_text())["status"], payload["status"])
                self.assertEqual(len(payload["before"]["sources"]), 2)
            payload = failed["worker_result"]
            self.assertEqual(payload["import_error"]["type"], "PermissionError")
            self.assertEqual(payload["import_error"]["errno"], 1)
            self.assertEqual(payload["import_error"]["filename"], "/synthetic/datashader/resampling.py")
            self.assertTrue(all(item["ok"] for item in payload["before"]["sources"]))
            self.assertTrue(all(not item["ok"] for item in payload["after"]["sources"]))
            self.assertTrue(all(change["readability_changed"] for change in payload["source_changes"].values()))
            self.assertIn("SYNTHETIC_CHILD_DENIAL", Path(failed["stdout_path"]).read_text())
            self.assertIn("PermissionError", Path(failed["stderr_path"]).read_text())
            self.assertIn("SYNTHETIC_FRESH_WORKER", Path(healthy["stdout_path"]).read_text())
            self.assertNotIn("SYNTHETIC_CHILD_DENIAL", printed)
            self.assertLess(len(printed) + len(errors), 16_000)
            self.assertFalse(hasattr(builtins, poison_key))
            self.assertEqual(os.environ.get(environment_key), previous_environment)
            for name, original in scientific.items():
                self.assertIs(sys.modules.get(name), original, f"Scientific package imported into supervisor: {name}")
            self.assertEqual({p.name for p in store.iterdir()}, set(baseline))
            for path in store.iterdir():
                self.assertEqual(path.read_bytes(), baseline[path.name][0])
                self.assertEqual(path.stat().st_mtime_ns, baseline[path.name][1])
            # Metadata reflects the actual test environment, never an invented lock match.
            recorded = healthy["worker_result"]["source_locations"]["datashader"]
            try:
                actual = metadata.version("datashader")
            except metadata.PackageNotFoundError:
                self.assertIn("error", recorded)
            else:
                self.assertEqual(recorded["version"], actual)

    @unittest.skipUnless(os.name == "posix" and Path("/proc").is_dir(), "POSIX process-group check")
    def test_timeout_terminates_descendants_and_reaps_worker(self):
        with tempfile.TemporaryDirectory() as td:
            root, report_root, _ = self._fixture(td)
            marker = root / "timeout_pids.json"
            (root / "step1_test_timeout.py").write_text(
                "import json, os, subprocess, sys, time\nfrom pathlib import Path\n"
                f"marker = Path({str(marker)!r})\n"
                "descendant = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)', str(marker)], "
                "stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
                "marker.write_text(json.dumps({'worker':os.getpid(),'descendant':descendant.pid}))\n"
                "print('SYNTHETIC_TIMEOUT_STARTED', flush=True)\n"
                "time.sleep(60)\n"
            )
            def state(pid):
                try:
                    return Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()[0]
                except FileNotFoundError:
                    return None

            started = time.monotonic()
            pids = None
            try:
                code, summary, _, _ = self._run(root, report_root, ["step1_test_timeout"], timeout=2)
                elapsed = time.monotonic() - started
                self.assertLess(elapsed, 10)
                self.assertEqual(code, 1)
                worker = summary["workers"][0]
                self.assertEqual(worker["status"], "timeout")
                self.assertIsNotNone(worker["returncode"])
                self.assertNotEqual(worker["returncode"], 0)
                self.assertTrue(marker.is_file(), "Timeout happened before the intended fixture import began.")
                pids = json.loads(marker.read_text())
                self.assertEqual(worker["pid"], pids["worker"])
                with self.assertRaises(ChildProcessError):
                    os.waitpid(worker["pid"], os.WNOHANG)  # Supervisor already reaped it.
                until = time.monotonic() + 1
                while state(pids["descendant"]) not in (None, "Z") and time.monotonic() < until:
                    time.sleep(.02)
                self.assertIn(state(pids["descendant"]), (None, "Z"))
                self.assertIn("SYNTHETIC_TIMEOUT_STARTED", Path(worker["stdout_path"]).read_text())
            finally:
                # If a regression leaves our descendant alive, remove only that
                # fixture process (its command line carries this unique path).
                if pids is None and marker.exists():
                    pids = json.loads(marker.read_text())
                if pids and state(pids["descendant"]) not in (None, "Z"):
                    command = Path(f"/proc/{pids['descendant']}/cmdline").read_bytes()
                    if str(marker).encode() in command:
                        os.kill(pids["descendant"], signal.SIGKILL)

    def test_invalid_cli_modes_and_options_stop_before_launching_a_worker(self):
        with tempfile.TemporaryDirectory() as td:
            root, report_root, _ = self._fixture(td)
            invalid = [
                ["check", "--timeout", "-1"],
                ["check", "--timeout", "nan"],
                ["check", "--timeout", "inf"],
                ["check", "--modules", "spatialdata;echo"],
                ["preview", "--all", "--sample-id", "sample"],
                ["preview", "--channel", "-1"],
                ["preview", "--sample-id", " "],
                ["preview", "--roi-um", "0", "0", "-1", "1"],
                ["preview", "--roi-um", "0", "0", "nan", "1"],
            ]
            for argv in invalid:
                with self.subTest(argv=argv), mock.patch.object(check, "_launch") as launch, redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit) as error:
                        check.main([*argv, "--project-root", str(root), "--report-root", str(report_root)])
                    self.assertEqual(error.exception.code, 2)
                    launch.assert_not_called()
            self.assertEqual(list(report_root.iterdir()), [])


class PreviewSafetyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("step1_preview_worker_under_test", SCRIPT.with_name("step1_preview_worker.py"))
        cls.preview = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.preview)

    def test_dependency_denial_stops_before_config_manifest_or_sample_reads(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "xenium_workflow").mkdir()
            original_import = builtins.__import__
            original_path = sys.path[:]
            for denied in ("matplotlib", "spatialdata"):
                with self.subTest(denied=denied):
                    fake_matplotlib = ModuleType("matplotlib")
                    fake_matplotlib.use = mock.Mock()
                    fake_matplotlib.pyplot = ModuleType("matplotlib.pyplot")
                    calls = []

                    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
                        calls.append(name)
                        if name == denied:
                            raise PermissionError(1, "synthetic dependency denial", f"/environment/{name}/__init__.py")
                        if name in {"matplotlib", "matplotlib.pyplot"}:
                            return fake_matplotlib
                        if name.startswith("xenium_workflow"):
                            raise AssertionError("Workflow imports reached before dependencies were ready")
                        return original_import(name, globals, locals, fromlist, level)

                    try:
                        with mock.patch.object(builtins, "__import__", side_effect=guarded_import), \
                             mock.patch.object(Path, "read_text", side_effect=AssertionError("Configuration/data read before successful imports")) as read:
                            with self.assertRaises(PermissionError):
                                self.preview.run_preview(root)
                        read.assert_not_called()
                        self.assertIn(denied, calls)
                        self.assertFalse(any(name.startswith("xenium_workflow") for name in calls))
                    finally:
                        sys.path[:] = original_path

    def test_failed_render_preserves_previous_png_and_cleans_only_its_staging_file(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            destination = folder / "step1_morphology_and_labels.png"
            previous = b"previous-complete-preview-sentinel"
            destination.write_bytes(previous)
            before_mtime = destination.stat().st_mtime_ns
            sibling = folder / "unrelated.png"
            sibling.write_bytes(b"unrelated-sentinel")

            def failing_render(staging):
                self.assertNotEqual(staging, destination)
                staging.write_bytes(b"partially rendered output")
                raise PermissionError(1, "synthetic rendering failure")

            with self.assertRaises(PermissionError):
                self.preview._save_completed_figure(destination, failing_render, SimpleNamespace(close=mock.Mock()))
            self.assertEqual(destination.read_bytes(), previous)
            self.assertEqual(destination.stat().st_mtime_ns, before_mtime)
            self.assertEqual(sibling.read_bytes(), b"unrelated-sentinel")
            self.assertEqual({p.name for p in folder.iterdir()}, {destination.name, sibling.name})


if __name__ == "__main__":
    unittest.main(verbosity=2)
