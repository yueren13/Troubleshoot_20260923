# Step1: isolated import checks and a terminal preview runner

## What the latest notebook tells us

The active kernel is the intended Python 3.13.7 uv environment. Datashader 0.19.0,
SpatialData 0.7.2, and spatialdata-plot 0.3.3 match the supplied lockfile. Ordinary
reads and Python code reads of the first 64 bytes of three Datashader sources
passed, as did all notebook/figure/log directory write probes. The later normal
SpatialData import nevertheless failed opening datashader/resampling.py. A
subsequent Matplotlib import failed on matplotlib/__init__.py.

The original full traceback maps to CPython 3.13.7's source-opening operation
(_bootstrap_external.py line 1217); the full file.read() follows on line 1218.
The original failure was therefore at opening the source during the import
sequence. Full-source checks improve coverage, but a large-read problem has
not been established as the cause.

The new evidence makes a persistent mode/ownership problem confined to one file
less convincing. It does not yet identify the responsible library, filesystem,
runtime policy, or Jupyter behavior. The WorkflowConfig NameError is a consequence
of the earlier import cell stopping before that name was defined.

The user reports that a forced kernel restart allowed saving. That observation
matters, but the Jupyter server's actual Save error remains unavailable. The
roughly 8.59-billion-GiB capacity number from the first diagnostic is not evidence
of usable project storage or quota; this diagnostic does not use it.

## Why this version runs from a terminal

The previous diagnostic still attempted the failing import in the notebook's
own kernel. This version leaves scientific imports in disposable child Python
processes and writes their output to log files before reporting a short status.
The controller itself uses only the standard library. Separate processes prevent
one test's Python import state from carrying over into the next test; they cannot
guarantee protection from a filesystem problem shared across the workspace.

No new diagnostic notebook is required. Copy step1_process_check.py and
step1_preview_worker.py into your existing xenium_initial_processing folder.
Keep the existing xenium_workflow/ and workflow_config.json there. Open a
JupyterLab Terminal in that folder.

## 1. Run the isolated checks

Use the exact interpreter reported by the uploaded notebook:

```bash
XENIUM_PYTHON="/home/domino/reny28/Projects/Visium_projects/TBIO-8057/env/gpu_env/.venv/bin/python"

"$XENIUM_PYTHON" step1_process_check.py check --project-root . --timeout 60
```

The controller runs five independent import tests: matplotlib.pyplot, numba,
cudf, datashader, and spatialdata. Each gets a fresh process using that same
interpreter and its normal environment. It does not resolve the virtual
environment interpreter's symlink to a different Python path. Wholly absent
cuDF is optional and is reported as skipped; installed cuDF that fails to import
is retained as a diagnostic failure.

For each worker, the report records:

- The active interpreter, environment prefix, host, working directory, and
  selected process/thread identity and security-state fields.
- Full ordinary and code-loader reads of Datashader's resampling.py and
  Matplotlib's __init__.py, before and after the tested import.
- Whether an error occurred when opening or reading; byte counts, SHA-256
  hashes, and source metadata. Source text is never printed or executed by
  these read checks. Equal hashes compare the reads; they do not independently
  establish that an installation is authentic or undamaged.
- The normal import result, a compact traceback without source-line lookup,
  and a timeout if the process did not finish.

The paths printed at completion identify summary.json and the worker logs in a
new report directory. Keep the entire report directory; it is the useful evidence
to share if a check fails. The checks do not open Xenium stores.

The default timeout applies to each import test. A timeout is inconclusive, not
a diagnosis of a permission failure. If a known slow import times out, use a
larger --timeout value for that named test, for example:

```bash
"$XENIUM_PYTHON" step1_process_check.py check --project-root . \
  --modules spatialdata --timeout 180
```

Optional report placement: add --report-root /path/to/an/approved/writable/folder
if the project directory cannot accept diagnostic logs.

## Why test cuDF?

In Datashader 0.19.0, core.py imports utils.py before resampling.py. utils.py
attempts to import cuDF and catches Exception. An earlier cuDF import failure
can therefore be hidden by that optional-dependency handler. A direct cuDF test
can expose that earlier evidence. This does not mean cuDF is responsible: a GPU
initialization error with unchanged before/after source access may be unrelated.

## 2. Interpret the result

| Observation | Supported interpretation / next action |
|---|---|
| Source access fails before a scientific import | The failure also occurs in this fresh process before its target import. Check the reported file/open operation and runtime/filesystem context. |
| Access passes before import and fails afterward | A reproducible change is associated with the import sequence. Compare identities, timestamps, and platform logs; do not assume the library intentionally changed permissions. |
| Import fails but identical source reads still pass afterward | Preserve the compact traceback and exact paths; investigate import-time context or an intermittent access event. |
| Fresh workers pass but the notebook kernel fails | Focus on kernel startup, extensions, prior imports, import order, and session context. The interpreter path alone does not guarantee an identical runtime. |
| Workers also reproduce EPERM | The problem extends beyond the notebook's current Python process. The short reproduction and logs are suitable for workspace/platform support. |
| cuDF alone fails | Examine the actual exception and before/after access. An optional GPU import failure alone is not proof of the source-file failure's cause. |

An unchanged /proc snapshot does not exclude every filesystem or native-runtime
mechanism. Normal container fields such as Seccomp=2 or NoNewPrivs=1 are not by
themselves evidence of a problem. This program records those fields; it does not
change them, replace import loaders, or change package versions.

## 3. If the required imports work, run Step1 in a fresh process

The following runs the first currently selected region through the original
Step1 helpers. It performs normal imports in its worker and stops before opening
a sample if those imports fail:

```bash
"$XENIUM_PYTHON" step1_process_check.py preview --project-root .
```

Review the saved morphology/cell-label overview and centroid PNG in your existing
configured figures directory. If they look appropriate, run all regions currently
selected by your manifest and workflow configuration:

```bash
"$XENIUM_PYTHON" step1_process_check.py preview --project-root . --all
```

This uses your existing SpatialData stores and xenium_vanilla_cell tables. It
does not repeat Step0B or update the expression tables. It uses a headless
Matplotlib backend in the worker. Derived PNGs have the same names as the original
Step1 outputs; each is rendered to a separate temporary PNG before replacement.
The exact replacement guarantees still depend on the underlying filesystem.

Optional controls:

```bash
# Use one selected manifest sample and a different channel index.
"$XENIUM_PYTHON" step1_process_check.py preview --project-root . \
  --sample-id "YOUR_EXACT_SAMPLE_ID" --channel 1

# Native Xenium micrometre bounds for that one region (choose a real tissue ROI).
"$XENIUM_PYTHON" step1_process_check.py preview --project-root . \
  --sample-id "YOUR_EXACT_SAMPLE_ID" --roi-um 1000 1000 1500 1500
```

Preview mode defaults to no wall-clock timeout because real-region rendering can
take much longer than an import. Do not use --all with an ROI. A forced process
termination can leave an owned temporary PNG; it does not promote that unfinished
PNG over the prior completed output. The report identifies the worker/logs.

If process imports still fail, keep the Step0B stores and focus on the isolated
error. Do not continue later notebook cells: their missing names only add cascade
errors. The new evidence does not justify a blanket chmod, a package upgrade, or
a Datashader reinstall as the default next step.

## Notebook saving

The controller avoids scientific imports in the interactive notebook kernel.
It is not a demonstrated fix for Jupyter's Save operation. If saving fails again,
retain its exact notification or corresponding server log together with the
worker timestamp. That is needed to connect the two symptoms reliably.

## Validation and a correction

See VALIDATION.txt for tests of this version. The prior recovery bundle's
validation note incorrectly listed the local QA Datashader version as 0.19.0;
that environment actually contained 0.19.1. The user's installed 0.19.0 correctly
matches the supplied lockfile. The difference does not invalidate the observed
access failures, but it matters when describing what was tested. The validation
record for this version lists the actual versions and test limits explicitly.

## Primary source references

- Exact Python source for the original traceback:
  https://github.com/python/cpython/blob/v3.13.7/Lib/importlib/_bootstrap_external.py
- Datashader's import order and optional cuDF handler:
  https://github.com/holoviz/datashader/blob/v0.19.0/datashader/core.py
  https://github.com/holoviz/datashader/blob/v0.19.0/datashader/utils.py
- Python code-opening API:
  https://docs.python.org/3.13/library/io.html#io.open_code
- Child processes and timeouts:
  https://docs.python.org/3.13/library/subprocess.html
- Jupyter server saving:
  https://jupyter-server.readthedocs.io/en/latest/developers/contents.html
