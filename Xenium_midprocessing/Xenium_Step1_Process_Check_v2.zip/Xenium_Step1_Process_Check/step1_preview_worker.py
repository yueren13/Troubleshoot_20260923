"""Run the existing Step1 preview logic in a disposable process.

Only run_preview() imports the scientific stack. This module does not edit
environment settings, raw inputs, or tables. Successful previews replace the
usual derived PNG files after rendering to separate temporary PNGs.
"""
from __future__ import annotations

import gc
import os
from pathlib import Path
import sys
import tempfile


def _save_completed_figure(destination: Path, render, plt) -> None:
    """Render to an owned temporary file, then replace the derived output."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(
        prefix="step1_render_", suffix=".png", dir=destination.parent
    )
    os.close(descriptor)
    staging = Path(name)
    fig = None
    try:
        fig = render(staging)
        plt.close(fig)
        fig = None
        if staging.stat().st_size == 0:
            raise RuntimeError(f"Preview renderer produced an empty PNG: {staging}")
        os.replace(staging, destination)
    finally:
        if fig is not None:
            plt.close(fig)
        try:
            staging.unlink(missing_ok=True)
        except OSError as exc:
            print(f"Temporary PNG cleanup failed: {staging}: {exc}", flush=True)


def run_preview(project_root: str | Path, *, select_all: bool = False,
                sample_id: str | None = None, channel: int = 0,
                roi_um: list[float] | None = None) -> dict:
    if select_all and sample_id is not None:
        raise ValueError("Choose all selected regions or one sample_id, not both.")
    root = Path(project_root).expanduser().absolute()
    if not (root / "xenium_workflow").is_dir():
        raise FileNotFoundError(f"Existing xenium_workflow package not found in {root}")
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

    # Use the normal installed dependencies. An import denial must stop here,
    # before loading the manifest or opening any sample store.
    import matplotlib
    matplotlib.use("Agg")  # Worker-only headless rendering; parent is untouched.
    import matplotlib.pyplot as plt
    import spatialdata  # noqa: F401
    import spatialdata_plot  # noqa: F401; registers the SpatialData plot accessor.
    from xenium_workflow.config import WorkflowConfig
    from xenium_workflow.manifest import selected_samples
    from xenium_workflow.io import TABLE_KEY, read_sample
    from xenium_workflow.plotting import preview_spatialdata, centroid_map
    from xenium_workflow.reporting import log_event, log_exception

    config = WorkflowConfig.load(root / "workflow_config.json")
    samples = selected_samples(config)
    if sample_id is not None:
        samples = samples.loc[samples["sample_id"].eq(sample_id)]
        if len(samples) != 1:
            raise ValueError("sample_id must identify one currently selected manifest row.")
    elif not select_all:
        samples = samples.iloc[:1]
    if roi_um is not None and len(samples) != 1:
        raise ValueError("An ROI preview requires one selected region; omit --all.")

    result = {"regions_completed": 0, "samples": [], "figures": [],
              "table_key": TABLE_KEY, "channel": channel,
              "roi_um": roi_um, "output_root": str(config.root)}
    for row in samples.to_dict("records"):
        sdata = None
        try:
            print("Opening imported region:", row["sample_id"], flush=True)
            sdata = read_sample(row["zarr_path"])
            folder = config.root / "figures" / row["sample_id"]
            overview = folder / "step1_morphology_and_labels.png"
            centroids = folder / "step1_centroids_um.png"
            _save_completed_figure(
                overview,
                lambda path: preview_spatialdata(sdata, path, channel=channel), plt,
            )
            _save_completed_figure(
                centroids,
                lambda path: centroid_map(sdata.tables[TABLE_KEY], path,
                                         title=row["sample_name"] + " · native centroids"), plt,
            )
            paths = [overview, centroids]
            if roi_um is not None:
                roi = folder / "step1_roi.png"
                _save_completed_figure(
                    roi,
                    lambda path: preview_spatialdata(sdata, path, roi_um=roi_um,
                                                     channel=channel, dpi=200), plt,
                )
                paths.append(roi)
            log_event(config.root, "step1_preview", row["sample_id"], "complete")
            result["samples"].append(row["sample_id"])
            result["figures"].extend(str(path) for path in paths)
            result["regions_completed"] += 1
            print("Saved previews:", row["sample_id"], flush=True)
        except Exception as exc:
            try:
                log_exception(config.root, "step1_preview", row["sample_id"], exc)
            except Exception as log_error:
                print("Could not write workflow error log:", type(log_error).__name__, str(log_error), flush=True)
            raise
        finally:
            plt.close("all")
            del sdata
            gc.collect()
    return result
