"""Isolate Step1 imports/preview in fresh processes; diagnose access, never repair it.

Only standard-library modules load in the supervisor. No Xenium data are opened
by ``check``. ``preview`` delegates to the separate step1_preview_worker module.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
from importlib import metadata, util
import io
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time

MAX_SOURCE_BYTES = 4 * 1024 * 1024
DEFAULT_MODULES = ["matplotlib.pyplot", "numba", "cudf", "datashader", "spatialdata"]
RESULT_PREFIX = "XENIUM_PROCESS_RESULT "


def error_details(exc: BaseException) -> dict:
    frames, tb = [], exc.__traceback__
    while tb is not None:
        code = tb.tb_frame.f_code
        frames.append({"file": code.co_filename, "line": tb.tb_lineno, "function": code.co_name})
        tb = tb.tb_next
    return {"type": type(exc).__name__, "message": str(exc)[:2000],
            "errno": getattr(exc, "errno", None), "filename": str(getattr(exc, "filename", "") or ""),
            "frames": frames[-12:]}


def _stat(path: Path) -> dict:
    value = path.stat()
    return {"bytes": value.st_size, "mtime_ns": value.st_mtime_ns, "inode": value.st_ino,
            "device": value.st_dev, "mode": stat.filemode(value.st_mode),
            "uid": value.st_uid, "gid": value.st_gid}


def _stats_changed(first: dict, second: dict) -> bool | None:
    return None if not first or not second or "error" in first or "error" in second else first != second


def probe_source(path: str | Path, max_bytes: int = MAX_SOURCE_BYTES) -> dict:
    """Read an entire small .py file twice, distinguishing opening from reading.

    A size check on the open descriptor precedes read(); source bytes are never
    compiled/executed. This deliberately uses read(), as Python's loader does.
    """
    path = Path(path)
    result = {"path": str(path)}
    try:
        result["stat_before"] = _stat(path)
    except OSError as exc:
        result["stat_before"] = {"error": error_details(exc)}
    for name, opener in (("ordinary_read", lambda: path.open("rb")),
                         ("code_read", lambda: io.open_code(str(path)))):
        phase = "open"
        expected_size = None
        try:
            with opener() as stream:
                phase = "limit"
                info = os.fstat(stream.fileno())
                if path.suffix != ".py" or not stat.S_ISREG(info.st_mode) or info.st_size > max_bytes:
                    raise ValueError(f"Probe requires a regular .py file no larger than {max_bytes} bytes.")
                expected_size = info.st_size
                phase = "read"
                data = stream.read()
                if len(data) > max_bytes:
                    raise ValueError("Source grew beyond the probe size limit while reading.")
            matches = len(data) == expected_size
            result[name] = {"ok": matches, "stage": "complete" if matches else "length_check",
                            "bytes_read": len(data), "bytes_expected": expected_size,
                            "size_matches_open_stat": matches, "sha256": hashlib.sha256(data).hexdigest()}
            if not matches:
                result[name]["error"] = {"type": "SourceLengthMismatch",
                                         "message": "Read length differs from open-file size; this probe is inconclusive."}
        except Exception as exc:
            result[name] = {"ok": False, "stage": phase, "bytes_expected": expected_size,
                            "size_matches_open_stat": None, "error": error_details(exc)}
    try:
        result["stat_after"] = _stat(path)
    except OSError as exc:
        result["stat_after"] = {"error": error_details(exc)}
    result["changed_during_probe"] = _stats_changed(result["stat_before"], result["stat_after"])
    reads = [result[key] for key in ("ordinary_read", "code_read")]
    result["ok"] = all(item["ok"] for item in reads)
    result["read_hashes_match"] = reads[0].get("sha256") == reads[1].get("sha256") if result["ok"] else None
    return result


def compare_probes(before: list[dict], after: list[dict]) -> dict:
    previous = {item["path"]: item for item in before}
    changes = {}
    for item in after:
        old = previous.get(item["path"], {})
        hash_changes = [old[k]["sha256"] != item[k]["sha256"] for k in ("ordinary_read", "code_read")
                        if old.get(k, {}).get("ok") and item.get(k, {}).get("ok")]
        changes[item["path"]] = {
            "stat_changed": _stats_changed(old.get("stat_before", {}), item.get("stat_before", {})),
            "hashes_changed": any(hash_changes) if hash_changes else None,
            "readability_changed": any(old.get(k, {}).get("ok") != item.get(k, {}).get("ok")
                                       for k in ("ordinary_read", "code_read")),
        }
    return changes


def _locations() -> tuple[list[str], dict]:
    paths, details = [], {}
    for name, relative in (("datashader", "resampling.py"), ("matplotlib", "__init__.py")):
        try:
            spec = util.find_spec(name)  # Top-level only: does not initialize the package.
            if spec is None or not spec.origin:
                raise ModuleNotFoundError(f"Cannot locate {name} source.")
            path = str(Path(spec.origin).parent / relative)
            paths.append(path)
            details[name] = {"path": path, "version": metadata.version(name)}
        except Exception as exc:
            details[name] = {"error": error_details(exc)}
    return paths, details


def _snapshot(paths: list[str]) -> dict:
    result = {"pid": os.getpid(), "python_executable": sys.executable, "python_version": sys.version.split()[0], "sys_prefix": sys.prefix,
              "base_prefix": sys.base_prefix,
              "euid": os.geteuid() if hasattr(os, "geteuid") else None,
              "egid": os.getegid() if hasattr(os, "getegid") else None}
    try:
        result["hostname"] = socket.gethostname()
    except OSError as exc:
        result["hostname_error"] = error_details(exc)
    try:
        result["cwd"] = os.getcwd()
    except OSError as exc:
        result["cwd_error"] = error_details(exc)
    try:
        wanted = {"Uid", "Gid", "Groups", "NoNewPrivs", "Seccomp", "Seccomp_filters", "CapEff", "Threads"}
        result["thread_status"] = {key: value.strip() for line in Path("/proc/thread-self/status").read_text().splitlines()
                                   if ":" in line for key, value in [line.split(":", 1)] if key in wanted}
    except OSError as exc:
        result["thread_status_error"] = error_details(exc)
    try:
        mounts = []
        for line in Path("/proc/self/mountinfo").read_text().splitlines():
            left, right = line.split(" - ", 1)
            point = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), left.split()[4])
            mounts.append((point, right.split()[0]))
        result["mounts"] = {}
        for path in paths:
            matches = [(point, kind) for point, kind in mounts
                       if os.path.commonpath([os.path.abspath(path), point]) == point]
            if matches:
                point, kind = max(matches, key=lambda pair: len(pair[0]))
                result["mounts"][path] = {"mount_point": point, "filesystem_type": kind}
    except (OSError, ValueError, IndexError) as exc:
        result["mounts_error"] = error_details(exc)
    return result


def _missing_optional_cudf(target: str) -> bool:
    if target != "cudf" or util.find_spec("cudf") is not None:
        return False
    for name in ("cudf", "cudf-cu12", "cudf-cu13"):
        try:
            metadata.version(name)
            return False  # An installed but broken package must fail visibly.
        except metadata.PackageNotFoundError:
            pass
    return True


def _save(stream, value: dict) -> None:
    stream.seek(0)
    json.dump(value, stream, indent=2)
    stream.write("\n")
    stream.truncate()
    stream.flush()


def _worker(payload: dict) -> int:
    sys.path.insert(0, payload["project_root"])
    started = time.monotonic()
    result = {"mode": payload["mode"], "target": payload["target"], "pid": os.getpid(), "status": "running"}
    # stdout/stderr are files opened by the healthy parent before this process
    # starts. Structured snapshots survive even if opening new files later fails.
    paths, locations = _locations()
    result["source_locations"] = locations
    result["before"] = {"process": _snapshot(paths + [payload["project_root"]]),
                        "sources": [probe_source(path) for path in paths]}
    print(RESULT_PREFIX + json.dumps(result), flush=True)
    try:
        if payload["mode"] == "check":
            if _missing_optional_cudf(payload["target"]):
                result.update(status="skipped", reason="Optional cuDF is not installed.")
            else:
                module = importlib.import_module(payload["target"])
                result.update(status="success", imported_file=str(getattr(module, "__file__", "")),
                              imported_version=str(getattr(module, "__version__", "not exposed")))
        else:
            from step1_preview_worker import run_preview
            result["preview"] = run_preview(payload["project_root"], select_all=payload["select_all"],
                                             sample_id=payload["sample_id"], channel=payload["channel"],
                                             roi_um=payload["roi_um"])
            result["status"] = "success"
    except BaseException as exc:
        result.update(status="failed", import_error=error_details(exc))
        print(json.dumps({"event": "worker_error", "error": result["import_error"]}), file=sys.stderr, flush=True)
    print(RESULT_PREFIX + json.dumps(result), flush=True)  # Original failure, before post-probes.
    try:
        result["after"] = {"process": _snapshot(paths + [payload["project_root"]]),
                           "sources": [probe_source(path) for path in paths]}
        result["source_changes"] = compare_probes(result["before"]["sources"], result["after"]["sources"])
    except BaseException as exc:
        result["post_probe_error"] = error_details(exc)
    result["elapsed_seconds"] = round(time.monotonic() - started, 3)
    print(RESULT_PREFIX + json.dumps(result), flush=True)
    return 0 if result["status"] in {"success", "skipped"} else 1


def _stop_worker(process: subprocess.Popen) -> None:
    """Kill only the session/group we created, then reap its leader."""
    try:
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
    except ProcessLookupError:
        pass
    finally:
        while True:
            try:
                process.wait()
                break
            except KeyboardInterrupt:
                continue  # Already cancelling: still reap our worker.


def _launch(payload: dict, directory: Path, timeout: float) -> dict:
    output, errors, result_path = (directory / name for name in ("stdout.log", "stderr.log", "result.json"))
    record = {"target": payload["target"], "status": "launch_error", "pid": None, "returncode": None,
              "stdout_path": str(output), "stderr_path": str(errors), "result_path": str(result_path)}
    process = None
    try:
        directory.mkdir()
        with output.open("x+b") as stdout, errors.open("xb") as stderr, result_path.open("x+", encoding="utf-8") as result_file:
            command = [sys.executable, "-B", "-u", str(Path(__file__).absolute()),
                       "_worker", json.dumps(payload)]
            process = subprocess.Popen(command, cwd=payload["project_root"], stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=os.name == "posix")
            record["pid"] = process.pid
            try:
                record["returncode"] = process.wait(timeout=timeout if timeout else None)
                record["status"] = "success" if process.returncode == 0 else "failed"
            except subprocess.TimeoutExpired:
                _stop_worker(process)
                record.update(status="timeout", returncode=process.returncode)
            except KeyboardInterrupt:
                _stop_worker(process)
                record.update(status="cancelled", returncode=process.returncode)
            # Bound parsing even when a dependency produced very large logs.
            end = stdout.seek(0, os.SEEK_END)
            stdout.seek(0)
            chunks = [stdout.read(128 * 1024)]
            if end > 128 * 1024:
                stdout.seek(max(0, end - 512 * 1024))
                chunks.append(stdout.read(512 * 1024))
            found = None
            for chunk in chunks:
                for line in chunk.decode("utf-8", errors="replace").splitlines():
                    if line.startswith(RESULT_PREFIX):
                        try:
                            found = json.loads(line[len(RESULT_PREFIX):])
                        except ValueError:
                            pass
            if found is not None:
                record["worker_result"] = found
                _save(result_file, found)
                if record["status"] == "success":
                    record["status"] = found.get("status", "failed")
            else:
                record["result_read_error"] = {"message": "No structured worker result; inspect stdout/stderr logs."}
                _save(result_file, {"status": record["status"], "error": record["result_read_error"]})
                if record["status"] == "success":
                    record["status"] = "failed"
    except KeyboardInterrupt:
        if process is not None:
            if process.poll() is None:
                _stop_worker(process)
            record["returncode"] = process.wait()
        record["status"] = "cancelled"
    except Exception as exc:
        if process is not None and process.poll() is None:
            _stop_worker(process)
            record["returncode"] = process.returncode
        record.update(status="supervisor_error", supervisor_error=error_details(exc))
    return record


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if argv and argv[0] == "_worker":
        return _worker(json.loads(argv[1]))
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest="mode", required=True)
    for mode in ("check", "preview"):
        sub = modes.add_parser(mode)
        sub.add_argument("--project-root", type=Path, required=True)
        sub.add_argument("--report-root", type=Path)
        sub.add_argument("--timeout", type=float, default=60 if mode == "check" else 0,
                         help="Seconds per worker; 0 disables the timeout (preview default).")
        if mode == "check":
            sub.add_argument("--modules", nargs="+", default=DEFAULT_MODULES)
        else:
            selection = sub.add_mutually_exclusive_group()
            selection.add_argument("--all", dest="select_all", action="store_true")
            selection.add_argument("--sample-id")
            sub.add_argument("--channel", type=int, default=0)
            sub.add_argument("--roi-um", nargs=4, type=float, metavar=("XMIN", "YMIN", "XMAX", "YMAX"))
    args = parser.parse_args(argv)
    root = args.project_root.expanduser().absolute()
    if not root.is_dir() or not math.isfinite(args.timeout) or args.timeout < 0:
        parser.error("--project-root must exist; --timeout must be finite and nonnegative.")
    if args.mode == "check" and any(not re.fullmatch(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*", name) for name in args.modules):
        parser.error("--modules requires ordinary dotted Python module names.")
    if args.mode == "preview":
        roi = args.roi_um
        if args.channel < 0 or (args.sample_id is not None and not args.sample_id.strip()):
            parser.error("Use a nonnegative channel and a nonempty sample ID.")
        if roi and (not all(math.isfinite(v) for v in roi) or roi[0] >= roi[2] or roi[1] >= roi[3]):
            parser.error("ROI requires finite XMIN < XMAX and YMIN < YMAX.")
    report_root = (args.report_root or root).expanduser().absolute()
    report_root.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix=f"step1_{args.mode}_", dir=report_root))
    summary = {"mode": args.mode, "created_utc": datetime.now(timezone.utc).isoformat(),
               "python_executable": sys.executable, "project_root": str(root), "workers": [],
               "scope": "Isolated diagnostics/preview; no permission repairs or package changes."}
    print(f"Report directory: {directory}", flush=True)
    targets = args.modules if args.mode == "check" else ["preview"]
    with (directory / "summary.json").open("x+", encoding="utf-8") as stream:
        _save(stream, summary)
        for index, target in enumerate(targets):
            payload = {"mode": args.mode, "project_root": str(root), "target": target}
            if args.mode == "preview":
                payload.update(select_all=args.select_all, sample_id=args.sample_id, channel=args.channel, roi_um=args.roi_um)
            print(f"Starting {target} in a fresh process...", flush=True)
            record = _launch(payload, directory / f"{index + 1:02d}_{target.replace('.', '_')}", args.timeout)
            summary["workers"].append(record)
            _save(stream, summary)
            print(f"{target}: {record['status']} (exit {record['returncode']})", flush=True)
            result = record.get("worker_result", {})
            probes = [probe for phase in ("before", "after") for probe in result.get(phase, {}).get("sources", [])]
            if (any(not p.get("ok") or p.get("read_hashes_match") is False or p.get("changed_during_probe") is True for p in probes)
                    or any(any(value is True for value in change.values()) for change in result.get("source_changes", {}).values())
                    or result.get("post_probe_error")):
                print("  Source access/content observations need review; see this worker's result.json.", flush=True)
            if record["status"] == "cancelled":
                break
    print(f"Summary: {directory / 'summary.json'}", flush=True)
    statuses = [record["status"] for record in summary["workers"]]
    return 130 if "cancelled" in statuses else (0 if all(s in {"success", "skipped"} for s in statuses) else 1)


if __name__ == "__main__":
    raise SystemExit(main())
