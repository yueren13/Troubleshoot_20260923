"""Small access diagnostic for the Step1 import failure; standard library only.

This module never repairs permissions or installs packages. Access checks do not
import the scientific stack or open a Xenium store. Optional write probes create
and remove only their own temporary files in the notebook/figure/log folders.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from importlib import import_module, metadata, util
import io
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile
from uuid import uuid4


EXPECTED_VERSIONS = {
    "datashader": "0.19.0",
    "spatialdata": "0.7.2",
    "spatialdata-plot": "0.3.3",
}


def error_details(exc: Exception) -> dict:
    """Report the error without asking IPython to read inaccessible source files."""
    return {"type": type(exc).__name__, "errno": getattr(exc, "errno", None),
            "filename": str(getattr(exc, "filename", "") or ""),
            "message": str(exc)[:2000]}


def check_source_file(path: str | Path) -> dict:
    """Test ordinary reading and the code-loader operation independently."""
    path = Path(os.path.abspath(Path(path).expanduser()))
    result = {"path": str(path)}
    try:
        info = path.stat()
        result["stat"] = {"mode": stat.filemode(info.st_mode), "uid": info.st_uid,
                          "gid": info.st_gid, "bytes": info.st_size}
    except Exception as exc:
        result["stat"] = {"error": error_details(exc)}
    for name, opener in (("ordinary_read", lambda: path.open("rb")),
                         ("code_read", lambda: io.open_code(str(path)))):
        try:
            with opener() as stream:
                sample = stream.read(64)
            if not sample:
                raise ValueError("The source file is empty.")
            result[name] = {"ok": True, "bytes_read": len(sample)}
        except Exception as exc:
            result[name] = {"ok": False, "error": error_details(exc)}
    result["ok"] = all(result[name]["ok"] for name in ("ordinary_read", "code_read"))
    return result


def write_probe(directory: str | Path) -> dict:
    """Create, replace, read and remove two uniquely owned temporary files.

    A passing probe tests this Python process, not the Jupyter server's ability
    to save an existing notebook or its checkpoints.
    """
    directory = Path(directory)
    result = {"directory": str(directory), "ok": False, "cleanup_errors": []}
    owned = []
    try:
        free = shutil.disk_usage(directory).free
        result["filesystem_free_gib"] = round(free / (1024 ** 3), 2)
    except OSError as exc:
        result["disk_usage_error"] = error_details(exc)
    try:
        descriptor, first = tempfile.mkstemp(prefix="xenium_step1_probe_", dir=directory)
        owned.append(Path(first))
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(b"Xenium Step1 access probe\n")
        descriptor, second = tempfile.mkstemp(prefix="xenium_step1_probe_", dir=directory)
        owned.append(Path(second))
        os.close(descriptor)
        os.replace(first, second)  # Both paths were created exclusively by this probe.
        if Path(second).read_bytes() != b"Xenium Step1 access probe\n":
            raise OSError("Temporary-file readback differs from the written content.")
        result["ok"] = True
    except Exception as exc:
        result["error"] = error_details(exc)
    finally:
        for path in owned:
            try:
                path.unlink(missing_ok=True)
            except Exception as exc:
                result["cleanup_errors"].append({"path": str(path), "error": error_details(exc)})
        if result["cleanup_errors"]:
            result["ok"] = False
    return result


def collect_access_report(project_root: str | Path, *, check_writes: bool = True) -> dict:
    root = Path(os.path.abspath(Path(project_root).expanduser()))
    report = {"created_utc": datetime.now(timezone.utc).isoformat(),
              "python_executable": sys.executable, "python_version": sys.version.split()[0],
              "sys_prefix": sys.prefix, "project_root": str(root),
              "effective_uid": os.geteuid() if hasattr(os, "geteuid") else None,
              "effective_gid": os.getegid() if hasattr(os, "getegid") else None,
              "versions": {}, "source_checks": [], "write_probes": [],
              "warnings": [], "blockers": []}
    for name, expected in EXPECTED_VERSIONS.items():
        try:
            actual = metadata.version(name)
            report["versions"][name] = {"installed": actual, "expected": expected}
            if actual != expected:
                report["warnings"].append(f"{name}: installed {actual}, supplied lock has {expected}.")
        except Exception as exc:
            report["versions"][name] = {"error": error_details(exc), "expected": expected}
            report["blockers"].append(f"Cannot read installed metadata for {name}.")

    # Looking up this top-level package does not execute its initializer.
    try:
        spec = util.find_spec("datashader")
        if spec is None or not spec.origin or not spec.submodule_search_locations:
            raise RuntimeError("Cannot locate the active Datashader package.")
        package = Path(spec.origin).parent
        report["datashader_origin"] = str(spec.origin)
        for name in ("__init__.py", "core.py", "resampling.py"):
            item = check_source_file(package / name)
            report["source_checks"].append(item)
            if not item["ok"]:
                report["blockers"].append(f"Source access failed: {item['path']}")
    except Exception as exc:
        report["datashader_location_error"] = error_details(exc)
        report["blockers"].append("Cannot locate/read the Datashader source package.")

    destinations = [root]
    try:
        config_path = root / "workflow_config.json"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        output_root = Path(config["output_root"]).expanduser()
        if not output_root.is_absolute():
            raise ValueError("Expected an absolute output_root in the saved workflow configuration.")
        report["workflow_config"] = {"ok": True, "path": str(config_path),
                                     "output_root": str(output_root)}
        destinations.extend([output_root / "figures", output_root / "logs"])
    except Exception as exc:
        report["workflow_config"] = {"ok": False, "error": error_details(exc)}
        report["blockers"].append("Cannot read workflow_config.json/output_root; check the selected project folder.")

    if check_writes:
        for directory in dict.fromkeys(destinations):
            result = write_probe(directory)
            report["write_probes"].append(result)
            if not result["ok"]:
                report["blockers"].append(f"Temporary-file write/replace/cleanup failed: {directory}")
    else:
        report["warnings"].append("Write probes were skipped; notebook/output-folder write access is untested.")
    report["access_checks_passed"] = not report["blockers"]
    report["scope"] = (
        "These checks do not import the scientific stack, read/modify Xenium stores, "
        "repair permissions, or prove that Jupyter's server can save this notebook. "
        "Free disk space does not establish that a user/project quota is available."
    )
    return report


def print_access_report(report: dict) -> None:
    # Small text-only output; no dataframe/SpatialData representations or image data.
    print(json.dumps(report, indent=2, ensure_ascii=False))


def save_access_report(report: dict, directory: str | Path) -> Path:
    """Create a uniquely named diagnostic JSON; never overwrite an existing file."""
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = Path(directory) / f"Step1_access_diagnostics_{stamp}_{uuid4().hex[:8]}.json"
    with path.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    return path


def require_access(report: dict) -> None:
    if not report["access_checks_passed"]:
        raise RuntimeError(
            "Step1 paused before dependency imports or sample reads. Restore the failed access checks "
            "shown above, then restart the Step1 kernel and retry. No Step0B re-import is indicated."
        ) from None


def import_preview_dependencies() -> dict:
    """Test the actual current kernel after access checks; expose concise failures."""
    result = {}
    for name in ("spatialdata", "spatialdata_plot"):
        try:
            module = import_module(name)
            result[name] = {"file": str(getattr(module, "__file__", "")),
                            "version": str(getattr(module, "__version__", "unknown"))}
        except Exception as exc:
            detail = json.dumps(error_details(exc), ensure_ascii=False)
            raise RuntimeError(
                f"Import failed before opening a Xenium store ({name}): {detail}. "
                "Restore package/runtime access; use a fresh kernel before retrying."
            ) from None
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--read-only", action="store_true", help="Skip temporary-file write probes.")
    parser.add_argument("--save-report", action="store_true", help="Create a diagnostic JSON in project-root.")
    args = parser.parse_args()
    report = collect_access_report(args.project_root, check_writes=not args.read_only)
    print_access_report(report)
    if args.save_report:
        try:
            print("Diagnostic report:", save_access_report(report, args.project_root))
        except OSError as exc:
            print("Could not save report:", json.dumps(error_details(exc)))
            return 2
    return 0 if report["access_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
