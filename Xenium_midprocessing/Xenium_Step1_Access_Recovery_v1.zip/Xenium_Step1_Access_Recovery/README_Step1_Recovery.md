# Step1 access diagnostic and retry notebook

## What failed

Your error occurs at `read_sample()`'s first line, `import spatialdata as sd`.
SpatialData imports Datashader, and Python's source loader is denied access to
`datashader/resampling.py` in the existing `gpu_env` environment. The exception is
`PermissionError: [Errno 1] Operation not permitted`.

The call has not reached the Zarr path, workflow lock, completion marker, or
`sd.read_zarr()`. The imported data do not need to be regenerated because of this
traceback. The preceding `functools.partial` FutureWarnings are separate.

The traceback establishes an access denial, but cannot distinguish ordinary
permissions, an ACL/platform policy, or a filesystem/session problem. It does not
establish a dependency-version conflict. The inability to save the notebook is
also not explained by this traceback alone.

## Files and installation

Copy the contents of this folder into the existing `xenium_initial_processing`
folder, beside `workflow_config.json` and `xenium_workflow/`:

- `Step1_DatasetPreview_access_checked.ipynb`: clean retry copy of the attached
  Step1, with early access diagnostics and a dependency import check.
- `step1_runtime_check.py`: standard-library helper; also runnable in a terminal.
- This README.

The original `Step1_DatasetPreview.ipynb`, workflow configuration, helper package,
raw inputs, imported Zarr stores, and environment files are not replaced by this
bundle. The preview-generation cells still write the usual figures and logs.

## Recommended sequence

1. Copy any unsaved edits and the displayed error from the old browser tab into
   a separate safe location before closing/reloading it. A download from the
   file browser may contain only the last server-saved notebook version.
2. Open the new access-checked notebook with a fresh Step1 kernel using the same
   existing uv environment. The uploaded kernelspec is preserved. Restarting a
   kernel resets import state; it cannot repair a persistent file-access denial.
3. Run the setup and access-report cells. They print the actual interpreter,
   versions, source path, ordinary/source-code read results, and temporary-file
   write results. A small, uniquely named `Step1_access_diagnostics_*.json` is
   saved beside the notebooks if that directory is writable.
4. If checks pass, run the dependency-import check in that same kernel. Then
   continue with the original Step1 preview cells. You do not need to rerun Step0B.
5. If a check fails, use the table below. The notebook intentionally stops rather
   than attempting to change filesystem permissions or install packages.

| Result | Meaning and next action |
|---|---|
| `ordinary_read` fails | Direct file access is still denied. Restore access to the reported package file/parent directories in the current runtime. |
| Ordinary read passes, `code_read` fails | Python's code-loading access is specifically denied. Supply both results to the platform/environment administrator; broad chmod changes may not address it. |
| Both reads pass, actual import fails | Inspect the concise import error; another dependency or runtime operation may be failing. The small read probe is not a complete import test. |
| Package access and imports pass | Proceed with Step1 using the existing imported stores. A transient access problem may have cleared, but its original cause is not established. |
| Notebook-folder write probe fails | The kernel cannot complete the tested create/write/replace/read/delete operations there. Inspect the reported error and the specific directory. |
| Kernel probe passes but Jupyter Save fails | Obtain the actual Save notification/server error. The Jupyter server can differ from the kernel in environment, identity, host, or save policy. |

The helper uses the active top-level Datashader module specification to locate
the source without importing Datashader. It checks `open(..., 'rb')` and
`io.open_code()` independently; both read only up to 64 bytes. The subsequent
real import is the complete dependency-loading test. Mode/UID/GID information is
context only; the actual read result is authoritative for that operation.

The write probe creates two uniquely owned small files, tests replacement and
readback, and removes those files. It never opens an existing notebook for
writing. Cleanup failures are reported with the exact leftover paths. Free
filesystem space does not prove that a separate user/project quota is available.

## If Jupyter still cannot save

Try creating and saving a new tiny text file through JupyterLab in the same
directory. This exercises the server's save route, unlike running a write in a
notebook cell. Retain the exact error/banner. If a different directory works,
also check the old notebook's ownership and its parent/checkpoint directories.

If both package reads and saves fail, a broader runtime/filesystem issue is a
plausible shared cause, but it needs confirmation. The supplied traceback does
not demonstrate that cell output size or the earlier transcript-category warning
caused the saving problem. Minimal traceback display in the retry notebook keeps
error output small and avoids rich traceback source inspection; it is not a
guaranteed fix for Jupyter saving.

## Terminal diagnostic if the notebook is inconvenient

Use the exact interpreter from the notebook's `sys.executable`. The path below
matches the earlier Step0A report and your Step1 traceback:

```bash
XENIUM_KERNEL_PYTHON="/home/domino/reny28/Projects/Visium_projects/TBIO-8057/env/gpu_env/.venv/bin/python"
XENIUM_WORKFLOW_DIR="/home/domino/reny28/Projects/Xenium_projects/TBIO-8136/code/xenium_initial_processing"

"$XENIUM_KERNEL_PYTHON" "$XENIUM_WORKFLOW_DIR/step1_runtime_check.py" \
  --project-root "$XENIUM_WORKFLOW_DIR" --save-report
```

Add `--read-only` to skip the temporary-file write probes; omit `--save-report`
if no diagnostic JSON should be written. The terminal script does not import the
scientific stack. Its process may differ from the affected notebook kernel, so
retain where each report was generated.

## Conditional environment repair

First restore normal access to the environment directory, through the workspace
or filesystem support route if necessary. A reinstall cannot override an access
policy that still denies reading or replacing these files.

If diagnosis instead identifies an isolated damaged Datashader installation in
an environment you maintain, the supplied lock pins `datashader==0.19.0`. With
kernels using that environment stopped, a narrowly targeted reinstall is:

```bash
XENIUM_KERNEL_PYTHON="/home/domino/reny28/Projects/Visium_projects/TBIO-8057/env/gpu_env/.venv/bin/python"

uv pip install --python "$XENIUM_KERNEL_PYTHON" \
  --no-deps --reinstall --no-cache "datashader==0.19.0"

"$XENIUM_KERNEL_PYTHON" -c 'import datashader, spatialdata; print(datashader.__version__, spatialdata.__version__)'
```

This is optional and is not executed by either provided file. `--python`
targets the printed kernel environment; `--no-deps` avoids changing its other
packages. The explicit version comes from your lockfile; `uv pip install` does
not automatically enforce that lock. No project files or versions are changed
by the diagnostic. If reinstalling is also denied, stop and resolve the access
restriction rather than trying broad recursive permission changes.

## Scope and validation

See `VALIDATION.txt` for the completed tests of this recovery bundle. The user's
remote filesystem and Jupyter server are not accessible from this review. The
diagnostic and retry notebook can identify/reduce the failure, but cannot claim
that the remote permission or Save problem has already been repaired.

## Primary references

- Python PermissionError: https://docs.python.org/3.13/library/exceptions.html#PermissionError
- Python code-file opening: https://docs.python.org/3.13/library/io.html#io.open_code
- Python import failure behavior: https://docs.python.org/3.13/reference/import.html#loading
- Jupyter server file/contents management: https://jupyter-server.readthedocs.io/en/latest/developers/contents.html
- JupyterLab terminal context: https://jupyterlab.readthedocs.io/en/stable/user/terminal.html
- uv environment targeting: https://docs.astral.sh/uv/pip/environments/
- uv pip install options: https://docs.astral.sh/uv/reference/cli/#uv-pip-install
