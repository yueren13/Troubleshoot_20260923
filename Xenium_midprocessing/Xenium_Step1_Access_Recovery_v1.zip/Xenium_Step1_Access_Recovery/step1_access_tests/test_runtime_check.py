"""Focused, standard-library tests of the Step1 access diagnostic.

Fixtures and probes live only in temporary test directories. Permission failures
are injected because Unix mode bits alone do not constrain a root test runner.
"""
from __future__ import annotations

from contextlib import ExitStack
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import traceback
from types import SimpleNamespace
import unittest
from unittest import mock

HELPER = Path(__file__).resolve().parents[1] / "step1_runtime_check.py"
_spec = importlib.util.spec_from_file_location("step1_runtime_check_under_test", HELPER)
check = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(check)


class SourceAccessTests(unittest.TestCase):
    def test_code_loader_denied_even_when_ordinary_read_succeeds(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            source.write_text("ANSWER = 42\n", encoding="utf-8")
            failure = PermissionError(1, "Operation not permitted", str(source))
            with mock.patch.object(check.io, "open_code", side_effect=failure):
                result = check.check_source_file(source)
            self.assertTrue(result["ordinary_read"]["ok"])
            self.assertFalse(result["code_read"]["ok"])
            self.assertEqual(result["code_read"]["error"]["errno"], 1)
            self.assertEqual(result["code_read"]["error"]["filename"], str(source))
            self.assertFalse(result["ok"])
            self.assertIn("mode", result["stat"])

    def test_ordinary_read_denied_without_short_circuiting_code_read(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "resampling.py"
            source.write_text("ANSWER = 42\n", encoding="utf-8")
            original = Path.open

            def deny_ordinary(path, *args, **kwargs):
                if path == source:
                    raise PermissionError(13, "Permission denied", str(source))
                return original(path, *args, **kwargs)

            with mock.patch.object(Path, "open", new=deny_ordinary):
                result = check.check_source_file(source)
            self.assertFalse(result["ordinary_read"]["ok"])
            self.assertEqual(result["ordinary_read"]["error"]["errno"], 13)
            self.assertTrue(result["code_read"]["ok"])
            self.assertFalse(result["ok"])

    def test_missing_source_reports_both_failures_without_raising(self):
        with tempfile.TemporaryDirectory() as td:
            result = check.check_source_file(Path(td) / "absent.py")
        self.assertFalse(result["ok"])
        self.assertIn("error", result["stat"])
        for key in ("ordinary_read", "code_read"):
            self.assertEqual(result[key]["error"]["type"], "FileNotFoundError")


class WriteProbeTests(unittest.TestCase):
    def _fixture(self, td):
        directory = Path(td)
        saved = directory / "Step1_DatasetPreview.ipynb"
        saved.write_bytes(b'{"cells": [], "metadata": {"sentinel": true}}\n')
        baseline = saved.read_bytes(), saved.stat().st_mtime_ns
        return directory, saved, baseline

    def _assert_existing_preserved(self, saved, baseline):
        self.assertEqual(saved.read_bytes(), baseline[0])
        self.assertEqual(saved.stat().st_mtime_ns, baseline[1])

    def test_success_leaves_no_probe_files_and_preserves_existing_notebook(self):
        with tempfile.TemporaryDirectory() as td:
            directory, saved, baseline = self._fixture(td)
            result = check.write_probe(directory)
            self.assertTrue(result["ok"], result)
            self.assertEqual(result["cleanup_errors"], [])
            self.assertEqual(list(directory.iterdir()), [saved])
            self._assert_existing_preserved(saved, baseline)

    def test_replace_error_is_reported_and_both_owned_files_are_removed(self):
        with tempfile.TemporaryDirectory() as td:
            directory, saved, baseline = self._fixture(td)
            with mock.patch.object(check.os, "replace", side_effect=PermissionError(1, "Operation not permitted")):
                result = check.write_probe(directory)
            self.assertFalse(result["ok"])
            self.assertEqual(result["error"]["type"], "PermissionError")
            self.assertEqual(result["error"]["errno"], 1)
            self.assertEqual(result["cleanup_errors"], [])
            self.assertEqual(list(directory.iterdir()), [saved])
            self._assert_existing_preserved(saved, baseline)

    def test_cleanup_failure_is_a_failure_with_the_exact_leftover_reported(self):
        with tempfile.TemporaryDirectory() as td:
            directory, saved, baseline = self._fixture(td)
            original = Path.unlink

            def deny_owned_cleanup(path, *args, **kwargs):
                if path.name.startswith("xenium_step1_probe_") and path.exists():
                    raise PermissionError(1, "Operation not permitted", str(path))
                return original(path, *args, **kwargs)

            with mock.patch.object(Path, "unlink", new=deny_owned_cleanup):
                result = check.write_probe(directory)
            self.assertFalse(result["ok"])
            self.assertEqual(len(result["cleanup_errors"]), 1)
            leftover = Path(result["cleanup_errors"][0]["path"])
            self.assertTrue(leftover.is_file())
            self.assertEqual(result["cleanup_errors"][0]["error"]["errno"], 1)
            self._assert_existing_preserved(saved, baseline)
            leftover.unlink()  # Test cleanup, after restoring the real unlink.
            self.assertEqual(list(directory.iterdir()), [saved])

    def test_missing_directory_is_reported_and_not_created(self):
        with tempfile.TemporaryDirectory() as td:
            missing = Path(td) / "missing"
            result = check.write_probe(missing)
            self.assertFalse(result["ok"])
            self.assertEqual(result["error"]["type"], "FileNotFoundError")
            self.assertFalse(missing.exists())


class ReportAndImportGuardTests(unittest.TestCase):
    def _report_fixture(self, td):
        base = Path(td)
        project = base / "project"
        package = base / "installed" / "datashader"
        output = base / "output"
        for path in (project, package, output / "figures", output / "logs"):
            path.mkdir(parents=True)
        for name in ("__init__.py", "core.py", "resampling.py"):
            (package / name).write_text("raise AssertionError('package code must never execute during a source check')\n")
        (project / "workflow_config.json").write_text(json.dumps({"output_root": str(output)}))
        notebook = project / "Step1_DatasetPreview.ipynb"
        notebook.write_text('{"cells":[],"metadata":{}}\n')
        store = output / "zarr" / "sample.zarr"
        store.mkdir(parents=True)
        raw = store / "raw_counts_sentinel.bin"
        raw.write_bytes(b"immutable raw-data sentinel\x00\x01\x02")
        spec = SimpleNamespace(origin=str(package / "__init__.py"), submodule_search_locations=[str(package)])
        return project, package, output, notebook, raw, spec

    def test_report_uses_current_kernel_without_importing_packages_or_mutating_data(self):
        with tempfile.TemporaryDirectory() as td:
            project, package, output, notebook, raw, spec = self._report_fixture(td)
            before = {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in (notebook, raw)}
            with ExitStack() as stack:
                finder = stack.enter_context(mock.patch.object(check.util, "find_spec", return_value=spec))
                stack.enter_context(mock.patch.object(check.metadata, "version", side_effect=lambda name: check.EXPECTED_VERSIONS[name]))
                importer = stack.enter_context(mock.patch.object(check, "import_module", side_effect=AssertionError("Scientific import during file preflight")))
                report = check.collect_access_report(project)
            self.assertTrue(report["access_checks_passed"], report)
            finder.assert_called_once_with("datashader")  # Never a dotted-name parent import.
            importer.assert_not_called()
            self.assertEqual(report["python_executable"], sys.executable)
            self.assertEqual(report["sys_prefix"], sys.prefix)
            self.assertEqual(len(report["write_probes"]), 3)
            self.assertIn("not", report["scope"])
            self.assertIn("prove that Jupyter's server can save", report["scope"])
            self.assertIn("quota", report["scope"])
            self.assertEqual({Path(r["path"]).name for r in report["source_checks"]}, {"__init__.py", "core.py", "resampling.py"})
            for path, (content, mtime) in before.items():
                self.assertEqual(path.read_bytes(), content)
                self.assertEqual(path.stat().st_mtime_ns, mtime)
            self.assertFalse(list(project.rglob("xenium_step1_probe_*")))
            self.assertFalse(list(output.rglob("xenium_step1_probe_*")))
            self.assertEqual(list(raw.parent.iterdir()), [raw])
            check.require_access(report)

    def test_code_denial_propagates_to_blockers_and_access_guard(self):
        with tempfile.TemporaryDirectory() as td:
            project, package, _, _, _, spec = self._report_fixture(td)
            original = io.open_code

            def deny_resampling(path):
                if Path(path).name == "resampling.py":
                    raise PermissionError(1, "Operation not permitted", str(path))
                return original(path)

            with mock.patch.object(check.util, "find_spec", return_value=spec), \
                 mock.patch.object(check.metadata, "version", side_effect=lambda name: check.EXPECTED_VERSIONS[name]), \
                 mock.patch.object(check.io, "open_code", side_effect=deny_resampling):
                report = check.collect_access_report(project, check_writes=False)
            self.assertFalse(report["access_checks_passed"])
            self.assertTrue(any("resampling.py" in value for value in report["blockers"]))
            self.assertEqual(report["write_probes"], [])
            self.assertTrue(any("untested" in value for value in report["warnings"]))
            with self.assertRaisesRegex(RuntimeError, "paused before dependency imports or sample reads"):
                check.require_access(report)

    def test_import_failure_is_concise_and_hides_original_loader_traceback(self):
        def inaccessible_dependency_loader(name):
            raise PermissionError(1, "Operation not permitted: " + "x" * 10_000, "/env/datashader/resampling.py")

        with mock.patch.object(check, "import_module", side_effect=inaccessible_dependency_loader) as importer:
            try:
                check.import_preview_dependencies()
            except RuntimeError as exc:
                rendered = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
                self.assertTrue(exc.__suppress_context__)
                self.assertIsNone(exc.__cause__)
                self.assertNotIn("inaccessible_dependency_loader", rendered)
                self.assertIn("Import failed before opening a Xenium store (spatialdata)", str(exc))
                self.assertIn("PermissionError", str(exc))
                self.assertIn("/env/datashader/resampling.py", str(exc))
                self.assertLess(len(str(exc)), 2500)
            else:
                self.fail("An inaccessible dependency must stop imports.")
        importer.assert_called_once_with("spatialdata")

    def test_successful_import_guard_reports_both_actual_module_paths(self):
        modules = {
            "spatialdata": SimpleNamespace(__file__="/kernel/site-packages/spatialdata/__init__.py", __version__="0.7.2"),
            "spatialdata_plot": SimpleNamespace(__file__="/kernel/site-packages/spatialdata_plot/__init__.py", __version__="0.3.3"),
        }
        with mock.patch.object(check, "import_module", side_effect=modules.__getitem__) as importer:
            result = check.import_preview_dependencies()
        self.assertEqual(importer.call_args_list, [mock.call("spatialdata"), mock.call("spatialdata_plot")])
        for name, module in modules.items():
            self.assertEqual(result[name]["file"], module.__file__)
            self.assertEqual(result[name]["version"], module.__version__)


if __name__ == "__main__":
    unittest.main(verbosity=2)
