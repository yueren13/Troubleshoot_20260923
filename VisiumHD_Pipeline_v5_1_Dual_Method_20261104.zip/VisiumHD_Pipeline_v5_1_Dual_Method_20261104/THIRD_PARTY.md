# Third-party software and attribution

This adapter invokes installed Bin2cell functions. It does not vendor or relicense Bin2cell's implementation. Bin2cell upstream: Teichlab/bin2cell, authors Krzysztof Polanski and Nadav Yayon; upstream MIT license (2024). Consult the installed distribution/source for its current license and citation.

StarDist, CSBDeep, TensorFlow, Proseg, AnnData, Scanpy, SpatialData, Rasterio, Shapely/GEOS, GeoPandas, PyArrow, Zarr, NumPy, SciPy, pandas, Jupyter and other dependencies retain their respective licenses. Follow the upstream citation instructions for analyses and publications. The retained palette helper records its original palette attribution.

**Pipeline license:** no top-level license was supplied in the uploaded working archive. This consolidation adds no blanket redistribution grant. The user/organization should choose an authorized license and review internal paths/examples before publication. The optional private reference pack must not be published accidentally.
