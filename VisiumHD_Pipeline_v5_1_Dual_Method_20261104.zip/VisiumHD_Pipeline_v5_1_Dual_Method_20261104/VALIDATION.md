# Validation — 0.5.1rc1

**Scope:** consolidated code and dependency-available checks, not a production scientific certification. Build date November 4, 2026.

## Executed in the build environment

- Complete retained available test collection: **636 passed, 19 skipped** (`validation/pytest_available.log`).
- Fresh extraction of the final executable tree: **636 passed, 19 skipped**, independently rerun (`validation/pytest_fresh_zip.log`); all executable/test/template bytes match the delivered tree.
- New mandatory tests included in that total: **45 passed** (33 numerical/routing checks + 12 Project Center/configuration/reporting checks).
- Primary/secondary-off route selection, exact sparse assignment sums, unchanged bin coordinates, hole/disconnected-component preservation, projected footprint equality, invalid horizon/grid rejection and bounded CPU-affinity restoration were executed.
- Real CSV/config/state save/reopen, unchanged original inputs, stale-edit/consent rejection, completed-result guards, method-specific analysis paths and same-method scVI group constraints were executed.
- Upstream-call orchestration uses explicitly identified test doubles in the mandatory tests. Those tests do **not** demonstrate installed Bin2cell behavior or scientific persistence.
- The real official Bin2cell and named SpatialData smoke tests are supplied separately and were dependency-skipped here. No Proseg binary or StarDist GPU inference was run.

## Skips: do not count these as passes

Nineteen reported skip entries include **sixteen dependency-gated modules** (AnnData/SpatialData/PyArrow/widget functionality) plus one optional original-workflow cross-version comparison and two opt-in scVI tests. A skipped module can contain multiple assertions/tests; this is not a claim that only nineteen scientific assertions remain untested.

The two new required target modules are:

| Test | What it really does when dependencies are available |
|---|---|
| `tests/test_dual_science_optional.py` | Installed official Bin2cell expansion/aggregation on tiny synthetic raw counts and a synthetic precomputed prior; real H5AD/GeoParquet outputs, count conservation and reuse. No StarDist inference. |
| `tests/test_dual_spatial_optional.py` | Append two synthetic prepared cell populations to a real tiny SpatialData store, verify CSR count readback/IDs/regions, preserve a legacy `cells` table and check reuse. Neither population is real Proseg inference. |

Run `notebooks/01_Dual_Method_Target_Smoke.ipynb` in the actual spatial-worker environment. It requires **two passed, zero skipped/failed/error** tests. It never installs packages or touches study inputs. Secondary density inference remains an additional separate pilot even if those two tests pass.

## Static and packaging checks

`tools/validate_repository.py --mode repository` checks syntax, notebook validity and empty execution state. `tools/audit_share_bundle.py` checks structural JSON/CSV validity and known private-deployment/credential patterns. Exact final counts and fresh-ZIP test output are recorded alongside this file in `validation/`. These tools do not prove biological correctness, complete privacy screening, filesystem durability or license authorization.

## Source continuity and baseline failures

The uploaded available suite had 13 failures, 601 passes and 17 skips before cleanup; several fixtures no longer matched its actual active code, and two old example CSVs were absent. The consolidated suite repairs those generic fixtures/contracts and excludes 23 tests of a personal one-off correction notebook removed from the shareable package. Comparing 636 to 601 alone is therefore not a scientific accuracy comparison or a count of all features added. See `validation/SOURCE_AUDIT.md`.

## Not verified here

The real mounted study files, whole-slide memory/time, GPU models, live Jupyter frontend interaction, original H&E/annotation registration, biological segmentation quality, CPU/GPU environment compatibility, and actual master writes were unavailable. The isolated internal SpatialData shapes reader must pass target checks for the installed SpatialData version. Memory estimates are conservative heuristics rather than limits or performance guarantees. Method comparisons are descriptive, not ground-truth accuracy. The first target pilot should preserve the working old code/workspace and use one sample before scaling out.

No GitHub commits, biological approvals, image repairs, source deletions or changes to the user's installed environment were performed.
