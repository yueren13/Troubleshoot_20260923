# Configuration entry points

Use the sample/asset sheets in `examples/` for new projects. `settings.example.json` is a complete advanced profile: replace `/EDIT/...` locations before use. `samples.csv` is a header-only full-schema template, not a runnable study. Do not manually create review signatures. The Project Center manages compatibility exports in its workspace.
