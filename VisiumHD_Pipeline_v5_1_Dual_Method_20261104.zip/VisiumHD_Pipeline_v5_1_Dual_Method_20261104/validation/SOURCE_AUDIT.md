# Source and change audit

Release: 0.5.1rc1, 2026-11-04.

## Exact input

`VisiumHD_Pipeline_v5_Project_Center_20261014.zip`, 3,390,881 bytes; SHA-256 `bec250e9ffc09f041c1c1de1c7b19451121c9be1efde78c4ff5584f2a852374b`.

The upload was extracted into a separate staging tree after checking paths. The original ZIP was not changed. The internal absolute-looking deployment prefix was stripped from the new release tree; it is not a required installation location.

## Verified active defaults from that upload

```json
{
  "stardist": {
    "model": "2D_versatile_he",
    "prob_thresh": 0.02,
    "nms_thresh": 0.3,
    "target_mpp": 0.3
  },
  "original_cells_mode": "proseg"
}
```

These are source configuration values, not measured segmentation-quality results. New generic primary H&E defaults retain 0.02/0.30. Existing imported settings remain explicit.

## Source continuity

Compared with the uploaded active `vhd/**/*.py`: **61 files byte-identical**, **19 modified**, **6 new files**. No active `vhd` Python file from that upload was removed. Exact per-file hashes are in `source_changes.json`.

The new `vhd/reconstruction/` package owns method options, Bin2cell adaptation, geometry, named-table storage and reporting. Changes outside it connect method routes, preflight, parameters, analysis table selection, storage readback and UI controls. `vhd/core.py` retains its original scientific cache version; the release version and new adapter version are separate.

## Cleanup and privacy

User examples were replaced by one five-route generic catalog; old test-only tables were moved to `tests/fixtures/config/`. Personal configurations/examples are retained separately in a PRIVATE reference pack. Saved outputs, private ready-paste snippets, old installation payloads, checkpoints and caches are absent from this colleague-facing tree.

The source snapshot's `notebooks/test_correction.py` contained 23 tests of a project-specific one-off corrective script. That notebook/tool pair is not part of the reusable release/test count. It remains in the unmodified original input archive.

A structural/private-path scan passes on the release; it is not a complete secrets audit, redistribution authorization or biological-validation statement.

## Test fixture reconciliation

The input snapshot's local available suite initially produced 13 failures, 601 passes, 17 skips. Failures included two absent old example CSVs and fixtures/assertions predating `assemble_bins`, startup output changes and the bin-master prerequisite. Generic missing fixtures were supplied and storage-stubbed tests were updated to explicitly stub the new storage prerequisite. Production coordinate/approval/storage guards were not relaxed to satisfy them. Compare `validation/source_changes.json` and the retained tests rather than treating a final pass count as evidence that real stores were written.

No full-size tissue, native study image, institutional mount, GPU inference, Proseg execution, or real scientific storage roundtrip was executed in the build environment.
