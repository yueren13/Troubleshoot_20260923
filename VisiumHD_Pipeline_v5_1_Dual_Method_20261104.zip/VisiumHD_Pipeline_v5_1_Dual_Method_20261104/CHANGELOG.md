# 0.5.1rc1 — 2026-11-04

Baseline: uploaded `VisiumHD_Pipeline_v5_Project_Center_20261014.zip` (SHA-256 recorded in validation/source_archive.json).

- Consolidated reusable source, generic examples and tests; removed deployment-specific/user-output clutter from the shareable package.
- Added official Bin2cell expansion/aggregation over the shared reviewed prior, raw-count conservation checks, projected bin-union boundaries, exact assignment-based metadata transfer and method-specific QC.
- Added opt-in secondary density StarDist; disabled by default and experimental/unvalidated on GPU.
- Added explicit methods and analysis selection, editable primary thresholds and expansion distance in Project Center; retained legacy route when imported settings have no method selection.
- Added independent named SpatialData tables, ID/region relationships, selective append verification, and method-partitioned analysis/report outputs. Legacy cells remains untouched.
- Fixed Output-context callback error handling found in the uploaded setup/UI; no suppressed exception may fall through to an unassigned center. Added consent disable/validation logic in the consolidated UI.
- Retained legacy scientific cache version for unchanged upstream science; introduced separate new adapter signatures.
- Reconciled outdated test fixtures and missing generic test tables. These changes do not relax biological review/storage guards.

Read VALIDATION.md for exactly what ran. This is a target pilot candidate, not a production-validated whole-slide release.
