# 05 annotations and signal

These are invented paths and identifiers. Edit the input locations, then import the two sheets using `00_Project_Center.ipynb`. Output/work/scratch locations are chosen in the setup panel or an explicit advanced profile. Approval flags are not pre-set. Extra sample columns become metadata, with leading-zero identifiers preserved.

Annotation categories are discovered, not listed at setup. Overlap is allowed. Fourfold scale is illustrative, not a universal calibration. Review the actual dimension/registration proposal before accepting it.
