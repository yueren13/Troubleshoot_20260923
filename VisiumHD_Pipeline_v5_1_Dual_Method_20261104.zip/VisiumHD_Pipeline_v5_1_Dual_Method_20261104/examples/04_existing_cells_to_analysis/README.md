# 04 existing cells to analysis

These are invented paths and identifiers. Edit the input locations, then import the two sheets using `00_Project_Center.ipynb`. Output/work/scratch locations are chosen in the setup panel or an explicit advanced profile. Approval flags are not pre-set. Extra sample columns become metadata, with leading-zero identifiers preserved.

Existing cell inputs remain the legacy `cells` population and are not relabeled as Proseg/Bin2cell. Boundary IDs and raw-count declaration must be correct. Select the clustered endpoint after import.
