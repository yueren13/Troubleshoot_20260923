# Default new-project forms

This convenience copy uses the same generic raw-to-cells sample and asset schema as `../02_raw_to_cells/`, but selects **Proseg only** by default. The catalog example 02 selects both methods explicitly. Use one set, not both. Enter your own locations; identifiers and paths are invented. No biological review is pre-approved.
