# One example catalog

All paths/identifiers in these examples are invented. Start with one folder, edit the sample/asset locations, then use **Create a new project from sample and asset sheets** in `00_Project_Center.ipynb`. Supply its `profile.json` in the optional profile field. Do not import all examples together.

| Folder | Entry | Endpoint / feature |
|---|---|---|
| 01_raw_to_qc_bins | Space Ranger | QC bins without segmentation |
| 02_raw_to_cells | Space Ranger | Proseg and Bin2cell; analysis chooses Proseg |
| 03_existing_bins_to_cells | Existing QC bin SpatialData | Reuse bins; reconstruct cells |
| 04_existing_cells_to_analysis | Existing raw-count cells | Independent analysis, no resegmentation |
| 05_annotations_and_signal | Space Ranger plus assets | Overlapping categories and native continuous stain |

`new_project/` is the launcher's convenience copy of the raw-to-cells forms with Proseg-only defaults; it is not a sixth distinct workflow. `config/` contains header-only full engine templates and generic advanced settings, not a real active study.

Sample columns describe entry material, goal, paths and metadata. The asset table lists optional files and coordinate declarations; categories are discovered before you choose them. An optional collaborator metadata CSV can be joined by ID. Review flags are not pre-approved in new examples. Per-category usage belongs in the Project Center, not a manually maintained choices sheet.

When using the existing-bin or existing-cell examples, review raw-count provenance, coordinate frame, boundary availability and feature IDs. Placeholder values must not be accepted merely to let a test start.
