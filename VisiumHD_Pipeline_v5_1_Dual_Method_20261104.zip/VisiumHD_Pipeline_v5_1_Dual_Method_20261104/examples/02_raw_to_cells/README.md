# 02 raw to cells

These are invented paths and identifiers. Edit the input locations, then import the two sheets using `00_Project_Center.ipynb`. Output/work/scratch locations are chosen in the setup panel or an explicit advanced profile. Approval flags are not pre-set. Extra sample columns become metadata, with leading-zero identifiers preserved.

This example chooses both cell methods. Secondary density segmentation is off. The analysis table is Proseg; change it explicitly in Segmentation / Cells for Bin2cell analysis.
