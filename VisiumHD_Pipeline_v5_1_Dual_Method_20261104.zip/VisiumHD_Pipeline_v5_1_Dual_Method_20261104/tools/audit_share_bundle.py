"""Read-only release hygiene check. Not a credential-security certification."""
from __future__ import annotations
import ast,json,re
from pathlib import Path

PATTERNS=(r'/home/domino/[A-Za-z0-9_-]+/',r'/host_root/nethome/[A-Za-z0-9_-]+/',
          r'/stash/(?:data/nonclin|results/dev)/',r'https?://[^/\s]*\.rdcloud\.',
          r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
          r'\bAKIA[A-Z0-9]{16}\b')

def audit(root):
    root=Path(root).resolve();errors=[];counts={'python':0,'notebooks':0,'json':0,'csv':0}
    for p in root.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if any(c in ('__pycache__','.pytest_cache','.ipynb_checkpoints','.git') for c in rel.parts):continue
        if p.suffix not in ('.py','.ipynb','.json','.csv','.md','.html','.toml','.txt'):continue
        text=p.read_text(encoding='utf-8-sig')
        # This checker contains deliberate detection-pattern literals; don't flag its source.
        if p.name!='audit_share_bundle.py':
            for pattern in PATTERNS:
                if re.search(pattern,text):errors.append(f'{rel}: potential private deployment/credential pattern {pattern}')
        if p.suffix=='.py':ast.parse(text,filename=str(rel));counts['python']+=1
        elif p.suffix=='.ipynb':
            nb=json.loads(text);counts['notebooks']+=1
            if nb.get('metadata',{}).get('widgets'):errors.append(f'{rel}: saved widget state')
            for c in nb['cells']:
                if c['cell_type']=='code' and (c.get('outputs') or c.get('execution_count') is not None):errors.append(f'{rel}: executed output')
        elif p.suffix=='.json':json.loads(text);counts['json']+=1
        elif p.suffix=='.csv':
            import csv,io
            rows=list(csv.reader(io.StringIO(text)))
            if not rows or not rows[0] or len(set(rows[0]))!=len(rows[0]):errors.append(f'{rel}: invalid header')
            elif any(len(r)!=len(rows[0]) for r in rows[1:]):errors.append(f'{rel}: inconsistent CSV row width')
            counts['csv']+=1
    if errors:raise ValueError('\n'.join(errors))
    return {'status':'passed','counts':counts,'scope':'Known private path patterns, static syntax, CSV structure and unexecuted notebooks; not a complete secrets/license/biological audit.'}

if __name__=='__main__':print(json.dumps(audit(Path(__file__).resolve().parents[1]),indent=2))
