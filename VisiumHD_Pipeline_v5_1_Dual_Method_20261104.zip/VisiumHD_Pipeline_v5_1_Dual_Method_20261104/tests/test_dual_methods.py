"""New dependency-light numerical/routing checks. They do not execute GPU models."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json,os
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
from vhd.reconstruction.config import selected_methods,analysis_table,bin2cell_settings,apply_method_route,method_paths,effective_bin_column
from vhd.reconstruction.geometry import sample_prior,assignment_matrix,grid_layout,label_polygons
from vhd.reconstruction.bin2cell_adapter import expand_with_upstream,run_secondary,limited_affinity
from vhd.center.stages import route,output_paths


def cfg(methods=('proseg','bin2cell')):
    return {'cells':{'methods':list(methods),'analysis_method':methods[0]},'bin2cell':{}}


def test_default_secondary_off_and_parameters():
    c=bin2cell_settings({})
    assert c['max_bin_distance']==2 and c['secondary']['enabled'] is False
    assert c['secondary']['prob_thresh'] is None and c['secondary']['nms_thresh'] is None
    assert selected_methods({}) is None and analysis_table({})=='cells'


@pytest.mark.parametrize('methods',[[],['unknown'],['proseg','proseg'],'proseg'])
def test_method_list_invalid(methods):
    with pytest.raises(ValueError):selected_methods({'cells':{'methods':methods}})


@pytest.mark.parametrize('raw',[{'max_bin_distance':-1},{'max_bin_distance':1.5},{'k':1},{'secondary':{'enabled':'false'}},{'max_grid_pixels':0},{'extra':1}])
def test_invalid_b2c_parameters(raw):
    with pytest.raises(ValueError):bin2cell_settings({'bin2cell':raw})


def test_no_aliases_of_imported_cells():
    assert analysis_table(cfg(),{'_row':{'stage':'cell_segmented'}})=='cells'
    with pytest.raises(ValueError):analysis_table({'cells':{'methods':['proseg','bin2cell']}})


@pytest.mark.parametrize('methods,expected',[
 (['proseg'],['proseg','postprocess_cells']),(['bin2cell'],['bin2cell']),
 (['proseg','bin2cell'],['proseg','postprocess_cells','bin2cell'])])
def test_routes_use_selected_methods(methods,expected):
    r={'stage':'raw','goal':'cell_annotated','assets_manifest':'assets.csv'}
    steps=route(r,'cells',cfg(methods));i=steps.index('review_prior')+1;j=steps.index('assemble_methods')
    assert steps[i:j]==expected and 'refresh_method_annotations' in steps
    assert 'bin2cell_secondary' not in steps
    b=cfg(methods);b['bin2cell']['secondary']={'enabled':True}
    assert ('bin2cell_secondary' in route(r,'cells',b))==('bin2cell' in methods)
    assert 'bin2cell' not in route(r,'qc_bins',b)


def test_existing_cells_route_not_reconstructed():
    r={'stage':'cell_segmented','goal':'cell_annotated','bin_input':'','assets_manifest':''}
    assert route(r,'cells',cfg())==['import_cells','assemble','review_cells']


def test_method_paths_never_overlap_count_products(tmp_path):
    p={'work':tmp_path/'work','report':tmp_path/'reports'}
    a,b=method_paths(p,'proseg'),method_paths(p,'bin2cell')
    assert a['cells']!=b['cells'] and a['polygons']!=b['polygons']
    assert a['cells']==p['work']/'cells_qc.h5ad'
    assert b['cells']==p['work']/'bin2cell/cells_qc.h5ad'


def test_bin_domain_matches_current_proseg_policy():
    assert effective_bin_column({})=='qc_keep'
    assert effective_bin_column({'prior_filter':{'filter_proseg_bins':True}})=='segmentation_keep'
    assert effective_bin_column({'bin2cell':{'bin_scope':'segmentation_keep'}})=='segmentation_keep'


def test_raw_count_sum_and_unassigned_bins_are_exact():
    labels=np.array([11,0,3,11,3],np.int64)
    x=sparse.csr_matrix(np.array([[2,0,1],[90,80,70],[0,5,1],[4,2,0],[7,0,6]],np.int64))
    ids,a,m=assignment_matrix(labels);out=a@x
    np.testing.assert_array_equal(ids,[3,11]);np.testing.assert_array_equal(m,[1,-1,0,1,0])
    np.testing.assert_array_equal(out.toarray(),[[7,5,7],[6,2,1]])
    np.testing.assert_array_equal(out.sum(0),x[labels>0].sum(0))
    assert out.dtype==np.int64


@pytest.mark.parametrize('bad',[[1,-1],[1.5,0],[[1,2]]])
def test_bad_labels_refused(bad):
    with pytest.raises(ValueError):assignment_matrix(np.array(bad))


def test_prior_sampling_respects_original_affines_and_bounds():
    m=np.array([[4,0],[0,9]],np.uint32)
    xy=np.array([[100,50],[102,52],[98,50],[200,200]],float);old=xy.copy()
    labels=sample_prior(m,xy,{'tenx_to_image':np.eye(3)}, {'mask_index_to_image_px':[[2,0,100],[0,2,50],[0,0,1]]},chunk_size=1)
    np.testing.assert_array_equal(labels,[4,9,0,0]);np.testing.assert_array_equal(xy,old)


def test_polygon_holes_and_disconnected_parts_preserved():
    pytest.importorskip('rasterio');pytest.importorskip('geopandas')
    rr,cc=np.indices((5,5));lab=np.zeros((5,5),np.int64)
    lab[:3,:3]=1;lab[1,1]=0;lab[4,0]=2;lab[4,4]=2
    g=label_polygons(rr.ravel(),cc.ravel(),lab.ravel(),np.eye(3))
    assert g.loc['1','geometry'].area==8 and len(g.loc['1','geometry'].interiors)==1
    assert g.loc['2','geometry'].geom_type=='MultiPolygon' and len(g.loc['2','geometry'].geoms)==2
    assert g.loc['2','geometry'].area==2 and g.crs is None


def test_projective_boundary_matches_union_of_actual_bin_corners():
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    from vhd.projective_grid import project_xy
    h=np.array([[7,1,102],[.2,-8,1150],[.0001,.0002,1.]])
    rows=np.array([10,10,11,11]);cols=np.array([20,21,20,21]);labs=np.array([4,4,4,0])
    expected=unary_union([Polygon(project_xy(np.array([[c-.5,r-.5],[c+.5,r-.5],[c+.5,r+.5],[c-.5,r+.5]]),h)) for r,c,l in zip(rows,cols,labs) if l])
    g=label_polygons(rows,cols,labs,h)
    assert g.iloc[0].geometry.symmetric_difference(expected).area<1e-8


def test_grid_budget_duplicates_and_horizon():
    with pytest.raises(MemoryError):grid_layout([0,100000],[0,100000],10)
    with pytest.raises(ValueError,match='Duplicate'):grid_layout([0,0],[1,1],10)
    h=np.array([[1,0,0],[0,1,0],[1,0,.1]])
    with pytest.raises(ValueError,match='denominator'):label_polygons([0,0],[0,1],[1,1],h)


def test_secondary_disabled_before_tensorflow_import(monkeypatch):
    import builtins
    old=builtins.__import__
    def guard(name,*a,**kw):
        if name.startswith(('tensorflow','stardist')):raise AssertionError('Secondary import was attempted')
        return old(name,*a,**kw)
    monkeypatch.setattr(builtins,'__import__',guard)
    with pytest.raises(ValueError,match='disabled'):run_secondary({}, {})


def test_expansion_passes_knobs_caps_k_and_keeps_seeds():
    a=SimpleNamespace(obs=pd.DataFrame({'labels_he':[7,7,0,0]}));seen={}
    def upstream(obj,**kw):seen.update(kw);obj.obs['labels_he_expanded']=[7,7,7,0]
    result=expand_with_upstream(a,bin2cell_settings({'bin2cell':{'max_bin_distance':5}}),SimpleNamespace(expand_labels=upstream),threads=1)
    assert seen['max_bin_distance']==5 and seen['k']==2 and seen['algorithm']=='max_bin_distance'
    assert result['expansion_called']


def test_zero_distance_does_not_invoke_upstream():
    a=SimpleNamespace(obs=pd.DataFrame({'labels_he':[1,0]}))
    def forbidden(*a,**k):raise AssertionError('Expansion should be off')
    expand_with_upstream(a,bin2cell_settings({'bin2cell':{'max_bin_distance':0}}),SimpleNamespace(expand_labels=forbidden))
    assert a.obs.labels_he_expanded.tolist()==[1,0]


def test_upstream_corrupt_seed_is_rejected():
    a=SimpleNamespace(obs=pd.DataFrame({'labels_he':[1,1,0]}))
    def wrong(obj,**kw):obj.obs['labels_he_expanded']=[2,1,1]
    with pytest.raises(ValueError,match='seed label'):expand_with_upstream(a,bin2cell_settings({}),SimpleNamespace(expand_labels=wrong))


def test_affinity_restored_after_exception():
    if not hasattr(os,'sched_getaffinity'):pytest.skip('POSIX affinity unavailable')
    before=os.sched_getaffinity(0)
    with pytest.raises(RuntimeError):
        with limited_affinity(1):
            assert len(os.sched_getaffinity(0))==1;raise RuntimeError('test')
    assert os.sched_getaffinity(0)==before


def test_selected_only_analysis_table_and_separate_integration_folders(tmp_path):
    from vhd.control.runner import integration_config
    # Method resolution tested separately; no AnnData or expression here.
    assert analysis_table(cfg(['bin2cell']))=='bin2cell'
    assert analysis_table(cfg(['proseg']))=='proseg'


def test_all_curated_example_rows_parse(tmp_path):
    from vhd.center.importers import project_from_sheets
    root=Path(__file__).parents[1]
    for directory in sorted((root/'examples').glob('[0-9]*')):
        output=tmp_path/directory.name;output.mkdir()
        p=project_from_sheets(directory/'samples.csv',directory/'assets.csv',output,profile=directory/'profile.json')
        assert len(p['rows'])==1
        assert p['rows'][0]['_sample_metadata']['donor_id']=='001'
