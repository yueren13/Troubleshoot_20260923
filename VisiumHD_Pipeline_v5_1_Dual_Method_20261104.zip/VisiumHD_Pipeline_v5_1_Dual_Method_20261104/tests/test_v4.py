"""v4 targeted real numerical/file tests, with mocked I/O only where stated."""
import copy,csv,json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
from vhd.annotations.workflow import (COLUMNS,OPTIONAL_ASSET_COLUMNS,read_assets,active_assets,asset_specification,
    validate_prior_sources,signal_values,MeasurementRaster)
from vhd.annotations.geometry import read_imagescope_annotation_xml,classify_polygons
from vhd.annotations.raster import open_raster,validate_signal_encoding
from vhd.annotations.transfer import aggregate_annotations,segmentation_decisions
from vhd.he.fixed import sample_field
from vhd.analysis_qc import cell_metrics,profile
from vhd.count_display import transform,ticks
from vhd.compact_images import compact_sources,build_images


def asset(**kw):
    a={k:'' for k in COLUMNS+OPTIONAL_ASSET_COLUMNS}
    a.update(enabled='true',dataset_id='Study',sample_id='A',asset_id='test',kind='polygons',path='a.annotations',
        format='imagescope_xml',category_column='name',source_to_fullres='1;0;0;0;1;0',coverage_mode='exhaustive',
        bin_method='membership',role='analysis');a.update(kw);return a


def manifest(tmp,rows):
    p=tmp/'assets.csv'
    with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=COLUMNS+OPTIONAL_ASSET_COLUMNS);w.writeheader();w.writerows(rows)
    return p


@pytest.mark.parametrize('role',['analysis','segmentation_qc','both','reference_only'])
def test_roles_parse(tmp_path,role):
    a=read_assets(manifest(tmp_path,[asset(role=role)]),'Study','A')[0]
    assert a['role']==role
    assert len(active_assets([a]))==(0 if role=='reference_only' else 1)


@pytest.mark.parametrize('legacy,expected',[('exclusion','segmentation_qc'),('biological','analysis'),('signal','analysis')])
def test_legacy_role_aliases(tmp_path,legacy,expected):
    assert read_assets(manifest(tmp_path,[asset(role=legacy)]),'Study','A')[0]['role']==expected


def test_reference_cannot_request_cell_transfer(tmp_path):
    with pytest.raises(ValueError,match='reference_only'):
        read_assets(manifest(tmp_path,[asset(role='reference_only',cell_methods='fraction')]),'Study','A')


@pytest.mark.parametrize('role',['analysis','reference_only'])
def test_reference_or_analysis_cannot_filter_prior(role):
    with pytest.raises(ValueError,match='not owned'):
        validate_prior_sources([asset(asset_id='bad',role=role)],{'enabled':True,'exclude_columns':['bad__Necrosis']})


def test_reference_changes_do_not_affect_scientific_signature(tmp_path,monkeypatch):
    import vhd.annotations.workflow as w
    cfg={};spec={'dataset_id':'Study','sample_id':'A','_row':{}}
    p=manifest(tmp_path,[asset(role='reference_only')]);spec['_row']['assets_manifest']=str(p)
    geom=tmp_path/'geometry.json';geom.write_text('{}');obs=tmp_path/'base';obs.write_text('same')
    monkeypatch.setattr(w,'sample_paths',lambda *args:{'geometry':geom,'bin_obs':obs})
    first=asset_specification(cfg,spec)[1]
    manifest(tmp_path,[asset(role='reference_only',path='missing_other.annotations',notes='bad alignment')])
    assert first==asset_specification(cfg,spec)[1]


@pytest.mark.parametrize('positive',[1,255])
def test_real_tiff_scale9_and_aggregation(tmp_path,positive):
    import tifffile
    arr=np.array([[0,positive,0],[positive,0,positive],[0,0,positive]],np.uint8)
    f=tmp_path/'signal.tif';tifffile.imwrite(f,arr)
    a=asset(kind='signal',path=str(f),axes='yx',channel=None,signal_type='binary',positive_value=positive,negative_value=0,
            nodata_value='',bin_method='center_nearest')
    validate_signal_encoding(a)
    xy=np.array([[0,0],[9,0],[9,9],[18,18],[900,0]],float)
    with open_raster(f,'yx') as raster:
        val,inside,valid=sample_field(MeasurementRaster(raster,a),xy,source_to_fullres=np.diag([9.,9.,1.]),interpolation='nearest')
    np.testing.assert_allclose(val[:4],[0,1,0,1]);assert not inside[-1] and np.isnan(val[-1])
    out=aggregate_annotations(pd.DataFrame({'signal':val}),np.array([0,0,0,1,1]),2,{'continuous':{'signal':['mean','sum','median']}})
    assert out.loc[0,'geometric__signal__mean']==pytest.approx(1/3)
    assert out.loc[1,'geometric__signal__annotation_coverage']==.5
    assert out.loc[1,'geometric__signal__sum']==1


def test_binary_unknown_code_rejected():
    with pytest.raises(ValueError,match='undeclared'):signal_values([0,128,255],{'signal_type':'binary','positive_value':255,'negative_value':0})


def test_nodata_distinct_from_negative():
    a={'signal_type':'binary','positive_value':255,'negative_value':0,'nodata_value':128}
    np.testing.assert_equal(signal_values([0,255,128,np.nan],a),[0,1,np.nan,np.nan])


@pytest.mark.parametrize('method',['center_linear','membership'])
def test_binary_reject_interpolation(tmp_path,method):
    with pytest.raises(ValueError):read_assets(manifest(tmp_path,[asset(kind='signal',axes='yx',bin_method=method,signal_type='binary',positive_value='255',negative_value='0')]),'Study','A')


@pytest.mark.parametrize('tag',['V','Vertex'])
def test_annotations_namespace_and_holes(tmp_path,tag):
    def reg(points,neg):return '<Region NegativeROA="'+str(neg)+'"><Vertices>'+''.join(f'<{tag} X="{x}" Y="{y}"/>' for x,y in points)+'</Vertices></Region>'
    xml='<Annotations xmlns="urn:test"><Annotation Name="Tissue"><Regions>'+reg([(0,0),(10,0),(10,10),(0,10)],0)+reg([(4,4),(6,4),(6,6),(4,6)],1)+'</Regions></Annotation></Annotations>'
    p=tmp_path/'qc.annotations';p.write_text(xml);g=read_imagescope_annotation_xml(p)
    assert g.geometry.area.sum()==96
    assert not classify_polygons([[5,5]],g,exhaustive=True).Tissue.iloc[0]


def test_unsupported_annotations_fail(tmp_path):
    p=tmp_path/'q.annotations';p.write_text('<Other/>')
    with pytest.raises(ValueError,match='Unsupported'):read_imagescope_annotation_xml(p)


@pytest.mark.parametrize('species,threshold',[('human',20),('mouse',10)])
def test_mito_strict_boundary(species,threshold):
    x=sparse.csr_matrix([[threshold,100-threshold],[threshold-1,101-threshold],[0,3],[0,2],[0,0]])
    obs=pd.DataFrame({'qc_pass':True},index=list('abcde'));var=pd.DataFrame({'gene_symbol':['mt-A','Gene']},index=['g1','g2'])
    original=x.copy();r=profile({'analysis_qc':{'enabled':True,'species':species}},{});out,_=cell_metrics(x,obs,var,r)
    assert out.analysis_qc_pass.tolist()==[False,True,True,False,False]
    assert (x!=original).nnz==0


@pytest.mark.parametrize('min_counts',[3,16])
def test_min_counts_is_not_min_genes(min_counts):
    x=sparse.csr_matrix([[0,min_counts],[0,min_counts-1]])
    obs=pd.DataFrame({'qc_pass':[True,True]});var=pd.DataFrame({'gene_symbol':['MT-A','B']})
    out,_=cell_metrics(x,obs,var,{'max_pct_mt':10,'min_counts':min_counts})
    assert out.analysis_qc_pass.tolist()==[True,False]


def test_missing_mt_requires_explicit_policy():
    x=sparse.csr_matrix([[5,4]]);obs=pd.DataFrame({'qc_pass':[True]});var=pd.DataFrame(index=['ENSG1','ENSG2'])
    with pytest.raises(ValueError,match='No mitochondrial'):cell_metrics(x,obs,var,{'max_pct_mt':20})
    out,_=cell_metrics(x,obs,var,{'max_pct_mt':20,'missing_mt_policy':'skip_explicit'})
    assert out.analysis_pct_counts_mt.isna().all() and not out.analysis_mt_filter_applied.any()


def test_existing_qc_remains_excluded():
    out,_=cell_metrics(sparse.csr_matrix([[0,100]]),pd.DataFrame({'qc_pass':[False]}),pd.DataFrame({'gene_symbol':['MT-A','G']}),{'max_pct_mt':20})
    assert not out.analysis_qc_pass.iloc[0]


@pytest.mark.parametrize('base',[10,2,'e'])
def test_readable_ticks_and_no_mutation(base):
    x=np.array([0,10,100,1000,10000]);y=x.copy();loc,labels=ticks(10000,base)
    np.testing.assert_allclose(loc,transform(x,base));assert labels==['0','10','100','1,000','10,000'];np.testing.assert_equal(x,y)


def test_compact_sources_use_recorded_scales(tmp_path):
    f=tmp_path/'spatial';f.mkdir()
    for x in ('tissue_hires_image.png','tissue_lowres_image.png'):(f/x).write_bytes(b'path-only-fixture')
    (f/'scalefactors_json.json').write_text(json.dumps({'tissue_hires_scalef':.1,'tissue_lowres_scalef':.01}))
    r=compact_sources({'storage':{}},{'outs':str(tmp_path)})
    assert r[0]['index_to_fullres'][0][0]==10 and r[1]['index_to_fullres'][1][1]==100


def test_compact_missing_no_silent_original_fallback(tmp_path):
    with pytest.raises(FileNotFoundError):compact_sources({'storage':{}},{'outs':str(tmp_path)})


def test_unknown_profile_species():
    with pytest.raises(ValueError,match='species'):profile({'analysis_qc':{'enabled':True}}, {})


def test_reference_only_not_transferred_and_prior_unchanged(tmp_path,monkeypatch):
    # Explicit storage isolation: bin-master validation has separate tests.
    import vhd.bin_master as bm
    monkeypatch.setattr(bm,'ensure_bin_master',lambda *a,**k:None)
    """Actual transfer orchestration, with master/table I/O isolated by explicit stubs."""
    import vhd.annotations.workflow as w
    import vhd.io as io
    import vhd.persistence as persistence
    work=tmp_path/'work';report=tmp_path/'reports';work.mkdir();report.mkdir()
    base=pd.DataFrame({'pxl_col_in_fullres':[1.,5.],'pxl_row_in_fullres':[1.,5.],'qc_keep':[True,False]},index=['b1','b2'])
    # Parquet is replaced in this dependency-light test; this is not a SpatialData roundtrip.
    monkeypatch.setattr(pd,'read_parquet',lambda p:base.copy())
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,p:Path(p).write_text(self.to_json()))
    geom=work/'geometry.json';geom.write_text('{}');bo=work/'bins';bo.write_text('base')
    path=manifest(tmp_path,[asset(role='reference_only',path='unavailable.annotations')])
    spec={'sample_id':'A','dataset_id':'Study','_row':{'assets_manifest':str(path)}}
    monkeypatch.setattr(w,'sample_paths',lambda *args:{'work':work,'report':report,'geometry':geom,'bin_obs':bo,'store':tmp_path/'s.zarr'})
    monkeypatch.setattr(io,'table_metadata',lambda *args:(base.copy(),pd.DataFrame()))
    captured={}
    monkeypatch.setattr(persistence,'update_table_metadata',lambda *args,**kwargs:captured.update(kwargs))
    out=w.transfer_assets({'prior_filter':{'enabled':False},'storage_policy':{},'storage':{'single_writer_ack':True}},spec)
    assert not any(c.startswith('test__') for c in out['owned_columns'])
    assert out['transfer_spec']=={'categorical':{},'boolean':[],'continuous':{}}
    assert captured['obs']['segmentation_keep'].tolist()==[True,False]


@pytest.mark.parametrize('value',[0,-1,True,3.5,float('nan'),float('inf')])
def test_gene_minimum_is_a_positive_integer(value):
    from vhd.analysis_qc import gene_minimum
    with pytest.raises(ValueError):gene_minimum({'analysis_qc':{'min_cells_per_gene':value}})


def test_reference_persistence_error_not_hidden(tmp_path,monkeypatch):
    """Real orchestration with explicit scientific model/I/O stubs; no roundtrip claim."""
    import sys,types
    import vhd.annotations.workflow as w
    import vhd.master as master
    import vhd.persistence as persistence
    fake=types.ModuleType('spatialdata');models=types.ModuleType('spatialdata.models');transforms=types.ModuleType('spatialdata.transformations')
    fake.read_zarr=lambda *a,**kw:SimpleNamespace(shapes={},images={})
    models.ShapesModel=SimpleNamespace(parse=lambda *a,**kw:object())
    transforms.Affine=lambda *a,**kw:object()
    monkeypatch.setitem(sys.modules,'spatialdata',fake);monkeypatch.setitem(sys.modules,'spatialdata.models',models);monkeypatch.setitem(sys.modules,'spatialdata.transformations',transforms)
    work=tmp_path/'work';work.mkdir();report=tmp_path/'reports';report.mkdir()
    bins=work/'bins';bins.write_text('placeholder');geom=work/'geometry.json';geom.write_text('{}')
    row=asset(role='reference_only');path=manifest(tmp_path,[row])
    monkeypatch.setattr(w,'sample_paths',lambda *a:{'bins':bins,'geometry':geom,'work':work,'store':tmp_path/'master.zarr','report':report})
    monkeypatch.setattr(master,'assemble_master',lambda *a,**kw:None)
    monkeypatch.setattr(w,'alignment_signature',lambda *a:'synthetic-signature')
    monkeypatch.setattr(w,'polygons',lambda *a:SimpleNamespace(empty=False))
    def broken(*a,**kw):raise ValueError('Transaction validation failed; stop')
    monkeypatch.setattr(persistence,'persist_changes',broken)
    spec={'dataset_id':'Study','sample_id':'A','_row':{'assets_manifest':str(path)}}
    with pytest.raises(ValueError,match='Transaction validation'):
        w.import_assets({'storage_policy':{},'storage':{'single_writer_ack':True}},spec)
    assert not (report/'asset_test.json').exists()


def test_xml_with_no_annotations_is_rejected(tmp_path):
    p=tmp_path/'empty.annotations';p.write_text('<Annotations/>')
    with pytest.raises(ValueError,match='No ImageScope'):read_imagescope_annotation_xml(p)
