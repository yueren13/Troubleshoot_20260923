"""Real CSV/configuration and in-memory metadata tests; no scientific I/O mocked as real."""
import copy
import csv
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
from vhd.control.sample_metadata import (read_metadata_csv, resolve_project_metadata,
    metadata_for_row, metadata_preview, validate_values)
from vhd.control.manifest import COLUMNS, load_project, row_config, scientific_row
from vhd.sample_metadata import attach_sample_metadata, plan_sample_metadata, RECORD_KEY


def write_table(tmp, text):
    p=tmp/'metadata.csv';p.write_text(text, encoding='utf-8');return p


def row(sid='A', dataset='Project', **kw):
    return {'sample_id':sid,'dataset_id':dataset,'sample_key':f'{dataset}__{sid}',
            'metadata_json':'', **kw}


def spec(values, sid='A'):
    return {'sample':'Project__'+sid, 'sample_id':sid, 'dataset_id':'Project', 'metadata':values}


def fake_adata(n=3):
    # A lightweight object exercises the real obs/uns helper, NOT an AnnData serializer.
    return SimpleNamespace(obs=pd.DataFrame({'sample':['Project__A']*n, 'total_counts':[5]*n},
        index=[f'c{i}' for i in range(n)]),uns={},X=sparse.csr_matrix(np.ones((n,2),np.int32)),
        layers={'counts':sparse.csr_matrix(np.ones((n,2),np.int32))},
        obsm={'spatial':np.arange(n*2).reshape(n,2)})


def test_one_csv_72_samples_shuffled_no_json_created(tmp_path):
    ids=[f'Sample{i:03d}' for i in range(72)]
    p=write_table(tmp_path,'sample_id,species,condition\n'+''.join(
        f'{s},mouse,group{i%3}\n' for i,s in reversed(list(enumerate(ids)))))
    before={x.name for x in tmp_path.iterdir()}
    rows,report=resolve_project_metadata([row(s) for s in ids],{'path':p.name},tmp_path)
    assert [r['sample_id'] for r in rows]==ids
    assert report['n_matched_samples']==72 and report['unused_metadata_keys']==[]
    assert rows[0]['_sample_metadata']=={'species':'mouse','condition':'group0'}
    assert {x.name for x in tmp_path.iterdir()}==before


def test_original_headings_quoted_unicode_newline_and_leading_zero_ids(tmp_path):
    p=write_table(tmp_path,'\ufeffSample ID,Treatment,Tumor weight,Notes\n001,"A, B",01.20,"重复\nvalue"\n')
    values,_,report=read_metadata_csv(p,{'sample_id_column':'Sample ID'})
    assert values[('001',)]=={'Treatment':'A, B','Tumor weight':'01.20','Notes':'重复\nvalue'}
    assert report['types']['Tumor weight']=='string'


def test_typed_fields_are_configured_once_by_source_header(tmp_path):
    p=write_table(tmp_path,'Sample,Species,Age,Tumor weight,Responder\nA,mouse,12,3.5,yes\nB,mouse,,,,\n')
    # Invalid row length is rejected before any coercion.
    with pytest.raises(ValueError,match='fields'):read_metadata_csv(p,{'sample_id_column':'Sample'})
    p.write_text('Sample,Species,Age,Tumor weight,Responder\nA,mouse,12,3.5,yes\nB,mouse,,,\n')
    v,_,rec=read_metadata_csv(p,{'sample_id_column':'Sample','rename':{'Species':'species','Tumor weight':'tumor_weight'},
           'types':{'Age':'int','Tumor weight':'float','Responder':'bool'}})
    assert v[('A',)]=={'species':'mouse','Age':12,'tumor_weight':3.5,'Responder':True}
    assert v[('B',)]['Age'] is None and v[('B',)]['Responder'] is None


@pytest.mark.parametrize('text,match',[
 ('sample_id,thing,thing\nA,a,b\n','headers'),
 ('sample_id,\nA,a\n','headers'),
 ('sample_id,thing\nA,a\nA,a\n','Duplicate'),
 ('sample_id,thing\n,a\n','nonempty'),
 ('sample_id,thing\n A,a\n','whitespace'),
 ('sample_id,thing\nA,a,b\n','fields'),
 ('sample_id,thing\nA\n','fields'),
 ('sample_id,thing\n,,\n','fields'),
 ('Other,thing\nA,b\n','join columns'),
 ('','empty'),
 ('sample_id, thing\nA,a\n','headers'),
])
def test_invalid_csv(tmp_path,text,match):
    with pytest.raises(ValueError,match=match):read_metadata_csv(write_table(tmp_path,text))


@pytest.mark.parametrize('field',['region','qc_pass','sample','sample_id','total_counts','vhd_fake','analysis_qc_pass','x/y'])
def test_protected_output_fields(tmp_path,field):
    p=write_table(tmp_path,f'Sample,{field}\nA,abc\n')
    with pytest.raises(ValueError):read_metadata_csv(p,{'sample_id_column':'Sample'})


def test_rename_reserved_metadata_column(tmp_path):
    p=write_table(tmp_path,'Sample,region\nA,lung\n')
    values,_,_=read_metadata_csv(p,{'sample_id_column':'Sample','rename':{'region':'study_region'}})
    assert values[('A',)]=={'study_region':'lung'}


def test_literal_na_null_nan_retained_unless_declared(tmp_path):
    p=write_table(tmp_path,'sample_id,x,y,z,empty\nA,NA,null,NaN,\n')
    v,_,_=read_metadata_csv(p);assert v[('A',)]=={'x':'NA','y':'null','z':'NaN','empty':None}
    v,_,_=read_metadata_csv(p,{'missing_values':['','NA']});assert v[('A',)]['x'] is None


@pytest.mark.parametrize('dtype,value',[('int','3.5'),('float','NaN'),('float','inf'),('bool','maybe'),('int',str(2**80))])
def test_bad_explicit_types_fail(tmp_path,dtype,value):
    with pytest.raises(ValueError,match='cannot parse'):read_metadata_csv(
        write_table(tmp_path,f'sample_id,x\nA,{value}\n'),{'types':{'x':dtype}})


def test_opt_in_auto_preserves_codes_dates_and_nonfinite_text(tmp_path):
    p=write_table(tmp_path,'sample_id,code,date,count,weight,flag,text\n001,001,2026-09-30,4,2.5,true,NaN\n002,002,2026-10-01,5,3.5,false,NA\n')
    v,_,r=read_metadata_csv(p,{'default_type':'auto'})
    assert v[('001',)]=={'code':'001','date':'2026-09-30','count':4,'weight':2.5,'flag':True,'text':'NaN'}


def test_duplicate_sample_ids_require_namespace(tmp_path):
    p=write_table(tmp_path,'sample_id,x\nA,a\n')
    with pytest.raises(ValueError,match='across datasets'):
        resolve_project_metadata([row('A','One'),row('A','Two')],{'path':str(p)},tmp_path)


def test_composite_key_and_single_key_modes(tmp_path):
    p=write_table(tmp_path,'Study,Sample,x\nTwo,A,two\nOne,A,one\n')
    rows,_=resolve_project_metadata([row('A','One'),row('A','Two')],
          {'path':str(p),'dataset_id_column':'Study','sample_id_column':'Sample'},tmp_path)
    assert [r['_sample_metadata']['x'] for r in rows]==['one','two']
    p.write_text('Key,x\nTwo__A,two\nOne__A,one\n')
    rows,_=resolve_project_metadata([row('A','One'),row('A','Two')],{'path':str(p),'sample_key_column':'Key'},tmp_path)
    assert rows[1]['_sample_metadata']=={'x':'two'}


def test_missing_and_extra_rows_reported(tmp_path):
    p=write_table(tmp_path,'sample_id,x\nA,a\nC,c\n')
    with pytest.raises(ValueError,match='missing for enabled'):
        resolve_project_metadata([row('A'),row('B')],{'path':str(p)},tmp_path)
    rows,report=resolve_project_metadata([row('A'),row('B')],{'path':str(p),'require_all_samples':False},tmp_path)
    assert report['missing_samples']==['Project__B'] and report['unused_metadata_keys']==[['C']]
    assert rows[1]['_sample_metadata']=={}
    with pytest.raises(ValueError,match='unmatched'):
        resolve_project_metadata([row('A')],{'path':str(p),'allow_extra_samples':False},tmp_path)


def test_subset_not_selected_by_row_order_and_case_exact(tmp_path):
    p=write_table(tmp_path,'sample_id,x\nA,a\nB,b\n')
    rows,report=resolve_project_metadata([row('B')],{'path':str(p)},tmp_path)
    assert rows[0]['_sample_metadata']=={'x':'b'} and report['unused_metadata_keys']==[['A']]
    with pytest.raises(ValueError,match='missing'):
        resolve_project_metadata([row('a')],{'path':str(p)},tmp_path)


def test_existing_json_and_csv_without_generated_sidecars(tmp_path):
    j=tmp_path/'old.json';j.write_text('{"species":"mouse","donor":"001"}')
    p=write_table(tmp_path,'sample_id,species,condition\nA,mouse,test\n')
    r=row(metadata_json=str(j))
    resolved,_=resolve_project_metadata([r],{'path':str(p)},tmp_path)
    assert metadata_for_row(resolved[0])=={'species':'mouse','donor':'001','condition':'test'}
    j.write_text('{"species":"human"}')
    assert metadata_for_row(resolved[0])['species']=='mouse'  # stable worker snapshot
    with pytest.raises(ValueError,match='conflict'):
        resolve_project_metadata([r],{'path':str(p)},tmp_path)
    for policy,expected in [('csv_wins','mouse'),('json_wins','human')]:
        new,_=resolve_project_metadata([r],{'path':str(p),'json_conflicts':policy},tmp_path)
        assert new[0]['_sample_metadata']['species']==expected
        assert new[0]['_sample_metadata_provenance']['conflict_columns']==['species']


def test_old_json_only_still_supported(tmp_path):
    j=tmp_path/'old.json';j.write_text('{"species":"mouse"}')
    rows,report=resolve_project_metadata([row(metadata_json=str(j))],None,tmp_path)
    assert metadata_for_row(rows[0])=={'species':'mouse'} and not report['enabled']
    assert metadata_for_row(row(metadata_json=str(j)))=={'species':'mouse'}


def test_other_sample_edit_does_not_change_this_sample_scientific_payload(tmp_path):
    p=write_table(tmp_path,'sample_id,x\nA,a\nB,b\n')
    before,_=resolve_project_metadata([row('A')],{'path':str(p)},tmp_path)
    p.write_text('sample_id,x\nB,new\nA,a\n')
    after,_=resolve_project_metadata([row('A')],{'path':str(p)},tmp_path)
    assert scientific_row(before[0])==scientific_row(after[0])
    assert metadata_for_row(before[0])==metadata_for_row(after[0])
    assert before[0]['_sample_metadata_provenance']!=after[0]['_sample_metadata_provenance']


def test_strings_compact_numeric_null_and_count_coordinate_identity():
    a=fake_adata(10000);x=a.X;layers=a.layers['counts'];coords=a.obsm['spatial'];before=a.obs.copy()
    values={'species':'mouse','donor':'001','age':12,'weight':2.5,'flag':True,'missing':None}
    plan=attach_sample_metadata(a,spec(values))
    assert a.X is x and a.layers['counts'] is layers and a.obsm['spatial'] is coords
    pd.testing.assert_frame_equal(a.obs[before.columns],before)
    assert isinstance(a.obs['species'].dtype,pd.CategoricalDtype)
    assert a.obs['species'].memory_usage(index=False)<20000
    assert a.obs.age.dtype==np.int64 and a.obs.flag.dtype==bool
    assert a.obs['missing'].isna().all() and len(plan['add_or_replace'])==6
    assert json.loads(a.uns[RECORD_KEY])['values']==values
    again=attach_sample_metadata(a,spec(values));assert again['add_or_replace']==[] and not again['record_changed']


def test_collision_failure_does_not_partially_modify():
    a=fake_adata();a.obs['condition']='existing';before=a.obs.copy()
    with pytest.raises(ValueError,match='conflicts'):
        attach_sample_metadata(a,spec({'new':'value','condition':'different'}))
    pd.testing.assert_frame_equal(a.obs,before);assert a.uns=={}


def test_identical_unowned_metadata_is_not_claimed_and_cannot_be_replaced():
    a=fake_adata();a.obs['condition']='existing'
    attach_sample_metadata(a,spec({'condition':'existing'}))
    assert json.loads(a.uns[RECORD_KEY])['owned_columns']==[]
    with pytest.raises(ValueError,match='conflicts'):
        plan_sample_metadata(a.obs,a.uns,spec({'condition':'different'}),replace_owned=True)


def test_only_owned_metadata_can_be_updated_or_pruned_explicitly():
    a=fake_adata();attach_sample_metadata(a,spec({'condition':'one','unused':'old'}))
    with pytest.raises(ValueError,match='no longer supplies'):
        plan_sample_metadata(a.obs,a.uns,spec({'condition':'two'}))
    with pytest.raises(ValueError,match='conflicts'):
        plan_sample_metadata(a.obs,a.uns,spec({'condition':'two'}),prune_owned=True)
    cols,drop,_,_=plan_sample_metadata(a.obs,a.uns,spec({'condition':'two'}),replace_owned=True,prune_owned=True)
    assert drop==['unused'] and cols.condition.astype(str).eq('two').all()


def test_no_cross_sample_attachment():
    a=fake_adata()
    with pytest.raises(ValueError,match='cross-sample'):
        attach_sample_metadata(a,spec({'condition':'test'},sid='B'))


def test_empty_metadata_noop():
    a=fake_adata();attach_sample_metadata(a,spec({}));assert a.uns=={} and list(a.obs)==['sample','total_counts']


@pytest.mark.parametrize('bad',[{'k':[1]}, {'k':{'a':1}}, {'k':float('nan')}, {'k':float('inf')}, {'k':2**80}])
def test_bad_json_metadata_rejected(bad):
    with pytest.raises(ValueError):validate_values(bad)


def test_unknown_settings_rejected(tmp_path):
    p=write_table(tmp_path,'sample_id,x\nA,a\n')
    with pytest.raises(ValueError,match='Unknown'):
        read_metadata_csv(p,{'colums':['x']})


def test_no_metadata_json_column_required_in_sample_csv(tmp_path):
    root=Path(__file__).parents[1]
    cfg=json.loads((root/'tests/fixtures/config/settings.g5_24xlarge.example.json').read_text())
    cfg['sample_metadata']={'path':'metadata.csv','sample_id_column':'Sample'}
    cfg['project_namespace']='MyProject'
    cfg['integration'].update({k:str(tmp_path/k) for k in ('control_dir','tmp_dir','output_object_dir','output_plot_dir','output_data_dir')})
    for name in ('python_spatial','python_stardist','python_scvi','python_rapids'):cfg['execution'][name]='current'
    settings=tmp_path/'settings.json';settings.write_text(json.dumps(cfg))
    write_table(tmp_path,'Sample,species,condition\n001,mouse,test\n')
    fields=[k for k in COLUMNS if k not in ('dataset_id','metadata_json')]
    r=dict.fromkeys(fields,'');r.update(enabled='true',sample_id='001',stage='cell_segmented',goal='cell_annotated',
        cell_input=str(tmp_path/'source.h5ad'),counts_source='X',cell_coordinate_mode='unregistered',
        **{k:str(tmp_path/k) for k in ('output_object_dir','output_plot_dir','output_data_dir','tmp_dir')})
    path=tmp_path/'samples.csv'
    with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerow(r)
    project=load_project(path,settings)
    assert project['metadata_report']['n_matched_samples']==1
    _,s=row_config(project,project['rows'][0]);assert s['metadata']=={'species':'mouse','condition':'test'}
    assert s['sample']=='MyProject__001' and metadata_preview(project).iloc[0]['sample_id']=='001'
    # Worker context is an in-memory JSON snapshot; CSV editing does not mix old/new rows.
    frozen=json.loads(json.dumps(project));write_table(tmp_path,'Sample,species,condition\n001,human,changed\n')
    _,s=row_config(frozen,frozen['rows'][0]);assert s['metadata']['species']=='mouse'
    fresh=load_project(path,settings);assert fresh['rows'][0]['_sample_metadata']['species']=='human'
