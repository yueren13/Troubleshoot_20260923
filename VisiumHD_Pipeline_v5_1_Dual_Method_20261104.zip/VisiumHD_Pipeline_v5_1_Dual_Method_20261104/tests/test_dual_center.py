"""Real configuration/state/UI contracts. No scientific job execution here."""
from pathlib import Path
from copy import deepcopy
import json
import pytest
from vhd.center import ProjectCenter
from vhd.control.manifest import row_config,sample_layout
from vhd.center.stages import route,output_paths

@pytest.fixture
def source(tmp_path):
    from test_visual_approval_bridge import setup
    return setup.__wrapped__(tmp_path)

@pytest.fixture
def center(source):
    return ProjectCenter.import_config(source['manifest'],source['settings'],source['root']/'center')


def save(center,**kw):
    args=dict(methods=['proseg','bin2cell'],analysis_method='proseg',prob_thresh=.02,nms_thresh=.30,max_bin_distance=2,secondary=False,confirmed=True)
    args.update(kw);return center.save_reconstruction('A',**args)


def test_save_reopen_keeps_methods_and_original_files(center,source):
    before={p:p.read_bytes() for p in (source['manifest'],source['settings'],source['assets'],source['choices'])}
    save(center);c=ProjectCenter.open(center.workspace);cfg,spec=row_config(c.project,c.project['rows'][0])
    assert cfg['cells']['methods']==['proseg','bin2cell'] and spec['_cell_table']=='proseg'
    assert cfg['bin2cell']['secondary']['enabled'] is False
    assert cfg['stardist']['prob_thresh']==.02 and cfg['stardist']['nms_thresh']==.30
    assert all(p.read_bytes()==b for p,b in before.items())
    steps=c._route(c.snapshot(),c.project['rows'][0],'cells')
    assert 'bin2cell' in steps and 'assemble_methods' in steps and 'bin2cell_secondary' not in steps
    assert not source['paths']['store'].exists()


def test_noop_save_does_not_clear_reviews_or_increment_revision(center):
    save(center);rev=center.snapshot()['revision'];out=save(center)
    assert out['status']=='unchanged' and center.snapshot()['revision']==rev


def test_no_consent_no_changes(center):
    before=center.snapshot()['revision']
    with pytest.raises(PermissionError):save(center,confirmed=False)
    assert center.snapshot()['revision']==before


def test_stale_revision_rejected(center):
    rev=center.snapshot()['revision'];center.refresh()
    with pytest.raises(RuntimeError,match='stale'):save(center,expected_revision=rev)


def test_completed_shared_prior_threshold_change_blocked(center):
    p=sample_layout(center.project,center.project['rows'][0]);p['work'].mkdir(parents=True,exist_ok=True)
    (p['work']/'03_prior_complete.json').write_text('{}')
    before=center.snapshot()['revision']
    with pytest.raises(RuntimeError,match='completed shared prior'):save(center,prob_thresh=.5)
    assert center.snapshot()['revision']==before


def test_completed_bin2cell_settings_change_blocked(center):
    save(center);p=sample_layout(center.project,center.project['rows'][0]);d=p['work']/'bin2cell';d.mkdir(parents=True,exist_ok=True);(d/'complete.json').write_text('{}')
    with pytest.raises(RuntimeError,match='completed Bin2cell'):save(center,max_bin_distance=3)


def test_analysis_switch_selects_independent_current_marker(center):
    save(center,analysis_method='bin2cell');p=center.project;row=p['rows'][0]
    assert row_config(p,row)[1]['_cell_table']=='bin2cell'
    assert output_paths(p,row,'cluster_individual')[0]==sample_layout(p,row)['report']/'individual_analysis/bin2cell/current.json'
    from vhd.center.single_sample import launch_individual
    assert launch_individual(p,row['sample_key'],{},execute=False)['source_table']=='bin2cell'


def test_scvi_cannot_mix_methods(center):
    from vhd.control.runner import integration_config
    save(center);p=center.project;r=p['rows'][0];r['integration_group']='G'
    second=deepcopy(r);second['sample_id']='B';second['sample_key']='Project__B'
    f=center.workspace/'engine/overrides/B.json';f.write_text(json.dumps({'cells':{'methods':['bin2cell'],'analysis_method':'bin2cell'}}));second['overrides_json']=str(f)
    p['rows'].append(second)
    with pytest.raises(ValueError,match='mix'):integration_config(p,'G')


def test_runtime_import_requirements_are_method_specific():
    from vhd.compute.runtime_checks import action_imports
    assert 'bin2cell' in action_imports('bin2cell')
    assert 'tensorflow' not in action_imports('bin2cell')
    assert 'tensorflow' in action_imports('bin2cell_secondary')
    assert 'bin2cell' not in action_imports('postprocess_cells')


def test_report_registry_collects_bin2cell_and_method_analysis(center):
    from vhd.center.reports import list_reports
    p=center.project;r=p['rows'][0];rep=sample_layout(p,r)['report'];(rep/'bin2cell').mkdir(parents=True,exist_ok=True)
    (rep/'bin2cell/run_summary.json').write_text('{}')
    (rep/'bin2cell/cell_qc_summary.csv').write_text('n_cells\n2\n')
    d=rep/'individual_analysis/bin2cell/a01';d.mkdir(parents=True);(d/'summary.json').write_text('{}')
    items=list_reports(p,r);names={Path(a['path']).relative_to(rep).as_posix() for a in items if Path(a['path']).is_relative_to(rep)}
    assert 'bin2cell/run_summary.json' in names and 'individual_analysis/bin2cell/a01/summary.json' in names


def test_matching_scvi_tables_partition_work_and_scratch(center):
    from vhd.control.runner import integration_config
    save(center,analysis_method='bin2cell');p=center.project;r=p['rows'][0];r['integration_group']='G'
    second=deepcopy(r);second['sample_id']='B';second['sample_key']='Project__B';p['rows'].append(second)
    effective=integration_config(p,'G')
    assert Path(effective['_integration_work']).name=='bin2cell'
    assert Path(effective['_integration_scratch']).name=='bin2cell'
    assert effective['scvi']['run_name'].endswith('__bin2cell')


def test_comparison_report_is_method_separated_and_descriptive(center):
    import pandas as pd
    from PIL import Image
    from vhd.reconstruction.reports import comparison_report
    save(center);row=center.project['rows'][0];cfg,spec=row_config(center.project,row)
    p=sample_layout(center.project,row)
    for method,report in [('proseg',p['report']),('bin2cell',p['report']/'bin2cell')]:
        report.mkdir(parents=True,exist_ok=True)
        pd.DataFrame([{'sample':'Fixture','n_cells':2,'n_qc_pass':2,'median_umis':10}]).to_csv(report/'cell_qc_summary.csv',index=False)
        Image.new('RGB',(20,20)).save(report/'cells_qc_pass_on_HE.png')
    result=comparison_report(cfg,spec)
    assert [r['method'] for r in result]==['proseg','bin2cell']
    record=json.loads((p['report']/'reconstruction_comparison.json').read_text())
    assert record['ground_truth_accuracy'] is False
    text=(p['report']/'reconstruction_comparison.html').read_text()
    assert text.count('data:image/jpeg;base64,')==2
    assert 'Do not concatenate' in text
