"""New importer / annotation branches, with only declared I/O stubs.

No result here is a real AnnData/SpatialData roundtrip.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import shapely
from vhd import io
from vhd.projective_grid import project_xy,grid_corners
from vhd.grid_geometry import GridGeometryError

H=np.array([[7.9,.1,300],[.2,7.8,500],[5e-4,-2.5e-4,1.]])


def _fixture(tmp,monkeypatch):
    from test_grid_hotfix_ingest import fixture
    cfg,spec,calls,written,pos=fixture(tmp,monkeypatch)
    xy=project_xy(pos[['array_col','array_row']].to_numpy(),H)
    pos['pxl_col_in_fullres']=xy[:,0];pos['pxl_row_in_fullres']=xy[:,1]
    return cfg,spec,calls,written,pos


def test_projective_import_preserves_every_center_and_count(tmp_path,monkeypatch):
    cfg,spec,calls,written,pos=_fixture(tmp_path,monkeypatch)
    g=io.ingest(cfg,spec)
    assert g['grid_fit']['acceptance']=='validated_projective_polygons'
    assert g['grid_geometry_model']=='projective' and g['bin_representation']=='projective_quadrilaterals'
    np.testing.assert_array_equal(written[0]['xy'],pos[['pxl_col_in_fullres','pxl_row_in_fullres']])
    np.testing.assert_array_equal(written[0]['X'].toarray(),np.tile([1,2,3],(len(pos),1)))
    again=io.ingest(cfg,spec);assert g==again and len(calls)==1


def test_nonprojective_warp_blocks_before_counts(tmp_path,monkeypatch):
    cfg,spec,calls,written,pos=_fixture(tmp_path,monkeypatch)
    pos.loc[0,'pxl_col_in_fullres']+=5
    with pytest.raises(GridGeometryError):io.ingest(cfg,spec)
    assert not calls and not written


def test_explicit_policy_change_does_not_reuse_prepared_geometry(tmp_path,monkeypatch):
    cfg,spec,calls,written,pos=_fixture(tmp_path,monkeypatch)
    io.ingest(cfg,spec);cfg['coordinates']['grid_geometry_policy']='affine_only'
    with pytest.raises(RuntimeError,match='Stale/incomplete'):io.ingest(cfg,spec)


def test_signal_transfer_uses_projective_bin_corners(tmp_path,monkeypatch):
    # Explicit storage isolation: bin-master validation has separate tests.
    import vhd.bin_master as bm
    monkeypatch.setattr(bm,'ensure_bin_master',lambda *a,**k:None)
    from test_v41 import source,prepare_choices,select
    from vhd.annotations.workflow import alignment_signature
    from vhd.annotations.projective_sampling import summarize_projective_bins
    import vhd.annotations.workflow as workflow
    import vhd.persistence as persistence
    import tifffile
    from vhd.projective_grid import geometry_contract
    h=np.array([[2,.2,1.5],[.1,2,1.5],[.007,-.005,1.]])
    field=np.arange(25*25,dtype=np.float32).reshape(25,25)
    f=tmp_path/'signal.tif';tifffile.imwrite(f,field)
    a=source(tmp_path,'signal',path=str(f));g={'grid_index_to_fullres':h.tolist(),**geometry_contract(h)}
    prepare_choices(a,g)
    select(a,g,{'__signal__':{'include_in_obs':'true','signal_methods':'mean;median;sum;min;max','obs_name':'stain'}})
    work=tmp_path/'work';rep=tmp_path/'rep';work.mkdir();rep.mkdir()
    geom=work/'geometry.json';geom.write_text(json.dumps(g));bo=work/'bins';bo.write_bytes(b'unchanged counts sentinel')
    p={'work':work,'report':rep,'geometry':geom,'bin_obs':bo,'store':tmp_path/'s.zarr'}
    (rep/'asset_signal.json').write_text(json.dumps({'alignment_signature':alignment_signature(a,g)}))
    r=np.array([0,3,6]);c=np.array([0,3,7]);xy=project_xy(np.c_[c,r],h)
    base=pd.DataFrame({'array_row':r,'array_col':c,'pxl_col_in_fullres':xy[:,0],
        'pxl_row_in_fullres':xy[:,1],'qc_keep':True},index=['a','b','c'])
    monkeypatch.setattr(workflow,'sample_paths',lambda *args:p)
    monkeypatch.setattr(pd,'read_parquet',lambda *args,**kwargs:base.copy())
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,path:Path(path).write_text(self.to_json()))
    monkeypatch.setattr(io,'table_metadata',lambda *args:(base.copy(),pd.DataFrame()))
    captured={};monkeypatch.setattr(persistence,'update_table_metadata',lambda *a,**k:captured.update(k))
    cfg={'prior_filter':{'mode':'from_review'},'annotations':{},'storage_policy':{},'storage':{'single_writer_ack':True}}
    spec={'dataset_id':'Project','sample_id':'A','_row':{'assets_manifest':str(tmp_path/'assets.csv')}}
    workflow.transfer_assets(cfg,spec)
    expected=summarize_projective_bins(field,r,c,grid_index_to_fullres=h,source_to_fullres=np.eye(3),methods=['mean','median','sum','min','max'])
    for k in ['mean','median','sum','min','max']:np.testing.assert_allclose(captured['obs']['stain__'+k],expected[k],rtol=0,atol=1e-9)
    assert 'X' not in captured and bo.read_bytes()==b'unchanged counts sentinel'
