"""Target-environment smoke: actual Bin2cell API and actual H5AD/GeoParquet outputs.

No GPU/StarDist/Proseg inference: the prior is explicitly synthetic and secondary is off.
This module MUST pass (not skip) before attempting a full biological Bin2cell run.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
ad=pytest.importorskip('anndata')
b2c=pytest.importorskip('bin2cell')
pytest.importorskip('pyarrow');pytest.importorskip('rasterio');pytest.importorskip('openslide')
import geopandas as gpd
import tifffile
from vhd.core import sample_paths,write_h5ad,completed,file_stamp
from vhd.segmentation import prior_signature
from vhd.reconstruction.bin2cell_adapter import run_bin2cell
from vhd.reconstruction.config import method_paths


def test_actual_bin2cell_raw_counts_and_outputs(tmp_path):
    cfg=json.loads((Path(__file__).parents[1]/'vhd/center/data/backend_defaults.json').read_text())
    cfg.update(work_root=str(tmp_path/'work'),output_root=str(tmp_path/'out'))
    cfg['cells'].update(methods=['bin2cell'],analysis_method='bin2cell')
    cfg['metadata_transfer']['enabled']=False;cfg['cell_cycle']['enabled']=False
    cfg['plots'].update(dpi=50,thumbnail_max_side=100,max_spatial_points=1000,roi_size_px=64)
    cfg['bin2cell']['max_bin_distance']=2;cfg['prior_filter'].update(enabled=False,mode='explicit')
    cfg['execution']['host_ram_budget_gib']=8
    spec={'sample':'Synthetic','sample_id':'Synthetic','dataset_id':'Fixture','coordinates_reviewed':True,
          'fresh_qc_reviewed':True,'metadata':{},'_row':{'stage':'raw'}}
    p=sample_paths(cfg,spec);r,c=np.mgrid[:12,:16];r=r.ravel();c=c.ravel();xy=np.c_[c*4+4,r*4+4].astype(float)
    x=sparse.csr_matrix(np.random.default_rng(3).poisson(2,(len(r),12)).astype(np.int64))
    obs=pd.DataFrame({'array_row':r,'array_col':c,'pxl_col_in_fullres':xy[:,0],'pxl_row_in_fullres':xy[:,1],
                     'qc_keep':True,'total_counts':np.asarray(x.sum(axis=1)).ravel()},index=[f'b{i}' for i in range(len(r))])
    var=pd.DataFrame({'gene_symbol':['MT-test',*[f'G{i}' for i in range(11)]]},index=[f'id{i}' for i in range(12)])
    a=ad.AnnData(X=x,obs=obs.copy(),var=var);a.obsm['spatial']=xy.copy();write_h5ad(a,p['bins']);obs.to_parquet(p['bin_obs'])
    image=tmp_path/'synthetic_HE.tif';tifffile.imwrite(image,np.full((64,80,3),230,np.uint8),photometric='rgb')
    h=np.array([[4,0,4],[0,4,4],[0,0,1.]])
    geom={'source_mpp':.5,'image_mpp':[.5,.5],'grid_index_to_fullres':h.tolist(),'tenx_to_image':np.eye(3).tolist(),
          'image':{'path':str(image),'backend':'tifffile','width':80,'height':64,'mpp':[.5,.5]}}
    p['geometry'].write_text(json.dumps(geom));(p['work']/'he_normalization.json').write_text('{}')
    mask=np.zeros((64,80),np.uint32)
    mask[11:21,11:21]=1;mask[31:41,35:45]=2
    np.save(p['prior'],mask);np.save(p['raw_prior'],mask);np.save(p['crop'],np.full((64,80,3),230,np.uint8))
    p['prior_meta'].write_text(json.dumps({'mask_index_to_image_px':np.eye(3).tolist()}))
    completed(p['work']/'03_prior_complete.json',prior_signature(cfg,spec),[p['prior'],p['raw_prior'],p['prior_meta'],p['crop']])
    stamps={f:file_stamp(f,True) for f in (p['bins'],p['bin_obs'],p['prior'])}
    result=run_bin2cell(cfg,spec);mp=method_paths(p,'bin2cell')
    b=ad.read_h5ad(mp['cells']);assign=pd.read_parquet(mp['assignments']);shapes=gpd.read_parquet(mp['polygons'])
    assert result['secondary_enabled'] is False and result['raw_count_conservation_passed']
    assert not (mp['work']/'secondary_complete.json').exists()
    assert b.obs.segmentation_method.eq('bin2cell').all() and b.obs.seed_source.eq('primary_he').all()
    for i,local in enumerate(b.obs.local_cell_id.astype(int)):
        selected=assign.cell_label.to_numpy()==local
        np.testing.assert_array_equal(np.asarray(b.X[i].toarray()).ravel(),np.asarray(x[selected].sum(0)).ravel())
        np.testing.assert_allclose(b.obsm['spatial'][i],xy[selected].mean(0),rtol=0,atol=1e-10)
    assert b.obs_names.equals(shapes.index) and b.var_names.equals(a.var_names)
    assert all(file_stamp(f,True)==stamp for f,stamp in stamps.items())
    before=file_stamp(mp['cells'],True);again=run_bin2cell(cfg,spec)
    assert before==file_stamp(mp['cells'],True) and again==result
