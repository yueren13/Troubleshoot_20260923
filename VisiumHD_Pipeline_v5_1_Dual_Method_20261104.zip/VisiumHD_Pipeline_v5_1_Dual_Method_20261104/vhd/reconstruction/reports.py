"""Method-separated summaries; not ground-truth segmentation accuracy scores."""
from pathlib import Path
import base64,html,io,json
import pandas as pd
from .config import selected_methods,method_paths
from ..core import sample_paths,dump_json


def comparison_report(cfg,spec):
    from ..center.reports import document
    from PIL import Image
    p=sample_paths(cfg,spec);rows=[];body=['<p>Alternative reconstructions of the same tissue. Differences are not ground-truth accuracy. Do not concatenate these cells as independent observations.</p>']
    for method in selected_methods(cfg) or ():
        mp=method_paths(p,method);f=mp['report']/'cell_qc_summary.csv'
        if not f.is_file():raise FileNotFoundError(f)
        record=pd.read_csv(f).iloc[0].to_dict();record['method']=method;rows.append(record)
        body.append('<h2>'+html.escape(method)+'</h2>')
        for name in ('cells_histograms.png','cells_total_counts_hist.png','cells_n_genes_by_counts_hist.png','cells_qc_pass_on_HE.png','cells_boundaries_ROI_center.png'):
            image=mp['report']/name
            if image.is_file() and image.stat().st_size<80*1024**2:
                with Image.open(image) as im:
                    im.thumbnail((1600,1600));buf=io.BytesIO();im.convert('RGB').save(buf,format='JPEG',quality=85)
                body.append('<figure><img style="max-width:100%" src="data:image/jpeg;base64,'+base64.b64encode(buf.getvalue()).decode()+'"><figcaption>'+html.escape(method+' / '+name)+'</figcaption></figure>')
    df=pd.DataFrame(rows);df.to_csv(p['report']/'reconstruction_comparison.csv',index=False)
    body.insert(1,df.to_html(index=False,escape=True))
    (p['report']/'reconstruction_comparison.html').write_text(document(spec['sample']+' | Reconstruction comparison',''.join(body)),encoding='utf-8')
    dump_json({'methods':list(selected_methods(cfg) or ()),'rows':rows,'ground_truth_accuracy':False},p['report']/'reconstruction_comparison.json')
    return rows
