"""Bin-assignment geometry without constructing millions of individual polygons.

Trace the integer array grid (4-connected), preserve all polygon pieces/holes,
then transform the boundary vertices by the validated homography. No hull,
smoothing, snapping, artificial radius, or geographic CRS is introduced.
"""
from __future__ import annotations
import numpy as np
from scipy import sparse


def sample_prior(mask, fullres_xy, geometry, prior_metadata, chunk_size=250000):
    from ..core import transform_xy
    if mask.ndim != 2 or not np.issubdtype(mask.dtype,np.integer):
        raise ValueError('The shared QC prior must be a 2D integer mask.')
    xy=np.asarray(fullres_xy,float)
    if xy.ndim!=2 or xy.shape[1]!=2 or not np.isfinite(xy).all():raise ValueError('Invalid original bin centers.')
    matrix=np.linalg.inv(np.asarray(prior_metadata['mask_index_to_image_px'],float)) @ np.asarray(geometry['tenx_to_image'],float)
    labels=np.zeros(len(xy),np.int64)
    for start in range(0,len(xy),chunk_size):
        q=transform_xy(xy[start:start+chunk_size],matrix)
        rc=np.rint(q[:,::-1]).astype(np.int64)
        valid=(rc[:,0]>=0)&(rc[:,0]<mask.shape[0])&(rc[:,1]>=0)&(rc[:,1]<mask.shape[1])
        idx=np.flatnonzero(valid)+start
        labels[idx]=mask[rc[valid,0],rc[valid,1]]
    return labels


def assignment_matrix(labels):
    """Return sorted positive labels, cell-by-bin int64 matrix, and bin row mapping."""
    labels=np.asarray(labels)
    if labels.ndim!=1 or not np.issubdtype(labels.dtype,np.integer) or np.any(labels<0):
        raise ValueError('Labels must be nonnegative integers; zero means unassigned.')
    values=np.unique(labels[labels>0]);mapping=np.full(len(labels),-1,np.int64)
    good=labels>0;mapping[good]=np.searchsorted(values,labels[good])
    m=sparse.csr_matrix((np.ones(good.sum(),np.int64),(mapping[good],np.flatnonzero(good))),shape=(len(values),len(labels)))
    return values,m,mapping


def grid_layout(rows, cols, max_pixels):
    r=np.asarray(rows);c=np.asarray(cols)
    if r.ndim!=1 or r.shape!=c.shape or not len(r) or not np.isfinite(r).all() or not np.isfinite(c).all():
        raise ValueError('Paired nonempty finite array row/column indices required.')
    if (r<0).any() or (c<0).any() or not np.equal(r,np.rint(r)).all() or not np.equal(c,np.rint(c)).all():
        raise ValueError('Array coordinates must be nonnegative integers.')
    r=r.astype(np.int64);c=c.astype(np.int64);origin=(int(r.min()),int(c.min()))
    shape=(int(r.max())-origin[0]+1,int(c.max())-origin[1]+1)
    if shape[0]*shape[1]>max_pixels:raise MemoryError(f'Array raster {shape} exceeds max_grid_pixels={max_pixels}.')
    rr=r-origin[0];cc=c-origin[1];flat=rr*shape[1]+cc
    if len(np.unique(flat))!=len(flat):raise ValueError('Duplicate array bin coordinates.')
    return rr,cc,shape,origin


def label_polygons(rows,cols,labels,matrix,max_pixels=50_000_000):
    import geopandas as gpd
    from rasterio.features import shapes
    from affine import Affine
    from shapely.geometry import shape as geometry_shape
    from shapely.ops import unary_union,transform
    from ..projective_grid import project_xy, homography
    labels=np.asarray(labels)
    values,_,_=assignment_matrix(labels)
    if not len(values):raise ValueError('No assigned bins; cannot build cells.')
    if labels.max()>np.iinfo(np.int32).max:raise ValueError('Label IDs exceed int32 raster limit.')
    rr,cc,size,origin=grid_layout(rows,cols,max_pixels)
    if labels.shape!=rr.shape:raise ValueError('Label/bin count mismatch.')
    raster=np.zeros(size,np.int32);raster[rr,cc]=labels.astype(np.int32)
    parts={int(v):[] for v in values}
    for feature,value in shapes(raster,mask=raster>0,connectivity=4,
                               transform=Affine.translation(origin[1]-.5,origin[0]-.5)):
        parts[int(value)].append(geometry_shape(feature))
    h=homography(matrix)
    domain=np.array([[origin[1]-.5,origin[0]-.5],[origin[1]+size[1]-.5,origin[0]-.5],
                     [origin[1]+size[1]-.5,origin[0]+size[0]-.5],[origin[1]-.5,origin[0]+size[0]-.5]])
    den=domain@h[2,:2]+h[2,2]
    if not (np.all(den>1e-8) or np.all(den < -1e-8)):raise ValueError('Projective denominator crosses the array domain.')
    def mapped(x,y,z=None):
        q=project_xy(np.column_stack([x,y]),h)
        return q[:,0],q[:,1]
    _, counts = np.unique(labels[labels>0], return_counts=True)
    geometries=[]
    for v, count in zip(values, counts):
        g=unary_union(parts[int(v)])
        if not np.isclose(g.area,int(count)):raise ValueError('Traced boundary does not preserve assigned-bin area.')
        g=transform(mapped,g)
        if not g.is_valid or g.is_empty or g.area<=0 or g.geom_type not in ('Polygon','MultiPolygon'):
            raise ValueError(f'Invalid traced/transformed geometry for label {v}; no silent repair.')
        geometries.append(g)
    return gpd.GeoDataFrame({'object_id':values},geometry=geometries,index=[str(v) for v in values],crs=None)
