"""Explicit opt-in method namespace; old projects remain on their legacy route."""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import math

VERSION = 'dual-method-v1'
METHODS = ('proseg', 'bin2cell')
BIN2CELL_DEFAULTS = {
    'max_bin_distance': 2, 'k': 4, 'subset_pca': True,
    'bin_scope': 'match_proseg', 'max_grid_pixels': 50_000_000,
    'secondary': {'enabled': False, 'smoothing_sigma_bins': 1.0,
                  'prob_thresh': None, 'nms_thresh': None,
                  'block_size': 2048, 'min_overlap': 256, 'context': 128},
}


def selected_methods(cfg):
    """None means untouched v5 cells route; an explicit list uses named tables."""
    values = cfg.get('cells', {}).get('methods')
    if values is None:
        return None
    if not isinstance(values, (list, tuple)) or not values:
        raise ValueError('cells.methods must be a nonempty list: proseg, bin2cell, or both.')
    if any(v not in METHODS for v in values) or len(set(values)) != len(values):
        raise ValueError('Unknown/duplicate reconstruction method; use proseg and/or bin2cell.')
    return tuple(v for v in METHODS if v in values)


def generated_entry(spec):
    return spec.get('_row', {}).get('stage', 'raw') in ('raw', 'bin_imported', 'bin_QCed')


def analysis_table(cfg, spec=None):
    # Never relabel an imported cell population as a reconstruction method.
    if spec is not None and not generated_entry(spec):
        return 'cells'
    values = selected_methods(cfg)
    if values is None:
        return 'cells'
    name = cfg.get('cells', {}).get('analysis_method')
    if name is None and len(values) == 1:
        name = values[0]
    if name not in values:
        raise ValueError('Choose cells.analysis_method from the selected reconstruction methods.')
    return name


def bin2cell_settings(cfg):
    raw = cfg.get('bin2cell', {})
    if not isinstance(raw, dict) or set(raw) - set(BIN2CELL_DEFAULTS):
        raise ValueError('Unknown Bin2cell configuration field.')
    out = deepcopy(BIN2CELL_DEFAULTS)
    out.update({k:v for k,v in raw.items() if k != 'secondary'})
    secondary = raw.get('secondary', {})
    if not isinstance(secondary, dict) or set(secondary) - set(out['secondary']):
        raise ValueError('Unknown secondary segmentation field.')
    out['secondary'].update(secondary)
    for key, minimum in [('max_bin_distance',0),('k',2),('max_grid_pixels',1)]:
        if isinstance(out[key], bool) or not isinstance(out[key], int) or out[key] < minimum:
            raise ValueError(f'bin2cell.{key} must be an integer >= {minimum}.')
    if not isinstance(out['subset_pca'], bool):
        raise ValueError('bin2cell.subset_pca must be boolean.')
    if out['bin_scope'] not in ('match_proseg','segmentation_keep','qc_keep'):
        raise ValueError('bin2cell.bin_scope: match_proseg, segmentation_keep, or qc_keep.')
    s = out['secondary']
    if not isinstance(s['enabled'], bool):
        raise ValueError('bin2cell.secondary.enabled must be boolean.')
    for k in ('prob_thresh','nms_thresh'):
        if s[k] is not None and (isinstance(s[k],bool) or not math.isfinite(float(s[k])) or not 0 <= float(s[k]) <= 1):
            raise ValueError(f'Secondary {k} must be None or a finite number in [0,1].')
    if not math.isfinite(float(s['smoothing_sigma_bins'])) or s['smoothing_sigma_bins'] < 0:
        raise ValueError('Secondary smoothing_sigma_bins must be finite and nonnegative.')
    for k in ('block_size','context','min_overlap'):
        if isinstance(s[k],bool) or not isinstance(s[k],int) or s[k] < 1:
            raise ValueError(f'Secondary {k} must be a positive integer.')
    if s['block_size'] <= 2*s['context'] + s['min_overlap']:
        raise ValueError('Secondary block_size must exceed 2*context + min_overlap.')
    return out


def method_paths(p, method):
    """Proseg keeps its existing on-disk cache. Bin2cell never overwrites it."""
    if method not in METHODS:
        raise ValueError(method)
    if method == 'proseg':
        w, r = Path(p['work']), Path(p['report'])
        marker = w/'05_cells_complete.json'
    else:
        w, r = Path(p['work'])/'bin2cell', Path(p['report'])/'bin2cell'
        marker = w/'complete.json'
    return {'work':w, 'report':r, 'cells':w/'cells_qc.h5ad',
            'polygons':w/'cells_fullres.parquet', 'marker':marker,
            'assignments':w/'bin_assignments.parquet',
            'region':method+'_cell_boundaries', 'table':method}


def effective_bin_column(cfg):
    value = bin2cell_settings(cfg)['bin_scope']
    if value == 'match_proseg':
        return 'segmentation_keep' if cfg.get('prior_filter',{}).get('filter_proseg_bins',False) else 'qc_keep'
    return value


def apply_method_route(steps, cfg, row):
    """Rewrite only generated-cell routes, preserving bin and imported-cell paths."""
    methods = selected_methods(cfg)
    if methods is None or row['stage'] not in ('raw','bin_imported','bin_QCed') or 'proseg' not in steps:
        return list(steps)
    out=[]
    for step in steps:
        if step == 'proseg':
            if 'proseg' in methods:out.append('proseg')
        elif step == 'postprocess_cells':
            if 'proseg' in methods:out.append('postprocess_cells')
            if 'bin2cell' in methods:
                if bin2cell_settings(cfg)['secondary']['enabled']:out.append('bin2cell_secondary')
                out.append('bin2cell')
        elif step == 'assemble':out.append('assemble_methods')
        elif step == 'refresh_cell_annotations':out.append('refresh_method_annotations')
        else:out.append(step)
    return out
