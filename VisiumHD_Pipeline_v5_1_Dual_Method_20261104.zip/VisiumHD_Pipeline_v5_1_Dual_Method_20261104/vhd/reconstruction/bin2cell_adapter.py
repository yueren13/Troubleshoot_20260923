"""Official Bin2cell expansion/aggregation on the existing reviewed bin/prior inputs.

Raw X is never destriped, normalized, or replaced by density-map intensities.
The optional density StarDist stage is separate and is never called when off.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import importlib.metadata
import json
import os
import numpy as np
import pandas as pd
from .config import VERSION, bin2cell_settings, effective_bin_column, method_paths
from .geometry import sample_prior, assignment_matrix, grid_layout, label_polygons
from ..core import (digest, file_stamp, reusable, completed, sample_paths, require_review,
                    integer_csr, dump_json, stage_lock, write_h5ad, qc_metrics, transform_xy)


def _sources(cfg,spec):
    from ..master import current_annotations,effective_bin_obs,transfer_config
    current_annotations(cfg,spec);require_review(cfg,spec)
    p=sample_paths(cfg,spec);cfg=transfer_config(cfg,p)
    for f in (p['bins'],p['geometry'],p['prior'],p['prior_meta'],effective_bin_obs(p)):
        if not f.is_file():raise FileNotFoundError(f)
    from ..segmentation import prior_signature
    sig=prior_signature(cfg,spec)
    required=[p['prior'],p['raw_prior'],p['prior_meta'],p['crop']]
    if not reusable(p['work']/'03_prior_complete.json',sig,required):
        raise RuntimeError('Generate the shared reviewed StarDist prior before running Bin2cell.')
    obs=pd.read_parquet(effective_bin_obs(p));column=effective_bin_column(cfg)
    if column not in obs or not pd.api.types.is_bool_dtype(obs[column]) or obs[column].isna().any():
        raise ValueError(f'Expected nonnullable Boolean bin eligibility column: {column}')
    keep=obs[column].to_numpy(bool)
    if not keep.any():raise ValueError('No eligible bins for Bin2cell.')
    return cfg,p,obs,keep,json.loads(p['geometry'].read_text()),json.loads(p['prior_meta'].read_text())


@contextmanager
def limited_affinity(n):
    """Bin2cell uses cKDTree workers=-1. Bound that query to this worker's CPUs."""
    previous=None
    if hasattr(os,'sched_getaffinity') and hasattr(os,'sched_setaffinity'):
        previous=os.sched_getaffinity(0)
        os.sched_setaffinity(0,sorted(previous)[:max(1,int(n))])
    try:yield
    finally:
        if previous is not None:os.sched_setaffinity(0,previous)


def expand_with_upstream(a, settings, b2c, threads=1):
    """Small/all-labelled edge cases are explicit; ordinary cases use upstream API."""
    before=a.obs['labels_he'].to_numpy(np.int64).copy();nseed=int((before>0).sum())
    if nseed==0:raise ValueError('No eligible bin center intersects the shared nuclear prior.')
    if settings['max_bin_distance']==0 or np.all(before>0):
        a.obs['labels_he_expanded']=before
        return {'expansion_called':False,'reason':'zero_distance_or_all_bins_seeded'}
    if nseed<2:
        # Upstream k=1 is a different array-shape path and is not robustly supported.
        raise ValueError('Bin2cell expansion requires at least two nucleus-labelled bins; use a larger pilot region.')
    k=min(settings['k'],nseed)
    with limited_affinity(threads):
        b2c.expand_labels(a,labels_key='labels_he',expanded_labels_key='labels_he_expanded',
                         algorithm='max_bin_distance',max_bin_distance=settings['max_bin_distance'],
                         k=k,subset_pca=settings['subset_pca'])
    out=a.obs['labels_he_expanded'].to_numpy()
    if not np.issubdtype(out.dtype,np.integer) or (out<0).any():raise ValueError('Unexpected Bin2cell labels.')
    if not np.array_equal(out[before>0],before[before>0]):raise ValueError('Expansion changed a primary seed label.')
    if not set(np.unique(out)).issubset(set(np.unique(before))|{0}):raise ValueError('Expansion introduced an unknown primary label.')
    return {'expansion_called':True,'k_effective':k,'cpu_affinity_limit_requested':int(threads)}


def _load_bins(cfg,p,obs,keep):
    import anndata as ad
    # Existing loaders already validate raw counts. Repeat integer validation at the boundary.
    a=ad.read_h5ad(p['bins'],backed='r')
    try:
        if not a.obs_names.equals(obs.index):raise ValueError('Bin barcode order differs from saved QC metadata.')
        import h5py, psutil
        with h5py.File(p['bins'],'r') as h:
            x=h['X']
            if not all(k in x for k in ('data','indices','indptr')):raise ValueError('Bin2cell expects sparse CSR raw counts.')
            if x.attrs.get('encoding-type')!='csr_matrix':raise ValueError('Bin2cell expects CSR counts.')
            matrix_bytes=sum(x[k].size*x[k].dtype.itemsize for k in ('data','indices','indptr'))
        # Budget the full raw matrix rather than underestimating the eligible subset.
        # Includes int64 conversion, verification copy, and aggregated matrix/PCA working room.
        estimate=5*matrix_bytes + int(keep.sum())*1024
        available=psutil.virtual_memory().available
        from ..center.resources import cgroup_limits
        headroom=cgroup_limits().get('memory_headroom_bytes')
        if headroom is not None:available=min(available,headroom)
        cap=float(cfg.get('import',{}).get('max_matrix_gib',100))*2**30
        budget=float(cfg.get('execution',{}).get('host_ram_budget_gib',available/2**30))*2**30
        available=min(available,budget)
        if matrix_bytes>cap or estimate>available*.75:
            raise MemoryError(f'Bin2cell eager matrix budget: source {matrix_bytes/2**30:.2f} GiB; estimated working {estimate/2**30:.2f} GiB; available {available/2**30:.2f} GiB. Run fewer samples or a smaller pilot; not a hard memory guarantee.')
        out=a[keep].to_memory()
    finally:a.file.close()
    out.obs=obs.loc[out.obs_names].copy()
    out.X=integer_csr(out.X).astype(np.int64)
    out.raw=None
    for key in list(out.layers):del out.layers[key]
    xy=out.obs[['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy(np.float64)
    if not np.array_equal(np.asarray(out.obsm['spatial']),xy):raise ValueError('Source bin coordinates differ from canonical full-resolution centers.')
    return out


def _cell_qc(a,g,cfg,spec,geom,report):
    from ..cells import transform_polygons,cycle_scores
    from ..sample_metadata import attach_sample_metadata
    for k,v in qc_metrics(a.X,a.var['gene_symbol']).items():a.obs[k]=v.to_numpy()
    physical=transform_polygons(g,np.diag([*geom['image_mpp'],1.])@np.asarray(geom['tenx_to_image'])).geometry.area.to_numpy()
    if not np.isfinite(physical).all() or (physical<=0).any():raise ValueError('Invalid physical cell footprint area.')
    a.obs['cell_area_um2']=physical;a.obs['counts_per_um2']=a.obs.total_counts.to_numpy()/physical
    a.obs['equivalent_2um_bins']=physical/4.
    a.obsm['spatial_image_px']=transform_xy(a.obsm['spatial'],geom['tenx_to_image'])
    q=a.obsm['spatial_image_px'];info=geom['image']
    a.obs['image_in_bounds']=(q[:,0]>=0)&(q[:,0]<info['width'])&(q[:,1]>=0)&(q[:,1]<info['height'])
    a.obs['centroid_x']=a.obsm['spatial'][:,0];a.obs['centroid_y']=a.obsm['spatial'][:,1]
    a.obs['sample']=spec['sample'];a.obs['sample_id']=spec.get('sample_id',spec['sample']);a.obs['dataset_id']=spec.get('dataset_id','')
    a.obs['cell_boundary_available']=True;attach_sample_metadata(a,spec)
    settings={**cfg['cells']['qc'],**spec.get('cell_qc_overrides',{})}
    rules={'low_counts':a.obs.total_counts<settings['min_counts'],'low_genes':a.obs.n_genes_by_counts<settings['min_genes']}
    for key,col,op in [('max_pct_mt','pct_counts_mt','gt'),('min_area_um2','cell_area_um2','lt'),('max_area_um2','cell_area_um2','gt')]:
        if settings.get(key) is not None:rules[key]=getattr(a.obs[col],op)(settings[key])
    failed=np.zeros(a.n_obs,bool);reasons=np.full(a.n_obs,'',object)
    for key,mask in rules.items():
        mask=np.asarray(mask,bool);a.obs['qc_fail__'+key]=mask;failed|=mask
        reasons[mask]=[s+';'+key if s else key for s in reasons[mask]]
    a.obs['qc_pass']=~failed;a.obs['qc_fail_reason']=pd.Categorical(np.where(failed,reasons,'pass'))
    cycle_scores(a,cfg['cell_cycle'])
    from ..plots import standard_qc_plots,scatter_categorical,scatter_numeric,boundary_overlay
    from ..images import thumbnail
    standard_qc_plots(a.obs,report,'cells',cfg['plots']['dpi'])
    thumb=thumbnail(info,cfg['plots']['thumbnail_max_side'])
    scatter_categorical(q,a.obs.qc_pass,spec['sample']+': Bin2cell QC',report/'cells_qc_pass_on_HE.png',thumb=thumb,image_size=(info['width'],info['height']),dpi=cfg['plots']['dpi'])
    for col in ('total_counts','n_genes_by_counts','pct_counts_mt','cell_area_um2'):
        scatter_numeric(q,a.obs[col],spec['sample']+': Bin2cell '+col,report/f'cells_{col}_on_HE.png',thumb=thumb,image_size=(info['width'],info['height']),dpi=cfg['plots']['dpi'],log1p=col in ('total_counts','n_genes_by_counts'))
    gi=transform_polygons(g,geom['tenx_to_image'])
    boundary_overlay(gi,info,thumb,report/'cells_boundaries_whole.png',dpi=cfg['plots']['dpi'])
    rois=spec.get('rois_image_px',{})
    if not rois:
        cx,cy=np.median(q,axis=0);n=cfg['plots']['roi_size_px'];x=max(0,int(cx-n/2));y=max(0,int(cy-n/2))
        rois={'center':[x,y,min(info['width'],x+n),min(info['height'],y+n)]}
    for name,bounds in rois.items():boundary_overlay(gi,info,thumb,report/f'cells_boundaries_ROI_{name}.png',bounds=bounds,dpi=cfg['plots']['dpi'])
    summary={'sample':spec['sample'],'method':'bin2cell','n_cells':a.n_obs,'n_qc_pass':int((~failed).sum()),'assigned_umis':int(a.X.sum(dtype=np.int64)),
             'median_umis':float(a.obs.total_counts.median()),'median_genes':float(a.obs.n_genes_by_counts.median()),'median_area_um2':float(np.median(physical))}
    pd.DataFrame([summary]).to_csv(report/'cell_qc_summary.csv',index=False)
    return summary


def run_bin2cell(cfg,spec):
    import bin2cell as b2c
    from ..master import effective_bin_obs
    cfg,p,obs,keep,geom,prior=_sources(cfg,spec);settings=bin2cell_settings(cfg);mp=method_paths(p,'bin2cell')
    version=importlib.metadata.version('bin2cell')
    from packaging.version import Version
    if not Version('0.3.3')<=Version(version)<Version('0.4'):
        raise RuntimeError(f'Bin2cell {version}: this adapter targets >=0.3.3,<0.4; validate the API before changing this guard.')
    for fn in ('expand_labels','bin_to_cell','salvage_secondary_labels'):
        if not callable(getattr(b2c,fn,None)):raise RuntimeError('Missing Bin2cell API: '+fn)
    inputs={'bins':file_stamp(p['bins']),'obs':file_stamp(effective_bin_obs(p)),
            'prior':file_stamp(p['work']/'03_prior_complete.json'),'geometry':file_stamp(p['geometry'])}
    secondary=mp['work']/'secondary_complete.json'
    if settings['secondary']['enabled']:
        if not secondary.is_file():raise FileNotFoundError('Run bin2cell_secondary first: '+str(secondary))
        expected=_secondary_signature(cfg,p)
        if not reusable(secondary,expected,[mp['work']/'secondary_labels.parquet',mp['work']/'density_image.npy']):raise RuntimeError('Missing secondary density labels.')
        inputs['secondary']=file_stamp(secondary)
    signature=digest({'adapter':VERSION,'upstream_version':version,'inputs':inputs,'settings':settings,
                     'cell_qc':cfg['cells']['qc'],'transfer':cfg['metadata_transfer'],'metadata':spec.get('metadata',{}),
                     'cycle':cfg['cell_cycle'],'cycle_lists':file_stamp(cfg['cell_cycle']['gene_lists_json']) if cfg['cell_cycle']['enabled'] else None})
    required=[mp['cells'],mp['polygons'],mp['assignments'],mp['report']/'run_summary.json']
    if reusable(mp['marker'],signature,required):return json.loads((mp['report']/'run_summary.json').read_text())
    mp['work'].mkdir(parents=True,exist_ok=True);mp['report'].mkdir(parents=True,exist_ok=True)
    with stage_lock(mp['work'],'bin2cell'):
        a=_load_bins(cfg,p,obs,keep)
        matrix=a.X.copy();xy=np.asarray(a.obsm['spatial']).copy();names=a.var_names.copy()
        labels=sample_prior(np.load(p['prior'],mmap_mode='r'),xy,geom,prior)
        a.obs['labels_he']=labels
        execution=expand_with_upstream(a,settings,b2c,int(os.environ.get('OMP_NUM_THREADS','1')))
        label_key='labels_he_expanded'
        if settings['secondary']['enabled']:
            sec=pd.read_parquet(mp['work']/'secondary_labels.parquet')
            if not sec.index.equals(a.obs_names):raise ValueError('Secondary bin identities/order mismatch.')
            a.obs['labels_gex']=sec['labels_gex'].to_numpy(np.int64)
            b2c.salvage_secondary_labels(a,primary_label=label_key,secondary_label='labels_gex',labels_key='labels_joint');label_key='labels_joint'
        final=a.obs[label_key].to_numpy(np.int64)
        ids,assignment,mapping=assignment_matrix(final)
        if not len(ids):raise ValueError('Bin2cell produced no assigned cells.')
        # bin_to_cell expects this display-only dictionary. It does not govern geometry.
        # No image pixels are placed in AnnData.uns.
        mpp=float(geom.get('source_mpp',float('nan')))
        if not np.isfinite(mpp) or mpp<=0:raise ValueError('Original-image microns-per-pixel calibration is required; none is guessed.')
        a.uns['spatial']={'vhd':{'scalefactors':{'spot_diameter_fullres':2./mpp}}}
        cells=b2c.bin_to_cell(a,labels_key=label_key,spatial_keys=['spatial'])
        if not cells.obs_names.equals(pd.Index(ids.astype(str))):raise ValueError('Unexpected Bin2cell cell order.')
        if not cells.var_names.equals(names) or not np.array_equal(a.obsm['spatial'],xy) or (a.X!=matrix).nnz:
            raise ValueError('Bin2cell changed source features, coordinates or raw counts.')
        expected=assignment@matrix
        cells.X=integer_csr(cells.X)
        if cells.X.shape!=expected.shape or (cells.X!=expected).nnz:raise ValueError('Aggregation differs from exact raw-count summation.')
        assigned=final>0
        if not np.array_equal(np.asarray(matrix[assigned].sum(axis=0,dtype=np.int64)),np.asarray(cells.X.sum(axis=0,dtype=np.int64))):
            raise ValueError('Per-gene assigned-bin count conservation failed.')
        g=label_polygons(a.obs.array_row.to_numpy(),a.obs.array_col.to_numpy(),final,geom['grid_index_to_fullres'],settings['max_grid_pixels'])
        if not settings['secondary']['enabled']:cells.obs['seed_source']='primary_he'
        else:
            source_column=label_key+'_source'
            if source_column not in cells.obs:raise ValueError('Upstream secondary-source attribution is missing.')
            cells.obs['seed_source']=cells.obs[source_column].astype(str)
        cells.obs['local_cell_id']=cells.obs_names.astype(str)
        canonical=pd.Index([f"{spec['sample']}::bin2cell::{v}" for v in cells.obs_names]);cells.obs_names=canonical;g.index=canonical
        cells.obs['segmentation_method']='bin2cell';cells.obs['region']=pd.Categorical(['bin2cell_cell_boundaries']*cells.n_obs);cells.obs['instance_id']=canonical.astype(str)
        if cfg['metadata_transfer']['enabled']:
            from ..annotations.transfer import aggregate_annotations
            annotations=aggregate_annotations(a.obs,mapping,cells.n_obs,cfg['metadata_transfer']).rename(columns=lambda c:c.replace('geometric_','assigned_',1))
            annotations.index=cells.obs_names
            for col in annotations:cells.obs[col]=annotations[col]
        cells.uns.pop('spatial',None);cells.uns.pop('spatialdata_attrs',None)
        cells.uns['vhd']={'adapter':VERSION,'segmentation_method':'bin2cell','upstream_version':version,'counts_location':'X',
                          'counts_kind':'integer raw-bin sums','coordinate_system':'fullres','secondary_enabled':settings['secondary']['enabled'],
                          'bin_scope_column':effective_bin_column(cfg),'boundary_basis':'union_of_assigned_array_bin_footprints_projected_to_fullres',
                          'bin_metadata_basis':'exact_bin_assignments_not_Proseg_molecule_assignments'}
        summary=_cell_qc(cells,g,cfg,spec,geom,mp['report'])
        summary.update(upstream_version=version,settings=settings,execution=execution,n_eligible_bins=a.n_obs,
                       n_assigned_bins=int(assigned.sum()),n_unassigned_bins=int((~assigned).sum()),
                       eligible_umis=int(matrix.sum(dtype=np.int64)),secondary_enabled=settings['secondary']['enabled'],
                       raw_count_conservation_passed=True,shared_prior=str(p['prior']))
        write_h5ad(cells,mp['cells']);g.to_parquet(mp['polygons'])
        pd.DataFrame({'cell_row':mapping,'cell_label':final,'primary_label':labels},index=a.obs_names).to_parquet(mp['assignments'])
        dump_json(summary,mp['report']/'run_summary.json')
        completed(mp['marker'],signature,required,method='bin2cell',cell_ids_sha256=digest(canonical.tolist()))
        return summary


def _secondary_signature(cfg,p):
    from ..master import effective_bin_obs
    from importlib.metadata import version
    return digest({'adapter':VERSION,'stage':'array_density_stardist','counts':file_stamp(p['bins']),
                   'obs':file_stamp(effective_bin_obs(p)),'scope':effective_bin_column(cfg),
                   'settings':bin2cell_settings(cfg)['secondary'],'stardist_version':version('stardist')})


def run_secondary(cfg,spec):
    """Optional fluorescence StarDist on a 2-um array-grid count-density image."""
    settings=bin2cell_settings(cfg)
    if not settings['secondary']['enabled']:raise ValueError('Secondary segmentation is disabled; nothing was run.')
    import tensorflow as tf
    from stardist.models import StarDist2D
    from csbdeep.utils import normalize
    from scipy.ndimage import gaussian_filter
    cfg,p,obs,keep,geom,prior=_sources(cfg,spec);mp=method_paths(p,'bin2cell');s=settings['secondary']
    signature=_secondary_signature(cfg,p);required=[mp['work']/'secondary_labels.parquet',mp['work']/'density_image.npy']
    marker=mp['work']/'secondary_complete.json'
    if reusable(marker,signature,required):return json.loads(marker.read_text())
    if cfg['stardist'].get('require_gpu',True) and not tf.config.list_physical_devices('GPU'):raise RuntimeError('Secondary StarDist requires a visible TensorFlow GPU.')
    for device in tf.config.list_physical_devices('GPU'):
        try:tf.config.experimental.set_memory_growth(device,True)
        except RuntimeError:pass
    chosen=obs.loc[keep];r,c,size,origin=grid_layout(chosen.array_row,chosen.array_col,settings['max_grid_pixels'])
    density=np.zeros(size,np.float32);values=chosen.total_counts.to_numpy(float)
    if not np.isfinite(values).all() or (values<0).any():raise ValueError('Invalid raw-count density values.')
    density[r,c]=np.log1p(values)
    if s['smoothing_sigma_bins']:density=gaussian_filter(density,s['smoothing_sigma_bins'])
    if density.max()<=density.min():raise ValueError('Constant density image cannot be segmented.')
    mp['work'].mkdir(parents=True,exist_ok=True);mp['report'].mkdir(parents=True,exist_ok=True)
    with stage_lock(mp['work'],'density_secondary'):
        model=StarDist2D.from_pretrained('2D_versatile_fluo')
        overrides={k:s[k] for k in ('prob_thresh','nms_thresh') if s[k] is not None}
        labels,_=model.predict_instances_big(normalize(density,1,99.8),axes='YX',block_size=s['block_size'],context=s['context'],min_overlap=s['min_overlap'],**overrides)
        pd.DataFrame({'labels_gex':labels[r,c].astype(np.int64)},index=chosen.index).to_parquet(required[0]);np.save(required[1],density)
        report={'basis':'array_row_col_2um','origin_row_col':origin,'grid_shape':size,'model':'2D_versatile_fluo','settings':s,
                'thresholds_effective':{'prob_thresh':overrides.get('prob_thresh',float(model.thresholds.prob)),
                                        'nms_thresh':overrides.get('nms_thresh',float(model.thresholds.nms))},
                'counts_modified':False,'note':'Only secondary objects not overlapping primary assignments will be salvaged.'}
        dump_json(report,mp['report']/'secondary_summary.json');completed(marker,signature,required)
        return report
