"""Append independently linked method tables; never replace another reconstruction.

Existing tables['cells'] remains untouched. Each method has its own provenance,
boundary region, IDs, completion record and metadata-refresh receipt.
"""
from __future__ import annotations
from pathlib import Path
from copy import deepcopy
import json
import numpy as np
import pandas as pd
from .config import VERSION, selected_methods, method_paths
from ..core import sample_paths,file_stamp,digest,dump_json,integer_csr


def _read_shapes(store,region):
    # SpatialData's public reader selects element TYPES, not individual names.
    # Isolate this internal reader dependency to avoid loading millions of bin shapes.
    try:
        from spatialdata._io.io_shapes import _read_shapes as read
    except ImportError as exc:
        raise RuntimeError('This SpatialData version lacks the selective shapes reader. Run tests/test_dual_spatial_optional.py in the target environment.') from exc
    return read(str(Path(store)/'shapes'/region))


def verify_method(store,method):
    from ..io import table_metadata
    from spatialdata.transformations import get_transformation
    from anndata.io import read_elem
    import zarr
    region=method+'_cell_boundaries';obs,var=table_metadata(store,method)
    g=_read_shapes(store,region)
    if not obs.index.is_unique or not g.index.is_unique or not np.array_equal(obs.instance_id.astype(str),g.index.astype(str)):
        raise ValueError(method+': table/shape identifiers or ordering differ.')
    if not obs.region.astype(str).eq(region).all() or not obs.segmentation_method.astype(str).eq(method).all():
        raise ValueError(method+': incorrect method/region linkage.')
    if not (g.geometry.is_valid & ~g.geometry.is_empty & g.geometry.geom_type.isin(['Polygon','MultiPolygon'])).all():
        raise ValueError(method+': invalid cell boundary geometry on readback.')
    m=get_transformation(g,to_coordinate_system='fullres').to_affine_matrix(input_axes=('x','y'),output_axes=('x','y'))
    if not np.allclose(m,np.eye(3),rtol=0,atol=1e-12):raise ValueError('Method boundaries are not in original full-resolution pixels.')
    root=zarr.open_group(str(Path(store)/'tables'/method),mode='r')
    xy=np.asarray(read_elem(root['obsm']['spatial']))
    if xy.shape!=(len(obs),2) or not np.isfinite(xy).all():raise ValueError('Invalid method cell coordinates.')
    if not np.array_equal(xy,obs[['centroid_x','centroid_y']].to_numpy(float)):raise ValueError('Cell centroid metadata drift.')
    return {'method':method,'n_cells':len(obs),'n_genes':len(var),'region':region,
            'expression_loaded':False,'cell_id_digest':digest(obs.index.astype(str).tolist())}


def verify_written_counts(store,method,expected,chunk_size=1_000_000):
    """Compare the just-written CSR components in bounded reads while X is available."""
    import zarr
    x=zarr.open_group(str(Path(store)/'tables'/method),mode='r')['X']
    if x.attrs.get('encoding-type')!='csr_matrix' or tuple(x.attrs['shape'])!=expected.shape:
        raise ValueError('Stored expression encoding/shape differs from source CSR.')
    for key in ('data','indices','indptr'):
        wanted=getattr(expected,key);written=x[key]
        if written.shape!=wanted.shape:raise ValueError('Stored CSR component shape changed: '+key)
        for start in range(0,len(wanted),chunk_size):
            if not np.array_equal(written[start:start+chunk_size],wanted[start:start+chunk_size]):
                raise ValueError(f'Stored raw counts differ in {method}/X/{key}.')


def canonicalize(a,g,method,spec):
    """Copy metadata/geometry identity only; retain the count matrix and coordinates."""
    if not a.obs_names.equals(g.index.astype(str)):raise ValueError('Prepared cell/shape order mismatch.')
    old=a.obs_names.astype(str).copy()
    local=a.obs['local_cell_id'].astype(str) if 'local_cell_id' in a.obs else pd.Series(old,index=old)
    if not local.is_unique:raise ValueError('Duplicate local IDs within a method.')
    ids=pd.Index([f"{spec['sample']}::{method}::{v}" for v in local],name=None)
    if 'source_obs_name' not in a.obs:a.obs['source_obs_name']=old.to_numpy()
    a.obs['local_cell_id']=local.to_numpy();a.obs_names=ids;g=g.copy();g.index=ids
    a.obs['segmentation_method']=method
    a.obs['centroid_x']=np.asarray(a.obsm['spatial'])[:,0];a.obs['centroid_y']=np.asarray(a.obsm['spatial'])[:,1]
    a.uns.setdefault('vhd',{})['segmentation_method']=method
    return a,g


def _tracked_sources(mp):
    if not mp['marker'].is_file():raise FileNotFoundError('Missing cell completion record: '+str(mp['marker']))
    record=json.loads(mp['marker'].read_text())
    if not record.get('outputs'):raise RuntimeError('Cell completion record has no tracked outputs.')
    for item in record['outputs']:
        if file_stamp(item['path'])!=item:raise RuntimeError('Prepared cell output changed: '+item['path'])
    return {'cells':file_stamp(mp['cells']),'polygons':file_stamp(mp['polygons']),
            'completion':file_stamp(mp['marker'])}


def append_method(cfg,spec,method):
    import anndata as ad
    import geopandas as gpd
    import spatialdata as sd
    from spatialdata.models import ShapesModel
    from spatialdata.transformations import Identity
    from ..persistence import persist_changes
    from ..storage import parse_table
    from ..sample_metadata import attach_sample_metadata
    p=sample_paths(cfg,spec);mp=method_paths(p,method);sources=_tracked_sources(mp)
    receipt=p['report']/f'method_{method}_master.json'
    sig=digest({'version':VERSION,'method':method,'sources':sources,'metadata':spec.get('metadata',{})})
    exists=(p['store']/'tables'/method).exists();shape_exists=(p['store']/'shapes'/mp['region']).exists()
    if exists or shape_exists:
        if not receipt.is_file() or not exists or not shape_exists:raise RuntimeError('Partial/untracked method elements; inspect without deleting: '+method)
        old=json.loads(receipt.read_text())
        if old.get('signature')!=sig:raise RuntimeError('Method inputs changed; use a new run/master, never overwrite another result.')
        for item in old['outputs']:
            if file_stamp(item['path'])!=item:raise RuntimeError('Stored method element changed outside tracked update: '+item['path'])
        return verify_method(p['store'],method)
    if receipt.exists():raise RuntimeError('Method receipt exists but its store elements are absent.')
    a=ad.read_h5ad(mp['cells']);a.X=integer_csr(a.X);g=gpd.read_parquet(mp['polygons'])
    a,g=canonicalize(a,g,method,spec);attach_sample_metadata(a,spec)
    # Empty selection loads container metadata only, not other expression or bin shapes.
    s=sd.read_zarr(str(p['store']),selection=())
    s.shapes[mp['region']]=ShapesModel.parse(g,transformations={'fullres':Identity()})
    s.tables[method]=parse_table(a,mp['region'],a.obs_names.astype(str))
    persist_changes(s,new_elements=[mp['region'],method],policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,
                    single_writer_ack=cfg['storage'].get('single_writer_ack',False),selected_readback=True)
    verify_written_counts(p['store'],method,a.X)
    check=verify_method(p['store'],method)
    dump_json({'signature':sig,'sources':sources,'method':method,'count_readback_verified':True,
               'outputs':[file_stamp(p['store']/'tables'/method),file_stamp(p['store']/'shapes'/mp['region'])],
               'validation':check},receipt)
    return check


def assemble_methods(cfg,spec):
    from ..master import assemble_master,current_annotations
    from ..bin_master import assert_destination_identity
    methods=selected_methods(cfg)
    if not methods:raise ValueError('Explicit cells.methods selection is required.')
    assert_destination_identity(cfg,spec);current_annotations(cfg,spec)
    # Build/reuse the bin master only. Never manufacture or rename legacy cells.
    base=deepcopy(cfg);base['cells']['mode']='none'
    assemble_master(base,spec,bins_only=True)
    p=sample_paths(cfg,spec);results=[]
    # Serialized appends; a failed second method does not delete the first.
    for method in methods:results.append(append_method(cfg,spec,method))
    result={'methods':list(methods),'tables':['bins_2um',*methods],'results':results,
            'legacy_cells_preserved':(p['store']/'tables/cells').exists()}
    dump_json(result,p['report']/'cell_methods_manifest.json')
    from .reports import comparison_report
    comparison_report(cfg,spec)
    return result


def refresh_method_annotations(cfg,spec):
    from ..master import current_annotations,transfer_config,effective_bin_obs
    from ..annotations.transfer import aggregate_annotations
    from ..cells import geometric_assign
    from ..io import table_metadata
    from ..persistence import update_table_metadata
    current_annotations(cfg,spec);p=sample_paths(cfg,spec);cfg=transfer_config(cfg,p)
    if not cfg['metadata_transfer']['enabled']:return {'status':'metadata_transfer_disabled'}
    bins=pd.read_parquet(effective_bin_obs(p));settings=cfg['metadata_transfer'];results=[]
    for method in selected_methods(cfg) or ():
        mp=method_paths(p,method);obs,_=table_metadata(p['store'],method)
        if method=='bin2cell':
            source=pd.read_parquet(mp['assignments'])
            if not source.index.is_unique:raise ValueError('Duplicate Bin2cell assignment barcodes.')
            labels=source.cell_label.to_numpy(np.int64)
            lut=pd.Series(np.arange(len(obs)),index=obs.local_cell_id.astype(str))
            rows=lut.reindex(labels.astype(str)).fillna(-1).to_numpy(np.int64)
            mapping=pd.Series(rows,index=source.index).reindex(bins.index,fill_value=-1).to_numpy(np.int64)
            basis='exact_discrete_bin2cell_assignments'
        else:
            g=_read_shapes(p['store'],mp['region'])
            if not np.array_equal(obs.instance_id.astype(str),g.index.astype(str)):raise ValueError('Method boundary order mismatch.')
            mapping=geometric_assign(bins[['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy(),g,settings['chunk_size'])
            basis='unique_bin_center_intersection_not_molecule_assignment'
        if settings['bin_scope']=='qc_keep_only':mapping[~bins.qc_keep.to_numpy(bool)]=-1
        elif settings['bin_scope']!='all_bins':raise ValueError('bin_scope: all_bins or qc_keep_only.')
        cols=aggregate_annotations(bins,mapping,len(obs),settings);cols.index=obs.index
        if method=='bin2cell':cols=cols.rename(columns=lambda c:c.replace('geometric_','assigned_',1))
        receipt=p['report']/f'method_{method}_annotation_refresh.json';old=json.loads(receipt.read_text()) if receipt.is_file() else {}
        drop=[c for c in old.get('owned_columns',[]) if c not in cols and c in obs]
        update_table_metadata(p['store'],method,obs=cols,drop_obs=drop,policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=cfg['storage'].get('single_writer_ack',False))
        result={'method':method,'n_cells':len(obs),'assignment_basis':basis,'n_assigned_bins':int((mapping>=0).sum()),
                'owned_columns':list(cols),'counts_rewritten':False}
        dump_json(result,receipt);results.append(result)
        master=p['report']/f'method_{method}_master.json'
        record=json.loads(master.read_text());record['outputs']=[file_stamp(p['store']/'tables'/method),file_stamp(p['store']/'shapes'/mp['region'])]
        record['annotation_refresh']=file_stamp(receipt);dump_json(record,master)
    dump_json({'methods':results},p['report']/'method_annotations.json')
    return results
