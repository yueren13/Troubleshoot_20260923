from __future__ import annotations

import gc
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .core import (VERSION, completed, digest, dump_json, file_stamp, integer_csr,
                   reusable, safe_frame, sample_paths, stage_lock, write_h5ad)
from .io import load_table, table_metadata
from .palette import distinct_palette, natural_order
from .plots import scatter_categorical, scatter_numeric, finish


def integration_dir(cfg):
    p=Path(cfg['_integration_work']) if cfg.get('_integration_work') else Path(cfg['output_root'])/'integration'/cfg['scvi']['run_name']
    p.mkdir(parents=True,exist_ok=True)
    return p


def eligible(obs,cfg):
    if 'qc_pass' not in obs or not pd.api.types.is_bool_dtype(obs.qc_pass):
        raise ValueError('Cell table requires a real boolean qc_pass column.')
    return (obs.qc_pass.to_numpy(bool)
            & (obs.total_counts.to_numpy()>=cfg['scvi']['min_counts'])
            & (obs.n_genes_by_counts.to_numpy()>=cfg['scvi']['min_genes']))


def consensus_hvg(rankings,number):
    """Batch-balanced consensus: number of top-HVG batches, then median within-batch rank."""
    ranks=pd.DataFrame(rankings).rename_axis(None)
    out=pd.DataFrame(index=ranks.index)
    out['n_batches_hvg']=ranks.notna().sum(axis=1)
    out['median_rank']=ranks.median(axis=1,skipna=True)
    out['gene_id']=out.index.astype(str)
    out=out.sort_values(['n_batches_hvg','median_rank','gene_id'],ascending=[False,True,True],na_position='last')
    out['selected_hvg']=False
    available=out.index[out.n_batches_hvg>0]
    if len(available)<number:
        raise ValueError(f'Only {len(available)} genes have usable within-sample HVG ranks; requested {number}.')
    out.loc[available[:number],'selected_hvg']=True
    return out


def prepare_scvi(cfg):
    """Two pass, one sample in RAM at a time; concat_on_disk assembles the shared-HVG input."""
    import anndata as ad
    import scanpy as sc
    from anndata.experimental import concat_on_disk
    p=integration_dir(cfg); stage=p/'staged_hvg'; stage.mkdir(exist_ok=True)
    specs=cfg['samples']
    if len(specs)<2:
        raise ValueError('Batch integration requires at least two samples.')
    store_paths={s['sample']:sample_paths(cfg,s)['store'] for s in specs}
    source_manifests=[sample_paths(cfg,s)['report']/'storage_manifest.json' for s in specs]
    source_tables={s['sample']:s.get('_cell_table','cells') for s in specs}
    if len(set(source_tables.values()))!=1:raise ValueError('Mixed reconstruction methods in an integration group.')
    settings=cfg['scvi']
    sig=digest({'version':VERSION,'sources':[file_stamp(x) for x in source_manifests], 'cell_tables':[file_stamp(store/'tables'/source_tables[name]) for name,store in store_paths.items()],
                'settings':{k:settings[k] for k in ('n_hvg','min_counts','min_genes','hvg_spans','exclude_prefixes')}})
    from .analysis_qc import require_analysis_qc,analysis_mask
    qc_record=require_analysis_qc(cfg)
    sig=digest({'prepare':sig,'analysis_qc':qc_record['signature'] if qc_record else None})
    def selection(name,obs):
        mask=eligible(obs,cfg)
        return mask & analysis_mask(cfg,name,obs.index) if qc_record else mask
    required=[p/'scvi_counts_hvg.h5ad',p/'features.csv',p/'sample_qc_counts.csv']
    marker=p/'08_prepare_complete.json'
    if reusable(marker,sig,required):
        return pd.read_csv(p/'sample_qc_counts.csv')
    with stage_lock(p,'prepare'):
        shared=None; summary=[]
        for name,store in store_paths.items():
            obs,var=table_metadata(store,source_tables[name])
            if not var.index.is_unique:
                raise ValueError(f'{name}: duplicate stable gene IDs.')
            gene_set=set(var.index.astype(str))
            shared=gene_set if shared is None else shared & gene_set
            summary.append({'sample':name,'n_cells':len(obs),'n_qc_eligible':int(selection(name,obs).sum()),
                            'n_assayed_genes':len(var)})
        common=pd.Index(sorted(shared))
        if qc_record:
            genes=pd.read_csv(p/'analysis_qc/gene_detection.csv',index_col=0)
            allowed=genes.index[genes['n_retained_cells_detecting']>=qc_record['gene_min_cells']]
            common=common[common.isin(allowed)]
        if len(common)<settings['n_hvg']:
            raise ValueError(f'{len(common)} common assayed genes < requested {settings["n_hvg"]} HVGs. '
                             'Review gene identifiers/panels or reduce n_hvg explicitly; no missing-gene zero-fill.')
        if any(x['n_qc_eligible']<20 for x in summary):
            raise ValueError('Each sample must have >=20 eligible cells for this HVG/scVI workflow.')
        rankings={}; hvg_audit=[]
        for name,store in store_paths.items():
            print(f'HVG pass: {name}')
            a=load_table(store,source_tables[name])
            a=a[selection(name,a.obs),common].copy(); a.X=integer_csr(a.X)
            if settings['exclude_prefixes']:
                symbols=a.var['gene_symbol'].astype(str).str.upper()
                allow=~symbols.str.startswith(tuple(x.upper() for x in settings['exclude_prefixes']))
            else:
                allow=np.ones(a.n_vars,bool)
            work=a[:,np.asarray(allow)].copy()
            n=min(settings['n_hvg'],work.n_vars)
            for span in settings['hvg_spans']:
                try:
                    sc.pp.highly_variable_genes(work,flavor='seurat_v3',n_top_genes=n,span=span,inplace=True)
                    break
                except ValueError as exc:
                    hvg_audit.append({'sample':name,'span':span,'error':str(exc)})
            else:
                raise RuntimeError(f'All seurat_v3 LOESS fits failed for {name}; no alternate method was substituted.')
            ranks=work.var['highly_variable_rank'].astype(float).copy()
            ranks.loc[~work.var['highly_variable'].to_numpy(bool)]=np.nan
            rankings[name]=ranks.reindex(common)
            del a,work; gc.collect()
        consensus=consensus_hvg(rankings,settings['n_hvg'])
        chosen=consensus.index[consensus.selected_hvg]
        dump_json({'method':'Per-sample seurat_v3; consensus sorts n_batches_hvg desc, median_rank asc, gene_id asc. '
                            'This is an explicit batch-balanced consensus, not a claim of identical scanpy batch_key implementation.',
                   'loess_retries':hvg_audit,'common_assayed_genes':len(common)},p/'hvg_method.json')
        consensus.to_csv(p/'features.csv',index=False)
        manifest={}; total_cells=0
        for name,store in store_paths.items():
            print(f'Staging selected HVGs: {name}')
            a=load_table(store,source_tables[name])
            a=a[selection(name,a.obs),chosen].copy()
            a.X=integer_csr(a.X)
            # A common all-gene QC threshold does not guarantee nonzero library size on HVGs.
            nonzero=np.asarray(a.X.sum(axis=1)).ravel()>0
            if not nonzero.all():
                pd.DataFrame({'cell_id':a.obs_names[~nonzero], 'reason':'zero_selected_HVG_counts'}).to_csv(
                    p/f'{name}_excluded_zero_HVG.csv',index=False)
                a=a[nonzero].copy()
            if a.n_obs<20:
                raise ValueError(f'{name}: fewer than 20 cells have nonzero selected-HVG counts.')
            a.obs['sample']=pd.Categorical([name]*a.n_obs)
            a.uns={}
            # Keep original-image coordinates in per-sample stores, not in a misleading pooled spatial graph.
            a.obsm.clear(); a.obsp.clear(); a.varm.clear(); a.varp.clear(); a.raw=None
            for key in list(a.layers):
                del a.layers[key]
            path=stage/f'{name}.h5ad'
            write_h5ad(a,path); manifest[name]=str(path)
            for row in summary:
                if row['sample']==name:
                    row.update(n_training_cells=a.n_obs,n_zero_hvg_excluded=int((~nonzero).sum()),
                               selected_hvg_umis=int(a.X.sum(dtype=np.int64)))
            total_cells+=a.n_obs
            del a; gc.collect()
        temporary=p/'scvi_counts_hvg.partial.h5ad'
        if temporary.exists():
            raise FileExistsError(temporary)
        concat_on_disk(manifest,str(temporary),axis=0,join='inner',merge='same',
                       label='sample',index_unique=None)
        check=ad.read_h5ad(temporary,backed='r')
        try:
            if check.n_obs!=total_cells or check.n_vars!=len(chosen) or not check.obs_names.is_unique:
                raise ValueError('On-disk concatenation did not preserve the expected cell/features set.')
            if not check.var_names.equals(pd.Index(chosen)):
                raise ValueError('HVG order changed during concat_on_disk.')
            if set(check.obs['sample'].astype(str))!=set(store_paths):
                raise ValueError('At least one sample is absent from the pooled training input.')
        finally:
            check.file.close()
        temporary.rename(p/'scvi_counts_hvg.h5ad')
        pd.DataFrame(summary).to_csv(p/'sample_qc_counts.csv',index=False)
        completed(marker,sig,required,n_cells=total_cells,n_hvg=len(chosen),n_samples=len(specs))
    return pd.DataFrame(summary)


def sparse_h5_ram_estimate(path):
    import h5py
    with h5py.File(path,'r') as f:
        x=f['X']
        if not isinstance(x,h5py.Group) or 'data' not in x:
            raise ValueError('Expected sparse CSR training X, not a dense matrix.')
        raw=sum(x[k].size*x[k].dtype.itemsize for k in ('data','indices','indptr'))
        return {'sparse_X_gib':raw/2**30,'conservative_working_gib':raw/2**30*4+4}


def train_scvi(cfg):
    """Compatibility single-device entry. DDP must use the explicit script launcher."""
    if cfg['execution']['scvi']['mode']!='single':raise ValueError('Use launch_integration for DDP.')
    from .compute.scvi_worker import execute
    execute(cfg,'train')
    return execute(cfg,'infer')


def leiden_umaps(cfg):
    import anndata as ad
    import scanpy as sc
    sc.settings.n_jobs=cfg.get('execution',{}).get('integration_threads',8)
    from scipy import sparse
    p=integration_dir(cfg); settings=cfg['clustering']
    resolutions=[round(i/10,1) for i in range(1,11)]
    sig=digest({'version':VERSION,'latent':file_stamp(p/'latent.npy'),
                'obs':file_stamp(p/'training_obs.parquet'),'settings':settings,'resolutions':resolutions})
    marker=p/'10_cluster_complete.json'; required=[p/'embedding_clusters.h5ad',p/'cluster_summary.csv',p/'colors.csv']
    if reusable(marker,sig,required):
        return pd.read_csv(p/'cluster_summary.csv')
    with stage_lock(p,'cluster'):
        obs=pd.read_parquet(p/'training_obs.parquet'); z=np.load(p/'latent.npy')
        if len(obs)!=len(z) or not obs.index.is_unique:
            raise ValueError('Latent rows do not match unique training observation rows.')
        a=ad.AnnData(X=sparse.csr_matrix((len(obs),0),dtype=np.float32),obs=safe_frame(obs))
        a.obsm['X_scVI']=z
        from .compute.clustering import graph_and_cluster
        backend_report=graph_and_cluster(a,cfg,resolutions)
        dump_json(backend_report,p/'clustering_backend.json')
        # Exactly one embedding: changing Leiden resolution changes labels, not UMAP coordinates.
        out=p/'plots'; out.mkdir(exist_ok=True)
        summaries=[]; color_rows=[]
        for res in resolutions:
            key=f'leiden_{res:.1f}'.replace('.','p')
            cats=natural_order(a.obs[key].astype(str).unique())
            a.obs[key]=pd.Categorical(a.obs[key].astype(str),categories=cats,ordered=True)
            colors=distinct_palette(len(cats),settings['allow_palette_extension'])
            palette=dict(zip(cats,colors)); a.uns[key+'_colors']=np.asarray(colors,dtype=str)
            scatter_categorical(a.obsm['X_umap'],a.obs[key],f'scVI integration | Leiden resolution {res:.1f}',
                                out/f'UMAP_{key}.png',colors=palette,max_points=settings['max_umap_points'],
                                labels=('UMAP 1','UMAP 2'),dpi=cfg['plots']['dpi'],
                                point_size=settings['point_size'])
            counts=pd.crosstab(a.obs[key],a.obs['sample'],dropna=False)
            counts.to_csv(p/f'{key}_cluster_by_sample_counts.csv')
            counts.div(counts.sum(axis=1),axis=0).to_csv(p/f'{key}_within_cluster_sample_fractions.csv')
            counts.div(counts.sum(axis=0),axis=1).to_csv(p/f'{key}_within_sample_cluster_fractions.csv')
            sizes=a.obs[key].value_counts(sort=False)
            sizes.rename('n_cells').to_csv(p/f'{key}_cluster_sizes.csv')
            summaries.append({'resolution':res,'key':key,'n_clusters':len(cats),'n_cells':a.n_obs,
                              'smallest_cluster':int(sizes.min()),'largest_cluster':int(sizes.max()),
                              'n_non_microviz_colors':max(0,len(cats)-41)})
            color_rows.extend({'key':key,'cluster':c,'hex':palette[c],
                               'source':'microViz brewerPlus' if i<41 else 'LAB-distance extension'}
                              for i,c in enumerate(cats))
            print(summaries[-1])
        a.uns['vhd_scvi_embedding']={'one_umap_for_all_resolutions':True,'batch_key':'sample',
                                     'latent_source':str(p/'latent.npy'),'run_name':cfg['scvi']['run_name']}
        write_h5ad(a,p/'embedding_clusters.h5ad')
        pd.DataFrame(summaries).to_csv(p/'cluster_summary.csv',index=False)
        pd.DataFrame(color_rows).to_csv(p/'colors.csv',index=False)
        completed(marker,sig,required,n_resolutions=10,n_cells=a.n_obs)
    return pd.DataFrame(summaries)


def diagnostics(cfg):
    import anndata as ad
    p=integration_dir(cfg); a=ad.read_h5ad(p/'embedding_clusters.h5ad')
    out=p/'diagnostics'; out.mkdir(exist_ok=True)
    xy=a.obsm['X_umap']
    scatter_categorical(xy,a.obs['sample'],'scVI UMAP colored by sample',out/'UMAP_by_sample.png',
                        max_points=cfg['clustering']['max_umap_points'],labels=('UMAP 1','UMAP 2'),dpi=cfg['plots']['dpi'])
    for column in ['total_counts','n_genes_by_counts','pct_counts_mt','cell_area_um2','S_score','G2M_score']:
        if column in a.obs:
            scatter_numeric(xy,a.obs[column],f'scVI UMAP: {column}',out/f'UMAP_by_{column}.png',
                            coordinate_labels=('UMAP 1','UMAP 2'),dpi=cfg['plots']['dpi'],
                            max_points=cfg['clustering']['max_umap_points'],
                            log1p=column in ('total_counts','n_genes_by_counts'))
    for column in cfg['scvi']['diagnostic_metadata_columns']:
        if column not in a.obs:
            raise KeyError(f'Requested diagnostic metadata absent: {column}')
        scatter_categorical(xy,a.obs[column],f'scVI UMAP: {column}',out/f'UMAP_by_{column}.png',
                            labels=('UMAP 1','UMAP 2'),dpi=cfg['plots']['dpi'],
                            max_points=cfg['clustering']['max_umap_points'])
        pd.crosstab(a.obs['sample'],a.obs[column]).to_csv(out/f'sample_by_{column}_confounding_audit.csv')
    rows=[]
    for key in [x for x in a.obs if x.startswith('leiden_')]:
        for column in ['total_counts','n_genes_by_counts','pct_counts_mt','cell_area_um2']:
            if column in a.obs:
                stats=a.obs.groupby(key,observed=True)[column].agg(['count','median','mean'])
                stats.to_csv(out/f'{key}_{column}_summary.csv')
    return out


def writeback_annotations(cfg,spec):
    """Append a SMALL zero-gene annotation table. Never rewrite huge bins or duplicate cell counts."""
    import anndata as ad
    import spatialdata as sd
    from scipy import sparse
    from .storage import parse_table
    p=integration_dir(cfg); sp=sample_paths(cfg,spec)
    if not (sp['report']/'storage_manifest.json').exists():
        raise RuntimeError('Writeback is restricted to stores built by this new workflow, not legacy originals.')
    a=ad.read_h5ad(p/'embedding_clusters.h5ad')
    selected=a.obs['sample'].astype(str).eq(spec['sample']).to_numpy()
    a=a[selected].copy()
    table=spec.get('_cell_table','cells');companion=table+'_scvi'
    obs,_=table_metadata(sp['store'],table)
    if not a.obs_names.isin(obs.index).all():
        raise ValueError('Integrated cell IDs are not a subset of the target sample cell table.')
    indexer=obs.index.get_indexer(a.obs_names)
    annotation=pd.DataFrame(index=obs.index.copy())
    annotation['sample']=spec['sample']
    annotation['included_in_scvi']=False
    annotation.loc[a.obs_names,'included_in_scvi']=True
    for key in [x for x in a.obs if x.startswith('leiden_')]:
        values=pd.Series('not_integrated',index=obs.index)
        values.loc[a.obs_names]=a.obs[key].astype(str).to_numpy()
        annotation[key]=pd.Categorical(values,categories=[*a.obs[key].cat.categories,'not_integrated'])
    b=ad.AnnData(X=sparse.csr_matrix((len(obs),0),dtype=np.float32),obs=annotation)
    for key in ('X_scVI','X_umap'):
        values=np.full((len(obs),a.obsm[key].shape[1]),np.nan,dtype=np.float32)
        values[indexer]=a.obsm[key]; b.obsm[key]=values
    for key,value in a.uns.items():
        if key.endswith('_colors'):
            # Explicit neutral category, only for excluded cells in writeback; not part of cluster palette.
            b.uns[key]=np.asarray([*list(value),'#BDBDBD'],dtype=str)
    b.uns['vhd_scvi_run']=cfg['scvi']['run_name']
    sig=digest({'embedding':file_stamp(p/'embedding_clusters.h5ad'),
                'store_signature':json.loads((sp['report']/'storage_manifest.json').read_text())['signature'],
                'sample':spec['sample']})
    b.uns['vhd_scvi_signature']=sig
    marker=sp['report']/('scvi_writeback.json' if table=='cells' else table+'_scvi_writeback.json')
    from .persistence import persist_changes,update_table_metadata
    mode=cfg['storage'].get('scvi_writeback','companion');ack=cfg['storage'].get('single_writer_ack',False)
    if mode=='primary_metadata':
        obs_update=b.obs.drop(columns=['sample','region','instance_id'],errors='ignore')
        embeds={key:pd.DataFrame(b.obsm[key],index=b.obs_names) for key in ('X_scVI','X_umap')}
        update_table_metadata(sp['store'],table,obs=obs_update,obsm=embeds,uns=dict(b.uns),policy=cfg['storage_policy'],staging_dir=sp['work'],execute=True,single_writer_ack=ack)
    elif mode=='companion':
        s=sd.read_zarr(sp['store'],selection=())
        from .reconstruction.storage import _read_shapes
        region=str(obs.region.astype(str).iloc[0]);s.shapes[region]=_read_shapes(sp['store'],region)
        s.tables[companion]=parse_table(b,str(obs.region.astype(str).iloc[0]),obs['instance_id'].astype(str))
        exists=(sp['store']/'tables'/companion).exists()
        if exists:
            previous=load_table(sp['store'],companion)
            if previous.uns.get('vhd_scvi_signature')==sig:return {'sample':spec['sample'],'status':'reused'}
        persist_changes(s,new_elements=[] if exists else [companion],replace_elements=[companion] if exists else [],policy=cfg['storage_policy'],staging_dir=sp['work'],execute=True,single_writer_ack=ack)
    else:raise ValueError('scvi_writeback: companion or primary_metadata.')
    annotation.to_parquet(sp['report']/('scvi_cell_annotations.parquet' if table=='cells' else table+'_scvi_cell_annotations.parquet'))
    report={'sample':spec['sample'],'n_integrated':a.n_obs,'n_all_cells':len(obs),'signature':sig,'counts_duplicated':False,'mode':mode}
    dump_json(report,marker)
    if table in ('proseg','bin2cell') and mode=='primary_metadata':
        receipt=sp['report']/f'method_{table}_master.json'
        record=json.loads(receipt.read_text())
        record['outputs']=[file_stamp(sp['store']/'tables'/table),file_stamp(sp['store']/'shapes'/(table+'_cell_boundaries'))]
        record['scvi_metadata_update']=file_stamp(marker);dump_json(record,receipt)
    return report
