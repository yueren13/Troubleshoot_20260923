"""Launch-time import checks in the selected interpreter, not the notebook kernel.

Checks run once per action before submitting sample jobs. No pip/uv installation,
no model fitting, no data access, and no interpreter symlink resolution.
Imports can initialize libraries and use the worker's configured scratch caches.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess


def executable_path(value, base):
    """Make an executable path absolute WITHOUT dereferencing symlinks.

    Data paths and write-allowlist checks must continue to use their existing
    canonicalization. A venv/bin/python is an invocation path, not just a file.
    Parent components are retained because symlink/.. has filesystem semantics.
    """
    value = str(value).strip()
    for a, b in re.findall(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)', value):
        if (a or b) not in os.environ:
            raise ValueError(f'Unset executable path variable: {a or b}')
    value = os.path.expanduser(os.path.expandvars(value))
    if not value or '://' in value or any(c in value for c in ('\x00', '\n', '\r', '*', '?')):
        raise ValueError('Executable must be an explicit nonempty filesystem path, not a URL, glob or command string.')
    p = Path(value)
    if not p.is_absolute():
        p = Path(base).absolute() / p
    return str(p)  # NEVER p.resolve() or realpath(p)


def action_imports(action, *, backend=None):
    modules = ['numpy', 'pandas', 'scipy', 'psutil', 'vhd.control.runner']
    if action != 'export_existing':
        modules += ['anndata', 'zarr']
    if action in {'assemble', 'assemble_bins', 'import_cells', 'import_bins', 'ingest_raw',
                  'postprocess_cells', 'refresh_cell_annotations', 'import_assets',
                  'transfer_assets', 'writeback', 'prepare','analysis_qc','replot'}:
        modules += ['spatialdata', 'geopandas', 'shapely', 'dask', 'h5py', 'pyarrow']
    if action in {'prepare','analysis_qc'}:modules += ['scanpy','pyarrow']
    if action=='prepare':modules += ['skmisc']
    if action in {'import_assets','transfer_assets'}:modules += ['defusedxml','tifffile','PIL']
    if action in {'bin2cell','assemble_methods','refresh_method_annotations'}:
        modules += ['geopandas','shapely','h5py','pyarrow','spatialdata']
    if action=='bin2cell':modules += ['bin2cell','scanpy','rasterio','packaging']
    if action in {'stardist','bin2cell_secondary'}:
        modules += ['tensorflow', 'stardist', 'csbdeep']
    if action in {'train', 'infer'}:
        modules += ['torch', 'scvi', 'h5py', 'pyarrow']
    if action == 'cluster':
        modules += ['scanpy']
        if backend in {'rapids', 'rapids_dask'}:
            modules += ['cupy', 'rapids_singlecell']
        if backend == 'rapids_dask':
            modules += ['dask_cuda']
    return list(dict.fromkeys(modules))


_PROBE = r'''
import faulthandler, importlib, json, os, sys, time
spec = json.loads(sys.argv[1])
faulthandler.enable()
interval = spec.get('stack_dump_interval_seconds', 60)
faulthandler.dump_traceback_later(interval, repeat=True, exit=False)
record = {'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix}
print('VHD_RUNTIME '+json.dumps(record), flush=True)
timings=[]
try:
    for name in spec['modules']:
        start=time.monotonic()
        print('BEGIN_IMPORT '+name, flush=True)
        importlib.import_module(name)
        elapsed=time.monotonic()-start
        timings.append({'module':name,'seconds':elapsed})
        print('END_IMPORT '+name+' '+format(elapsed,'.2f')+' seconds', flush=True)
    if spec.get('gpu_enumeration'):
        import tensorflow as tf
        print('BEGIN_GPU_ENUMERATION', flush=True)
        devices=tf.config.list_physical_devices('GPU')
        print('END_GPU_ENUMERATION '+json.dumps([str(d) for d in devices]), flush=True)
        if spec.get('require_gpu') and not devices:
            raise RuntimeError('TensorFlow sees no GPU in the selected worker environment. No CPU fallback was requested.')
    print('VHD_IMPORT_TIMINGS '+json.dumps(timings), flush=True)
    print('VHD_IMPORTS_OK', flush=True)
finally:
    faulthandler.cancel_dump_traceback_later()
'''


def preflight_python(executable, modules, *, env=None, cwd=None, timeout=None,
                     log_path=None, require_gpu=False, stack_dump_interval_seconds=60,
                     heartbeat_seconds=30):
    """Timed and logged startup; no success cache and no scientific timeout.

    A None deadline is 900 seconds for StarDist and 300 for other import lists.
    Explicit caller-supplied deadlines remain respected. GPU enumeration here
    covers only the device visible to this common preflight. Native workers
    retain their own GPU checks and assigned device environment.
    """
    from .startup_support import run_probe, atomic_json, DEFAULTS, RUNTIME_PATCH_ID
    import uuid
    exe = str(executable)
    names = list(dict.fromkeys(modules))
    stardist = 'stardist' in names and 'tensorflow' in names
    if timeout is None:
        timeout = DEFAULTS['stardist_import_timeout_seconds' if stardist else 'python_import_timeout_seconds']
    if not Path(exe).is_file() or not os.access(exe, os.X_OK):
        raise FileNotFoundError(f'Configured Python is not an executable file: {exe}')
    if stardist:
        names = list(dict.fromkeys(['matplotlib', 'matplotlib.font_manager'] + names + ['stardist.models', 'csbdeep.utils']))
    if log_path is None:
        parent = Path((env or os.environ).get('TMPDIR', os.getcwd()))/'vhd_startup_probes'/uuid.uuid4().hex
        log_path = parent/'imports.log'
    log_path = Path(log_path)
    spec = {'modules':names,'gpu_enumeration':stardist,'require_gpu':bool(require_gpu),
            'stack_dump_interval_seconds':stack_dump_interval_seconds}
    cmd = [exe, '-B', '-u', '-c', _PROBE, json.dumps(spec)]
    report = run_probe(cmd, env=env, cwd=cwd, timeout=timeout,
                       log_path=log_path, heartbeat_seconds=heartbeat_seconds)
    try:
        output = log_path.read_text(errors='replace')
        records = [line[len('VHD_RUNTIME '):] for line in output.splitlines() if line.startswith('VHD_RUNTIME ')]
        if len(records) != 1 or 'VHD_IMPORTS_OK' not in output.splitlines():
            raise RuntimeError(f'Unexpected Python preflight output for {exe}. Full log: {log_path}')
        record = json.loads(records[0])
        venv_root = Path(exe).parent.parent
        if (venv_root / 'pyvenv.cfg').is_file():
            if not Path(record['prefix']).exists() or not os.path.samefile(record['prefix'], venv_root):
                raise RuntimeError(f'Python did not enter the requested virtual environment: {record}. '
                                   'Check PYTHONHOME and executable configuration. No sample jobs were submitted.')
        report.update(interpreter_validation='passed', runtime=record, modules=names)
    except Exception as exc:
        report.update(status='failed', interpreter_validation='failed', error=str(exc))
        atomic_json(log_path.with_suffix('.json'),report)
        raise
    atomic_json(log_path.with_suffix('.json'),report)
    print(json.dumps({'worker_import_preflight': 'passed', 'runtime_patch_id':RUNTIME_PATCH_ID,
                      **record, 'modules':names, 'log':str(log_path),
                      'scientific_execution_tested':False}, indent=2), flush=True)
    return record
