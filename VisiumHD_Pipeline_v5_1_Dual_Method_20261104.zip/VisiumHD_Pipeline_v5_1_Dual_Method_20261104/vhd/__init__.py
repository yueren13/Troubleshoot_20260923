"""Visium HD Project Center; existing scientific cache versions are preserved."""
__version__ = "0.5.1rc1"
