"""Small-file prerequisite checks before launching an entire batch."""
from pathlib import Path
from .manifest import row_config,sample_layout


def check_action_inputs(project,rows,action):
    errors=[]
    for row in rows:
        cfg,spec=row_config(project,row);p=sample_layout(project,row)
        source_keys={'ingest_raw':['spaceranger_outs','segmentation_image'],
          'import_bins':['bin_input','segmentation_image'],
          'import_cells':['cell_input','cell_boundaries','segmentation_image']} .get(action,[])
        for key in source_keys:
            val=row.get(key)
            if val and not val.startswith('s3://') and not Path(val).exists():errors.append(f"{row['sample_key']}: missing {key}: {val}")
        if action in ('assemble','assemble_bins','assemble_methods','refresh_method_annotations','import_assets','transfer_assets','refresh_cell_annotations'):
            if cfg['storage'].get('single_writer_ack') is not True:errors.append(f"{row['sample_key']}: set storage.single_writer_ack only after reviewing the write destination and other processes.")
        if action in ('assemble','assemble_bins'):
            bins=(p['work']/'bins_raw.h5ad').is_file() # report actual pipeline paths below
            from ..core import sample_paths
            pp=sample_paths(cfg,spec)
            bins=pp['bins'].is_file() and pp['bin_obs'].is_file()
            cells=pp['cells'].is_file()
            if not bins and not cells:errors.append(f"{row['sample_key']}: no prepared bins/cells in {p['work']}; execute import for this workspace before assembly.")
            if action=='assemble' and row['goal']=='cell_annotated' and not cells:errors.append(f"{row['sample_key']}: cells are required; finish import_cells/postprocess_cells first.")
            if (bins or row['cell_coordinate_mode']!='unregistered') and not spec['coordinates_reviewed']:errors.append(f"{row['sample_key']}: coordinates_reviewed is false; inspect the overlay before assembly.")
            partial=p['store'].with_name(p['store'].name+'.partial')
            if partial.exists():errors.append(f"{row['sample_key']}: incomplete store {partial}; inspect, do not delete automatically.")
        if action=='transfer_assets':
            try:
                from ..annotations.workflow import asset_specification
                if not (p['work']/'bins_qc_obs.parquet').is_file():raise FileNotFoundError('Prepare the bin table and QC before image/category transfer.')
                asset_specification(cfg,spec)
            except Exception as e:errors.append(f"{row['sample_key']}: {e}")
        if action in ('stardist','bin2cell','bin2cell_secondary'):
            from ..master import current_annotations
            try:current_annotations(cfg,spec)
            except Exception as e:errors.append(f"{row['sample_key']}: {e}")
    if errors:raise RuntimeError('Preflight stopped before starting workers:\n'+'\n'.join(dict.fromkeys(errors)))
