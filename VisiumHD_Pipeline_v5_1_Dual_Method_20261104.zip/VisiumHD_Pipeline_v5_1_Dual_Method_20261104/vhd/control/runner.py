"""Stage dispatch, independent of notebook cell state and of biological tool environments."""
from __future__ import annotations
import copy
import json
import shutil
import time
from pathlib import Path
from ..core import dump_json,file_stamp,digest,sample_paths,environment_report
from .manifest import row_config,sample_layout,check_policy
from .storage import localize,free_space_gate,publish_tree,join_uri


def prepare_context(project,row,action):
    check_policy(project)
    cfg,spec=row_config(project,row); p=sample_layout(project,row)
    for key in ('root','work','report','objects','plots','data'): p[key].mkdir(parents=True,exist_ok=True)
    free_space_gate(p['root'],reserve_gib=cfg['storage_policy'].get('min_free_tmp_gib',20))
    # Never stage raw inputs for a standalone cell import/export merely because paths exist in the row.
    needed={'ingest_raw':['spaceranger_outs','segmentation_image'],
            'import_bins':['bin_input','segmentation_image','spaceranger_outs'],
            'import_cells':['cell_input','cell_boundaries','segmentation_image','spaceranger_outs'],
            'export_existing':['cell_input'],
            'measure_he':['spaceranger_outs'],'bin_qc':[],'reuse_bin_qc':[],'stardist':[],'proseg':[],
            'postprocess_cells':[],'assemble':[]}.get(action,[])
    inputs={}
    for key in needed:
        if row.get(key):
            from .paths_v3 import stage_mounted,storage_profile
            value=localize(row[key],p['scratch'],cfg['storage_policy'])
            if row.get('cache_dir') and storage_profile(value,cfg['storage_policy'])['backend']=='mounted_s3':
                value=stage_mounted(value,row['cache_dir'],cfg['storage_policy'])
            inputs[key]=value
    for source,target in [('spaceranger_outs','outs'),('segmentation_image','image')]:
        if source in inputs: spec[target]=inputs[source]
    spec['_inputs']=inputs
    # Downstream engines use resolved paths recorded in geometry.json; no raw restaging.
    return cfg,spec


def export_existing(cfg,spec):
    from ..adapters.anndata_input import metadata
    row=spec['_row']; p=sample_paths(cfg,spec); source=Path(spec['_inputs']['cell_input'])
    destination=p['objects']/('annotated_input'+('.h5ad' if source.is_file() else '.zarr'))
    marker=p['report']/'export_existing.json'
    sig=digest({'source':file_stamp(source),'kind':row['cell_input_kind'],'table':row['cell_table']})
    if destination.exists():
        if not marker.exists() or json.loads(marker.read_text())['signature']!=sig:
            raise FileExistsError('Existing export does not match source. Use a new run_id.')
        return json.loads(marker.read_text())
    obs,var=metadata(source,row['cell_input_kind'],row['cell_table'])
    # Byte-for-byte source copy, retaining corrected X, raw layers, embeddings, graphs and all uns.
    total=sum(f.stat().st_size for f in source.rglob('*') if f.is_file()) if source.is_dir() else source.stat().st_size
    free_space_gate(p['root'],total,cfg['storage_policy']['min_free_tmp_gib'])
    if source.is_dir(): shutil.copytree(source,destination)
    else: shutil.copy2(source,destination)
    obs.to_parquet(p['report']/'exported_cell_obs.parquet'); var.to_csv(p['report']/'exported_cell_var.csv')
    report={'signature':sig,'n_cells':len(obs),'n_genes':len(var),'source':row['cell_input'],
            'expression_normalized_or_reclustered':False,'full_source_copy':str(destination),
            'source_format_preserved':True}
    dump_json(report,marker); return report


def run_action(project,sample_key,action):
    matches=[r for r in project['rows'] if r['sample_key']==sample_key]
    if len(matches)!=1: raise KeyError(sample_key)
    row=matches[0]
    if action not in row['_plan'] and action!='replot': return {'sample':sample_key,'action':action,'status':'not_applicable'}
    if action=='publish': return publish_sample(project,row,execute=True)
    if action not in ('replot','export_existing'):
        from ..bin_master import check_project_destinations
        check_project_destinations(project,row)
    cfg,spec=prepare_context(project,row,action)
    p=sample_layout(project,row); status=p['report']/f'status_{action}.json'
    start=time.time()
    dump_json({'sample':sample_key,'action':action,'status':'running','started_unix':start},status)
    try:
        if action=='ingest_raw':
            from ..io import ingest
            result=ingest(cfg,spec)
        elif action=='import_bins':
            from ..adapters.bins import import_bins
            result=import_bins(cfg,spec)
        elif action=='reuse_bin_qc':
            from ..adapters.bins import reuse_qc
            result=reuse_qc(cfg,spec)
        elif action=='measure_he':
            from ..he.workflow import measure
            result=measure(cfg,spec)
        elif action=='bin_qc':
            if cfg.get('he_score',{}).get('enabled'):
                from ..he.workflow import classify_stage
                result=classify_stage(cfg,spec)
            else:
                from ..qc import build_bin_qc
                result=build_bin_qc(cfg,spec)
        elif action=='assemble_bins':
            from ..bin_master import ensure_bin_master
            result=ensure_bin_master(cfg,spec)
        elif action=='import_assets':
            from ..annotations.workflow import import_assets
            result=import_assets(cfg,spec)
        elif action=='transfer_assets':
            from ..annotations.workflow import transfer_assets
            result=transfer_assets(cfg,spec)
        elif action=='refresh_cell_annotations':
            from ..master import refresh_cell_annotations
            result=refresh_cell_annotations(cfg,spec)
        elif action=='stardist':
            from ..segmentation import stardist_prior
            result=stardist_prior(cfg,spec)
        elif action=='proseg':
            from ..segmentation import run_proseg
            result=run_proseg(cfg,spec)
        elif action=='postprocess_cells':
            from ..cells import build_cells
            # Routing keys must not invalidate existing Proseg scientific caches.
            cfg=copy.deepcopy(cfg)
            for k in ('methods','analysis_method'):cfg['cells'].pop(k,None)
            result=build_cells(cfg,spec)
        elif action=='bin2cell_secondary':
            from ..reconstruction.bin2cell_adapter import run_secondary
            result=run_secondary(cfg,spec)
        elif action=='bin2cell':
            from ..reconstruction.bin2cell_adapter import run_bin2cell
            result=run_bin2cell(cfg,spec)
        elif action=='assemble_methods':
            from ..reconstruction.storage import assemble_methods
            result=assemble_methods(cfg,spec)
        elif action=='refresh_method_annotations':
            from ..reconstruction.storage import refresh_method_annotations
            result=refresh_method_annotations(cfg,spec)
        elif action=='import_cells':
            from ..adapters.cells import import_cells
            result=import_cells(cfg,spec)
        elif action=='assemble':
            from ..master import assemble_master
            result=assemble_master(cfg,spec)
        elif action=='replot':
            from ..plots import replot_sample
            result=replot_sample(cfg,spec)
        elif action=='export_existing': result=export_existing(cfg,spec)
        else: raise ValueError(action)
        # The CSV source-stage is not edited. Verified progress is a separate auditable product.
        dump_json({'sample':sample_key,'entry_stage':row['stage'],'action':action,'status':'complete',
                   'elapsed_seconds':time.time()-start,'environment':environment_report()},status)
        return {'sample':sample_key,'action':action,'status':'complete'}
    except Exception as exc:
        dump_json({'sample':sample_key,'action':action,'status':'failed','error':repr(exc),
                   'elapsed_seconds':time.time()-start},status)
        raise


def copy_reports(p):
    """Only plot files go to plot output; metadata/tables/logs go to data output."""
    images={'.png','.pdf','.svg','.jpg','.jpeg','.webp','.tif','.tiff'}
    for f in p['report'].rglob('*'):
        if not f.is_file(): continue
        root=p['plots'] if f.suffix.lower() in images else p['data']
        dest=root/f.relative_to(p['report']); dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(f,dest)


def publish_sample(project,row,execute=False):
    check_policy(project)
    p=sample_layout(project,row)
    if row['goal']!='export_only' and not (p['report']/'storage_manifest.json').exists():
        raise RuntimeError(f"{row['sample_key']}: assemble and validate the product before publishing.")
    if row['goal']=='export_only' and not (p['report']/'export_existing.json').exists():
        raise RuntimeError('Export-only artifact has not been prepared.')
    for k in ('plots','data','objects'): p[k].mkdir(parents=True,exist_ok=True)
    copy_reports(p)
    result=[]
    for category,col in [('objects','output_object_dir'),('plots','output_plot_dir'),('data','output_data_dir')]:
        target=join_uri(row[col],row['dataset_id'],row['sample_id'],project['settings']['run_id'],category)
        source=p[category]
        if category=='objects' and row['goal']!='export_only':source=p['store'];target=join_uri(target,row['sample_id']+'.zarr')
        result.append(publish_tree(source,target,project['settings']['storage_policy'],execute=execute))
    if execute:
        dump_json({'sample':row['sample_key'],'publications':result},p['root']/'PUBLICATION_RECEIPT.json')
    return result


def integration_config(project,group):
    rows=[r for r in project['rows'] if r['integration_group']==group]
    if len(rows)<2: raise ValueError('An integration group requires at least two explicit sample rows.')
    check_policy(project)
    cfg=copy.deepcopy(project['settings'])
    settings=cfg['integration']
    work=Path(settings.get('work_dir') or settings['tmp_dir'])/'vhd_integration'/group/cfg['run_id']
    analysis_id=settings.get('analysis_id')
    if analysis_id:
        import re
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',analysis_id):raise ValueError('Invalid integration.analysis_id')
        work=work/analysis_id
    scratch=Path(settings['tmp_dir'])/'vhd_integration_scratch'/group/cfg['run_id']
    if analysis_id:scratch=scratch/analysis_id
    cfg['_integration_scratch']=str(scratch)
    cfg['_integration_work']=str(work); cfg['output_root']=str(work); cfg['work_root']=str(work)
    cfg['scvi']['run_name']=group+'__'+cfg['run_id']
    cfg['samples']=[row_config(project,r)[1] for r in rows]
    method_tables={s.get('_cell_table','cells') for s in cfg['samples']}
    if len(method_tables)!=1:raise ValueError('An integration group must select the same cell reconstruction for every sample; do not mix methods.')
    cfg['_cell_method']=next(iter(method_tables))
    if cfg['_cell_method']!='cells':
        cfg['_integration_work']=str(Path(cfg['_integration_work'])/cfg['_cell_method'])
        cfg['_integration_scratch']=str(Path(cfg['_integration_scratch'])/cfg['_cell_method'])
        cfg['scvi']['run_name']+='__'+cfg['_cell_method']
    cfg['_integration_group']=group
    return cfg


def publish_integration(project,group,execute=False):
    from ..integration import integration_dir
    cfg=integration_config(project,group); work=integration_dir(cfg)
    if not (work/'10_cluster_complete.json').exists(): raise RuntimeError('Finish clustering before publishing integration.')
    roots={k:work/('publish_'+k) for k in ('objects','plots','data')}
    for p in roots.values(): p.mkdir(exist_ok=True)
    for f in work.rglob('*'):
        rel=f.relative_to(work)
        if not f.is_file() or any(part.startswith('publish_') for part in rel.parts) or rel.parts[0]=='staged_hvg': continue
        if f.name.startswith('.') or f.name.endswith('.lock'): continue
        if f.suffix in ('.png','.pdf','.svg'): cat='plots'
        elif f.suffix in ('.h5ad','.npy','.npz','.pt','.ckpt') or 'model' in rel.parts: cat='objects'
        else: cat='data'
        dest=roots[cat]/rel; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,dest)
    output=[]
    for cat in roots:
        root=cfg['integration'][{'objects':'output_object_dir','plots':'output_plot_dir','data':'output_data_dir'}[cat]]
        target=join_uri(root,'integration',group,cfg['run_id'],*([cfg['integration']['analysis_id']] if cfg['integration'].get('analysis_id') else []),cat)
        output.append(publish_tree(roots[cat],target,cfg['storage_policy'],execute=execute))
    return output
