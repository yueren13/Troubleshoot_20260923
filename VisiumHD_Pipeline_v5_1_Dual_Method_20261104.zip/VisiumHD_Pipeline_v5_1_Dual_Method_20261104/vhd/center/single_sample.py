"""Explicit independent-sample analysis. Never batch-corrects or writes master counts.

CPU Scanpy PCA/neighbor/Leiden route, not a singleton scVI integration workaround.
The group scVI/RAPIDS route remains separate in the existing scientific engine.
"""
from __future__ import annotations
from pathlib import Path
import argparse, json


def run_individual(project,sample_key,settings):
    import numpy as np
    import pandas as pd
    import anndata as ad
    import scanpy as sc
    from scipy import sparse
    from ..control.manifest import row_config,sample_layout
    from ..io import load_table
    from ..analysis_qc import profile,cell_metrics,gene_minimum
    from ..core import file_stamp,digest,dump_json,write_h5ad,integer_csr,reusable,completed,stage_lock
    from ..palette import natural_order,distinct_palette
    from ..plots import scatter_categorical,scatter_numeric,standard_qc_plots
    row=next(r for r in project['rows'] if r['sample_key']==sample_key)
    cfg,spec=row_config(project,row);p=sample_layout(project,row)
    ident=str(settings.get('analysis_id','analysis01'))
    import re
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',ident):raise ValueError('Safe nonempty analysis_id required.')
    table=spec.get('_cell_table','cells')
    folder=p['report']/'individual_analysis'/ident if table=='cells' else p['report']/'individual_analysis'/table/ident
    folder.mkdir(parents=True,exist_ok=True)
    source=p['store']/'tables'/table
    rules=profile(cfg,spec)
    if not rules.get('enabled'):raise ValueError('Enable and review analysis_qc for independent analysis.')
    sig=digest({'method':'independent_scanpy_pca_v1','source':file_stamp(source),'rules':rules,'settings':settings,
                'clustering':cfg['clustering'],'gene_min_cells':gene_minimum(cfg)})
    marker=folder/'complete.json';required=[folder/'embedding_clusters.h5ad',folder/'summary.json',folder/'cluster_sizes.csv']
    current=(p['report']/'individual_analysis/current.json') if table=='cells' else (p['report']/'individual_analysis'/table/'current.json')
    if reusable(marker,sig,required):
        dump_json({'analysis_id':ident,'folder':str(folder),'signature':sig,'master_modified':False,'source_table':table},current)
        return json.loads((folder/'summary.json').read_text())
    with stage_lock(folder,'individual_analysis'):
        a=load_table(p['store'],table);a.X=integer_csr(a.X)
        metrics,qc_summary=cell_metrics(a.X,a.obs,a.var,rules)
        metrics.to_parquet(folder/'analysis_cell_qc.parquet')
        cell_keep=metrics.analysis_qc_pass.to_numpy(bool)
        if int(cell_keep.sum())<4:raise ValueError('Fewer than four cells pass analysis QC; inspect the saved QC table.')
        genes=np.asarray((a.X[cell_keep]>0).sum(axis=0)).ravel()>=gene_minimum(cfg)
        if genes.sum()<3:raise ValueError('Fewer than three genes pass the retained-cell detection criterion.')
        work=a[cell_keep,genes].copy()
        for column in metrics:work.obs[column]=metrics.loc[work.obs_names,column]
        sc.settings.n_jobs=int(cfg['execution'].get('integration_threads',8))
        target=float(settings.get('target_sum',10000))
        if target<=0 or not np.isfinite(target):raise ValueError('Normalization target must be finite and positive.')
        sc.pp.normalize_total(work,target_sum=target);sc.pp.log1p(work)
        hvgs=min(int(settings.get('n_hvg',3000)),work.n_vars)
        if hvgs<3:raise ValueError('At least three highly variable genes requested.')
        if hvgs<work.n_vars:
            sc.pp.highly_variable_genes(work,flavor='seurat',n_top_genes=hvgs)
            work=work[:,work.var.highly_variable].copy()
        pcs=min(int(settings.get('n_pcs',30)),work.n_vars-1,work.n_obs-1)
        if pcs<2:raise ValueError('Insufficient dimensionality for PCA.')
        seed=int(settings.get('seed',42));sc.pp.pca(work,n_comps=pcs,svd_solver='arpack',random_state=seed)
        sc.pp.neighbors(work,n_neighbors=min(int(cfg['clustering']['n_neighbors']),work.n_obs-1),use_rep='X_pca',random_state=seed)
        sc.tl.umap(work,min_dist=float(cfg['clustering']['umap_min_dist']),random_state=seed)
        sizes=[];summary=[]
        for i in range(1,11):
            res=i/10;name=f'leiden_0p{i}' if i<10 else 'leiden_1p0'
            sc.tl.leiden(work,resolution=res,key_added=name,flavor='igraph',directed=False,n_iterations=2,random_state=seed)
            cats=natural_order(work.obs[name].astype(str).unique());work.obs[name]=pd.Categorical(work.obs[name].astype(str),categories=cats)
            palette=dict(zip(cats,distinct_palette(len(cats),True)));work.uns[name+'_colors']=list(palette.values())
            scatter_categorical(work.obsm['X_umap'],work.obs[name],f'{row["sample_id"]} independent PCA | Leiden {res:.1f}',
                folder/f'UMAP_{name}.png',colors=palette,labels=('UMAP 1','UMAP 2'),max_points=cfg['clustering'].get('max_umap_points'),dpi=cfg['plots']['dpi'])
            counts=work.obs[name].value_counts(sort=False)
            sizes.extend({'resolution':res,'cluster':str(c),'n_cells':int(n)} for c,n in counts.items())
            summary.append({'resolution':res,'n_clusters':len(cats),'n_cells':work.n_obs})
        for metric in ('analysis_total_counts','analysis_n_genes','analysis_pct_counts_mt'):
            scatter_numeric(work.obsm['X_umap'],work.obs[metric],metric,folder/f'UMAP_{metric}.png',
                coordinate_labels=('UMAP 1','UMAP 2'),dpi=cfg['plots']['dpi'],log1p=False)
        # Deliberately zero genes: output is a companion embedding/metadata object, not normalized master RNA.
        companion=ad.AnnData(X=sparse.csr_matrix((work.n_obs,0),dtype=np.float32),obs=work.obs.copy())
        for k in ('X_umap','X_pca','spatial'):
            if k in work.obsm:companion.obsm[k]=work.obsm[k].copy()
        for k in work.obsp:companion.obsp[k]=work.obsp[k].copy()
        for k,v in work.uns.items():
            if k.endswith('_colors'):companion.uns[k]=v
        companion.uns['vhd_analysis']={'method':'independent_scanpy_pca','batch_correction':False,'source_sample':sample_key,'source_table':table,
            'normalization_target_sum':target,'hvg_method':'seurat_on_log1p','n_pcs':pcs,'seed':seed,'one_umap_for_all_resolutions':True}
        write_h5ad(companion,required[0]);pd.DataFrame(sizes).to_csv(required[2],index=False)
        record={'method':'independent_scanpy_pca','master_modified':False,'source_table':table,'batch_correction':False,'sample':sample_key,
                'signature':sig,'qc':qc_summary,'qc_profile':rules,'n_genes_after_detection':int(genes.sum()),
                'n_hvg':work.n_vars,'n_pcs':pcs,'resolutions':summary,'normalization':'total-count target then natural log1p, in memory only',
                'embedding_output':str(required[0])}
        dump_json(record,required[1]);completed(marker,sig,required)
        dump_json({'analysis_id':ident,'folder':str(folder),'signature':sig,'master_modified':False,'source_table':table},current)
    return record


def launch_individual(project,sample_key,settings,*,execute=False):
    from ..control.manifest import sample_layout, row_config
    from ..compute.launch import worker_env,run_logged,PACKAGE_ROOT
    from ..compute.runtime_checks import preflight_python
    from ..core import dump_json
    row=next(r for r in project['rows'] if r['sample_key']==sample_key);p=sample_layout(project,row)
    table=row_config(project,row)[1].get('_cell_table','cells')
    ex=project['settings']['execution'];config=p['report']/('individual_analysis_job.json' if table=='cells' else table+'_individual_analysis_job.json')
    cmd=[ex['python_spatial'],'-m','vhd.center.single_sample','--config',str(config)]
    if not execute:return {'command':cmd,'sample':sample_key,'analysis':settings,'master_modified':False,'source_table':table}
    env=worker_env(p['scratch']/'runtime/individual_analysis',[],ex['integration_threads'])
    preflight_python(ex['python_spatial'],['scanpy','anndata','igraph','numpy','pandas','pyarrow'],env=env,cwd=PACKAGE_ROOT)
    dump_json({'project':project,'sample':sample_key,'settings':settings},config)
    return run_logged(cmd,env,p['report']/('worker_independent_clustering.log' if table=='cells' else table+'_worker_independent_clustering.log'))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--config',required=True);args=ap.parse_args()
    job=json.loads(Path(args.config).read_text());print(run_individual(job['project'],job['sample'],job['settings']))
