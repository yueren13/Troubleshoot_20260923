"""Self-contained HTML stage summaries; no counts, native TIFFs, or Zarr arrays read.

Only known report patterns are indexed. Small PNG/JPEG report images are thumbnailed;
large native microscopy images are excluded. An inventory never implies approval.
"""
from pathlib import Path
import base64, html, io, json, os
from .state import atomic_write, fingerprint, stamp

CSS='''body{margin:0;background:#f3f5f8;color:#20324a;font:16px/1.55 system-ui,sans-serif}main{max-width:1250px;margin:auto;padding:32px}header{background:#15304c;color:white;padding:30px;border-radius:14px;margin-bottom:22px}header p{color:#dce5ef}h1{margin:0;font-size:30px}h2{font-size:23px;margin-top:28px}h3{font-size:18px}a{color:#146b96}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:16px}.card,details{background:white;border:1px solid #dce3eb;border-radius:10px;padding:18px;margin-bottom:14px}.muted{color:#61758c;font-size:14px}.badge{display:inline-block;border-radius:18px;background:#e6eef6;padding:4px 12px;font-size:13px;margin:3px}.warning{background:#fff1d9;border-left:5px solid #c78b27;padding:14px}table{width:100%;border-collapse:collapse;background:white}td,th{padding:10px;text-align:left;border-bottom:1px solid #e5eaf0;vertical-align:top}img{max-width:100%;height:auto}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px;max-height:480px;overflow:auto}summary{cursor:pointer;font-weight:600}code{overflow-wrap:anywhere}.path{font-size:12px;overflow-wrap:anywhere}button{padding:10px}'''
GROUPS={
 'bin_qc':('Bin-level QC', ['*fixed.png','bins*.png','bin_qc_report.json','grid_coordinate_diagnostic.json',
                          'bin_qc_cutoff_review/*/*.png','bin_qc_cutoff_review/*/*/*.png','bin_qc_cutoff_review/*/review_summary.json']),
 'assets':('Annotations and staining',['asset_*.png','asset_*.json','assets_preview.json','assets_transfer.json',
                          'assets_on_he_*/all_sources_on_HE.png','assets_on_he_*/all_categories_on_HE.png','assets_on_he_*/signal_*png',
                          'assets_on_he_*/category_*.png','assets_on_he_*/summary.json',
                          'assets_on_he_*/*.png','assets_on_he_*/*/*.png',
                          'annotation_geometry_review_*/review_summary.json','annotation_geometry_review_*/source_*/*.png']),
 'segmentation':('Nuclear prior and segmentation',['stardist*.png','prior_metadata.json','proseg_exit.json','proseg_command.txt',
                          'cells_boundaries*.png','worker_stardist.resources.json','worker_proseg.resources.json','worker_bin2cell.resources.json','bin2cell/secondary_summary.json','bin2cell/run_summary.json','bin2cell/cells_boundaries*.png']),
 'cells':('Cell-level QC',['cells*.png','cell_qc_summary.csv','cell_import_report.json','cell_annotation_refresh.json',
                          'storage_manifest.json','master_sources.json','cellplots/*.png','bin2cell/cells*.png','bin2cell/cell_qc_summary.csv','cell_methods_manifest.json','reconstruction_comparison.csv','reconstruction_comparison.json','method_*_annotation_refresh.json']),
 'clustering':('Clustering and analysis',['individual_analysis/*/*.png','individual_analysis/*/summary.json',
                          'individual_analysis/*/cluster_sizes.csv','individual_analysis/current.json','individual_analysis/*/*/*.png','individual_analysis/*/*/summary.json','individual_analysis/*/*/cluster_sizes.csv','individual_analysis/*/current.json']),
}
NOTES={
 'bin_qc':'H&E signal is fixed-scale evidence, not a probability. Count-axis log spacing is a display choice. Review actual bin/H&E alignment and classification before segmentation.',
 'assets':'Geometry proposals (XML coordinates), category-discovery inventories, H&E overlay galleries, and transfer outputs are DIFFERENT artifacts. Missing bins_annotated_obs.parquet/assets_transfer.json before transfer is expected. Overlapping categories remain independent. Selecting a report does not approve alignment or usage. Native signal means are not automatically binary-positive fractions.',
 'segmentation':'Nuclear priors and inferred cells are model-derived. Inspect whole tissue and local regions. A successful process does not establish segmentation accuracy.',
 'cells':'Technical QC does not define cell type. Assess counts, genes, mitochondrial fractions, area and boundaries. Annotations do not replace raw RNA counts.',
 'clustering':'UMAP is an embedding, not tissue coordinates. All ten resolutions use the same embedding; cluster labels vary. Independent samples are not integrated. Clusters are not validated cell types.'}


def list_reports(project,row):
    from ..control.manifest import sample_layout
    root=sample_layout(project,row)['report'];items=[];seen=set()
    if not root.is_dir():return items
    for stage,(_,patterns) in GROUPS.items():
        for pattern in patterns:
            for p in sorted(root.glob(pattern)):
                if p.is_file() and p.resolve().is_relative_to(root.resolve()) and not p.is_symlink():
                    ident=(stage,str(p))
                    if ident in seen:continue
                    seen.add(ident);items.append({'stage':stage,**stamp(p)})
                    if len(items)>5000:raise RuntimeError('Report inventory exceeded 5,000 entries for one sample; archive historical reports explicitly.')
    work=sample_layout(project,row)['work']
    for stage,names in {'bin_qc':['geometry.json','he_fixed/measurement.json'],
                        'segmentation':['prior_metadata.json'], 'cells':['cell_geometry.json']}.items():
        for name in names:
            p=work/name
            if p.is_file() and not p.is_symlink() and p.stat().st_size<2*1024**2:
                items.append({'stage':stage,**stamp(p)})
    return items


def _thumbnail(p,max_side=1300):
    from PIL import Image
    p=Path(p)
    if p.stat().st_size>80*1024**2:return None
    with Image.open(p) as im:
        if im.width*im.height>80_000_000:return None
        im.thumbnail((max_side,max_side));im=im.convert('RGB');b=io.BytesIO();im.save(b,format='JPEG',quality=83)
    return 'data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()


def document(title,body,subtitle='Read-only snapshot • decisions are saved through the live Project Center'):
    return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(title)+'</title><style>'+CSS+'</style></head><body><main><header><h1>'+html.escape(title)+'</h1><p>'+html.escape(subtitle)+'</p></header>'+body+'</main></body></html>'


def stage_html(sample,stage,artifacts,statuses=None):
    title=GROUPS[stage][0];parts=['<div class="warning">'+html.escape(NOTES[stage])+'</div>']
    if statuses:parts.append('<details><summary>Recorded progress and saved reviews</summary><pre>'+html.escape(json.dumps(statuses,indent=2,default=str))+'</pre></details>')
    if not artifacts:parts.append('<div class="card">No reports for this stage are registered yet. This does not mean that a later stage has run.</div>')
    images=[a for a in artifacts if Path(a['path']).suffix.lower() in ('.png','.jpg','.jpeg')]
    # The existing files are measurements; the HTML never invents missing plots or metrics.
    for a in images:
        p=Path(a['path']);thumb=_thumbnail(p)
        parts.append('<details open><summary>'+html.escape(p.name)+'</summary><p class="path">'+html.escape(str(p))+'</p>'+
                     ('<img loading="lazy" alt="'+html.escape(p.name)+'" src="'+thumb+'">' if thumb else '<p>Image exceeds the bounded summary-render limit. Open the registered original in the live center.</p>')+'</details>')
    for a in artifacts:
        p=Path(a['path'])
        if p.suffix.lower() not in ('.json','.csv','.txt'):continue
        if p.stat().st_size>250_000:
            text='Large report: use the registered original. Not loaded for this summary.'
        else:text=p.read_text(errors='replace')
        if p.stat().st_size<=250_000:
            import csv
            try:
                if p.suffix=='.csv':
                    reader=csv.DictReader(io.StringIO(text));cols=(reader.fieldnames or [])[:12];rows=list(reader)[:50]
                    if cols and rows:
                        parts.append('<section class="card"><h3>'+html.escape(p.name)+'</h3><div style="overflow:auto"><table><thead><tr>'+''.join('<th>'+html.escape(c)+'</th>' for c in cols)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r.get(c,'')))+'</td>' for c in cols)+'</tr>' for r in rows)+'</tbody></table></div><p class="muted">First 50 rows and 12 columns at most; full path in technical record below.</p></section>')
                elif p.suffix=='.json':
                    record=json.loads(text)
                    if isinstance(record,dict):
                        scalar={k:v for k,v in record.items() if isinstance(v,(str,int,float,bool)) and len(str(v))<180}
                        if scalar:
                            parts.append('<section class="card"><h3>'+html.escape(p.name)+'</h3><table>'+''.join('<tr><th>'+html.escape(k)+'</th><td>'+html.escape(str(v))+'</td></tr>' for k,v in list(scalar.items())[:24])+'</table></section>')
            except (ValueError,csv.Error):pass
        parts.append('<details><summary>'+html.escape(p.name)+'</summary><p class="path">'+html.escape(str(p))+'</p><pre>'+html.escape(text)+'</pre></details>')
    return document(sample+' | '+title,''.join(parts))


def write_center_reports(state,workspace,*,refresh_samples=None):
    """Fixed HTML index plus cached per-sample stage pages. Only changed pages rewrite."""
    from ..control.manifest import sample_layout
    root=Path(workspace)/'html';root.mkdir(parents=True,exist_ok=True)
    project=state['project'];selected=set(refresh_samples or [r['sample_key'] for r in project['rows']]);registry=state.setdefault('artifacts',{})
    for row in project['rows']:
        key=row['sample_key']
        if key in selected:registry[key]=list_reports(project,row)
        folder=root/'samples'/key;folder.mkdir(parents=True,exist_ok=True)
        records=registry.get(key,[])
        for stage in GROUPS:
            arts=[a for a in records if a['stage']==stage]
            related={'bin_qc':{'ingest_raw','import_bins','measure_he','bin_qc','reuse_bin_qc','review_bins'},
                     'assets':{'review_assets','transfer_assets'},'segmentation':{'stardist','review_prior','proseg','bin2cell','bin2cell_secondary'},
                     'cells':{'import_cells','postprocess_cells','assemble','assemble_methods','refresh_cell_annotations','refresh_method_annotations','review_cells'},
                     'clustering':{'cluster_individual','review_clustering'}}[stage]
            statuses={'jobs':{k:v for k,v in state.get('jobs',{}).get(key,{}).items() if k in related},
                      'reviews':{k:v for k,v in state.get('reviews',{}).get(key,{}).items() if k in related},
                      'legacy_inventory':{k:v for k,v in state.get('inventory',{}).get(key,{}).items() if k in related}}
            sig=fingerprint({'reports':arts,'states':statuses});mark=folder/(stage+'.fingerprint')
            if not mark.exists() or mark.read_text()!=sig:
                atomic_write(folder/(stage+'.html'),stage_html(row['sample_id'],stage,arts,statuses))
                atomic_write(mark,sig)
    body='<p class="muted">Revision '+str(state['revision'])+' • Saved '+html.escape(state['updated_at'])+'</p>'
    body+='<div class="warning">Read-only exported state. Open 00_Project_Center.ipynb for live Save / Run controls. File presence is not scientific approval; imported historical statuses are not fresh verification.</div>'
    body+='<div class="grid">'
    for row in project['rows']:
        key=row['sample_key'];jobs=state.get('jobs',{}).get(key,{})
        body+='<section class="card"><h2>'+html.escape(row['sample_id'])+'</h2><span class="badge">Input: '+html.escape(row['stage'])+'</span><span class="badge">Endpoint: '+html.escape(state.get('endpoints',{}).get(key,'cells'))+'</span>'
        if not jobs:body+='<p>Existing outputs may be present; no new center job is recorded yet.</p>'
        else:
            for name,j in jobs.items():body+='<p><b>'+html.escape(name)+'</b>: '+html.escape(j.get('status','unknown'))+'</p>'
        for stage,(label,_) in GROUPS.items():
            n=sum(x['stage']==stage for x in registry.get(key,[]))
            body+='<p><a href="samples/'+html.escape(key)+'/'+stage+'.html">'+html.escape(label)+'</a> <span class="muted">('+str(n)+' report files)</span></p>'
        body+='</section>'
    body+='</div>'
    if state.get('group_jobs'):
        body+='<h2>Explicit joint-analysis groups</h2><div class="grid">'
        for group,phases in state['group_jobs'].items():
            body+='<div class="card"><h3>'+html.escape(group)+'</h3>'
            target=root/'groups'/group/'clustering.html'
            if target.is_file():body+='<a href="groups/'+html.escape(group)+'/clustering.html">Group clustering / scVI report</a>'
            body+='<pre>'+html.escape(json.dumps(phases,indent=2))+'</pre></div>'
        body+='</div>'
    body+='<details><summary>Recent recorded decisions / operations</summary><pre>'+html.escape(json.dumps(state.get('history',[])[-40:],indent=2))+'</pre></details>'
    atomic_write(root/'project_review.html',document(state.get('title','Visium HD Project Center'),body))
    # Fixed entry alongside project_state.json; HTML folder stays portable as one ZIP.
    atomic_write(Path(workspace)/'project_review.html',document('Visium HD Project Center','<div class="card"><a href="html/project_review.html">Open the latest project overview</a></div>'))
    return root/'project_review.html'


def write_group_report(cfg,group,workspace,states=None):
    root=Path(cfg['_integration_work']);artifacts=[]
    for pattern in ('plots/*.png','diagnostics/*.png','analysis_qc/plots/*.png','cluster_summary.csv',
                    'clustering_backend.json','analysis_qc/sample_summary.csv','analysis_qc/complete.json','*cluster_sizes.csv',
                    'worker_*.resources.json'):
        for p in sorted(root.glob(pattern)):
            if p.is_file() and p.resolve().is_relative_to(root.resolve()) and not p.is_symlink():artifacts.append(stamp(p))
    page=Path(workspace)/'html/groups'/group/'clustering.html'
    text=stage_html('Integration group '+group,'clustering',artifacts,states)
    text=text.replace('Independent samples are not integrated.','This is the explicitly configured group analysis; inspect batch mixing and biological conservation separately.')
    atomic_write(page,text)
    return page
