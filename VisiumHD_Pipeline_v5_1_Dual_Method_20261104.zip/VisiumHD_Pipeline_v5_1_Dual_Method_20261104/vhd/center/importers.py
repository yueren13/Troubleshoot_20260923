"""Two-sheet setup and import of an existing configuration into managed copies."""
from __future__ import annotations
from pathlib import Path
from copy import deepcopy
import csv, io, json, re
from .state import atomic_write, file_fingerprint, now


def read_csv(path):
    p=Path(path)
    with p.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f); fields=reader.fieldnames
        if not fields or len(fields)!=len(set(fields)):raise ValueError(f'Missing/duplicate headers: {p}')
        rows=list(reader)
        if any(None in r or any(v is None for v in r.values()) for r in rows):raise ValueError(f'Malformed row: {p}')
    return fields,rows


def csv_text(fields,rows):
    stream=io.StringIO(newline='');w=csv.DictWriter(stream,fieldnames=fields)
    w.writeheader();w.writerows({k:r.get(k,'') for k in fields} for r in rows)
    return stream.getvalue()


def serialize_asset(asset):
    from ..annotations.workflow import COLUMNS, OPTIONAL_ASSET_COLUMNS
    a={k:asset.get(k,'') for k in COLUMNS+OPTIONAL_ASSET_COLUMNS}
    for k,v in list(a.items()):
        if k=='source_to_fullres' and isinstance(v,list):a[k]=';'.join(str(x) for row in v[:2] for x in row)
        elif isinstance(v,list):a[k]=';'.join(map(str,v))
        elif v is None:a[k]=''
        elif isinstance(v,bool):a[k]=str(v).lower()
        else:a[k]=str(v)
    return a


def clone_project(project, workspace):
    """Small copies only. Biological paths/run identity remain the supplied ones."""
    from ..control.manifest import COLUMNS, OPTIONAL_COLUMNS, row_config
    from ..annotations.workflow import read_assets,COLUMNS as AC,OPTIONAL_ASSET_COLUMNS as AO
    from ..annotations.discovery import read_choices,CHOICE_COLUMNS
    root=Path(workspace); engine=root/'engine';engine.mkdir(parents=True,exist_ok=False)
    p=deepcopy(project); sources={};choices={}; asset_rows=[]
    p['settings']['path_variables_file']=None
    metadata=p['settings'].get('sample_metadata')
    if metadata and metadata.get('path'):
        from ..control.manifest import path_value
        metadata['path']=path_value(metadata['path'],Path(project['settings_path']).parent)
    for row in p['rows']:
        # Store source fingerprints for audit; do not pretend to validate expression.
        oldrow=next(r for r in project['rows'] if r['sample_key']==row['sample_key'])
        assets=read_assets(row.get('assets_manifest'),row['dataset_id'],row['sample_id'])
        for a in assets:
            for c in read_choices(a['review_table']) if a.get('review_table') else []:
                if c['sample_key']==row['sample_key'] and c['asset_id']==a['asset_id']:
                    key=(c['sample_key'],c['asset_id'],c['item_key'])
                    if key in choices and choices[key]!=c:raise ValueError('Conflicting choice identities.')
                    choices[key]=c
            raw=serialize_asset(a);raw['review_table']=str(engine/'asset_choices.csv');asset_rows.append(raw)
        row['assets_manifest']=str(engine/'assets.csv') if assets else ''
        if row.get('overrides_json'):
            original=Path(row['overrides_json']);cfg,_=row_config(project,oldrow)
            # Copy the supplied override, resolving its path-valued special cases.
            d=json.loads(original.read_text())
            if d.get('he_score',{}).get('image_path'):d['he_score']['image_path']=cfg['he_score']['image_path']
            if d.get('storage',{}).get('compact_images'):d['storage']['compact_images']=cfg['storage']['compact_images']
            target=engine/'overrides'/(row['sample_key']+'.json')
            atomic_write(target,json.dumps(d,indent=2));row['overrides_json']=str(target)
        # Keep existing row metadata, including exact strings/leading zero identifiers.
        if row.get('metadata_json'):row['metadata_json']=str(Path(row['metadata_json']).absolute())
    atomic_write(engine/'assets.csv',csv_text(AC+AO,asset_rows))
    atomic_write(engine/'asset_choices.csv',csv_text(CHOICE_COLUMNS,list(choices.values())))
    p['manifest_path']=str(engine/'samples.csv');p['settings_path']=str(engine/'settings.json')
    atomic_write(engine/'samples.csv',csv_text(COLUMNS+OPTIONAL_COLUMNS,p['rows']))
    atomic_write(engine/'settings.json',json.dumps(p['settings'],indent=2,default=str))
    # Source snapshots deliberately exclude credentials/environment variables and arrays.
    for key in ('manifest_path','settings_path'):
        source=Path(project[key]);target=root/'inputs'/source.name
        if target.exists():target=root/'inputs'/(key+'_'+source.name)
        atomic_write(target,source.read_bytes());sources[key]={'path':str(source),'sha256':file_fingerprint(source)}
    extra_sources=set()
    for r in project['rows']:
        for name in ('assets_manifest','overrides_json','metadata_json'):
            if r.get(name):extra_sources.add(Path(r[name]))
        for a in read_assets(r.get('assets_manifest'),r['dataset_id'],r['sample_id']):
            if a.get('review_table') and Path(a['review_table']).is_file():extra_sources.add(Path(a['review_table']))
    if metadata and metadata.get('path'):extra_sources.add(Path(metadata['path']))
    for i,source in enumerate(sorted(extra_sources)):
        if source.is_file():
            target=root/'inputs'/f'{i:03d}_{source.name}'
            atomic_write(target,source.read_bytes());sources[str(source)]={'path':str(source),'sha256':file_fingerprint(source),'snapshot':str(target)}
    return p,sources


def project_from_sheets(samples,assets,output_root,*,profile=None,run_id='run01',namespace='Project',metadata_table=None,metadata_id_column='sample_id'):
    """Read a compact sample sheet; extra columns become sample metadata.

    No unqualified cell-coordinate or raw-count assumptions for midway cells.
    A filesystem output root must already be present; this never recreates a mount.
    """
    from ..control.manifest import COLUMNS,OPTIONAL_COLUMNS,validate_row,path_value,row_plan,as_bool
    output=Path(output_root).expanduser().absolute()
    if not output.is_dir():raise FileNotFoundError(f'Choose an existing approved project output root: {output}')
    defaults=json.loads((Path(__file__).parent/'data/backend_defaults.json').read_text())
    if profile:
        from ..control.manifest import deep_update
        supplied=json.loads(Path(profile).read_text());defaults=deep_update(defaults,supplied)
    cfg=defaults;cfg['run_id']=run_id;cfg['project_namespace']=namespace
    dirs={'work':output/'work','scratch':output/'scratch','objects':output/'exports','plots':output/'published_plots',
          'data':output/'published_data','master':output/'zarr_files','cache':output/'cache','control':output/'control'}
    for name in ('tmp','object','plot','data','work','cache','master'):
        key={'tmp':'scratch','object':'objects','plot':'plots'}.get(name,name)
        cfg['storage_policy']['approved_'+name+'_roots']=[str(dirs[key])]
    cfg['storage_policy']['approved_work_roots'] += [str(dirs['control'])]
    cfg['storage_policy']['required_existing_roots']=[str(output)]
    cfg['storage_policy']['locations']=[{'root':str(output),'backend':'unspecified','access':'filesystem','capacity_check':True}]
    cfg['integration'].update(control_dir=str(dirs['control']),tmp_dir=str(dirs['scratch']),work_dir=str(dirs['work']/'analysis'),
        output_object_dir=str(dirs['objects']),output_plot_dir=str(dirs['plots']),output_data_dir=str(dirs['data']))
    import sys
    for role in ('python_spatial','python_stardist','python_scvi','python_rapids'):
        if cfg['execution'].get(role)=='current':cfg['execution'][role]=sys.executable
    fields,raws=read_csv(samples);base=Path(samples).absolute().parent
    if 'sample_id' not in fields:raise ValueError('Sample sheet needs sample_id.')
    recognized=set(COLUMNS+OPTIONAL_COLUMNS)|{'species','endpoint'}
    rows=[]
    for line,raw in enumerate(raws,2):
        if not as_bool(raw.get('enabled','true')):continue
        r={k:raw.get(k,'').strip() for k in COLUMNS+OPTIONAL_COLUMNS}
        r['dataset_id']=r['dataset_id'] or namespace;r['stage']=r['stage'] or 'raw'
        r['goal']=r['goal'] or ('bin_QCed' if raw.get('endpoint')=='bins' else 'cell_annotated')
        r['enabled']='true';r['assets_manifest']=str(Path(assets).absolute()) if assets else ''
        for key,value in [('tmp_dir',dirs['scratch']),('work_dir',dirs['work']),('cache_dir',dirs['cache']),
                          ('output_object_dir',dirs['objects']),('output_plot_dir',dirs['plots']),('output_data_dir',dirs['data']),
                          ('master_store',dirs['master']/(r['sample_id']+'.zarr'))]:
            r[key]=r[key] or str(value)
        pathcols=['spaceranger_outs','segmentation_image','bin_input','cell_input','cell_boundaries','metadata_json',
                  'overrides_json','work_dir','cache_dir','tmp_dir','output_object_dir','output_plot_dir','output_data_dir','master_store','assets_manifest']
        for k in pathcols:r[k]=path_value(r[k],base)
        r=validate_row(r);r['sample_key']=r['dataset_id']+'__'+r['sample_id'];r['_csv_line']=line
        r['_plan']=row_plan(r)
        if r['stage'] in ('raw','bin_imported') and cfg.get('he_score',{}).get('enabled'):
            r['_plan'].insert(r['_plan'].index('bin_qc'),'measure_he')
        if assets:
            from ..annotations.workflow import read_assets
            found=read_assets(assets,r['dataset_id'],r['sample_id'])
            if not found:r['assets_manifest']=''
            else:
                index=next((r['_plan'].index(k) for k in ('stardist','import_cells','assemble') if k in r['_plan']),len(r['_plan']))
                r['_plan'][index:index]=['assemble_bins','import_assets','transfer_assets']
                if r['goal']=='cell_annotated':r['_plan'].insert(r['_plan'].index('publish'),'refresh_cell_annotations')
        from ..reconstruction.config import apply_method_route
        r['_plan']=apply_method_route(r['_plan'],cfg,r)
        meta={k:v for k,v in raw.items() if k not in recognized and v!=''}
        if raw.get('species'):meta['species']=raw['species']
        r['_sample_metadata']=meta;r['_sample_metadata_provenance']={'source':str(Path(samples).absolute()),'match':'sample_id','imported_at':now()}
        rows.append(r)
    if not rows or len({r['sample_key'] for r in rows})!=len(rows):raise ValueError('No enabled samples, or duplicate sample identities.')
    if metadata_table:
        from ..control.sample_metadata import resolve_project_metadata
        original=[dict(r.get('_sample_metadata',{})) for r in rows]
        config={'path':str(Path(metadata_table).absolute()),'sample_id_column':metadata_id_column}
        joined,join_report=resolve_project_metadata(rows,config,base)
        for r,old in zip(joined,original):
            for k,v in old.items():
                if k in r['_sample_metadata'] and r['_sample_metadata'][k]!=v:
                    raise ValueError(f"{r['sample_id']}: conflicting metadata {k!r} between sample and metadata sheets.")
                r['_sample_metadata'][k]=v
        rows=joined;cfg['sample_metadata']=config
    # Used only to snapshot a minimal settings profile. The caller supplies a workspace.
    return {'manifest_path':str(Path(samples).absolute()),'settings_path':str(Path(profile).absolute()) if profile else '',
            'rows':rows,'settings':cfg,'metadata_report':{'source':'sample_sheet_extra_columns','matched':len(rows)}}
