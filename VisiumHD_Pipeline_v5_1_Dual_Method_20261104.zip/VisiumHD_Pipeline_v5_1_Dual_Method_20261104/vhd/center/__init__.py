"""Persistent, review-first interface over the uploaded Visium HD scientific engine."""
__version__ = '0.5.1rc1'
from .controller import ProjectCenter

__all__ = ['ProjectCenter', '__version__']
