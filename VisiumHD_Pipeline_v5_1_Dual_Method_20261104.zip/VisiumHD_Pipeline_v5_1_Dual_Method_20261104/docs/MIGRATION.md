# Migration without overwriting working results

1. Keep the original October 14 code, original study sheets and current controller workspace backup. Extract this release into a new code directory. Do not apply historical patch installers afterward.
2. Open the existing managed workspace only after stopping other controllers/jobs against the same master. No raw-object migration occurs simply on opening. Managed configuration revisions are written when you explicitly save changes.
3. If the source configuration has no `cells.methods`, the old legacy `cells` route is retained. Saving an explicit method selection enables new method tables for generated-cell entries. Existing-cell imports continue to use `cells` because their method is not inferable from the path.
4. Existing Proseg prepared counts/polygons use their original work paths and scientific cache signatures. Named-table storage can reuse validated prepared products but does not rename an existing table. If those products are absent, compatible processing may need rerunning; a legacy table is not automatically relabelled.
5. Adding Bin2cell does not require a second H&E prior when scientific settings and source signatures are unchanged. Do not alter the completed prior's thresholds merely to match the new default. Prior, Bin2cell and method-store guards reject changed/partial outputs rather than overwriting them.
6. Old reviews are not blindly repurposed: new method selection requires review of the selected populations; an analysis-only switch affects its analysis review, not the biological source files.

## What was consolidated

Kept: the actual patched October 14 `vhd/` engine, necessary tools, tests, public provenance fields, shared priors, projective geometry, annotation repair/approval logic, runtime probes and the Project Center.

Removed from the colleague bundle: executed notebook outputs, checkpoints, bytecode/test caches, historical installer payloads/backups, one-off sample-specific corrective scripts and redundant ready-to-paste cells. In particular the supplied `notebooks/test_correction.py` (23 tests of a personal corrective script) is not part of the reusable release. The original archive remains unchanged. Private supplied configs/examples are separately preserved; never copy that pack into a public repository.

Old generic fixtures needed by tests now live under `tests/fixtures/config/`; user examples are a single five-route catalog. The old archive was not a license grant, and this release does not create one.

## Known unresolved inherited limitations

The Project Center does not yet provide general merge/reimport of new samples into an existing managed workspace, arbitrary edit/rebranch of every completed scientific input, unattended background service operation, or automatic repair of a half-written scientific store. Static HTML is reporting, not a live approval authority. These limitations are not fixed by naming cell tables.
