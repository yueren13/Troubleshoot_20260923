# Environment: retain the working scientific stack

The same Docker/UV-project layout is supported. Code runs inside the container; no host access, remounting, credential copying or automatic package installation is performed.

## New CPU dependency

Bin2cell stages run using the configured **spatial worker Python**. Add the dependency to that UV project, from its `pyproject.toml` directory, using your approved package indexes and normal groups/extras. An example dependency addition is:

```bash
uv add "bin2cell==0.3.5" rasterio
```

Do not run a blind global upgrade. Retain compatible versions of the already working AnnData, Scanpy, SpatialData, Shapely, GeoPandas, PyArrow, Zarr, h5py and image stack. The `bin2cell` optional dependency set in this package describes the adapter's added requirements, not a completely locked scientific environment. Full hardware/backend requirements remain stage-specific.

The raw-count expansion/aggregation branch does not request a GPU. The shared H&E StarDist prior and optional secondary density stage use the configured StarDist Python/GPU. Proseg retains its executable and multicore settings. Runtime role checks do not install missing programs.

## Widgets

The notebook kernel requires `ipywidgets>=8,<9`. If JupyterLab is installed separately, its frontend must discover `jupyterlab_widgets` / `@jupyter-widgets/jupyterlab-manager`; adding only the kernel package can display `VBox(...)` text. Use the working extension configuration already established in your deployment. A prebuilt user-level extension may be appropriate where authorized; persistence depends on the container/volume setup. Do not reinstall the running managed server or bypass extension policy.

Check a fresh slider/button, then the center's Test browser connection. Static HTML reports can be read without widgets but cannot save decisions or launch workers.

## Scientific smoke tests

Run `01_Dual_Method_Target_Smoke.ipynb` using the configured spatial worker Python. It refuses to call a skipped scientific test a pass. Both required tests use synthetic files under a uniquely named scratch directory: actual Bin2cell aggregation/H5AD/GeoParquet, then actual named SpatialData table/shape append and readback. They do not download a StarDist model or run GPU inference.

The target check also records package versions so you can preserve the working UV lockfile after success. No lockfile fabricated in a different environment is claimed to reproduce your GPU stack.

References:
- https://docs.astral.sh/uv/concepts/projects/dependencies/
- https://ipywidgets.readthedocs.io/en/stable/user_install.html
