# Start here: dual-method Project Center

## What this release is

A complete, consolidated code folder based on your uploaded October 14 v5 archive. It is **not a patch installer** and does not require the previous patch ZIPs. Version: **0.5.1rc1**.

The core workflow still begins at `notebooks/00_Project_Center.ipynb`. The ordinary user does not edit approval hashes or generated receipt files. HTML reports are regenerated from actual outputs; static exported HTML is read-only, while the connected Jupyter interface has the Save/Run controls.

## First pilot

1. Extract beside the working installation, not over it. Keep the old code and outputs. Save/stop active jobs before using a different controller with the same master.
2. Use the existing scientific kernel. The **spatial worker Python** also needs Bin2cell, Rasterio and the existing AnnData/SpatialData/GeoParquet stack. Do not install a new JupyterLab server in that kernel merely to enable widgets. See ENVIRONMENT.md.
3. Run `01_Dual_Method_Target_Smoke.ipynb`. Its two tests create tiny synthetic inputs and a tiny temporary store. A skipped test is **not** acceptance; the notebook raises when required tests are skipped. No real sample data are accessed.
4. Open `00_Project_Center.ipynb`. Choose **Open an existing Project Center** for the same managed workspace, after backing it up; or **Import existing pipeline configuration** for a new managed workspace. Import from your current on-instance files, not an old packaged study example. New studies can use the five examples under `examples/`.
5. Verify sample IDs, output paths, reports and existing approvals. Choose one sample for the first dual-method run. No computation starts just by opening the interface.
6. On **Segmentation / Cells**, select Proseg, Bin2cell, or both (Ctrl/Cmd-click in the multiple-selection box). Select the table for downstream analysis separately. Set the distance/threshold controls, leave secondary OFF for the first pilot, check the save-confirmation box and press **Save reconstruction choices**. Save does not execute segmentation.
7. Preview the route; use **Run until next review**. Review the shared prior before continuing. After reconstruction and assembly, inspect each method's counts, genes, cell areas, boundaries and method-specific HTML summaries before accepting cell QC.

### Controls

| Control | Default for new projects | Meaning |
|---|---:|---|
| Methods | Proseg | Bin2cell-only and both are explicit choices |
| Primary H&E probability | 0.02 | Passed to the shared H&E StarDist prior |
| Primary H&E NMS | 0.30 | Passed to that same prior |
| Bin2cell max distance | 2 | Expansion in 2-µm array bins; 0 means no expansion |
| Secondary density segmentation | Off | Optional extra fluorescence-model objects; separate settings |
| Analysis method | Proseg | Explicitly selected from the reconstructed methods |

Imported configurations keep their supplied settings, not new defaults. Existing projects without `cells.methods` keep the **legacy `cells` route** until you explicitly save a method selection. Imported cells are not relabelled Proseg/Bin2cell based on a filename.

## Where results live

The scientific master location remains the configured one. A named-method run adds:

```
tables/bins_2um
tables/proseg                 # when selected
tables/bin2cell               # when selected
shapes/proseg_cell_boundaries
shapes/bin2cell_cell_boundaries
```

A preexisting `tables/cells` remains untouched. Proseg keeps its existing prepared-cell cache locations to permit checked reuse. Bin2cell uses `work/bin2cell/` and `reports/bin2cell/`. The method comparison is `reports/reconstruction_comparison.html` with CSV/JSON companions. The Project Center's cells/segmentation pages include method-specific reports.

The live interface maintains `<workspace>/html/project_review.html` and sample pages under `html/samples/<sample_key>/`. Reports update at controller action boundaries or explicit Refresh; there is no detached file watcher. Missing or historical files are not labelled newly scientifically validated.

## Clustering and integration

Choose the analysis table in Segmentation / Cells. Independent PCA/Leiden/UMAP outputs are partitioned by method, and selecting another method does not concatenate cells. Joint scVI groups require at least two explicit sample members **all using the same selected cell table**. Work, scratch and companions are method-separated. Leave groups blank when no integration is wanted.

## Existing completed work and reruns

Changing only the selected analysis method can be saved without changing reconstruction. Changing a completed primary prior's thresholds or an already completed Bin2cell run's scientific settings requires a new run/master revision. This release refuses unsafe overwrites rather than implementing an implicit branching policy.

After switching method selection, previously complete controller actions may need checked revalidation under the new route. The shared prior's signature is preserved for identical scientific inputs. Do not delete completion records, alter signatures, or relabel a legacy table to force reuse.

## Readiness boundaries

The dependency-light tests ran here. Actual Bin2cell aggregation/SpatialData serialization are supplied as target tests but were skipped in the build environment. They are deliberately separate from the normal unit tests. Secondary inference, full-scale RAM, actual biological registration, institutional mounted-store behavior and live widget rendering were not validated here. Start with the two tiny tests, then one real sample; do not launch an entire cohort merely because the UI opens.
