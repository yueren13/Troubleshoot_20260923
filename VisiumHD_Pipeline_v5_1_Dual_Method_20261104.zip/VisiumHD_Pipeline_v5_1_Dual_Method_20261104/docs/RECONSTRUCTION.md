# Reconstruction contract

## Shared preparation

Space Ranger import, full-resolution bin centers, projective grid handling, fixed-reference H&E, and reviewed annotation eligibility remain the shared upstream preparation. The Bin2cell adapter consumes the existing `bins_raw.h5ad`, effective bin metadata, and QC-filtered `prior_qc.npy` with its recorded coordinate transform. It does not call a second Visium loader or rerun the primary H&E model.

Both primary H&E controls are exposed in the Project Center. Defaults 0.02/0.30 were read from the uploaded active configuration and retained for new generic profiles. They are not claimed universally optimal. Existing projects retain their own explicit values.

## Which bins are eligible

The default `bin2cell.bin_scope="match_proseg"` uses `segmentation_keep` **only if** the existing `prior_filter.filter_proseg_bins` is true; otherwise it uses `qc_keep`, matching the existing Proseg transcript-input policy. Nucleus QC/annotation gating still applies to the shared prior. A stricter Bin2cell aggregation domain can be explicitly selected in an advanced profile with `bin_scope="segmentation_keep"`; `qc_keep` is also explicit. Do not confuse filtering nuclei with excluding every transcript/bin in an annotation region. Comparison reports record the actual input-bin scope.

## Official Bin2cell calls, raw counts

Supported API series: Bin2cell >=0.3.3,<0.4; documentation/source inspected for 0.3.5. The adapter calls the installed package's `expand_labels` and `bin_to_cell`, not a reimplementation described as Bin2cell. `max_bin_distance` is an integer in array bins, default 2, nominally 4 µm on a 2-µm grid. It is not cell diameter or H&E-pixel distance. Expansion uses the upstream spatial/PCA tie-breaking behavior. The numerical tests do not establish which distance is optimal for a biological specimen.

Raw integer counts are aggregated without destriping or expression normalization. Before writing, the adapter verifies exact per-cell raw-bin sums, per-gene conservation over assigned bins, source feature order and original bin coordinates. Unassigned bins are counted and remain unassigned; a cell total is not required to equal all capture-area counts. The cell coordinate is the upstream mean of its assigned original bin centers, not a polygon geometric centroid.

Upstream k-neighbor queries request all CPUs; the adapter bounds the process CPU affinity to the worker allocation on Linux. Extremely small seed configurations stop with an explanation. A zero expansion distance or all-seeded input avoids unnecessary expansion.

## Boundaries and method identity

Bin2cell boundary geometry is the union of assigned 2-µm array-bin footprints, projected vertex by vertex into original full-resolution coordinates by the already validated grid mapping. All disconnected parts and holes are retained; no convex hull, simplification, or unreviewed repair is substituted. Geometry areas are checked against assigned bin counts before projection. A guard rejects invalid projective denominators or excessive grid raster size.

Method-qualified cell IDs prevent collisions. `local_cell_id` and source names are retained. Tables link only to their own regions: `proseg` → `proseg_cell_boundaries`; `bin2cell` → `bin2cell_cell_boundaries`. Legacy `cells` is never deleted/renamed. Selective readback depends on an isolated SpatialData internal shapes reader because the public reader selects element types rather than individual names; the target storage smoke test detects compatibility problems.

Append-only method storage serializes writes, uses the existing transaction machinery, verifies table/shape IDs and coordinate relationships, and compares stored CSR counts in chunks. An existing untracked or partially written named method is not silently adopted. New method files may coexist with a legacy `cells` copy, so enabling explicit Proseg names can increase storage; no invisible alias or hard-link assumption is made.

## Optional secondary step

Default is **disabled**, and the route never imports/runs TensorFlow for this stage while disabled. Enabling it creates a log1p total-count image on the 2-µm array grid, optionally Gaussian-smoothed (sigma=1 bin by default), and applies `2D_versatile_fluo`. Its model-default thresholds are used unless explicitly overridden in `bin2cell.secondary`; the primary H&E threshold is not reused. Effective values are recorded.

The upstream `salvage_secondary_labels` accepts only secondary objects not overlapping primary expanded assignments. Source attribution is stored per cell. Density values never replace raw counts. This is an **experimental opt-in implementation**: GPU inference and biological secondary-segmentation quality were not tested here. Pilot it separately from the default branch.

## Cell metadata and analysis

Bin2cell cell summaries use exact discrete bin assignments. Proseg retains its existing geometry-based bin-metadata transfer, explicitly not a reconstruction of molecule assignments. Categorical fractions/majorities, Boolean assessments and continuous summaries retain the existing selected transfer rules. Cell count/area/mitochondrial QC and sample metadata are applied per method.

Analysis must select one cell table. Alternative reconstructions of the same tissue are not independent replicates; the pipeline does not concatenate them for integration. Named method analyses and companions are isolated. Method comparison statistics are descriptive, not ground-truth accuracy scores.

## Resource limits

Bin2cell loads eligible expression into memory; PCA, exact verification and final geometry are eager. A conservative sparse-size/headroom check and one-worker default reduce avoidable concurrent allocations but cannot predict all peak usage or enforce a RAM limit. Run one representative sample and inspect measured resources before increasing concurrency. Base master creation/validation can still incur the existing large-bin I/O cost; selective method appends do not make the entire inherited workflow lightweight.

Primary upstream references (checked November 4, 2026):
- https://bin2cell.readthedocs.io/en/latest/bin2cell.expand_labels.html
- https://bin2cell.readthedocs.io/en/latest/bin2cell.bin_to_cell.html
- https://bin2cell.readthedocs.io/en/latest/bin2cell.salvage_secondary_labels.html
- https://github.com/Teichlab/bin2cell
- https://spatialdata.scverse.org/en/stable/api/SpatialData.html
