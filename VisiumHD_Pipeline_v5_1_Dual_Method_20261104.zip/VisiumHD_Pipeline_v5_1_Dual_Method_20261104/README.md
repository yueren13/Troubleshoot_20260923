# Visium HD Project Center — dual-method release candidate

**Version 0.5.1rc1 · November 4, 2026.** Built from the uploaded October 14 working archive, with its later scientific fixes retained. This is a target-pilot candidate, not a claim of production validation.

## Start

Open **`notebooks/00_Project_Center.ipynb`**. Use the Project Center for configuration, reviews, reports, and execution. Read [START_HERE](docs/START_HERE.md), then run the small [target smoke notebook](notebooks/01_Dual_Method_Target_Smoke.ipynb) in the intended scientific environment before a full-size Bin2cell run.

- Import an existing configuration or reopen an existing managed workspace; no raw data are bundled or moved.
- New studies use **one sample CSV and one optional asset CSV**. An optional profile supplies advanced defaults. Metadata columns can be included in the sample sheet.
- Select **Proseg, Bin2cell, or both** in **Segmentation / Cells**. Both use the same reviewed, QC-filtered H&E StarDist prior.
- Primary H&E defaults remain `prob_thresh=0.02`, `nms_thresh=0.30`; both are editable before generating a new prior. They are the supplied project's chosen profile, not universally optimal parameters.
- Bin2cell `max_bin_distance=2` is editable in **2-µm array bins**, not H&E pixels. Its secondary transcript-density StarDist is **off by default**.
- Named tables are `proseg` and `bin2cell`; original bins remain `bins_2um`. Existing legacy `cells` is not deleted or silently renamed.
- Cell QC, boundaries, annotation transfer, HTML summaries, and downstream analysis selection are method-aware. Alternative reconstructions are not independent biological replicates.

## Guides

| Guide | Purpose |
|---|---|
| [Start here](docs/START_HERE.md) | Installation, first pilot, and UI controls |
| [Examples catalog](examples/README.md) | Five invented, portable input scenarios |
| [Scientific/geometry contract](docs/RECONSTRUCTION.md) | Counts, prior, scope, boundaries, secondary step |
| [Migration](docs/MIGRATION.md) | Keep working results and legacy tables safe |
| [Environment](docs/ENVIRONMENT.md) | UV, Docker, Jupyter widgets, worker roles |
| [Validation](VALIDATION.md) | Executed tests, skips, and target acceptance checks |
| [Source changes](validation/SOURCE_AUDIT.md) | Exact baseline and change inventory |
| [Third-party notices](THIRD_PARTY.md) | External software and license boundaries |

## Safety and sharing

Extract into a **new code directory**. Do not apply old hotfix installers on top of this release. Do not run two controllers/notebooks against the same mutable master. Back up a controller workspace before opening it with a new code version. Scientific input and output paths remain user-selected.

This colleague-facing bundle contains generic examples, source-only notebooks, and tests. It excludes the supplied archive's personal deployment configuration, embedded notebook outputs, backups, and one-off corrective scripts. A separate **PRIVATE reference pack** preserves the supplied configuration/examples; do not publish it. No GitHub repository was modified.

The original source archive had no top-level license granting redistribution rights. This cleanup does **not** create a new license for that code. Obtain the appropriate owner/organization authorization before public distribution.

## Limits to read before a pilot

Real Bin2cell/AnnData/SpatialData roundtrips and GPU inference were not available in the build environment. Included target tests must pass, not skip. Secondary-density segmentation is experimental opt-in. Bin2cell matrix aggregation and final cell geometries are eager; resource estimates are guards, not guarantees. Changed completed scientific settings require a separate run/output revision; no force-overwrite or automatic method-table migration is provided.
