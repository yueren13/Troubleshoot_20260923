# Source and evidence audit

## Materials inspected

- `01_Dual_Method_Target_Smoke_run&result.zip`: the first executed notebook and synthetic test artifacts.
- `01_Dual_Method_Target_Smoke_run&result02.zip`: the later notebook plus both test runs.
- Delivered `VisiumHD_Pipeline_v5_1_Dual_Method_20261104.zip`: the implementation and tests.

Only archive contents were inspected. No mounted EC2 filesystem, study input,
production master, or biological slide was accessed. The attached tests use
synthetic fixtures, not the three study samples.

## Exact result distinction

| Run identifier | Actual Bin2cell test | Storage test | Suite outcome |
|---|---|---|---|
| `dual_method_ffa17102b9f04c45945396d11e6bb286` | Skipped: rasterio missing | Failed | 1 failed, 1 skipped |
| `dual_method_1c7e92d62ce24922998c029565429bd0` | Passed | Failed | 1 failed, 1 passed; 0 skipped |

Latest JUnit source:
`vhd_smoke_tests/dual_method_1c7e92d62ce24922998c029565429bd0/junit.xml`.
The later notebook points to that same run. The latest storage failure is the same
assertion that also failed before rasterio was installed; the dependency issue
and the storage defect are separate.

The failing assertion is retained in the patch:

```python
assert file_stamp(p['store']/'tables/cells',True)==old
```

The posted error reports legacy table payload size changing from **9,736 to
24,351 bytes**, together with size/mtime-inventory differences. The new method
count-readback and linkage assertions preceding this assertion completed without
raising in the submitted run. Later reuse assertions were NOT reached.

## Source-level cause

The original `vhd/persistence/spatial.py`, `refresh_metadata()`:

```python
def refresh_metadata(store):
    import zarr
    p=Path(store)
    for t in (p/'tables').iterdir() if (p/'tables').is_dir() else []:
        if t.is_dir() and ((t/'.zgroup').exists() or (t/'zarr.json').exists()):
            zarr.consolidate_metadata(str(t))
    zarr.consolidate_metadata(str(p))
```

Both `persist_changes()` and `update_table_metadata()` supplied this unscoped
function as the transaction metadata-refresh callback. The `append_method()`
implementation calls `persist_changes()` to add its named table and boundary.
Thus adding Bin2cell explicitly reconsolidated the already-written Proseg table
and the legacy `cells` table, even though neither was a replacement target.

The pipeline's directory `file_stamp(full_hash=True)` is a recursive size/mtime
inventory, NOT a per-file cryptographic payload hash. This patch leaves that
function and the test's original stamp comparison untouched. Additional test
checks use `inventory()` to verify actual file-content hashes too.

## Evidence in the uploaded final synthetic Zarr store

The legacy `tables/cells` contains 34 files totalling **24,351 bytes**. Its table-root
`zarr.json` is **14,920 bytes**, containing inline `consolidated_metadata`.
Removing that cache field from the inspected JSON and serializing the remaining
header with its observed indentation gives **305 bytes**:

```text
14,920 - 305 = 14,615 bytes of cache expansion
24,351 - 14,615 = 9,736 bytes (the test's recorded pre-append total)
```

That is exact accounting for the reported size difference. It is not a claim that
an independent pre-append byte snapshot was supplied; it was not.

The uploaded array metadata identifies Zarr format 3, int32 CSR components, and
bytes + Zstandard codecs. Using system libzstd to decode the tiny archived chunk
files directly (without installing Zarr), the expected fixture values were read:

| Table | CSR data | CSR indices | CSR indptr |
|---|---|---|---|
| cells | `[7, 1]` | `[0, 1]` | `[0, 2]` |
| proseg | `[2, 3, 4, 5]` | `[0, 1, 0, 1]` | `[0, 2, 4]` |
| bin2cell | `[2, 3, 4, 5]` | `[0, 1, 0, 1]` | `[0, 2, 4]` |

This confirms the submitted synthetic raw counts match those defined by the test.
It is not validation of production data or every field in the master.
`validation/uploaded_synthetic_counts.json` records this independent readback.

## Resolution

Metadata refresh is scoped to explicitly affected tables. The container root is
still refreshed so its catalogue includes newly added elements. Untouched table
roots are not independently consolidated. Metadata-only edits refresh their own
table so readers do not use a stale table-level metadata cache.

The original preservation assertion is NOT removed, changed to a skip, or loosened.
The enhanced smoke test checks legacy table and shape fingerprints/content after
each append, the first method after adding the second, raw legacy counts and
identifiers, and no-op reuse.

## External API reference (separate from attachment-derived evidence)

Zarr's public documentation says consolidation updates the root node of the
hierarchy supplied to it. Directly consolidating each table therefore writes at
those table roots. The root-only call does not itself require a separate
consolidation call for every existing table:

- https://zarr.readthedocs.io/en/latest/user-guide/consolidated_metadata/
- https://zarr.readthedocs.io/en/v3.4.0/api/zarr/functions/consolidate_metadata/

The warning about v3 consolidation being experimental and the `shapes.parquet`
warning in the submitted notebook are not the fatal exception. The actual
failure is the unchanged-table fingerprint assertion shown above.
