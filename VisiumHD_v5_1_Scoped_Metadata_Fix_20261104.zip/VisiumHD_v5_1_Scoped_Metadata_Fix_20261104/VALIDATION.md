# Validation — scoped metadata-refresh fix

Patch: `scoped-metadata-refresh-20261104-v1`.

## Executed checks

- **22 new dependency-light regression tests passed.** These exercise table-name
  validation, root-only refresh, targeted refresh, duplicate targets, missing
  targets, symlinks, new table/image/shape operations, table replacement, and the
  metadata-only writer's refresh dispatch. Real temporary files, checksums,
  journals, locks, and copy routines are used; Zarr/SpatialData/AnnData encoding
  in these mandatory tests uses explicit test doubles. They are NOT scientific
  serialization tests.
- **9 installer tests passed.** Preview writes nothing; replacements are backed
  up; configuration/notebook/data sentinels are preserved; repeated installation
  is a no-op; modified code, conflicting new files, symlinks, corrupt payloads,
  and invalid roots are rejected.
- **658 passed, 20 skipped** in the complete available pipeline collection on a
  fresh extraction of the delivered v5.1 ZIP with the supplied installer applied.
  This includes the 22 new mandatory regression tests, but not the 9 installer
  tests. See `validation/available_tests.log` and `validation/installer_tests.log`.
- The original legacy-table preservation assertion remains literally present.
- Independently decoded the tiny CSR payloads in the submitted synthetic Zarr:
  legacy `[7,1]`; each new method `[[2,3],[4,5]]`. This used libzstd and the stored
  array metadata, not the installed SpatialData reader. See `SOURCE_AUDIT.md`.

## Not executed here

Zarr, AnnData, SpatialData, PyArrow and Bin2cell are unavailable in this build
runtime. The real scientific tests therefore remain dependency-skipped locally.
A skip is not a pass. The twenty skip entries include seventeen dependency-gated
modules, one optional cross-version check, and two opt-in scVI checks. A skipped
module can contain several tests.

The actual two-module smoke notebook must be rerun in the user's environment.
Its intended completion requirement remains **2 passed, no skips/failures/errors**.
The updated storage smoke test checks real write/readback plus stricter per-append
preservation when those dependencies are available.

Additional real Zarr v2/v3 cache/readback tests are provided in
`tests/test_metadata_refresh_zarr_optional.py`. They were not executed locally.
No claim is made that the patch has already passed these target tests.

No EC2 mounted storage, full-scale biological sample, GPU inference, live widget
frontend, Proseg inference, or performance benchmark was executed in this fix.
No dependency installation or changes to source data, original archives, user
configuration, or approval records were made. The installer applies code only.
