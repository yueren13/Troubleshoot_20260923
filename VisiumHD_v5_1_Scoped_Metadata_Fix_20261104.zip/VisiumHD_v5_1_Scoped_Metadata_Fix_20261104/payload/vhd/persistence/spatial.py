"""Selective SpatialData writes using public encoders, with retained recovery copies.

Scientific roundtrip tests are provided but require SpatialData/AnnData installations.
Component metadata mutations do not rewrite expression arrays or unrelated elements.
"""
from __future__ import annotations
import tempfile,json,uuid
from pathlib import Path
import numpy as np
import pandas as pd
from .transaction import apply_replacements,validate_store,inventory,writer,copy_verified,remove_component
from ..control.paths_v3 import assert_target
from ..core import dump_json,safe_frame


def open_group(path,mode='r'):
    import zarr
    return zarr.open_group(str(path),mode=mode,use_consolidated=False)


def format_number(path):
    p=Path(path)
    for name in ('zarr.json','.zgroup'):
        if (p/name).exists():return int(json.loads((p/name).read_text())['zarr_format'])
    raise ValueError(f'Not a Zarr group: {p}')


def refresh_metadata(store, *, table_names=()):
    """Refresh only explicitly changed tables, then the container's root cache.

    Consolidating a table rewrites that table's metadata even when its counts
    are unchanged. Never iterate over all tables: doing so mutates unrelated
    elements and invalidates their tracked size/mtime fingerprints.

    The default is ROOT ONLY (appropriate for image/shape/root-attribute edits).
    A table-data or table-metadata writer must pass its affected table names.
    The store writer lock / single-writer acknowledgement is managed by callers.
    This function does not load or rewrite expression/image array payloads.
    """
    import zarr
    p=Path(store)
    if isinstance(table_names,str):
        table_names=(table_names,)
    if table_names is None:
        raise ValueError('Pass explicit changed table_names, or () for root only.')
    tables=[]
    for name in table_names:
        if (not isinstance(name,str) or not name or name in ('.','..')
                or '/' in name or '\\' in name):
            raise ValueError('Invalid table name for metadata refresh: '+repr(name))
        t=p/'tables'/name
        if t.is_symlink() or not t.resolve().is_relative_to(p.resolve()):
            raise ValueError('Refusing symlinked/escaped table metadata refresh: '+name)
        if not t.is_dir() or not ((t/'.zgroup').is_file() or (t/'zarr.json').is_file()):
            raise FileNotFoundError('Table Zarr group is absent: '+str(t))
        if t not in tables:
            tables.append(t)
    # Validate every explicit target before starting any metadata writes.
    format_number(p)
    for t in tables:
        zarr.consolidate_metadata(str(t))
    # Zarr's public consolidation writes metadata at the root passed here;
    # it does not separately reconsolidate each table's on-disk root.
    zarr.consolidate_metadata(str(p))


def aligned(frame,index):
    if not frame.index.is_unique or not index.is_unique or len(frame)!=len(index) or set(frame.index)!=set(index):raise ValueError('Annotation IDs must exactly match the unique observation ID set.')
    return frame.reindex(index)


def update_table_metadata(store,table,*,obs=None,obsm=None,uns=None,drop_obs=(),policy,staging_dir,
                          execute=False,single_writer_ack=False):
    """Merge selected columns and indexed embedding DataFrames. Never write X/layers.

    By-ID reordering is explicit; filtering/cell-set changes are not metadata updates.
    Full obs is rewritten (not counts). No physical-area/statistical meaning is inferred.
    """
    from anndata.io import read_elem,write_elem
    import zarr
    p=validate_store(store,policy)
    if not table or '/' in table or table in ('.','..'):raise ValueError('Invalid table name.')
    root=open_group(p/'tables'/table);old=read_elem(root['obs']);new=old.copy()
    old_uns=read_elem(root['uns']) if 'uns' in root else {};new_uns=dict(old_uns)
    links=old_uns.get('spatialdata_attrs',{});protected={'region','instance_id',links.get('region_key'),links.get('instance_key')}-{None}
    for col in drop_obs:
        if col in protected:raise ValueError('Cannot remove spatial linkage columns.')
        if col in new:new=new.drop(columns=col)
    if obs is not None:
        f=aligned(obs,old.index)
        for col in f:
            if col in protected and (col not in old or not f[col].equals(old[col])):raise ValueError('Changing spatial links is not an annotation-only update.')
            new[col]=f[col]
    embeds={}
    for key,frame in (obsm or {}).items():
        if '/' in key or key in ('','..','.','spatial'):raise ValueError('Invalid/coordinate embedding update; use a reviewed spatial transform operation.')
        if not isinstance(frame,pd.DataFrame):raise ValueError('Embedding update requires an indexed DataFrame, not anonymous positional rows.')
        embeds[key]=aligned(frame,old.index).to_numpy()
    if uns and 'spatialdata_attrs' in uns:raise ValueError('Cannot change table linkage in uns.')
    new_uns.update(uns or {})
    new=safe_frame(new)
    plan={'table':table,'obs_columns':list(obs.columns) if obs is not None else [],'drop_obs':list(drop_obs),'obsm':list(embeds),'uns':list(uns or {}),'writes_expression':False,'execute':execute}
    if not execute:return plan
    assert_target(staging_dir,policy.get('approved_work_roots',policy.get('approved_tmp_roots',[])))
    stage_dir=Path(staging_dir);stage_dir.mkdir(parents=True,exist_ok=True)
    base=p/'tables'/table;old_stamp=inventory(base/'obs');uns_stamp=inventory(base/'uns') if (base/'uns').exists() else None
    with tempfile.TemporaryDirectory(prefix='vhd_metadata_',dir=stage_dir) as tmp:
        tmp=Path(tmp);g=zarr.open_group(str(tmp),mode='w',zarr_format=format_number(base));replacements={}
        if obs is not None or drop_obs:
            write_elem(g,'obs',new);pd.testing.assert_frame_equal(read_elem(g['obs']),new)
            replacements[f'tables/{table}/obs']=tmp/'obs'
        if uns:
            write_elem(g,'uns',new_uns);read_elem(g['uns']);replacements[f'tables/{table}/uns']=tmp/'uns'
        if embeds:
            write_elem(g,'obsm',{})
            for key,value in embeds.items():
                write_elem(g['obsm'],key,value)
                np.testing.assert_equal(read_elem(g['obsm'][key]),value)
                replacements[f'tables/{table}/obsm/{key}']=tmp/'obsm'/key
            if not (base/'obsm').exists():
                replacements={k:v for k,v in replacements.items() if not k.startswith(f'tables/{table}/obsm/')}
                replacements[f'tables/{table}/obsm']=tmp/'obsm'
        def check_before(_):
            if inventory(base/'obs')!=old_stamp:raise RuntimeError('Annotations changed while preparing update; reload before retry.')
            if uns and (inventory(base/'uns') if (base/'uns').exists() else None)!=uns_stamp:raise RuntimeError('uns changed while preparing update.')
        def check_after(_):
            q=open_group(base)
            if obs is not None or drop_obs:pd.testing.assert_frame_equal(read_elem(q['obs']),new)
            for key,value in embeds.items():np.testing.assert_equal(read_elem(q['obsm'][key]),value)
            if uns:
                check=read_elem(q['uns'])
                for key in uns:
                    if key not in check:raise IOError('Written uns key missing.')
        report=apply_replacements(p,replacements,policy,execute=True,single_writer_ack=single_writer_ack,
                                  refresh=lambda store: refresh_metadata(store,table_names=(table,)),
                                  verify=check_after,precondition=check_before)
    return {**plan,**report}


def persist_changes(sdata,*,new_elements=(),replace_elements=(),transformation_elements=(),policy,staging_dir,execute=False,single_writer_ack=False,selected_readback=False):
    """Explicit intent. Non-table data replacements are NEVER silently transform-only."""
    import spatialdata as sd
    p=validate_store(sdata.path,policy)
    names=list(new_elements)+list(replace_elements)+list(transformation_elements)
    if len(names)!=len(set(names)):raise ValueError('Duplicate operation name.')
    groups={k:getattr(sdata,k) for k in ('images','labels','shapes','points','tables')}
    kinds={n:k for k,v in groups.items() for n in v}
    for name in names:
        if '/' in name or name in ('','.','..'):raise ValueError('Invalid element name.')
        if name not in kinds:raise KeyError(name)
    for n in new_elements:
        if (p/kinds[n]/n).exists():raise FileExistsError('New element already exists.')
    for n in list(replace_elements)+list(transformation_elements):
        if not (p/kinds[n]/n).exists():raise FileNotFoundError('Updated element is absent.')
    plan={'new':list(new_elements),'replace':list(replace_elements),'transforms':list(transformation_elements),'execute':execute}
    if not execute:return plan
    assert_target(staging_dir,policy.get('approved_work_roots',policy.get('approved_tmp_roots',[])))
    Path(staging_dir).mkdir(parents=True,exist_ok=True)
    if transformation_elements:
        if new_elements or replace_elements:raise ValueError('Persist transforms in a separate call.')
        if any(kinds[n]=='tables' for n in names):raise ValueError('Tables have no element transformation.')
        with writer(p,policy,single_writer_ack):
            tx=p.parent/(p.name+'.vhd_transactions')/uuid.uuid4().hex;tx.mkdir(parents=True);j=tx/'journal.json'
            files=[f for n in names for f in (p/kinds[n]/n).rglob('*') if f.name in ('zarr.json','.zattrs')]
            if not files:raise ValueError('No writable transformation metadata found.')
            ops=[]
            for f in files:
                rel=f.relative_to(p).as_posix();copy_verified(f,tx/'backup'/rel)
                ops.append({'relative':rel,'existed':True,'old':inventory(f),'status':'backed_up'})
            record={'master':str(p),'state':'prepared','operations':ops};dump_json(record,j)
            try:
                for op in ops:op['status']='promoting'
                record['state']='promoting';dump_json(record,j)
                for n in names:sdata.write_transformations(element_name=n)
                refresh_metadata(p)
                for op in ops:op['incoming']=inventory(p/op['relative']);op['status']='promoted'
                record['state']='committed';dump_json(record,j)
            except BaseException as e:
                record['state']='needs_recovery';record['error']=repr(e);dump_json(record,j)
                raise RuntimeError(f'Transform save incomplete; recovery journal {j}') from e
        return {**plan,'journal':str(j),'state':'committed'}
    with tempfile.TemporaryDirectory(prefix='vhd_elements_',dir=staging_dir) as tmp:
        stage=Path(tmp)/'elements.zarr';kwargs={}
        if format_number(p)==2:
            from spatialdata._io.format import SpatialDataContainerFormatV01
            kwargs['sdata_formats']=SpatialDataContainerFormatV01()
        chosen={k:{n:v[n] for n in list(new_elements)+list(replace_elements) if kinds[n]==k} for k,v in groups.items()}
        sd.SpatialData(**chosen).write(stage,overwrite=False,consolidate_metadata=False,**kwargs)
        if format_number(stage)!=format_number(p):raise ValueError('Stage/live formats differ; refusing to mix formats.')
        check=sd.read_zarr(stage,selection=tuple(k for k,v in chosen.items() if v))
        for n in names:
            if n not in check:raise IOError('Missing staged element.')
        del check
        replacements={f'{kinds[n]}/{n}':stage/kinds[n]/n for n in names}
        for kind in {kinds[n] for n in names}:
            for name in ('.zgroup','.zattrs','zarr.json'):
                if (stage/kind/name).exists() and not (p/kind/name).exists():replacements[f'{kind}/{name}']=stage/kind/name
        def verify(_):
            if selected_readback:
                # Method append: do not load another method's counts or millions of bin shapes.
                for n in names:
                    if kinds[n]=='tables':
                        from ..io import table_metadata
                        table_metadata(p,n)
                    elif kinds[n]=='shapes':
                        from spatialdata._io.io_shapes import _read_shapes
                        _read_shapes(p/'shapes'/n)
                    else:raise ValueError('Selective readback currently supports tables/shapes only.')
            else:
                q=sd.read_zarr(p,selection=tuple(k for k,v in chosen.items() if v))
                for n in names:
                    if n not in q:raise IOError('Promoted element cannot be reopened.')
        changed_tables=tuple(n for n in names if kinds[n]=='tables')
        return apply_replacements(p,replacements,policy,execute=True,single_writer_ack=single_writer_ack,
                                  refresh=lambda store: refresh_metadata(store,table_names=changed_tables),
                                  verify=verify)
