"""Actual named-table persistence and count readback in the target environment.

Both prepared cell populations here are SYNTHETIC, not Proseg/Bin2cell inference.
The test executes the real append/persistence code and preserves legacy `cells`.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
ad=pytest.importorskip('anndata');sd=pytest.importorskip('spatialdata')
pytest.importorskip('pyarrow')
import geopandas as gpd
from shapely.geometry import box
from spatialdata.models import ShapesModel
from spatialdata.transformations import Identity
from vhd.core import sample_paths,write_h5ad,completed,file_stamp
from vhd.storage import parse_table
from vhd.reconstruction.storage import append_method,verify_method
from vhd.reconstruction.config import method_paths
from vhd.io import load_table
from vhd.persistence.transaction import inventory


def test_append_two_methods_keeps_original_tables(tmp_path):
    work=tmp_path/'work';work.mkdir();dest=tmp_path/'master';dest.mkdir()
    cfg={'work_root':str(work),'output_root':str(dest),'storage':{'single_writer_ack':True},
         'storage_policy':{'approved_master_roots':[str(dest)],'approved_object_roots':[str(dest)],
             'approved_work_roots':[str(work)],'required_existing_roots':[str(tmp_path)],'check_master_free_space':False}}
    spec={'sample':'Fixture','sample_id':'Fixture','dataset_id':'Demo','metadata':{}}
    p=sample_paths(cfg,spec)
    legacy=ad.AnnData(X=sparse.csr_matrix([[7,1]],dtype=np.int32),obs=pd.DataFrame(index=['old']),var=pd.DataFrame(index=['g1','g2']))
    g=gpd.GeoDataFrame(geometry=[box(0,0,1,1)],index=['old'],crs=None)
    base=sd.SpatialData(shapes={'old_boundaries':ShapesModel.parse(g,transformations={'fullres':Identity()})},tables={'cells':parse_table(legacy.copy(),'old_boundaries',['old'])})
    base.write(p['store'],consolidate_metadata=False)
    old=file_stamp(p['store']/'tables/cells',True)
    protected={
        'tables/cells': (old, inventory(p['store']/'tables/cells')),
        'shapes/old_boundaries': (file_stamp(p['store']/'shapes/old_boundaries',True),
                                  inventory(p['store']/'shapes/old_boundaries')),
    }
    expected={}
    for method in ('proseg','bin2cell'):
        mp=method_paths(p,method);mp['work'].mkdir(parents=True,exist_ok=True)
        a=ad.AnnData(X=sparse.csr_matrix([[2,3],[4,5]],dtype=np.int32),obs=pd.DataFrame({'local_cell_id':['1','2']},index=['1','2']),var=pd.DataFrame(index=['g1','g2']))
        a.obsm['spatial']=np.array([[.5,.5],[2.5,.5]])
        polygons=gpd.GeoDataFrame(geometry=[box(0,0,1,1),box(2,0,3,1)],index=a.obs_names,crs=None)
        write_h5ad(a,mp['cells']);polygons.to_parquet(mp['polygons']);completed(mp['marker'],'synthetic',[mp['cells'],mp['polygons']])
        expected[method]=a.X.copy();append_method(cfg,spec,method)
        assert (load_table(p['store'],method).X!=expected[method]).nnz==0
        assert verify_method(p['store'],method)['region']==method+'_cell_boundaries'
        # Preserve every pre-existing element after EACH append, including
        # Proseg when Bin2cell is added. Check file bytes as well as timestamps.
        for relative,(stamp,content) in protected.items():
            assert file_stamp(p['store']/relative,True)==stamp, relative
            assert inventory(p['store']/relative)==content, relative
        for relative in (f'tables/{method}',f'shapes/{method}_cell_boundaries'):
            protected[relative]=(file_stamp(p['store']/relative,True),inventory(p['store']/relative))
        old_table=load_table(p['store'],'cells')
        assert (old_table.X!=legacy.X).nnz==0
        assert old_table.obs_names.equals(legacy.obs_names)
        assert old_table.var_names.equals(legacy.var_names)
    assert file_stamp(p['store']/'tables/cells',True)==old
    for method in ('proseg','bin2cell'):
        table=load_table(p['store'],method)
        assert table.obs_names.str.contains('::'+method+'::',regex=False).all()
        assert table.obs.segmentation_method.eq(method).all()
        assert (table.X!=expected[method]).nnz==0
        before=file_stamp(p['store']/'tables'/method,True);append_method(cfg,spec,method)
        assert file_stamp(p['store']/'tables'/method,True)==before
        for relative,(stamp,content) in protected.items():
            assert file_stamp(p['store']/relative,True)==stamp, relative
            assert inventory(p['store']/relative)==content, relative
