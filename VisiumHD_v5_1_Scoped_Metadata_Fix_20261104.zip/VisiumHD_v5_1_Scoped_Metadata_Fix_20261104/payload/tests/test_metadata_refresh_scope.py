"""Dependency-light scope tests; the Zarr/SpatialData encoders are explicit doubles.

Actual Zarr and SpatialData cases live in the *_optional modules. These tests
exercise real pipeline dispatch, transaction copies/locks, and file preservation.
"""
from pathlib import Path
from types import SimpleNamespace
import json
import sys
import pytest

from vhd.core import file_stamp
from vhd.persistence.spatial import refresh_metadata, persist_changes
from vhd.persistence.transaction import inventory


def group(path, fmt=3):
    path=Path(path);path.mkdir(parents=True,exist_ok=True)
    name='zarr.json' if fmt==3 else '.zgroup'
    doc={'zarr_format':fmt,'node_type':'group','attributes':{}} if fmt==3 else {'zarr_format':2}
    (path/name).write_text(json.dumps(doc))
    return path


@pytest.fixture
def fixture(tmp_path,monkeypatch):
    root=group(tmp_path/'sample.zarr');group(root/'tables');group(root/'shapes')
    for name in ('cells','proseg','bin2cell'):
        t=group(root/'tables'/name);(t/'count_sentinel').write_bytes(b'counts:'+name.encode())
    calls=[]
    def consolidate(path):
        p=Path(path);calls.append(p)
        # Explicit simulator of root metadata consolidation, not the Zarr library.
        if (p/'zarr.json').exists():
            j=json.loads((p/'zarr.json').read_text());j['consolidated_metadata']={'simulated':len(calls)}
            (p/'zarr.json').write_text(json.dumps(j))
        else:
            (p/'.zmetadata').write_text(json.dumps({'simulated':len(calls)}))
    monkeypatch.setitem(sys.modules,'zarr',SimpleNamespace(consolidate_metadata=consolidate))
    return root,calls


def snapshots(root):
    return {name:(file_stamp(root/'tables'/name,True),inventory(root/'tables'/name))
            for name in ('cells','proseg','bin2cell')}


def test_root_only_preserves_all_table_bytes_and_stamps(fixture):
    root,calls=fixture;old=snapshots(root)
    refresh_metadata(root)
    assert calls==[root]
    assert snapshots(root)==old


def test_selected_table_only_and_root_last(fixture):
    root,calls=fixture;old=snapshots(root)
    refresh_metadata(root,table_names=('bin2cell',))
    assert calls==[root/'tables/bin2cell',root]
    now=snapshots(root)
    assert now['cells']==old['cells'] and now['proseg']==old['proseg']
    assert now['bin2cell']!=old['bin2cell']
    assert (root/'tables/bin2cell/count_sentinel').read_bytes()==b'counts:bin2cell'


def test_repeat_input_names_deduplicated(fixture):
    root,calls=fixture
    refresh_metadata(root,table_names=['proseg','proseg','bin2cell'])
    assert calls==[root/'tables/proseg',root/'tables/bin2cell',root]


def test_single_string_is_one_table(fixture):
    root,calls=fixture;refresh_metadata(root,table_names='proseg')
    assert calls==[root/'tables/proseg',root]


@pytest.mark.parametrize('value',[None,[''],['.'],['..'],['../cells'],['a/b'],['a\\b'],[1],[True]])
def test_invalid_targets_fail_without_any_metadata_write(fixture,value):
    root,calls=fixture;before=inventory(root)
    with pytest.raises(ValueError):refresh_metadata(root,table_names=value)
    assert not calls and inventory(root)==before


def test_missing_second_target_validated_before_first_write(fixture):
    root,calls=fixture;before=inventory(root)
    with pytest.raises(FileNotFoundError):refresh_metadata(root,table_names=['proseg','absent'])
    assert not calls and inventory(root)==before


def test_symlink_refused(fixture,tmp_path):
    root,calls=fixture;outside=group(tmp_path/'outside')
    (root/'tables/link').symlink_to(outside,target_is_directory=True)
    with pytest.raises(ValueError):refresh_metadata(root,table_names=['link'])
    assert not calls


def test_invalid_store_fails_before_metadata_write(fixture,tmp_path):
    _,calls=fixture
    with pytest.raises(ValueError):refresh_metadata(tmp_path/'absent')
    assert not calls


def test_v2_marker_supported(fixture,tmp_path):
    _,calls=fixture;root=group(tmp_path/'v2.zarr',2);group(root/'tables/new',2);group(root/'tables/old',2)
    old=file_stamp(root/'tables/old',True)
    refresh_metadata(root,table_names=['new'])
    assert calls==[root/'tables/new',root]
    assert (root/'tables/new/.zmetadata').is_file() and (root/'.zmetadata').is_file()
    assert file_stamp(root/'tables/old',True)==old


def fake_spatialdata(monkeypatch):
    class FakeData:
        def __init__(self,path=None,**kwargs):
            self.path=path
            for k in ('images','labels','shapes','points','tables'):setattr(self,k,kwargs.get(k,{}))
        def __contains__(self,name):
            return any(name in getattr(self,k) for k in ('images','labels','shapes','points','tables'))
        def write(self,path,**kwargs):
            assert kwargs.get('consolidate_metadata') is False
            root=group(path)
            for k in ('images','labels','shapes','points','tables'):
                for n in getattr(self,k):group(root/k/n)
    def read(path,selection=()):
        p=Path(path)
        return FakeData(path=p,**{k:{d.name:object() for d in (p/k).iterdir() if d.is_dir()}
                                 for k in selection if (p/k).exists()})
    monkeypatch.setitem(sys.modules,'spatialdata',SimpleNamespace(SpatialData=FakeData,read_zarr=read))
    return FakeData


@pytest.mark.parametrize('kind',['tables','shapes','images'])
def test_persist_new_element_refreshes_only_affected_tables(fixture,tmp_path,monkeypatch,kind):
    root,calls=fixture;old=snapshots(root);Fake=fake_spatialdata(monkeypatch)
    obj=Fake(path=root,**{kind:{'new_element':object()}})
    policy={'approved_master_roots':[str(tmp_path)],'approved_work_roots':[str(tmp_path)],'check_master_free_space':False}
    result=persist_changes(obj,new_elements=['new_element'],policy=policy,staging_dir=tmp_path/'stage',
                           execute=True,single_writer_ack=True)
    assert result['state']=='committed'
    assert calls==([root/'tables/new_element'] if kind=='tables' else [])+[root]
    assert snapshots(root)==old


def test_replacing_table_preserves_other_tables(fixture,tmp_path,monkeypatch):
    root,calls=fixture;old=snapshots(root);Fake=fake_spatialdata(monkeypatch)
    policy={'approved_master_roots':[str(tmp_path)],'approved_work_roots':[str(tmp_path)],'check_master_free_space':False}
    result=persist_changes(Fake(path=root,tables={'bin2cell':object()}),replace_elements=['bin2cell'],policy=policy,
                           staging_dir=tmp_path/'stage',execute=True,single_writer_ack=True)
    assert result['state']=='committed'
    assert calls==[root/'tables/bin2cell',root]
    now=snapshots(root)
    assert now['cells']==old['cells'] and now['proseg']==old['proseg']


def test_obs_update_dispatch_refreshes_target_not_sibling(fixture,tmp_path,monkeypatch):
    """Real metadata-update orchestration; explicit fake AnnData/Zarr encoders."""
    import pandas as pd
    import vhd.persistence.spatial as module
    root,calls=fixture;before=snapshots(root)
    for name in ('cells','proseg','bin2cell'):
        group(root/'tables'/name/'obs')
    before=snapshots(root)
    class FakeGroup(dict):
        def __init__(self,path):super().__init__();self.path=Path(path)
    live=FakeGroup(root/'tables/bin2cell')
    live['obs']=pd.DataFrame({'old':[1,2]},index=['a','b'])
    def write_elem(g,k,value):
        g[k]=value;folder=g.path/k;folder.mkdir(parents=True,exist_ok=True)
        (folder/'zarr.json').write_text('{"zarr_format":3,"node_type":"group"}')
    monkeypatch.setitem(sys.modules,'anndata',SimpleNamespace())
    monkeypatch.setitem(sys.modules,'anndata.io',SimpleNamespace(read_elem=lambda x:x,write_elem=write_elem))
    backend=sys.modules['zarr']
    backend.open_group=lambda path,**kwargs:FakeGroup(path)
    monkeypatch.setattr(module,'open_group',lambda path,mode='r':live)
    def apply(store,replacements,policy,**kwargs):
        assert list(replacements)==['tables/bin2cell/obs']
        kwargs['refresh'](store)
        return {'state':'committed','test_double_for_payload_promotion':True}
    monkeypatch.setattr(module,'apply_replacements',apply)
    result=module.update_table_metadata(root,'bin2cell',obs=pd.DataFrame({'new':[3,4]},index=['a','b']),
            policy={'approved_master_roots':[str(tmp_path)],'approved_work_roots':[str(tmp_path)]},
            staging_dir=tmp_path/'stage',execute=True,single_writer_ack=True)
    assert result['state']=='committed'
    assert calls==[root/'tables/bin2cell',root]
    now=snapshots(root)
    assert now['cells']==before['cells'] and now['proseg']==before['proseg']
