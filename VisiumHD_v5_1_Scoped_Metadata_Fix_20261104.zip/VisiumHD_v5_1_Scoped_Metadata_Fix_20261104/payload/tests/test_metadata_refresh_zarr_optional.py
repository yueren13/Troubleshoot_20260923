"""Real Zarr v2/v3 cache scope/readback; requires Zarr, but not SpatialData."""
import json
import numpy as np
import pytest
zarr=pytest.importorskip('zarr')
from vhd.core import file_stamp
from vhd.persistence.spatial import refresh_metadata
from vhd.persistence.transaction import inventory


@pytest.mark.parametrize('fmt',[2,3])
def test_scoped_refresh_real_zarr_preserves_siblings_and_updates_reads(tmp_path,fmt):
    path=tmp_path/'fixture.zarr'
    root=zarr.open_group(str(path),mode='w',zarr_format=fmt)
    for table in ('cells','proseg'):
        g=root.create_group('tables/'+table)
        g.create_array('X',data=np.array([[7,1]],dtype=np.int32))
        g.create_group('obs').create_array('score',data=np.array([1.],dtype=np.float32))
    refresh_metadata(path,table_names=['proseg'])
    protected={n:(file_stamp(path/'tables'/n,True),inventory(path/'tables'/n)) for n in ('cells','proseg')}
    new=root.create_group('tables/bin2cell')
    new.create_array('X',data=np.array([[2,3],[4,5]],dtype=np.int32))
    new.create_group('obs').create_array('score',data=np.array([2.,3.],dtype=np.float32))
    refresh_metadata(path,table_names=['bin2cell'])
    for n,value in protected.items():
        assert (file_stamp(path/'tables'/n,True),inventory(path/'tables'/n))==value
    # Root and direct table reads both see the new content.
    np.testing.assert_array_equal(zarr.open_group(str(path),mode='r')['tables/bin2cell/X'][:],[[2,3],[4,5]])
    direct=zarr.open_group(str(path/'tables/bin2cell'),mode='r')
    np.testing.assert_array_equal(direct['obs/score'][:],[2.,3.])
    # A real metadata edit must refresh THAT table's cache, not its sibling's.
    writable=zarr.open_group(str(path/'tables/bin2cell'),mode='a',use_consolidated=False)
    writable['obs'].create_array('new_column',data=np.array([4,5],dtype=np.int32))
    refresh_metadata(path,table_names=['bin2cell'])
    np.testing.assert_array_equal(zarr.open_group(str(path/'tables/bin2cell'),mode='r')['obs/new_column'][:],[4,5])
    for n,value in protected.items():assert (file_stamp(path/'tables'/n,True),inventory(path/'tables'/n))==value
