# v5.1 scoped metadata-refresh fix

Patch ID: `scoped-metadata-refresh-20261104-v1`  
Baseline: `VisiumHD_Pipeline_v5_1_Dual_Method_20261104` (0.5.1rc1).

## Why this fix exists

The submitted second smoke-test run has **one pass, one failure, and zero skips**.
The actual Bin2cell raw-count/output test passes. The named-method storage test
fails because adding the method tables changes the file fingerprint of the
pre-existing synthetic `tables/cells` element.

The persistence helper reconsolidated **every table** during each incremental
write. Consolidation changes table-root metadata even when counts are unchanged.
It also risks making an earlier method's receipt appear stale after another
method is added. This is a code defect, not a missing approval or another missing
package. The original preservation assertion is retained and strengthened.

## Install into the existing v5.1 folder

Finish/stop active workers first. Extract this entire fix directory beside the
v5.1 pipeline directory. In the smoke notebook, after the first setup cell has
defined `ROOT`, run:

```python
from pathlib import Path
import runpy

FIX = Path(ROOT).parent / "VisiumHD_v5_1_Scoped_Metadata_Fix_20261104"
installer = runpy.run_path(str(FIX / "apply_fix.py"))
installer["apply_fix"](ROOT, apply=True)
```

An optional dry run uses `apply=False`. The installer verifies payload and existing
source hashes, checks all targets before writing, backs up replaced code under
`.vhd_code_backups/`, and refuses unexpected local edits. An identical repeated
installation is a no-op. Do not manually force a source-check failure.

Only one production module changes: `vhd/persistence/spatial.py`. The installer
also updates the storage smoke test and adds two regression-test modules. It does
**not** edit configuration, environments, approval state, existing notebooks,
biological data, or previous smoke outputs. The Bin2cell adapter is unchanged.

## Rerun the same smoke notebook

Restart the notebook kernel so old modules do not remain cached. Rerun
`01_Dual_Method_Target_Smoke.ipynb`, keeping your existing spatial Python and your
chosen approved scratch parent. In the submitted notebook you added a separate
location/confirmation cell; keep and rerun that cell too.

The existing smoke notebook creates a new UUID-named test directory for each run.
No deletion or repair of old test outputs is necessary. Do not point pytest's
`--basetemp` at an existing data directory.

Expected result from the two required modules:

```text
2 passed
{'tests': 2, 'failures': 0, 'errors': 0, 'skipped': 0}
```

The strengthened storage test is still **one test**, so the notebook's two-test
requirement remains correct. It now checks all already-present table/shape bytes
and file stamps after **each** append, verifies the legacy raw counts/IDs, and
checks reuse. It does not skip or weaken the failing assertion.

Keep full biological runs paused until both required target tests pass. The
unchanged original test modules remain responsible for real Bin2cell/SpatialData
behavior in the target environment. Optional extra cache-only tests are in
`tests/test_metadata_refresh_zarr_optional.py`; they are not required for the
notebook's fixed count of two tests.

## Change in persistence behavior

- `refresh_metadata(store)` now refreshes the container root only. It does not
  independently rewrite any table's own root.
- `refresh_metadata(store, table_names=("bin2cell",))` refreshes that table, then
  the container root. All names are checked before any refresh write.
- Element add/replace passes only table elements affected by that call.
- A metadata-only update passes only the table receiving the obs/uns/embedding edit.
- Image/shape/transform/root-attribute changes use root-only refresh.
- Raw arrays, count comparisons, `file_stamp()`, table names, links, scientific
  algorithms, and overwrite/partial-output safeguards are unchanged.

An external script that explicitly edits a table then calls `refresh_metadata`
must name that table. Advanced manual recovery after table-component restoration
likewise needs the affected table names, e.g. a refresh callback calling
`refresh_metadata(store, table_names=("bin2cell",))`. This patch does not automate
or bless repair of an existing partial/untracked biological store.

## Evidence and validation

Read `SOURCE_AUDIT.md` for the exact submitted results, byte-size accounting, and
independent readback of the uploaded synthetic counts. `VALIDATION.md` separates
executed tests from dependency-skipped scientific roundtrips.
