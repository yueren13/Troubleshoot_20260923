"""Install the scoped metadata fix into an existing v5.1 code checkout only.

No dependency imports, biological data/config edits, automatic cleanup, or test
execution. Default is a dry-run. Stop workers and restart the kernel afterwards.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import uuid

PACKAGE = Path(__file__).resolve().parent
EXPECTED_PATHS = (
    'vhd/persistence/spatial.py',
    'tests/test_dual_spatial_optional.py',
    'tests/test_metadata_refresh_scope.py',
    'tests/test_metadata_refresh_zarr_optional.py',
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_target(root: Path, relative: str) -> Path:
    part=Path(relative)
    if part.is_absolute() or '..' in part.parts or relative not in EXPECTED_PATHS:
        raise ValueError('Unexpected patch target: '+relative)
    target=root/part
    current=target
    while current != root:
        if current.is_symlink():raise ValueError('Refusing symlinked code target: '+str(current))
        current=current.parent
    if not target.resolve().is_relative_to(root):raise ValueError('Target escapes code root.')
    return target


def atomic_write(path: Path, data: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.'+path.name+'.vhd_fix_',dir=path.parent)
    temp=Path(name)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.chmod(temp,mode)
        os.replace(temp,path)
    finally:
        if temp.exists():temp.unlink()


def apply_fix(root: str | Path, *, apply: bool = False) -> dict:
    """Preview or apply code-only replacements; unchanged reapplication is a no-op."""
    root=Path(root).expanduser().resolve()
    if not (root/'vhd/persistence/spatial.py').is_file() or not (root/'vhd/center').is_dir():
        raise ValueError('Point ROOT to the v5.1 pipeline folder containing vhd/ and tests/.')
    manifest=json.loads((PACKAGE/'manifest.json').read_text())
    if tuple(e['path'] for e in manifest['files'])!=EXPECTED_PATHS:
        raise ValueError('Unexpected patch manifest targets.')
    planned=[]
    for entry in manifest['files']:
        target=safe_target(root,entry['path']);payload=PACKAGE/'payload'/entry['path']
        content=payload.read_bytes()
        if sha(content)!=entry['after_sha256']:
            raise ValueError('Patch payload checksum failed: '+entry['path'])
        old=target.read_bytes() if target.is_file() else None
        current_hash=sha(old) if old is not None else None
        if current_hash==entry['after_sha256']:
            status='already installed'
        elif current_hash==entry['before_sha256'] and not (target.exists() and old is None):
            status='replace' if old is not None else 'add'
        else:
            raise RuntimeError('Unexpected local source; nothing was changed: '+str(target))
        planned.append((entry,target,content,old,status))
    changes=[p for p in planned if p[-1]!='already installed']
    result={'patch':manifest['patch'],'code_root':str(root),'applied':False,
            'changes':[{'path':p[0]['path'],'action':p[-1]} for p in planned]}
    for p in planned:print(p[-1]+': '+p[0]['path'])
    if not apply:
        print('Preview only. No files changed.');return result
    if not changes:
        print('Already installed; no files changed.');return result
    # A second check catches concurrent code changes before creating backups.
    for entry,target,content,old,status in changes:
        now=target.read_bytes() if target.is_file() else None
        if now!=old:raise RuntimeError('Code changed while planning; retry after stopping editors/workers.')
    backup=root/'.vhd_code_backups'/(manifest['patch']+'_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8])
    if (root/'.vhd_code_backups').is_symlink():raise ValueError('Refusing symlinked code backup directory.')
    backup.mkdir(parents=True,exist_ok=False)
    journal={'patch':manifest['patch'],'state':'preparing','files':result['changes'],'written':[]}
    journal_path=backup/'installation.json'
    for entry,target,content,old,status in changes:
        if old is not None:
            b=backup/entry['path'];b.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(target,b)
            if b.read_bytes()!=old:raise IOError('Code backup verification failed: '+str(b))
    atomic_write(journal_path,(json.dumps(journal,indent=2)+'\n').encode())
    try:
        for entry,target,content,old,status in changes:
            mode=(target.stat().st_mode & 0o777) if target.exists() else 0o644
            atomic_write(target,content,mode)
            journal['written'].append(entry['path'])
            if sha(target.read_bytes())!=entry['after_sha256']:
                raise IOError('Installed checksum mismatch: '+str(target))
            journal['state']='writing'
            atomic_write(journal_path,(json.dumps(journal,indent=2)+'\n').encode())
        journal['state']='complete'
        atomic_write(journal_path,(json.dumps(journal,indent=2)+'\n').encode())
    except BaseException:
        journal['state']='incomplete'
        atomic_write(journal_path,(json.dumps(journal,indent=2)+'\n').encode())
        print('Code installation interrupted. Backups retained at:',backup)
        raise
    result.update(applied=True,backup_dir=str(backup))
    print('Installed. Code backups:',backup)
    print('Configuration, notebooks, environments and data were not modified.')
    print('Restart the kernel; rerun the same tiny smoke notebook.')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--apply',action='store_true',help='Apply; default is preview only.')
    arguments=parser.parse_args()
    apply_fix(arguments.root,apply=arguments.apply)
