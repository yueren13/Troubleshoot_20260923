from pathlib import Path
import runpy,shutil,json
import pytest
PACKAGE=Path(__file__).resolve().parents[1]


def tree(path):
    return {p.relative_to(path).as_posix():p.read_bytes() for p in path.rglob('*') if p.is_file()}


@pytest.fixture
def target(tmp_path):
    root=tmp_path/'pipeline';(root/'vhd/center').mkdir(parents=True)
    (root/'vhd/persistence').mkdir();(root/'tests').mkdir()
    (root/'vhd/persistence/spatial.py').write_bytes((PACKAGE/'tests/fixtures/original_spatial.txt').read_bytes())
    (root/'tests/test_dual_spatial_optional.py').write_bytes((PACKAGE/'tests/fixtures/original_dual_spatial_test.txt').read_bytes())
    (root/'config').mkdir();(root/'config/settings.json').write_text('{"private_sentinel":true}')
    (root/'notebooks').mkdir();(root/'notebooks/user.ipynb').write_text('user edited notebook sentinel')
    (root/'data.zarr').mkdir();(root/'data.zarr/sentinel').write_bytes(b'never touch')
    return root


def apply(package=PACKAGE):return runpy.run_path(str(package/'apply_fix.py'))['apply_fix']


def test_preview_no_files_or_directories_changed(target):
    before=tree(target);dirs=sorted(str(p) for p in target.rglob('*') if p.is_dir())
    result=apply()(target)
    assert result['applied'] is False and tree(target)==before
    assert sorted(str(p) for p in target.rglob('*') if p.is_dir())==dirs


def test_install_backups_and_preserves_config_notebook_and_data(target):
    before=tree(target);result=apply()(target,apply=True)
    assert result['applied'] is True
    backup=Path(result['backup_dir'])
    for rel in ('vhd/persistence/spatial.py','tests/test_dual_spatial_optional.py'):
        assert (backup/rel).read_bytes()==before[rel]
    for rel in ('config/settings.json','notebooks/user.ipynb','data.zarr/sentinel'):
        assert (target/rel).read_bytes()==before[rel]
    manifest=json.loads((PACKAGE/'manifest.json').read_text())
    for e in manifest['files']:assert (target/e['path']).read_bytes()==(PACKAGE/'payload'/e['path']).read_bytes()


def test_reapply_noop_preserves_bytes_and_mtimes(target):
    fn=apply();fn(target,apply=True);before=tree(target)
    stamps={p:p.stat().st_mtime_ns for p in target.rglob('*')}
    result=fn(target,apply=True)
    assert not result['applied'] and tree(target)==before
    assert {p:p.stat().st_mtime_ns for p in target.rglob('*')}==stamps


@pytest.mark.parametrize('rel',['vhd/persistence/spatial.py','tests/test_dual_spatial_optional.py','tests/test_metadata_refresh_scope.py'])
def test_unknown_local_file_stops_all_writes(target,rel):
    (target/rel).write_text('local edit');before=tree(target)
    with pytest.raises(RuntimeError,match='Unexpected local source'):apply()(target,apply=True)
    assert tree(target)==before and not (target/'.vhd_code_backups').exists()


def test_tampered_payload_refused(target,tmp_path):
    pkg=tmp_path/'tampered';shutil.copytree(PACKAGE,pkg)
    (pkg/'payload/vhd/persistence/spatial.py').write_text('bad bytes')
    before=tree(target)
    with pytest.raises(ValueError,match='checksum'):apply(pkg)(target,apply=True)
    assert tree(target)==before


def test_symlink_code_refused(target,tmp_path):
    original=target/'tests/test_dual_spatial_optional.py'
    external=tmp_path/'external';external.write_bytes(original.read_bytes());original.unlink();original.symlink_to(external)
    before=tree(target)
    with pytest.raises(ValueError,match='symlink'):apply()(target,apply=True)
    assert tree(target)==before


def test_wrong_root_refused_without_creating_directory(tmp_path):
    root=tmp_path/'absent'
    with pytest.raises(ValueError,match='Point ROOT'):apply()(root,apply=True)
    assert not root.exists()
