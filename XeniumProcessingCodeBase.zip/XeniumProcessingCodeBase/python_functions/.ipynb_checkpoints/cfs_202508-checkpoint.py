# sam_gpu_shim.py
# GPU shim for SAM: unify neighbor algorithm selection across inner loop + final graph
from typing import Optional, Dict, Any
import numpy as np
import scipy.sparse as sp
import pandas as pd
import warnings

# Module-level config shared by both functions
_SAM_GPU_CFG = {
    "neighbors_algorithm": "ivfpq",        # default ANN algorithm (can be 'brute','ivfflat','ivfpq','cagra','nn_descent'*)
    "neighbors_metric": "correlation",     # SAM default
    "neighbors_kwargs": {},                # algorithm-specific kwargs (e.g. n_lists, n_probes for IVF; graph_degree for CAGRA)
    "rmm_mode": "pool",
    "random_state": 0,
}

def _normalize_algo(name: Optional[str]) -> str:
    """Normalize synonyms to what rapids/cuml/cuvs commonly use."""
    if not name:
        return _SAM_GPU_CFG["neighbors_algorithm"]
    name = str(name).lower().replace("-", "_")
    synonyms = {
        "ivf_pq": "ivfpq",
        "ivf_flat": "ivfflat",
        "nndescent": "nn_descent",
    }
    return synonyms.get(name, name)

def enable_gpu_for_sam(
    neighbors_algorithm: str = "ivfpq",
    neighbors_metric: str = "correlation",
    neighbors_kwargs: Optional[Dict[str, Any]] = None,
    rmm_mode: str = "pool",       # 'pool' or 'managed'
    set_random_state: int = 0,
):
    """
    Monkey-patch SAM's internal neighbor search to use cuML on GPU and
    record a shared config for downstream calls.

    Parameters
    ----------
    neighbors_algorithm : str
        'brute' | 'ivfflat' | 'ivfpq' | 'cagra'  (cuML/cuvs algorithms)
        (SAM inner loop does not support 'nn_descent' via cuML's NearestNeighbors)
    neighbors_metric : str
        Typically 'correlation' (SAM default). Others: 'euclidean', 'cosine', ...
    neighbors_kwargs : dict
        Algorithm-specific knobs, e.g. {'n_lists': 1024, 'n_probes': 64} for IVF-PQ
        or {'graph_degree': 64, 'intermediate_graph_degree': 128} for CAGRA.
    rmm_mode : str
        'pool' (fast, fits-in-VRAM) or 'managed' (oversubscribe VRAM safely).
    set_random_state : int
        RNG seed.
    """
    import cupy as cp
    import numpy as np
    import scipy.sparse as sp
    from cupyx.scipy import sparse as csp
    from cuml.neighbors import NearestNeighbors
    from rmm.allocators.cupy import rmm_cupy_allocator
    import rmm

    # Persist config for later use (so both functions "talk").
    _SAM_GPU_CFG.update({
        "neighbors_algorithm": _normalize_algo(neighbors_algorithm),
        "neighbors_metric": neighbors_metric,
        "neighbors_kwargs": dict(neighbors_kwargs or {}),
        "rmm_mode": rmm_mode,
        "random_state": set_random_state,
    })

    # 1) Configure GPU memory
    if rmm_mode == "managed":
        rmm.reinitialize(managed_memory=True, pool_allocator=False)
    else:
        rmm.reinitialize(managed_memory=False, pool_allocator=True)
    cp.cuda.set_allocator(rmm_cupy_allocator)

    # 2) Patch SAM’s neighbor search
    import samalg.utilities as ut

    def _to_cupy_dense_or_csr(x):
        if sp.issparse(x):
            x = x.tocsr().astype(np.float32, copy=False)
            return csp.csr_matrix((cp.asarray(x.data), cp.asarray(x.indices), cp.asarray(x.indptr)),
                                  shape=x.shape)
        else:
            return cp.asarray(np.asarray(x, dtype=np.float32), order="C")

    def nearest_neighbors_gpu(X, n_neighbors, metric=_SAM_GPU_CFG["neighbors_metric"],
                              metric_kwds=None, angular=False, seed=_SAM_GPU_CFG["random_state"],
                              low_memory=False, **kwargs):
        """
        Drop-in replacement for samalg.utilities.nearest_neighbors().
        Returns (indices, distances) as NumPy arrays.
        """
        Xg = _to_cupy_dense_or_csr(X)
        algo = _normalize_algo(_SAM_GPU_CFG["neighbors_algorithm"])
        if algo == "nn_descent":
            # cuML NearestNeighbors does not expose 'nn_descent' here; choose a sane fallback.
            warnings.warn("nn_descent is not supported inside SAM loop; using 'cagra' fallback.")
            algo = "cagra"

        nn = NearestNeighbors(
            n_neighbors=n_neighbors,
            metric=metric,
            algorithm=algo,
            random_state=seed,
            **_SAM_GPU_CFG.get("neighbors_kwargs", {})
        )
        nn.fit(Xg)
        dists, inds = nn.kneighbors(Xg)
        return inds.get(), dists.get()

    ut.nearest_neighbors = nearest_neighbors_gpu  # monkey-patch


def run_sam_with_gpu_projection(
    sam,
    *,
    n_pcs: int = 150,
    n_neighbors: int = 15,
    use_harmony: bool = False,
    harmony_key: Optional[str] = None,       # e.g. 'batch' in adata.obs
    harmony_basis: str = "X_pca",
    harmony_adjusted_basis: str = "X_pca_harmony",
    umap_neighbors_key: Optional[str] = None,
    random_state: int = 0,

    # NEW: make the final neighbors algorithm configurable too
    neighbors_algorithm: Optional[str] = None,     # if None -> use shared config
    neighbors_metric: Optional[str] = None,        # if None -> use shared config
    neighbors_kwargs: Optional[Dict[str, Any]] = None,
    use_existing_pca: bool = False,
    overwrite_pca_with_harmony: bool = True,
):
    """
    1) Ensures data is on GPU
    2) PCA on GPU
    3) Optional Harmony on GPU (corrects PCs)
    4) Neighbors on GPU with selectable algorithm (final graph)
    5) UMAP on GPU
    """
    import rapids_singlecell as rsc

    adata = sam.adata
    rsc.get.anndata_to_GPU(adata)
    rsc.get.X_to_CPU(adata)#save ram
    
    # (A) PCA
    if use_existing_pca and "X_pca" in adata.obsm:
        pass  # reuse SAM's PCs
    else:
        rsc.pp.pca(adata, n_comps=n_pcs)     # or call gpu_sparse_pca_chunked(...)

    # (B) Optional Harmony
    if use_harmony:
        if harmony_key is None:
            raise ValueError("Set harmony_key to the column(s) in adata.obs that encode batches.")
        rsc.pp.harmony_integrate(
            adata, harmony_key,
            basis=harmony_basis,
            adjusted_basis=harmony_adjusted_basis,
            dtype=np.float32,
            correction_method="fast"
        )
        use_rep = harmony_adjusted_basis
    else:
        use_rep = "X_pca"

    # (C) Final neighbors on GPU (configurable)
    algo = _normalize_algo(neighbors_algorithm or _SAM_GPU_CFG.get("neighbors_algorithm"))
    metric = neighbors_metric or _SAM_GPU_CFG.get("neighbors_metric", "correlation")
    nn_kwargs = {**_SAM_GPU_CFG.get("neighbors_kwargs", {})}
    if neighbors_kwargs:
        nn_kwargs.update(neighbors_kwargs)

    # rsc.pp.neighbors supports GPU ANN backends like cagra/ivfpq/ivfflat and nn_descent (>=0.12.1).
    # Fall back gracefully if the 'algorithm' kw is not available in your version.
    try:
        rsc.pp.neighbors(
            adata,
            n_neighbors=n_neighbors,
            use_rep=use_rep,
            metric=metric,
            algorithm=algo,
            **nn_kwargs
        )
    except TypeError:
        warnings.warn("Your rapids_singlecell version may not expose 'algorithm='; using defaults.")
        rsc.pp.neighbors(
            adata,
            n_neighbors=n_neighbors,
            use_rep=use_rep,
            metric=metric,
        )

    # (D) UMAP on GPU
    rsc.tl.umap(adata, neighbors_key=umap_neighbors_key, random_state=random_state)
    rsc.get.anndata_to_CPU(adata)

    