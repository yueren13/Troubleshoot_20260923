import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy.stats import t as tdist, rankdata, hypergeom
from statsmodels.stats.multitest import multipletests
from skimage.filters import threshold_otsu
from sklearn.mixture import GaussianMixture
import gc
from typing import Optional, Tuple, Union
import json

# ---------- read visium json file ----------
def read_json_to_dict(file_path):
    """
    Reads a JSON file and converts its content into a Python dictionary.

    Args:
        file_path (str): The path to the JSON file.

    Returns:
        dict: A Python dictionary representing the JSON data, or None if an error occurs.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
            return data
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from '{file_path}'. Check file format.")
        return None
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return None

# ---------- helpers ----------

def _as_hwc(img_cyx: np.ndarray) -> np.ndarray:
    """(c,y,x) -> (h,w,c) without copying if possible."""
    if img_cyx.ndim != 3 or img_cyx.shape[0] not in (3, 4):
        raise ValueError("Expected (c,y,x) with 3 channels.")
    return np.moveaxis(img_cyx[:3], 0, -1)  # keep RGB, drop A if present

def _as_cyx(img_hwc: np.ndarray) -> np.ndarray:
    """(h,w,c) -> (c,y,x)."""
    return np.moveaxis(img_hwc, -1, 0)

def _auto_Io(img: np.ndarray) -> float:
    """
    Pick a robust 'white' intensity for OD computation.
    Works for uint8/uint16/float; returns a scalar Io.
    """
    if np.issubdtype(img.dtype, np.integer):
        # robust near-white across channels (ignore dark tissue)
        Io = float(np.percentile(img, 99.9))
        # fallbacks by bit-depth if percentile is too small
        if Io < 10:
            maxv = float(np.iinfo(img.dtype).max)
            Io = 240.0 if maxv <= 255 else maxv
    else:  # float
        m = float(img.max())
        if m <= 1.5:  # already in [0,1]
            Io = 1.0
        else:
            Io = float(np.percentile(img, 99.9))
            if Io < 1.0:
                Io = m
    return Io

def _batch_lstsq(HE: np.ndarray, Y: np.ndarray, batch: int = 100_000) -> np.ndarray:
    """
    Solve C = argmin ||HE*C - Y|| in batches to keep memory bounded.
    HE: (3,2), Y: (3,N) -> C: (2,N)
    """
    Cs = []
    for i in range(0, Y.shape[1], batch):
        C_i, _, _, _ = np.linalg.lstsq(HE, Y[:, i:i+batch], rcond=None)
        Cs.append(C_i)
    return np.concatenate(Cs, axis=1)

# ---------- main normalizer ----------

def macenko_normalize_visiumhd(
    img: Union[np.ndarray, "xarray.DataArray"],           # (c,y,x) or (h,w,c); RGB
    mask: Optional[np.ndarray] = None,                    # (h,w) bool; True = use for basis estimation
    Io: Union[str, float] = "auto",
    alpha: float = 1.0,                                   # Macenko angle percentile trim
    beta: float = 0.15,                                   # OD threshold (remove near-white)
    sample_max: int = 200_000,                            # subsample for eigen/basis estimation
    lstsq_batch: int = 200_000,                           # batch size for least-squares solve
    return_HE_H_E: bool = False,
) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
    """
    Macenko H&E normalization adapted for Visium HD / SpatialData images.

    Returns
    -------
    Inorm_cyx : uint8 (c,y,x)
    optionally (Inorm_cyx, HE(3x2), H_hwc, E_hwc)
    """
    # Accept xarray (SpatialData) or numpy
    try:
        import xarray as xr
        if isinstance(img, xr.DataArray):
            arr = img.values
        else:
            arr = img
    except Exception:
        arr = img

    # Orient to HWC and convert to float64 for numerics
    if arr.shape[0] in (3,4):  # (c,y,x)
        I = _as_hwc(arr)
    elif arr.shape[-1] in (3,4):  # (h,w,c)
        I = arr[..., :3]
    else:
        raise ValueError("Provide an RGB image as (c,y,x) or (h,w,c).")

    h, w, _ = I.shape
    I = I.astype(np.float64, copy=False)

    # Auto Io if requested
    Io_val = _auto_Io(I) if (isinstance(Io, str) and Io == "auto") else float(Io)

    # ---- Optical density for all pixels (in float32 to save RAM) ----
    # add 1 to avoid log(0) on pure white
    OD = -np.log((I + 1.0) / Io_val).astype(np.float32, copy=False)

    # ---- Choose pixels for basis estimation ----
    if mask is not None:
        if mask.shape != (h, w):
            raise ValueError("mask must have shape (h, w).")
        sel = mask.ravel()
    else:
        sel = np.ones((h*w,), dtype=bool)

    ODsel = OD.reshape(-1, 3)[sel]
    # Remove near-white rows (low OD in all channels)
    good = ~(ODsel < beta).all(axis=1)
    ODhat = ODsel[good]
    # Subsample to control memory/time
    if ODhat.shape[0] > sample_max:
        idx = np.random.choice(ODhat.shape[0], sample_max, replace=False)
        ODsub = ODhat[idx]
    else:
        ODsub = ODhat

    # ---- Eigen/basis (Macenko) ----
    # covariance over columns (RGB)
    w_eig, v_eig = np.linalg.eigh(np.cov(ODsub.T))
    order = np.argsort(w_eig)  # ascending
    v_eig = v_eig[:, order]    # columns = eigenvectors
    # project onto top-2 eigvecs
    That = ODsub @ v_eig[:, 1:3]
    phi = np.arctan2(That[:, 1], That[:, 0])
    minPhi = np.percentile(phi, alpha)
    maxPhi = np.percentile(phi, 100 - alpha)
    vMin = v_eig[:, 1:3] @ np.array([np.cos(minPhi), np.sin(minPhi)])
    vMax = v_eig[:, 1:3] @ np.array([np.cos(maxPhi), np.sin(maxPhi)])
    # put Hematoxylin first, Eosin second (heuristic)
    HE = np.stack([vMin, vMax], axis=1)
    if HE[0, 0] < HE[0, 1]:
        HE = HE[:, ::-1]

    # Reference matrix from Macenko (optional to tune)
    HERef = np.array([[0.5626, 0.2159],
                      [0.7201, 0.8012],
                      [0.4062, 0.5581]], dtype=np.float64)
    maxCRef = np.array([1.9705, 1.0308], dtype=np.float64)

    # ---- Solve C for all pixels in batches: OD = HE*C  ----
    Y = OD.reshape(-1, 3).T  # (3, N)
    gc.collect()
    C = _batch_lstsq(HE, Y, batch=lstsq_batch)  # (2, N)
    gc.collect()

    # ---- Scale concentrations to reference ----
    maxC = np.array([np.percentile(C[0, :], 99), np.percentile(C[1, :], 99)], dtype=np.float64)
    scale = (maxC / maxCRef).reshape(2, 1)
    C2 = C / np.where(scale == 0.0, 1.0, scale)

    # ---- Reconstruct normalized RGB & H/E images ----
    Inorm = (Io_val * np.exp(-HERef @ C2)).T.reshape(h, w, 3)
    Inorm = np.clip(Inorm, 0, 255).astype(np.uint8)

    H_img = (Io_val * np.exp(-(HERef[:, [0]] @ C2[[0], :]))).T.reshape(h, w, 3)
    H_img = np.clip(H_img, 0, 255).astype(np.uint8)

    E_img = (Io_val * np.exp(-(HERef[:, [1]] @ C2[[1], :]))).T.reshape(h, w, 3)
    E_img = np.clip(E_img, 0, 255).astype(np.uint8)

    Inorm_cyx = _as_cyx(Inorm)

    if return_HE_H_E:
        return Inorm_cyx, HE.astype(np.float64), H_img, E_img
    return Inorm_cyx
###------------------------------------------------------------------------###
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy.stats import t as tdist, rankdata, hypergeom
from statsmodels.stats.multitest import multipletests
from skimage.filters import threshold_otsu
from sklearn.mixture import GaussianMixture


def threshold_by_gmm_log(y, sample=300_000, random_state=0):
    rng = np.random.default_rng(random_state)
    y = y[np.isfinite(y)]
    if y.size > sample:
        y = rng.choice(y, size=sample, replace=False)
    z = np.log1p(y).reshape(-1,1)
    gmm = GaussianMixture(n_components=2, random_state=random_state).fit(z)
    m = gmm.means_.ravel(); s = np.sqrt(gmm.covariances_.ravel()); w = gmm.weights_.ravel()
    order = np.argsort(m); m, s, w = m[order], s[order], w[order]
    grid = np.linspace(z.min(), z.max(), 2048).ravel()
    n0 = w[0] * np.exp(-0.5*((grid-m[0])/s[0])**2) / (s[0]+1e-12)
    n1 = w[1] * np.exp(-0.5*((grid-m[1])/s[1])**2) / (s[1]+1e-12)
    thr = float(np.expm1(grid[np.argmin(np.abs(n0-n1))]))
    return thr

def threshold_by_target_rate(y, target_pos_rate=0.10):
    y = y[np.isfinite(y)]
    return float(np.quantile(y, 1.0 - float(target_pos_rate)))

def threshold_by_otsu_log(y):
    y = y[np.isfinite(y)]
    z = np.log1p(y)
    thr_z = threshold_otsu(z)
    return float(np.expm1(thr_z))

def choose_protein_threshold(y, strategy="quantile", *,
                             target_pos_rate=0.10, bg_mask=None,
                             alpha=1e-3, random_state=0):
    y = np.asarray(y)
    if strategy == "quantile":
        return threshold_by_target_rate(y, target_pos_rate)
    elif strategy == "otsu":
        return threshold_by_otsu_log(y)
    elif strategy == "gmm":
        return threshold_by_gmm_log(y, random_state=random_state)
    elif strategy == "background":
        if bg_mask is None:
            raise ValueError("bg_mask is required for strategy='background'")
        return threshold_by_background_fpr(y, bg_mask, alpha)
    else:
        raise ValueError(f"Unknown strategy: {strategy}")

# =========================
# Helpers
# =========================
def _row_normalize_csr(W):
    W = W.tocsr(copy=True)
    rs = np.asarray(W.sum(axis=1)).ravel()
    rs[rs == 0.0] = 1.0
    return sp.diags(1.0 / rs) @ W

def _get_tqdm(total, desc, enable=True):
    try:
        from tqdm.auto import tqdm
        return tqdm(total=total, desc=desc, disable=not enable)
    except Exception:
        class Dummy:
            def update(self, *a, **k): pass
            def set_postfix_str(self, *a, **k): pass
            def close(self): pass
        return Dummy()

def _to_indices_from_names_or_mask(var_names, sel):
    """Convert a list of gene names / numpy bool mask / int indices to a 1D numpy int array."""
    if sel is None:
        return None
    import numpy as _np
    if isinstance(sel, (list, tuple)):
        # could be names or ints
        if len(sel) == 0:
            return _np.array([], dtype=int)
        if isinstance(sel[0], (int, np.integer)):
            return _np.array(sel, dtype=int)
        # assume names
        return _np.array([int(var_names.get_loc(g)) for g in sel], dtype=int)
    sel = _np.asarray(sel)
    if sel.dtype == bool:
        return _np.flatnonzero(sel)
    return sel.astype(int)

# =========================
# A) Non-spatial Jaccard (+ significance & effect-size)
# =========================
def jaccard_metrics_with_significance(
    adata,
    *,
    protein_key: str,
    protein_value: float,
    protein_mode: str = "value_ge",   # "value_ge" or "value_gt"
    gene_mode: str = "present",       # "present" -> counts > 0
    in_tissue_key: str = None
) -> pd.DataFrame:
    """
    Per-gene: TP/FP/FN/TN, precision/recall/specificity, FPR/FDR/FNR, F1, MCC, balanced accuracy,
    Jaccard + expected Jaccard + lift, hypergeometric p & FDR.
    """
    # Row mask
    y = adata.obs[protein_key].to_numpy()
    valid = np.isfinite(y)
    if in_tissue_key is not None and in_tissue_key in adata.obs:
        valid &= adata.obs[in_tissue_key].to_numpy().astype(bool)
    X = adata.X.tocsr()[valid]
    yv = y[valid]
    n = X.shape[0]
    if n == 0:
        raise ValueError("No valid rows after masking.")

    # Protein positives
    b = (yv >= protein_value) if protein_mode == "value_ge" else (yv > protein_value)
    b = b.astype(bool)
    nb = int(b.sum())
    pos_rate_protein = nb / n

    # Gene positives / intersection
    if gene_mode != "present":
        raise ValueError("Only gene_mode='present' is implemented.")
    na = np.asarray(X.getnnz(axis=0), dtype=np.int64).ravel()           # |A|
    tp = np.asarray(X[b].getnnz(axis=0), dtype=np.int64).ravel()        # |A ∩ B|

    # Confusion table parts (all int)
    fp = na - tp                          # A & ~B
    fn = nb - tp                          # ~A & B
    tn = n - na - nb + tp                 # ~A & ~B

    # Jaccard (IoU)
    union = na + nb - tp
    jacc = np.divide(tp, union, out=np.zeros_like(tp, dtype=float), where=union > 0)

    # Expected Jaccard under independence
    exp_tp = na * (nb / n)
    exp_union = na + nb - exp_tp
    j0 = np.divide(exp_tp, exp_union, out=np.zeros_like(jacc), where=exp_union > 0)
    lift = np.divide(jacc, j0, out=np.full_like(jacc, np.nan), where=j0 > 0)
    excess = jacc - j0

    # Rates & scores
    precision = np.divide(tp, na, out=np.zeros_like(jacc), where=na > 0)                   # PPV
    recall    = np.divide(tp, nb, out=np.zeros_like(jacc), where=nb > 0)                   # TPR / sensitivity
    specificity = np.divide(tn, tn + fp, out=np.zeros_like(jacc), where=(tn + fp) > 0)     # TNR
    fpr = 1.0 - specificity
    fnr = np.divide(fn, fn + tp, out=np.zeros_like(jacc), where=(fn + tp) > 0)
    fdr = 1.0 - precision
    npv = np.divide(tn, tn + fn, out=np.zeros_like(jacc), where=(tn + fn) > 0)
    f1  = np.divide(2*tp, 2*tp + fp + fn, out=np.zeros_like(jacc), where=(2*tp + fp + fn) > 0)

    # Matthews correlation coefficient (robust for imbalance)
    mcc_den = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)).astype(float)
    mcc = np.divide(tp*tn - fp*fn, mcc_den, out=np.zeros_like(jacc), where=mcc_den > 0)

    # Balanced accuracy
    bal_acc = (recall + specificity) / 2.0

    # “Outside” share: gene positives that lie outside protein region
    outside_share = np.divide(fp, na, out=np.zeros_like(jacc), where=na > 0)  # = 1 - precision

    # Hypergeometric tail p-values and FDR
    pval = hypergeom.sf(tp - 1, n, na, nb)   # P[TP* >= tp]
    qval = multipletests(pval, method="fdr_bh")[1]

    return pd.DataFrame({
        "gene": adata.var_names.to_numpy(),
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "na": na, "nb": nb, "n": n,
        "pos_rate_gene": na / n, "pos_rate_protein": pos_rate_protein,
        "jaccard": jacc, "jaccard_expected": j0, "jaccard_lift": lift, "jaccard_excess": excess,
        "precision": precision, "recall": recall, "specificity": specificity,
        "fpr": fpr, "fnr": fnr, "fdr": fdr, "npv": npv,
        "f1": f1, "mcc": mcc, "balanced_accuracy": bal_acc,
        "outside_share": outside_share,
        "pval_hypergeom": pval, "qval_jaccard": qval,
        "protein_threshold": protein_value, "protein_mode": protein_mode,
    })

# =========================
# B) Spatial spread (tile overlap fraction)
# =========================
def spatial_tile_overlap_fraction(
    adata,
    *,
    protein_key: str,
    protein_threshold: float,
    protein_mode: str = "value_ge",
    spatial_key: str = "spatial",
    in_tissue_key: str = None,
    n_bins_xy=(40, 40),
) -> pd.DataFrame:
    """
    tile_overlap_frac = (# tiles with ≥1 (gene & protein) bin) / (# tiles with ≥1 protein-positive bin)
    Also returns raw tile counts.
    """
    y = adata.obs[protein_key].to_numpy()
    valid = np.isfinite(y)
    if in_tissue_key is not None and in_tissue_key in adata.obs:
        valid &= adata.obs[in_tissue_key].to_numpy().astype(bool)
    X = adata.X.tocsr()[valid]
    coords = adata.obsm[spatial_key][valid]
    yv = y[valid]
    n = X.shape[0]
    if n == 0:
        raise ValueError("No valid rows after masking.")

    b = (yv >= protein_threshold) if protein_mode == "value_ge" else (yv > protein_threshold)
    b = b.astype(bool)
    nb = int(b.sum())
    if nb == 0:
        raise ValueError("No protein-positive bins at this threshold.")

    # make tiles
    nx, ny = n_bins_xy
    x, z = coords[:, 0], coords[:, 1]
    x_edges = np.linspace(x.min(), x.max(), nx + 1)
    z_edges = np.linspace(z.min(), z.max(), ny + 1)
    ix = np.clip(np.digitize(x, x_edges) - 1, 0, nx - 1)
    iz = np.clip(np.digitize(z, z_edges) - 1, 0, ny - 1)
    tile_id = ix * ny + iz

    # tiles with any protein-positive bin
    tiles_prot, inv_tiles = np.unique(tile_id[b], return_inverse=True)
    n_tiles_prot = tiles_prot.size

    # T: (n_tiles_prot × nb) one-hot (one 1 per column)
    T = sp.csr_matrix(
        (np.ones(inv_tiles.size, dtype=np.int8), (inv_tiles, np.arange(inv_tiles.size))),
        shape=(n_tiles_prot, inv_tiles.size)
    )

    # gene presence within protein-positive rows
    Gpos = X[b].sign().astype(np.int8)              # (nb × n_genes)

    # tiles with any gene∧protein per gene
    tile_gene_any = (T @ Gpos).sign()               # (n_tiles_prot × n_genes)
    tiles_with_overlap = np.asarray(tile_gene_any.sum(axis=0)).ravel().astype(np.int64)
    frac = tiles_with_overlap / float(n_tiles_prot)

    return pd.DataFrame({
        "gene": adata.var_names.to_numpy(),
        "tiles_with_overlap": tiles_with_overlap,
        "tiles_with_protein": np.full(adata.n_vars, n_tiles_prot, dtype=np.int64),
        "tile_overlap_frac": frac
    })

# =========================
# C) Fast spatial correlation (presence vs smoothed protein)
#     * Spearman: rank(smoothed protein) vs presence
#     * Pearson : smoothed protein vs presence
#     * Permutations can target a specific gene set (indices/names/mask)
# =========================
def fast_spatial_corr_presence(
    adata,
    *,
    protein_key: str,
    W=None,                         # CSR; if None, use adata.obsp['spatial_connectivities']
    smooth: bool = True,            # neighbor-average
    include_self: bool = False,     # if True, (I+W) before row-normalization
    corr_method: str = "spearman",  # "spearman" or "pearson"
    use_mkl: bool = True,           # try sparse_dot_mkl for CSR^T @ vector
    threads: int = None,            # MKL threads
    # permutations (optional)
    permute_genes=None,             # names / indices / boolean mask; if None, use top-K fallback
    return_permutation_for_top: int = 0,
    n_perm: int = 0,
    random_state: int = 0,
    progress: bool = True
) -> pd.DataFrame:
    """
    Returns per-gene correlation ('rho' for Spearman or 'r_pearson') + t-approx p-values (all genes).
    If permute_genes is provided, computes permutation p-values for that subset; otherwise uses top-K.
    """
    pbar = _get_tqdm(3 + (1 if n_perm > 0 and (permute_genes is not None or return_permutation_for_top > 0) else 0),
                     desc=f"Spatial {corr_method.title()} (presence)", enable=progress)

    # 0) subset to finite protein rows
    y = adata.obs[protein_key].to_numpy().astype(np.float64)
    valid = np.isfinite(y)
    if not np.all(valid):
        adata = adata[valid].copy()
        y = y[valid]
        if W is not None:
            W = W[valid][:, valid]
    n = adata.n_obs
    if n < 3:
        raise ValueError("Not enough observations.")

    # 1) spatial smoothing
    if W is None:
        if "spatial_connectivities" not in adata.obsp:
            raise KeyError("Provide W or compute adata.obsp['spatial_connectivities'] first.")
        W = adata.obsp["spatial_connectivities"].tocsr()
    if smooth:
        W_use = W + (sp.identity(W.shape[0], format="csr") if include_self else 0)
        y_s = _row_normalize_csr(W_use) @ y
    else:
        y_s = y
    pbar.update(1); pbar.set_postfix_str("smoothed")

    # 2) transform target vector for correlation
    if corr_method.lower() == "spearman":
        vec = rankdata(y_s, method="average").astype(np.float64)  # 1..n
        mean_vec = (n + 1.0) / 2.0
        var_vec = (n**2 - 1.0) / 12.0
        corr_col = "rho"
    elif corr_method.lower() == "pearson":
        vec = y_s.astype(np.float64)
        mean_vec = float(vec.mean())
        var_vec = float(vec.var())
        corr_col = "r_pearson"
    else:
        raise ValueError("corr_method must be 'spearman' or 'pearson'")
    std_vec = np.sqrt(var_vec)
    pbar.update(1); pbar.set_postfix_str("target ready")

    # 3) presence matrix & single sparse mat-vec
    X = adata.X.tocsr()
    G = X.sign()                                     # 0/1 CSR
    na = np.asarray(G.getnnz(axis=0), dtype=np.int64).ravel()
    p = na / n
    std_a = np.sqrt(p * (1 - p))
    ok = std_a > 0

    used_mkl = False
    if use_mkl:
        try:
            from sparse_dot_mkl import dot_product_mkl, set_mkl_threads
            if threads:
                set_mkl_threads(threads)
            sums = dot_product_mkl(G.T, vec, cast=True)
            sums = np.asarray(sums).ravel()
            used_mkl = True
        except Exception:
            used_mkl = False
    if not used_mkl:
        sums = np.asarray(G.T.dot(vec)).ravel()

    Era = sums / n
    cov = Era - mean_vec * p

    r = np.zeros(adata.n_vars, dtype=np.float64)
    denom = std_vec * std_a
    r[ok] = cov[ok] / denom[ok]
    r = np.clip(r, -1.0, 1.0)

    df = n - 2
    tden = np.maximum(1.0 - r**2, 1e-15)
    tstat = np.zeros_like(r)
    tstat[ok] = r[ok] * np.sqrt(df / tden[ok])
    pval = np.ones_like(r)
    pval[ok] = 2.0 * tdist.sf(np.abs(tstat[ok]), df)
    pbar.update(1); pbar.set_postfix_str("matvec done")

    out = pd.DataFrame({
        "gene": adata.var_names.to_numpy(),
        corr_col: r,
        "tstat": tstat,
        "pval_t": pval,
        "na": na,
        "n": n,
        "corr_method": corr_method.lower()
    }).sort_values(corr_col, ascending=False).reset_index(drop=True)

    # 4) optional permutations for a chosen subset
    if n_perm > 0:
        idx_sel = _to_indices_from_names_or_mask(adata.var_names, permute_genes)
        if (idx_sel is None or len(idx_sel) == 0) and return_permutation_for_top > 0:
            idx_sel = out.index[:min(return_permutation_for_top, adata.n_vars)].to_numpy()
        if idx_sel is not None and len(idx_sel) > 0:
            genes_sel = adata.var_names[idx_sel].to_list()
            Gk = G[:, idx_sel].astype(np.float64).tocsr()

            pk = np.asarray(Gk.getnnz(axis=0)).ravel() / n
            denomk = std_vec * np.sqrt(pk * (1 - pk))
            denomk[denomk == 0] = np.nan

            r_obs = out.set_index("gene").loc[genes_sel, corr_col].to_numpy()
            ge_count = np.zeros(len(genes_sel), dtype=np.int64)

            try:
                from tqdm.auto import tqdm
                perm_bar = tqdm(range(n_perm), desc=f"Permuting {len(genes_sel)} genes", disable=not progress, leave=False)
            except Exception:
                perm_bar = range(n_perm)

            rng = np.random.default_rng(random_state)
            for _ in perm_bar:
                perm = rng.permutation(n)
                vec_perm = vec[perm]
                if used_mkl:
                    sp_sum = np.asarray(dot_product_mkl(Gk.T, vec_perm, cast=True)).ravel()
                else:
                    sp_sum = np.asarray(Gk.T.dot(vec_perm)).ravel()
                Era_perm = sp_sum / n
                cov_perm = Era_perm - mean_vec * pk
                r_perm = cov_perm / denomk
                r_perm = np.nan_to_num(r_perm, nan=0.0)
                ge_count += (np.abs(r_perm) >= np.abs(r_obs)).astype(np.int64)

            p_perm = (ge_count + 1) / (n_perm + 1)  # add-one smoothing
            out["pval_perm"] = np.nan
            out.loc[out["gene"].isin(genes_sel), "pval_perm"] = p_perm

            pbar.update(1); pbar.set_postfix_str("perms done")

    pbar.close()
    return out
    
# =========================
# D) One-call wrapper:
#     * computes Jaccard + spatial spread
#     * chooses permutation genes by thresholds (if requested)
#     * computes spatial correlation (Spearman/Pearson)
#     * merges & coalesces columns, adds unified 'corr' & convenient ranks
# =========================
def _as_bool_mask_from_series(s):
    """Turn an obs column into a boolean mask robustly."""
    if s.dtype == bool:
        return s.to_numpy()
    # Treat common truthy labels as True
    truthy = {"true","1","t","yes","y","pass","keep","in","in_tissue"}
    vals = s.astype(str).str.lower()
    return vals.isin(truthy).to_numpy()
def run_spatial_corr_and_jaccard(
    adata,
    *,
    protein_key: str,
    protein_threshold: float,
    protein_mode: str = "value_ge",
    W=None,
    smooth: bool = True,
    include_self: bool = False,
    corr_method: str = "spearman",   # "spearman" or "pearson"
    use_mkl: bool = True,
    threads: int = None,
    # permutation selection by thresholds:
    permute_by_thresholds: bool = False,
    permute_lift_min: float = 2.0,
    permute_tile_frac_min: float = 0.25,
    permute_tp_min: int = 50,
    permute_specificity_min: float | None = None,   # e.g., 0.95 to drop “everywhere” genes
    permute_precision_min:   float | None = None,   # e.g., 0.05 to avoid very low PPV
    permute_max_genes: int = 2000,
    # OR fallback to top-K:
    return_permutation_for_top: int = 0,
    n_perm: int = 0,
    random_state: int = 0,
    in_tissue_key: str = None,
    n_bins_xy=(40, 40),
    progress: bool = True
) -> pd.DataFrame:
    """
    Produce one merged DataFrame with:
      - Non-spatial Jaccard & significance
      - Spatial spread (tile overlap fraction)
      - Spatial correlation (Spearman/Pearson), t-approx p and (optionally) permutation p for selected genes.
    """
    # --- ensure sliceable formats (CSR) ---
    if sp.issparse(adata.X) and sp.isspmatrix_coo(adata.X):
        # convert in-place to avoid COO slicing error
        adata.X = adata.X.tocsr()
    for lay in list(adata.layers.keys()):
        M = adata.layers[lay]
        if sp.issparse(M) and sp.isspmatrix_coo(M):
            adata.layers[lay] = M.tocsr()
    if W is not None and sp.issparse(W) and sp.isspmatrix_coo(W):
        W = W.tocsr()
    # --- build a consistent row mask once (finite protein & optional in_tissue) ---
    y = adata.obs[protein_key].to_numpy()
    valid = np.isfinite(y)
    if in_tissue_key is not None and in_tissue_key in adata.obs:
        valid &= _as_bool_mask_from_series(adata.obs[in_tissue_key])
    # Subset once; after CSR conversion, this is safe
    ad = adata[valid].copy()
    W_sub = W[valid][:, valid] if W is not None else None

    # 1) Jaccard + TN metrics
    jac = jaccard_metrics_with_significance(
        ad, protein_key=protein_key, protein_value=protein_threshold,
        protein_mode=protein_mode, gene_mode="present", in_tissue_key=None
    )

    # 2) Spatial spread
    spread = spatial_tile_overlap_fraction(
        ad, protein_key=protein_key, protein_threshold=protein_threshold,
        protein_mode=protein_mode, spatial_key="spatial",
        in_tissue_key=None, n_bins_xy=n_bins_xy
    )

    # 3) Select genes for permutations (if requested)
    permute_idx = None
    if n_perm > 0 and permute_by_thresholds:
        sel = (jac["jaccard_lift"] >= permute_lift_min) & (jac["tp"] >= permute_tp_min)
        if permute_specificity_min is not None:
            sel &= (jac["specificity"] >= permute_specificity_min)
        if permute_precision_min is not None:
            sel &= (jac["precision"] >= permute_precision_min)

        jac_sel = jac.loc[sel, ["gene"]].merge(
            spread[["gene", "tile_overlap_frac"]], on="gene", how="left"
        )
        jac_sel = jac_sel[jac_sel["tile_overlap_frac"] >= permute_tile_frac_min]

        if permute_max_genes is not None and len(jac_sel) > permute_max_genes:
            jac_sel = jac_sel.iloc[:permute_max_genes]

        permute_idx = [ad.var_names.get_loc(g) for g in jac_sel["gene"].to_list()]

    # 4) Spatial correlation (permute chosen subset, or top-K fallback)
    corr = fast_spatial_corr_presence(
        ad, protein_key=protein_key, W=W_sub, smooth=smooth, include_self=include_self,
        corr_method=corr_method, use_mkl=use_mkl, threads=threads,
        permute_genes=permute_idx,
        return_permutation_for_top=0 if permute_idx is not None else return_permutation_for_top,
        n_perm=n_perm, random_state=random_state, progress=progress
    )
    corr["qval_t"] = multipletests(corr["pval_t"], method="fdr_bh")[1]
    corr["corr"] = corr["rho"] if "rho" in corr.columns else corr["r_pearson"]

    # 5) Merge & coalesce; add convenience ranks
    merged = jac.merge(spread, on="gene", how="left").merge(
        corr, on="gene", how="inner", suffixes=("_jacc", "_corr")
    )

    # coalesce na/n if both sides exist
    def _coalesce(df, base, prefer="jacc"):
        a, b = f"{base}_jacc", f"{base}_corr"
        if a in df.columns and b in df.columns:
            df[base] = df[a] if prefer == "jacc" else df[b]
            df.drop(columns=[a, b], inplace=True)
    for base in ("na", "n"):
        _coalesce(merged, base, prefer="jacc")

    merged["rank_lift"] = 1.0 - merged["jaccard_lift"].rank(pct=True, method="average")
    merged["rank_abs_corr"] = 1.0 - np.abs(merged["corr"]).rank(pct=True, method="average")
    merged["rank_mean"] = (merged["rank_lift"] + merged["rank_abs_corr"]) / 2.0

    sort_key = "rho" if ("rho" in merged.columns and corr_method == "spearman") else \
               ("r_pearson" if "r_pearson" in merged.columns else "corr")
    merged = merged.sort_values(
        ["qval_t", "qval_jaccard", sort_key, "jaccard_lift"],
        ascending=[True, True, False, False]
    ).reset_index(drop=True)

    return merged

