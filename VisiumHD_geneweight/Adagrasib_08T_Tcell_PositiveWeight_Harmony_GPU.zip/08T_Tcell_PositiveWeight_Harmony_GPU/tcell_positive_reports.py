"""Portable HTML entry point and compact return files for the 08T experiment."""
from __future__ import annotations

import html
import json
import os
from pathlib import Path
import zipfile

import numpy as np
import pandas as pd

from tcell_weighted_workflow import save_json


def write_main_dominance_audit(review_dir):
    """Flag near-single-transcript patterns from existing all-cell summaries."""
    directory = Path(review_dir)
    table = pd.read_csv(directory / "marker_statistics.csv.gz")
    audit = table[table.gene.isin(("Trac", "Nkg7", "Ccl5"))].copy()
    audit["mean_count_when_detected"] = audit.mean_observed_counts.div(
        audit.fraction_positive.replace(0, np.nan))
    audit["near_universal_detection"] = audit.fraction_positive >= .95
    audit["low_mean_count_when_detected"] = audit.mean_count_when_detected <= 1.5
    audit["near_single_transcript_pattern"] = (
        audit.near_universal_detection & audit.low_mean_count_when_detected)
    audit.to_csv(directory / "single_gene_dominance_audit.csv", index=False)
    return audit


def build_report_index(run_root, experiment, review_dirs, timings=None):
    root = Path(run_root)
    audit = pd.read_csv(Path(experiment["experiment_dir"]) / "gene_weight_audit.csv")
    selected = audit[audit.gene.isin(experiment["boost_genes"])][
        ["gene", "ratio", "baseline_weight", "positive_multiplier", "positive_weight"]]
    descriptions = {
        "main": "Main comparison: ratio baseline versus positive weighting",
        "heldout": "Companion comparison: both embeddings withhold the same five genes",
        "companion": "Held-out companion diagnostics and single-gene audit",
    }
    links = []
    for label, directory in review_dirs.items():
        directory = Path(directory)
        for name in ("review.html", "companion_review.html"):
            path = directory / name
            if path.is_file():
                relative = html.escape(os.path.relpath(path, root))
                text = html.escape(descriptions.get(label, label))
                links.append(f'<li><a href="{relative}">{text}</a></li>')
                break
    dominance_html = ""
    if "main" in review_dirs:
        dominance = write_main_dominance_audit(review_dirs["main"])
        flagged = dominance[dominance.near_single_transcript_pattern]
        columns = ["method", "clustering", "cluster", "n_cells", "gene", "fraction_positive", "mean_count_when_detected"]
        dominance_html = ("<h2>Main comparison: single-gene review prompts</h2>"
                         "<p>Detection in at least 95% of the group with mean count among detected cells at most 1.5. "
                         "These flags identify patterns to inspect; they do not establish artifacts or subtype identity.</p>"
                         + (flagged[columns].to_html(index=False, float_format=lambda x:f'{x:.4g}', escape=True)
                            if len(flagged) else "<p>No groups met both descriptive thresholds.</p>"))
    document = f'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>08T positive weighting</title>
<style>body{{font:17px/1.6 system-ui,sans-serif;max-width:1100px;margin:35px auto;padding:24px;color:#20334a}}
table{{border-collapse:collapse}}td,th{{padding:9px 14px;border:1px solid #ccd6df}}th{{background:#edf3f6}}
a{{color:#126b91}}.note{{background:#f0f5f8;padding:18px;border-left:4px solid #126b91}}</style></head><body>
<h1>08T · Positive lineage weighting</h1>
<p>{experiment['n_cells']:,} cells; ratio midpoint {experiment['midpoint']:g};
{experiment['boost_factor']:g}× distance contribution for the four prespecified markers.</p>
<h2>Reports</h2><ol>{''.join(links)}</ol>
<h2>Applied weights</h2>{selected.to_html(index=False,float_format=lambda x:f'{x:.4g}',escape=True)}
{dominance_html}
<p class="note">The main comparison uses all eligible features. The companion comparison reserves
Cd8b1, Il2ra, Ctla4, Ikzf2 and Tnfrsf18 by assigning them zero input contribution in both embeddings,
then reads their original expression. Compare each pair internally. Held-out evidence supports a relative
check of CD8/Treg coherence; it does not establish independent CD4 identity or cell-typing accuracy.</p>
<p>Every marker plot uses original counts and unweighted normalized expression. All input cells are retained.
No subtype labels are forced. The same per-gene ratio weights are applied to every T cell; this is
feature guidance and does not estimate a cell-specific endogenous transcript fraction.</p>
<p>Trac, Nkg7, Ccl5 and shared cell-state programs have no extra boost. Review sample/depth consistency
and groups dominated by single-transcript detection alongside the marker plots.</p></body></html>'''
    path = root / "review.html"
    path.write_text(document, encoding="utf-8")
    if timings is not None:
        save_json(root / "notebook_timings.json", timings)
    return path


def make_return_package(run_root, experiment, review_dirs=None, max_megabytes=25):
    """Pack aggregate diagnostics and prioritized figures, excluding large assays."""
    root = Path(run_root)
    root.mkdir(parents=True, exist_ok=True)
    review_dirs = {} if review_dirs is None else review_dirs
    archive = root / "08T_return_to_chat.zip"
    exp_root = Path(experiment["experiment_dir"])
    cache = Path(experiment["base_cache_dir"])
    candidates = []
    for name in ("experiment.json", "gene_weight_audit.csv", "panel_availability.csv"):
        candidates.append((exp_root / name, "experiment/" + name, 0))
    candidates.append((exp_root / "weight_audit.png", "experiment/weight_audit.png", 4))
    candidates.append((cache / "cache_manifest.json", "cache/base_cache_manifest.json", 0))
    for name in ("launch.json", "comparison_complete.json", "comparison_status.json",
                 "gpu_settings.json", "notebook_timings.json"):
        candidates.append((root / name, name, 0))
    for variant in experiment["variants"]:
        for name in ("run_metadata.json", "console.log", "imported_baseline.json", "completion.json"):
            candidates.append((root / variant / name, variant + "/" + name, 0))
    omitted = []
    for label, directory in review_dirs.items():
        directory = Path(directory)
        for path in directory.rglob("*"):
            if not path.is_file() or path.suffix in (".h5ad", ".npz", ".html"):
                continue
            relative = label + "/" + str(path.relative_to(directory))
            if path.name in ("observed_marker_evidence.csv.gz", "umap_display_cell_ids.csv.gz"):
                omitted.append({"file": relative, "reason": "per-cell table; aggregate diagnostics included"})
                continue
            priority = 1
            if path.suffix.lower() == ".png":
                priority = 5 if label == "companion" else 20
                if "umap_clusters" in path.name or "umap_lineage_markers" in path.name:
                    priority = 8 if label == "main" else 12
                if "leiden_0_4_lineage_mean_log1p" in path.name:
                    priority = 10 if label == "main" else 15
            candidates.append((path, relative, priority))
    selected, total = [], 0
    budget = int(float(max_megabytes) * 1_000_000)
    if budget <= 0:
        raise ValueError("A positive compact-package size is required.")
    for path, name, _ in sorted(candidates, key=lambda v: (v[2], v[1])):
        if not path.is_file():
            continue
        size = path.stat().st_size
        if total + size > budget:
            omitted.append({"file": name, "reason": "compact return budget", "bytes": size})
            continue
        selected.append((path, name))
        total += size
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for path, name in selected:
            handle.write(path, name)
        links, figures = [], []
        for path, name in selected:
            safe = html.escape(name)
            if path.suffix.lower() == ".png":
                figures.append(f'<h2>{safe}</h2><img loading="lazy" src="{safe}" style="max-width:100%">')
            else:
                links.append(f'<li><a href="{safe}">{safe}</a></li>')
        page = ('<!doctype html><html><meta charset="utf-8"><title>08T compact review</title>'
                '<body style="font:16px/1.5 system-ui;max-width:1500px;margin:auto;padding:25px">'
                '<h1>08T compact return review</h1><p>Original marker expression and all-cell summaries. '
                'See PACKAGE_CONTENTS.json for omitted figures. The complete report remains on the instance.</p>'
                '<ul>' + ''.join(links) + '</ul>' + ''.join(figures) + '</body></html>')
        handle.writestr("compact_review.html", page)
        handle.writestr("PACKAGE_CONTENTS.json", json.dumps({
            "files": [name for _, name in selected], "omitted": omitted,
            "matrix_data_included": False, "selected_uncompressed_bytes": total,
            "complete_local_reports": {str(k): str(v) for k, v in review_dirs.items()},
        }, indent=2))
    print(f"Return file: {archive} ({archive.stat().st_size/1e6:.1f} MB)", flush=True)
    return archive
