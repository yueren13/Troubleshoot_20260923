# 08T — Positive lineage weighting with GPU PCA and Harmony

Project: **Adagrasib_mouse_project_VisiumHD_2026**  
Release: **1.0.0**

## Run it

1. Place `08T_Tcell_PositiveWeight_Harmony_GPU.ipynb` beside the working 08S notebook, or in the original project folder.
2. Select the same working RAPIDS GPU Python kernel.
3. Choose **Run All**. The default midpoint is **0.60** and the positive distance-weight multiplier is **3.0**.
4. Open the linked report and return **08T_return_to_chat.zip**.

The notebook is standalone: all six helpers are embedded and restored automatically. The ZIP also contains readable helper files. No installation, H5AD picker or analysis-mode selection is added. If discovery needs a path, set `PROJECT_DIR` to the original folder containing `ct26_analysis_config.json` and `inputs/pipeline_config.json`, or to the completed 08O output folder containing `08O_latest_result.json`.

## The experiment

The successful 08S ratio curve remains the baseline:

`baseline_distance_weight = 1 / (1 + (neighbor_to_T_ratio / 0.60)**2)`

For **Cd4, Cd8a, Cd8b1 and Foxp3**, the main guided variant multiplies that distance weight by **3**. Every other eligible gene retains its existing ratio weight. The PCA features are multiplied by the square root of the effective distance weight, so a threefold distance contribution increases feature amplitude by approximately **1.732**. No gene-wise standardization follows the weighting.

Trac, Nkg7, Ccl5, shared naive/memory genes, cytotoxic genes, cycling genes and activation genes receive no extra boost. All cells in the completed T cell 1 + T cell 2 input participate. The broad gene set, original full-library log1p normalization, GPU settings and original marker assays are retained.

This is guided feature weighting. It does not correct molecule counts, estimate a cell-specific endogenous fraction, recover undetected transcripts, or automatically annotate all cells. Equal per-gene boosts do not equalize CD4/CD8/Treg program influence.

## Two matched comparisons run automatically

| Variant | Ratio weights | Positive boost | Reserved companions contribute to embedding? |
|---|---|---|---|
| `baseline060` | Midpoint 0.60 | None | Yes |
| `positive060` | Midpoint 0.60 | Cd4, Cd8a, Cd8b1, Foxp3 | Yes |
| `heldout_baseline060` | Midpoint 0.60 | None | No |
| `heldout_positive060` | Midpoint 0.60 | Same boost, with held-out exclusion taking precedence | No |

The reserved genes are **Cd8b1, Il2ra, Ctla4, Ikzf2 and Tnfrsf18**. Both diagnostic embeddings give them exactly zero input weight. Their original expression is retained for subsequent review. Zero columns remain in the stored feature matrix for provenance but make no contribution to centered PCA or the downstream graph.

The companion check asks whether Cd8a-associated structure gains support from reserved Cd8b1, and whether Foxp3-associated structure gains support from reserved Treg-associated companions. It compares the two held-out variants against each other. It does **not** independently validate CD4 identity or establish classification accuracy.

## GPU execution and caching

The notebook retains the working 08S sparse GPU PCA, GPU Harmony, CAGRA neighbors, Leiden and UMAP implementation, including the explicit NumPy-to-CuPy preflight transfer and compatible sparse `astype` call. A small synthetic preflight now also exercises positive weights above one and exact-zero weights.

| Setting | Default |
|---|---|
| PCA | 50 centered PCs; sparse randomized GPU calculation |
| Randomized approximation | 20 extra dimensions, 3 power iterations |
| Harmony | `sample_id`, theta 1.0, original Harmony flavor |
| Harmony iteration limits | 100 internal clusters, 10 outer and 20 inner iterations |
| Neighbor graph | 30 neighbors, GPU CAGRA |
| Leiden | 0.2, 0.4, 0.6 |
| UMAP | 200 iterations, minimum distance 0.3 |
| Seed | 0 |
| GPU-stage allowance | 100 minutes; preparation and reports add time |

Each variant runs in a fresh process. Up to four visible GPU cards can run independent variants; one visible card runs them sequentially. Device visibility is respected, and VRAM is not pooled across cards. The matrix stays sparse, with only thin dense PCA working arrays.

The original 08S prepared matrix is reused when compatible. New variants share those immutable assay bytes and have separate weight tables and manifests. A fully compatible completed 0.60 baseline is copied into the 08T result folder; the old result is not modified. Compatibility checks include ordered cells/genes/samples, matrix identity, applied float32 weights, settings, package versions, embedding contents and completion receipts. A matching filename alone is insufficient.

Changing the boost creates a new experiment. Rerunning the same configuration resumes compatible completed work and checkpoints. If startup or a GPU run fails, the notebook links a small diagnostic ZIP when possible.

The prior cached 08S run took approximately 4.3 minutes, but this expanded four-variant experiment has not been benchmarked on the user's instance. Runtime depends on cache reuse, visible GPUs, startup compilation and reporting.

## Outputs

New analyses are under **19_tcell_positive_weight_harmony**. Convenient report copies are under **08T_results** in the notebook working folder. The report entry page links:

- The main ratio-baseline versus positive-weighting comparison.
- The paired held-out comparison.
- Companion-marker diagnostics and a single-gene detection audit.

Dot size uses original count-positive fractions; dot color uses original unweighted log1p expression including zeros. All cells contribute to summaries. Only UMAP displays are limited to 120,000 reproducibly selected cells. The main comparison includes lineage dotplots at all three resolutions, plus T-cell state, NK/environmental, sample, condition and depth review. The held-out overview focuses on resolution 0.4.

The companion neighbor score subtracts each neighbor's sample/depth-stratum detection expectation, contrasts guide-positive and guide-negative focal cells within their own sample/depth strata, then averages eligible shared strata and samples equally. It reports a descriptive difference in percentage points and coverage. It excludes self-edges and makes no significance or accuracy claim. Full-library normalization is shared, so this isolates explicit feature contributions rather than all possible statistical dependence.

Trac/Nkg7/Ccl5 groups with detection in at least 95% of cells and mean count among detected cells at most 1.5 are flagged for inspection in both the main and companion comparisons. These are review prompts, not automatic artifact calls.

`08T_return_to_chat.zip` includes gene weights, aggregate marker/cluster/sample/depth tables, companion checks, run metadata, timings and selected figures. It excludes large matrices, embedding H5ADs and per-cell evidence/display tables. Selected files are capped near 25 MB before compression; omitted figures are listed in `PACKAGE_CONTENTS.json`.

## How to interpret the result

Look for multi-gene coherence, held-out companion support, consistency across samples and comparable depth groups, and limited dependence on isolated transcript detection. A more separated UMAP, more clusters or higher internal marker purity alone does not establish lineage identity. Treatment differences should remain interpretable; stronger sample or condition mixing is not automatically an improvement. Cluster IDs are arbitrary across variants and resolutions.

## Included code

- Standalone notebook with embedded helper source.
- `tcell_weighted_workflow.py`: the established source discovery, preparation and preflight.
- `tcell_weighted_gpu.py`: extended GPU engine supporting boosts and held-out weights.
- `tcell_weighted_review.py`: original-expression marker and technical review.
- `tcell_positive_workflow.py`: isolated variants, safe baseline reuse and GPU scheduling.
- `tcell_positive_review.py`: reserved-companion and single-gene diagnostics.
- `tcell_positive_reports.py`: report entry point and compact return package.
- `VALIDATION.md` and `MANIFEST.json`: completed checks, limitations and exact file hashes.

## Primary references

- Randomized matrix decompositions: https://arxiv.org/abs/0909.4061
- GPU Harmony: https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.harmony_integrate.html
- GPU neighbors: https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.neighbors.html
- Mouse T-cell lineage/state atlas: https://doi.org/10.1038/s41467-021-23324-4

The positive-weighting panel and multiplier are a prespecified experiment for this project, not a published replacement for cell typing or an implementation of SAM.
