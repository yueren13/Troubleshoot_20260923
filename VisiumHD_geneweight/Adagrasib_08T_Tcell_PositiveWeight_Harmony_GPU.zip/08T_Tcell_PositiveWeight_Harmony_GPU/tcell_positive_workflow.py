"""08T positive-weight experiment: immutable assays, isolated variants and GPUs.

Every variant retains every 08S cell. Fixed feature weights are not corrected
counts. The companion-marker pair gives held-out genes exactly zero contribution
to PCA; their original counts remain available in the shared review assays.
"""
from __future__ import annotations

from collections import OrderedDict
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_gpu as gpu
import tcell_weighted_workflow as base

VERSION = "08T-positive-workflow-1.0.0"
DEFAULT_BOOST_GENES = ("Cd4", "Cd8a", "Cd8b1", "Foxp3")
DEFAULT_HELDOUT_GENES = ("Cd8b1", "Il2ra", "Ctla4", "Ikzf2", "Tnfrsf18")
VARIANT_NAMES = ("baseline060", "positive060", "heldout_baseline060", "heldout_positive060")
SHARED_ASSAYS = ("lognorm_features.npz", "obs.csv.gz", "marker_counts.npz",
                 "marker_log1p.npz", "marker_genes.csv")


def _now():
    return datetime.now(timezone.utc).isoformat()


def _gene_list(values, name):
    if isinstance(values, str):
        raise TypeError(f"{name} must be a sequence of gene symbols, not one string.")
    values = tuple(values)
    if not values or any(not isinstance(g, str) or not g or g != g.strip() for g in values):
        raise ValueError(f"{name} must contain nonempty exact gene symbols.")
    if len(set(values)) != len(values):
        raise ValueError(f"{name} must not contain duplicate genes.")
    return values


def _link_immutable(source, destination):
    """Only immutable input assays may be hardlinked; result files are copied."""
    source, destination = Path(source), Path(destination)
    if destination.exists():
        destination.unlink()
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def prepare_experiment(base_cache_dir, *, boost_factor=3.0, midpoint=0.60,
                       boost_genes=DEFAULT_BOOST_GENES, heldout_genes=DEFAULT_HELDOUT_GENES,
                       output_root=None):
    """Create four weight specifications sharing the unchanged 08S assays.

    Returns a JSON-serializable experiment dictionary. The baseline uses the
    exact supplied cache. Other variants have their own small feature tables
    and manifests, with immutable large assays hardlinked or copied by copy2.
    """
    cache = Path(base_cache_dir).expanduser().resolve()
    if isinstance(boost_factor, bool) or not math.isfinite(float(boost_factor)) or float(boost_factor) < 1:
        raise ValueError("boost_factor must be finite and at least 1.")
    boost_factor = float(boost_factor)
    if not math.isfinite(float(midpoint)) or float(midpoint) <= 0:
        raise ValueError("midpoint must be finite and positive.")
    midpoint = float(midpoint)
    boost_genes, heldout_genes = _gene_list(boost_genes, "boost_genes"), _gene_list(heldout_genes, "heldout_genes")
    required = (*SHARED_ASSAYS, "features.csv", "cache_manifest.json")
    missing = [str(cache / name) for name in required if not (cache / name).is_file()]
    if missing:
        raise FileNotFoundError("A complete 08S prepared cache is required. Missing: " + ", ".join(missing))
    manifest = base._complete_cache(cache)
    if manifest is None:
        raise ValueError("The 08S cache is incomplete or its files no longer match its manifest.")
    power = float(manifest.get("power", 2.0))
    if not np.isclose(float(manifest.get("midpoint", np.nan)), midpoint, rtol=0, atol=1e-12):
        raise ValueError("The supplied base cache does not use the requested midpoint. Prepare the 0.60 cache first.")
    features = pd.read_csv(cache / "features.csv", dtype={"gene": str})
    needed = {"gene", "ratio", "weight", "variance_log1p"}
    if not needed.issubset(features):
        raise ValueError("features.csv is missing: " + ", ".join(sorted(needed - set(features))))
    if features.gene.isna().any() or features.gene.eq("").any() or features.gene.duplicated().any():
        raise ValueError("Feature genes must be nonempty, unique exact symbols.")
    ratios = pd.to_numeric(features.ratio, errors="raise").to_numpy(dtype=float)
    weights = pd.to_numeric(features.weight, errors="raise").to_numpy(dtype=np.float32)
    variance = pd.to_numeric(features.variance_log1p, errors="raise").to_numpy(dtype=float)
    if (not np.isfinite(ratios).all() or (ratios < 0).any()
            or not np.isfinite(weights).all() or (weights <= 0).any()
            or not np.isfinite(variance).all() or (variance < 0).any()):
        raise ValueError("Baseline ratios, positive weights and variances must be finite and valid.")
    expected = base.soft_weights(ratios, midpoint, power)
    if not np.allclose(weights, expected, rtol=2e-6, atol=1e-8):
        raise ValueError("Baseline feature weights do not match the declared smooth ratio curve.")
    # Reads row metadata and the stored sparse shape, not the large expression
    # array. It checks frozen cell/gene identities before new caches are made.
    _, _, _, obs, _, _, _, _ = gpu._metadata_inputs(cache, "weighted", gpu.validate_settings())
    gene_set = set(features.gene)
    marker_genes = pd.read_csv(cache / "marker_genes.csv", dtype=str)["gene"].tolist()
    marker_set = set(marker_genes)
    selected = features.gene.isin(boost_genes).to_numpy()
    heldout = features.gene.isin(heldout_genes).to_numpy()
    if not selected.any():
        raise ValueError("None of the requested positive-weight genes is an eligible embedding feature.")
    multipliers = np.where(selected, boost_factor, 1).astype(np.float32)
    positive = (weights * multipliers).astype(np.float32)
    validation_baseline = np.where(heldout, 0, weights).astype(np.float32)
    validation_positive = np.where(heldout, 0, positive).astype(np.float32)
    applied = OrderedDict(zip(VARIANT_NAMES, (weights, positive, validation_baseline, validation_positive)))
    for name, vector in applied.items():
        if not np.isfinite(vector).all() or (vector < 0).any() or np.count_nonzero(vector) < 4:
            raise ValueError(f"{name} requires finite nonnegative weights and at least four active genes.")
        if float(np.dot(vector.astype(float), variance)) <= 0:
            raise ValueError(f"{name} has no positive weighted expression variance.")
    assay_identity = {name: {"size": (cache/name).stat().st_size,
                             "mtime_ns": (cache/name).stat().st_mtime_ns}
                      for name in SHARED_ASSAYS}
    spec = {"version": VERSION, "base_cache_dir": str(cache),
            "base_cache_id": manifest["cache_id"],
            "data_identity": manifest.get("data_identity", manifest["cache_id"]),
            "baseline_weights_sha256": gpu._weight_hash(weights),
            "assay_identity": assay_identity, "midpoint": midpoint, "power": power,
            "boost_factor": boost_factor, "boost_genes": list(boost_genes),
            "heldout_genes": list(heldout_genes)}
    identity = base._digest(spec)
    root = (Path(output_root).expanduser().resolve() if output_root is not None
            else cache.parent.parent.parent / "19_tcell_positive_weight_harmony")
    directory = root / identity[:20]
    directory.mkdir(parents=True, exist_ok=True)
    labels = {
        "baseline060": f"Ratio only · midpoint {midpoint:.2f}",
        "positive060": f"Ratio + positive weights · {boost_factor:g}×",
        "heldout_baseline060": "Held-out markers · ratio only",
        "heldout_positive060": f"Held-out markers · positive {boost_factor:g}×",
    }
    variants = OrderedDict()
    for name, vector in applied.items():
        is_positive = name in {"positive060", "heldout_positive060"}
        is_heldout = name.startswith("heldout_")
        variant_cache = cache if name == "baseline060" else directory / "caches" / name
        weight_hash = gpu._weight_hash(vector)
        if name != "baseline060":
            variant_id = base._digest({"experiment_id": identity, "variant": name, "weights_sha256": weight_hash})
            previous = base._complete_cache(variant_cache)
            valid = bool(previous and previous.get("cache_id") == variant_id
                         and previous.get("engine_feature_weights_sha256") == weight_hash)
            if valid:
                stored_weights = pd.read_csv(variant_cache / "features.csv")["weight"].to_numpy(dtype=np.float32)
                valid = gpu._weight_hash(stored_weights) == weight_hash
            if not valid:
                variant_cache.mkdir(parents=True, exist_ok=True)
                (variant_cache / "cache_manifest.json").unlink(missing_ok=True)
                for filename in SHARED_ASSAYS:
                    _link_immutable(cache / filename, variant_cache / filename)
                table = features.copy()
                table["baseline_weight"] = weights
                table["positive_multiplier"] = multipliers if is_positive else np.ones(len(weights), dtype=np.float32)
                table["held_out"] = heldout if is_heldout else False
                table["included_in_embedding"] = vector > 0
                table["variant"] = name
                table["weight"] = vector
                table["weighted_variance"] = vector * variance
                table.to_csv(variant_cache / "features.csv", index=False)
                base.save_json(variant_cache / "variant_settings.json", {
                    **spec, "variant": name, "heldout": is_heldout, "positive": is_positive})
                updated = dict(manifest)
                updated.update(cache_id=variant_id, version=VERSION, source_08s_cache=str(cache),
                               engine_feature_weights_sha256=weight_hash,
                               variant=name, positive_weighting=is_positive, marker_holdout=is_heldout,
                               heldout_genes=list(heldout_genes) if is_heldout else [],
                               n_active_features=int(np.count_nonzero(vector)),
                               weight_definition="ratio_distance_weight * positive_multiplier; heldout markers = 0",
                               original_counts_modified=False)
                names = (*SHARED_ASSAYS, "features.csv", "variant_settings.json")
                updated["files"] = {filename: (variant_cache/filename).stat().st_size for filename in names}
                base.save_json(variant_cache / "cache_manifest.json", updated)
        variants[name] = {"cache_dir": str(variant_cache), "label": labels[name],
                          "positive": is_positive, "heldout": is_heldout,
                          "heldout_genes": list(heldout_genes) if is_heldout else [],
                          "weights_sha256": weight_hash, "n_active_features": int(np.count_nonzero(vector))}
    audit = pd.DataFrame({"gene": features.gene, "ratio": ratios, "baseline_weight": weights,
                          "positive_multiplier": multipliers, "positive_weight": positive,
                          "held_out_in_validation": heldout,
                          "heldout_baseline_weight": validation_baseline,
                          "heldout_positive_weight": validation_positive,
                          "variance_log1p": variance, "baseline_weighted_variance": weights * variance,
                          "positive_weighted_variance": positive * variance})
    audit.to_csv(directory / "gene_weight_audit.csv", index=False)
    availability = []
    for panel, genes in [("positive boost", boost_genes), ("held-out validation", heldout_genes)]:
        for gene in genes:
            in_features, in_assay = gene in gene_set, gene in marker_set
            status = "available" if in_features and in_assay else (
                "not an eligible embedding feature" if not in_features else "not in original marker assay")
            availability.append({"panel": panel, "gene": gene, "in_features": in_features,
                                 "in_marker_assay": in_assay, "status": status})
    panel_table = pd.DataFrame(availability)
    panel_table.to_csv(directory / "panel_availability.csv", index=False)
    for row in availability:
        if row["status"] != "available":
            print(f"Panel availability: {row['gene']} ({row['panel']}): {row['status']}.", flush=True)
    shares = {"baseline": float(np.dot((weights*variance)[selected], np.ones(selected.sum())) / np.dot(weights, variance)),
              "positive": float(np.dot((positive*variance)[selected], np.ones(selected.sum())) / np.dot(positive, variance))}
    experiment = {**spec, "experiment_id": identity, "experiment_dir": str(directory),
                  "variants": variants, "n_cells": len(obs), "n_features": len(features),
                  "target_variance_share_before_pca": shares,
                  "all_08s_cells_retained": True, "original_counts_modified": False,
                  "gene_weight_audit": str(directory / "gene_weight_audit.csv"),
                  "panel_availability": str(directory / "panel_availability.csv")}
    base.save_json(directory / "experiment.json", experiment)
    print(f"Prepared 08T: {len(obs):,} cells × {len(features):,} genes; "
          f"midpoint {midpoint:.2f}; {boost_factor:g}× distance-weight boost.", flush=True)
    print("Variants: " + ", ".join(variants) + ". Original expression is shared unchanged.", flush=True)
    return experiment


def _copy_baseline_result(source, destination, description):
    """Validate and COPY a completed baseline; never mutate or hardlink outputs."""
    source, destination = Path(source).resolve(), Path(destination).resolve()
    if source == destination:
        raise ValueError("Baseline import needs a separate destination.")
    if not gpu.is_compatible_result(source, description):
        return False
    stage = destination.with_name(destination.name + ".import-" + uuid.uuid4().hex)
    stage.mkdir(parents=True)
    required = ("embedding.h5ad", "cluster_assignments.csv.gz", "run_metadata.json")
    copied = []
    try:
        for filename in (*required, "console.log", "completion.json"):
            if filename == "console.log" and not (source/filename).is_file():
                continue
            shutil.copy2(source / filename, stage / filename)
            copied.append(filename)
        if not gpu.is_compatible_result(stage, description):
            raise RuntimeError("Copied 08S baseline failed validation; source may have changed during import.")
        destination.mkdir(parents=True, exist_ok=True)
        (destination / "completion.json").unlink(missing_ok=True)
        for filename in [n for n in copied if n != "completion.json"]:
            os.replace(stage / filename, destination / filename)
        os.replace(stage / "completion.json", destination / "completion.json")
        if not gpu.is_compatible_result(destination, description):
            raise RuntimeError("Imported baseline did not pass final compatibility checks.")
        base.save_json(destination / "imported_baseline.json", {
            "source_output_dir": str(source), "destination_output_dir": str(destination),
            "imported_utc": _now(), "mode": "copy2; source unchanged; completion promoted last",
            "files": copied, "final_fingerprint": description["final_fingerprint"]})
        return True
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def launch_experiment(experiment, helper_dir, runtime, *, settings=None, devices=None,
                      max_minutes=100.0, resume=True):
    """Launch every variant in a fresh process on up to four visible GPUs."""
    cfg = gpu.validate_settings(settings)
    if not math.isfinite(float(max_minutes)) or float(max_minutes) <= 0:
        raise ValueError("max_minutes must be finite and positive.")
    count = int(runtime.get("visible_device_count", runtime.get("device_count", 0)))
    if count < 1:
        raise ValueError("No GPU is visible to this kernel.")
    if devices is None:
        devices = tuple(range(min(4, count)))
    devices = tuple(int(d) for d in devices)
    if not devices or len(set(devices)) != len(devices) or any(d < 0 or d >= count for d in devices):
        raise ValueError("devices must contain distinct available logical GPU indices.")
    devices = devices[:4]
    helper = Path(helper_dir).expanduser().resolve() / "tcell_weighted_gpu.py"
    if not helper.is_file():
        raise FileNotFoundError(helper)
    variants = experiment["variants"]
    if tuple(variants) != VARIANT_NAMES:
        raise ValueError("The experiment must contain the four expected ordered variants.")
    run_id = base._digest({"experiment_id": experiment["experiment_id"], "settings": cfg,
                           "version": VERSION})[:20]
    run_root = Path(experiment["experiment_dir"]) / "runs" / run_id
    run_root.mkdir(parents=True, exist_ok=True)
    settings_path = run_root / "gpu_settings.json"
    base.save_json(settings_path, cfg)
    started = time.monotonic()
    completed, reused, imported, failures = OrderedDict(), [], [], []
    active, pending, descriptions = {}, [], {}
    readers = []
    free_devices = list(devices)
    status_path = run_root / "comparison_status.json"
    base.save_json(run_root / "launch.json", {
        "experiment_id": experiment["experiment_id"], "experiment_dir": experiment["experiment_dir"],
        "settings": cfg, "devices": devices, "visible_device_count": count,
        "max_minutes": float(max_minutes), "resume": bool(resume), "started_utc": _now(), "version": VERSION})

    def save_status(status, error=None):
        base.save_json(status_path, {"status": status, "updated_utc": _now(),
            "elapsed_seconds": time.monotonic()-started, "run_root": str(run_root),
            "completed": completed, "reused_variants": reused, "imported_variants": imported,
            "pending": list(pending), "active": {name: {"device": state["device"],
                "pid": state["process"].pid, "output": state["output"]} for name, state in active.items()},
            "failures": failures, "error": error})

    try:
        save_status("checking compatible results")
        for name, variant in variants.items():
            description = gpu.describe_branch(variant["cache_dir"], settings=cfg)
            descriptions[name] = description
            if description["applied_weights_sha256"] != variant["weights_sha256"]:
                raise ValueError(f"{name} cache weights no longer match the frozen experiment.")
            output = run_root / name
            if resume and gpu.is_compatible_result(output, description):
                completed[name] = output / "embedding.h5ad"
                reused.append(name)
                print(f"Reusing completed 08T variant: {name}.", flush=True)
                continue
            if resume and name == "baseline060":
                candidates = list((Path(experiment["base_cache_dir"]).parent / "runs").glob("*/weighted"))
                candidates.sort(key=lambda p: p.stat().st_mtime_ns, reverse=True)
                for candidate in candidates:
                    if _copy_baseline_result(candidate, output, description):
                        completed[name] = output / "embedding.h5ad"
                        reused.append(name)
                        imported.append(name)
                        print(f"Copied compatible 08S baseline into isolated 08T output: {candidate}", flush=True)
                        break
                if name in completed:
                    continue
            pending.append(name)
        save_status("running")
        last_heartbeat = time.monotonic()
        while pending or active:
            if time.monotonic()-started > float(max_minutes)*60:
                raise TimeoutError(f"08T reached its {max_minutes:g}-minute comparison budget. "
                                   f"Completed results and checkpoints remain in {run_root}.")
            while pending and free_devices:
                name, device = pending.pop(0), free_devices.pop(0)
                output = run_root / name
                output.mkdir(parents=True, exist_ok=True)
                log = output / "console.log"
                writer = log.open("a", encoding="utf-8")
                writer.write(f"\n08T invocation {_now()} | {name} | logical visible GPU {device}\n")
                writer.flush()
                reader = log.open("r", encoding="utf-8", errors="replace")
                reader.seek(0, os.SEEK_END)
                readers.append(reader)
                command = [sys.executable, str(helper), "--cache-dir", variants[name]["cache_dir"],
                           "--output-dir", str(output), "--branch", "weighted", "--gpu-device", "0",
                           "--settings-json", str(settings_path)]
                if not resume:
                    command.append("--no-resume")
                try:
                    process = subprocess.Popen(command, env=base._process_env(device), stdout=writer,
                                               stderr=subprocess.STDOUT, start_new_session=True)
                except BaseException:
                    writer.close()
                    raise
                active[name] = {"process": process, "writer": writer, "reader": reader,
                                "device": device, "output": output}
                print(f"Started {name}: logical visible GPU {device}; all {experiment['n_cells']:,} T cells.", flush=True)
                save_status("running")
            for name, state in list(active.items()):
                for line in state["reader"].readlines():
                    print(f"[{name}] {line.rstrip()}", flush=True)
                code = state["process"].poll()
                if code is not None:
                    state["writer"].close()
                    for line in state["reader"].readlines():
                        print(f"[{name}] {line.rstrip()}", flush=True)
                    free_devices.append(state["device"])
                    if code == 0 and gpu.is_compatible_result(state["output"], descriptions[name]):
                        completed[name] = state["output"] / "embedding.h5ad"
                        print(f"Completed and validated {name}.", flush=True)
                    else:
                        failures.append({"variant": name, "exit_code": code,
                                         "log": str(state["output"] / "console.log"),
                                         "reason": "Process failed or its completed output failed validation."})
                    del active[name]
                    save_status("running")
            if active:
                if time.monotonic()-last_heartbeat >= 15:
                    print(f"08T running: {', '.join(active)}; {len(completed)}/4 complete; "
                          f"{(time.monotonic()-started)/60:.1f} min elapsed.", flush=True)
                    last_heartbeat = time.monotonic()
                time.sleep(1)
        if failures:
            raise RuntimeError("One or more 08T variants failed. See comparison_status.json and variant console.log files: "
                               + ", ".join(item["variant"] for item in failures))
        branches = OrderedDict((name, completed[name]) for name in VARIANT_NAMES)
        base.save_json(run_root / "comparison_complete.json", {
            "status": "complete", "experiment_id": experiment["experiment_id"],
            "branches": branches, "reused_variants": reused, "imported_variants": imported,
            "elapsed_seconds": time.monotonic()-started, "completed_utc": _now(),
            "all_cells_retained": True})
        save_status("complete")
        return branches, run_root
    except BaseException as exc:
        for state in active.values():
            base._stop_owned(state["process"])
        save_status("interrupted" if isinstance(exc, KeyboardInterrupt) else "failed",
                    f"{type(exc).__name__}: {exc}")
        try:
            exc.run_root = run_root
            exc.diagnostic_path = status_path
        except Exception:
            pass
        raise
    finally:
        for state in active.values():
            base._stop_owned(state["process"])
            state["writer"].close()
        for reader in readers:
            reader.close()


def load_marker_data(base_cache_dir):
    """Return unchanged log expression/counts and metadata in frozen cell order."""
    cache = Path(base_cache_dir)
    obs = pd.read_csv(cache / "obs.csv.gz", dtype={"cell_id": str, "sample_id": str,
                                                       "condition": str, "population": str},
                      keep_default_na=False).set_index("cell_id")
    if not obs.index.is_unique or obs.index.to_series().eq("").any():
        raise ValueError("Original marker metadata needs unique nonempty cell IDs.")
    genes = pd.read_csv(cache / "marker_genes.csv", dtype=str)["gene"].tolist()
    counts = sp.load_npz(cache / "marker_counts.npz").tocsr()
    log_expr = sp.load_npz(cache / "marker_log1p.npz").tocsr()
    if counts.shape != log_expr.shape or counts.shape != (len(obs), len(genes)):
        raise ValueError("Original marker matrices and ordered metadata have inconsistent dimensions.")
    return log_expr, counts, genes, obs


def load_methods(branches, obs, names):
    """Load only requested lightweight results, preserving method/cell order."""
    import anndata as ad
    methods = OrderedDict()
    for name in names:
        if name not in branches:
            raise KeyError(f"Missing completed variant: {name}")
        result = ad.read_h5ad(branches[name])
        if not np.array_equal(result.obs_names.astype(str), obs.index.astype(str)):
            raise ValueError(f"Cell order differs in {name}; review cannot safely proceed.")
        methods[name] = result
    return methods
