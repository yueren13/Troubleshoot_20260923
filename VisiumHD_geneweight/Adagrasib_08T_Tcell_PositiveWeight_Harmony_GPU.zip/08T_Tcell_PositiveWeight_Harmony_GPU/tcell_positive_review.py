"""Original-count companion checks for the 08T held-out weighting comparison.

Held-out genes must have exactly zero effective input weights in every supplied
embedding. The diagnostics assess CD8 companion and Treg-support coherence, not
classification accuracy. They do not independently validate CD4 identity.
"""
from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Mapping
import html
import json
import time

import numpy as np
import pandas as pd
import scipy.sparse as sp


DEFAULT_HELDOUT_GENES = ("Cd8b1", "Il2ra", "Ctla4", "Ikzf2", "Tnfrsf18")
DEFAULT_GUIDE_PAIRS = (("Cd8a", "Cd8b1"), ("Foxp3", "Il2ra"),
                       ("Foxp3", "Ctla4"), ("Foxp3", "Ikzf2"),
                       ("Foxp3", "Tnfrsf18"))
DOMINANCE_GENES = ("Trac", "Nkg7", "Ccl5")
NOTES = [
    "All assays are original observed counts or original full-library-normalized log1p expression. No weighted assay is used for marker review.",
    "The diagnostic checks CD8 companion evidence and Treg-associated support. It does not independently validate CD4 identity or assign cell types.",
    "The held-out gene columns have exactly zero input contribution to PCA, Harmony and the graph in both diagnostic methods. Original measurements remain available for evaluation; the shared full-library normalization totals stay unchanged.",
    "A guide is an observed Cd8a-positive or Foxp3-positive cell, not an independently established cell-type label. Observed-negative cells can include cells whose transcripts were not captured.",
    "Neighbor statistics exclude self-edges. Expected held-out detection uses each neighbor's sample and within-sample depth quintile. The focal guide-positive/guide-negative comparison is also made within sample/depth strata.",
    "The reported contrast averages shared eligible depth strata within each sample, then gives each contributing sample equal weight. This controls coarse sample/depth composition; it is not exact depth matching or a causal effect estimate.",
    "Only strata meeting the minimum guide-positive and guide-negative counts in every supplied graph are compared. Their coverage and sample count are reported.",
    "Positive values indicate stronger held-out neighbor support around guide-positive cells. They are descriptive concordance, not typing accuracy, significance, or proof of decontamination.",
    "Near-universal, low-count marker flags identify groups needing companion-marker inspection. They do not establish that a group is an artifact.",
    "Missing genes are unavailable, never measured zeros. A held-out gene absent from the feature universe has no embedding contribution; its original assay may still be reviewable.",
    "CD4/CD8/Treg marker genes and the companion checks were chosen before this run, but previous data inspection informed the experiment. These are exploratory validation diagnostics rather than a blinded external benchmark.",
]


def _clean(value):
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return _clean(value.tolist())
    if isinstance(value, np.generic):
        return _clean(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def _json(path, value):
    Path(path).write_text(json.dumps(_clean(value), indent=2, allow_nan=False), encoding="utf-8")


def _method_parts(value, expected_index, cluster_key):
    if hasattr(value, "obs"):
        frame = value.obs
        graphs = getattr(value, "obsp", {})
        var = getattr(value, "var", None)
    elif isinstance(value, Mapping):
        frame = value["obs"]
        graphs = value.get("obsp", value)
        var = value.get("var")
    else:
        raise TypeError("Each method must have a pandas obs table and optional sparse connectivities.")
    if not isinstance(frame, pd.DataFrame) or not frame.index.equals(expected_index):
        raise ValueError("Companion-review cell IDs/order differ from the original marker input.")
    if cluster_key not in frame or frame[cluster_key].isna().any():
        raise ValueError(f"Every method needs complete {cluster_key!r} cluster labels.")
    graph = None
    for key in ("connectivities", "neighbors_connectivities"):
        if key in graphs:
            graph = graphs[key]
            break
    if graph is not None:
        if not sp.issparse(graph) or graph.shape != (len(frame), len(frame)):
            raise ValueError("Companion-review graph must be a CPU sparse, all-cell square matrix.")
        graph = graph.tocsr(copy=False)
        for left in range(0, graph.nnz, 2_000_000):
            x = graph.data[left:left + 2_000_000]
            if not np.isfinite(x).all() or (x < 0).any():
                raise ValueError("Graph connectivity weights must be finite and nonnegative.")
    return frame, graph, var


def _feature_weights(table):
    if not isinstance(table, pd.DataFrame):
        raise TypeError("Provide a feature DataFrame for each diagnostic method.")
    if "gene" in table:
        if table["gene"].isna().any():
            raise ValueError("Feature genes must be unique nonempty symbols.")
        genes = pd.Index(table["gene"].astype(str))
    else:
        if table.index.isna().any():
            raise ValueError("Feature genes must be unique nonempty symbols.")
        genes = pd.Index(table.index.astype(str))
    if not genes.is_unique or genes.isna().any() or (genes == "").any():
        raise ValueError("Feature genes must be unique nonempty symbols.")
    weight_key = "applied_distance_weight" if "applied_distance_weight" in table else "weight"
    if weight_key not in table:
        raise ValueError("Feature audit needs effective weight or applied_distance_weight.")
    weights = pd.to_numeric(table[weight_key], errors="raise").to_numpy(dtype=float)
    if not np.isfinite(weights).all() or (weights < 0).any():
        raise ValueError("Effective feature weights must be finite and nonnegative.")
    return pd.Series(weights, index=genes)


def _prepare_assays(counts, log_expr, gene_names, n_cells, requested):
    names = pd.Index([str(g) for g in gene_names])
    if not names.is_unique:
        raise ValueError("Marker genes must be unique.")
    if counts.shape != (n_cells, len(names)) or log_expr.shape != counts.shape:
        raise ValueError("Original marker counts/log expression do not align with cells and genes.")
    genes = [g for g in requested if g in names]
    ix = names.get_indexer(genes)
    C = sp.csr_matrix(counts[:, ix], dtype=np.float64, copy=True)
    L = sp.csr_matrix(log_expr[:, ix], dtype=np.float64, copy=True)
    for matrix in (C, L):
        matrix.sum_duplicates()
        matrix.eliminate_zeros()
        matrix.sort_indices()
        if not np.isfinite(matrix.data).all() or (matrix.data < 0).any():
            raise ValueError("Original assays must contain finite nonnegative values.")
    if not np.allclose(C.data, np.rint(C.data), atol=1e-4, rtol=0):
        raise ValueError("Pass original observed integer counts, not weighted or normalized counts.")
    B = C.copy()
    B.data = np.ones(B.nnz, dtype=float)
    LB = L.copy()
    LB.data = np.ones(LB.nnz, dtype=float)
    if (B != LB).nnz:
        raise ValueError("Original count and log-expression detection patterns disagree.")
    return genes, C, L, B


def _depth_strata(samples, depth):
    bins = np.empty(len(samples), dtype=object)
    for sample in pd.unique(samples):
        ix = np.flatnonzero(samples == sample)
        ranks = pd.Series(depth[ix]).rank(method="average", pct=True).to_numpy()
        q = np.clip(np.ceil(ranks * 5).astype(int) - 1, 0, 4)
        bins[ix] = np.asarray(["Q1", "Q2", "Q3", "Q4", "Q5"])[q]
    levels = pd.MultiIndex.from_arrays([samples, bins], names=["sample", "depth_quintile"])
    codes, unique = pd.factorize(levels, sort=True)
    return bins, codes, pd.DataFrame(unique.tolist(), columns=levels.names)


def _group_stats(arrays, names, C, L, B, genes):
    index = pd.MultiIndex.from_arrays(arrays, names=names)
    codes, levels = pd.factorize(index, sort=True)
    n_groups, n = len(levels), len(codes)
    sizes = np.bincount(codes, minlength=n_groups)
    membership = sp.csr_matrix((np.ones(n), (codes, np.arange(n))), shape=(n_groups, n))
    positives = (membership @ B).toarray()
    sums = (membership @ C).toarray()
    logs = (membership @ L).toarray()
    g = len(genes)
    frame = pd.DataFrame({name: np.repeat(np.asarray(levels.get_level_values(i)), g)
                          for i, name in enumerate(names)})
    frame["gene"] = np.tile(genes, n_groups)
    frame["n_cells"] = np.repeat(sizes, g)
    frame["n_positive"] = np.rint(positives).astype(np.int64).ravel()
    frame["fraction_positive"] = (positives / sizes[:, None]).ravel()
    frame["mean_observed_counts"] = (sums / sizes[:, None]).ravel()
    frame["mean_log1p_unweighted"] = (logs / sizes[:, None]).ravel()
    return frame, codes, sizes


def _neighbor_values(graph, measured, expected):
    """Return neighbor fractions without modifying the sparse graph; no self-edges."""
    if graph is None:
        return None, None, np.zeros(measured.shape[0], dtype=bool)
    diagonal = graph.diagonal().astype(np.float64)
    totals = np.asarray(graph.sum(axis=1), dtype=np.float64).ravel() - diagonal
    # Tiny cancellation on diagonal-only rows must not create a negative degree.
    if (totals < -1e-7).any():
        raise ValueError("Graph has invalid negative off-diagonal connectivity mass.")
    valid = totals > 1e-10
    observed_neighbors = np.asarray(graph @ measured, dtype=np.float64)
    expected_neighbors = np.asarray(graph @ expected, dtype=np.float64)
    observed_neighbors -= diagonal[:, None] * measured
    expected_neighbors -= diagonal[:, None] * expected
    observed_neighbors[valid] /= totals[valid, None]
    expected_neighbors[valid] /= totals[valid, None]
    observed_neighbors[~valid] = np.nan
    expected_neighbors[~valid] = np.nan
    return observed_neighbors, expected_neighbors, valid


def _neighbor_rows(method, guide_pairs, genes, B, graph, strata_codes, strata_table, stratum_fractions,
                   min_cells):
    lookup = {g: i for i, g in enumerate(genes)}
    targets = list(dict.fromkeys(target for _, target in guide_pairs if target in lookup))
    target_lookup = {g: i for i, g in enumerate(targets)}
    measured = B[:, [lookup[g] for g in targets]].toarray().astype(np.float32)
    expected = stratum_fractions[strata_codes][:, [lookup[g] for g in targets]].astype(np.float32)
    neighbor_obs, neighbor_expected, valid = _neighbor_values(graph, measured, expected)
    rows = []
    n_strata = len(strata_table)
    for guide, target in guide_pairs:
        available = guide in lookup and target in lookup
        positive = np.asarray(B[:, lookup[guide]].toarray()).ravel() > 0 if guide in lookup else np.zeros(B.shape[0], dtype=bool)
        n_pos = np.bincount(strata_codes[valid & positive], minlength=n_strata)
        n_neg = np.bincount(strata_codes[valid & ~positive], minlength=n_strata)
        values = {}
        if graph is not None and available:
            j = target_lookup[target]
            for label, vec in [("observed", neighbor_obs[:, j]), ("expected", neighbor_expected[:, j])]:
                for side, mask in [("guide_positive", valid & positive), ("guide_negative", valid & ~positive)]:
                    totals = np.bincount(strata_codes[mask], weights=vec[mask], minlength=n_strata)
                    denom = n_pos if side == "guide_positive" else n_neg
                    values[label + "_" + side] = np.divide(totals, denom, out=np.full(n_strata, np.nan), where=denom > 0)
        for code, row in strata_table.iterrows():
            result = {"method": method, "guide_gene": guide, "heldout_gene": target,
                      "sample": row["sample"], "depth_quintile": row["depth_quintile"],
                      "marker_pair_available": available, "graph_available": graph is not None,
                      "n_guide_positive_with_neighbors": int(n_pos[code]),
                      "n_guide_negative_with_neighbors": int(n_neg[code]),
                      "eligible_stratum": bool(available and graph is not None and n_pos[code] >= min_cells and n_neg[code] >= min_cells)}
            for name in ("observed_guide_positive", "observed_guide_negative", "expected_guide_positive", "expected_guide_negative"):
                result["neighbor_fraction_" + name] = float(values[name][code]) if name in values else np.nan
            result["raw_neighbor_difference"] = result["neighbor_fraction_observed_guide_positive"] - result["neighbor_fraction_observed_guide_negative"]
            result["expected_neighbor_difference"] = result["neighbor_fraction_expected_guide_positive"] - result["neighbor_fraction_expected_guide_negative"]
            result["neighbor_excess_difference"] = result["raw_neighbor_difference"] - result["expected_neighbor_difference"]
            rows.append(result)
    return rows, float(valid.mean())


def build_companion_review(counts, log_expr, gene_names, obs, methods, feature_tables, output_dir, *,
                           primary_cluster_key="leiden_0.4", heldout_genes=DEFAULT_HELDOUT_GENES,
                           guide_pairs=DEFAULT_GUIDE_PAIRS, sample_key="sample_id", depth_key="total_counts",
                           min_cells_per_guide_group=5, normalization_target_sum=10000.0):
    """Build a small auditable report for the paired held-out diagnostic.

    ``methods`` maps labels to AnnData results (or mappings with obs/obsp).
    ``feature_tables`` maps the same labels to effective feature audits. Applied
    weights stored in AnnData.var are also checked when present. A missing graph
    leaves the graph score unavailable; cluster/count diagnostics still run.
    """
    started = time.perf_counter()
    if not isinstance(obs, pd.DataFrame) or not obs.index.is_unique or len(obs) < 2:
        raise ValueError("obs must have unique ordered cell IDs and at least two cells.")
    if not methods or set(methods) != set(feature_tables):
        raise ValueError("Supply one effective feature table for every held-out method.")
    if sample_key not in obs or depth_key not in obs or obs[sample_key].isna().any():
        raise ValueError("Original sample IDs and full-library total counts are required.")
    if isinstance(min_cells_per_guide_group, bool) or int(min_cells_per_guide_group) != min_cells_per_guide_group or min_cells_per_guide_group < 1:
        raise ValueError("min_cells_per_guide_group must be a positive integer.")
    heldout_genes = tuple(dict.fromkeys(map(str, heldout_genes)))
    guide_pairs = tuple(dict.fromkeys((str(g), str(t)) for g, t in guide_pairs if str(t) in heldout_genes))
    if not heldout_genes or not guide_pairs:
        raise ValueError("At least one held-out guide/companion pair is required.")
    if any(g in heldout_genes for g, _ in guide_pairs):
        raise ValueError("A guide gene cannot also be an excluded companion in this diagnostic.")
    depth = pd.to_numeric(obs[depth_key], errors="raise").to_numpy(dtype=float)
    if not np.isfinite(depth).all() or (depth <= 0).any():
        raise ValueError("Full-library counts must be finite and positive.")
    samples = obs[sample_key].astype(str).to_numpy()
    requested = tuple(dict.fromkeys(["Cd4", "Cd8a", "Foxp3", *(g for g, _ in guide_pairs), *heldout_genes,
                                     "Cd3d", "Cd3e", "Trbc1", "Trbc2", *DOMINANCE_GENES]))
    genes, C, L, B = _prepare_assays(counts, log_expr, gene_names, len(obs), requested)
    if not genes:
        raise ValueError("No requested original marker assays are available.")
    lookup = {g: j for j, g in enumerate(genes)}
    max_normalization_error = None
    if normalization_target_sum is not None:
        if not np.isfinite(normalization_target_sum) or normalization_target_sum <= 0:
            raise ValueError("The normalization target must be finite and positive.")
        normalized = C.multiply(float(normalization_target_sum) / depth[:, None]).tocsr()
        np.log1p(normalized.data, out=normalized.data)
        difference = normalized - L
        max_normalization_error = float(np.max(np.abs(difference.data))) if difference.nnz else 0.0
        if max_normalization_error > 2e-4:
            raise ValueError("Companion markers must use original full-library log1p normalization.")
    prepared, audit_rows = OrderedDict(), []
    for name, value in methods.items():
        frame, graph, var = _method_parts(value, obs.index, primary_cluster_key)
        weights = _feature_weights(feature_tables[name])
        actual_weights = _feature_weights(var) if isinstance(var, pd.DataFrame) and ("weight" in var or "applied_distance_weight" in var) else None
        if actual_weights is not None:
            if not weights.index.equals(actual_weights.index) or not np.allclose(weights.to_numpy(), actual_weights.to_numpy(), rtol=2e-6, atol=0):
                raise ValueError(f"Supplied effective feature weights disagree with the completed embedding for {name}.")
            if "feature_in_embedding" in var:
                flags = var["feature_in_embedding"]
                if flags.isna().any() or not pd.api.types.is_bool_dtype(flags.dtype):
                    raise ValueError("Completed feature_in_embedding audit must contain nonmissing Boolean values.")
                if not np.array_equal(flags.to_numpy(), actual_weights.to_numpy() > 0):
                    raise ValueError("Completed feature_in_embedding flags disagree with applied distance weights.")
        for gene in heldout_genes:
            value = float(weights[gene]) if gene in weights else 0.0
            if value != 0.0:
                raise ValueError(f"Held-out gene {gene} has nonzero effective weight in {name}; leaving it unboosted is not exclusion.")
            j = lookup.get(gene)
            audit_rows.append({"method": str(name), "gene": gene, "original_assay_available": j is not None,
                               "in_feature_universe": gene in weights, "effective_input_weight": value,
                               "excluded_from_embedding": True, "completed_embedding_weight_checked": actual_weights is not None,
                               "original_n_positive": int(B[:, j].sum()) if j is not None else np.nan,
                               "original_fraction_positive": float(B[:, j].mean()) if j is not None else np.nan})
        prepared[str(name)] = (frame, graph)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    figures = output / "figures"
    figures.mkdir(exist_ok=True)
    pd.DataFrame(audit_rows).to_csv(output / "heldout_exclusion_audit.csv", index=False)
    depth_bins, strata_codes, strata_table = _depth_strata(samples, depth)
    n_strata = len(strata_table)
    stratum_sizes = np.bincount(strata_codes, minlength=n_strata)
    strata_membership = sp.csr_matrix((np.ones(len(obs)), (strata_codes, np.arange(len(obs)))), shape=(n_strata, len(obs)))
    stratum_fractions = (strata_membership @ B).toarray() / stratum_sizes[:, None]
    cluster_frames, sample_frames, depth_frames, dominance_frames, pair_frames = [], [], [], [], []
    neighbor_rows, graph_coverage = [], {}
    global_fractions = np.asarray(B.mean(axis=0)).ravel()
    for method, (frame, graph) in prepared.items():
        print(f"Companion review: {method}; original markers for all {len(obs):,} cells.", flush=True)
        clusters = frame[primary_cluster_key].astype(str).to_numpy()
        table, codes, sizes = _group_stats([clusters], ["cluster"], C, L, B, genes)
        composition = sp.csr_matrix((np.ones(len(obs)), (codes, strata_codes)), shape=(len(sizes), n_strata))
        expected = np.asarray(composition @ stratum_fractions) / sizes[:, None]
        table["sample_depth_expected_fraction"] = expected.ravel()
        table["sample_depth_excess_fraction"] = table["fraction_positive"] - table["sample_depth_expected_fraction"]
        table["global_fraction_positive"] = np.tile(global_fractions, len(sizes))
        table["is_heldout"] = table["gene"].isin(heldout_genes)
        table.insert(0, "clustering", primary_cluster_key)
        table.insert(0, "method", method)
        cluster_frames.append(table)
        for labels, names, destination in [([clusters, samples], ["cluster", "sample"], sample_frames),
                                            ([clusters, samples, depth_bins], ["cluster", "sample", "depth_quintile"], depth_frames)]:
            subtable, _, _ = _group_stats(labels, names, C, L, B, genes)
            subtable.insert(0, "clustering", primary_cluster_key)
            subtable.insert(0, "method", method)
            subtable["is_heldout"] = subtable["gene"].isin(heldout_genes)
            destination.append(subtable)
        for key in [primary_cluster_key] + [key for key in frame if key.startswith("leiden_") and key != primary_cluster_key]:
            if frame[key].isna().any():
                raise ValueError(f"Missing cluster labels for marker dominance audit: {key}.")
            if key == primary_cluster_key:
                dom = table[table["gene"].isin(DOMINANCE_GENES)].copy()
            else:
                extra, _, _ = _group_stats([frame[key].astype(str).to_numpy()], ["cluster"], C, L, B, genes)
                dom = extra[extra["gene"].isin(DOMINANCE_GENES)].copy()
                dom.insert(0, "clustering", key)
                dom.insert(0, "method", method)
            dom["mean_count_when_detected"] = dom["mean_observed_counts"].div(dom["fraction_positive"].replace(0, np.nan))
            dom["near_universal_detection"] = dom["fraction_positive"] >= .95
            dom["low_mean_count_when_detected"] = dom["mean_count_when_detected"] <= 1.5
            dom["near_single_transcript_pattern"] = dom["near_universal_detection"] & dom["low_mean_count_when_detected"]
            dominance_frames.append(dom)
        for guide, target in guide_pairs:
            if guide not in lookup or target not in lookup:
                continue
            a = table[table.gene == guide].set_index("cluster")
            b = table[table.gene == target].set_index("cluster")
            pair_frames.append(pd.DataFrame({"method": method, "clustering": primary_cluster_key,
                "cluster": a.index, "n_cells": a.n_cells.to_numpy(), "guide_gene": guide, "heldout_gene": target,
                "guide_fraction_positive": a.fraction_positive.to_numpy(), "heldout_fraction_positive": b.fraction_positive.to_numpy(),
                "guide_sample_depth_excess": a.sample_depth_excess_fraction.to_numpy(),
                "heldout_sample_depth_excess": b.sample_depth_excess_fraction.to_numpy()}))
        rows, coverage = _neighbor_rows(method, guide_pairs, genes, B, graph, strata_codes, strata_table,
                                         stratum_fractions, int(min_cells_per_guide_group))
        neighbor_rows.extend(rows)
        graph_coverage[method] = coverage
    tables = {
        "companion_cluster_markers.csv.gz": pd.concat(cluster_frames, ignore_index=True),
        "companion_by_sample.csv.gz": pd.concat(sample_frames, ignore_index=True),
        "companion_by_sample_depth.csv.gz": pd.concat(depth_frames, ignore_index=True),
        "single_gene_dominance_audit.csv": pd.concat(dominance_frames, ignore_index=True),
        "cluster_guide_companion.csv": pd.concat(pair_frames, ignore_index=True) if pair_frames else pd.DataFrame(columns=["method", "guide_gene", "heldout_gene", "cluster"]),
    }
    strata = pd.DataFrame(neighbor_rows)
    paired_keys = ["guide_gene", "heldout_gene", "sample", "depth_quintile"]
    common = strata.groupby(paired_keys, sort=False)["eligible_stratum"].transform(lambda x: len(x) == len(prepared) and bool(x.all()))
    strata["shared_eligible_stratum"] = common.astype(bool)
    eligible = strata[strata.shared_eligible_stratum]
    by_sample = eligible.groupby(["method", "guide_gene", "heldout_gene", "sample"], as_index=False).agg(
        n_shared_depth_strata=("depth_quintile", "size"),
        n_guide_positive_with_neighbors=("n_guide_positive_with_neighbors", "sum"),
        n_guide_negative_with_neighbors=("n_guide_negative_with_neighbors", "sum"),
        raw_neighbor_difference=("raw_neighbor_difference", "mean"),
        expected_neighbor_difference=("expected_neighbor_difference", "mean"),
        neighbor_excess_difference=("neighbor_excess_difference", "mean"))
    summary_rows = []
    for method in prepared:
        for guide, target in guide_pairs:
            use = by_sample[(by_sample.method == method) & (by_sample.guide_gene == guide) & (by_sample.heldout_gene == target)]
            available = guide in lookup and target in lookup
            summary_rows.append({"method": method, "guide_gene": guide, "heldout_gene": target,
                "marker_pair_available": available, "graph_available": prepared[method][1] is not None,
                "n_samples_compared": len(use), "n_shared_depth_strata": int(use.n_shared_depth_strata.sum()),
                "n_guide_positive_compared": int(use.n_guide_positive_with_neighbors.sum()),
                "n_guide_negative_compared": int(use.n_guide_negative_with_neighbors.sum()),
                "global_heldout_detection_fraction": float(global_fractions[lookup[target]]) if target in lookup else np.nan,
                "sample_balanced_raw_neighbor_difference": float(use.raw_neighbor_difference.mean()) if len(use) else np.nan,
                "sample_balanced_neighbor_excess_difference": float(use.neighbor_excess_difference.mean()) if len(use) else np.nan,
                "n_samples_with_positive_excess_difference": int((use.neighbor_excess_difference > 0).sum()),
                "graph_nonself_neighbor_coverage": graph_coverage[method]})
    summary_frame = pd.DataFrame(summary_rows)
    tables.update({"heldout_neighbor_by_sample_depth.csv": strata,
                   "heldout_neighbor_by_sample.csv": by_sample,
                   "heldout_neighbor_summary.csv": summary_frame})
    for filename, table in tables.items():
        table.to_csv(output / filename, index=False)
    figure_path = figures / "heldout_companion_concordance.png"
    _plot_summary(summary_frame, figure_path, list(prepared), guide_pairs)
    summary = {"n_cells": len(obs), "n_samples": len(pd.unique(samples)), "primary_clustering": primary_cluster_key,
               "heldout_genes": heldout_genes, "guide_pairs": guide_pairs, "independent_CD4_validation": False,
               "missing_assays": [g for g in requested if g not in lookup], "min_cells_per_guide_group": int(min_cells_per_guide_group),
               "normalization_max_absolute_error": max_normalization_error, "graph_nonself_neighbor_coverage": graph_coverage,
               "neighbor_summary": summary_frame.to_dict(orient="records"), "interpretation_notes": NOTES,
               "single_gene_flag_definition": {"fraction_positive_at_least": .95, "mean_count_when_detected_at_most": 1.5,
                                                "meaning": "review flag, not an artifact or cell-type label"},
               "elapsed_seconds": time.perf_counter() - started,
               "figure": str(figure_path.relative_to(output)), "files": ["heldout_exclusion_audit.csv", *tables, "companion_summary.json", "companion_review.html", str(figure_path.relative_to(output))]}
    _json(output / "companion_summary.json", summary)
    links = "".join(f'<li><a href="{html.escape(name)}">{html.escape(name)}</a></li>' for name in summary["files"] if name.endswith((".csv", ".csv.gz", ".json")))
    notes = "".join(f"<li>{html.escape(note)}</li>" for note in NOTES)
    display_table = summary_frame[["method", "guide_gene", "heldout_gene", "n_samples_compared", "n_guide_positive_compared",
                                   "global_heldout_detection_fraction", "sample_balanced_neighbor_excess_difference"]].copy()
    doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>08T held-out companion review</title><style>body{{font:16px/1.5 system-ui,sans-serif;max-width:1350px;margin:30px auto;padding:20px;color:#18293b}}img{{max-width:100%}}table{{border-collapse:collapse;display:block;overflow:auto}}td,th{{border:1px solid #ccd7e2;padding:7px;text-align:right}}th{{background:#edf3f8}}a{{color:#146e94}}</style></head>
<body><h1>08T held-out companion review</h1><p>{len(obs):,} cells; original counts; Leiden {html.escape(primary_cluster_key)}. Companion genes contribute exactly zero to the two validation embeddings.</p>
<h2>How to read this check</h2><p>Each comparison asks whether observed Cd8a-positive or Foxp3-positive cells acquire neighbors with more independently held-out companion evidence. The figure shows a difference in observed neighbor detection after accounting for coarse sample/depth composition. It is not an accuracy score. CD4 identity is not independently validated here.</p>
<img src="{html.escape(summary['figure'])}" alt="Held-out companion concordance by method">
{display_table.to_html(index=False, float_format=lambda x: f'{x:.4g}', escape=True)}
<h2>Interpretation and limitations</h2><ul>{notes}</ul><p><strong>Unavailable original assays:</strong> {html.escape(', '.join(summary['missing_assays']) or 'None')}</p>
<h2>Tables and audit</h2><ul>{links}</ul></body></html>'''
    (output / "companion_review.html").write_text(doc, encoding="utf-8")
    print(f"Held-out companion review complete: {output / 'companion_review.html'}", flush=True)
    return summary


def _plot_summary(summary, path, method_order, pairs):
    import matplotlib
    matplotlib.use("Agg", force=False)
    import matplotlib.pyplot as plt
    labels = [f"{guide} → {target}" for guide, target in pairs]
    x = np.arange(len(pairs), dtype=float)
    width = .76 / max(1, len(method_order))
    colors = ["#60899e", "#ce7941", "#63815b", "#906b9a"]
    display_names = {"heldout_baseline060": "0.60 baseline; companions held out",
                     "heldout_positive060": "0.60 + positive boost; companions held out"}
    fig, ax = plt.subplots(figsize=(11.6, 5.3))
    for j, method in enumerate(method_order):
        block = summary[summary.method == method].set_index(["guide_gene", "heldout_gene"])
        values = np.asarray([block.loc[pair, "sample_balanced_neighbor_excess_difference"] for pair in pairs], dtype=float) * 100
        positions = x + (j - (len(method_order) - 1) / 2) * width
        finite = np.isfinite(values)
        ax.bar(positions[finite], values[finite], width, label=display_names.get(method, method), color=colors[j % len(colors)])
        for pos in positions[~finite]:
            ax.text(pos, 0, "N/A", rotation=90, va="bottom", ha="center", fontsize=9)
    ax.axhline(0, color="#52616b", lw=1)
    ax.set_xticks(x, labels, rotation=16, ha="right")
    ax.set_ylabel("Held-out neighbor excess: guide+ minus guide−\n(percentage points; sample-balanced)")
    ax.set_title("Companion genes excluded from both validation embeddings", fontsize=13)
    ax.legend(frameon=False, fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)
    fig.text(.02, .015, "Self-edges excluded • sample/depth expected detection subtracted • shared eligible strata • descriptive, not typing accuracy", fontsize=9, color="#52616b")
    fig.tight_layout(rect=[0, .055, 1, 1])
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)
