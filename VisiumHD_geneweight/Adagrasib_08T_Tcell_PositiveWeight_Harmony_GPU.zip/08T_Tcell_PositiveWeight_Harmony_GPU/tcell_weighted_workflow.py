"""08S input preparation, isolated GPU launch, and compact return package.

Reuses the completed 08O T-cell subset. The ratio changes gene-feature influence;
it does not estimate clean molecule counts. No original input is modified.
"""
from __future__ import annotations

import gc
import hashlib
import html
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time
import uuid
import zipfile

import numpy as np
import pandas as pd
import scipy.sparse as sp

VERSION = "08S-soft-weight-harmony-1.0.0"
# Reporting/API fixes with unchanged numerics retain prepared data and checkpoints.
RELEASE_VERSION = "1.0.3"
KNOWN_PROJECT_DIR = Path("/host_root/nethome/reny28/Projects/Visium_projects/TBIO-8110/code/python")
POPULATIONS = ("T cell 1", "T cell 2")


def _jsonable(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(v) for v in value]
    return value


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".partial")
    temp.write_text(json.dumps(_jsonable(value), indent=2, allow_nan=False))
    temp.replace(path)


def _digest(value):
    return hashlib.sha256(json.dumps(_jsonable(value), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def ordered_id_hash(values):
    digest = hashlib.sha256()
    for value in values:
        data = str(value).encode("utf-8")
        digest.update(len(data).to_bytes(8, "little"))
        digest.update(data)
    return digest.hexdigest()


def _signature(path):
    """Fast source fingerprint: metadata plus first/last MiB, not a full file hash."""
    path = Path(path).resolve()
    stat = path.stat()
    h = hashlib.sha256()
    with path.open("rb") as handle:
        h.update(handle.read(1024 * 1024))
        if stat.st_size > 1024 * 1024:
            handle.seek(max(0, stat.st_size - 1024 * 1024))
            h.update(handle.read(1024 * 1024))
    return {"path": str(path), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns,
            "head_tail_sha256": h.hexdigest()}


def _path(value, parent):
    result = Path(str(value)).expanduser()
    return (result if result.is_absolute() else Path(parent) / result).resolve()


def resolve_inputs(project_dir, *, allow_known_fallback=False):
    """One-path setup: original CT26 code folder, an 08O folder, or its pointer.

The normal path is the existing project's 08O_latest_result.json. There is no
new extraction, H5AD picker, or search across unrelated projects.
"""
    start = Path(project_dir).expanduser().resolve()
    pointer = None
    project = start if start.is_dir() else start.parent
    tracked = []
    if start.is_file() and start.name == "08O_latest_result.json":
        pointer = start
    elif start.is_dir() and (start / "08O_latest_result.json").is_file():
        pointer = start / "08O_latest_result.json"
    else:
        candidates = list(dict.fromkeys([project, *project.parents]
                          + ([KNOWN_PROJECT_DIR] if allow_known_fallback else [])))
        project = next((p for p in candidates
                        if (p / "ct26_analysis_config.json").is_file()
                        and (p / "inputs/pipeline_config.json").is_file()), None)
        if project is not None:
            config_path = project / "ct26_analysis_config.json"
            pipeline_path = project / "inputs/pipeline_config.json"
            config = json.loads(config_path.read_text())
            pipeline = json.loads(pipeline_path.read_text())
            run_root = (_path(pipeline["paths"]["derived_root"], project)
                        / "08_ct26_joint_scvi" / str(config["run_name"]))
            pointer = run_root / "14_tcell_ratio_subclustering/08O_latest_result.json"
            tracked.extend([config_path, pipeline_path])
    if pointer is None or not pointer.is_file():
        raise FileNotFoundError(
            "Set PROJECT_DIR to the original CT26 code folder used by 08O and 08Q "
            "(containing ct26_analysis_config.json and inputs/pipeline_config.json). "
            "You may also point it directly to the 08O output folder containing "
            "08O_latest_result.json. If 08O finished clustering but not its final "
            "review cell, run that final 08O cell once to write the pointer.")
    index = json.loads(pointer.read_text())
    source = _path(index["analysis_h5ad"], pointer.parent)
    ratio = source.parent / "ratio_filter_in_analysis.csv"
    receipt = source.parent / "complete.json"
    for path in [source, ratio, receipt]:
        if not path.is_file():
            raise FileNotFoundError(f"Completed 08O input is missing: {path}")
        if not path.resolve().is_relative_to(pointer.parent.resolve()):
            raise ValueError(f"08O pointer refers outside its own run: {path}")
    run_root = pointer.parent.parent
    tracked.extend([pointer, source, ratio, receipt])
    result = {"project_dir": str(project), "pointer_path": str(pointer),
              "baseline_path": str(source), "ratio_path": str(ratio),
              "receipt_path": str(receipt), "index": index,
              "output_root": str(run_root / "18_tcell_soft_weight_harmony"),
              "source_signatures": [_signature(p) for p in tracked]}
    print("Completed 08O input:", source, flush=True)
    print("Ratio audit:", ratio, flush=True)
    print("New 08S output:", result["output_root"], flush=True)
    return result


def _unchanged(inputs):
    for old in inputs["source_signatures"]:
        if _signature(old["path"]) != old:
            raise RuntimeError(f"An 08O input changed during this run: {old['path']}. Restart from input discovery.")


def _read_elem(group):
    try:
        from anndata.io import read_elem
    except ImportError:
        from anndata.experimental import read_elem
    return read_elem(group)


def load_original_counts(inputs):
    """Read only counts and metadata, avoiding old graphs and duplicate log layers."""
    import h5py
    _unchanged(inputs)
    with h5py.File(inputs["baseline_path"], "r") as handle:
        obs = _read_elem(handle["obs"])
        var = _read_elem(handle["var"])
        if "layers/counts" not in handle:
            raise ValueError("08O must contain original observations in layers['counts']; weighted/log data cannot substitute.")
        group = handle["layers/counts"]
        encoding = group.attrs.get("encoding-type", "")
        if isinstance(encoding, bytes):
            encoding = encoding.decode()
        if encoding not in ("csr_matrix", "csc_matrix"):
            raise ValueError("Expected a sparse original 08O count layer. Full dense expression is not loaded by this workflow.")
        shape = tuple(group.attrs["shape"])
        constructor = sp.csr_matrix if encoding == "csr_matrix" else sp.csc_matrix
        counts = constructor((group["data"][:], group["indices"][:], group["indptr"][:]), shape=shape).tocsr()
        original_identity = None
        if "uns/08m/analysis_id" in handle:
            original_identity = _read_elem(handle["uns/08m/analysis_id"])
    receipt = json.loads(Path(inputs["receipt_path"]).read_text())
    if original_identity is None or original_identity != receipt.get("analysis_id"):
        raise ValueError("08O H5AD and its completion receipt have different analysis identities.")
    required = {"sample", "condition", "population", "total_counts", "n_genes_by_counts"}
    if required - set(obs):
        raise ValueError(f"Required 08O observation fields missing: {sorted(required - set(obs))}")
    if obs[list(required)].isna().any().any():
        raise ValueError("Required 08O metadata contains missing values.")
    if obs.index.has_duplicates or var.index.has_duplicates:
        raise ValueError("Unique cell IDs and gene symbols are required.")
    if not obs["population"].astype(str).isin(POPULATIONS).all():
        raise ValueError("This pilot requires the completed T cell 1 + T cell 2 subset. T-centric weights must not be applied to all lineages.")
    if len(obs) != int(inputs["index"]["analyzed_cells"]) or counts.shape != (len(obs), len(var)):
        raise ValueError("The 08O pointer, count matrix and cell/gene metadata dimensions disagree.")
    if "selected_cells" in inputs["index"] and int(inputs["index"]["selected_cells"]) != len(obs):
        raise ValueError("The completed 08O result contains fewer cells than its selected T-cell population. "
                         "This all-T-cell test requires the full 08O result; no biological cell subsampling is applied here.")
    counts.sum_duplicates()
    counts.eliminate_zeros()
    counts.sort_indices()
    for left in range(0, counts.nnz, 2_000_000):
        values = counts.data[left:left + 2_000_000]
        if (not np.isfinite(values).all() or np.any(values < 0)
                or not np.equal(values, np.rint(values)).all()):
            raise ValueError("The count layer must hold finite, nonnegative original integer-valued observations.")
        if values.size and values.max() > 2 ** 24:
            raise ValueError("Observed counts exceed exact float32 integer storage.")
    full = obs["total_counts"].to_numpy(dtype=np.float64)
    if (not np.isfinite(full).all() or (full <= 0).any()
            or not np.equal(full, np.rint(full)).all()):
        raise ValueError("Positive full-source library sizes are required; no cells will be silently removed.")
    common = np.asarray(counts.sum(axis=1, dtype=np.float64)).ravel()
    if (common > full + 1e-7).any():
        raise ValueError("Common-gene counts exceed the stored full-source library sizes.")
    detected = np.diff(counts.indptr)
    if not np.array_equal(detected, obs["n_genes_by_counts"].to_numpy()):
        raise ValueError("Stored detected-gene numbers disagree with the original common-gene counts.")
    slim = pd.DataFrame(index=obs.index.astype(str))
    slim.index.name = "cell_id"
    for out, source in [("sample_id", "sample"), ("condition", "condition"),
                        ("population", "population"), ("total_counts", "total_counts"),
                        ("n_genes", "n_genes_by_counts")]:
        slim[out] = obs[source].to_numpy()
    for col in ["unit", "cell_id"]:
        if col in obs:
            slim["source_cell_id" if col == "cell_id" else col] = obs[col].astype(str).to_numpy()
    slim["common_gene_counts"] = common
    _unchanged(inputs)
    return counts, var.index.astype(str).to_numpy(), slim


def soft_weights(ratios, midpoint=0.75, power=2.0):
    ratios = np.asarray(ratios, dtype=np.float64)
    if not np.isfinite(midpoint) or midpoint <= 0 or not np.isfinite(power) or power <= 0:
        raise ValueError("The smooth-weight midpoint and exponent must be positive and finite.")
    if not np.isfinite(ratios).all() or np.any(ratios < 0):
        raise ValueError("Eligible genes require finite nonnegative ratios; missing ratios are not zero.")
    log_ratio = np.full_like(ratios, -np.inf)
    positive = ratios > 0
    log_ratio[positive] = np.log(ratios[positive]) - np.log(midpoint)
    values = np.exp(-np.logaddexp(0.0, power * log_ratio))
    return np.maximum(values, np.finfo(np.float32).tiny).astype(np.float32)


def log_normalize(counts, full_library_sizes, target_sum=10000.0, block_rows=25000):
    """Full-source exposure normalization; multiplication/log preserve sparsity."""
    full = np.asarray(full_library_sizes, dtype=np.float64)
    if full.shape != (counts.shape[0],) or not np.isfinite(full).all() or np.any(full <= 0):
        raise ValueError("Invalid full-source library sizes.")
    out = counts.astype(np.float32, copy=True).tocsr()
    for left in range(0, out.shape[0], block_rows):
        right = min(out.shape[0], left + block_rows)
        lo, hi = out.indptr[left], out.indptr[right]
        row_factors = (float(target_sum) / full[left:right]).astype(np.float32)
        out.data[lo:hi] *= np.repeat(row_factors, np.diff(out.indptr[left:right + 1]))
        np.log1p(out.data[lo:hi], out=out.data[lo:hi])
    return out


def _save_npz(path, matrix):
    path = Path(path)
    temp = path.with_name(path.stem + ".partial.npz")
    sp.save_npz(temp, matrix, compressed=False)
    temp.replace(path)


def _complete_cache(cache):
    path = Path(cache) / "cache_manifest.json"
    if not path.is_file():
        return None
    try:
        manifest = json.loads(path.read_text())
        files = manifest.get("files", {})
        if files and all((Path(cache) / name).is_file()
                         and (Path(cache) / name).stat().st_size == size for name, size in files.items()):
            return manifest
    except (OSError, ValueError):
        pass
    return None


def _reuse_normalized_data(base, cache, manifest, inputs, spec, identity, data_identity):
    """Reuse immutable arrays across weight curves; update only small weight tables."""
    cache.mkdir(parents=True, exist_ok=True)
    shared_names = ["lognorm_features.npz", "obs.csv.gz", "marker_counts.npz",
                    "marker_log1p.npz", "marker_genes.csv"]
    for name in shared_names:
        destination = cache / name
        destination.unlink(missing_ok=True)
        try:
            os.link(base / name, destination)
        except OSError:
            shutil.copy2(base / name, destination)
    features = pd.read_csv(base / "features.csv", dtype={"gene": str})
    features["weight"] = soft_weights(features["ratio"], spec["midpoint"], spec["power"])
    features["weighted_variance"] = features["weight"] * features["variance_log1p"]
    features.to_csv(cache / "features.csv", index=False)
    audit = pd.read_csv(base / "feature_audit_all_genes.csv", dtype={"gene": str})
    audit["weight_08S"] = audit["gene"].map(features.set_index("gene")["weight"])
    audit.to_csv(cache / "feature_audit_all_genes.csv", index=False)
    save_json(cache / "source_inputs.json", inputs)
    save_json(cache / "preparation_settings.json", spec)
    updated = dict(manifest)
    updated.update(cache_id=identity, data_identity=data_identity,
                   midpoint=spec["midpoint"], power=spec["power"], preparation_seconds=0,
                   reused_normalized_cache=str(base))
    updated["files"] = {name: (cache / name).stat().st_size for name in manifest["files"]}
    _unchanged(inputs)
    save_json(cache / "cache_manifest.json", updated)
    print(f"Reused normalized expression and original marker matrices; applied new curve {spec['midpoint']}, {spec['power']}.", flush=True)
    return cache, updated


def prepare_cache(inputs, marker_genes, *, midpoint=0.75, power=2.0, min_detected_cells=20,
                  target_sum=10000.0, resume=True):
    """Build one broad feature cache and compact original marker matrices.

    Both branches share this exact feature set. The previous HVG and ratio-pass
    masks are ignored. All cells are kept, including cells with zero eligible
    feature counts; those cells are reported explicitly.
    """
    if isinstance(min_detected_cells, bool) or int(min_detected_cells) != min_detected_cells or min_detected_cells < 1:
        raise ValueError("min_detected_cells must be a positive integer.")
    _unchanged(inputs)
    marker_genes = list(dict.fromkeys(map(str, marker_genes)))
    spec = {"version": VERSION, "sources": inputs["source_signatures"], "midpoint": midpoint,
            "power": power, "min_detected_cells": int(min_detected_cells), "target_sum": target_sum,
            "marker_genes": marker_genes, "normalization": "original full-source library totals"}
    identity = _digest(spec)
    data_spec = {key: value for key, value in spec.items() if key not in ("midpoint", "power")}
    data_identity = _digest(data_spec)
    folder = Path(inputs["output_root"]) / identity[:20]
    cache = folder / "cache"
    manifest_path = cache / "cache_manifest.json"
    if resume:
        manifest = _complete_cache(cache)
        if manifest and manifest.get("cache_id") == identity:
            print(f"Reusing complete 08S feature cache: {cache}", flush=True)
            return cache, manifest
    base_index = Path(inputs["output_root"]) / "prepared" / data_identity[:20] / "data_cache.json"
    if resume and base_index.is_file():
        base_info = json.loads(base_index.read_text())
        base = Path(base_info["cache_dir"])
        previous = _complete_cache(base)
        if base.resolve() != cache.resolve() and previous and previous.get("data_identity") == data_identity:
            return _reuse_normalized_data(base, cache, previous, inputs, spec, identity, data_identity)
    cache.mkdir(parents=True, exist_ok=True)
    manifest_path.unlink(missing_ok=True)
    started = time.perf_counter()
    counts, genes, obs = load_original_counts(inputs)
    audit = pd.read_csv(inputs["ratio_path"], dtype={"gene": str})
    if "gene" not in audit or "ratio" not in audit or audit["gene"].isna().any() or audit["gene"].duplicated().any():
        raise ValueError("The 08O gene-ratio audit requires unique gene symbols and a ratio column.")
    if set(audit["gene"]) != set(genes):
        raise ValueError("The gene-ratio audit and 08O gene universe differ. Use the completed matching 08O result.")
    audit = audit.set_index("gene").reindex(genes).reset_index()
    ratios = pd.to_numeric(audit["ratio"], errors="raise").to_numpy(dtype=float)
    detected = np.asarray((counts > 0).sum(axis=0)).ravel().astype(np.int64)
    normalized = log_normalize(counts, obs["total_counts"].to_numpy(), target_sum)
    sums = np.asarray(normalized.sum(axis=0, dtype=np.float64)).ravel()
    means = sums / counts.shape[0]
    centered_sum_sq = (counts.shape[0] - detected) * means ** 2
    for left in range(0, normalized.nnz, 2_000_000):
        right = min(normalized.nnz, left + 2_000_000)
        columns = normalized.indices[left:right]
        deviations = normalized.data[left:right].astype(np.float64) - means[columns]
        centered_sum_sq += np.bincount(columns, weights=deviations * deviations,
                                      minlength=normalized.shape[1])
    variances = centered_sum_sq / counts.shape[0]
    eligible = (detected >= min_detected_cells) & (variances > 1e-14)
    if np.any(eligible & (~np.isfinite(ratios) | (ratios < 0))):
        bad = genes[eligible & (~np.isfinite(ratios) | (ratios < 0))]
        raise ValueError("Eligible genes lack valid ratios: " + ", ".join(bad[:20])
                         + ". Undefined ratios are not interpreted as maximum T specificity.")
    if eligible.sum() < 3:
        raise ValueError("Fewer than three eligible genes remain; inspect the selected 08O source.")
    weights = np.full(len(genes), np.nan)
    weights[eligible] = soft_weights(ratios[eligible], midpoint, power)
    audit["detected_cells_08S"] = detected
    audit["variance_log1p_08S"] = variances
    audit["eligible_08S"] = eligible
    audit["weight_08S"] = weights
    audit["eligibility_reason"] = np.where(detected < min_detected_cells, "too_few_observed_cells",
                                          np.where(variances <= 1e-14, "zero_variance", "included"))
    audit.to_csv(cache / "feature_audit_all_genes.csv", index=False)
    features = pd.DataFrame({"gene": genes[eligible], "ratio": ratios[eligible], "weight": weights[eligible],
                             "detected_cells": detected[eligible], "variance_log1p": variances[eligible]})
    features["weighted_variance"] = features["weight"] * features["variance_log1p"]
    features.to_csv(cache / "features.csv", index=False)
    positions = {gene: i for i, gene in enumerate(genes)}
    observed_markers = [gene for gene in marker_genes if gene in positions]
    marker_positions = [positions[gene] for gene in observed_markers]
    marker_counts = counts[:, marker_positions].tocsr()
    marker_log = normalized[:, marker_positions].tocsr()
    matrix = normalized[:, eligible].tocsr()
    observed_feature_counts = np.asarray(counts[:, eligible].sum(axis=1, dtype=np.float64)).ravel()
    obs["eligible_feature_counts"] = observed_feature_counts
    obs["no_observed_eligible_feature"] = observed_feature_counts == 0
    obs.to_csv(cache / "obs.csv.gz", index=True)
    _save_npz(cache / "lognorm_features.npz", matrix)
    _save_npz(cache / "marker_counts.npz", marker_counts)
    _save_npz(cache / "marker_log1p.npz", marker_log)
    pd.DataFrame({"gene": observed_markers}).to_csv(cache / "marker_genes.csv", index=False)
    save_json(cache / "source_inputs.json", inputs)
    save_json(cache / "preparation_settings.json", spec)
    files = ["lognorm_features.npz", "obs.csv.gz", "features.csv", "feature_audit_all_genes.csv",
             "marker_counts.npz", "marker_log1p.npz", "marker_genes.csv", "source_inputs.json",
             "preparation_settings.json"]
    manifest = {"version": VERSION, "cache_id": identity, "data_identity": data_identity,
                "shape": list(matrix.shape),
                "n_cells": int(counts.shape[0]), "n_source_genes": int(counts.shape[1]),
                "n_features": int(eligible.sum()), "nnz": int(matrix.nnz),
                "all_08O_cells_retained": True, "sample_key": "sample_id", "condition_key": "condition",
                "n_samples": int(obs["sample_id"].nunique()), "n_conditions": int(obs["condition"].nunique()),
                "zero_feature_cells": int(obs["no_observed_eligible_feature"].sum()),
                "cell_order_hash": ordered_id_hash(obs.index), "gene_order_hash": ordered_id_hash(features["gene"]),
                "engine_cell_ids_sha256": ordered_id_hash(obs.index),
                "engine_gene_ids_sha256": ordered_id_hash(features["gene"]),
                "preparation_seconds": time.perf_counter() - started,
                "weight_definition": "1 / (1 + (neighbor_to_T_ratio / midpoint)**power)",
                "column_multiplier": "sqrt(weight)", "midpoint": midpoint, "power": power,
                "original_counts_modified": False,
                "ratio_weight_semantics": "T-compartment feature importance; not corrected transcript counts",
                "feature_policy": "broad observed genes; basic detection/variance eligibility; old HVG and ratio cutoffs ignored",
                "missing_marker_genes": [g for g in marker_genes if g not in positions],
                "csr_bytes": int(matrix.data.nbytes + matrix.indices.nbytes + matrix.indptr.nbytes),
                "files": {name: (cache / name).stat().st_size for name in files}}
    _unchanged(inputs)
    save_json(manifest_path, manifest)
    save_json(base_index, {"data_identity": data_identity, "cache_dir": str(cache)})
    print(f"Prepared {matrix.shape[0]:,} cells x {matrix.shape[1]:,} broad genes; "
          f"CSR {manifest['csr_bytes'] / 2**30:.2f} GiB; "
          f"{manifest['zero_feature_cells']:,} cells with zero eligible-feature counts retained.", flush=True)
    del counts, normalized, marker_counts, marker_log, matrix
    gc.collect()
    return cache, manifest


def _process_env(device=None):
    env = os.environ.copy()
    for name in ["OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
        env[name] = "8"
    env["PYTHONUNBUFFERED"] = "1"
    if device is not None:
        previous = env.get("CUDA_VISIBLE_DEVICES")
        if previous is not None:
            visible = [token.strip() for token in previous.split(",") if token.strip()]
            if int(device) >= len(visible):
                raise ValueError("Requested logical GPU is outside CUDA_VISIBLE_DEVICES.")
            env["CUDA_VISIBLE_DEVICES"] = visible[int(device)]
        else:
            env["CUDA_VISIBLE_DEVICES"] = str(int(device))
    return env


class GPUPreflightError(RuntimeError):
    """Startup failure with a small, already-written diagnostic archive."""

    def __init__(self, message, diagnostic_zip):
        super().__init__(message)
        self.diagnostic_zip = Path(diagnostic_zip)


def preflight_gpu(helper_dir, *, log_dir=None, timeout_seconds=600.0,
                  heartbeat_seconds=15.0, poll_seconds=0.25):
    """Stream and retain the isolated GPU check, including failure/timeout output.

    A regular log file receives child stdout and stderr directly, so diagnostic
    output survives a parent-kernel interruption and cannot fill a PIPE buffer.
    The notebook tails that file while the child runs. Numerical settings and
    prepared-data/checkpoint identities are unchanged by this diagnostic release.
    """
    for name, value in [("timeout_seconds", timeout_seconds),
                        ("heartbeat_seconds", heartbeat_seconds), ("poll_seconds", poll_seconds)]:
        if not np.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be positive and finite.")
    helper = Path(helper_dir).expanduser().resolve() / "tcell_weighted_gpu.py"
    if log_dir is None:
        stamp = pd.Timestamp.now(tz="UTC").strftime("%Y%m%dT%H%M%SZ")
        log_dir = Path.cwd() / "08S_diagnostics" / f"preflight_{stamp}_{uuid.uuid4().hex[:8]}"
    directory = Path(log_dir).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    log_path = directory / "preflight.log"
    report_path = directory / "preflight_report.json"
    diagnostic_zip = directory / "08S_preflight_diagnostics.zip"
    command = [sys.executable, str(helper), "--preflight-only", "--gpu-device", "0"]
    report = {"release_version": RELEASE_VERSION, "status": "starting",
              "started_utc": pd.Timestamp.now(tz="UTC").isoformat(),
              "python_executable": sys.executable, "python_version": sys.version,
              "helper_path": str(helper), "timeout_seconds": float(timeout_seconds),
              "log_path": str(log_path), "diagnostic_zip": str(diagnostic_zip),
              "biological_data_loaded_by_check": False}
    save_json(report_path, report)
    print(f"GPU startup check: live output below; timeout {timeout_seconds:g} seconds.", flush=True)
    print(f"Startup log: {log_path}", flush=True)
    started = time.monotonic()
    last_output_at = started
    last_heartbeat_at = started
    process = writer = reader = None

    def show_new_output():
        nonlocal last_output_at
        if reader is None:
            return
        chunk = reader.read()
        if chunk:
            print(chunk, end="", flush=True)
            last_output_at = time.monotonic()
            lines = [line for line in chunk.splitlines() if line.strip()]
            if lines:
                report["last_output_line"] = lines[-1][-2000:]

    try:
        writer = log_path.open("w", encoding="utf-8")
        reader = log_path.open("r", encoding="utf-8", errors="replace")
        process = subprocess.Popen(command, env=_process_env(), stdout=writer,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        report.update(status="running", pid=process.pid)
        save_json(report_path, report)
        while True:
            show_new_output()
            code = process.poll()
            now = time.monotonic()
            elapsed = now - started
            if code is not None:
                show_new_output()
                break
            if elapsed >= timeout_seconds:
                report["status"] = "timeout"
                raise GPUPreflightError(
                    f"GPU startup check exceeded {timeout_seconds:g} seconds. "
                    f"The unfinished check was stopped; its partial log is retained. "
                    f"Return this diagnostic ZIP: {diagnostic_zip}", diagnostic_zip)
            if now - last_heartbeat_at >= heartbeat_seconds:
                print(f"[08S preflight] still running: {elapsed:.0f}s elapsed; "
                      f"{now - last_output_at:.0f}s since the last child output.", flush=True)
                report["elapsed_seconds"] = elapsed
                save_json(report_path, report)
                last_heartbeat_at = now
            time.sleep(min(float(poll_seconds), max(0.001, timeout_seconds - elapsed)))
        report["returncode"] = code
        if code != 0:
            reason = f"exited with status {code}"
            if code < 0:
                try:
                    reason = f"terminated by signal {signal.Signals(-code).name} ({-code})"
                except ValueError:
                    reason = f"terminated by signal {-code}"
            report["status"] = "failed"
            raise GPUPreflightError(
                f"GPU startup check {reason}. The captured stdout/stderr and any traceback are saved. "
                f"Return this diagnostic ZIP: {diagnostic_zip}", diagnostic_zip)
        parsed = None
        for line in log_path.read_text(encoding="utf-8", errors="replace").splitlines()[::-1]:
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict) and "ok" in candidate:
                parsed = candidate
                break
        if (parsed is None or parsed.get("ok") is not True
                or not isinstance(parsed.get("visible_device_count"), int)
                or isinstance(parsed.get("visible_device_count"), bool)
                or parsed["visible_device_count"] < 1):
            report["status"] = "invalid_report"
            raise GPUPreflightError(
                f"GPU startup did not return a valid success report. "
                f"Return this diagnostic ZIP: {diagnostic_zip}", diagnostic_zip)
        report.update(status="passed", gpu_report=parsed)
        return dict(parsed, diagnostic_zip=str(diagnostic_zip),
                    preflight_log_path=str(log_path), preflight_report_path=str(report_path))
    except BaseException as exc:
        if report["status"] in ("starting", "running"):
            report["status"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
        report["error"] = {"type": type(exc).__name__, "message": str(exc)}
        # The notebook can offer the archive link even after a manual interrupt.
        if not hasattr(exc, "diagnostic_zip"):
            exc.diagnostic_zip = diagnostic_zip
        raise
    finally:
        if process is not None:
            _stop_owned(process)
            report["returncode"] = process.poll()
        if writer is not None:
            writer.close()
        show_new_output()
        if reader is not None:
            reader.close()
        report["elapsed_seconds"] = time.monotonic() - started
        report["finished_utc"] = pd.Timestamp.now(tz="UTC").isoformat()
        save_json(report_path, report)
        temporary = diagnostic_zip.with_suffix(".zip.partial")
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in (log_path, report_path):
                if path.is_file():
                    archive.write(path, path.name)
        temporary.replace(diagnostic_zip)
        print(f"Startup status: {report['status']}; diagnostics: {diagnostic_zip}", flush=True)


def _stop_owned(process):
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=10)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)


def launch_comparison(cache_dir, helper_dir, runtime, *, settings=None, devices=None,
                      max_minutes=100.0, resume=True):
    """Run matched full-T analyses in fresh processes, respecting visible GPUs.

    Two GPUs run the branches concurrently; one GPU runs them sequentially.
    An interrupt/time limit terminates only processes started by this call.
    """
    cache = Path(cache_dir).resolve()
    helper = Path(helper_dir).resolve() / "tcell_weighted_gpu.py"
    count = int(runtime.get("visible_device_count", runtime.get("device_count", 1)))
    if devices is None:
        devices = tuple(range(min(2, count)))
    devices = tuple(map(int, devices))
    if not devices or len(set(devices)) != len(devices) or any(d < 0 or d >= count for d in devices):
        raise ValueError("Choose one or two distinct logical visible GPU indices.")
    devices = devices[:2]
    if not np.isfinite(max_minutes) or max_minutes <= 0:
        raise ValueError("A positive GPU time budget is required.")
    settings = dict(settings or {})
    manifest = json.loads((cache / "cache_manifest.json").read_text())
    run_identity = _digest({"cache_id": manifest["cache_id"], "settings": settings, "version": VERSION})[:16]
    run_root = cache.parent / "runs" / run_identity
    run_root.mkdir(parents=True, exist_ok=True)
    settings_path = run_root / "gpu_settings.json"
    save_json(settings_path, settings)
    save_json(run_root / "launch.json", {"cache": str(cache), "devices": devices, "settings": settings,
              "max_minutes": max_minutes, "started_utc": pd.Timestamp.now(tz="UTC").isoformat(),
              "visible_device_count": count, "version": VERSION})
    pending = ["unweighted", "weighted"]
    active, completed, failed = {}, {}, []
    started = time.monotonic()
    free_devices = list(devices)
    control_id = _digest({"data_identity": manifest.get("data_identity", manifest["cache_id"]),
                          "settings": settings, "version": VERSION})[:20]
    shared_control = cache.parent.parent / "controls" / control_id / "unweighted"
    readers = []
    try:
        while pending or active:
            while pending and free_devices:
                branch = pending.pop(0)
                device = free_devices.pop(0)
                out = shared_control if branch == "unweighted" else run_root / branch
                out.mkdir(parents=True, exist_ok=True)
                log_path = out / "console.log"
                handle = log_path.open("w")
                command = [sys.executable, str(helper), "--cache-dir", str(cache), "--output-dir", str(out),
                           "--branch", branch, "--gpu-device", "0", "--settings-json", str(settings_path)]
                if not resume:
                    command.append("--no-resume")
                process = subprocess.Popen(command, env=_process_env(device), stdout=handle,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                reader = log_path.open("r")
                readers.append(reader)
                active[branch] = {"process": process, "writer": handle, "reader": reader,
                                  "device": device, "output": out}
                print(f"Started {branch}: logical GPU {device}; all {manifest['n_cells']:,} T cells.", flush=True)
            if time.monotonic() - started > max_minutes * 60:
                raise TimeoutError(f"08S GPU work reached its {max_minutes:g}-minute budget. Completed checkpoints are retained in {run_root}.")
            for branch, state in list(active.items()):
                for line in state["reader"].readlines():
                    print(f"[{branch}] {line.rstrip()}", flush=True)
                code = state["process"].poll()
                if code is not None:
                    state["writer"].close()
                    for line in state["reader"].readlines():
                        print(f"[{branch}] {line.rstrip()}", flush=True)
                    free_devices.append(state["device"])
                    if code == 0 and (state["output"] / "embedding.h5ad").is_file():
                        completed[branch] = state["output"] / "embedding.h5ad"
                    else:
                        failed.append((branch, code, str(state["output"] / "console.log")))
                    del active[branch]
            if active:
                time.sleep(1)
        if failed:
            raise RuntimeError(f"One or more 08S branches failed: {failed}. Successful branches/checkpoints remain available for restart.")
        save_json(run_root / "comparison_complete.json", {"branches": completed,
                  "elapsed_seconds": time.monotonic() - started, "cache_id": manifest["cache_id"]})
        return completed, run_root
    finally:
        for state in active.values():
            _stop_owned(state["process"])
            state["writer"].close()
        for reader in readers:
            reader.close()


def load_review_data(cache_dir, branches):
    import anndata as ad
    cache = Path(cache_dir)
    obs = pd.read_csv(cache / "obs.csv.gz", dtype={"cell_id": str, "sample_id": str,
                                                       "condition": str, "population": str}).set_index("cell_id")
    genes = pd.read_csv(cache / "marker_genes.csv", dtype=str)["gene"].tolist()
    counts = sp.load_npz(cache / "marker_counts.npz").tocsr()
    log_expr = sp.load_npz(cache / "marker_log1p.npz").tocsr()
    methods = {}
    for name in ["unweighted", "weighted"]:
        data = ad.read_h5ad(branches[name])
        if not np.array_equal(data.obs_names.astype(str), obs.index.astype(str)):
            raise ValueError(f"Cell order differs in {name}; review cannot safely proceed.")
        methods[name] = data
    return log_expr, counts, genes, obs, methods


def make_return_package(run_root, cache_dir, review_dir, max_megabytes=25):
    """Small upload package: aggregate reviews, timing and audits; no cell matrices."""
    root, cache, review = map(Path, [run_root, cache_dir, review_dir])
    archive = root / "08S_return_to_chat.zip"
    selected = []
    candidates = [(cache / "cache_manifest.json", "cache/cache_manifest.json"),
                  (cache / "features.csv", "cache/features.csv"),
                  (root / "launch.json", "launch.json"),
                  (root / "comparison_complete.json", "comparison_complete.json")]
    completed = json.loads((root / "comparison_complete.json").read_text()).get("branches", {})
    for branch in ["unweighted", "weighted"]:
        directory = Path(completed[branch]).parent if branch in completed else root / branch
        candidates.extend([(directory / "run_metadata.json", branch + "/run_metadata.json"),
                           (directory / "console.log", branch + "/console.log")])
    omitted = []
    if review.is_dir():
        def priority(path):
            if path.suffix.lower() not in (".png", ".pdf"):
                return (0, path.stat().st_size)
            if "leiden_0_4_lineage_mean_log1p" in path.name:
                return (10, path.name)
            order = {"umap_clusters.png": 20, "umap_sample_condition_depth.png": 21,
                     "umap_lineage_markers.png": 22, "umap_treg_support.png": 23,
                     "umap_background_markers.png": 24}
            return (order.get(path.name, 30), path.stat().st_size)
        review_files = []
        for path in review.rglob("*"):
            if not path.is_file():
                continue
            if path.name in ("observed_marker_evidence.csv.gz", "umap_display_cell_ids.csv.gz"):
                omitted.append({"file": path.name, "reason": "per-cell display/evidence table; aggregate diagnostics included",
                                "bytes": path.stat().st_size})
            elif path.name != "review.html":
                review_files.append(path)
        candidates.extend((p, "review/" + str(p.relative_to(review))) for p in
                          sorted(review_files, key=priority))
    budget = int(max_megabytes * 1_000_000)
    total = 0
    for path, name in candidates:
        if not path.is_file() or path == archive or path.suffix in (".h5ad", ".npz"):
            continue
        size = path.stat().st_size
        if total + size > budget:
            omitted.append({"file": path.name, "reason": "compact upload budget", "bytes": size})
            continue
        total += size
        selected.append((path, name))
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for path, name in selected:
            handle.write(path, name)
        links = []
        figures = []
        for path, name in selected:
            if not name.startswith("review/"):
                continue
            relative = name[len("review/"):]
            safe = html.escape(relative)
            label = html.escape(path.name)
            if path.suffix.lower() == ".png":
                figures.append(f'<h2>{label}</h2><img loading="lazy" src="{safe}" alt="{label}" style="max-width:100%">')
            else:
                links.append(f'<li><a href="{safe}">{label}</a></li>')
        compact = ('<!doctype html><html><head><meta charset="utf-8"><title>08S compact review</title></head>'
                   '<body style="font:16px/1.5 system-ui,sans-serif;max-width:1500px;margin:30px auto;padding:20px">'
                   '<h1>08S compact return review</h1><p>Original, unweighted marker expression; all-cell statistics. '
                   'This compact archive includes selected figures. See PACKAGE_CONTENTS.json for omitted items; '
                   'the complete report remains in the local analysis output.</p><ul>'
                   + ''.join(links) + '</ul>' + ''.join(figures) + '</body></html>')
        handle.writestr("review/compact_review.html", compact)
        handle.writestr("PACKAGE_CONTENTS.json", json.dumps({"files": [x[1] for x in selected],
                          "generated_files": ["review/compact_review.html"],
                          "omitted": omitted, "matrix_data_included": False}, indent=2))
    print(f"Return this compact file for review: {archive} ({archive.stat().st_size / 1e6:.1f} MB)", flush=True)
    return archive
