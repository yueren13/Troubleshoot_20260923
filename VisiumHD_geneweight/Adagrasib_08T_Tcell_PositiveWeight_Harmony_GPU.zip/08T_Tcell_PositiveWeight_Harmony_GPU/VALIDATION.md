# 08T validation

Release **1.0.0**. Validation completed in the build environment on Python 3.12.

## Completed checks

**33 targeted automated tests passed**, followed by a successful integrated synthetic notebook execution.

| Area | Tests | What was checked |
|---|---:|---|
| GPU mathematical contract and compatibility | 14 | Boosted sparse PCA against directly centered dense SVD; input preservation; exact-zero holdout invariance; invalid weights; active-feature bounds; applied-weight hashes; checkpoint invalidation; read-only completed-result validation; strict CuPy transfer and sparse-API compatibility |
| Variant preparation and orchestration | 9 | Exact four-variant weights; unchanged source assay bytes/timestamps; hardlink-to-copy fallback; stable and changing identities; missing panel reporting; safe baseline copying; row order; actual fresh CPU fixture subprocesses under one/four logical GPU mappings; failure and timeout cleanup |
| Companion review | 10 | Original-count denominators; graph-score arithmetic; zero-weight enforcement; stale embedding and inclusion-flag rejection; row order; missing assays; measured all-zero companions; self-edge exclusion; shared-stratum eligibility; fractional-count rejection; original matrix preservation |

The four stage fingerprints reconstructed from the user's actual completed midpoint-0.60 metadata matched exactly. On a deterministic suppression-only fixture, the extended sparse PCA produced array-identical outputs to the working 08S engine.

## Integrated notebook execution

Every actual notebook code cell was executed on a synthetic completed-08O project with **400 cells, 58 eligible genes, four samples, two conditions, and varying full-library depths**. Only GPU preflight and GPU launch were replaced by explicitly labeled synthetic outputs. The actual input discovery, embedded helper loading, preparation, weight audit, marker reports, held-out report, companion checks, report index, result copies and ZIP export were executed.

Verified outcomes:

- The original H5AD SHA-256 remained unchanged and all cells were retained.
- Original marker counts and full-library log1p values were preserved.
- Saved feature weights for all four variants matched their specifications.
- Reserved genes had exact-zero effective weights and false inclusion flags in both diagnostic embeddings.
- All **205 relative links** in HTML and compact-ZIP reports resolved.
- The synthetic return ZIP was **5.61 MB**, with no H5ADs, NPZ matrices, or per-cell evidence/display/assignment tables.
- Main lineage and companion diagnostic figures were visually inspected for legibility and labeling.
- Notebook schema, Python code-cell syntax, clean output state, and agreement between embedded and readable helper source were checked.

## Interpretation and limits

No actual CUDA execution or biological analysis was performed in the build environment. The notebook's synthetic GPU preflight tests the installed RAPIDS/CuPy path, including weights above one and exact-zero held-out weights, on the user's instance before the biological run. Actual GPU memory use, runtime and biological improvement are not guaranteed by these CPU checks.

The test checks feature importance, not molecule decontamination. The held-out comparison provides descriptive CD8/Treg companion evidence and does not independently validate CD4 identity or establish cell-typing accuracy. A predeclared positive boost may strengthen isolated detection events as well as coherent programs; original-marker and sample/depth reviews remain necessary.
