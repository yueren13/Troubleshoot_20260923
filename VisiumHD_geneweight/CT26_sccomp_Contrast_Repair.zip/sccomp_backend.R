#!/usr/bin/env Rscript
# Reference sccomp API matched to Bioconductor RELEASE_3_22 (2.2.x), with named-formal checks.
a<-commandArgs(trailingOnly=TRUE)
for(p in c('jsonlite','sccomp','cmdstanr')) if(!requireNamespace(p,quietly=TRUE)) stop('Required package absent: ',p)
suppressPackageStartupMessages(library(sccomp))

# CT26 sccomp contrast compatibility repair. Quote parameter TOKENS, not the whole expression.
# No change to the installed sccomp namespace, biological labels, count matrix or model.
CT26_BACKEND_PATCH <- "ct26-sccomp-backtick-contrasts-20261111-v1"
ct26_contrast_pairs <- data.frame(
  numerator = c("AntiPD1", "Adagrasib", "Combination", "Adagrasib", "Combination", "Combination"),
  denominator = c("Vehicle", "Vehicle", "Vehicle", "AntiPD1", "AntiPD1", "Adagrasib"),
  stringsAsFactors = FALSE
)
ct26_contrasts <- function() {
  lhs <- paste0("condition", ct26_contrast_pairs$numerator)
  rhs <- paste0("condition", ct26_contrast_pairs$denominator)
  expressions <- paste0("`", lhs, "` - `", rhs, "`")
  # Preserve the ORIGINAL plain contrast names for plot_results()/CSV consumers.
  stats::setNames(expressions, paste(lhs, rhs, sep = " - "))
}
ct26_check_contrast_parser <- function() {
  ns <- asNamespace("sccomp")
  if (!exists("contrasts_to_parameter_list", envir = ns, inherits = FALSE) ||
      !exists("mutate_from_expr_list", envir = ns, inherits = FALSE)) {
    stop("Installed sccomp contrast internals differ. No package files were changed.")
  }
  parser <- get("contrasts_to_parameter_list", envir = ns, inherits = FALSE)
  evaluator <- get("mutate_from_expr_list", envir = ns, inherits = FALSE)
  requested <- ct26_contrasts()
  expected <- c("conditionVehicle", "conditionAntiPD1", "conditionAdagrasib", "conditionCombination")
  parsed <- unique(as.character(parser(requested)))
  if (!setequal(parsed, expected)) {
    stop("Quoted-token preflight failed. Expected: ", paste(expected, collapse = ", "),
         "; parser returned: ", paste(parsed, collapse = ", "),
         ". Do not fit the model until this mismatch is resolved.")
  }
  # Isolate the digit bug: the unquoted expression may lose the final '1'.
  unquoted <- unique(as.character(parser(unname(names(requested)))))
  synthetic_draws <- tibble::tibble(
    M = c(1L, 1L, 2L), .chain = c(1L, 1L, 1L),
    .iteration = 1:3, .draw = 1:3,
    conditionVehicle = c(1, 3, 7), conditionAntiPD1 = c(4, 8, 10),
    conditionAdagrasib = c(6, 12, 15), conditionCombination = c(11, 19, 22)
  )
  evaluated <- evaluator(synthetic_draws, requested, ignore_errors = FALSE)
  if (!all(names(requested) %in% names(evaluated))) stop("Contrast evaluator omitted an expected comparison.")
  for (i in seq_along(requested)) {
    lhs <- paste0("condition", ct26_contrast_pairs$numerator[[i]])
    rhs <- paste0("condition", ct26_contrast_pairs$denominator[[i]])
    truth <- synthetic_draws[[lhs]] - synthetic_draws[[rhs]]
    value <- as.numeric(evaluated[[names(requested)[[i]]]])
    if (!isTRUE(all.equal(value, as.numeric(truth), tolerance = 1e-12))) {
      stop("Contrast arithmetic preflight failed for ", names(requested)[[i]])
    }
    vars <- all.vars(parse(text = unname(requested[[i]])))
    if (!setequal(vars, c(lhs, rhs))) stop("R expression variables differ from the intended comparison.")
  }
  list(status = "PASS", backend_patch = CT26_BACKEND_PATCH,
       checks = "All six expressions preserve parameter tokens and evaluate numerator minus denominator",
       unquoted_tokens = unquoted, quoted_tokens = parsed,
       original_digit_token_preserved = "conditionAntiPD1" %in% unquoted,
       quoted_digit_token_preserved = "conditionAntiPD1" %in% parsed,
       installed_package_modified = FALSE)
}
if(nzchar(Sys.getenv('CMDSTAN')))cmdstanr::set_cmdstan_path(Sys.getenv('CMDSTAN'))
if(length(a)==1 && a[1]=='--check') {
 cat(jsonlite::toJSON(list(R=R.version.string,sccomp=as.character(packageVersion('sccomp')),cmdstanr=as.character(packageVersion('cmdstanr')),
   cmdstan=as.character(cmdstanr::cmdstan_version()),cmdstan_path=cmdstanr::cmdstan_path(),
   estimate_formals=names(formals(sccomp::sccomp_estimate)),test_formals=names(formals(sccomp::sccomp_test)),
   backend_patch=CT26_BACKEND_PATCH,contrast_preflight=ct26_check_contrast_parser()),auto_unbox=TRUE),'\n');quit(status=0)
}
if(length(a)!=1)stop('Pass job.json')
j<-jsonlite::fromJSON(a[1]);s<-j$settings;out<-j$output;dir.create(out,recursive=TRUE,showWarnings=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'R_sessionInfo.txt'))
x<-read.csv(j$counts,check.names=FALSE,stringsAsFactors=FALSE)
need<-c('sample','condition','cell_group','count');if(!all(need %in% names(x)))stop('Counts table contract differs')
if(anyNA(x$count)||any(x$count<0)||any(x$count!=round(x$count)))stop('sccomp requires nonnegative integer cell counts, not percentages')
if(anyDuplicated(x[c('sample','cell_group')]))stop('Duplicate sample/cell-group entries')
lev<-c('Vehicle','AntiPD1','Adagrasib','Combination');x$condition<-factor(x$condition,levels=lev)
if(anyNA(x$condition))stop('Unknown condition')
units<-unique(x[c('sample','condition')]);if(anyDuplicated(units$sample)||any(table(units$condition)<3))stop('Need independent mice, three per condition')
if(any(tapply(x$count,x$sample,sum)==0))stop('Zero denominator sample; do not manufacture zero composition')
if(any(table(x$sample)!=length(unique(x$cell_group))))stop('Explicit complete zero-inclusive count grid required')
# Completely absent categories contribute no information; record rather than add pseudocounts.
total<-tapply(x$count,x$cell_group,sum);absent<-names(total)[total==0]
write.csv(data.frame(dropped_globally_absent_group=absent),file.path(out,'absent_groups.csv'),row.names=FALSE)
x<-x[!x$cell_group %in% absent,,drop=FALSE]
if(length(unique(x$cell_group))<2)stop('Composition requires at least two observed parts')
x$count<-as.integer(x$count)
parser_report <- ct26_check_contrast_parser()
jsonlite::write_json(parser_report, file.path(out, "contrast_parser_preflight.json"), auto_unbox = TRUE, pretty = TRUE)
requested_contrasts <- ct26_contrasts()
write.csv(data.frame(contrast = names(requested_contrasts),
                     expression = unname(requested_contrasts),
                     numerator = ct26_contrast_pairs$numerator,
                     denominator = ct26_contrast_pairs$denominator),
          file.path(out, "contrast_expression_audit.csv"), row.names = FALSE)
cache<-j$stan_cache;dir.create(cache,recursive=TRUE,showWarnings=FALSE)
args<-list(.data=tibble::as_tibble(x),formula_composition=~0+condition,formula_variability=~1,
 sample='sample',cell_group='cell_group',abundance='count',cores=as.integer(s$cores),inference_method='hmc',
 mcmc_seed=as.integer(s$seed),max_sampling_iterations=as.integer(s$max_sampling_iterations),pass_fit=TRUE,
 cache_stan_model=cache,output_directory=file.path(out,'stan_draws'),verbose=TRUE)
required<-setdiff(names(args),'.data')
if(!all(required %in% names(formals(sccomp::sccomp_estimate))))stop('Installed sccomp API differs. Inspect --check; do not silently swap methods.')
# No optional automated outlier removal: retain all three biological replicates per arm.
# Let the versioned package choose its HMC chain/ESS schedule, bounded by max_sampling_iterations.
estimate<-do.call(sccomp::sccomp_estimate,args)
saveRDS(estimate,file.path(out,'sccomp_estimate.rds'))
atomic<-function(d){d<-as.data.frame(d);d[,vapply(d,function(y)is.atomic(y)||is.factor(y),logical(1)),drop=FALSE]}
write.csv(atomic(estimate),file.path(out,'parameter_estimates.csv'),row.names=FALSE)
contrasts <- ct26_contrasts()
actual_parameters <- colnames(attr(estimate, "model_input")$X)
needed_parameters <- unique(unlist(lapply(unname(contrasts), function(z) all.vars(parse(text = z)))))
write.csv(data.frame(parameter = actual_parameters),
          file.path(out, "fitted_composition_parameters.csv"), row.names = FALSE)
if (!all(needed_parameters %in% actual_parameters)) {
  stop("The actual fitted model lacks requested parameters: ",
       paste(setdiff(needed_parameters, actual_parameters), collapse = ", "),
       ". Inspect fitted_composition_parameters.csv; no factor-label guessing is performed.")
}
# Version 2.2 names the threshold logit; current development calls it CLR. Save the actual API/scale.
tform<-names(formals(sccomp::sccomp_test));tn<-intersect(c('test_composition_above_logit_fold_change','test_composition_above_CLR_fold_change'),tform)
if(length(tn)!=1)stop('Unknown effect-threshold API in sccomp_test')
targs<-list(.data=estimate,contrasts=contrasts,pass_fit=TRUE);targs[[tn]]<-as.numeric(s$effect_threshold)
tested<-do.call(sccomp::sccomp_test,targs);saveRDS(tested,file.path(out,'sccomp_test.rds'))
result<-atomic(tested);write.csv(result,file.path(out,'contrasts.csv'),row.names=FALSE)
fit<-attr(estimate,'fit');diagnostics<-list();sm<-NULL
if(!is.null(fit)){
 diagnostics$summary<-tryCatch(fit$diagnostic_summary(),error=function(e)list(error=conditionMessage(e)))
 diagnostics$metadata<-tryCatch(fit$metadata(),error=function(e)list(error=conditionMessage(e)))
 writeLines(capture.output(print(diagnostics)),file.path(out,'Stan_diagnostics.txt'))
 sm<-tryCatch(fit$summary(),error=function(e)NULL)
 if(!is.null(sm))write.csv(sm,file.path(out,'Stan_parameter_summary.csv'),row.names=FALSE)
}
# sccomp can leave contrast-row R-hat fields NA: contrasts are not base coefficient names.
# Use actual fitted-parameter summaries for the pre-existing basic diagnostic flag.
rh_candidates <- numeric()
rh_cols <- intersect(c("c_rhat", "v_rhat", "c_R_k_hat", "v_R_k_hat"), names(estimate))
if (length(rh_cols)) rh_candidates <- c(rh_candidates, unlist(atomic(estimate)[rh_cols], use.names = FALSE))
if (!is.null(sm) && "rhat" %in% names(sm)) rh_candidates <- c(rh_candidates, as.numeric(sm$rhat))
rh_candidates <- as.numeric(rh_candidates)
max_rhat <- if (any(is.infinite(rh_candidates))) Inf else if (any(is.finite(rh_candidates))) max(rh_candidates[is.finite(rh_candidates)]) else NA_real_
div<-NA_integer_
if(is.list(diagnostics$summary)&&'num_divergent' %in% names(diagnostics$summary))div<-sum(diagnostics$summary$num_divergent)
# A failed diagnostic is surfaced and not translated into biological significance.
status<-if(is.finite(max_rhat)&&max_rhat<=1.05&&!is.na(div)&&div==0)'diagnostics_pass_basic' else 'REVIEW_CONVERGENCE'
if(isTRUE(s$posterior_predictive_plots)){
 tryCatch({
  plots<-sccomp::sccomp_boxplot(tested,factor='condition',cache_stan_model=cache)
  if(inherits(plots,c('ggplot','patchwork')))ggplot2::ggsave(file.path(out,'posterior_predictive_check.png'),plots,width=10,height=7,dpi=300)
  else if(is.list(plots))for(i in seq_along(plots))if(inherits(plots[[i]],c('ggplot','patchwork')))ggplot2::ggsave(file.path(out,paste0('posterior_predictive_',i,'.png')),plots[[i]],width=10,height=7,dpi=300)
 },error=function(e)writeLines(conditionMessage(e),file.path(out,'posterior_predictive_plot_error.txt')))
}
jsonlite::write_json(list(job_id=j$job_id,status=status,n_mice=length(unique(x$sample)),n_categories=length(unique(x$cell_group)),
 model=j$model_name,backend_patch=CT26_BACKEND_PATCH,contrast_preflight=parser_report$status,
 composition_formula='~0+condition',variability_formula='~1',inference_method='hmc',
 effect_threshold=as.numeric(s$effect_threshold),threshold_argument=tn,max_rhat=max_rhat,n_divergences=div,
 diagnostic_rhat_source='uncontrasted estimate plus actual Stan parameter summary; not contrast-label joins',
 no_outlier_removal=TRUE,sccomp=as.character(packageVersion('sccomp')),cmdstan=as.character(cmdstanr::cmdstan_version()),
 interpretation='Relative composition among specified denominator, not absolute tumor burden. Bayesian c_pH0/c_FDR are not DESeq2 pvalues.'),
 file.path(out,'complete_R.json'),auto_unbox=TRUE,pretty=TRUE,na='null')
