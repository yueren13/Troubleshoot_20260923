"""Local checks for this narrow repair; NOT an R or sccomp execution test."""
from pathlib import Path
from datetime import datetime, timezone
from types import SimpleNamespace
import hashlib,json,re,shutil,tempfile,nbformat

ROOT=Path(__file__).resolve().parent
NB=nbformat.read(ROOT/'10C0_CT26_Repair_sccomp_ContrastParsing.ipynb',4)
PATCH=ROOT/'sccomp_backend.R'
checks=[]
def ok(s): checks.append(s);print('PASS:',s)

# Pure-Python reproduction of the release's character-by-character, substring-based
# "remove regex outside backquotes" helper. It explains the observed numeric-token loss.
def strip_outside_quotes(text,pattern):
    inside=False;result=[];i=0
    while i<len(text):
        c=text[i]
        if c=='`':inside=not inside;result.append(c);i+=1;continue
        m=None if inside else re.search(pattern,text[i:])
        if m is not None and m.start()==0 and m.end()>0:i+=m.end()
        else:result.append(c);i+=1
    return ''.join(result)

def release_parser_reproduction(text):
    for pat in [r'([0-9]+/[0-9]+ ?\* ?)|(\* ?[0-9]+/[0-9]+)',
                r'([-+]?[0-9]+\.[0-9]+ ?\* ?)|(\* ?[-+]?[0-9]+\.[0-9]+)',
                r'/ ?[0-9]+',r'\b[0-9]+\b']:
        text=strip_outside_quotes(text,pat)
    inside=False;pieces=[];current=[]
    for c in text:
        if c=='`':inside=not inside;current.append(c)
        elif not inside and c in '+-*/':pieces.append(''.join(current));current=[]
        else:current.append(c)
    pieces.append(''.join(current))
    return list(dict.fromkeys(t.replace('`','') for p in pieces if (t:=strip_outside_quotes(p,r'[\(\) ]'))))

pairs=[('AntiPD1','Vehicle'),('Adagrasib','Vehicle'),('Combination','Vehicle'),
       ('Adagrasib','AntiPD1'),('Combination','AntiPD1'),('Combination','Adagrasib')]
assert release_parser_reproduction('conditionAntiPD1 - conditionVehicle')==['conditionAntiPD','conditionVehicle']
for numerator,denominator in pairs:
    quoted=f'`condition{numerator}` - `condition{denominator}`'
    assert release_parser_reproduction(quoted)==[f'condition{numerator}',f'condition{denominator}']
ok('Release-style character scan reproduces unquoted digit loss; all six quoted pairs retain exact names')

ns=dict(hashlib=hashlib)
exec(NB.cells[2].source,ns)
assert ns['PATCHED_R']==PATCH.read_text()
assert hashlib.sha256(PATCH.read_bytes()).hexdigest()==ns['EXPECTED_PATCHED_SHA256']
ok('Standalone notebook embeds the exact replacement R file with a verified checksum')
nbformat.validate(NB)
for i,c in enumerate(NB.cells):
    if c.cell_type=='code':
        compile(c.source,f'cell{i}','exec')
        assert c.execution_count is None and c.outputs==[]
ok('Notebook schema and every Python code cell validate/compile; no retained execution output')

# Test the actual installation cell, with only the JSON-save utility replaced.
# The ORIGINAL runner bytes are supplied by the recorded unified diff reconstruction.
# A local copy is reconstructed from sccomp_backend.diff for a controlled installer test.
def reverse_unified_diff(patched,diff):
    import difflib
    # Use hunk old/new records; walk the NEW stream and recreate OLD lines.
    lines=patched.splitlines(keepends=True);out=[];at=0;d=diff.splitlines(keepends=True);i=0
    while i<len(d):
        h=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',d[i])
        if not h:i+=1;continue
        start=int(h.group(3))-1;out.extend(lines[at:start]);at=start;i+=1
        while i<len(d) and not d[i].startswith('@@ '):
            record=d[i]
            if record.startswith(' '):assert lines[at]==record[1:];out.append(record[1:]);at+=1
            elif record.startswith('+'):assert lines[at]==record[1:];at+=1
            elif record.startswith('-'):out.append(record[1:])
            elif record.startswith('\\'):pass
            else:break
            i+=1
    out.extend(lines[at:]);return ''.join(out)
original=reverse_unified_diff(PATCH.read_text(),(ROOT/'sccomp_backend.diff').read_text())
assert hashlib.sha256(original.encode()).hexdigest()==ns['EXPECTED_ORIGINAL_SHA256']
def write_json(x,p):Path(p).write_text(json.dumps(x))
with tempfile.TemporaryDirectory() as td:
    home=Path(td);target=home/'tumor_characterization'/'sccomp_backend.R';target.parent.mkdir()
    target.write_text(original)
    repair=home/'repair';repair.mkdir()
    connection=home/'sccomp_connection.json';connection.write_text('{}')
    tc=SimpleNamespace(save_json=write_json,load_json=lambda p:json.loads(Path(p).read_text()))
    scope=dict(ns,Path=Path,datetime=datetime,timezone=timezone,shutil=shutil,os=__import__('os'),
               TARGET=target,ADDON_DIR=home,REPAIR_DIR=repair,SCCOMP_CONNECTION=connection,tc=tc,
               current_sha=ns['EXPECTED_ORIGINAL_SHA256'],preflight={'contrast_preflight':{'status':'PASS'}})
    exec(NB.cells[4].source,scope)
    assert target.read_text()==PATCH.read_text()
    backups=list(target.parent.glob('*.bak'));assert len(backups)==1 and backups[0].read_text()==original
    scope['current_sha']=ns['EXPECTED_PATCHED_SHA256']
    exec(NB.cells[4].source,scope)
    assert len(list(target.parent.glob('*.bak')))==1
    target.write_text('# concurrently edited runner\n')
    try:exec(NB.cells[4].source,scope)
    except RuntimeError:pass
    else:raise AssertionError('Concurrent mutation was not protected')
ok('Actual notebook installation cell creates exact backup, is idempotent, and refuses a concurrent edit')

# Model definition/selection must remain unchanged, apart from quoting the requested contrast values.
a=original.index('args<-list(');b=original.index("required<-setdiff",a)
new=PATCH.read_text();a2=new.index('args<-list(');b2=new.index("required<-setdiff",a2)
assert original[a:b]==new[a2:b2]
assert "x$condition<-factor(x$condition,levels=lev)" in new
assert "lev<-c('Vehicle','AntiPD1','Adagrasib','Combination')" in new
assert "max_rhat<=1.05" in new and 'div==0' in new
assert "No optional automated outlier removal" in new
assert 'assignInNamespace' not in new and 'unlockBinding' not in new
ok('Model arguments, treatment labels, effect threshold usage and diagnostic cutoffs unchanged; no namespace patch')

# Lexical delimiter/string sanity check; deliberately NOT described as an R parser.
stack=[];quote=None;escaped=False;comment=False
for pos,c in enumerate(new):
    if comment:
        if c=='\n':comment=False
        continue
    if quote:
        if escaped:escaped=False
        elif c=='\\':escaped=True
        elif c==quote:quote=None
        continue
    if c=='#':comment=True;continue
    if c in '\"\'`':quote=c;continue
    if c in '([{':stack.append((c,pos))
    elif c in ')]}':
        assert stack and '([{'.index(stack[-1][0])==')]}'.index(c),(pos,c,stack)
        stack.pop()
assert not stack and quote is None
ok('Replacement R text has balanced strings/brackets (lexical check only, not R execution)')

print('\nChecks passed:',len(checks))
(ROOT/'validation_results.json').write_text(json.dumps({'checks':checks,'R_executed_locally':False,
 'scope':'CPU checks only; actual sccomp parser/evaluator and HMC are verified on the user server by the repair notebook.'},indent=2)+'\n')
