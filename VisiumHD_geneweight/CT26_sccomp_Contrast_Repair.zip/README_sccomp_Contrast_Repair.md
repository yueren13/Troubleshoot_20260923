# CT26 sccomp contrast repair — no reinstallation

## What the uploaded notebook established

- R 4.5.2, sccomp 2.2.0, cmdstanr 0.9.0 and CmdStan 2.37.0 were available.
- The count-model design actually included `conditionAntiPD1`.
- Both Stan chains completed before the fatal error.
- `sccomp_test()` failed on `conditionAntiPD1 - conditionVehicle`.
- Its missing-parameter warning named `conditionAntiPD` (the final digit vanished).
- One divergent transition out of 2,000 was also reported. This is a separate
  sampling-diagnostic concern, not the cause of the missing-coefficient error.

The release contrast tokenizer scans strings and removes numerical tokens outside
backquotes; its substring-based scan can strip the `1` from a parameter name.
Quoting the coefficient tokens protects that name. The contrast becomes:

```r
"`conditionAntiPD1` - `conditionVehicle`"
```

The minus sign must stay OUTSIDE the backticks. Do not quote the whole expression
as one parameter. Do not rename treatment groups, samples, annotations, or files.

## Recommended usage

1. Download `10C0_CT26_Repair_sccomp_ContrastParsing.ipynb`.
2. Put it beside the existing characterization notebooks and their
   `tumor_characterization/` and `tumor_visibility/` directories.
3. Open it in the SAME Python environment used for 10C0. Check `ADDON_DIR` and
   `SCCOMP_ENV_ROOT` in the first code cell.
4. Run it top to bottom. No R/CmdStan/package installer is invoked.
5. It first runs a no-HMC parser/arithmetic check on a candidate R runner using
   the actual installed sccomp. Only after that succeeds does it back up and
   replace the shared project `tumor_characterization/sccomp_backend.R`.
6. It reruns the small synthetic smoke fit and verifies that every synthetic
   category returns all six intended comparisons.
7. Continue with the existing 10C notebook, which uses the same corrected runner.
   Real-data convergence diagnostics still need review independently.

This notebook is SELF-CONTAINED: the corrected R runner is embedded. Downloading
only the notebook is sufficient if archive delivery fails. Search its exact name
in ChatGPT Library, the route that already worked for this project.

If you revisit the original uploaded 10C0 notebook, set `INSTALL_SCCOMP=False` in
both duplicated installation cells or skip them. Reinstallation does not fix a
contrast-string parsing error.

## Changes and scope

Only `tumor_characterization/sccomp_backend.R` is replaced. A timestamped backup
is made automatically. Exact SHA256 checks protect unexpected local edits. The
candidate preflight tests token extraction, known numerical subtraction results,
and all six named comparisons before modifying the target or running Stan.

- No R namespace monkeypatch or installed-package file edit.
- No condition renaming, model/formula change, count modification, denominator
  change, cell exclusion, outlier removal, threshold relaxation or sampler change.
- Returned contrast labels remain the original plain strings, so existing plots
  and downstream CSV consumers continue to work.
- New audits record contrast expressions, parser behavior and fitted parameters.
- Basic R-hat reporting uses uncontrasted fit/Stan summaries, rather than relying
  on contrast labels to join against coefficient names (which can give all NA).
- One divergence still causes the existing `REVIEW_CONVERGENCE` outcome.
- The basic diagnostic flag is NOT a comprehensive validation of the scientific model.
- The exact compiled-model cache path and installed CmdStan are retained.
- Smoke preflight now includes a repair ID, producing a fresh smoke-output identity.
  The original real-model cache already includes the R script hash, so it does
  not silently reuse a previous result from a different runner.
- The old failed synthetic RDS is preserved but not automatically recovered;
  this notebook reruns the small synthetic fit. Other completed stages are untouched.

No `run_name`, upstream `run_spec.json`, annotation, model input or original
CT26 source is changed. No restart is technically required solely for the R-file
replacement: each call starts a new R process. Restart only if imports resolve to
another characterization folder, as the first cell checks explicitly.

## Outputs to expect

Parser-only preflight:

```
contrast_preflight.status: PASS
quoted_digit_token_preserved: true
```

The smoke output has:

- `contrast_expression_audit.csv`
- `contrast_parser_preflight.json`
- `fitted_composition_parameters.csv`
- `contrasts.csv` (six comparisons for every synthetic category)
- `Stan_parameter_summary.csv`
- `Stan_diagnostics.txt`
- `complete_R.json`

`REVIEW_CONVERGENCE` means the pipeline reached diagnostic reporting but the fit
needs review. It is distinct from a parser/API exception and does not mean that
reinstalling the package is necessary. Never treat it as automatic acceptance of
real study effect estimates.

## Validation and references

See `VALIDATION_sccomp_Repair.md`. Actual R/sccomp execution could not be performed
in the authoring runtime. The notebook verifies its candidate on YOUR installed
R/sccomp BEFORE replacing the shared runner, then runs the full synthetic smoke test.

Primary sources:
- https://github.com/bioconductor-source/sccomp/blob/RELEASE_3_22/R/utilities.R
- https://github.com/bioconductor-source/sccomp/blob/RELEASE_3_22/R/sccomp_test.R
- https://github.com/MangiolaLaboratory/sccomp/pull/234
- https://mc-stan.org/cmdstanr/reference/fit-method-summary.html
- https://mc-stan.org/cmdstanr/reference/fit-method-diagnostic_summary.html
