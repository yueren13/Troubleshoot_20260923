# Validation — sccomp contrast repair

- PASS: Release-style character scan reproduces unquoted digit loss; all six quoted pairs retain exact names
- PASS: Standalone notebook embeds the exact replacement R file with a verified checksum
- PASS: Notebook schema and every Python code cell validate/compile; no retained execution output
- PASS: Actual notebook installation cell creates exact backup, is idempotent, and refuses a concurrent edit
- PASS: Model arguments, treatment labels, effect threshold usage and diagnostic cutoffs unchanged; no namespace patch
- PASS: Replacement R text has balanced strings/brackets (lexical check only, not R execution)

The failed notebook and the original supplied project runner were inspected directly. Local tests use the original checksum and test the actual installer cell with temporary files. The parser reproduction is a Python reproduction of the release source logic, not execution of R.

**No R/Rscript executable is installed in the authoring runtime.** The actual sccomp parser/evaluator and repaired HMC/test workflow were NOT executed here. The repair notebook performs a no-HMC R candidate preflight before replacing the project runner, followed by the full synthetic smoke test on the user server. No CT26 input data or genuine study model was run locally.

The repaired runner retains the original model and diagnostic cutoffs. The sampling divergence reported by the user is kept separate from the contrast compatibility repair.
