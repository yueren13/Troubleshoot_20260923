# CT26 tumor-assigned immune-visibility transcription: 09A–09D

## Purpose and scope

Pooled **All tumor cell** is the primary population; **Tumor cell 1–5** are secondary
state-resolved analyses. The question is whether adagrasib is associated with
increased immune-visibility-related RNA in the annotated tumor compartment and
whether the response is broad or concentrated near immune cells.

This package does not call transcript measurements surface MHC/PD-L1 status, establish
which cell synthesized a possibly misassigned RNA, or prove direct tumor-intrinsic
causality. It does not generate AP-low/excluded niche labels. Those remain later
analyses requiring coverage thresholds, tissue geometry and better attribution.

## Install and start

Extract the **whole ZIP** into a code folder. Keep the four notebooks,
`tumor_visibility/`, and `programs_proposed_mouse.json` together. Do not copy them into
the original `inputs/` folder. Leave `ct26_common.py`, the original configuration,
`run_name`, raw matrices, annotation sidecars and completed graphs unchanged.

Set:
- `ADDON_DIR`: the extracted folder with `tumor_visibility/`.
- `PACKAGE_DIR` in 09A: the original CT26 code folder containing `ct26_common.py`,
  `ct26_analysis_config.json`, `sample_metadata.csv`, and `inputs/`.

The original run guard is called without modification. The source resolver follows
`08FG_v2_annotation_pointer.json`, `01_density_qc/prepared_samples.csv`, and the
existing source/prior summaries. It uses the corrected detailed labels, not a
previous merged-T annotation. No scVI, segmentation, QC-filtering, or annotation
rerun is needed.

The user has already confirmed **12 independent mouse tumors, three per condition,
no technical replicates**. The notebook records this and verifies the metadata;
it does not demand another generic approval toggle. A conflicting source map stops.

## Notebooks

| Notebook | Work | Required environment |
|---|---|---|
| 09A | Source/coverage audit; all-gene compartment sums; compact tumor-cell panel; observed tumor scores | Existing CPU/scverse environment |
| 09B | All-tumor-first and state-level raw pseudobulk DESeq2; IFN Hallmarks; mouse-level dashboard | Same Python kernel + existing Rscript/DESeq2/ashr; fgsea for enrichment |
| 09C | Exact immune proximity/counts; tumor-rich sensitivity; distance-band profiles; tumor-only tiles | CPU, no R or GPU |
| 09D | 300-dpi H&E expression/tile maps, immune overlays and configurable ROIs | CPU spatial-image environment |

Run **09A first**. Then 09B and 09C reuse its caches independently. Run **09D after
09C**. Spatial/H&E work does not depend on successful R fitting. The project pointer
`active_tumor_visibility_project.json` is saved beside these new notebooks, not in
original pipeline inputs. Each later notebook also accepts an explicit project path.

## Before the first count scan: choose the IFN definition

For the full proposed analysis, set `HALLMARK_GMT` in 09A to your existing, versioned
**Mouse MH gene-symbol GMT** used by 08J and record `HALLMARK_RELEASE`. No MSigDB
content is bundled and no file is downloaded automatically.

Canonical IFN-alpha and IFN-gamma membership is taken from that file. The complete
Hallmark collection remains the enrichment-testing family; the dashboard emphasizes
the two IFN programs. The source checksum and coverage are recorded.

Without a GMT, `REQUIRE_HALLMARKS=False` permits AP/Cd274/chemokine work with the
separately named `IFN_core_exploratory`. The status explicitly says canonical Hallmark
scoring/enrichment did not run. This core is NOT substituted under a Hallmark name
and cannot separate IFN-alpha from IFN-gamma biology. Set REQUIRE_HALLMARKS=True to
stop until the GMT is supplied. Adding a GMT after extraction creates a new panel
fingerprint and can require another source scan; choose it before the first run.

## Definitions and gene coverage

`programs_proposed_mouse.json` is an editable proposed panel, not a validated classifier:

- **AP_MHCI_core**: H2-K1, H2-D1, B2m, Tap1, Tap2, Tapbp, Psmb8, Psmb9, Nlrc5.
- **Cd274**: PD-L1 transcript expression/detection, not protein-defined positivity.
- **Cxcl9/Cxcl10**: source-aware recruiting-signal candidates.
- **Dusp6**: pharmacodynamic context, not a direct target-engagement assay.
- **Immune/stromal lineage context**: descriptive admixture/context diagnostics, not
  grounds for automatic deletion or proof of contamination.

Raw gene symbols and feature IDs are joined exactly; identical-symbol features are
summed. Case conversion and missing-feature-to-zero imputation are not performed.
Each score uses one fixed set of source-measured genes common to the cohort. Default
eligibility requires >=70% panel coverage and at least min(3, number requested) genes.
The full requested membership, common measured subset, exclusions and eligibility
are exported. An unavailable individual gene has NA scalar output, not zero signal.

For descriptive cell scores:

    mean_g log1p(10000 × observed count_g / whole-source cell library total)

No per-sample z scoring, expression imputation or control-gene-adjusted enrichment
is claimed. These are observed normalized RNA signals, not absolute RNA per cell.

Canonical IFN sets are kept unchanged for enrichment. Spatial IFN variants remove
the AP panel plus Cd274/Cxcl9/Cxcl10 to reduce arithmetic overlap. They are explicitly
named `_spatial_no_AP_PDL1_CXCL`, and are NOT called canonical Hallmarks. Canonical
IFN-alpha and gamma programs also overlap each other, so do not interpret correlated
scores as evidence of separate independent cytokine signals.

## One source scan, several reusable outputs

09A streams bounded CSR/dense raw-H5AD rows and verifies source-cell IDs and raw QC
library totals. It rejects graph-placeholder X, negative/fractional counts, wrong
axes, or inconsistent libraries. No huge dense cell-by-all-gene matrix is built.

The single pass saves:
- all-gene raw sums per reviewed compartment, including each tumor subtype;
- raw small-panel counts for each tumor cell in compressed HDF5;
- full-reference physical cell coordinates and labels for immune context;
- panel expression/detection summaries in all reviewed compartments.

Only tumor-assigned counts enter tumor program scores and tumor tiles. Nearby immune
cells are a separate layer. Compartment summaries let you inspect whether Cd274 or
chemokine expression is predominantly observed in tumor, myeloid or other labels,
without claiming that segmentation alone proves the source.

Caches are sample-specific, identity-checked and completion-marked. Interrupted
work reuses completed samples. A revised panel, annotation/source file, or numerical
setting gets a new fingerprint rather than reusing incompatible results.

## 09B: treatment inference and pooled-versus-state interpretation

Primary contrasts:
1. **Adagrasib versus Vehicle**.
2. **Combination versus Anti-PD1**.

The remaining four pairwise contrasts, companion signed interaction Wald contrast,
omnibus condition LRT, and drug-interaction LRT are also retained. All tumor is fit
first, followed by Tumor 1–5, where adequately represented.

Raw counts are summed within mouse/population. Default eligibility: >=50 cells,
>=1000 raw counts, and >=3 units per condition; genes need >=10 counts in >=3 units
and source availability across all contributing eligible units. An absent subtype
is not an artificial zero-expression mouse. Each population records eligible units
and reasons for `not_testable` status. All contrasts within it use the same fitting
cohort. These QC settings are editable analyst choices, not universal thresholds.

R uses `~condition`, with Vehicle as reference, DESeq2 poscounts size factors and
ashr shrinkage. The full factorial span matches the four-condition model:
- overall LRT: `~condition` versus `~1`, 3 df;
- interaction LRT: `~anti_pd1 * adagrasib` versus `~anti_pd1 + adagrasib`, 1 df.

The interaction is a difference of log-expression differences, not proof of
pharmacologic synergy. Original counts are not automatically replaced; default
Cook's/independent filtering remain enabled. All-gene result tables retain NA
statistics rather than displaying them as significant. Targeted dashboard values
come from those full tests; significance is not recomputed on just AP/Cd274 genes.

Use the same verified `r_connection.json` and R 4.5.2 environment as 08H. Required:
DESeq2, jsonlite, ashr. `fgsea` is required only when run_hallmark=True and a GMT is
provided. Nothing is installed automatically. A fresh-process synthetic R smoke
test checks the new backend before actual fits. R execution was not available in
the authoring runtime; on-server validation is essential.

Hallmark ranks are full finite signed Wald statistics with valid raw P values,
not the significant-gene subset or selected heatmap genes. Original Hallmark sets
are intersected with the valid rank universe; coverage/leading edges are exported.
Pathway FDR is over all tested Hallmarks within a population/contrast. The two
IFN sets in the two primary contrasts receive an additional combined-screen BH
column. Preranked enrichment is not a mouse-label permutation test or correction
for ambient RNA.

The dashboard displays all individual mice, tumor-state proportions, the focused
AP/Cd274/chemokine/Dusp6 gene effects, and IFN enrichment. Descriptive per-cell-score
means and model-normalized pseudobulk counts are kept separately labeled. A pooled
increase may arise from within-state induction, different state proportions, or
both; state plots help distinguish those possibilities. They do not force states
to be independent cell lineages.

## 09C: spatial context without a niche-classification shortcut

All measurements are 2D Euclidean centroid measurements within one physical sample.
No UMAP/image-pixel distances, cross-sample neighbors, membrane-contact inference,
barrier/tissue-mask distances, or edge-area correction are used.

- nearest **All T**, **T cell 1**, and **T cell 2**;
- exact count-only radius queries at 25 and 50 µm (50/100 µm diameters);
- Myeloid = Macrophage 1 + Macrophage 2 + Dendritic cell, plus separate DC context;
- preserved full-reference neighbor counts and local reviewed-tumor fraction;
- sample-level expression profiles across [0,25], (25,50], (50,100], >100 µm;
- each profile is available for pooled tumor and every subtype.

No-target distance is NA, not infinity silently categorized as 'far'. If there are
no T cells in a specimen, that absence is recorded rather than imputed. Distances
can cross tissue holes/fragments; inspect the H&E context before mechanistic claims.

The optional tumor-rich sensitivity requires >=80% of other segmented neighbors
within 50 µm to be annotated tumor, and at least five neighbors. This is a spatial
context filter, NOT an independent histology/tumor-identity validation. It does not
exclude cells because they express immune/AP/IFN genes. All-tumor results remain
primary. `lineage_context_depth_sensitivity.csv` reports retained fractions, RNA
depth, AP, Cd274 and lineage-context changes so the sensitivity can be audited.

Near-minus-far expression means <=50 µm minus >100 µm (intermediate cells excluded
from this specific endpoint). Each mouse contributes one endpoint per population,
metric, target and sensitivity. Default >=30 tumor cells per distance band is
required. Optional exact treatment tests require three eligible independent units
per group. With 3 vs 3, the exact two-sided absolute-mean-difference P cannot be
below 0.10. BH adjustment separates the predefined pooled primary family from
secondary subtype/target/sensitivity families. Cells and overlapping neighborhoods
are never treated as independent treatment replicates.

Local cell-density/program Spearman correlations are reported per sample using
adequate tiles but without cell/tile-level significance P values. These are
spatial descriptors, not effects of immune infiltration on tumor expression.

## Tumor-only tiles

Tiles are **nonoverlapping 50 or 100 µm squares** in the Proseg physical coordinate
frame (side length, not radius/diameter). Each tile pools tumor raw counts and
whole-library totals, then computes the normalized gene/program signal. It does
NOT average a mixed tumor+immune spot or use immune counts in the denominator.
Pooled and subtype tiles are calculated separately. Default >=5 tumor cells and
>=500 tumor counts per tile; inadequate tiles remain NA/masked, not AP-low.

Tile signal = mean of gene-wise log1p-normalized **pooled** counts. This differs
from the mean of per-cell log1p scores and is labeled as a distinct representation.
Tumor occupancy and local immune context are saved separately. Spatial binning
increases measurement support but does not recover cell of origin or generate
additional independent mice.

## 09D: H&E figures

Default: pooled tumor maps, then enable selected subtypes in MAP_POPULATIONS for
secondary review. Both per-cell maps and tumor-only tile maps use 300-dpi outputs,
with whole-image overviews and two dense-tumor ROI proposals per sample. Manual
ROIs support pixel bounds or image-relative center plus physical width/height.

The image resolver uses the saved prior affine/registered crop. It does not assume
that Proseg microns equal pixels. Original SVS fallback requires an explicit
source-crop/resize mapping or user-supplied verified affine. Geometries preserve
aspect ratio; no geographic latitude-dependent plotting is used. Raw source images
remain read-only. Uncompressed TIFF uses mmap; compressed TIFF/SVS use bounded
readers. Large unsupported files stop rather than decode the entire slide.

For each metric, a common cohort color scale is computed from the primary pooled
population and reused across all samples/subtype views. Cell and tile modes have
separate scales because their normalization/aggregation differs. The scale source,
quantile and numerical range are exported. Detection maps use 0–1. Invalid or
low-support tiles are not colored as zero. T1/T2 positions use their existing pink
colors in a separate overlay layer. Review alignment numerically and on H&E.

Figure choices create separate style directories. Regenerating an identical style
refreshes its plots; it does not redo raw extraction or spatial calculations.
Large default figure sets are deliberate. For a first inspection, restrict metrics,
MAP_POPULATIONS and manual ROIs before rendering every sample/view.

## Output layout

```
<existing RUN_ROOT>/13_tumor_immune_visibility/<project_fingerprint>/
  input_review/                 # source/metadata/program/probe audits
  project_spec.json
  sample_cache/<sample>/        # raw sums, compact tumor panel, scores, full coordinates
  tables/                      # cohort descriptive expression summaries
  model/<input_id>/
    population_input_manifest.csv
    <population>/              # pseudobulk input matrices/QC
    fits/<model_id>/
      fit_status.csv
      <population>/            # DESeq2/fgsea tables, models, logs and versions
      focused_tumor_gene_results.csv
      all_tumor_Hallmark_results.csv
  spatial/<settings_id>/       # cell contexts, distance profiles, tumor-only tiles
    lineage_context_depth_sensitivity.csv
    figures/
    HE_maps/<style_id>/       # exact style subtree printed by 09D
  figures/expression/
```

OUTPUT_ROOT_OVERRIDE can place new derived caches on fast persistent local storage;
it does not move, mount, modify or replace original source files. Existing relative
and absolute pipeline source paths remain the input authority.

## Interpretation and limitations

PD-L1 here means Cd274 transcript measurements. MHC/AP machinery RNA does not prove
surface peptide-MHC, antigen specificity or T-cell killing. Zero Cd274 counts do
not prove a protein-negative cell. Immune-proximal tumor expression can reflect
biological IFN exposure, transcriptional mixing, or both. Tumor-rich sensitivity
and lineage-context diagnostics strengthen review but are not decontamination.

The exact study CT26/Kras allele is left as a provenance note to fill from study
records; no genotype is inferred from adagrasib treatment or observed response.
The initial conclusions should remain associations in the annotated tumor
compartment until tumor-origin/protein/functional evidence is available.

`VALIDATION.md` documents synthetic checks and what could not be executed here.
No actual CT26 expression, treatment, spatial or R/DESeq2 result is claimed by this
package's creation.
