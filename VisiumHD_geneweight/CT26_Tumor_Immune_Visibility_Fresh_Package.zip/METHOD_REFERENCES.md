# Sources, methods and provenance

## Project inputs

Source/root locations, the twelve Ada sample names, image locations and upstream
prior configuration come from the user's TBIO-8110 pipeline_config.json and existing
completed pipeline manifests. Annotation labels/colors come from the corrected
08F v2 schema. The independent unit design (each sample a separate tumor from a
separate mouse, 3 per condition) was explicitly confirmed by the user.

No model genotype, biological result, source availability or cell-of-origin fact
is inferred from those file paths or sample names. The included small marker panels
and numerical sensitivity thresholds are proposed analysis choices.

## Primary/official methodological references

- DESeq2: Wald contrasts, LRT full/reduced models, normalization, shrinkage:
  https://bioconductor.org/packages/3.22/bioc/vignettes/DESeq2/inst/doc/DESeq2.html
  Love MI, Huber W, Anders S. Genome Biology 2014;15:550.
  https://doi.org/10.1186/s13059-014-0550-8
- Mouse MSigDB MH collection and gene-symbol files:
  https://www.gsea-msigdb.org/gsea/msigdb/mouse/collections.jsp
- Canonical IFN-gamma response (includes shared AP/PD-L1-related members):
  https://www.gsea-msigdb.org/gsea/msigdb/mouse/geneset/HALLMARK_INTERFERON_GAMMA_RESPONSE.html
- Canonical IFN-alpha response:
  https://www.gsea-msigdb.org/gsea/msigdb/mouse/geneset/HALLMARK_INTERFERON_ALPHA_RESPONSE.html
- fgsea preranked input and output conventions:
  https://bioconductor.org/packages/release/bioc/vignettes/fgsea/inst/doc/fgsea-tutorial.html
  (The package uses preranked enrichment; it does not claim pre-registration or a
   mouse-label permutation null.)
- Exact spatial queries and count-only radius output:
  https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.cKDTree.query.html
  https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.cKDTree.query_ball_point.html
- Proseg image-pixel x/y to physical-coordinate transform convention:
  https://github.com/dcjones/proseg#initializing-using-cellpose-masks
- OpenSlide bounded pyramid image reads:
  https://openslide.org/api/python/

The spatial overlap-removed IFN variants, simple observed-log-expression program
summary, tumor-rich context threshold and diagnostic dashboard are explicit
workflow choices. They are not a published validated tumor-immunogenicity classifier,
cell-origin correction, protein-status assay, or immune-excluded-niche definition.
No proprietary or licensed MSigDB GMT is bundled. The user's local versioned GMT
and checksum define canonical membership.
