"""Small safe I/O utilities for a read-only CT26 tumor-visibility add-on."""
from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass
import hashlib, importlib, json, os, re, sys, warnings
import h5py
import numpy as np
import pandas as pd
import scipy.sparse as sp

VERSION='ct26-tumor-visibility-1.0'
TUMOR=[f'Tumor cell {i}' for i in range(1,6)]
ALL_TUMOR='All tumor cell'
T_TYPES=['T cell 1','T cell 2']
CONDITIONS=['Vehicle','AntiPD1','Adagrasib','Combination']
DISPLAY={'Vehicle':'Vehicle','AntiPD1':'Anti-PD1','Adagrasib':'Adagrasib','Combination':'Adagrasib + Anti-PD1'}
CONDITION_MAP={'Vehicle':'Vehicle','Anti-PD1':'AntiPD1','AntiPD1':'AntiPD1','Adagrasib':'Adagrasib',
 'Adagrasib+Anti-PD1':'Combination','Adagrasib + Anti-PD1':'Combination','Combination':'Combination'}
PRIMARY=[('Adagrasib','Vehicle'),('Combination','AntiPD1')]
CONTRASTS=PRIMARY+[('AntiPD1','Vehicle'),('Combination','Adagrasib'),('Combination','Vehicle'),('Adagrasib','AntiPD1')]
LABEL='preliminary_annotation'

def jsonable(x):
    if isinstance(x,Path):return str(x)
    if isinstance(x,np.generic):return jsonable(x.item())
    if isinstance(x,np.ndarray):return jsonable(x.tolist())
    if isinstance(x,dict):return {str(k):jsonable(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [jsonable(v) for v in x]
    if x is pd.NA or (isinstance(x,float) and not np.isfinite(x)):return None
    return x

def digest(x):return hashlib.sha256(json.dumps(jsonable(x),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
    return h.hexdigest()
def signature(path):
    p=Path(path).expanduser().resolve();s=p.stat()
    return dict(path=str(p),size=s.st_size,mtime_ns=s.st_mtime_ns)
def slug(x):return (re.sub(r'[^A-Za-z0-9_.-]+','_',str(x)).strip('._') or 'item')
def load_json(p):return json.loads(Path(p).read_text())
def save_json(x,p):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.name+'.partial')
    q.write_text(json.dumps(jsonable(x),indent=2,allow_nan=False)+'\n');q.replace(p)
def save_csv(x,p,index=False):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.name+'.partial')
    x.to_csv(q,index=index,sep='\t' if '.tsv' in p.name else ',',compression={'method':'gzip','mtime':0} if p.name.endswith('.gz') else None);q.replace(p)
def save_npz(p,**arrays):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.name+'.partial')
    with q.open('wb') as f:np.savez_compressed(f,**arrays)
    q.replace(p)
def save_frame(df,p):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.name+'.partial')
    df.to_parquet(q,index=True);q.replace(p)
def read_frame(p,columns=None):
    p=Path(p)
    if p.suffix.lower()=='.parquet':
        import pyarrow.parquet as pq
        names=set(pq.read_schema(p).names)
        return pd.read_parquet(p,columns=None if columns is None else [c for c in columns if c in names])
    if p.suffix in ['.h5ad','.h5']:
        with h5py.File(p) as f:return h5frame(f['obs'],columns)
    x=pd.read_csv(p,sep='\t' if '.tsv' in p.name else ',',keep_default_na=False,dtype=str)
    return x if columns is None else x[[c for c in columns if c in x]]
def strings(values,name,unique=False):
    s=pd.Series(values,dtype='string')
    if s.isna().any() or s.str.strip().eq('').any() or (s!=s.str.strip()).any():raise ValueError(f'{name}: missing/padded identifiers')
    out=s.to_numpy(str)
    if unique and pd.Index(out).has_duplicates:raise ValueError(f'{name}: duplicate identifiers')
    return out

def h5vector(node):
    if isinstance(node,h5py.Dataset):return node.asstr()[...] if h5py.check_string_dtype(node.dtype) else node[...]
    e=node.attrs.get('encoding-type','');e=e.decode() if isinstance(e,bytes) else e
    if e=='categorical' or {'codes','categories'}.issubset(node):
        return pd.Categorical.from_codes(node['codes'][...].astype(int),h5vector(node['categories']),ordered=bool(node.attrs.get('ordered',False)))
    if {'values','mask'}.issubset(node):
        v=np.asarray(h5vector(node['values']),object);v[np.asarray(node['mask'][...],bool)]=pd.NA;return v
    if e=='null':return None
    raise TypeError(f'Unsupported H5AD vector {e} at {node.name}')
def h5frame(group,columns=None):
    key=group.attrs.get('_index','_index');key=key.decode() if isinstance(key,bytes) else key
    ix=strings(h5vector(group[key]),group.name+' index',True);out=pd.DataFrame(index=pd.Index(ix,name=None))
    for c in (group.keys() if columns is None else columns):
        if c==key or c not in group:continue
        v=h5vector(group[c])
        if v is not None:out[c]=v
    return out

class RawReader:
    """CSR/dense chunked source, without loading graph/uns. Counts not transformed."""
    def __init__(self,path,matrix_key):
        self.file=h5py.File(path,'r');key=str(matrix_key).strip('/')
        try:
            self.obs=h5frame(self.file['obs'],[])
            self.var=h5frame(self.file['raw/var' if key.startswith('raw/') else 'var'])
            self.node=self.file[key]
            if isinstance(self.node,h5py.Dataset):self.kind='dense';self.shape=tuple(self.node.shape)
            else:
                e=self.node.attrs.get('encoding-type','');e=e.decode() if isinstance(e,bytes) else e
                if e!='csr_matrix':raise ValueError('Use observed-count CSR or dense input; CSC is not silently materialized')
                self.kind='csr';self.shape=tuple(map(int,self.node.attrs['shape']))
            if self.shape!=(len(self.obs),len(self.var)) or self.shape[1]<2:raise ValueError('Raw axes disagree or graph-placeholder X selected')
        except Exception:self.file.close();raise
    def __enter__(self):return self
    def __exit__(self,*args):self.file.close()
    def block(self,a,b):
        if self.kind=='dense':x=sp.csr_matrix(self.node[a:b,:])
        else:
            ptr=self.node['indptr'][a:b+1].astype(np.int64);lo,hi=int(ptr[0]),int(ptr[-1])
            x=sp.csr_matrix((self.node['data'][lo:hi],self.node['indices'][lo:hi],ptr-lo),shape=(b-a,self.shape[1]))
        x.sum_duplicates();x.eliminate_zeros();return x
    def selected(self,ids,chunk):
        pos=self.obs.index.get_indexer(ids)
        if np.any(pos<0):raise ValueError('Annotation IDs absent from raw source')
        order=np.argsort(pos,kind='stable');pos=pos[order]
        if not len(pos):return
        chunk=min(chunk,max(1,10_000_000//self.shape[1])) if self.kind=='dense' else chunk
        windows=pos//chunk;bounds=np.r_[0,np.flatnonzero(np.diff(windows))+1,len(pos)]
        for a,b in zip(bounds[:-1],bounds[1:]):
            left=int(windows[a]*chunk);right=min(left+chunk,self.shape[0])
            yield order[a:b],self.block(left,right)[pos[a:b]-left]

def validate_counts(x):
    x=sp.csr_matrix(x);x.sum_duplicates();x.eliminate_zeros()
    if len(x.data) and (not np.isfinite(x.data).all() or np.any(x.data<0) or not np.equal(x.data,np.rint(x.data)).all()):
        raise ValueError('Raw counts must be finite nonnegative integers; no normalized/ResolVI matrix or rounding')
    return x.astype(np.int64,copy=False)

def source_symbols(row,raw):
    if row.get('gene_table'):
        g=read_frame(row['gene_table'])
        key=row.get('gene_id_column','__index__')
        if key=='__index__':
            # Parquet preserves feature index; CSV fixtures require explicit feature_id column.
            if g.index.equals(pd.RangeIndex(len(g))):
                candidates=[c for c in ['feature_id','gene_id','Unnamed: 0','_index'] if c in g]
                if len(candidates)!=1:raise ValueError('CSV gene table needs explicit gene_id_column')
                g=g.set_index(candidates[0])
        else:g=g.set_index(key)
        g.index=pd.Index(strings(g.index,'feature IDs',True))
        if not raw.var.index.isin(g.index).all():raise ValueError('Gene mapping missing source feature IDs')
        symbols=g.reindex(raw.var.index)[row.get('gene_symbol_column','gene_symbol')]
    else:
        key=row.get('gene_symbol_column','gene_symbol');symbols=raw.var.index if key=='__index__' else raw.var[key]
    return strings(symbols,'source gene symbols')

def annotation(row,raw=None):
    a=read_frame(row['annotation_file'])
    idcol=row.get('cell_id_column','source_cell_id')
    ids=a.index if idcol=='__index__' else a[idcol]
    a=a.copy();a.index=pd.Index(strings(ids,'source cell IDs',True),name=None)
    scol=row.get('sample_column','sample')
    if scol:
        if scol not in a or not a[scol].astype(str).eq(row['sample']).all():raise ValueError('Sidecar not a single exact physical sample')
    if raw is not None:
        if len(a)!=len(raw.obs) or set(a.index)!=set(raw.obs.index):raise ValueError('Expected full 08F cell universe; no positional ID join')
    labelcol=row.get('label_column',LABEL)
    labels=a[labelcol].astype('string');labels=labels.mask(labels.str.strip().eq(''))
    a['population']=labels
    if 'is_in_scvi_graph' in a:
        graph=a.is_in_scvi_graph.astype(str).str.lower().isin(['true','1'])
        if (labels.notna()&~graph).any():raise ValueError('Reviewed annotation assigned outside scVI')
    pairs=[('_proseg_x_um','_proseg_y_um'),('spatial_x_um','spatial_y_um'),('centroid_x','centroid_y')]
    explicit=row.get('x_column') and row.get('y_column')
    if explicit:pairs=[(row['x_column'],row['y_column'])]
    coords=None
    for x,y in pairs:
        if {x,y}.issubset(a):coords=a[[x,y]].apply(pd.to_numeric,errors='raise').to_numpy(float);break
    if coords is None:raise ValueError('Missing physical micron coordinates; no H&E-pixel/UMAP fallback')
    scale=float(row.get('coordinates_to_um',1.))
    if not np.isfinite(scale) or scale<=0:raise ValueError('coordinates_to_um must be positive')
    coords*=scale
    if not np.isfinite(coords).all():raise ValueError('Nonfinite coordinates in full-reference sidecar')
    a['x_um']=coords[:,0];a['y_um']=coords[:,1]
    key=row.get('total_counts_column','__auto_raw_qc__')
    if key=='__auto_raw_qc__':key='raw_total_counts' if 'raw_total_counts' in a else 'total_counts'
    if key not in a:raise KeyError('Missing original raw QC library totals')
    a['raw_total_counts']=pd.to_numeric(a[key],errors='raise')
    a['source_cell_id']=a.index
    return a

def ct26_sources(package_dir,annotation_root=None,metadata_file=None,unit_map=None):
    package=Path(package_dir).resolve();sys.path.insert(0,str(package));ct=importlib.import_module('ct26_common')
    if Path(ct.__file__).resolve()!=package/'ct26_common.py':raise RuntimeError('Wrong ct26_common imported; restart with correct package directory')
    cfg,supplied,run,package=ct.load_settings(package)
    if not (run/'run_spec.json').is_file():raise FileNotFoundError('Not the completed current CT26 run')
    ct.guard_run(run,cfg,list((package/'inputs').glob('*'))+[package/'sample_metadata.csv'])
    if annotation_root is None:
        pointer=run/'08FG_v2_annotation_pointer.json'
        if not pointer.is_file():raise FileNotFoundError('Set ANNOTATION_ROOT or complete 08F v2')
        annotation_root=load_json(pointer)['annotation_root']
    ann=Path(annotation_root).resolve();schema=load_json(ann/'annotation'/'annotation_schema.json')
    if not set(TUMOR+T_TYPES).issubset(schema['detail_order']):raise ValueError('Need reviewed tumor1–5 and T1/T2 labels')
    m=pd.read_csv(metadata_file or package/'sample_metadata.csv',dtype=str,keep_default_na=False).set_index('sample',drop=False)
    sources=pd.read_csv(run/'01_density_qc'/'prepared_samples.csv',dtype=str,keep_default_na=False).set_index('sample')
    sample_ids=list(supplied['sample_ids'])
    if not m.index.is_unique or set(m.index)!=set(sample_ids) or not sources.index.is_unique or set(sources.index)!=set(sample_ids):raise ValueError('Sample metadata/source mismatch')
    prior=pd.read_csv(package/'inputs'/'all_samples_stardist_qcprior_summary.csv',dtype=str,keep_default_na=False).set_index('sample')
    im=pd.read_csv(package/'inputs'/'sample_manifest.csv',dtype=str,keep_default_na=False).set_index('sample')
    rows=[]
    if unit_map and set(unit_map)!=set(sample_ids):raise ValueError('Unit map must cover every sample')
    for sample in sample_ids:
        r=sources.loc[sample];treatment=m.loc[sample,'treatment']
        if treatment not in CONDITION_MAP:raise ValueError(f'Unknown treatment {treatment!r}; map it explicitly')
        sidecar=ann/'full_cell_metadata'/f'{sample}_all_cells_preliminary_annotation.parquet'
        rows.append(dict(sample=sample,unit=str(unit_map[sample] if unit_map else (m.loc[sample,'independent_unit'] if 'independent_unit' in m else sample)),
            condition=CONDITION_MAP[treatment],treatment=treatment,raw_h5ad=r['raw_h5ad'],matrix_key=r['raw_matrix_key'],
            annotation_file=str(sidecar),gene_table=r['genes_parquet'],gene_id_column='__index__',gene_symbol_column='gene_symbol',
            cell_id_column='source_cell_id',sample_column='sample',label_column=LABEL,total_counts_column='__auto_raw_qc__',coordinates_to_um=1.,
            prior_metadata=prior.loc[sample,'metadata'],source_image=im.loc[sample,'image_path']))
    return normalize_sources(pd.DataFrame(rows)),run,schema,dict(original_run=str(run),annotation_root=str(ann),package_dir=str(package),upstream_guard_checked=True)

def normalize_sources(df):
    df=df.copy()
    for c in ['sample','unit','condition','raw_h5ad','matrix_key','annotation_file']:
        if c not in df:raise KeyError(c)
        df[c]=strings(df[c],c,unique=c=='sample')
    if set(df.condition)!=set(CONDITIONS):raise ValueError('Need all four conditions for this CT26 study')
    if (df.groupby('unit').condition.nunique()>1).any():raise ValueError('Biological unit spans conditions; repeated-measures design is not configured')
    if df.raw_h5ad.duplicated().any():raise ValueError('This workstream expects separate physical sample raw files, not duplicate combined sources')
    for c in ['raw_h5ad','annotation_file','gene_table','prior_metadata','source_image']:
        if c not in df:df[c]=''
        df[c]=df[c].fillna('').astype(str)
        for p in df[c]:
            if p and c not in ['prior_metadata','source_image'] and not Path(p).is_file():raise FileNotFoundError(p)
    return df

def bh(v):
    x=np.asarray(v,float);out=np.full(len(x),np.nan);ids=np.flatnonzero(np.isfinite(x))
    if len(ids):
        order=ids[np.argsort(x[ids],kind='stable')];q=x[order]*len(order)/np.arange(1,len(order)+1)
        out[order]=np.minimum(1,np.minimum.accumulate(q[::-1])[::-1])
    return out
