"""Mouse-level dashboards and readable spatial profiles; plotted cells/tiles are not replicates."""
from pathlib import Path
import html
import numpy as np
import pandas as pd
from .common import *
from .expression import open_project,sample_cache

TUMOR_COLORS={'Tumor cell 1':'#CFD266','Tumor cell 2':'#BBDE93','Tumor cell 3':'#7EDD45','Tumor cell 4':'#549E3F','Tumor cell 5':'#4B9C79'}
CONDITION_COLORS={'Vehicle':'#606060','AntiPD1':'#3C76AF','Adagrasib':'#D88426','Combination':'#9C3B8B'}

def finish(fig,path,dpi):
    import matplotlib.pyplot as plt
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.stem+'.partial.png')
    fig.savefig(q,dpi=dpi,bbox_inches='tight',pad_inches=.15);plt.close(fig);q.replace(p)

def unit_points(df,value,path,title,ylabel,dpi=300):
    import matplotlib.pyplot as plt
    if df.empty:return
    # Same biological unit is never counted repeatedly as independent observations.
    g=df.groupby(['unit','condition'],observed=True)[value].agg(mean='mean',n='size',valid='count').reset_index()
    g.loc[g.n!=g.valid,'mean']=np.nan
    fig,ax=plt.subplots(figsize=(8.7,5.5))
    for i,c in enumerate(CONDITIONS):
        z=g.loc[(g.condition==c)&g['mean'].notna()]
        if len(z):
            xs=i+np.linspace(-.10,.10,len(z)) if len(z)>1 else np.array([i])
            ax.scatter(xs,z['mean'],s=42,color=CONDITION_COLORS[c],zorder=3)
            ax.plot([i-.22,i+.22],[z['mean'].mean()]*2,color=CONDITION_COLORS[c],lw=2)
            for xx,r in zip(xs,z.itertuples()):ax.annotate(str(r.unit),(xx,r.mean),xytext=(3,3),textcoords='offset points',fontsize=7)
        else:ax.text(i,.5,'NA',transform=ax.get_xaxis_transform(),ha='center')
    ax.set_xticks(range(4));ax.set_xticklabels([DISPLAY[c] for c in CONDITIONS],rotation=20,ha='right')
    ax.set(title=title,ylabel=ylabel)
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
    fig.text(.01,.005,'Points: biological units. Horizontal lines: means. No cell/tile-level significance tests.',fontsize=8)
    finish(fig,path,dpi)

def default_metrics(project,spatial_nonoverlap=False):
    _,j,_=open_project(project)
    out=['score__AP_MHCI_core','gene_log1p__Cd274','detected__Cd274','gene_log1p__Cxcl9','gene_log1p__Cxcl10','gene_log1p__Dusp6']
    h=['HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_INTERFERON_ALPHA_RESPONSE']
    if h[0] in j['programs']:
        out += ['score__'+g+('_spatial_no_AP_PDL1_CXCL' if spatial_nonoverlap else '') for g in h]
    else:out+=['score__IFN_core_spatial_no_AP_PDL1_CXCL' if spatial_nonoverlap else 'score__IFN_core_exploratory']
    return out

def expression_dashboard(root,model_root=None,populations=None,metrics=None,dpi=300):
    import matplotlib.pyplot as plt
    root,j,m=open_project(root);pops=populations or [ALL_TUMOR]+TUMOR;metrics=metrics or default_metrics(root)
    spec=dict(metrics=metrics,populations=pops,dpi=dpi,helper_sha=sha(__file__),summary=signature(root/'tables'/'tumor_program_cell_summaries.csv'),model_root=str(model_root))
    out=root/'figures'/'expression'/digest(spec)[:12];out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'plot_spec.json')
    df=pd.read_csv(root/'tables'/'tumor_program_cell_summaries.csv')
    for pop in pops:
        for metric in metrics:
            z=df.loc[(df.population==pop)&(df.metric==metric)].copy()
            z.loc[z.n_cells<50,'mean']=np.nan
            label='Raw detection fraction (not protein-defined positivity)' if metric.startswith('detected__') else 'Mean per-cell observed log1p-normalized signal'
            unit_points(z,'mean',out/slug(pop)/(slug(metric)+'.png'),f'{pop} | {metric}',label,dpi)
    proportions=[]
    for row in m.to_dict('records'):
        with np.load(sample_cache(root,row['sample'])/'allgene_compartment_sums.npz',allow_pickle=False) as z:
            cats=z['populations'].tolist();num=np.array([z['n_cells'][cats.index(x)] for x in TUMOR]);total=int(num.sum())
        proportions.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],**{c:(v/total if total else np.nan) for c,v in zip(TUMOR,num)}))
    prop=pd.DataFrame(proportions);save_csv(prop,out/'tumor_state_composition.csv')
    fig,ax=plt.subplots(figsize=(max(9,.6*len(prop)+3),6));bottom=np.zeros(len(prop))
    for c in TUMOR:
        ax.bar(np.arange(len(prop)),prop[c],bottom=bottom,label=c,color=TUMOR_COLORS[c],width=.7);bottom+=prop[c].fillna(0).to_numpy()
    ax.set_xticks(np.arange(len(prop)));ax.set_xticklabels([f'{r.sample}\n{DISPLAY[r.condition]}' for r in prop.itertuples()],rotation=70,ha='right',fontsize=8)
    ax.set(ylabel='Fraction of reviewed tumor cells',title='Tumor states: composition context, not a treatment-expression test',ylim=(0,1))
    ax.legend(bbox_to_anchor=(1.01,1),loc='upper left',frameon=False);finish(fig,out/'tumor_subtype_proportions.png',dpi)
    # Source-aware chemokine/PDL1 summary: separate observed compartments, not cell-origin proof.
    parts=[pd.read_csv(sample_cache(root,r['sample'])/'all_compartments_panel_summary.csv.gz') for r in m.to_dict('records')]
    context=pd.concat(parts,ignore_index=True)
    context=context.loc[context.gene.isin(['Cd274','Cxcl9','Cxcl10'])]
    save_csv(context,out/'Cd274_chemokine_compartment_context.csv')
    for gene,z in context.groupby('gene',sort=False):
        grouped=z.loc[z.n_cells>=30].groupby(['condition','population'],observed=True).agg(mean_log1p=('mean_log1p','mean'),fraction_detected=('fraction_detected','mean')).reset_index()
        cats=list(dict.fromkeys(z.population));pairs=[(c,p) for c in CONDITIONS for p in cats]
        fig,ax=plt.subplots(figsize=(8.5,max(5,.23*len(cats)+2)))
        for r in grouped.itertuples():
            ax.scatter(CONDITIONS.index(r.condition),cats.index(r.population),s=180*np.sqrt(max(0,r.fraction_detected)) if pd.notna(r.fraction_detected) else 0,
                c=[r.mean_log1p],cmap='viridis',vmin=0,vmax=max(1e-8,grouped.mean_log1p.max()),edgecolors='none')
        ax.set_xticks(range(4));ax.set_xticklabels([DISPLAY[c] for c in CONDITIONS],rotation=25,ha='right',fontsize=8)
        ax.set_yticks(range(len(cats)));ax.set_yticklabels(cats,fontsize=8);ax.invert_yaxis();ax.set_title(gene+' | measured compartment context\nSize: mean detected fraction; color: mean observed log1p')
        from matplotlib.cm import ScalarMappable
        from matplotlib.colors import Normalize
        fig.colorbar(ScalarMappable(norm=Normalize(0,max(1e-8,grouped.mean_log1p.max())),cmap='viridis'),ax=ax,label='Equal-sample mean log1p')
        finish(fig,out/(gene+'_compartment_context.png'),dpi)
    if model_root is not None:
        model=Path(model_root);status=pd.read_csv(model/'fit_status.csv',keep_default_na=False)
        focused=pd.read_csv(model/'focused_tumor_gene_results.csv') if (model/'focused_tumor_gene_results.csv').is_file() else None
        targets=j['definition']['individual_genes'][:]
        for fit in status.itertuples():
            if fit.status!='complete' or fit.population not in pops:continue
            d=Path(fit.directory);meta=pd.read_csv(d/'fitted_library_metadata.csv');x=pd.read_csv(d/'normalized_counts.tsv.gz',sep='\t',index_col=0)
            for gene in ['Cd274','B2m','Tap1','Nlrc5','Cxcl9','Cxcl10','Dusp6']:
                if gene not in x.index:continue
                vals=meta[['independent_unit','condition']].rename(columns={'independent_unit':'unit'}).copy()
                vals['value']=np.log2(x.loc[gene,meta.library_id].to_numpy(float)+1)
                unit_points(vals,'value',out/slug(fit.population)/(gene+'_DESeq2_pseudobulk.png'),fit.population+' | '+gene,'log2(DESeq2-normalized pseudobulk count + 1)',dpi)
            if focused is not None:
                z=focused.loc[(focused.population==fit.population)&(focused.family=='wald_pairwise')]
                tests=[f'{a}_vs_{b}' for a,b in PRIMARY]
                effect='lfc_shrunken' if 'lfc_shrunken' in z else 'log2FoldChange'
                mat=z.pivot(index='gene',columns='test_id',values=effect).reindex(index=targets,columns=tests)
                q=z.pivot(index='gene',columns='test_id',values='padj').reindex_like(mat)
                fig,ax=plt.subplots(figsize=(8,max(5,.28*len(mat)+2)))
                im=ax.imshow(np.ma.masked_invalid(mat.values),cmap='RdBu_r',vmin=-2,vmax=2,aspect='auto')
                for y,k in zip(*np.where((q.values<.05)&np.isfinite(mat.values))):ax.text(k,y,'*',ha='center',va='center')
                ax.set_xticks(range(2));ax.set_xticklabels(tests,rotation=25,ha='right',fontsize=8)
                ax.set_yticks(range(len(mat)));ax.set_yticklabels(mat.index,fontsize=9);ax.set_title(fit.population+' | adagrasib-focused contrasts\n* original gene-level padj < .05; NA masked')
                fig.colorbar(im,ax=ax,label=effect+' (display clipped ±2)');finish(fig,out/slug(fit.population)/'primary_AP_IFN_PDL1_effects.png',dpi)
        hpath=model/'all_tumor_Hallmark_results.csv'
        if hpath.is_file():
            h=pd.read_csv(hpath);keep=h.pathway.isin(['HALLMARK_INTERFERON_ALPHA_RESPONSE','HALLMARK_INTERFERON_GAMMA_RESPONSE'])
            save_csv(h.loc[keep],out/'IFN_Hallmark_focused_table.csv')
            for pop,g in h.loc[keep & h.population.isin(pops)].groupby('population',sort=False):
                tests=[f'{a}_vs_{b}' for a,b in PRIMARY];matrix=g.pivot(index='pathway',columns='test_id',values='NES').reindex(columns=tests)
                q=g.pivot(index='pathway',columns='test_id',values='padj').reindex_like(matrix)
                fig,ax=plt.subplots(figsize=(8,4));im=ax.imshow(np.ma.masked_invalid(matrix.values),aspect='auto',cmap='RdBu_r',vmin=-3,vmax=3)
                for y,k in zip(*np.where(q.values<.05)):ax.text(k,y,'*',ha='center',va='center')
                ax.set_xticks(range(2));ax.set_xticklabels(tests,rotation=20,ha='right',fontsize=9);ax.set_yticks(range(len(matrix)));ax.set_yticklabels(matrix.index,fontsize=8)
                ax.set_title(pop+' | canonical IFN Hallmark NES\nFDR calculated across all tested Hallmarks');fig.colorbar(im,ax=ax,label='NES');finish(fig,out/slug(pop)/'IFN_Hallmark_NES.png',dpi)
    gallery(out);return out

def spatial_profiles(root,spatial_root,populations=None,metrics=None,dpi=300):
    import matplotlib.pyplot as plt
    root,j,m=open_project(root);spatial=Path(spatial_root);pops=populations or [ALL_TUMOR]+TUMOR;metrics=metrics or default_metrics(root,True)
    df=pd.read_csv(spatial/'all_distance_profiles.csv');s=load_json(spatial/'spatial_spec.json')['spatial_settings']
    e=s['distance_edges_um'];names=[f'0-{e[0]:g}',f'{e[0]:g}-{e[1]:g}',f'{e[1]:g}-{e[2]:g}',f'>{e[2]:g}']
    out=spatial/'figures'/digest(dict(populations=pops,metrics=metrics,dpi=dpi,helper=sha(__file__)))[:12];out.mkdir(parents=True,exist_ok=True)
    for (pop,target,sensitivity,metric),sub in df.loc[df.population.isin(pops)&df.metric.isin(metrics)].groupby(['population','T_target','sensitivity','metric'],sort=False):
        fig,ax=plt.subplots(figsize=(8.4,5.4))
        z=sub.copy();z.loc[~z.eligible,'mean']=np.nan
        for sample,g in z.groupby('sample',sort=False):
            g=g.set_index('band').reindex(names);cond=g.condition.dropna().iloc[0] if g.condition.notna().any() else None
            if cond:ax.plot(range(4),g['mean'],marker='o',ms=3,lw=.7,alpha=.4,color=CONDITION_COLORS[cond])
        u=z.groupby(['unit','condition','band'],observed=True)['mean'].agg(value='mean',n='size',valid='count').reset_index()
        u.loc[u.n!=u.valid,'value']=np.nan
        for cond,g in u.groupby('condition',sort=False):
            average=g.groupby('band').value.mean().reindex(names)
            ax.plot(range(4),average,marker='o',lw=2.2,color=CONDITION_COLORS[cond],label=DISPLAY[cond])
        ax.set_xticks(range(4));ax.set_xticklabels(names);ax.set(xlabel=f'Distance to nearest {target} centroid (µm)',ylabel='Tumor-only mean measured signal',
            title=f'{pop} | {metric}\n{sensitivity}')
        ax.legend(frameon=False,fontsize=8);fig.text(.01,.01,'Thin: individual mice/sections; thick: mean units. Ineligible bands are NA. Spatial adjacency is not a causal effect.',fontsize=8)
        finish(fig,out/slug(pop)/slug(sensitivity)/slug(target)/(slug(metric)+'.png'),dpi)
    contrasts=pd.read_csv(spatial/'all_near_far_contrasts.csv')
    for (pop,metric,sensitivity),sub in contrasts.loc[(contrasts.population.isin(pops))&(contrasts.metric.isin(metrics))&(contrasts.T_target=='All T cell')].groupby(['population','metric','sensitivity'],sort=False):
        unit_points(sub,'near_minus_far',out/slug(pop)/slug(sensitivity)/('near_far_'+slug(metric)+'.png'),
                    f'{pop} | near ≤50 µm minus far >100 µm\n{metric} | {sensitivity}','Within-mouse mean signal difference',dpi)
    gallery(out);return out

def gallery(out):
    out=Path(out);parts=['<!doctype html><html><head><meta charset="utf-8"><title>Tumor immune visibility</title><style>body{font-family:Arial;margin:30px}img{max-width:100%;height:auto}figure{max-width:1300px;margin:25px 0}</style></head><body>',
        '<h1>Tumor-assigned immune-visibility transcription</h1><p>Exploratory RNA measurements; not surface MHC/PD-L1 status or proof of cell-intrinsic causality.</p>']
    for p in sorted(out.rglob('*.png')):
        rel=p.relative_to(out).as_posix();parts.append(f'<figure><figcaption>{html.escape(rel)}</figcaption><a href="{html.escape(rel)}"><img loading="lazy" src="{html.escape(rel)}"></a></figure>')
    parts.append('</body></html>');(out/'index.html').write_text('\n'.join(parts));return out/'index.html'
