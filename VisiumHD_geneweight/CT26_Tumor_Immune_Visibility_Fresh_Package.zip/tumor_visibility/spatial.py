"""Tumor-only expression, separately measured immune context; no cell/tile pseudoreplication."""
from pathlib import Path
from itertools import combinations
import gc
import h5py
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import spearmanr
from .common import *
from .expression import open_project,sample_cache,panel_score_matrix

DEFAULT_SPATIAL=dict(radii_um=[25.,50.],distance_edges_um=[25.,50.,100.],tile_sizes_um=[50.,100.],
    tumor_rich_radius_um=50.,tumor_rich_fraction=.8,tumor_rich_min_neighbors=5,
    min_cells_per_band=30,min_cells_per_tile=5,min_counts_per_tile=500,min_tiles_per_correlation=20,
    workers=8,chunk_cells=25000,
    immune_groups={'All T cell':T_TYPES,'T cell 1':['T cell 1'],'T cell 2':['T cell 2'],
                   'Myeloid':['Macrophage 1','Macrophage 2','Dendritic cell'],'Dendritic cell':['Dendritic cell']})

def nearest(tree,points,chunk,workers):
    out=np.full(len(points),np.nan)
    if tree is None:return out
    for a in range(0,len(points),chunk):out[a:a+chunk]=tree.query(points[a:a+chunk],k=1,eps=0,workers=workers)[0]
    return out

def within(tree,points,r,chunk,workers):
    out=np.zeros(len(points),np.int64)
    if tree is None:return out
    for a in range(0,len(points),chunk):out[a:a+chunk]=tree.query_ball_point(points[a:a+chunk],r=r,eps=0,workers=workers,return_length=True)
    return out

def context_metrics(tumor,reference,settings):
    s=settings;xy=tumor[['x_um','y_um']].to_numpy(float);allxy=reference[['x_um','y_um']].to_numpy(float)
    if not np.isfinite(xy).all() or not np.isfinite(allxy).all():raise ValueError('Invalid physical coordinates')
    if reference.source_cell_id.duplicated().any() or tumor.source_cell_id.duplicated().any():raise ValueError('Duplicate source IDs')
    refix=reference.set_index('source_cell_id');got=refix.loc[tumor.source_cell_id,['x_um','y_um']].to_numpy(float)
    if not np.allclose(got,xy,rtol=0,atol=1e-8):raise ValueError('Cached tumor/reference coordinate mismatch')
    out=tumor.copy();audit=[];labels=reference.population.astype('string')
    for group,members in s['immune_groups'].items():
        mask=labels.isin(members).to_numpy();tree=cKDTree(allxy[mask]) if mask.any() else None
        out['distance_um__'+group]=nearest(tree,xy,s['chunk_cells'],s['workers'])
        audit.append(dict(immune_group=group,n_targets=int(mask.sum()),status='ok' if mask.any() else 'no_target_cells'))
        for r in s['radii_um']:
            count=within(tree,xy,r,s['chunk_cells'],s['workers'])
            out[f'neighbors_r{r:g}um__{group}']=count
            out[f'density_r{r:g}um__{group}']=count/(np.pi*r*r)*1e6
        del tree
    r=s['tumor_rich_radius_um'];fulltree=cKDTree(allxy);tumtree=cKDTree(xy) if len(xy) else None
    total=within(fulltree,xy,r,s['chunk_cells'],s['workers'])-1
    num=within(tumtree,xy,r,s['chunk_cells'],s['workers'])-1
    if (total<0).any() or (num<0).any() or (num>total).any():raise AssertionError('Self-neighbor accounting failed')
    fraction=np.divide(num,total,out=np.full(len(xy),np.nan),where=total>0)
    out['full_segmented_neighbors_for_tumor_rich']=total
    out['annotated_tumor_neighbor_fraction']=fraction
    out['tumor_rich_context']=(total>=s['tumor_rich_min_neighbors'])&(fraction>=s['tumor_rich_fraction'])
    del fulltree,tumtree
    return out,pd.DataFrame(audit)

def bands(distance,edges):
    """[0,25], (25,50], (50,100], (100,inf); missing target remains NA, not far."""
    edges=np.asarray(edges,float)
    if len(edges)!=3 or np.any(np.diff(edges)<=0) or edges[0]<=0:raise ValueError('Exactly three increasing positive distance edges required')
    names=[f'0-{edges[0]:g}',f'{edges[0]:g}-{edges[1]:g}',f'{edges[1]:g}-{edges[2]:g}',f'>{edges[2]:g}']
    d=np.asarray(distance,float);ix=np.searchsorted(edges,d,side='left');out=np.array([names[min(i,3)] for i in ix],object)
    out[~np.isfinite(d)]=None
    return out,names

def profile_summaries(cells,row,s):
    metrics=[c for c in cells if c.startswith(('score__','gene_log1p__','detected__'))]
    records=[];contrast=[]
    for pop in [ALL_TUMOR]+TUMOR:
        p=cells if pop==ALL_TUMOR else cells.loc[cells.population==pop]
        for sensitivity in ['all_reviewed_tumor','tumor_rich_context']:
            q=p if sensitivity=='all_reviewed_tumor' else p.loc[p.tumor_rich_context]
            for target in ['All T cell']+T_TYPES:
                if 'distance_um__'+target not in q:continue
                b,names=bands(q['distance_um__'+target],s['distance_edges_um'])
                for name in names:
                    subset=q.loc[b==name]
                    for metric in metrics:
                        v=subset[metric].to_numpy(float);v=v[np.isfinite(v)]
                        records.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=pop,
                            sensitivity=sensitivity,T_target=target,band=name,metric=metric,n_cells=len(subset),n_measured=len(v),
                            eligible=len(v)>=s['min_cells_per_band'],mean=float(v.mean()) if len(v) else np.nan,
                            median=float(np.median(v)) if len(v) else np.nan))
                d=q['distance_um__'+target].to_numpy(float)
                near=q.loc[np.isfinite(d)&(d<=50.)];far=q.loc[np.isfinite(d)&(d>100.)]
                for metric in metrics:
                    a=near[metric].to_numpy(float);a=a[np.isfinite(a)];b=far[metric].to_numpy(float);b=b[np.isfinite(b)]
                    eligible=len(a)>=s['min_cells_per_band'] and len(b)>=s['min_cells_per_band']
                    contrast.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=pop,sensitivity=sensitivity,
                        T_target=target,metric=metric,n_near=len(a),n_far=len(b),eligible=eligible,
                        near_mean=float(a.mean()) if len(a) else np.nan,far_mean=float(b.mean()) if len(b) else np.nan,
                        near_minus_far=float(a.mean()-b.mean()) if eligible else np.nan))
    return pd.DataFrame(records),pd.DataFrame(contrast)

def make_tiles(cells,reference,h5path,j,s,row):
    """Nonoverlapping physical squares; expression ONLY from annotated tumor cells.
    Score = mean_g log1p(target * SUM_tumor counts_g / SUM_tumor all-source totals).
    It is not the mean per-cell score and not a smoothed mixed-cell image.
    """
    outputs=[];genes=j['panel_genes'];ng=len(genes);lookup={g:i for i,g in enumerate(genes)}
    tx=cells[['x_um','y_um']].to_numpy(float);rx=reference[['x_um','y_um']].to_numpy(float)
    with h5py.File(h5path) as h:
        if cells.source_cell_id.tolist()!=h['cell_id'].asstr()[...].tolist():raise ValueError('Tile cache cell order mismatch')
        for width in s['tile_sizes_um']:
            if width<=0:raise ValueError('Tile sizes must be positive')
            keys=np.floor(tx/width).astype(np.int64);rkeys=np.floor(rx/width).astype(np.int64)
            rtable=pd.DataFrame(rkeys,columns=['ix','iy']).value_counts(sort=False)
            for pop in [ALL_TUMOR]+TUMOR:
                mask=np.ones(len(cells),bool) if pop==ALL_TUMOR else cells.population.eq(pop).to_numpy()
                selected=np.flatnonzero(mask)
                if not len(selected):continue
                unique,codes=np.unique(keys[selected],axis=0,return_inverse=True);nt=len(unique)
                global_code=np.full(len(cells),-1,np.int64);global_code[selected]=codes
                counts=np.zeros((nt,ng),np.int64);det=np.zeros((nt,ng),np.int64)
                total=np.bincount(codes,weights=cells.all_source_total_counts.to_numpy()[selected],minlength=nt)
                nc=np.bincount(codes,minlength=nt)
                for a in range(0,len(cells),s['chunk_cells']):
                    b=min(a+s['chunk_cells'],len(cells));keep=global_code[a:b]>=0
                    if not keep.any():continue
                    pan=h['counts'][a:b,:][keep];tile=global_code[a:b][keep]
                    np.add.at(counts,tile,pan);np.add.at(det,tile,(pan>0).astype(np.int64))
                if not np.isfinite(total).all() or (total<=0).any():raise ValueError('Nonpositive tile tumor library')
                tab=pd.DataFrame(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=pop,
                     tile_width_um=width,ix=unique[:,0],iy=unique[:,1],x0_um=unique[:,0]*width,y0_um=unique[:,1]*width,
                     x_um=(unique[:,0]+.5)*width,y_um=(unique[:,1]+.5)*width,n_tumor_cells=nc,tumor_library_counts=total))
                tab['n_full_segmented_in_tile']=[int(rtable.get((int(x),int(y)),0)) for x,y in unique]
                # For subtype tiles this is subtype fraction, not total tumor fraction.
                tab['selected_tumor_group_fraction_in_tile']=nc/tab.n_full_segmented_in_tile
                valid=(nc>=s['min_cells_per_tile'])&(total>=s['min_counts_per_tile']);tab['expression_eligible']=valid
                out,expr=panel_score_matrix(counts,total,genes,j['programs'],j['settings']['normalization_target'])
                for metric,values in out.items():tab[metric]=np.where(valid,values,np.nan)
                for g,measured in j['scalar_genes'].items():
                    tab['gene_log1p__'+g]=np.where(valid,expr[:,lookup[g]],np.nan) if measured else np.nan
                    tab['detected__'+g]=np.where(valid,det[:,lookup[g]]/nc,np.nan) if measured else np.nan
                for metric in [c for c in cells if c.startswith(('distance_um__','density_r','neighbors_r'))]+['annotated_tumor_neighbor_fraction']:
                    values=cells[metric].to_numpy(float)[selected];finite=np.isfinite(values)
                    sums=np.bincount(codes[finite],weights=values[finite],minlength=nt);nvalid=np.bincount(codes[finite],minlength=nt)
                    tab['mean_cell_'+metric]=np.divide(sums,nvalid,out=np.full(nt,np.nan),where=nvalid>0)
                outputs.append(tab)
    return pd.concat(outputs,ignore_index=True) if outputs else pd.DataFrame(columns=['sample','unit','condition','population','tile_width_um','ix','iy','x0_um','y0_um','x_um','y_um','n_tumor_cells','tumor_library_counts','n_full_segmented_in_tile','selected_tumor_group_fraction_in_tile','expression_eligible']+['score__'+k for k in j['programs']]+['gene_log1p__'+g for g in j['scalar_genes']]+['detected__'+g for g in j['scalar_genes']])

def run(root,settings=None):
    root,j,m=open_project(root);s={**DEFAULT_SPATIAL,**(settings or {})}
    # Defaults may be overridden as a whole mapping, never silently combine unrelated labels.
    all_labels=set()
    for row in m.to_dict('records'):
        ref=pd.read_csv(sample_cache(root,row['sample'])/'full_reference_coordinates.csv.gz',dtype={'source_cell_id':str})
        all_labels.update(ref.population.dropna().astype(str))
    for g,members in s['immune_groups'].items():
        if set(members)-all_labels:raise ValueError(f'Unknown immune labels in {g}: {set(members)-all_labels}')
    if not set(['All T cell']+T_TYPES).issubset(s['immune_groups']):raise ValueError('Keep the requested broad All T/T1/T2 group definitions')
    spec=dict(project_id=j['project_id'],spatial_settings=s,helper_sha=sha(__file__),
        score_sources=[signature(sample_cache(root,r['sample'])/'tumor_scores.csv.gz') for r in m.to_dict('records')])
    sid=digest(spec);out=root/'spatial'/sid[:16];out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'spatial_spec.json')
    profiles=[];contrasts=[];correlations=[];diagnostics=[]
    for row in m.to_dict('records'):
        cache=sample_cache(root,row['sample']);dest=out/slug(row['sample']);dest.mkdir(exist_ok=True);done=dest/'complete.json'
        if done.is_file():
            rec=load_json(done)
            if rec['spatial_id']!=sid or any(not (dest/f).is_file() or (dest/f).stat().st_size!=v for f,v in rec['output_sizes'].items()):raise ValueError('Invalid completed spatial cache')
            print('Reusing tumor spatial metrics:',row['sample'])
        else:
            print('Tumor expression vs immune context:',row['sample'],flush=True)
            cells=pd.read_csv(cache/'tumor_scores.csv.gz',dtype={'source_cell_id':str,'population':str})
            reference=pd.read_csv(cache/'full_reference_coordinates.csv.gz',dtype={'source_cell_id':str,'population':str})
            enriched,audit=context_metrics(cells,reference,s);prof,con=profile_summaries(enriched,row,s)
            diagnostics_rows=[]
            for population in [ALL_TUMOR]+TUMOR:
                base=enriched if population==ALL_TUMOR else enriched.loc[enriched.population==population]
                for sensitivity in ['all_reviewed_tumor','tumor_rich_context']:
                    subset=base if sensitivity=='all_reviewed_tumor' else base.loc[base.tumor_rich_context]
                    rec=dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=population,sensitivity=sensitivity,
                             n_cells=len(subset),fraction_of_population_retained=len(subset)/len(base) if len(base) else np.nan,
                             median_all_source_counts=float(subset.all_source_total_counts.median()) if len(subset) else np.nan)
                    for key in ['score__AP_MHCI_core','score__immune_lineage_context','score__stromal_lineage_context','gene_log1p__Cd274','detected__Cd274']:
                        rec['mean_'+key]=float(subset[key].mean()) if key in subset and subset[key].notna().any() else np.nan
                    diagnostics_rows.append(rec)
            diagnostic=pd.DataFrame(diagnostics_rows)
            save_csv(diagnostic,dest/'lineage_context_depth_sensitivity.csv')
            tiles=make_tiles(enriched,reference,cache/'tumor_panel.h5',j,s,row)
            save_csv(enriched,dest/'tumor_expression_context.csv.gz');save_csv(audit,dest/'immune_target_counts.csv')
            save_csv(prof,dest/'distance_band_profiles.csv');save_csv(con,dest/'near_far_contrasts.csv')
            save_csv(tiles,dest/'tumor_only_tiles.csv.gz')
            records=[]
            if len(tiles):
                scorecols=[c for c in tiles if c.startswith(('score__','gene_log1p__','detected__'))]
                for (pop,width),z in tiles.groupby(['population','tile_width_um'],sort=False):
                    for group in ['All T cell']+T_TYPES:
                        key='mean_cell_density_r50um__'+group
                        if key not in z:continue
                        for metric in scorecols:
                            x=z[key].to_numpy(float);y=z[metric].to_numpy(float);good=np.isfinite(x)&np.isfinite(y)
                            usable=good.sum()>=s['min_tiles_per_correlation'] and np.ptp(x[good])>0 and np.ptp(y[good])>0
                            rho=float(spearmanr(x[good],y[good]).statistic) if usable else np.nan
                            records.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=pop,tile_width_um=width,
                                T_target=group,metric=metric,n_eligible_tiles=int(good.sum()),spearman_rho=rho,
                                inferential_pvalue_not_computed=True,note='Within-sample descriptive association; tiles not independent replicates'))
            corr=pd.DataFrame(records);save_csv(corr,dest/'tile_density_correlations.csv')
            outputs=['lineage_context_depth_sensitivity.csv','tumor_expression_context.csv.gz','immune_target_counts.csv','distance_band_profiles.csv','near_far_contrasts.csv','tumor_only_tiles.csv.gz','tile_density_correlations.csv']
            save_json(dict(spatial_id=sid,output_sizes={f:(dest/f).stat().st_size for f in outputs}),done)
            del cells,reference,enriched,tiles;gc.collect()
        diagnostics.append(pd.read_csv(dest/'lineage_context_depth_sensitivity.csv'))
        profiles.append(pd.read_csv(dest/'distance_band_profiles.csv'))
        contrasts.append(pd.read_csv(dest/'near_far_contrasts.csv'))
        try:correlations.append(pd.read_csv(dest/'tile_density_correlations.csv'))
        except pd.errors.EmptyDataError:pass
    save_csv(pd.concat(diagnostics,ignore_index=True),out/'lineage_context_depth_sensitivity.csv')
    save_csv(pd.concat(profiles,ignore_index=True),out/'all_distance_profiles.csv')
    save_csv(pd.concat(contrasts,ignore_index=True),out/'all_near_far_contrasts.csv')
    if correlations:save_csv(pd.concat(correlations,ignore_index=True),out/'all_tile_correlations.csv')
    save_json(dict(spatial_root=str(out)),root/'latest_spatial_pointer.json')
    return out

def exact_unit_test(x,y):
    x=np.asarray(x,float);y=np.asarray(y,float);v=np.r_[x,y];n=len(x);obs=abs(x.mean()-y.mean());extreme=0;total=0
    for ix in combinations(range(len(v)),n):
        sx=v[list(ix)].sum();d=abs(sx/n-(v.sum()-sx)/len(y));extreme+=d>=obs-1e-12;total+=1
    return dict(mean_difference=float(x.mean()-y.mean()),pvalue=extreme/total,n_permutations=total)

def compare_near_far(root,spatial_root,metrics=None,min_units=3):
    """Exploratory: treatment contrasts of mouse-level near-minus-far effects, not cells/tiles."""
    root,j,m=open_project(root);out=Path(spatial_root);df=pd.read_csv(out/'all_near_far_contrasts.csv')
    if metrics is None:
        metrics=['score__AP_MHCI_core','gene_log1p__Cd274']
        hm=['score__'+h+'_spatial_no_AP_PDL1_CXCL' for h in ['HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_INTERFERON_ALPHA_RESPONSE']]
        metrics+=hm if any(k[7:] in j['programs'] for k in hm) else ['score__IFN_core_spatial_no_AP_PDL1_CXCL']
    df=df.loc[df.metric.isin(metrics)].copy();df.loc[~df.eligible,'near_minus_far']=np.nan
    keys=['unit','condition','population','sensitivity','T_target','metric']
    units=df.groupby(keys,observed=True)['near_minus_far'].agg(value='mean',n_sections='size',n_valid='count').reset_index()
    units.loc[units.n_sections!=units.n_valid,'value']=np.nan;results=[]
    for keys_,g in units.groupby(['population','sensitivity','T_target','metric'],sort=False):
        context=dict(zip(['population','sensitivity','T_target','metric'],keys_))
        for a,b in PRIMARY:
            x=g.loc[(g.condition==a)&g.value.notna(),'value'].to_numpy();y=g.loc[(g.condition==b)&g.value.notna(),'value'].to_numpy()
            r=exact_unit_test(x,y) if len(x)>=min_units and len(y)>=min_units else dict(mean_difference=np.nan,pvalue=np.nan,n_permutations=0)
            results.append(dict(**context,contrast=f'{a}_vs_{b}',n_numerator=len(x),n_denominator=len(y),
                status='tested' if np.isfinite(r['pvalue']) else 'insufficient_complete_units',**r))
    result=pd.DataFrame(results);result['padj']=np.nan
    # Primary pooled and subtype exploration are not conflated; sensitivity is separate.
    result['family']=np.where((result.population==ALL_TUMOR)&(result.T_target=='All T cell'),'pooled_primary','subtype_or_Tstate_exploratory')
    for _,ix in result.groupby(['family','sensitivity']).groups.items():result.loc[ix,'padj']=bh(result.loc[ix,'pvalue'])
    save_csv(units,out/'near_far_unit_endpoints.csv');save_csv(result,out/'near_far_treatment_tests.csv')
    return result
