"""All-tumor-first and subtype raw pseudobulk DESeq2/Hallmark orchestration."""
from pathlib import Path
import json, os, shutil, subprocess
import numpy as np
import pandas as pd
from .common import *
from .expression import open_project,sample_cache

DEFAULT_MODEL=dict(min_cells=50,min_library_counts=1000,min_gene_count=10,min_gene_units=3,
    min_units_per_condition=3,alpha=.05,sf_type='poscounts',fit_type='parametric',shrinkage='ashr',
    run_hallmark=True,hallmark_min_size=15,hallmark_max_size=500,
    populations=[ALL_TUMOR]+TUMOR,confirmed_independent_units=True,
    design_note='User confirmed each sample is one tumor from a different mouse, no technical replicates; three per condition.')

def r_connection(path=None,rscript='Rscript'):
    env=os.environ.copy()
    if path:
        data=load_json(path);rscript=data['rscript'];env.update(data['environment'])
    exe=shutil.which(str(rscript)) or (str(Path(rscript)) if Path(rscript).is_file() else None)
    if not exe:raise FileNotFoundError('Set the same verified Rscript / r_connection.json used in 08H')
    return exe,env

def preflight(exe,env):
    script=Path(__file__).with_name('visibility_deseq2.R')
    p=subprocess.run([exe,'--vanilla',str(script),'--check'],env=env,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stdout+'\n'+p.stderr)
    return json.loads(p.stdout.strip().splitlines()[-1])

def prepare(root,settings=None):
    root,j,m=open_project(root);s={**DEFAULT_MODEL,**(settings or {})}
    if not s['confirmed_independent_units'] or not s['design_note'].strip():raise ValueError('Independent-unit design must be documented')
    if set(s['populations'])-set([ALL_TUMOR]+TUMOR):raise ValueError('Unknown tumor population')
    data=[]
    for row in m.to_dict('records'):
        f=sample_cache(root,row['sample'])/'allgene_compartment_sums.npz'
        if not (f.parent/'complete.json').is_file():raise ValueError('Complete extraction before fitting')
        data.append((row,f))
    mid=digest(dict(project_id=j['project_id'],settings=s,inputs=[signature(f) for _,f in data],model_helper=sha(__file__)))
    out=root/'model'/mid[:16];out.mkdir(parents=True,exist_ok=True);save_json(dict(settings=s,project_id=j['project_id'],model_input_id=mid),out/'input_spec.json')
    manifest=[];proportions=[]
    for pop in s['populations']:
        dest=out/slug(pop);dest.mkdir(exist_ok=True);C=[];P=[];sample_rows=[]
        leaves=TUMOR if pop==ALL_TUMOR else [pop]
        for row,f in data:
            with np.load(f,allow_pickle=False) as z:
                if z['genes'].tolist()!=j['genes']:raise ValueError('Pseudobulk gene axis mismatch')
                ix=[z['populations'].tolist().index(x) for x in leaves]
                c=z['counts'][ix].sum(axis=0,dtype=np.int64);present=z['present'].copy();n=int(z['n_cells'][ix].sum())
                all_ix=[z['populations'].tolist().index(x) for x in TUMOR];den=int(z['n_cells'][all_ix].sum())
            C.append(c);P.append(present);sample_rows.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],n_cells=n,total_counts=int(c.sum())))
            proportions.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=pop,n_cells=n,n_all_tumor=den,fraction_of_tumor=n/den if den else np.nan))
        C=np.asarray(C);P=np.asarray(P);sf=pd.DataFrame(sample_rows);unit_rows=[];UC=[];UP=[]
        for unit,g in sf.groupby('unit',sort=False):
            ids=g.index.to_numpy();active=ids[sf.loc[ids,'n_cells'].to_numpy()>0]
            c=C[ids].sum(axis=0,dtype=np.int64);p=P[active].all(axis=0) if len(active) else np.zeros(len(j['genes']),bool)
            unit_rows.append(dict(library_id=f'U{len(unit_rows)+1:03d}',independent_unit=unit,condition=g.condition.iloc[0],
                sample_ids=';'.join(g['sample']),n_sections=len(g),n_cells=int(g.n_cells.sum()),library_counts=int(c.sum())))
            UC.append(c);UP.append(p)
        uf=pd.DataFrame(unit_rows);UC=np.asarray(UC);UP=np.asarray(UP)
        uf['eligible']=(uf.n_cells>=s['min_cells'])&(uf.library_counts>=s['min_library_counts'])
        save_csv(sf,dest/'sample_QC.csv');save_csv(uf,dest/'unit_QC.csv')
        use=uf.eligible.to_numpy();counts_per_group=uf.loc[use].groupby('condition').size().reindex(CONDITIONS,fill_value=0)
        available=UP[use].all(axis=0) if use.any() else np.zeros(len(j['genes']),bool)
        enough=(UC[use]>=s['min_gene_count']).sum(axis=0)>=s['min_gene_units'];gene_use=available&enough
        save_csv(pd.DataFrame({'gene':j['genes'],'present_all_eligible_units':available,'count_filter_pass':enough,'tested':gene_use}),dest/'gene_filter.csv')
        save_npz(dest/'unfiltered_unit_counts.npz',counts=UC,present=UP,genes=np.array(j['genes']),library_id=uf.library_id.to_numpy(str))
        ok=bool((counts_per_group>=s['min_units_per_condition']).all() and gene_use.sum()>=50)
        reason='' if ok else f'Need >= {s["min_units_per_condition"]} units per condition and >=50 genes; units={counts_per_group.to_dict()}, genes={int(gene_use.sum())}'
        if ok:
            u=uf.loc[use].copy();order=sorted(range(len(u)),key=lambda i:(CONDITIONS.index(u.condition.iloc[i]),u.independent_unit.iloc[i]))
            u=u.iloc[order];c=UC[use][:,gene_use][order]
            if c.max()>np.iinfo(np.int32).max or (c.sum(axis=1)<=0).any():raise ValueError('Invalid DESeq2 counts')
            frame=pd.DataFrame(c.T,index=np.array(j['genes'])[gene_use],columns=u.library_id);frame.index.name='gene'
            save_csv(frame,dest/'counts.tsv.gz',True);save_csv(u,dest/'coldata.tsv')
        manifest.append(dict(population=pop,status='ready' if ok else 'not_testable',reason=reason,directory=str(dest),n_eligible_units=int(use.sum()),n_genes=int(gene_use.sum()),**{f'n_{k}':int(v) for k,v in counts_per_group.items()}))
    save_csv(pd.DataFrame(manifest),out/'population_input_manifest.csv');save_csv(pd.DataFrame(proportions),out/'tumor_state_proportions.csv')
    return out,pd.DataFrame(manifest)

def fit(root,input_root,settings=None,connection_json=None,rscript='Rscript',retry_failed=True):
    root,j,m=open_project(root);inp=Path(input_root);s=load_json(inp/'input_spec.json')['settings']
    if settings is not None and {**DEFAULT_MODEL,**settings}!=s:raise ValueError('Model settings differ; regenerate exports via prepare()')
    exe,env=r_connection(connection_json,rscript);versions=preflight(exe,env)
    if s['shrinkage']=='ashr' and not versions['ashr_available']:raise RuntimeError('ashr not visible in the selected R environment')
    gmt=load_json(root/'project_spec.json')['hallmark'];hallmark=bool(s['run_hallmark'] and gmt)
    if hallmark and not versions['fgsea_available']:raise RuntimeError('Install fgsea in the verified R library, or explicitly set run_hallmark=False and rebuild model inputs')
    script=Path(__file__).with_name('visibility_deseq2.R')
    inputs=pd.read_csv(inp/'population_input_manifest.csv',keep_default_na=False)
    spec=dict(input_id=load_json(inp/'input_spec.json')['model_input_id'],settings=s,versions=versions,R_sha=sha(script),
              gmt=gmt,run_hallmark=hallmark,counts_sha={r.population:sha(Path(r.directory)/'counts.tsv.gz') for r in inputs.itertuples() if r.status=='ready'})
    modelid=digest(spec);out=inp/'fits'/modelid[:16];out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'model_spec.json');statuses=[]
    for r in inputs.itertuples():
        dest=out/slug(r.population);dest.mkdir(exist_ok=True)
        if r.status!='ready':statuses.append(dict(population=r.population,status='not_testable',directory=str(dest),detail=r.reason));continue
        done=dest/'complete.json'
        if done.exists():
            rec=load_json(done)
            if rec['model_id']==modelid and all((dest/k).is_file() and sha(dest/k)==v for k,v in rec['hashes'].items()):
                print('Reusing tumor fit:',r.population);statuses.append(dict(population=r.population,status='complete',directory=str(dest),detail='reused'));continue
            raise ValueError('Changed completed model output; do not silently overwrite')
        job=dict(model_id=modelid,population=r.population,counts=str(Path(r.directory)/'counts.tsv.gz'),metadata=str(Path(r.directory)/'coldata.tsv'),
                 output=str(dest),settings=s,run_hallmark=hallmark,gmt=gmt['path'] if hallmark else '',primary_contrasts=[f'{a}_vs_{b}' for a,b in PRIMARY])
        save_json(job,dest/'job.json');print('Reference DESeq2:',r.population,flush=True)
        with (dest/'DESeq2.log').open('w') as log:
            proc=subprocess.Popen([exe,'--vanilla',str(script),str(dest/'job.json')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
            try:
                for line in proc.stdout:print(line,end='',flush=True);log.write(line);log.flush()
                ret=proc.wait()
            except BaseException:proc.terminate();proc.wait();raise
        if ret or not (dest/'complete_R.json').is_file():
            statuses.append(dict(population=r.population,status='failed',directory=str(dest),detail='See DESeq2.log'))
        else:
            files=[f for f in dest.iterdir() if f.suffix in ['.rds','.csv','.gz','.txt'] and f.name!='DESeq2.log']
            save_json(dict(model_id=modelid,hashes={f.name:sha(f) for f in files}),done)
            statuses.append(dict(population=r.population,status='complete',directory=str(dest),detail='new fit'))
        save_csv(pd.DataFrame(statuses),out/'fit_status.csv')
    save_csv(pd.DataFrame(statuses),out/'fit_status.csv')
    save_json(dict(model_root=str(out),input_root=str(inp)),root/'latest_tumor_model_pointer.json')
    return out,pd.DataFrame(statuses)

def collect_targets(root,model_root):
    root,j,m=open_project(root);model=Path(model_root);status=pd.read_csv(model/'fit_status.csv',keep_default_na=False);rows=[];fgsea=[]
    targets=list(dict.fromkeys(j['definition']['individual_genes']+j['definition']['panels']['AP_MHCI_core']))
    for r in status.itertuples():
        if r.status!='complete':continue
        p=Path(r.directory);index=pd.read_csv(p/'result_index.csv',keep_default_na=False)
        for z in index.itertuples():
            f=pd.read_csv(p/z.file,sep='\t').set_index('gene')
            for gene in targets:
                d=f.loc[gene].to_dict() if gene in f.index else {}
                rows.append(dict(population=r.population,family=z.family,test_id=z.test_id,gene=gene,tested=gene in f.index,
                    interpretation='NOT_TESTED_OR_UNAVAILABLE' if gene not in f.index else 'tested',**d))
        for f in p.glob('fgsea_*.tsv.gz'):
            x=pd.read_csv(f,sep='\t');x['population']=r.population;x['test_id']=f.name[len('fgsea_'):-len('.tsv.gz')];fgsea.append(x)
    result=pd.DataFrame(rows) if rows else pd.DataFrame(columns=['population','family','test_id','gene','tested','interpretation','padj','log2FoldChange'])
    save_csv(result,model/'focused_tumor_gene_results.csv')
    if fgsea:
        h=pd.concat(fgsea,ignore_index=True);h['padj_primary_IFN_screen']=np.nan
        use=h.pathway.isin(['HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_INTERFERON_ALPHA_RESPONSE'])&h.test_id.isin([f'{a}_vs_{b}' for a,b in PRIMARY])
        h.loc[use,'padj_primary_IFN_screen']=bh(h.loc[use,'pval'])
        save_csv(h,model/'all_tumor_Hallmark_results.csv')
    return result

def backend_smoke_test(output_root,connection_json=None,rscript='Rscript'):
    """Runs only SIMULATED data on the user's R stack, never actual CT26 sources."""
    exe,env=r_connection(connection_json,rscript);versions=preflight(exe,env)
    if not versions['ashr_available']:raise RuntimeError('ashr is required for this configured smoke test')
    script=Path(__file__).with_name('visibility_deseq2.R');sid=digest(dict(versions=versions,script=sha(script),seed=18))
    out=Path(output_root)/'_R_backend_smoke'/sid[:12];out.mkdir(parents=True,exist_ok=True)
    if (out/'validated.json').is_file():return load_json(out/'validated.json')
    rng=np.random.default_rng(18);g=600;conds=np.repeat(CONDITIONS,3);A=np.isin(conds,['AntiPD1','Combination']);B=np.isin(conds,['Adagrasib','Combination'])
    base=rng.lognormal(np.log(80),.7,g);lfcA=np.zeros(g);lfcB=np.zeros(g);inter=np.zeros(g)
    lfcA[:40]=1.5;lfcB[40:80]=1.5;inter[80:120]=2
    mu=base[:,None]*2**(lfcA[:,None]*A+lfcB[:,None]*B+inter[:,None]*(A&B));theta=60
    c=rng.negative_binomial(theta,theta/(theta+mu));ids=[f'SIM{i:02d}' for i in range(12)]
    counts=pd.DataFrame(c,index=[f'SIMGENE{i}' for i in range(g)],columns=ids);counts.index.name='gene'
    save_csv(counts,out/'counts.tsv.gz',True);meta=pd.DataFrame(dict(library_id=ids,independent_unit=ids,condition=conds,n_cells=1000))
    save_csv(meta,out/'coldata.tsv');settings={**DEFAULT_MODEL,'run_hallmark':False,'fit_type':'mean'}
    save_json(dict(model_id=sid,population='SIMULATED_BACKEND_TEST_NOT_CT26',counts=str(out/'counts.tsv.gz'),metadata=str(out/'coldata.tsv'),output=str(out),settings=settings,
                   run_hallmark=False,gmt='',primary_contrasts=[f'{a}_vs_{b}' for a,b in PRIMARY]),out/'job.json')
    proc=subprocess.run([exe,'--vanilla',str(script),str(out/'job.json')],env=env,capture_output=True,text=True)
    (out/'smoke.log').write_text(proc.stdout+'\n'+proc.stderr)
    if proc.returncode:raise RuntimeError('Synthetic R smoke test failed; see '+str(out/'smoke.log'))
    idx=pd.read_csv(out/'result_index.csv')
    if len(idx)!=9 or idx.loc[idx.family=='lrt_omnibus','df'].iloc[0]!=3 or idx.loc[idx.family=='lrt_interaction','df'].iloc[0]!=1:raise AssertionError('Unexpected DESeq2 result inventory/DF')
    r=pd.read_csv(out/'Adagrasib_vs_Vehicle.tsv.gz',sep='\t')
    if 'lfc_shrunken' not in r or r.loc[r.gene.isin([f'SIMGENE{i}' for i in range(40,80)]),'lfc_shrunken'].median()<=0:raise AssertionError('Synthetic ashr direction failed')
    result=dict(status='passed_on_this_server',synthetic_only=True,versions=versions,path=str(out))
    save_json(result,out/'validated.json');return result
