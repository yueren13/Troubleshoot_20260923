"""One chunked read per physical sample: all-gene compartment sums + tumor-only panel cache."""
from __future__ import annotations
from pathlib import Path
import gc, json, math, warnings
import h5py
import numpy as np
import pandas as pd
import scipy.sparse as sp
from .common import *

HALLMARKS=['HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_INTERFERON_ALPHA_RESPONSE']
DEFAULT_EXTRACT=dict(chunk_cells=20000,normalization_target=10000.,min_panel_coverage=.7,
                    allow_missing_hallmarks=True,genotype_note='CT26 derivative/allele not yet documented',
                    biological_design_note='User confirmed: 12 independent mouse tumors, three per condition, no technical replicates.')

def gmt_read(path):
    out={}
    for i,line in enumerate(Path(path).read_text(encoding='utf-8-sig').splitlines(),1):
        if not line.strip():continue
        fields=line.split('\t')
        if len(fields)<3:raise ValueError(f'Malformed GMT line {i}')
        name=fields[0]
        if name in out:raise ValueError(f'Duplicate GMT set {name}')
        genes=list(dict.fromkeys(fields[2:]));strings(genes,'GMT genes')
        out[name]=genes
    return out

def create_project(manifest,output_root,program_file,settings=None,hallmark_gmt=None,hallmark_release='',provenance=None):
    m=normalize_sources(manifest);s={**DEFAULT_EXTRACT,**(settings or {})}
    if s['chunk_cells']<1 or s['normalization_target']<=0 or not 0<s['min_panel_coverage']<=1:raise ValueError('Invalid extraction settings')
    program_file=Path(program_file);definition=load_json(program_file);requested=dict(definition['panels'])
    gmt=None
    if hallmark_gmt:
        if not str(hallmark_release).strip():raise ValueError('Record the mouse GMT release/source explicitly')
        gmt=gmt_read(hallmark_gmt)
        for key in HALLMARKS:
            if key not in gmt:raise KeyError(f'Missing canonical Hallmark {key}')
            requested[key]=gmt[key]
            requested[key+'_spatial_no_AP_PDL1_CXCL']=[g for g in gmt[key] if g not in set(definition['spatial_ifn_exclusion_genes'])]
    elif not s['allow_missing_hallmarks']:
        raise ValueError('Provide the same mouse-symbol GMT used by 08J; not bundled or auto-downloaded')
    requested['IFN_core_spatial_no_AP_PDL1_CXCL']=[g for g in definition['panels']['IFN_core_exploratory'] if g not in set(definition['spatial_ifn_exclusion_genes'])]
    wanted=list(dict.fromkeys(definition['individual_genes']+[g for x in requested.values() for g in x]))
    symbols={};specs=[];feature_rows=[]
    for row in m.to_dict('records'):
        with RawReader(row['raw_h5ad'],row['matrix_key']) as raw:
            sym=source_symbols(row,raw);symbols[row['sample']]=set(sym)
            for f,g in zip(raw.var.index,sym):feature_rows.append(dict(sample=row['sample'],feature_id=f,gene=g))
        specs.append(dict(row=row,files={k:signature(row[k]) for k in ['raw_h5ad','annotation_file','gene_table'] if row.get(k)}))
    allgenes=sorted(set().union(*symbols.values()));common=set.intersection(*symbols.values())
    audit=[];programs={}
    for name,genes in requested.items():
        genes=list(dict.fromkeys(genes));measured=[g for g in genes if g in common]
        enough=len(measured)>=min(3,len(genes)) and len(measured)/len(genes)>=s['min_panel_coverage']
        programs[name]=dict(requested_genes=genes,measured_genes=measured,eligible=enough,
            coverage_fraction=len(measured)/len(genes),score_definition='mean log1p(target_sum * gene counts / all-source library counts)',
            canonical_set=name in HALLMARKS,spatial_nonoverlap='spatial_no_' in name)
        for g in genes:audit.append(dict(program=name,gene=g,present_in_all_samples=g in common,
                               n_samples_present=sum(g in symbols[x] for x in symbols),score_eligible=enough))
    scalar={g:g in common for g in definition['individual_genes']}
    spec=dict(version=VERSION,io_sha=sha(Path(__file__).with_name('common.py')),expression_sha=sha(__file__),
        samples=specs,program_file=signature(program_file),program_sha=sha(program_file),settings=s,
        hallmark=dict(path=str(Path(hallmark_gmt).resolve()),sha256=sha(hallmark_gmt),release=hallmark_release) if hallmark_gmt else None,
        phenotype_language='Tumor-assigned/associated transcription, not established cell-intrinsic origin or protein status')
    pid=digest(spec);root=Path(output_root).expanduser().resolve()/pid[:16]
    for d in ['input_review','sample_cache','tables','model','spatial','figures']:(root/d).mkdir(parents=True,exist_ok=True)
    save_json(spec,root/'project_spec.json');save_csv(m,root/'source_manifest.csv')
    save_json(dict(project_id=pid,genes=allgenes,panel_genes=wanted,programs=programs,scalar_genes=scalar,
              definition=definition,common_source_genes=sorted(common),settings=s,provenance=provenance or {}),root/'project.json')
    save_csv(pd.DataFrame(audit),root/'input_review'/'program_gene_coverage.csv')
    save_csv(pd.DataFrame(feature_rows),root/'input_review'/'source_feature_symbols.csv.gz')
    save_csv(pd.DataFrame({'gene':allgenes,'n_samples_present':[sum(g in symbols[x] for x in symbols) for g in allgenes]}),root/'input_review'/'all_gene_coverage.csv')
    if gmt:save_json({k:gmt[k] for k in HALLMARKS},root/'input_review'/'supplied_IFN_Hallmark_membership.json')
    save_json(dict(canonical_hallmark_status='configured' if gmt else 'NOT_RUN_NO_GMT',
                   exploratory_core_not_a_substitute=True),root/'input_review'/'hallmark_status.json')
    return root

def open_project(root):
    root=Path(root).resolve();j=load_json(root/'project.json');m=pd.read_csv(root/'source_manifest.csv',keep_default_na=False)
    return root,j,m

def sample_cache(root,sample):return Path(root)/'sample_cache'/slug(sample)

def _projection(source_symbols,dest):
    lut={g:i for i,g in enumerate(dest)};rr=[];cc=[]
    for i,g in enumerate(source_symbols):
        if g in lut:rr.append(i);cc.append(lut[g])
    return sp.csr_matrix((np.ones(len(rr),dtype=np.int64),(rr,cc)),shape=(len(source_symbols),len(dest)))

def panel_score_matrix(counts,totals,genes,programs,target):
    """Actual zeros kept; genes absent from a source are NOT silently scored as zeros."""
    counts=np.asarray(counts);totals=np.asarray(totals,float)
    if np.any(totals<=0) or not np.isfinite(totals).all():raise ValueError('Scores require positive raw library totals')
    expr=np.log1p(counts*(target/totals[:,None]));lookup={g:i for i,g in enumerate(genes)};out={}
    for name,p in programs.items():
        out['score__'+name]=expr[:,[lookup[g] for g in p['measured_genes']]].mean(axis=1) if p['eligible'] else np.full(len(counts),np.nan)
    return out,expr

def extract(root,verify_cached_hashes=False):
    root,j,m=open_project(root);panel=j['panel_genes'];genes=j['genes'];settings=j['settings'];complete=[]
    sourcespec={x['row']['sample']:x for x in load_json(root/'project_spec.json')['samples']}
    for row in m.to_dict('records'):
        sample=row['sample'];dest=sample_cache(root,sample);dest.mkdir(parents=True,exist_ok=True)
        for k,old in sourcespec[sample]['files'].items():
            if signature(row[k])!=old:raise RuntimeError(f'{sample}: source changed after project setup ({k})')
        done=dest/'complete.json'
        if done.is_file():
            rec=load_json(done)
            if rec['project_id']!=j['project_id']:raise ValueError('Wrong completed cache identity')
            for name,h in rec['outputs'].items():
                p=dest/name
                if not p.is_file() or p.stat().st_size!=h['size'] or (verify_cached_hashes and sha(p)!=h['sha256']):raise ValueError('Changed/incomplete sample cache '+str(p))
            print('Reusing tumor expression:',sample,flush=True);complete.append(rec['summary']);continue
        print('Extracting all-gene sums and tumor panel:',sample,flush=True)
        with RawReader(row['raw_h5ad'],row['matrix_key']) as raw:
            a=annotation(row,raw);sym=source_symbols(row,raw);symset=set(sym);gene_lookup={g:i for i,g in enumerate(genes)}
            observed=list(dict.fromkeys(a['population'].dropna().astype(str)))
            # Populate every declared tumor group even when absent, without generating artificial cells.
            cats=list(dict.fromkeys(TUMOR+observed));selected=a.loc[a.population.notna()].copy()
            cats_index={c:i for i,c in enumerate(cats)}
            gcodes=np.array([cats_index[c] for c in selected.population.astype(str)],np.int32)
            tumor_mask=selected.population.isin(TUMOR).to_numpy();tumor_meta=selected.loc[tumor_mask].copy()
            selected_to_tumor=np.full(len(selected),-1,np.int64);selected_to_tumor[tumor_mask]=np.arange(tumor_mask.sum())
            panel_proj=_projection(sym,panel);all_proj=_projection(sym,genes)
            pb=np.zeros((len(cats),len(genes)),np.int64);pdet=np.zeros((len(cats),len(panel)),np.int64)
            plog=np.zeros((len(cats),len(panel)),float);ns=np.bincount(gcodes,minlength=len(cats));lib=np.zeros(len(cats),np.int64)
            temp=dest/'tumor_panel.partial.h5';final=dest/'tumor_panel.h5';temp.unlink(missing_ok=True)
            with h5py.File(temp,'w') as h:
                h.attrs['project_id']=j['project_id'];h.attrs['sample']=sample
                h.create_dataset('cell_id',data=tumor_meta.index.to_numpy(object),dtype=h5py.string_dtype())
                h.create_dataset('gene',data=np.array(panel,object),dtype=h5py.string_dtype())
                h.create_dataset('source_gene_present',data=np.array([g in symset for g in panel],bool))
                if len(tumor_meta):ds=h.create_dataset('counts',shape=(len(tumor_meta),len(panel)),dtype='i4',chunks=(min(2048,len(tumor_meta)),len(panel)),compression='lzf')
                else:ds=h.create_dataset('counts',shape=(0,len(panel)),dtype='i4')
                totals=np.zeros(len(tumor_meta),np.int64);seen=np.zeros(len(selected),bool)
                for pos,x in raw.selected(selected.index,int(settings['chunk_cells'])):
                    x=validate_counts(x);rawtot=np.asarray(x.sum(axis=1,dtype=np.int64)).ravel()
                    expected=selected.raw_total_counts.iloc[pos].to_numpy(float)
                    if not np.allclose(rawtot,expected,atol=1e-4,rtol=0):raise ValueError('All-source library totals differ from completed QC; inspect raw matrix/source IDs')
                    if (rawtot<=0).any():raise ValueError('Annotated zero-library cells; no pseudocounts')
                    membership=sp.csr_matrix((np.ones(len(pos),np.int64),(gcodes[pos],np.arange(len(pos)))),shape=(len(cats),len(pos)))
                    pb+=(membership@x@all_proj).toarray()
                    pan=(x@panel_proj).toarray()
                    if pan.max(initial=0)>np.iinfo(np.int32).max:raise OverflowError('Panel cell counts exceed int32')
                    pdet+=np.asarray(membership@(pan>0).astype(np.int64));plog+=np.asarray(membership@np.log1p(pan*(settings['normalization_target']/rawtot[:,None])))
                    lib+=np.bincount(gcodes[pos],weights=rawtot,minlength=len(cats)).astype(np.int64)
                    sel=selected_to_tumor[pos]>=0
                    ti=selected_to_tumor[pos[sel]];order=np.argsort(ti)
                    if len(ti):ds[ti[order],:]=pan[sel][order].astype(np.int32);totals[ti]=rawtot[sel]
                    if seen[pos].any():raise AssertionError('Duplicate selected source rows')
                    seen[pos]=True
                if not seen.all() or not np.array_equal(pb.sum(axis=1),lib):raise AssertionError('Count/cell conservation check failed')
                h.create_dataset('all_source_total_counts',data=totals);h.flush()
            temp.replace(final)
            tumor_meta['all_source_total_counts']=totals
            columns=['source_cell_id','population','x_um','y_um','all_source_total_counts']
            for col in ['total_counts','n_genes_by_counts','pct_counts_mt','cell_area_um2']:
                if col in tumor_meta:columns.append(col)
            save_csv(tumor_meta[columns],dest/'tumor_cells.csv.gz',index=False)
            # All full-reference coordinates remain available for local coverage/neighbor context.
            ref=a[['source_cell_id','population','x_um','y_um']].copy();ref['in_reviewed_annotation']=ref.population.notna()
            save_csv(ref,dest/'full_reference_coordinates.csv.gz')
            save_npz(dest/'allgene_compartment_sums.npz',counts=pb,n_cells=ns,all_source_totals=lib,
                     populations=np.array(cats),genes=np.array(genes),present=np.array([g in symset for g in genes]))
            panrows=[]
            for i,c in enumerate(cats):
                for z,g in enumerate(panel):
                    present=g in symset
                    panrows.append(dict(sample=sample,unit=row['unit'],condition=row['condition'],population=c,gene=g,n_cells=int(ns[i]),
                        source_measured=present,total_raw_counts=int(pb[i,gene_lookup[g]]) if present and g in genes else np.nan,
                        fraction_detected=float(pdet[i,z]/ns[i]) if present and ns[i] else np.nan,
                        mean_log1p=float(plog[i,z]/ns[i]) if present and ns[i] else np.nan))
            save_csv(pd.DataFrame(panrows),dest/'all_compartments_panel_summary.csv.gz')
            summary=dict(sample=sample,unit=row['unit'],condition=row['condition'],n_full_cells=len(a),n_reviewed=len(selected),n_tumor=len(tumor_meta),
                         n_genes=len(genes),n_panel_genes=len(panel),hallmark_configured=load_json(root/'project_spec.json')['hallmark'] is not None)
            files=[final,dest/'tumor_cells.csv.gz',dest/'full_reference_coordinates.csv.gz',dest/'allgene_compartment_sums.npz',dest/'all_compartments_panel_summary.csv.gz']
            save_json(dict(project_id=j['project_id'],summary=summary,outputs={p.name:dict(size=p.stat().st_size,sha256=sha(p)) for p in files}),done)
            complete.append(summary)
        gc.collect()
    save_csv(pd.DataFrame(complete),root/'tables'/'extraction_summary.csv')
    return pd.DataFrame(complete)

def compute_cell_scores(root):
    root,j,m=open_project(root);summaries=[]
    for row in m.to_dict('records'):
        d=sample_cache(root,row['sample']);source=d/'tumor_panel.h5'
        if not (d/'complete.json').is_file():raise ValueError('Finish extraction first for '+row['sample'])
        spec=dict(panel=signature(source),programs=j['programs'],scalar=j['scalar_genes'],target=j['settings']['normalization_target'])
        identity=digest(spec);done=d/'scores_complete.json';outfile=d/'tumor_scores.csv.gz'
        if done.exists() and load_json(done).get('score_id')==identity and outfile.is_file():
            scores=pd.read_csv(outfile,dtype={'source_cell_id':str})
        else:
            scores=pd.read_csv(d/'tumor_cells.csv.gz',dtype={'source_cell_id':str,'population':str})
            with h5py.File(source) as h:
                if scores.source_cell_id.tolist()!=h['cell_id'].asstr()[...].tolist():raise ValueError('Score cell axis mismatch')
                names=h['gene'].asstr()[...].tolist();lookup={g:i for i,g in enumerate(names)}
                for a in range(0,len(scores),j['settings']['chunk_cells']):
                    b=min(len(scores),a+j['settings']['chunk_cells']);counts=h['counts'][a:b,:];tot=h['all_source_total_counts'][a:b]
                    calculated,expr=panel_score_matrix(counts,tot,names,j['programs'],j['settings']['normalization_target'])
                    for key,value in calculated.items():scores.loc[a:b-1,key]=value
                    for g,available in j['scalar_genes'].items():
                        scores.loc[a:b-1,'gene_log1p__'+g]=expr[:,lookup[g]] if available else np.nan
                        scores.loc[a:b-1,'detected__'+g]=(counts[:,lookup[g]]>0).astype(float) if available else np.nan
            if not len(scores):
                for key in j['programs']:scores['score__'+key]=np.nan
                for g in j['scalar_genes']:scores['gene_log1p__'+g]=np.nan;scores['detected__'+g]=np.nan
            save_csv(scores,outfile);save_json(dict(score_id=identity,spec=spec),done)
        metrics=[c for c in scores if c.startswith(('score__','gene_log1p__','detected__'))]
        for pop in [ALL_TUMOR]+TUMOR:
            x=scores if pop==ALL_TUMOR else scores.loc[scores.population==pop]
            for metric in metrics:
                v=pd.to_numeric(x[metric],errors='raise');finite=v[np.isfinite(v)]
                summaries.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=pop,metric=metric,
                    n_cells=len(x),n_measured_cells=len(finite),mean=float(finite.mean()) if len(finite) else np.nan,
                    median=float(finite.median()) if len(finite) else np.nan))
    save_csv(pd.DataFrame(summaries),root/'tables'/'tumor_program_cell_summaries.csv')
    return pd.DataFrame(summaries)
