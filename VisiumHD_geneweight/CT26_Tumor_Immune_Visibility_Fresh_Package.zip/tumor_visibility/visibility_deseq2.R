#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)
for (p in c('jsonlite','DESeq2')) if (!requireNamespace(p,quietly=TRUE)) stop('Required R package missing: ',p)
suppressPackageStartupMessages(library(DESeq2))
if (length(args)==1 && args[[1]]=='--check') {
 cat(jsonlite::toJSON(list(R=R.version.string,DESeq2=as.character(packageVersion('DESeq2')),
  ashr_available=requireNamespace('ashr',quietly=TRUE),fgsea_available=requireNamespace('fgsea',quietly=TRUE)),auto_unbox=TRUE),'\n');quit(status=0)
}
if (length(args)!=1) stop('Supply job.json')
j <- jsonlite::fromJSON(args[[1]],simplifyVector=TRUE);s <- j$settings;out <- j$output
set.seed(17);dir.create(out,recursive=TRUE,showWarnings=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'R_sessionInfo.txt'))
writegz <- function(x,file,index=FALSE) {
 if(index) x <- data.frame(gene=rownames(x),as.data.frame(x),check.names=FALSE)
 con <- gzfile(file.path(out,file),'wt');tryCatch(write.table(x,con,sep='\t',quote=FALSE,row.names=FALSE,na='NA'),finally=close(con))
}
f <- read.delim(gzfile(j$counts),check.names=FALSE,stringsAsFactors=FALSE)
ids <- f$gene;cts <- as.matrix(f[,-1,drop=FALSE]);rownames(cts) <- ids
if(anyDuplicated(ids)||anyNA(ids)||any(!is.finite(cts))||any(cts<0)||any(cts!=round(cts))||max(cts)>.Machine$integer.max) stop('Invalid integer counts')
storage.mode(cts)<-'integer'
meta<-read.delim(j$metadata,check.names=FALSE,stringsAsFactors=FALSE);rownames(meta)<-meta$library_id
if(anyDuplicated(meta$independent_unit)||!setequal(colnames(cts),rownames(meta))) stop('Invalid independent units or axes')
meta<-meta[colnames(cts),,drop=FALSE]
meta$condition<-factor(meta$condition,levels=c('Vehicle','AntiPD1','Adagrasib','Combination'))
if(anyNA(meta$condition)||any(table(meta$condition)<as.integer(s$min_units_per_condition)))stop('Insufficient units per condition')
meta$anti_pd1<-factor(as.integer(meta$condition %in% c('AntiPD1','Combination')),levels=c(0,1))
meta$adagrasib<-factor(as.integer(meta$condition %in% c('Adagrasib','Combination')),levels=c(0,1))
mm<-model.matrix(~condition,meta);fm<-model.matrix(~anti_pd1*adagrasib,meta)
if(qr(mm)$rank!=ncol(mm)||nrow(mm)<=ncol(mm)||qr(cbind(mm,fm))$rank!=ncol(mm))stop('Invalid design/full model spans')
write.csv(meta,file.path(out,'fitted_library_metadata.csv'),row.names=FALSE)
dds<-DESeqDataSetFromMatrix(cts,meta,~condition)
dds<-DESeq(dds,test='Wald',sfType=s$sf_type,fitType=s$fit_type,betaPrior=FALSE,minReplicatesForReplace=Inf,quiet=FALSE)
saveRDS(dds,file.path(out,'DESeq2_Wald.rds'))
writegz(counts(dds,normalized=TRUE),'normalized_counts.tsv.gz',TRUE)
writegz(assay(varianceStabilizingTransformation(dds,blind=FALSE)),'vst_expression.tsv.gz',TRUE)
write.csv(data.frame(library_id=colnames(dds),size_factor=sizeFactors(dds),library_counts=colSums(cts)),file.path(out,'size_factors.csv'),row.names=FALSE)
qc<-data.frame(gene=rownames(dds),baseMean=mcols(dds)$baseMean,dispersion=dispersions(dds))
for(n in c('betaConv','maxCooks','dispOutlier'))if(n %in% names(mcols(dds))) qc[[n]]<-mcols(dds)[[n]]
write.csv(qc,file.path(out,'gene_fit_diagnostics.csv'),row.names=FALSE)
index<-list();effects<-data.frame(gene=ids)
save_res<-function(res,name,family,num='',den='',df=1,lrt=FALSE) {
 x<-as.data.frame(res)
 if(lrt) x<-x[,c('baseMean','stat','pvalue','padj'),drop=FALSE]
 if(!lrt && identical(s$shrinkage,'ashr')) {
  sh<-lfcShrink(dds=dds,res=res,type='ashr',quiet=TRUE)
  x$lfc_shrunken<-sh$log2FoldChange;x$lfcSE_shrunken<-sh$lfcSE
 }
 x<-data.frame(gene=rownames(x),x,check.names=FALSE);file<-paste0(name,'.tsv.gz');writegz(x,file)
 index[[length(index)+1]]<<-data.frame(family=family,test_id=name,file=file,numerator=num,denominator=den,df=df)
 invisible(x)
}
pairs<-list(c('Adagrasib','Vehicle'),c('Combination','AntiPD1'),c('AntiPD1','Vehicle'),c('Combination','Adagrasib'),c('Combination','Vehicle'),c('Adagrasib','AntiPD1'))
if(isTRUE(j$run_hallmark)) {
 if(!requireNamespace('fgsea',quietly=TRUE))stop('fgsea not installed')
 paths<-fgsea::gmtPathways(j$gmt);paths<-lapply(paths[startsWith(names(paths),'HALLMARK_')],unique)
 if(!all(c('HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_INTERFERON_ALPHA_RESPONSE') %in% names(paths)))stop('Missing IFN Hallmarks')
}
for(pair in pairs) {
 nm<-paste(pair,collapse='_vs_');res<-results(dds,contrast=c('condition',pair[[1]],pair[[2]]),alpha=s$alpha)
 tbl<-save_res(res,nm,'wald_pairwise',pair[[1]],pair[[2]])
 if(pair[[2]]=='Vehicle') effects[[paste0(pair[[1]],'_vs_Vehicle_log2FC')]]<-res$log2FoldChange
 if(isTRUE(j$run_hallmark)) {
  keep<-is.finite(res$stat)&is.finite(res$pvalue)&res$baseMean>0
  ranks<-setNames(res$stat[keep],rownames(res)[keep]);ranks<-ranks[order(-ranks,names(ranks))]
  coverage<-data.frame(pathway=names(paths),original_size=lengths(paths),in_ranked_universe=vapply(paths,function(g)sum(g %in% names(ranks)),integer(1)))
  write.csv(coverage,file.path(out,paste0('fgsea_coverage_',nm,'.csv')),row.names=FALSE)
  fr<-as.data.frame(fgsea::fgseaMultilevel(pathways=paths,stats=ranks,minSize=s$hallmark_min_size,maxSize=s$hallmark_max_size,
        eps=0,scoreType='std',nPermSimple=10000,nproc=1))
  fr$leadingEdge<-vapply(fr$leadingEdge,paste,collapse=';',FUN.VALUE=character(1));writegz(fr,paste0('fgsea_',nm,'.tsv.gz'))
 }
}
w<-setNames(rep(0,length(resultsNames(dds))),resultsNames(dds))
for(z in c('AntiPD1','Adagrasib','Combination'))w[[paste0('condition_',z,'_vs_Vehicle')]]<-if(z=='Combination')1 else -1
res<-results(dds,contrast=as.numeric(w),alpha=s$alpha);save_res(res,'Interaction_difference_of_differences','wald_interaction','Combination+Vehicle','AntiPD1+Adagrasib')
effects$interaction_log2FC<-res$log2FoldChange;writegz(effects,'Vehicle_baseline_effect_profiles.tsv.gz')
omni<-nbinomLRT(dds,full=~condition,reduced=~1,quiet=TRUE)
save_res(results(omni,test='LRT',alpha=s$alpha),'LRT_any_condition','lrt_omnibus',df=3,lrt=TRUE)
fact<-dds;design(fact)<-~anti_pd1*adagrasib
inter<-nbinomLRT(fact,full=~anti_pd1*adagrasib,reduced=~anti_pd1+adagrasib,quiet=TRUE)
save_res(results(inter,test='LRT',alpha=s$alpha),'LRT_PD1_by_Adagrasib','lrt_interaction',df=1,lrt=TRUE)
saveRDS(omni,file.path(out,'DESeq2_omnibus_LRT.rds'));saveRDS(inter,file.path(out,'DESeq2_interaction_LRT.rds'))
write.csv(do.call(rbind,index),file.path(out,'result_index.csv'),row.names=FALSE)
jsonlite::write_json(list(model_id=j$model_id,population=j$population,status='complete',n_units=ncol(dds),n_genes=nrow(dds),
 hallmark_run=isTRUE(j$run_hallmark),primary_contrasts=j$primary_contrasts,
 caution='Tumor-assigned RNA; no surface PD-L1/MHC, direct target-engagement or cell-intrinsic causality established'),file.path(out,'complete_R.json'),auto_unbox=TRUE,pretty=TRUE)
