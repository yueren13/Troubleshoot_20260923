"""H&E expression maps in audited pixel coordinates; cohort-shared expression scales."""
from pathlib import Path
import math, warnings
import numpy as np
import pandas as pd
from .common import *
from .expression import open_project,sample_cache
from .plots import default_metrics,finish,gallery

def affine(a):
    a=np.asarray(a,float)
    if a.shape==(2,3):a=np.vstack([a,[0,0,1]])
    if a.shape!=(3,3) or not np.isfinite(a).all() or not np.allclose(a[2],[0,0,1]) or abs(np.linalg.det(a[:2,:2]))<1e-12:raise ValueError('Invalid affine')
    return a

def transform(points,a):
    p=np.asarray(points,float);a=affine(a)
    return p@a[:2,:2].T+a[:2,2]

def dicts(x,path='root'):
    if isinstance(x,dict):
        yield path,x
        for k,v in x.items():
            if isinstance(v,dict):yield from dicts(v,path+'.'+k)

def resolve_asset(row,override=None):
    ov=dict(override or {});mp=Path(ov.get('metadata') or row['prior_metadata'])
    meta=load_json(mp) if mp.is_file() else {}
    image=ov.get('image');kind=ov.get('image_kind','prior_crop');route=''
    if image is None:
        candidates=[]
        for _,node in dicts(meta):
            for key in ['scaled_crop_tiff','crop_tiff','image_crop','scaled_he']:
                if key in node and isinstance(node[key],str):
                    p=Path(node[key]);p=p if p.is_absolute() else mp.parent/p
                    if p.is_file():candidates.append(str(p.resolve()))
        candidates=list(dict.fromkeys(candidates))
        if len(candidates)>1:raise ValueError('Multiple registered image candidates; specify IMAGE_OVERRIDES')
        if candidates:image=candidates[0];kind='prior_crop'
        else:image=row.get('source_image');kind='fullres'
    if not image or not Path(image).is_file():raise FileNotFoundError('Registered H&E image not found. Supply image and audited affine override.')
    if 'image_xy_from_proseg_xy' in ov:
        A=affine(ov['image_xy_from_proseg_xy']);route='explicit image_xy_from_proseg_xy'
    else:
        matches=[]
        for path,node in dicts(meta):
            if {'x_transform','y_transform'}.issubset(node):matches.append((path,affine([node['x_transform'],node['y_transform']])))
        if not matches or any(not np.allclose(a,matches[0][1]) for _,a in matches):raise ValueError('Missing/conflicting prior affine. Supply an explicit audited image_xy_from_proseg_xy, never identity by default.')
        A=np.linalg.inv(matches[0][1]);route='inverse saved prior pixel-to-micron affine: '+matches[0][0]
        if kind=='fullres':
            crops=[]
            for path,node in dicts(meta):
                if all(k in node for k in ['source_crop_left','source_crop_top','source_crop_right','source_crop_bottom']):
                    l,t,r,b=[float(node[k]) for k in ['source_crop_left','source_crop_top','source_crop_right','source_crop_bottom']]
                    scale=node.get('resize_scale_source_to_mask')
                    if scale is not None:sx=sy=float(scale)
                    elif 'mask_shape' in node:
                        h,w=node['mask_shape'][:2];sx=w/(r-l);sy=h/(b-t)
                    else:continue
                    crops.append(affine([[sx,0,-sx*l],[0,sy,-sy*t]]))
            if not crops or any(not np.allclose(c,crops[0]) for c in crops):raise ValueError('Original SVS fallback requires explicit saved source-crop/resize mapping. Use the registered crop or an override.')
            A=np.linalg.inv(crops[0])@A;route+=' + inverse source crop/resize'
        elif kind!='prior_crop':raise ValueError('image_kind must be prior_crop/fullres without explicit affine')
    with RegionImage(image) as reader:w,h=reader.width,reader.height
    inv=np.linalg.inv(A);mppx=float(np.linalg.norm(inv[:2,0]));mppy=float(np.linalg.norm(inv[:2,1]))
    return dict(sample=row['sample'],image=str(Path(image).resolve()),kind=kind,width=w,height=h,
        px_from_um=A.tolist(),um_per_x_pixel=mppx,um_per_y_pixel=mppy,route=route,
        image_signature=signature(image),metadata=str(mp),metadata_sha=sha(mp) if mp.is_file() else None)

class RegionImage:
    def __init__(self,path):
        self.path=Path(path);self.slide=None;self.store=None;self.arr=None;self.kind=''
        if self.path.suffix.lower() in ['.svs','.ndpi','.mrxs']:
            try:import openslide
            except ImportError as e:raise ImportError('OpenSlide is needed for SVS; no full-slide RAM fallback') from e
            self.slide=openslide.OpenSlide(str(path));self.width,self.height=self.slide.dimensions;self.kind='slide'
        elif self.path.suffix.lower() in ['.tif','.tiff','.btf']:
            import tifffile
            with tifffile.TiffFile(path) as t:
                self.axes=t.series[0].axes;shape=t.series[0].shape
                tag=t.pages[0].tags.get('Orientation')
                if tag and int(tag.value)!=1:raise ValueError('Nonstandard TIFF orientation requires a verified transformed image')
            if self.axes in ['YXS','YXC']:self.height,self.width=shape[:2]
            elif self.axes in ['SYX','CYX']:self.height,self.width=shape[-2:]
            else:raise ValueError(f'Expected RGB image axes, found {self.axes}')
            try:self.arr=tifffile.memmap(path,mode='r');self.kind='memmap'
            except ValueError:
                try:
                    import zarr
                    self.store=tifffile.imread(path,series=0,aszarr=True);self.arr=zarr.open(self.store,mode='r');self.kind='zarr'
                except Exception as e:raise RuntimeError('Compressed TIFF needs compatible tifffile/imagecodecs/zarr; no huge full-image decode fallback') from e
        else:
            from PIL import Image
            self.arr=Image.open(path);self.width,self.height=self.arr.size;self.kind='PIL'
            if self.width*self.height>50_000_000:raise ValueError('Use tiled TIFF/SVS for large images')
    def __enter__(self):return self
    def __exit__(self,*args):
        if self.slide:self.slide.close()
        if self.store is not None and hasattr(self.store,'close'):self.store.close()
        if self.kind=='PIL':self.arr.close()
        if isinstance(self.arr,np.memmap):self.arr._mmap.close()
    def read(self,bounds=None,max_side=4500):
        from PIL import Image
        l,t,r,b=valid_bounds(bounds or [0,0,self.width,self.height],self.width,self.height)
        scale=min(1,max_side/max(r-l,b-t));ow=max(1,round((r-l)*scale));oh=max(1,round((b-t)*scale))
        if self.slide:
            level=self.slide.get_best_level_for_downsample(1/scale);ds=self.slide.level_downsamples[level]
            tile=self.slide.read_region((l,t),level,(math.ceil((r-l)/ds),math.ceil((b-t)/ds)))
            white=Image.new('RGBA',tile.size,(255,255,255,255));white.alpha_composite(tile)
            image=white.convert('RGB').transform((ow,oh),Image.Transform.EXTENT,(0,0,(r-l)/ds,(b-t)/ds),resample=Image.Resampling.BILINEAR)
        elif self.kind=='PIL':image=self.arr.crop((l,t,r,b)).convert('RGB').resize((ow,oh))
        else:
            step=max(1,int(1/scale))
            a=np.asarray(self.arr[t:b:step,l:r:step,:3]) if self.axes in ['YXS','YXC'] else np.moveaxis(np.asarray(self.arr[:3,t:b:step,l:r:step]),0,-1)
            if a.dtype!=np.uint8:raise ValueError('Supply an explicit uint8 RGB image; no automatic contrast normalization')
            image=Image.fromarray(a).resize((ow,oh),Image.Resampling.LANCZOS)
        return np.asarray(image),(l,t,r,b)

def valid_bounds(bounds,w,h):
    v=np.asarray(bounds,float)
    if v.shape!=(4,) or not np.isfinite(v).all():raise ValueError('ROI needs [left,top,right,bottom] pixels')
    l,t=np.floor(v[:2]).astype(int);r,b=np.ceil(v[2:]).astype(int)
    if not (0<=l<r<=w and 0<=t<b<=h):raise ValueError(f'Out-of-image/reversed ROI {bounds}; image={w,h}')
    return int(l),int(t),int(r),int(b)

def roi_bounds(roi,asset):
    if 'bounds_px' in roi:return valid_bounds(roi['bounds_px'],asset['width'],asset['height'])
    center=np.asarray(roi['center_fraction'],float);size=np.asarray(roi['size_um'],float)
    if size.ndim==0:size=np.repeat(size,2)
    if center.shape!=(2,) or size.shape!=(2,) or (center<0).any() or (center>1).any() or (size<=0).any():raise ValueError('Invalid fractional ROI')
    c=center*np.array([asset['width'],asset['height']]);dims=size/np.array([asset['um_per_x_pixel'],asset['um_per_y_pixel']])
    return valid_bounds([*(c-dims/2),*(c+dims/2)],asset['width'],asset['height'])

def shared_limits(root,spatial_root,metrics,quantile=.99,per_sample_cells=20000,seed=17):
    root,j,m=open_project(root);spatial=Path(spatial_root);rng=np.random.default_rng(seed);values={};s=load_json(spatial/'spatial_spec.json')['spatial_settings']
    for row in m.to_dict('records'):
        d=spatial/slug(row['sample']);cells=pd.read_csv(d/'tumor_expression_context.csv.gz')
        for metric in metrics:
            if metric not in cells:continue
            v=cells[metric].to_numpy(float);v=v[np.isfinite(v)]
            if len(v)>per_sample_cells:v=v[rng.choice(len(v),per_sample_cells,replace=False)]
            values.setdefault('cells|'+metric,[]).append(v)
        tiles=pd.read_csv(d/'tumor_only_tiles.csv.gz')
        for width in s['tile_sizes_um']:
            z=tiles.loc[(tiles.population==ALL_TUMOR)&(tiles.tile_width_um==width)&tiles.expression_eligible]
            for metric in metrics:
                if metric not in z:continue
                v=z[metric].to_numpy(float);v=v[np.isfinite(v)]
                values.setdefault(f'tiles{width:g}|'+metric,[]).append(v)
    limits={}
    for key,parts in values.items():
        v=np.concatenate(parts) if parts else np.array([])
        if len(v):limits[key]=dict(vmin=0.,vmax=1.0 if '|detected__' in key else (float(np.quantile(v,quantile)) if float(np.quantile(v,quantile))>0 else max(float(v.max()),1.0)),n_reference_values=len(v),quantile=quantile,
            note='Shared across samples/subtypes; reference is pooled tumor. Clipped values retained in numerical tables.')
    return limits

def _draw(root,row,asset,cells,tiles,reference,metric,mode,pop,bounds,limits,path,style):
    import matplotlib.pyplot as plt
    from matplotlib.collections import PolyCollection
    from matplotlib.colors import Normalize
    from matplotlib.lines import Line2D
    with RegionImage(asset['image']) as image:rgb,bounds=image.read(bounds,style['max_image_side'])
    l,t,r,b=bounds;ratio=(b-t)/(r-l);fig,ax=plt.subplots(figsize=(13,min(12,max(5,10*ratio))))
    ax.imshow(rgb,extent=(l,r,b,t),aspect='equal',interpolation='none')
    a=asset['px_from_um'];key=('cells' if mode=='cells' else f'tiles{style["tile_size_um"]:g}')+'|'+metric
    limit=limits.get(key);norm=Normalize(limit['vmin'],limit['vmax'],clip=True) if limit else Normalize(0,1)
    z=cells if pop==ALL_TUMOR else cells.loc[cells.population==pop]
    n_display=0
    if mode=='cells' and metric in z:
        xy=transform(z[['x_um','y_um']].to_numpy(),a);v=z[metric].to_numpy(float)
        inroi=(xy[:,0]>=l)&(xy[:,0]<r)&(xy[:,1]>=t)&(xy[:,1]<b);good=inroi&np.isfinite(v)
        ax.scatter(xy[inroi&~np.isfinite(v),0],xy[inroi&~np.isfinite(v),1],s=style['point_size'],color='#A0A0A0',alpha=.3,lw=0)
        ax.scatter(xy[good,0],xy[good,1],c=v[good],norm=norm,cmap=style['cmap'],s=style['point_size'],alpha=style['expression_alpha'],linewidths=0,rasterized=True)
        n_display=int(good.sum())
    elif mode=='tiles':
        z=tiles.loc[(tiles.population==pop)&(tiles.tile_width_um==style['tile_size_um'])]
        polygons=[];vals=[]
        for ix,q in z.iterrows():
            px=transform([[q.x0_um,q.y0_um],[q.x0_um+q.tile_width_um,q.y0_um],[q.x0_um+q.tile_width_um,q.y0_um+q.tile_width_um],[q.x0_um,q.y0_um+q.tile_width_um]],a)
            if px[:,0].max()<l or px[:,0].min()>r or px[:,1].max()<t or px[:,1].min()>b:continue
            value=q.get(metric,np.nan)
            if q.expression_eligible and np.isfinite(value):polygons.append(px);vals.append(value)
        if polygons:
            coll=PolyCollection(polygons,array=np.asarray(vals),cmap=style['cmap'],norm=norm,alpha=style['tile_alpha'],edgecolors='none',rasterized=True);ax.add_collection(coll)
        n_display=len(vals)
    else:
        if mode!='cells':raise ValueError('Mode must be cells or tiles')
    # Coordinates of immune context are separate; they never contribute to the expression score.
    handles=[];colors={'T cell 1':'#D43E88','T cell 2':'#ED9F9C','Macrophage 1':'#643F95','Macrophage 2':'#7470AE','Dendritic cell':'#3C76AF'}
    for celltype in style['immune_overlay_types']:
        if celltype not in colors:raise ValueError('Provide a known exact broad immune type for this first-pass overlay')
        q=reference.loc[reference.population==celltype];xy=transform(q[['x_um','y_um']].to_numpy(),a)
        good=(xy[:,0]>=l)&(xy[:,0]<r)&(xy[:,1]>=t)&(xy[:,1]<b)
        ax.scatter(xy[good,0],xy[good,1],s=style['immune_point_size'],facecolors='none',edgecolors=colors[celltype],linewidths=.45,alpha=.85,rasterized=True)
        handles.append(Line2D([0],[0],marker='o',linestyle='none',markerfacecolor='none',markeredgecolor=colors[celltype],label=celltype))
    ax.set(xlim=(l,r),ylim=(b,t),aspect='equal');ax.axis('off')
    ax.set_title(f"{row['sample']} | {DISPLAY[row['condition']]} | {pop}\n{metric} | {mode}; tumor-assigned RNA",fontsize=12)
    if limit and n_display:
        from matplotlib.cm import ScalarMappable
        fig.colorbar(ScalarMappable(norm=norm,cmap=style['cmap']),ax=ax,fraction=.03,pad=.02,extend='max',label='Cohort-shared expression scale')
    else:ax.text(.02,.02,'No eligible measured expression in this view',transform=ax.transAxes,color='black',bbox=dict(facecolor='white',alpha=.9))
    physical=(r-l)*asset['um_per_x_pixel'];bar=10**np.floor(np.log10(max(physical*.12,1)))
    pxlength=bar/asset['um_per_x_pixel'];x=l+.04*(r-l);y=b-.05*(b-t)
    ax.plot([x,x+pxlength],[y,y],color='white',lw=5);ax.plot([x,x+pxlength],[y,y],color='black',lw=2.5)
    ax.text(x,y-.02*(b-t),f'{bar:g} µm',fontsize=9,bbox=dict(facecolor='white',alpha=.75,edgecolor='none'))
    if handles:ax.legend(handles=handles,bbox_to_anchor=(.5,-.025),loc='upper center',ncol=min(3,len(handles)),frameon=False,fontsize=8)
    finish(fig,path,style['dpi'])
    return dict(n_expression_objects=n_display,limits=limit,bounds_px=bounds,mode=mode,metric=metric,population=pop)

def run_maps(root,spatial_root,metrics=None,populations=None,requests=None,overrides=None,settings=None):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    root,j,m=open_project(root);spatial=Path(spatial_root)
    style=dict(dpi=300,max_image_side=4500,point_size=.8,immune_point_size=3.,expression_alpha=.85,tile_alpha=.65,
               cmap='viridis',tile_size_um=100.,modes=['cells','tiles'],auto_rois=2,auto_roi_size_um=500.,
               immune_overlay_types=['T cell 1','T cell 2'],min_in_bounds=.98,scale_quantile=.99)
    style.update(settings or {});metrics=metrics or default_metrics(root,True);pops=populations or [ALL_TUMOR];requests=requests or [];overrides=overrides or {}
    if set(pops)-set([ALL_TUMOR]+TUMOR):raise ValueError('Unknown population map selection')
    limits=shared_limits(root,spatial,metrics,style['scale_quantile'])
    spec=dict(spatial_spec=load_json(spatial/'spatial_spec.json'),settings=style,metrics=metrics,populations=pops,requests=requests,overrides=overrides,helper_sha=sha(__file__))
    out=spatial/'HE_maps'/digest(spec)[:12];out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'map_spec.json');save_json(limits,out/'cohort_shared_color_scales.json')
    failures=[];reports=[]
    for row in m.to_dict('records'):
        sample=row['sample'];dest=out/slug(sample);dest.mkdir(exist_ok=True)
        try:
            asset=resolve_asset(row,overrides.get(sample));save_json(asset,dest/'resolved_image_asset.json')
            cells=pd.read_csv(spatial/slug(sample)/'tumor_expression_context.csv.gz',dtype={'source_cell_id':str})
            tiles=pd.read_csv(spatial/slug(sample)/'tumor_only_tiles.csv.gz')
            ref=pd.read_csv(sample_cache(root,sample)/'full_reference_coordinates.csv.gz')
            xy=transform(cells[['x_um','y_um']].to_numpy(),asset['px_from_um'])
            inside=(xy[:,0]>=0)&(xy[:,0]<asset['width'])&(xy[:,1]>=0)&(xy[:,1]<asset['height'])
            report=dict(sample=sample,fraction_tumor_in_bounds=float(inside.mean()) if len(inside) else None,n_tumor=len(cells),asset=asset)
            save_json(report,dest/'alignment_check.json')
            if len(inside) and inside.mean()<style['min_in_bounds']:raise ValueError('Insufficient in-bounds tumor coordinates; inspect affine/image override before plotting')
            rois=[r for r in requests if r['sample']==sample]
            if not rois and style['auto_rois'] and len(cells):
                # Reproducible populated-region choices, not histology/niche discovery.
                dims=np.array([style['auto_roi_size_um']/asset['um_per_x_pixel'],style['auto_roi_size_um']/asset['um_per_y_pixel']])
                grid=np.floor(xy/np.maximum(dims*.5,1)).astype(int);unique,count=np.unique(grid,axis=0,return_counts=True);centers=[]
                for i in np.argsort(-count,kind='stable'):
                    center=(unique[i]+.5)*dims*.5;center=np.minimum(np.maximum(center,dims/2),np.array([asset['width'],asset['height']])-dims/2)
                    if (dims>np.array([asset['width'],asset['height']])).any():break
                    if any(np.linalg.norm((center-c)/dims)<.9 for c in centers):continue
                    centers.append(center);rois.append(dict(sample=sample,name=f'auto_tumor_{len(centers)}',bounds_px=[*(center-dims/2),*(center+dims/2)]))
                    if len(rois)>=style['auto_rois']:break
            whole=dict(sample=sample,name='whole',bounds_px=[0,0,asset['width'],asset['height']])
            for roi in [whole]+rois:
                b=roi_bounds(roi,asset);name=slug(roi['name'])
                with RegionImage(asset['image']) as im:rgb,bb=im.read(b,style['max_image_side'])
                fig,ax=plt.subplots(figsize=(12,max(5,min(12,10*(b[3]-b[1])/(b[2]-b[0])))))
                ax.imshow(rgb,extent=(b[0],b[2],b[3],b[1]),aspect='equal');ax.set_title(sample+' | H&E-only coordinate view | '+name)
                ax.set_xlabel('Image x / column pixels');ax.set_ylabel('Image y / row pixels')
                if name=='whole':
                    for r in rois:
                        l,t,rr,bb=roi_bounds(r,asset);ax.add_patch(Rectangle((l,t),rr-l,bb-t,fill=False,color='red',lw=.8));ax.text(l,t,r['name'],fontsize=8)
                finish(fig,dest/(name+'_HE_only.png'),style['dpi']);save_json(roi,dest/(name+'_ROI.json'))
                for pop in pops:
                    for mode in style['modes']:
                        for metric in roi.get('metrics',metrics):
                            path=dest/name/slug(pop)/(mode+'_'+slug(metric)+'.png');path.parent.mkdir(parents=True,exist_ok=True)
                            detail=_draw(root,row,asset,cells,tiles,ref,metric,mode,pop,b,limits,path,style)
                            save_json(detail,path.with_suffix('.json'))
            reports.append(dict(sample=sample,status='complete',output=str(dest)))
        except Exception as e:
            import traceback
            fail=dict(sample=sample,error=f'{type(e).__name__}: {e}',traceback=traceback.format_exc());failures.append(fail);save_json(fail,dest/'failure.json');print('Map failure:',sample,e)
    save_csv(pd.DataFrame(reports),out/'map_summary.csv');save_json(failures,out/'map_failures.json');gallery(out)
    return out,pd.DataFrame(reports)
