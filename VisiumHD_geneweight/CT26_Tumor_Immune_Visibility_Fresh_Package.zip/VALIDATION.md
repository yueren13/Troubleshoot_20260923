# Validation — CT26 tumor immune-visibility notebooks

## Executed synthetic checks

- PASS: Program coverage uses common measurable genes; canonical membership retained and spatial overlaps explicitly removed
- PASS: Actual HDF5 CSR streaming, shuffled ID joins and duplicate-feature count conservation verified against dense truth
- PASS: Completed per-sample raw caches reused without rewriting or rescanning
- PASS: Tumor-only scores match formula; missing source genes remain NA, not zero
- PASS: Exact pooled tumor pseudobulk sums; absent subtype not tested; unavailable genes excluded from DE universe
- PASS: Exact tumor–T distances/radius counts agree with brute force; no-target distances NA; self exclusion correct
- PASS: Distance-band edge convention and missing-target handling verified
- PASS: Tile signal is pooled tumor-only counts normalized by tumor-only whole-library totals, never mixed immune counts
- PASS: Spatial reuse, exact independent-unit tests and 3-vs-3 P resolution exercised
- PASS: Axis-exchanging affine round trip and bounded uncompressed RGB TIFF reads tested
- PASS: Expression/proximity figures and 12-sample cell/tile H&E galleries rendered from real TIFF fixtures
- PASS: All original synthetic raw H5AD/annotation/image/registration files retained byte-for-byte
- PASS: A 300-dpi synthetic overlay produced for visual inspection; delivered defaults use 300 dpi
- PASS: Model dashboard/target tables tested with explicitly synthetic R-format results; missing genes masked and named effects/NES displayed

The fixture contains 12 physically separate synthetic HDF5 count sources, four
conditions, distinct biological-unit IDs, shuffled annotation rows, duplicated
B2m feature symbols, a deliberately missing H2-D1 source feature, a missing tumor
subtype in one sample, and missing T1 cells in another sample. It uses actual
h5py/SciPy sparse source reads and actual uncompressed TIFF images with a saved
axis-exchanging affine. The GMT fixture is artificial and is not MSigDB content.

Most figures were rendered at 75 dpi to exercise all twelve samples efficiently.
A separate 300-dpi synthetic H&E overlay was rendered and visually inspected;
its immune legend and expression color bar occupy separate regions. Detailed
model/IFN dashboard branches were additionally tested with clearly synthetic
R-format result tables. No result in these checks is a CT26 biological observation.

## Not executed in the authoring runtime

- Reference R DESeq2/ashr/fgsea fitting. R/Rscript was not installed. The backend
  was reviewed and received a textual delimiter check, not an actual R parse/fit.
  09B includes a small synthetic backend smoke test to run on the user's server.
- Real CT26 raw data, images, genotype records and treatment results.
- The source auto-resolver importing the server's original ct26_common module.
  The direct explicit-manifest route was used by the synthetic tests.
- Actual Parquet/GeoParquet I/O (pyarrow was unavailable). Tests used the explicitly
  supported CSV metadata and feature-map pathway, not fake Parquet files.
- OpenSlide SVS and compressed-TIFF/Zarr region reads; only uncompressed TIFF
  memory-mapped bounded reads were executed locally.

## Package checks

All four notebook schemas and every Python code cell validate and compile.
All Python package modules compile. Notebook outputs/execution counts are empty.
Both real count sums and small source-panel extraction were compared with dense
references. KD-tree distances/radius counts and tile pooling were independently
compared with brute-force calculations. Original synthetic inputs remained
byte-identical. The final ZIP was integrity checked.

## Optional local test

From the extracted folder:

```bash
CT26_VISIBILITY_TEST_ROOT=/your/scratch/visibility_tests \
python tests/test_tumor_visibility.py
```

This generates synthetic data/images under the selected test directory. Do not
point it at a real source-data directory. It does not invoke R or modify original
pipeline inputs.
