"""Synthetic CPU integration tests. No server CT26 data or actual R fits are used."""
from pathlib import Path
import tempfile,os,sys,json,hashlib
import numpy as np,pandas as pd,h5py,scipy.sparse as sp
import matplotlib
matplotlib.use('Agg')
from scipy.spatial.distance import cdist
import tifffile
PACKAGE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(PACKAGE))
from tumor_visibility import common as tv,expression as tx,spatial as ts,models as tm,plots as tp,images as ti

TESTROOT=Path(os.environ.get('CT26_VISIBILITY_TEST_ROOT',tempfile.mkdtemp(prefix='ct26_visibility_')));TESTROOT.mkdir(parents=True,exist_ok=True)
checks=[]
def check(text):checks.append(text);print('PASS:',text,flush=True)
def vector(group,key,a):
 a=np.asarray(a)
 if a.dtype.kind in 'OU':e=group.create_dataset(key,data=a.astype(object),dtype=h5py.string_dtype())
 else:e=group.create_dataset(key,data=a)
 return e

def frame(group,df):
 group.attrs.update({'encoding-type':'dataframe','encoding-version':'0.2.0','_index':'_index'})
 vector(group,'_index',df.index.astype(str))
 for k in df:vector(group,k,df[k].to_numpy())

rng=np.random.default_rng(42);definition=tv.load_json(PACKAGE/'programs_proposed_mouse.json')
basegenes=list(dict.fromkeys(definition['individual_genes']+[g for x in definition['panels'].values() for g in x]+[f'SyntheticG{i:03d}' for i in range(100)]))
manifest=[];truth={};sample_names=[f'SYN_{i:02d}' for i in range(12)]
for i,sample in enumerate(sample_names):
 d=TESTROOT/sample;d.mkdir(exist_ok=True)
 labels=sum(([t]*12 for t in tv.TUMOR),[])+['T cell 1']*12+['T cell 2']*9+['Macrophage 1']*8+['Macrophage 2']*7+['Dendritic cell']*6+['Fibroblast cell 1']*6+['']*6
 if i==0:labels=[x for x in labels if x!='Tumor cell 5'] # true missing subtype, not a zero pseudoreplicate
 if i==1:labels=[x for x in labels if x!='T cell 1']
 n=len(labels);pixels=rng.uniform([10,10],[990,790],(n,2))
 # Actual affine includes axis exchange and translations; generated raw coordinates are physical µm.
 A=np.array([[0,.3,100],[.3,0,200],[0,0,1]])
 xy=ti.transform(pixels,A)
 syms=[g for g in basegenes if not(i==0 and g=='H2-D1')]+['B2m'] # deliberate missing gene + duplicate symbol
 C=rng.poisson(2,(n,len(syms))).astype(np.int64)
 for g in ['Cd274','Tap1','Cxcl9']:
  if g in syms:C[:,syms.index(g)]*=1+(i//3)
 C[rng.random(C.shape)<.35]=0
 ids=[f'{sample}_c{q:04d}' for q in range(n)];obs=pd.DataFrame({'centroid_x':xy[:,0],'centroid_y':xy[:,1]},index=ids)
 var=pd.DataFrame({'gene_symbol':syms},index=[f'f{q:04d}' for q in range(len(syms))])
 raw=d/'raw.h5ad'
 with h5py.File(raw,'w') as f:
  frame(f.create_group('obs'),obs);frame(f.create_group('var'),var)
  x=sp.csr_matrix(C);node=f.create_group('X');node.attrs.update({'encoding-type':'csr_matrix','shape':x.shape})
  for key,arr in [('data',x.data),('indices',x.indices),('indptr',x.indptr)]:node.create_dataset(key,data=arr)
 side=pd.DataFrame({'source_cell_id':ids,'sample':sample,'preliminary_annotation':labels,'is_in_scvi_graph':np.array(labels)!='',
       '_proseg_x_um':xy[:,0],'_proseg_y_um':xy[:,1],'raw_total_counts':C.sum(axis=1),'total_counts':C.sum(axis=1),
       'n_genes_by_counts':(C>0).sum(axis=1),'pct_counts_mt':2.})
 side=side.sample(frac=1,random_state=17).reset_index(drop=True);sidepath=d/'annotation.csv';side.to_csv(sidepath,index=False)
 image=d/'crop.tiff';RGB=np.full((800,1000,3),245,np.uint8)
 for x0,y0 in pixels.astype(int):RGB[max(0,y0-2):y0+3,max(0,x0-2):x0+3]=[160,120,160]
 tifffile.imwrite(image,RGB,photometric='rgb')
 meta=d/'prior.json';meta.write_text(json.dumps(dict(x_transform=A[0].tolist(),y_transform=A[1].tolist(),scaled_crop_tiff=str(image),mask_shape=[800,1000])))
 manifest.append(dict(sample=sample,unit=f'mouse{i:02d}',condition=tv.CONDITIONS[i//3],raw_h5ad=str(raw),matrix_key='X',
       annotation_file=str(sidepath),gene_table='',gene_symbol_column='gene_symbol',label_column=tv.LABEL,
       cell_id_column='source_cell_id',sample_column='sample',total_counts_column='raw_total_counts',
       prior_metadata=str(meta),source_image=str(image),coordinates_to_um=1.))
 truth[sample]=dict(C=C,syms=syms,ids=ids,labels=np.array(labels),xy=xy,A=A,paths=[raw,sidepath,image,meta])
manifest=pd.DataFrame(manifest)
source_hashes={p:tv.sha(p) for t in truth.values() for p in t['paths']}
# A synthetic GMT for coverage/overlap tests only; it is NOT MSigDB.
gmt=TESTROOT/'synthetic_test_only.gmt'
gmt.write_text('HALLMARK_INTERFERON_GAMMA_RESPONSE\tSYNTHETIC_NOT_MSIGDB\t'+ '\t'.join(['Cd274','Tap1','B2m','Stat1','Stat2','Irf1','Irf7','Irf9','Isg15','Ifit1','Ifit2','Ifit3'])+'\n'+
 'HALLMARK_INTERFERON_ALPHA_RESPONSE\tSYNTHETIC_NOT_MSIGDB\t'+'\t'.join(['Psmb8','Cd274','Isg15','Isg20','Ifit1','Ifit2','Ifit3','Mx1','Oas1a','Oas2','Rsad2','Usp18'])+'\n')
root=tx.create_project(manifest,TESTROOT/'outputs',PACKAGE/'programs_proposed_mouse.json',settings={'chunk_cells':17},hallmark_gmt=gmt,hallmark_release='SYNTHETIC fixture, not actual MSigDB')
_,j,_=tx.open_project(root)
assert not j['scalar_genes']['H2-D1']
for name,program in j['programs'].items():
 if name.endswith('_spatial_no_AP_PDL1_CXCL'):
  assert not set(program['requested_genes'])&set(definition['spatial_ifn_exclusion_genes'])
assert 'Cd274' in j['programs']['HALLMARK_INTERFERON_GAMMA_RESPONSE']['requested_genes']
check('Program coverage uses common measurable genes; canonical membership retained and spatial overlaps explicitly removed')
summary=tx.extract(root);assert len(summary)==12
for sample,t in truth.items():
 d=tx.sample_cache(root,sample)
 with np.load(d/'allgene_compartment_sums.npz',allow_pickle=False) as z:
  for pop in tv.TUMOR:
   a=z['populations'].tolist().index(pop);mask=t['labels']==pop
   for g in ['B2m','Cd274','Tap1']:
    b=z['genes'].tolist().index(g);cols=[i for i,x in enumerate(t['syms']) if x==g]
    assert z['counts'][a,b]==t['C'][mask][:,cols].sum()
 with h5py.File(d/'tumor_panel.h5') as h:
  ids=h['cell_id'].asstr()[...];gix=h['gene'].asstr()[...].tolist().index('B2m');lookup={v:i for i,v in enumerate(t['ids'])}
  assert np.array_equal(h['counts'][:,gix],t['C'][[lookup[x] for x in ids]][:,[i for i,g in enumerate(t['syms']) if g=='B2m']].sum(axis=1))
check('Actual HDF5 CSR streaming, shuffled ID joins and duplicate-feature count conservation verified against dense truth')
cache_files=list((root/'sample_cache').glob('*/tumor_panel.h5'));mt={p:p.stat().st_mtime_ns for p in cache_files}
tx.extract(root);assert all(p.stat().st_mtime_ns==v for p,v in mt.items())
check('Completed per-sample raw caches reused without rewriting or rescanning')
scores=tx.compute_cell_scores(root)
sample=sample_names[3];d=tx.sample_cache(root,sample);cell=pd.read_csv(d/'tumor_scores.csv.gz')
assert cell['gene_log1p__H2-D1'].isna().all()
with h5py.File(d/'tumor_panel.h5') as h:
 cols=[h['gene'].asstr()[...].tolist().index(g) for g in j['programs']['AP_MHCI_core']['measured_genes']]
 expected=np.log1p(h['counts'][...][:,cols]*10000/h['all_source_total_counts'][...][:,None]).mean(axis=1)
 np.testing.assert_allclose(cell['score__AP_MHCI_core'],expected)
check('Tumor-only scores match formula; missing source genes remain NA, not zero')
inputroot,design=tm.prepare(root,{'min_cells':5,'min_library_counts':50,'min_gene_count':1,'min_gene_units':1})
assert design.set_index('population').loc['All tumor cell','status']=='ready'
assert design.set_index('population').loc['Tumor cell 5','status']=='not_testable'
with np.load(inputroot/'All_tumor_cell'/'unfiltered_unit_counts.npz') as z:
 pooled=z['counts'];ids=z['genes'].tolist()
 leaf=[]
 for pop in tv.TUMOR:
  with np.load(inputroot/tv.slug(pop)/'unfiltered_unit_counts.npz') as zz:leaf.append(zz['counts'])
 np.testing.assert_array_equal(pooled,np.sum(leaf,axis=0))
assert not pd.read_csv(inputroot/'All_tumor_cell'/'gene_filter.csv').set_index('gene').loc['H2-D1','tested']
check('Exact pooled tumor pseudobulk sums; absent subtype not tested; unavailable genes excluded from DE universe')
# Every sample has full count conservation with positive tumors; small cutoffs only for synthetic spatial coverage.
settings=dict(min_cells_per_band=1,min_cells_per_tile=1,min_counts_per_tile=1,min_tiles_per_correlation=3,chunk_cells=19,workers=1)
sroot=ts.run(root,settings)
sample=sample_names[1];context=pd.read_csv(sroot/sample/'tumor_expression_context.csv.gz')
assert context['distance_um__T cell 1'].isna().all()
sample=sample_names[3];context=pd.read_csv(sroot/sample/'tumor_expression_context.csv.gz')
ref=pd.read_csv(tx.sample_cache(root,sample)/'full_reference_coordinates.csv.gz')
C=context[['x_um','y_um']].to_numpy();T=ref.loc[ref.population.isin(tv.T_TYPES),['x_um','y_um']].to_numpy()
np.testing.assert_allclose(context['distance_um__All T cell'],cdist(C,T).min(axis=1))
for r in [25,50]:np.testing.assert_array_equal(context[f'neighbors_r{r}um__All T cell'],(cdist(C,T)<=r).sum(axis=1))
allxy=ref[['x_um','y_um']].to_numpy();nall=(cdist(C,allxy)<=50).sum(axis=1)-1;ntum=(cdist(C,C)<=50).sum(axis=1)-1
np.testing.assert_array_equal(context.full_segmented_neighbors_for_tumor_rich,nall)
expected=np.divide(ntum,nall,out=np.full(len(nall),np.nan),where=nall>0)
np.testing.assert_allclose(context.annotated_tumor_neighbor_fraction,expected,equal_nan=True)
check('Exact tumor–T distances/radius counts agree with brute force; no-target distances NA; self exclusion correct')
b,names=ts.bands([0,25,25.001,50,100,101,np.nan],[25,50,100])
assert b.tolist()==['0-25','0-25','25-50','25-50','50-100','>100',None]
check('Distance-band edge convention and missing-target handling verified')
tiles=pd.read_csv(sroot/sample/'tumor_only_tiles.csv.gz');width=50.;r=tiles.loc[(tiles.population==tv.ALL_TUMOR)&(tiles.tile_width_um==width)].iloc[0]
cm=pd.read_csv(tx.sample_cache(root,sample)/'tumor_cells.csv.gz');k=(np.floor(cm.x_um/width)==r.ix)&(np.floor(cm.y_um/width)==r.iy)
with h5py.File(tx.sample_cache(root,sample)/'tumor_panel.h5') as h:
 gix=h['gene'].asstr()[...].tolist().index('Cd274');counts=h['counts'][...][k.to_numpy(),gix].sum();den=h['all_source_total_counts'][...][k.to_numpy()].sum()
 assert r.tumor_library_counts==den and r.n_tumor_cells==k.sum()
 np.testing.assert_allclose(r['gene_log1p__Cd274'],np.log1p(10000*counts/den))
 np.testing.assert_allclose(r['detected__Cd274'],(h['counts'][...][k.to_numpy(),gix]>0).mean())
check('Tile signal is pooled tumor-only counts normalized by tumor-only whole-library totals, never mixed immune counts')
spdone=list(sroot.glob('*/complete.json'));before={p:p.stat().st_mtime_ns for p in spdone}
ts.run(root,settings);assert all(p.stat().st_mtime_ns==v for p,v in before.items())
assert ts.exact_unit_test([1,2,3],[4,5,6])['pvalue']==.1
unit=ts.compare_near_far(root,sroot,min_units=3)
assert not unit.empty
check('Spatial reuse, exact independent-unit tests and 3-vs-3 P resolution exercised')
# Real TIFF/affine + synthetic plotting; no server imaging or R model fixtures claimed.
a=ti.resolve_asset(manifest.iloc[3].to_dict());mapped=ti.transform(context[['x_um','y_um']],a['px_from_um'])
assert (mapped[:,0]>=0).all() and (mapped[:,0]<1000).all()
np.testing.assert_allclose(ti.transform(mapped,np.linalg.inv(a['px_from_um'])),context[['x_um','y_um']])
with ti.RegionImage(a['image']) as im:
 image,bounds=im.read([0,0,1000,800],200);assert image.shape[:2]==(160,200)
check('Axis-exchanging affine round trip and bounded uncompressed RGB TIFF reads tested')
fig1=tp.expression_dashboard(root,populations=[tv.ALL_TUMOR],metrics=['score__AP_MHCI_core','gene_log1p__Cd274'],dpi=75)
fig2=tp.spatial_profiles(root,sroot,populations=[tv.ALL_TUMOR],metrics=['score__AP_MHCI_core','gene_log1p__Cd274'],dpi=75)
# Map only small selected ROI/whole for two genes but all 12 sample files, no statistical models needed.
maproot,maptable=ti.run_maps(root,sroot,metrics=['gene_log1p__Cd274'],populations=[tv.ALL_TUMOR],
 settings={'dpi':75,'max_image_side':600,'auto_rois':0,'immune_point_size':2,'point_size':4,'modes':['cells','tiles'],'tile_size_um':100.})
assert len(maptable)==12 and tv.load_json(maproot/'map_failures.json')==[]
check('Expression/proximity figures and 12-sample cell/tile H&E galleries rendered from real TIFF fixtures')
for p,h in source_hashes.items():assert tv.sha(p)==h
check('All original synthetic raw H5AD/annotation/image/registration files retained byte-for-byte')
# actual 300-dpi sample one-panel rendering (not a user biological result).
style=dict(dpi=300,max_image_side=1000,point_size=5,immune_point_size=5,expression_alpha=.85,tile_alpha=.65,cmap='viridis',tile_size_um=100,immune_overlay_types=tv.T_TYPES)
limits=ti.shared_limits(root,sroot,['gene_log1p__Cd274'])
ti._draw(root,manifest.iloc[3].to_dict(),a,context,tiles,ref,'gene_log1p__Cd274','cells',tv.ALL_TUMOR,[0,0,1000,800],limits,TESTROOT/'SYNTHETIC_H&E_inspection_300dpi.png',style)
check('A 300-dpi synthetic overlay produced for visual inspection; delivered defaults use 300 dpi')
report=dict(passed=checks,n_checks=len(checks),project=str(root),spatial=str(sroot),
 notes=['Synthetic dataset only, 12 independent-source fixtures.','Real HDF5 CSR and TIFF I/O tested; CSV annotations/gene maps used because pyarrow absent.',
        'R DESeq2/ashr/fgsea not executed here; on-server synthetic smoke test included.',
        'Source auto-resolver calling original ct26_common and real Parquet/SVS compressed TIFF not exercised.',
        'Most integration plots rendered at 75 dpi for test speed, one inspection at 300 dpi.'])
save=TESTROOT/'validation_report.json';save.write_text(json.dumps(report,indent=2))
print('ALL CHECKS PASSED:',len(checks));print('REPORT:',save)
