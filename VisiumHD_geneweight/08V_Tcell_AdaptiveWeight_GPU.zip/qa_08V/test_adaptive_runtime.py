"""Runtime wiring tests. GPU computation is mocked; no CUDA claim is made."""
from pathlib import Path
from collections import OrderedDict
import contextlib
import json
import os
import subprocess
import tempfile
import types
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
import tcell_adaptive_runtime as r
import tcell_adaptive_math as maths
import tcell_adaptive_workflow as workflow
import tcell_weighted_workflow as base
from synthetic_fixtures import make_fixture, write_embedding


STUB_WORKER = '''import argparse,json,os,sys
from pathlib import Path
p=argparse.ArgumentParser()
for name in ('plan-json','branch','output-dir','gpu-settings-json','adaptive-settings-json'):p.add_argument('--'+name,required=True)
p.add_argument('--no-resume',action='store_true')
a=p.parse_args(); plan=json.loads(Path(a.plan_json).read_text()); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
if plan['branches'][a.branch].get('fail'):sys.exit(3)
if plan['branches'][a.branch].get('kind')=='adaptive':
 assert (out.parent/'broad_ratio'/'result.json').is_file(),'adaptive launched before matched baseline'
model=out/'synthetic_only.h5ad'; model.write_text('synthetic supervisor fixture, not a scientific result')
(out/'visible_device.txt').write_text(os.environ.get('CUDA_VISIBLE_DEVICES','absent'))
(out/'result.json').write_text(json.dumps({'embedding_path':str(model),'status':'complete'}))
'''


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_settings_bounds_unknown_and_math_api(self):
        for bad in ({"max_updates": 0}, {"max_updates": 4}, {"damping": 1.1}, {"penalty_max": 0.5}, {"guide_reward": True}):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                r.validate_adaptive_settings(bad)
        rows = maths.select_probe_rows(np.array(["a"] * 4 + ["b"] * 4), max_probe_per_sample=3, max_probe_total=6, seed=17)
        self.assertEqual(len(rows), 6)
        self.assertNotEqual(getattr(maths, "VERSION", "unknown"), "unknown")

    def test_failed_cuda_probe_stops_before_rapids(self):
        with patch.object(r.subprocess, "run", return_value=subprocess.CompletedProcess([], 1, "no GPU", "error")), patch.object(r.base, "preflight_gpu") as rapids:
            with self.assertRaises(RuntimeError):
                r.preflight(self.root, self.root / "logs")
            rapids.assert_not_called()
        self.assertEqual((self.root / "logs" / "cuda_probe_stdout.txt").read_text(), "no GPU")

    def test_cuda_timeout_writes_diagnostic(self):
        with patch.object(r.subprocess, "run", side_effect=subprocess.TimeoutExpired("probe", 45)):
            with self.assertRaises(RuntimeError):
                r.preflight(self.root, self.root / "timeout")
        self.assertEqual(json.loads((self.root / "timeout" / "cuda_probe_failure.json").read_text())["status"], "timeout")

    def test_supervisor_rejects_unsuccessful_runtime(self):
        plan = {"plan_dir": str(self.root), "plan_id": "synthetic", "branches": {}}
        for runtime in ({"ok": True, "visible_device_count": 0}, {"ok": False, "visible_device_count": 2}, {"visible_device_count": 2}, {"ok": True, "visible_device_count": True}):
            with self.subTest(runtime=runtime), patch.object(r.subprocess, "Popen") as popen, self.assertRaises(ValueError):
                r.launch_experiment(plan, self.root, runtime)
            popen.assert_not_called()

    def test_visibility_maps_logical_indices_to_inherited_tokens(self):
        with patch.dict(os.environ, {"CUDA_VISIBLE_DEVICES": "GPU-uuid-A,MIG-uuid-B"}):
            self.assertEqual(base._process_env(0)["CUDA_VISIBLE_DEVICES"], "GPU-uuid-A")
            self.assertEqual(base._process_env(1)["CUDA_VISIBLE_DEVICES"], "MIG-uuid-B")
            with self.assertRaises(ValueError):
                base._process_env(2)

    def test_supervisor_dependencies_and_visible_gpu_mapping(self):
        helper = self.root / "helper"
        helper.mkdir()
        (helper / "tcell_adaptive_runtime.py").write_text(STUB_WORKER)
        branches = OrderedDict([(n, {"kind": k}) for n, k in [("broad_adaptive", "adaptive"), ("selected", "fixed"), ("broad_ratio", "fixed")]])
        plan = {"plan_dir": str(self.root), "plan_id": "supervisor", "branches": branches}
        with patch.dict(os.environ, {"CUDA_VISIBLE_DEVICES": "GPU-A,GPU-B"}):
            completed, out = r.launch_experiment(plan, helper, {"ok": True, "visible_device_count": 2}, max_minutes=1)
        self.assertEqual(set(completed), set(branches))
        tokens = {(out / n / "visible_device.txt").read_text() for n in branches}
        self.assertEqual(tokens, {"GPU-A", "GPU-B"})

    def test_baseline_failure_prevents_adaptive_launch(self):
        helper = self.root / "helper"
        helper.mkdir()
        (helper / "tcell_adaptive_runtime.py").write_text(STUB_WORKER)
        plan = {"plan_dir": str(self.root), "plan_id": "failure", "branches": OrderedDict([
            ("broad_ratio", {"kind": "fixed", "fail": True}), ("broad_adaptive", {"kind": "adaptive"})])}
        with self.assertRaises(RuntimeError) as caught:
            r.launch_experiment(plan, helper, {"ok": True, "visible_device_count": 1}, max_minutes=1)
        out = caught.exception.run_root
        self.assertFalse((out / "broad_adaptive" / "result.json").exists())
        self.assertIn("Matched static baseline failed", json.loads((out / "comparison_complete.json").read_text())["failures"]["broad_adaptive"])

    def test_worker_records_gpu_failure_without_cpu_substitution(self):
        plan = {"branches": {"fixed": {"kind": "fixed", "cache_dir": "synthetic"}}}
        with patch.object(r.engine, "run_gpu_branch", side_effect=ImportError("CUDA unavailable")) as run:
            with self.assertRaises(ImportError):
                r.run_worker(plan, "fixed", self.root / "worker", {})
        self.assertEqual(run.call_count, 1)
        self.assertEqual(run.call_args.kwargs["gpu_device"], 0)
        self.assertTrue((self.root / "worker" / "worker_error.json").is_file())
        self.assertFalse((self.root / "worker" / "result.json").exists())

    def test_read_embedding_rejects_reordered_cells(self):
        f = make_fixture(self.root)
        path = write_embedding(f["weighted"], self.root / "wrong.h5ad", reverse_rows=True)
        with self.assertRaises(ValueError):
            r._read_embedding(path, f["obs"].index)

    def test_adaptive_cpu_wiring_applies_every_row_and_writes_final_cache(self):
        f = make_fixture(self.root)
        features = pd.read_csv(f["weighted"] / "features.csv")
        features = features.loc[~features.gene.isin(workflow.HELDOUT_GENES)].copy()
        pool, _ = workflow.create_branch_cache(f["weighted"], self.root / "pool", features)
        initial = write_embedding(pool, self.root / "initial.h5ad")
        plan = {"branches": {"broad_adaptive": {"cache_dir": str(pool), "kind": "adaptive"}}, "heldout_genes": list(workflow.HELDOUT_GENES)}
        cp = types.ModuleType("cupy")
        cp.__version__ = "synthetic_cpu_wiring_only"
        cp.cuda = types.SimpleNamespace(Device=lambda device: contextlib.nullcontext())
        real_score = maths.score_adaptive_weights
        seen = []
        def score(*args, **kwargs):
            kwargs["xp"] = np
            kwargs["verbose"] = False
            return real_score(*args, **kwargs)
        def run(cache, output, **kwargs):
            seen.append((Path(cache), kwargs))
            return write_embedding(cache, Path(output) / "embedding.h5ad")
        with patch.dict("sys.modules", {"cupy": cp}), patch.object(maths, "score_adaptive_weights", side_effect=score), patch.object(r.engine, "run_gpu_branch", side_effect=run):
            result = r.run_adaptive(plan, self.root / "adaptive", initial,
                adaptive_settings={"max_updates": 2, "max_probe_per_sample": 8, "max_probe_total": 16, "gene_chunk_size": 4, "convergence_log_change": 0})
        self.assertTrue(result.is_file())
        meta = json.loads((self.root / "adaptive" / "adaptive_metadata.json").read_text())
        self.assertEqual(meta["n_cells"], 30)
        self.assertEqual(meta["n_score_probes"], 16)
        self.assertTrue(meta["all_declared_cells_embedded"])
        self.assertFalse(meta["guide_marker_labels_used_for_fitting"])
        self.assertNotEqual(meta["math_version"], "unknown")
        self.assertEqual(len(seen), 2)
        self.assertTrue(seen[0][1]["graph_only"])
        self.assertFalse(seen[-1][1]["graph_only"])
        self.assertEqual(len(pd.read_csv(Path(meta["final_feature_cache"]) / "obs.csv.gz")), 30)


if __name__ == "__main__":
    unittest.main()
