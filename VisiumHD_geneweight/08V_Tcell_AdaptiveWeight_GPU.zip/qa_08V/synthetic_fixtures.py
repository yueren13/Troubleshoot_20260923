"""Small synthetic 08O/cache fixtures; never real biological data."""
from pathlib import Path
import json
import shutil
import numpy as np
import pandas as pd
import scipy.sparse as sp
import anndata as ad
import tcell_weighted_workflow as base
import tcell_adaptive_workflow as workflow


def make_fixture(root):
    root = Path(root)
    genes = [f"G{i}" for i in range(10)] + ["Rare", "Cd4", "Cd8a", "Foxp3"] + list(workflow.HELDOUT_GENES)
    rng = np.random.default_rng(73)
    raw = rng.poisson(0.8, (30, len(genes))).astype(np.float32)
    raw[:, 0] += 1
    raw[:, genes.index("Rare")] = 0
    raw[[0, 10, 20], genes.index("Rare")] = [1, 3, 2]
    counts = sp.csr_matrix(raw)
    totals = np.asarray(counts.sum(axis=1)).ravel() + np.arange(30) * 6 + 50
    obs = pd.DataFrame({"sample": ["s1"] * 15 + ["s2"] * 15,
                        "condition": ["control"] * 15 + ["treat"] * 15,
                        "population": ["T cell 1"] * 15 + ["T cell 2"] * 15,
                        "total_counts": totals.astype(np.int64),
                        "n_genes_by_counts": np.diff(counts.indptr)},
                       index=pd.Index([f"cell_{i:02d}" for i in range(30)], name="cell_id"))
    original = ad.AnnData(X=counts.copy(), obs=obs, var=pd.DataFrame(index=genes))
    original.layers["counts"] = counts.copy()
    original.uns["08m"] = {"analysis_id": "synthetic_08v_fixture"}
    source = root / "source.h5ad"
    original.write_h5ad(source)
    ratio = root / "ratios.csv"
    pd.DataFrame({"gene": genes, "ratio": np.linspace(0.1, 1.5, len(genes))}).to_csv(ratio, index=False)
    receipt = root / "receipt.json"
    base.save_json(receipt, {"analysis_id": "synthetic_08v_fixture"})
    pointer = root / "inputs" / "08o_pointer.json"
    pointer.parent.mkdir()
    pointer.write_text("{}")
    inputs = {"baseline_path": str(source), "ratio_path": str(ratio),
              "receipt_path": str(receipt), "pointer_path": str(pointer),
              "output_root": str(root / "weighted_output"),
              "index": {"analyzed_cells": 30, "selected_cells": 30},
              "source_signatures": [base._signature(p) for p in (source, ratio, receipt)]}
    weighted, manifest = base.prepare_cache(inputs, ["Cd4", "Cd8a", "Foxp3"] + list(workflow.HELDOUT_GENES),
        midpoint=0.6, power=2, min_detected_cells=2, target_sum=10000)
    selected = root / "selected_cache"
    selected.mkdir()
    names = ["lognorm_features.npz", "obs.csv.gz", "features.csv", "marker_counts.npz", "marker_log1p.npz", "marker_genes.csv", "source_inputs.json"]
    for name in names:
        shutil.copy2(weighted / name, selected / name)
    base.save_json(selected / "preparation_settings.json", {
        "n_top_genes": 14, "min_detected_cells": 2,
        "target_sum": 10000.0, "heldout_genes": list(workflow.HELDOUT_GENES)})
    names.append("preparation_settings.json")
    selected_manifest = dict(manifest, cache_id="synthetic-selected-panel", data_identity="synthetic-selected-panel",
                             files={name: (selected / name).stat().st_size for name in names})
    base.save_json(selected / "cache_manifest.json", selected_manifest)
    return {"inputs": inputs, "weighted": weighted, "selected": selected,
            "counts": counts, "genes": genes, "obs": obs, "root": root}


def prep_settings(**overrides):
    result = {"selected_n_top_genes": 14, "selected_min_detected_cells": 2,
              "broad_min_detected_cells": 5, "qc_min_counts": 150,
              "qc_min_genes": 5, "qc_min_cells": 4}
    result.update(overrides)
    return result


def write_embedding(cache, target, *, reverse_rows=False, wrong_weight=False):
    cache, target = Path(cache), Path(target)
    obs = pd.read_csv(cache / "obs.csv.gz", index_col=0)
    var = pd.read_csv(cache / "features.csv").set_index("gene")
    var["applied_distance_weight"] = var["weight"] + (0.5 if wrong_weight else 0)
    if reverse_rows:
        obs = obs.iloc[::-1]
    n = len(obs)
    rows = np.repeat(np.arange(n), 2)
    columns = np.column_stack(((np.arange(n) + 1) % n, (np.arange(n) - 1) % n)).ravel()
    graph = sp.csr_matrix((np.ones(n * 2, np.float32), (rows, columns)), shape=(n, n))
    data = ad.AnnData(X=sp.csr_matrix((n, len(var)), dtype=np.float32), obs=obs, var=var)
    data.obsp["neighbors_connectivities"] = graph
    target.parent.mkdir(parents=True, exist_ok=True)
    data.write_h5ad(target)
    return target
