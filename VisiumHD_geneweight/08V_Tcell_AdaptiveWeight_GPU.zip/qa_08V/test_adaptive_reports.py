"""Execute the real 08V notebook on synthetic assays with explicit CPU/GPU mocks.

The saved QA figures do not represent biological data or a CUDA benchmark.
All preparation, adaptive scoring math, review aggregation and ZIP creation run.
Only CUDA preflight, GPU embedding work and scheduler execution are substituted.
"""
from pathlib import Path, PurePosixPath
from html.parser import HTMLParser
from urllib.parse import urlsplit
from unittest.mock import patch
import contextlib
import importlib
import json
import os
import tempfile
import types
import unittest
import zipfile

import anndata as ad
import numpy as np
import pandas as pd

from synthetic_fixtures import make_fixture, prep_settings, write_embedding


QA_ROOT = Path(__file__).resolve().parent
NOTEBOOK = QA_ROOT.parent / "08V_Tcell_AdaptiveWeight_GPU" / "08V_Tcell_AdaptiveWeight_GPU.ipynb"
CLUSTER_KEYS = ("leiden_0.2", "leiden_0.4", "leiden_0.6")


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in ("src", "href") and value:
                self.links.append(value)


def complete_synthetic_embedding(cache, output, **kwargs):
    target = write_embedding(cache, Path(output) / "embedding.h5ad")
    result = ad.read_h5ad(target)
    n = result.n_obs
    angle = np.arange(n, dtype=float) * (2 * np.pi / n)
    result.obsm["X_umap"] = np.column_stack((np.cos(angle), np.sin(angle))).astype(np.float32)
    for key, groups in zip(CLUSTER_KEYS, (2, 3, 4)):
        result.obs[key] = pd.Categorical((np.arange(n) * groups // n).astype(str))
    result.uns["qa_only"] = "Synthetic CPU-wired outputs; not real UMAP or biological results."
    result.write_h5ad(target)
    return target


def execute_notebook():
    root = Path(tempfile.mkdtemp(prefix="report_smoke_", dir=QA_ROOT))
    fixture_dir = root / "fixture"
    fixture_dir.mkdir()
    fixture = make_fixture(fixture_dir)
    notebook = json.loads(NOTEBOOK.read_text())
    env = {"__name__": "__08v_notebook_smoke__"}
    executed = []
    previous_cwd = Path.cwd()
    os.chdir(root)
    try:
        with contextlib.ExitStack() as patches:
            for index, cell in enumerate(notebook["cells"]):
                if cell["cell_type"] != "code":
                    continue
                source = "".join(cell["source"])
                exec(compile(source, f"08V-notebook-cell-{index}", "exec"), env)
                executed.append({"index": index, "id": cell.get("id")})
                if "HELPER_SOURCE_ID" in env and "qa_hooks_installed" not in env:
                    # Bootstrap clears helper imports: patch the restored modules,
                    # not stale pre-bootstrap references.
                    workflow, runtime = env["workflow"], env["runtime"]
                    real_prepare = workflow.prepare_inputs

                    def prepare(project_dir=None, settings=None, **kwargs):
                        return real_prepare(project_dir, output_root=root / "prepared", settings=settings,
                            source_08u_cache=fixture["selected"], source_weighted_cache=fixture["weighted"])

                    def preflight(*args, **kwargs):
                        return {"ok": True, "visible_device_count": 1,
                                "qa_only": "Fake CUDA gate: no real GPU was used."}

                    def launch(plan, helper_dir, gpu_runtime, *, gpu_settings=None,
                               adaptive_settings=None, **kwargs):
                        run_root = Path(plan["plan_dir"]) / "synthetic_cpu_run"
                        run_root.mkdir()
                        maths = importlib.import_module("tcell_adaptive_math")
                        real_score = maths.score_adaptive_weights
                        cp = types.ModuleType("cupy")
                        cp.__version__ = "synthetic_cpu_wiring_only"
                        cp.cuda = types.SimpleNamespace(Device=lambda device: contextlib.nullcontext())

                        def score(*args, **kwargs):
                            kwargs.update(xp=np, verbose=False)
                            return real_score(*args, **kwargs)

                        branches = {}
                        names = ["broad_ratio"] + [name for name in plan["branches"] if name != "broad_ratio"]
                        with patch.dict("sys.modules", {"cupy": cp}), patch.object(maths, "score_adaptive_weights", side_effect=score), patch.object(runtime.engine, "run_gpu_branch", side_effect=complete_synthetic_embedding):
                            for name in names:
                                branches[name] = runtime.run_worker(plan, name, run_root / name,
                                    gpu_settings, adaptive_settings, resume=False)
                        return branches, run_root

                    patches.enter_context(patch.object(workflow, "_resolve_inputs", return_value=fixture["inputs"]))
                    patches.enter_context(patch.object(workflow, "prepare_inputs", side_effect=prepare))
                    patches.enter_context(patch.object(runtime, "preflight", side_effect=preflight))
                    patches.enter_context(patch.object(runtime, "launch_experiment", side_effect=launch))
                    env["qa_displays"] = []
                    env["display"] = lambda *args, **kwargs: env["qa_displays"].extend(args)
                    env["qa_hooks_installed"] = True
                if "PREP_SETTINGS" in env and "qa_settings_installed" not in env:
                    env["PREP_SETTINGS"].update(prep_settings())
                    env["ADAPTIVE_SETTINGS"].update(max_updates=2, max_probe_per_sample=8,
                        max_probe_total=16, gene_chunk_size=4, convergence_log_change=0)
                    env["MAX_PLOT_CELLS"] = 30
                    env["qa_settings_installed"] = True
    finally:
        os.chdir(previous_cwd)
    summary = {"qa_only": True, "real_gpu_tested": False, "notebook": str(NOTEBOOK),
               "helper_source_id": env["HELPER_SOURCE_ID"], "executed_code_cells": executed,
               "review": env["REVIEW"], "return_zip": str(env["LOCAL_RETURN"]),
               "synthetic_root": str(root)}
    (root / "notebook_smoke_result.json").write_text(json.dumps(summary, indent=2))
    (QA_ROOT / "latest_report_smoke.json").write_text(json.dumps(summary, indent=2))
    return root, fixture, env, executed


class ReportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root, cls.fixture, cls.env, cls.executed = execute_notebook()
        cls.review_dir = Path(cls.env["REVIEW"]["index_path"]).parent
        cls.metrics = pd.read_csv(cls.env["REVIEW"]["comparison_path"])

    def test_every_notebook_code_cell_executed(self):
        notebook = json.loads(NOTEBOOK.read_text())
        expected = [i for i, c in enumerate(notebook["cells"]) if c["cell_type"] == "code"]
        self.assertEqual([c["index"] for c in self.executed], expected)
        self.assertEqual(len(expected), 9)
        self.assertTrue(Path(self.env["LOCAL_RETURN"]).is_file())

    def test_three_feature_two_adaptive_two_qc_methods_all_resolutions(self):
        expected = {"feature_scaling": 3, "adaptive": 2, "qc": 2}
        for group, number in expected.items():
            rows = self.metrics[self.metrics.review_group == group]
            self.assertEqual(rows.method.nunique(), number)
            self.assertEqual(set(rows.clustering), set(CLUSTER_KEYS))
            self.assertEqual(len(rows), number * len(CLUSTER_KEYS))
        self.assertTrue(self.env["REVIEW"]["all_statistics_use_original_counts"])
        self.assertFalse(self.env["REVIEW"]["score_training_uses_marker_labels"])

    def test_qc_comparison_uses_exact_same_retained_cells(self):
        n = self.env["PLAN"]["qc"]["n_retained"]
        qc = self.metrics[self.metrics.review_group == "qc"]
        self.assertEqual(qc.n_cells.unique().tolist(), [n])
        self.assertLess(n, self.env["PLAN"]["n_cells"])
        self.assertTrue(qc.observed_evidence_graph_assortativity.isna().all())
        self.assertIn("same retained cells", self.env["REVIEW"]["qc_note"])

    def test_marker_aggregation_uses_original_integer_counts(self):
        original = self.fixture["counts"].toarray()
        genes = self.fixture["genes"]
        for group, method in (("feature_scaling", "selected_zscore"), ("adaptive", "broad_adaptive")):
            table = pd.read_csv(self.review_dir / group / "marker_statistics.csv.gz")
            result = ad.read_h5ad(self.env["BRANCHES"][method])
            labels = result.obs["leiden_0.4"].astype(str).to_numpy()
            for cluster in np.unique(labels):
                measured = original[labels == cluster, genes.index("Cd4")]
                row = table[(table.method == method) & (table.clustering == "leiden_0.4") &
                            (table.cluster.astype(str) == cluster) & (table.gene == "Cd4")].iloc[0]
                self.assertAlmostEqual(row.mean_observed_counts, float(measured.mean()), places=6)
                self.assertEqual(row.n_positive, int((measured > 0).sum()))

    def test_learned_weight_diagnostics_and_holdout_audits(self):
        weight_root = self.review_dir / "weights"
        self.assertTrue((weight_root / "adaptive_weight_diagnostics.png").is_file())
        table = pd.read_csv(weight_root / "final_gene_weights.csv")
        self.assertTrue(table.multiplier_vs_ratio.between(1 / 3, 3).all())
        self.assertFalse(set(table.gene) & set(self.env["PLAN"]["heldout_genes"]))
        meta = json.loads((Path(self.env["RUN_ROOT"]) / "broad_adaptive" / "adaptive_metadata.json").read_text())
        self.assertEqual(len(meta["rounds"]), 2)
        for group in ("feature_scaling", "adaptive"):
            audit = pd.read_csv(self.review_dir / group / "companions" / "heldout_exclusion_audit.csv")
            self.assertEqual(len(audit), len(self.env["PLAN"]["heldout_genes"]) * (3 if group == "feature_scaling" else 2))

    def test_full_reports_use_08v_titles_and_existing_relative_local_links(self):
        for path in self.review_dir.rglob("*.html"):
            source = path.read_text()
            self.assertNotIn("<title>08T", source)
            self.assertNotIn("<h1>08T", source)
            parser = Links()
            parser.feed(source)
            for link in parser.links:
                parsed = urlsplit(link)
                if parsed.scheme in ("https", "http") or not parsed.path:
                    continue
                self.assertFalse(PurePosixPath(parsed.path).is_absolute(), (path, link))
                self.assertTrue((path.parent / parsed.path).is_file(), (path, link))

    def test_notebook_review_copy_and_download_links_are_inside_visible_working_folder(self):
        display_root = Path(self.env["DISPLAY_DIR"])
        self.assertTrue(display_root.is_relative_to(self.root / "08V_results"))
        self.assertTrue((display_root / "index.html").is_file())
        self.assertEqual(Path(self.env["LOCAL_RETURN"]).parent, display_root)
        links = [value for value in self.env["qa_displays"] if type(value).__name__ == "FileLink"]
        self.assertGreaterEqual(len(links), 2)
        for link in links:
            self.assertFalse(Path(link.path).is_absolute())
            self.assertTrue((self.root / link.path).is_file())

    def _check_archive(self, archive_path, bound):
        self.assertLessEqual(archive_path.stat().st_size, bound)
        with zipfile.ZipFile(archive_path) as archive:
            names = set(archive.namelist())
            self.assertFalse(any(PurePosixPath(n).is_absolute() or ".." in PurePosixPath(n).parts for n in names))
            self.assertFalse(any(n.endswith((".h5ad", ".npz", ".npy")) for n in names))
            self.assertFalse(any(n.endswith(("observed_marker_evidence.csv.gz", "cell_qc_flags.csv.gz", "umap_display_cell_ids.csv.gz")) for n in names))
            parser = Links()
            parser.feed(archive.read("index.html").decode())
            for link in parser.links:
                self.assertIn(link, names)
            return json.loads(archive.read("bundle_manifest.json"))

    def test_return_zip_uses_bounded_portable_existing_links(self):
        self._check_archive(Path(self.env["LOCAL_RETURN"]), 25_000_000)

    def test_tight_bundle_bound_records_omissions(self):
        path = self.env["reports"].make_return_bundle(self.env["PLAN"], self.env["RUN_ROOT"],
            destination=self.root / "tiny_return.zip", max_bytes=1_000_000)
        receipt = self._check_archive(path, 1_000_000)
        self.assertTrue(receipt["omitted_for_size"])


class BundlePriorityTests(unittest.TestCase):
    def test_raw_primary_dotplots_are_prioritized_by_actual_slugged_resolution(self):
        reports = importlib.import_module("tcell_adaptive_reports")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            figures = root / "review" / "adaptive" / "figures"
            figures.mkdir(parents=True)
            plan = {"plan_dir": str(root), "qc": {"retention_path": str(root / "absent.csv")}}
            names = {}
            for resolution in ("0_2", "0_4", "0_6"):
                name = f"dotplot_broad_adaptive_leiden_{resolution}_lineage_mean_log1p_page01.png"
                (figures / name).write_bytes(b"QA priority placeholder; not a plotted image")
                names[resolution] = "review/adaptive/figures/" + name
            for resolution in ("0.4", "0.6"):
                with self.subTest(primary_resolution=resolution):
                    (root / "review" / "review_manifest.json").write_text(json.dumps({"primary_cluster_key": "leiden_" + resolution}))
                    path = reports.make_return_bundle(plan, root, root / "return.zip")
                    with zipfile.ZipFile(path) as archive:
                        included = json.loads(archive.read("bundle_manifest.json"))["included_files"]
                    primary = included.index(names[resolution.replace(".", "_")])
                    self.assertLess(primary, included.index(names["0_2"]))


if __name__ == "__main__":
    unittest.main()
