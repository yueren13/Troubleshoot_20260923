"""08V preflight supervisor regression tests; real Python children, no CUDA required.

Only the two previously passing hardware/RAPIDS checks are mocked.  Controlled
child programs exercise the actual spawn, log streaming, deadline, cleanup
and evidence validation pathways without waiting for a production-length boot.
"""
import inspect
import json
import os
from pathlib import Path
import subprocess
import time
from unittest.mock import patch

import pytest

import tcell_adaptive_runtime as runtime


GOOD = {
    "probe": "08V-adaptive-score-cuda-parity-v1",
    "status": "passed", "absolute_tolerance": 2e-5,
    "max_absolute_errors": {"depth_r2": 1e-10, "coherence": 1e-8, "new_weight": 2e-5},
    "production_cpu_fallback": False, "gpu_logical_device": 0,
    "visible_gpu_count": 1, "gpu_name": "test fixture: no actual GPU",
    "n_cells": 192, "n_samples": 2, "n_genes": 8, "n_probes": 64,
    "gene_chunk_size": 3, "versions": {"cupy": "test fixture"},
}


def _write_probe(root, body):
    (root / "tcell_adaptive_cuda_probe.py").write_text(
        "import json, os, sys, time\nfrom pathlib import Path\n" + body,
        encoding="utf-8",
    )


def _emit(value):
    return f"print({json.dumps(value)!r}, flush=True)\n"


def _run(root, *, deadline=3):
    # subprocess.run (older availability check); subprocess.Popen for the adaptive
    # probe is intentionally real.  Keep this seam local to the regression suite.
    available = subprocess.CompletedProcess([], 0, '{"ok":true,"visible_device_count":1}', '')
    with patch.object(runtime.subprocess, "run", return_value=available), \
         patch.object(runtime.base, "preflight_gpu", return_value={"ok": True, "visible_device_count": 1}):
        return runtime.preflight(root, root / "diagnostics",
                                 adaptive_timeout_seconds=deadline, heartbeat_seconds=.05)


def _read_receipt(root):
    return json.loads((root / "diagnostics" / "adaptive_cuda_probe.json").read_text())


def test_slow_start_then_valid_parity_passes_with_longer_default(tmp_path, capsys):
    assert inspect.signature(runtime.preflight).parameters["adaptive_timeout_seconds"].default == 600
    _write_probe(tmp_path, 'print("[08V parity stage] CuPy import", file=sys.stderr, flush=True)\n'
                          'time.sleep(.25)\n' + _emit(GOOD))
    result = _run(tmp_path)
    cap = capsys.readouterr()
    assert "CuPy import" in cap.out + cap.err
    assert result["adaptive_cuda_parity"]["status"] == "passed"
    assert _read_receipt(tmp_path)["max_absolute_errors"]["new_weight"] == 2e-5
    assert json.loads((tmp_path / "diagnostics" / "runtime.json").read_text())["ok"] is True


def test_timeout_preserves_partial_streams_and_last_stage_and_reaps_worker(tmp_path):
    # A failed retry may not inherit success from a previous invocation.
    _write_probe(tmp_path, _emit(GOOD))
    _run(tmp_path)
    _write_probe(tmp_path,
                 'print("incomplete stdout marker", flush=True)\n'
                 'print("[08V parity stage] GPU scoring", file=sys.stderr, flush=True)\n'
                 'Path(__file__).with_suffix(".pid").write_text(str(os.getpid()))\n'
                 'time.sleep(30)\n')
    with pytest.raises(RuntimeError, match="(?i)timed out|timeout"):
        _run(tmp_path, deadline=.65)
    path = tmp_path / "diagnostics"
    receipt = _read_receipt(tmp_path)
    assert receipt["status"] == "timeout" and receipt["last_stage"] == "GPU scoring"
    assert (path / "adaptive_cuda_stdout.txt").read_text().strip() == "incomplete stdout marker"
    assert "GPU scoring" in (path / "adaptive_cuda_stderr.txt").read_text()
    assert not (path / "runtime.json").exists()
    pid = int((tmp_path / "tcell_adaptive_cuda_probe.pid").read_text())
    with pytest.raises(ProcessLookupError):
        os.kill(pid, 0)


def test_real_child_reporting_numerical_disagreement_stops_pipeline(tmp_path):
    problem = dict(GOOD, status="failed", error={"type": "AssertionError", "message": "coherence mismatch"})
    problem["max_absolute_errors"] = dict(GOOD["max_absolute_errors"], coherence=0.02)
    _write_probe(tmp_path, 'print("[08V parity stage] Comparing scores", file=sys.stderr, flush=True)\n'
                          + _emit(problem) + 'sys.exit(1)\n')
    with pytest.raises(RuntimeError):
        _run(tmp_path)
    r = _read_receipt(tmp_path)
    assert r["status"] == "failed"
    assert "coherence mismatch" in json.dumps(r)
    assert not (tmp_path / "diagnostics" / "runtime.json").exists()


def test_notebook_interrupt_terminates_only_started_probe_and_keeps_evidence(tmp_path):
    # Interrupt the supervising poll loop only after the real child says it is
    # inside the GPU step. No signals are sent to the test runner.
    pid_path = tmp_path / "tcell_adaptive_cuda_probe.pid"
    _write_probe(tmp_path,
                 'print("[08V parity stage] GPU scoring", file=sys.stderr, flush=True)\n'
                 'Path(__file__).with_suffix(".pid").write_text(str(os.getpid()))\n'
                 'time.sleep(30)\n')
    real_sleep, did_interrupt = time.sleep, []
    def sleep_or_interrupt(seconds):
        if not did_interrupt and pid_path.exists():
            did_interrupt.append(True)
            raise KeyboardInterrupt
        real_sleep(seconds)
    with patch.object(runtime.time, "sleep", sleep_or_interrupt), pytest.raises(KeyboardInterrupt):
        _run(tmp_path)
    receipt = _read_receipt(tmp_path)
    assert receipt["status"] == "interrupted" and receipt["last_stage"] == "GPU scoring"
    assert not (tmp_path / "diagnostics" / "runtime.json").exists()
    with pytest.raises(ProcessLookupError):
        os.kill(int(pid_path.read_text()), 0)


@pytest.mark.parametrize("stdout", [
    "{",
    json.dumps({"status": "passed"}),
    json.dumps(dict(GOOD, max_absolute_errors={**GOOD["max_absolute_errors"], "coherence": 1.0})),
])
def test_broken_or_unsubstantiated_zero_exit_pass_is_rejected(tmp_path, stdout):
    _write_probe(tmp_path, f"print({stdout!r}, flush=True)\n")
    with pytest.raises(RuntimeError):
        _run(tmp_path)
    assert _read_receipt(tmp_path)["status"] != "passed"
    assert not (tmp_path / "diagnostics" / "runtime.json").exists()
