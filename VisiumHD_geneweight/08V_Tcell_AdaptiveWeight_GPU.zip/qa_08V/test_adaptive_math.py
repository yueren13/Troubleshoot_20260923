"""Independent numerical and scientific-behavior checks for the 08V scores."""

from pathlib import Path
import sys
import unittest

import numpy as np
import scipy.sparse as sp

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "08V_Tcell_AdaptiveWeight_GPU"))
from tcell_adaptive_math import (prepare_probe_graph, score_adaptive_weights,
                                 select_probe_rows, update_distance_weights)


def group_graph(labels, biological_group, k=12, self_weight=0):
    """Deterministic graph built from independent synthetic group truth."""
    row, col, data = [], [], []
    for i in range(len(labels)):
        candidates = np.flatnonzero((labels == labels[i]) & (biological_group == biological_group[i]))
        candidates = candidates[candidates != i]
        offset = i % len(candidates)
        neighbors = np.roll(candidates, offset)[:k]
        row.extend([i] * len(neighbors)); col.extend(neighbors); data.extend([1.0] * len(neighbors))
        if self_weight:
            row.append(i); col.append(i); data.append(float(self_weight))
    return sp.csr_matrix((data, (row, col)), shape=(len(labels), len(labels)), dtype=np.float32)


def independent_scores(X, A, labels, counts, rows):
    """Dense least-squares reference, intentionally separate from module math."""
    x = np.asarray(X, dtype=np.float32).astype(np.float64)
    residual = np.empty_like(x)
    depth = []
    for label in np.unique(labels):
        idx = labels == label
        z = np.log1p(counts[idx])
        design = np.column_stack([np.ones(idx.sum()), z, z * z])
        fitted = design @ np.linalg.lstsq(design, x[idx], rcond=None)[0]
        residual[idx] = x[idx] - fitted
        tss = ((x[idx] - x[idx].mean(0)) ** 2).sum(0)
        rss = ((x[idx] - fitted) ** 2).sum(0)
        depth.append(np.where(tss > 1e-10 * idx.sum(), np.clip(1 - rss / np.maximum(tss, 1e-10), 0, 1), 0))
    # Production intentionally stores residual blocks as float32.
    residual = residual.astype(np.float32)
    neighbors = A @ residual
    corr = []
    for label in np.unique(labels):
        pidx = labels[rows] == label
        a, b = residual[rows[pidx]].astype(float), neighbors[pidx].astype(float)
        a -= a.mean(0); b -= b.mean(0)
        va, vb = (a * a).sum(0), (b * b).sum(0)
        good = (va > 1e-10 * pidx.sum()) & (vb > 1e-10 * pidx.sum())
        corr.append(np.where(good, (a * b).sum(0) / np.maximum(np.sqrt(va * vb), 1e-10), 0))
    return np.mean(depth, axis=0), np.mean(corr, axis=0)


class AdaptiveMathTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(101)
        self.labels = np.repeat(["A", "B", "C"], 240)
        self.n = self.labels.size
        self.bio = np.tile(np.repeat([0, 1], 120), 3)
        self.counts = rng.integers(40, 2000, size=self.n).astype(float)
        z = np.log1p(self.counts)
        sample_shift = np.repeat([0, 1, 2], 240)
        self.X = np.column_stack([
            0.7 + 0.8 * z + 0.08 * z * z,
            2.0 + 2.0 * self.bio + rng.normal(0, 0.15, self.n),
            2.0 + rng.normal(0, 0.15, self.n),
            np.ones(self.n) * 3.0,
            1.0 + sample_shift,
            rng.poisson(0.2, self.n).astype(float),
        ]).astype(np.float32)
        self.graph = group_graph(self.labels, self.bio, k=15, self_weight=1000)
        self.base = np.array([0.4, 0.7, 0.9, 0.2, 0.6, 0.5])

    def score(self, **kwargs):
        args = dict(X=sp.csr_matrix(self.X), graph=self.graph,
                    sample_labels=self.labels, total_counts=self.counts,
                    base_weights=self.base, gene_chunk_size=2,
                    probe_rows=np.arange(self.n), reliability_count=500, verbose=False)
        args.update(kwargs)
        return score_adaptive_weights(**args)

    def test_blocked_scores_match_independent_least_squares_reference(self):
        result = self.score()
        A, _ = prepare_probe_graph(self.graph, np.arange(self.n), self.n)
        depth, coherence = independent_scores(self.X, A, self.labels, self.counts, np.arange(self.n))
        np.testing.assert_allclose(result["depth_r2"], depth, atol=2e-8)
        np.testing.assert_allclose(result["coherence"], coherence, atol=2e-6)

    def test_single_block_and_gene_chunks_agree_and_preserve_inputs(self):
        original = self.X.copy(); graph_original = self.graph.copy()
        a = self.score(X=self.X, gene_chunk_size=1)
        b = self.score(X=sp.csc_matrix(self.X), gene_chunk_size=100)
        for key in ["depth_r2", "coherence", "reliability", "reward", "new_weight", "detected_cells"]:
            np.testing.assert_allclose(a[key], b[key], rtol=2e-6, atol=2e-7, err_msg=key)
        np.testing.assert_array_equal(original, self.X)
        self.assertEqual((graph_original != self.graph).nnz, 0)

    def test_depth_only_gene_penalized_and_independent_biology_rewarded(self):
        r = self.score()
        self.assertGreater(r["depth_r2"][0], 0.99999)
        self.assertEqual(r["reward"][0], 0)
        self.assertLess(r["new_weight"][0], self.base[0])
        self.assertGreater(r["coherence"][1], 0.95)
        self.assertLess(r["depth_r2"][1], 0.05)
        self.assertGreater(r["new_weight"][1], self.base[1])
        self.assertLess(abs(r["coherence"][2]), 0.15)

    def test_constant_and_sample_only_genes_do_not_receive_rewards(self):
        r = self.score()
        np.testing.assert_array_equal(r["depth_r2"][[3, 4]], [0, 0])
        np.testing.assert_array_equal(r["coherence"][[3, 4]], [0, 0])
        np.testing.assert_allclose(r["new_weight"][[3, 4]], self.base[[3, 4]], atol=1e-15)

    def test_self_only_and_zero_graph_cannot_generate_coherence(self):
        for graph in [sp.eye(self.n, format="csr"), sp.csr_matrix((self.n, self.n))]:
            r = self.score(graph=graph)
            np.testing.assert_array_equal(r["coherence"], np.zeros(self.X.shape[1]))
            np.testing.assert_array_equal(r["reward"], np.zeros(self.X.shape[1]))
            self.assertEqual(r["diagnostics"]["n_zero_nonself_neighbor_probe_rows"], self.n)
            self.assertLess(r["new_weight"][0], self.base[0])

    def test_self_edges_are_removed_before_normalization(self):
        full, valid = prepare_probe_graph(self.graph, np.arange(self.n), self.n)
        np.testing.assert_array_equal(full.diagonal(), np.zeros(self.n))
        np.testing.assert_allclose(full.sum(1), np.ones((self.n, 1)), atol=2e-7)
        self.assertTrue(valid.all())
        graph_no_self = self.graph.copy(); graph_no_self.setdiag(0); graph_no_self.eliminate_zeros()
        np.testing.assert_allclose(self.score()["new_weight"], self.score(graph=graph_no_self)["new_weight"], atol=1e-12)

    def test_deterministic_balanced_probe_selection_with_small_samples(self):
        labels = np.array(["A"] * 3 + ["B"] * 100 + ["C"] * 100)
        a = select_probe_rows(labels, max_probe_per_sample=10, max_probe_total=21, seed=42)
        b = select_probe_rows(labels, max_probe_per_sample=10, max_probe_total=21, seed=42)
        np.testing.assert_array_equal(a, b)
        self.assertEqual(np.unique(a).size, 21)
        self.assertEqual({x: int((labels[a] == x).sum()) for x in np.unique(labels)}, {"A": 3, "B": 9, "C": 9})
        c = select_probe_rows(labels, max_probe_per_sample=10, max_probe_total=21, seed=43)
        self.assertFalse(np.array_equal(a, c))

    def test_preselected_probe_graph_has_same_result(self):
        rows = select_probe_rows(self.labels, max_probe_per_sample=40, max_probe_total=120, seed=9)
        a = self.score(probe_rows=rows)
        b = self.score(probe_rows=rows, graph=self.graph[rows])
        np.testing.assert_allclose(a["new_weight"], b["new_weight"], atol=1e-12)
        np.testing.assert_array_equal(a["probe_rows"], rows)

    def test_geometric_damping_bounds_and_zero_prior(self):
        b = np.array([0.2, 1.0, 0.0])
        kwargs = dict(base_weights=b, current_weights=b, coherence=[1, 0, 1],
                      depth_r2=[0, 1, 0], detected_cells=[1000000, 500, 1000000],
                      reliability_count=0)
        r = update_distance_weights(**kwargs, damping=0.5)
        np.testing.assert_allclose(r["target_weight"], [0.6, 1/3, 0])
        np.testing.assert_allclose(r["new_weight"], [0.2*np.sqrt(3), 1/np.sqrt(3), 0])
        self.assertTrue((r["new_weight"] >= b/3).all())
        self.assertTrue((r["new_weight"] <= b*3).all())
        np.testing.assert_allclose(update_distance_weights(**kwargs, damping=0)["new_weight"], b)
        np.testing.assert_allclose(update_distance_weights(**kwargs, damping=1)["new_weight"], r["target_weight"])

    def test_rare_detection_reduces_same_coherence_reward(self):
        r = update_distance_weights([1, 1], None, [0.8, 0.8], [0, 0], [20, 5000])
        self.assertLess(r["reward"][0], r["reward"][1])
        self.assertLess(r["new_weight"][0], r["new_weight"][1])

    def test_physically_excluded_gene_values_cannot_change_scores(self):
        # The graph is deliberately fixed independently of the heldout column.
        heldout = np.column_stack([self.X, np.arange(self.n)])
        other = heldout.copy(); other[:, -1] = 1e8
        a = self.score(X=heldout[:, :-1], feature_names=np.array(list("abcdef")))
        b = self.score(X=other[:, :-1], feature_names=np.array(list("abcdef")))
        np.testing.assert_array_equal(a["new_weight"], b["new_weight"])
        np.testing.assert_array_equal(a["gene"], np.array(list("abcdef")))

    def test_invalid_inputs_are_rejected(self):
        with self.assertRaises(ValueError):
            self.score(base_weights=-self.base)
        with self.assertRaises(ValueError):
            self.score(total_counts=np.full(self.n, np.nan))
        with self.assertRaises(ValueError):
            self.score(X=-self.X)
        with self.assertRaises(ValueError):
            self.score(graph=-self.graph)
        with self.assertRaises(TypeError):
            self.score(graph=self.graph.toarray())
        with self.assertRaises(ValueError):
            self.score(probe_rows=[1, 1, 2])


if __name__ == "__main__":
    unittest.main(verbosity=2)
