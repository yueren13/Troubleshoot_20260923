"""Independent preparation/identity tests using synthetic source assays."""
from pathlib import Path
import hashlib
import json
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
import scipy.sparse as sp
import tcell_adaptive_workflow as w
import tcell_weighted_workflow as base
import tcell_weighted_gpu as engine
from synthetic_fixtures import make_fixture, prep_settings


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.f = make_fixture(self.root)
        self.features = pd.read_csv(self.f["weighted"] / "features.csv")
        self.safe = self.features.loc[~self.features.gene.isin(w.HELDOUT_GENES)].copy()

    def tearDown(self):
        self.temp.cleanup()

    def prepare(self, **settings):
        with patch.object(w, "_resolve_inputs", return_value=self.f["inputs"]):
            return w.prepare_inputs(output_root=self.root / "08v", settings=prep_settings(**settings),
                source_08u_cache=self.f["selected"], source_weighted_cache=self.f["weighted"])

    def test_sparse_variance_matches_dense_population_variance(self):
        x = sp.csr_matrix(np.array([[0, 1, 0], [2, 0, 0], [0, 5, 7], [1, 0, 0]], np.float32))
        np.testing.assert_allclose(w._sparse_variance(x), x.toarray().astype(float).var(axis=0), atol=1e-12)

    def test_matched_panels_holdouts_qc_and_unchanged_source(self):
        original_hash = hashlib.sha256(Path(self.f["inputs"]["baseline_path"]).read_bytes()).hexdigest()
        plan = self.prepare()
        self.assertEqual(plan["n_cells"], 30)
        self.assertEqual(plan["branches"]["broad_ratio"]["cache_dir"], plan["branches"]["broad_adaptive"]["cache_dir"])
        genes = {}
        for name, branch in plan["branches"].items():
            c = Path(branch["cache_dir"])
            f = pd.read_csv(c / "features.csv")
            genes[name] = f.gene.tolist()
            self.assertFalse(set(f.gene) & set(w.HELDOUT_GENES))
            _, _, _, obs, _, _, _, _ = engine._metadata_inputs(c, "weighted", engine.validate_settings())
            expected = self.f["obs"].loc[obs.index, "total_counts"].to_numpy()
            np.testing.assert_array_equal(obs.total_counts, expected)
            np.testing.assert_array_equal(obs.n_genes, self.f["obs"].loc[obs.index, "n_genes_by_counts"])
            if branch["cohort"] == "all":
                self.assertEqual(len(obs), 30)
        self.assertEqual(genes["selected_zscore"], genes["selected_centered"])
        self.assertIn("Rare", genes["selected_centered"])
        self.assertNotIn("Rare", genes["selected500_centered"])
        self.assertNotIn("Rare", genes["broad_ratio"])
        self.assertEqual(hashlib.sha256(Path(self.f["inputs"]["baseline_path"]).read_bytes()).hexdigest(), original_hash)
        self.assertEqual(plan["qc"]["status"], "planned")
        self.assertTrue(4 <= plan["qc"]["n_retained"] < 30)
        self.assertIn("common", plan["qc_gene_definition"])

    def test_zscore_distance_is_unit_variance_and_centered_arm_unchanged(self):
        plan = self.prepare(run_qc_branch=False)
        zc = Path(plan["branches"]["selected_zscore"]["cache_dir"])
        cc = Path(plan["branches"]["selected_centered"]["cache_dir"])
        x = sp.load_npz(zc / "lognorm_features.npz").toarray().astype(float)
        f = pd.read_csv(zc / "features.csv")
        transformed = (x - x.mean(axis=0)) * np.sqrt(f.weight.to_numpy())
        np.testing.assert_allclose(transformed.var(axis=0), 1, rtol=3e-6)
        np.testing.assert_array_equal(x, sp.load_npz(cc / "lognorm_features.npz").toarray())
        np.testing.assert_allclose(pd.read_csv(cc / "features.csv").weight, 1)

    def test_resume_reuses_same_identity_and_derived_weights_change_identity(self):
        out = self.root / "branch"
        first, manifest = w.create_branch_cache(self.f["weighted"], out, self.safe)
        stamp = (first / "lognorm_features.npz").stat().st_mtime_ns
        _, again = w.create_branch_cache(self.f["weighted"], out, self.safe)
        self.assertEqual(manifest["cache_id"], again["cache_id"])
        self.assertEqual(stamp, (first / "lognorm_features.npz").stat().st_mtime_ns)
        changed = self.safe.copy()
        changed["weight"] *= 1.1
        with self.assertRaises(ValueError):
            w.create_branch_cache(self.f["weighted"], out, changed)
        _, other = w.create_branch_cache(self.f["weighted"], self.root / "changed", changed)
        self.assertNotEqual(manifest["cache_id"], other["cache_id"])

    def test_qc_subset_keeps_marker_rows_and_normalization(self):
        rows = np.array([1, 3, 7, 12, 20])
        c, m = w.create_branch_cache(self.f["weighted"], self.root / "subset", self.safe, rows=rows)
        old = sp.load_npz(self.f["weighted"] / "lognorm_features.npz")
        ix = pd.Index(self.features.gene).get_indexer(self.safe.gene)
        np.testing.assert_array_equal(sp.load_npz(c / "lognorm_features.npz").toarray(), old[rows][:, ix].toarray())
        np.testing.assert_array_equal(sp.load_npz(c / "marker_counts.npz").toarray(), sp.load_npz(self.f["weighted"] / "marker_counts.npz")[rows].toarray())
        self.assertFalse(m["all_08O_cells_retained"])

    def test_rejects_ancestor_overwrite(self):
        cache = self.f["weighted"]
        for output in (cache, cache.parent, cache / "nested"):
            with self.subTest(output=output), self.assertRaises(ValueError):
                w.create_branch_cache(cache, output, self.safe)

    def test_rejects_negative_and_nonfinite_weights(self):
        for value in (-1, np.nan, np.inf):
            bad = self.safe.copy()
            bad.loc[bad.index[0], "weight"] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                w.create_branch_cache(self.f["weighted"], self.root / "bad", bad)

    def test_rejects_positive_heldout_weights(self):
        with self.assertRaises(ValueError):
            w.create_branch_cache(self.f["weighted"], self.root / "heldout", self.features)

    def test_rejects_permuted_duplicate_and_invalid_rows(self):
        for rows in ([3, 2, 1, 0], [0, 1, 1, 2], [0, 1, 2, 30], [0.0, 1.0, 2.0, 3.0]):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                w.create_branch_cache(self.f["weighted"], self.root / "bad_rows", self.safe, rows=rows)
        with self.assertRaises(ValueError):
            w.create_branch_cache(self.f["weighted"], self.root / "bad_genes", self.safe.iloc[::-1])

    def test_changed_source_signature_rejected(self):
        obs, genes = w._source_axes(self.f["inputs"])
        inputs = dict(self.f["inputs"], source_signatures=[dict(s) for s in self.f["inputs"]["source_signatures"]])
        inputs["source_signatures"][0]["mtime_ns"] += 1
        with self.assertRaises(ValueError):
            w._cache_matches_source(self.f["weighted"], inputs, obs, genes, weighted=True, cfg=w._settings(prep_settings()))

    def test_qc_all_pass_is_skipped(self):
        plan = self.prepare(qc_min_counts=1, qc_min_genes=1)
        self.assertEqual(plan["qc"]["status"], "skipped_all_cells_pass_identical_cohort")
        self.assertNotIn("qc_ratio", plan["branches"])

    def test_unknown_settings_fail(self):
        with self.assertRaises(ValueError):
            w._settings({"mistyped_threshold": 42})


if __name__ == "__main__":
    unittest.main()
