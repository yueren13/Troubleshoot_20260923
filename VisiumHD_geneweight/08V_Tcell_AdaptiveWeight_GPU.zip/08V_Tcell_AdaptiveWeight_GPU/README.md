# 08V — T-cell feature scaling, QC and adaptive gene weights

Open **08V_Tcell_AdaptiveWeight_GPU.ipynb** in the same UV/Jupyter environment used for 08T and 08U, check `PROJECT_DIR`, and choose **Run All**. The notebook supplies its helper code. `PROJECT_DIR` identifies the existing CT26 project code folder or completed 08O output folder; it does not require choosing an H5AD file. The default also checks the established same-project paths if the notebook starts in another directory.

This is an exploratory comparison for the complete existing T cell 1 + T cell 2 cohort. It tests whether rare-feature standardization, low-information cells, or the current gene weighting explain fragmentation and depth-driven clusters. It also tries two bounded, SAM-inspired adaptive updates without assigning rewards to named lineage markers.

## Comparisons

**Release 1.0.1 (18 November 2026), startup repair.** If 1.0.0 reported an adaptive CUDA parity timeout after exactly 60 seconds, open the revised notebook in the same UV/RAPIDS environment and select Restart Kernel and Run All. The separate adaptive check now allows 600 seconds, prints stages and heartbeats, and preserves partial logs on timeout. It still requires CPU/GPU agreement before starting any model. The scientific method, model settings and previously compatible data caches are unchanged. A session exposing only one GPU is supported; comparisons will run sequentially.

The five main variants use exactly the same cells in exactly the same order. The number of genes is printed and saved after preparation.

| Variant | Feature panel | Distance weighting | Main question |
|---|---|---|---|
| `selected_zscore` | Original 08U selected reference genes, with reserved companions excluded | Inverse log-expression population variance | Reproduce the effect of unit-variance scaling on the own-cell selected panel |
| `selected_centered` | Exactly the same genes | Equal weights; center only | Does avoiding rare-feature amplification reduce anomalies? |
| `selected500_centered` | Same reference panel intersected with genes detected in at least 500 T cells | Equal weights; center only | Does excluding extremely sparse genes help? |
| `broad_ratio` | Broad genes detected in at least 500 T cells | Environment-to-T ratio prior, midpoint 0.60 and power 2 | Matched static weighting baseline |
| `broad_adaptive` | Exactly the same genes as `broad_ratio` | Ratio prior plus bounded residual-coherence reward and depth-association penalty | Does adaptive reweighting improve structure beyond the static prior? |

These are own-transcriptome PCA comparisons. They do not reconstruct BANKSY neighborhood features or repeat its physical-neighbor processing. The comparison using 08U genes is therefore an own-cell feature/scaling control, rather than a rerun of the complete BANKSY model.

The sixth, separate sensitivity variant, `qc_ratio`, refits the static ratio model on cells with **at least 200 original counts and at least 100 detected common-source genes**. The gene panel and ratio weights remain frozen from the complete cohort. QC reports also show retention at 100 counts/50 genes. The main five comparisons retain every original T cell. The QC variant is explicitly skipped if every cell already passes, if it is disabled, or if fewer than 1,000 cells pass; that decision is printed and recorded.

Here, the `n_genes` field refers to the original 08O **common-gene universe**. It must not be interpreted as detected genes across every gene present in each original sample. These exploratory thresholds do not reconstruct or change the earlier atlas QC settings.

## What is fitted

Original counts are normalized using each cell's original full-source library size:

\[
x_{ig}=\log\left(1+10^4\frac{c_{ig}}{L_i}\right).
\]

PCA operates on centered columns multiplied by the square root of a nonnegative distance weight:

\[
y_{ig}=(x_{ig}-\bar{x}_g)\sqrt{w_g},\qquad
d^2(i,j)=\sum_g w_g(x_{ig}-x_{jg})^2.
\]

For the unit-variance control, \(w_g=1/\operatorname{Var}(x_g)\), using float64 population moments with implicit zeros included. Constant or numerically constant columns receive zero weight. The centering-only controls use \(w_g=1\).

For the ratio baseline, the existing environment-to-T expression ratio \(r_g\) supplies the prior:

\[
b_g=\frac{1}{1+(r_g/0.60)^2}.
\]

This ratio is an empirical contextual prior, not an estimated probability that an individual transcript is contamination. All candidate genes satisfying the broad detection and variance requirements can contribute; no named gene receives a special positive reward.

### Adaptive update

The adaptive procedure starts from the held-out `broad_ratio` graph and repeats at most two updates by default:

1. Within each sample, fit each gene's original log expression against an intercept and linear and quadratic terms in `log1p(total_counts)`. Record the variance explained by the depth terms. Use the residuals for scoring only.
2. Remove self-neighbor edges. Compare each probe cell's residual expression with the weighted mean residual expression of its expression-graph neighbors. Cells from the entire cohort remain eligible neighbors.
3. Average signed correlations equally across supported samples, then retain the positive part. Scale by the 95th percentile across candidate genes and damp low-detection evidence using \(n_g/(n_g+500)\).
4. Reward coherent residual expression and penalize depth association, apply bounded geometric damping, then recompute PCA, Harmony and the expression-neighbor graph on the entire cohort.

In symbols, let \(H_g\in[0,1]\) be the scaled, reliability-adjusted residual coherence and \(D_g\in[0,1]\) the sample-balanced depth \(R^2\). Defaults use

\[
t_g=\operatorname{clip}\left[b_g\exp\{\log(3)H_g-\log(3)D_g\},\ b_g/3,\ 3b_g\right],
\]

\[
w_g^{\rm new}=\operatorname{clip}\left[
\exp\{0.5\log w_g^{\rm old}+0.5\log t_g\},\ b_g/3,\ 3b_g
\right].
\]

The learned weights stay positive. A negative column multiplier would disappear on squaring Euclidean distances; a negative coefficient inside a squared distance would cease to define an ordinary Euclidean metric. Downweighting is expressed by a smaller positive value.

No subtype labels, marker identities, treatment groups, or desired number of clusters enter this reward. Sample IDs define technical strata. The existing T-cell selection and environment-to-T ratio prior remain contextual information. The method is therefore an exploratory, label-free update within a biologically selected cohort, not a claim of completely context-free discovery.

Residuals are never written back as corrected counts or substituted for the PCA input. Expression and original atlas labels remain unchanged. Depth association can reflect real biology, so the depth term is a bounded association penalty, not a causal correction.

## Held-out evidence

**Cd8b1, Il2ra, Ctla4, Ikzf2 and Tnfrsf18** are excluded before the first embedding in every main variant and remain absent throughout adaptive graph construction. Their original counts are retained separately for review.

Original Cd8a, Cd4 and Foxp3 assays are also shown. If those genes occur in the embedding pool, their separation is an internal consistency check; it is not independent validation. The companion panel provides a stronger internal feature-holdout check, but it is not an external dataset. In particular, this experiment has no independent held-out CD4-specific panel. Full-library normalization totals still include all original transcripts.

The report combines marker patterns with fragmentation, cluster size, sample and condition composition, and depth association. It does not select a winner merely because the UMAP looks cleaner or the number of clusters increases. A coherent false neighborhood can reinforce itself, and dropout can leave rare Foxp3-positive cells poorly resolved.

## Resources and execution

Production PCA, Harmony, nearest neighbors, Leiden and UMAP use the established RAPIDS/CuPy GPU engine. A fresh-process CUDA probe and a RAPIDS smoke test run before the large jobs. GPU initialization failure is reported rather than falling back to a long CPU run.

Independent variants are queued across up to four visible GPUs, with one worker per GPU. This uses the four GPUs for parallel comparisons; it does not combine their VRAM into one device. Adaptive updates wait for the matched static graph. An intermediate adaptive update builds the graph without a full UMAP/Leiden report, and the last update produces the complete analysis.

Adaptive scoring uses deterministic, sample-balanced probe rows: at most 6,000 per sample and 72,000 overall by default. This reduces scoring work only. PCA, Harmony, final graphs, clustering and UMAP still include every cell in the declared cohort. Dense scoring blocks contain at most 64 genes, and no dense cell-by-cell matrix is constructed. Original sparse assays are shared between compatible weight variants whenever the filesystem permits hard links.

The default **110-minute budget applies to the GPU execution stage**. Input preparation, cache validation and report generation take additional time. The notebook is intended as a bounded pilot on the existing four-GPU instance; no measured one-hour or two-hour completion time is claimed. At the budget limit, the supervisor stops only the workers it started and preserves compatible checkpoints. Rerunning with the same settings reuses completed work; a different weight vector receives a separate immutable cache.

If the environment has lost access to the GPUs, restore GPU visibility before rerunning. If memory is the limiting issue, the first focused adjustment for adaptive scoring is a smaller `gene_chunk_size`; the exact failure log should guide changes to the main GPU engine.

## Outputs and review

Outputs are placed under the resolved run's `21_tcell_feature_qc_dynamic_weights` directory unless `output_root` is explicitly supplied. Source signatures, ordered cell/gene identities and frozen feature panels are saved with the plan. Original source-normalized values are checked on deterministic rows from every sample; detection counts and float64 log-expression moments are checked across the feature cache. Older cached variance estimates are audit-only; the new moments govern this experiment.

The generated review index links to:

- Matched UMAPs and original-count marker dotplots for the scaling, detection and adaptive comparisons.
- Held-out companion evidence and neighborhood summaries.
- Cluster fragmentation and depth-association diagnostics across Leiden resolutions.
- Per-sample and per-condition QC retention, with the retained cells compared under the full-cohort model and the QC-refitted model.
- Final gene weights, reward/penalty components and the largest weight changes.

Use **`08V_return_to_chat.zip`** to return the compact reports and diagnostics. The bundle excludes large count matrices, embedding H5AD files and full per-cell CSVs. Keep the analysis outputs on the instance for later investigation.

## Method references

- Tarashansky et al., *Self-assembling manifolds in single-cell RNA sequencing data*, eLife (2019): [paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC6795480/) and [SAM repository](https://github.com/atarashansky/self-assembling-manifold).
- The adaptive code documents the SAM source revision it inspected. This notebook borrows the idea of alternating a graph and gene weights, but its residual-coherence reward, contextual prior and bounded depth penalty are a new exploratory construction rather than a reproduction of SAM.
- [RAPIDS-singlecell Harmony documentation](https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.harmony_integrate.html).
