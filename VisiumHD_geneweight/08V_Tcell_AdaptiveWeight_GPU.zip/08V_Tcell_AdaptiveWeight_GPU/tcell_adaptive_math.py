"""Bounded, label-free adaptive gene weights for the 08V T-cell pilot.

This is a SAM-inspired experiment, NOT a reproduction of SAM.  The reference
method alternates expression-neighbor graphs and neighborhood-dispersion gene
weights (Tarashansky et al., eLife 2019, doi:10.7554/eLife.48994):
https://pmc.ncbi.nlm.nih.gov/articles/PMC6795480/
Reference code inspected at commit 28c16607d469d5a9954bea7649ac50bbc16ca0a6:
https://github.com/atarashansky/self-assembling-manifold/blob/
28c16607d469d5a9954bea7649ac50bbc16ca0a6/src/samalg/sam.py

Here X is nonnegative full-library log-normalized ORIGINAL expression.  For
each sample and gene, fit an intercept plus linear and quadratic log1p(total
counts), using orthonormal columns and float64 accumulation.  D_g is the
sample-balanced R-squared for the two depth terms against an intercept-only
model.  Residuals are used ONLY to score weights: this routine does not return
corrected counts or replace the PCA input expression.

A fixed deterministic sample-balanced set of probe cells is used for scoring.
Remove graph self-edges and row-normalize its probe rows, retaining all cells
as potential expression-graph neighbors.  Compute, within each probe sample,
the Pearson correlation of each gene's residual with its neighbors' residual
mean.  Undefined/constant correlations contribute zero.  Average the signed
correlations equally over samples that have at least two supported probe rows,
then take the positive part r+; this avoids rewarding disagreement in signs.

H_g = clip(r+ / P95(r+), 0, 1) * detected_cells/(detected_cells + 500)
  (P95 is over genes with positive prior weight; a positive-score percentile
   is the fallback when the all-gene percentile is zero).
target_g = clip(prior_g * exp(log(3)*H_g - log(3)*D_g), prior_g/3, 3*prior_g)
new_g = clip(exp((1-rho)*log(old_g) + rho*log(target_g)), prior_g/3, 3*prior_g)

Weights are DISTANCE weights; multiply expression columns by sqrt(weight).
Negative expression multipliers do not penalize Euclidean distance.  Positive
weights prevent an indefinite distance metric.  Defaults use rho=0.5.

No lineage/subtype labels, marker identities, or treatment categories enter
the score; sample identifiers define technical strata.  Held-out genes
must be physically removed from X AND from the graph-building feature set by
the caller before this function is called.  The return value explicitly
records that graph independence cannot be established from a graph alone.
Graph reinforcement and true biology-depth associations remain limitations:
the depth score is an association proxy, not a causal contamination estimate.

Expression is processed in <=64-gene dense blocks by default, never a dense
cell-by-cell matrix or complete dense cell-by-gene matrix.  scipy/numpy are
the default backend.  Pass the imported cupy module as xp to run dense block
math and sparse graph products on GPU; small final metrics return to CPU.
"""

from __future__ import annotations

import time
from typing import Any

import numpy as np
import scipy.sparse as sp


METHOD_VERSION = "08V-adaptive-residual-coherence-v1"
VERSION = METHOD_VERSION


def _sample_array(sample_labels: Any) -> np.ndarray:
    labels = np.asarray(sample_labels)
    if labels.ndim != 1 or labels.size == 0:
        raise ValueError("sample_labels must be a nonempty one-dimensional array.")
    if any(v is None or (isinstance(v, (float, np.floating)) and not np.isfinite(v))
           for v in labels):
        raise ValueError("sample_labels must not contain missing values.")
    return labels.astype(str)


def _positive_integer(value: Any, name: str) -> int:
    if isinstance(value, (bool, np.bool_)) or int(value) != value or int(value) <= 0:
        raise ValueError(f"{name} must be a positive integer.")
    return int(value)


def select_probe_rows(sample_labels: Any, max_probe_per_sample: int = 6000,
                      max_probe_total: int = 72000, seed: int = 17) -> np.ndarray:
    """Select fixed, sample-balanced probe rows without examining expression.

    A small sample contributes all its cells when it has fewer than its share;
    unused capacity is distributed evenly among the remaining samples.  The
    output is sorted by original cell index and contains no duplicates.
    """
    labels = _sample_array(sample_labels)
    per_sample = _positive_integer(max_probe_per_sample, "max_probe_per_sample")
    total = _positive_integer(max_probe_total, "max_probe_total")
    names = np.unique(labels)
    if total < names.size:
        raise ValueError("max_probe_total must allow at least one probe per sample.")
    groups = [np.flatnonzero(labels == name) for name in names]
    capacity = np.array([min(g.size, per_sample) for g in groups], dtype=np.int64)
    target = min(total, int(capacity.sum()))
    allocation = np.zeros(names.size, dtype=np.int64)
    remaining = target
    while remaining:
        active = np.flatnonzero(allocation < capacity)
        step = max(1, remaining // active.size)
        for j in active:
            take = min(step, int(capacity[j] - allocation[j]), remaining)
            allocation[j] += take
            remaining -= take
            if remaining == 0:
                break
    rng = np.random.default_rng(seed)
    rows = [g if k == g.size else rng.choice(g, size=int(k), replace=False)
            for g, k in zip(groups, allocation)]
    return np.sort(np.concatenate(rows).astype(np.int64, copy=False))


def prepare_probe_graph(graph: Any, probe_rows: Any, n_cells: int):
    """Return a self-excluded, row-normalized scipy CSR probe graph.

    graph may be a full n_cells x n_cells sparse matrix or an already selected
    len(probe_rows) x n_cells matrix whose row order matches probe_rows.
    Empty nonself rows remain zero and are excluded from correlations.
    """
    rows = np.asarray(probe_rows)
    if rows.ndim != 1 or rows.size == 0 or not np.issubdtype(rows.dtype, np.integer):
        raise ValueError("probe_rows must be a nonempty integer vector.")
    rows = rows.astype(np.int64, copy=False)
    if rows.min() < 0 or rows.max() >= n_cells or np.unique(rows).size != rows.size:
        raise ValueError("probe_rows must contain unique valid cell indices.")
    if not sp.issparse(graph):
        if hasattr(graph, "get"):
            graph = graph.get()
        else:
            raise TypeError("graph must be a sparse matrix; dense graphs are rejected.")
    if graph.ndim != 2 or graph.shape[1] != n_cells:
        raise ValueError("graph must have one column per cell.")
    if graph.shape[0] == n_cells:
        a = graph.tocsr()[rows, :].astype(np.float32, copy=True)
    elif graph.shape[0] == rows.size:
        a = graph.tocsr().astype(np.float32, copy=True)
    else:
        raise ValueError("graph row count must be n_cells or the number of probe rows.")
    a.sum_duplicates()
    if not np.isfinite(a.data).all() or np.any(a.data < 0):
        raise ValueError("graph edge weights must be finite and nonnegative.")
    row_for_edge = np.repeat(np.arange(rows.size), np.diff(a.indptr))
    a.data[a.indices == rows[row_for_edge]] = 0.0
    a.eliminate_zeros()
    degree = np.asarray(a.sum(axis=1), dtype=np.float64).reshape(-1)
    valid = degree > 0
    inv = np.zeros(degree.size, dtype=np.float64)
    inv[valid] = 1.0 / degree[valid]
    a = a.multiply(inv[:, None]).astype(np.float32).tocsr()
    a.sort_indices()
    return a, valid


def _depth_groups(labels: np.ndarray, counts: np.ndarray, variance_epsilon: float):
    """Orthonormal depth columns per sample, computed once on CPU."""
    result = []
    for sample in np.unique(labels):
        indices = np.flatnonzero(labels == sample)
        z = np.log1p(counts[indices]).astype(np.float64)
        z -= z.mean()
        columns = []
        for v in (z, z * z):
            v = v - v.mean()
            for q in columns:
                v = v - q * np.dot(q, v)
            # A second orthogonalization pass protects nearly constant depth.
            v = v - v.mean()
            for q in columns:
                v = v - q * np.dot(q, v)
            norm = np.linalg.norm(v)
            if norm * norm > variance_epsilon * indices.size:
                columns.append(v / norm)
        q = np.column_stack(columns) if columns else np.empty((indices.size, 0))
        result.append({"sample": str(sample), "indices": indices, "q": q})
    return result


def _cpu(value: Any, xp: Any) -> np.ndarray:
    return np.asarray(value) if xp is np else np.asarray(xp.asnumpy(value))


def _block(X: Any, start: int, stop: int, xp: Any):
    piece = X[:, start:stop]
    if sp.issparse(piece):
        piece = piece.toarray()
    elif hasattr(piece, "toarray"):
        piece = piece.toarray()
    if xp is np:
        if hasattr(piece, "get"):
            piece = piece.get()
        return np.array(piece, dtype=np.float32, copy=True)
    return xp.array(piece, dtype=xp.float32, copy=True)


def update_distance_weights(base_weights: Any, current_weights: Any,
                            coherence: Any, depth_r2: Any, detected_cells: Any,
                            *, damping: float = 0.5, reward_max: float = 3.0,
                            penalty_max: float = 3.0, reliability_count: float = 500.0):
    """Apply the bounded positive-distance update to already computed scores."""
    base = np.asarray(base_weights, dtype=np.float64)
    old = base.copy() if current_weights is None else np.asarray(current_weights, dtype=np.float64)
    r = np.asarray(coherence, dtype=np.float64)
    d = np.asarray(depth_r2, dtype=np.float64)
    detected = np.asarray(detected_cells, dtype=np.float64)
    if any(a.ndim != 1 or a.shape != base.shape for a in (base, old, r, d, detected)):
        raise ValueError("Every per-gene vector must have the same one-dimensional shape.")
    if not all(np.isfinite(a).all() for a in (base, old, r, d, detected)):
        raise ValueError("Weight inputs and scores must be finite.")
    if np.any(base < 0) or np.any(old < 0) or np.any(detected < 0):
        raise ValueError("Prior/current weights and detected counts must be nonnegative.")
    active = base > 0
    if np.any(old[active] <= 0) or np.any(old[~active] != 0):
        raise ValueError("Current weights must be positive exactly where prior weights are positive.")
    if not 0 <= damping <= 1 or reward_max < 1 or penalty_max < 1 or reliability_count < 0:
        raise ValueError("Invalid damping, reward/penalty bound, or reliability count.")
    if not np.isfinite([damping, reward_max, penalty_max, reliability_count]).all():
        raise ValueError("Weight update parameters must be finite.")
    r = np.clip(r, -1, 1)
    d = np.clip(d, 0, 1)
    positive = np.maximum(r, 0)
    eligible = positive[active]
    normalizer = float(np.quantile(eligible, 0.95)) if eligible.size else 0.0
    fallback = False
    if normalizer <= 0 and np.any(eligible > 0):
        normalizer = float(np.quantile(eligible[eligible > 0], 0.95))
        fallback = True
    normalized = np.clip(positive / normalizer, 0, 1) if normalizer > 0 else np.zeros_like(positive)
    reliability = np.divide(detected, detected + reliability_count,
                            out=np.zeros_like(detected), where=(detected + reliability_count) > 0)
    reward = normalized * reliability
    reward[~active] = 0
    lo, hi = base / penalty_max, base * reward_max
    target = np.clip(base * np.exp(np.log(reward_max) * reward - np.log(penalty_max) * d), lo, hi)
    new = np.zeros_like(base)
    new[active] = np.exp((1 - damping) * np.log(old[active]) + damping * np.log(target[active]))
    new = np.clip(new, lo, hi)
    return {
        "base_weight": base, "old_weight": old, "depth_r2": d,
        "coherence": r, "coherence_positive": positive,
        "coherence_normalized": normalized, "reliability": reliability,
        "reward": reward, "target_weight": target, "new_weight": new,
        "column_multiplier": np.sqrt(new),
        "diagnostics": {"coherence_p95": normalizer,
                        "positive_only_percentile_fallback": fallback,
                        "n_current_outside_bounds": int(np.count_nonzero((old < lo) | (old > hi)))},
    }


def score_adaptive_weights(
    X: Any, graph: Any, sample_labels: Any, total_counts: Any, base_weights: Any,
    *, current_weights: Any = None, detected_cells: Any = None,
    probe_rows: Any = None, feature_names: Any = None, gene_chunk_size: int = 64,
    max_probe_per_sample: int = 6000, max_probe_total: int = 72000,
    seed: int = 17, damping: float = 0.5, reward_max: float = 3.0,
    penalty_max: float = 3.0, reliability_count: float = 500.0,
    variance_epsilon: float = 1e-10, xp: Any = None,
    verbose: bool = True, progress_every: int = 20,
) -> dict:
    """Score all supplied genes in blocks and return CPU arrays plus diagnostics.

    X may be NumPy/SciPy or a CuPy dense/sparse array; graph is sparse.  The
    caller owns all upstream normalization, feature/heldout exclusion, and
    graph construction.  Neither input matrix nor graph is modified.  Pass
    feature_names to retain an explicit output-to-gene mapping.
    """
    started = time.monotonic()
    xp = np if xp is None else xp
    if not (xp is np or getattr(xp, "__name__", "").split(".")[0] == "cupy"):
        raise TypeError("xp must be numpy or the imported cupy module.")
    labels = _sample_array(sample_labels)
    if len(X.shape) != 2 or X.shape[0] != labels.size or X.shape[1] == 0:
        raise ValueError("X must have one row per labeled cell and at least one candidate gene.")
    n_cells, n_genes = map(int, X.shape)
    chunk = _positive_integer(gene_chunk_size, "gene_chunk_size")
    progress_every = _positive_integer(progress_every, "progress_every")
    if not np.isfinite(variance_epsilon) or variance_epsilon <= 0:
        raise ValueError("variance_epsilon must be finite and positive.")
    counts = np.asarray(total_counts, dtype=np.float64)
    if counts.shape != (n_cells,) or not np.isfinite(counts).all() or np.any(counts < 0):
        raise ValueError("total_counts must be one finite nonnegative full-library total per cell.")
    base = np.asarray(base_weights, dtype=np.float64)
    if base.shape != (n_genes,):
        raise ValueError("base_weights must have one entry per candidate gene.")
    if feature_names is not None and np.asarray(feature_names).shape != (n_genes,):
        raise ValueError("feature_names must have one entry per candidate gene.")
    supplied_detected = detected_cells is not None
    detected = np.zeros(n_genes, dtype=np.float64) if not supplied_detected else np.asarray(detected_cells, dtype=np.float64).copy()
    if detected.shape != (n_genes,) or not np.isfinite(detected).all() or np.any((detected < 0) | (detected > n_cells)):
        raise ValueError("detected_cells must be between zero and n_cells for every gene.")
    # Reject invalid weights/settings before allocating expression/graph blocks.
    update_distance_weights(base, current_weights, np.zeros(n_genes), np.zeros(n_genes), detected,
                            damping=damping, reward_max=reward_max,
                            penalty_max=penalty_max, reliability_count=reliability_count)
    rows = select_probe_rows(labels, max_probe_per_sample, max_probe_total, seed) if probe_rows is None else np.asarray(probe_rows)
    a, supported = prepare_probe_graph(graph, rows, n_cells)
    rows = rows.astype(np.int64, copy=False)
    groups = _depth_groups(labels, counts, variance_epsilon)
    if xp is np:
        a_backend = a
    else:
        from cupyx.scipy.sparse import csr_matrix
        a_backend = csr_matrix(a)
    probe_backend = xp.asarray(rows)
    backend_groups = []
    for group in groups:
        p = np.flatnonzero((labels[rows] == group["sample"]) & supported)
        backend_groups.append({**group, "index_backend": xp.asarray(group["indices"]),
                               "q_backend": xp.asarray(group["q"], dtype=xp.float64),
                               "probe_backend": xp.asarray(p), "n_probe": int(p.size)})
    depth = np.zeros(n_genes, dtype=np.float64)
    correlations = np.zeros(n_genes, dtype=np.float64)
    n_valid_depth = np.zeros(n_genes, dtype=np.int32)
    n_valid_coherence = np.zeros(n_genes, dtype=np.int32)
    n_probe_samples = sum(g["n_probe"] >= 2 for g in backend_groups)
    for start in range(0, n_genes, chunk):
        stop = min(n_genes, start + chunk)
        residual = _block(X, start, stop, xp)
        if not bool(_cpu(xp.isfinite(residual).all(), xp)) or bool(_cpu((residual < 0).any(), xp)):
            raise ValueError("X must be finite, nonnegative original log-normalized expression.")
        if not supplied_detected:
            detected[start:stop] = _cpu(xp.count_nonzero(residual > 0, axis=0), xp)
        d_sum = xp.zeros(stop - start, dtype=xp.float64)
        for group in backend_groups:
            ix = group["index_backend"]
            own = residual[ix, :].astype(xp.float64)
            centered = own - own.mean(axis=0)
            sst = xp.sum(centered * centered, axis=0, dtype=xp.float64)
            q = group["q_backend"]
            if q.shape[1]:
                coefficients = q.T @ centered
                fitted = q @ coefficients
                explained = xp.sum(coefficients * coefficients, axis=0, dtype=xp.float64)
                errors = centered - fitted
            else:
                explained = xp.zeros(stop - start, dtype=xp.float64)
                errors = centered
            valid = sst > variance_epsilon * ix.size
            ds = xp.where(valid, xp.clip(explained / xp.maximum(sst, variance_epsilon), 0, 1), 0)
            d_sum += ds
            n_valid_depth[start:stop] += _cpu(valid, xp).astype(np.int32)
            residual[ix, :] = errors.astype(xp.float32)
        # Every sample has equal weight; undefined depth effects contribute 0.
        depth[start:stop] = _cpu(d_sum / len(backend_groups), xp)
        own_probe = residual[probe_backend, :]
        neighbor_probe = a_backend @ residual
        r_sum = xp.zeros(stop - start, dtype=xp.float64)
        for group in backend_groups:
            if group["n_probe"] < 2:
                continue
            ix = group["probe_backend"]
            p = own_probe[ix, :].astype(xp.float64)
            q = neighbor_probe[ix, :].astype(xp.float64)
            p -= p.mean(axis=0)
            q -= q.mean(axis=0)
            ps = xp.sum(p * p, axis=0, dtype=xp.float64)
            qs = xp.sum(q * q, axis=0, dtype=xp.float64)
            valid = (ps > variance_epsilon * ix.size) & (qs > variance_epsilon * ix.size)
            denominator = xp.sqrt(ps * qs)
            r = xp.where(valid, xp.sum(p * q, axis=0, dtype=xp.float64) / xp.maximum(denominator, variance_epsilon), 0)
            r_sum += xp.clip(r, -1, 1)
            n_valid_coherence[start:stop] += _cpu(valid, xp).astype(np.int32)
        correlations[start:stop] = _cpu(r_sum / max(n_probe_samples, 1), xp)
        if verbose and (((start // chunk) + 1) % progress_every == 0 or stop == n_genes):
            print(f"08V adaptive scores: {stop:,}/{n_genes:,} genes; "
                  f"{time.monotonic() - started:.1f} seconds; "
                  f"{'CPU' if xp is np else 'GPU'} block math", flush=True)
    out = update_distance_weights(base, current_weights, correlations, depth, detected,
                                  damping=damping, reward_max=reward_max,
                                  penalty_max=penalty_max, reliability_count=reliability_count)
    out.update({"detected_cells": detected.astype(np.int64), "probe_rows": rows,
                "n_samples_depth_informative": n_valid_depth,
                "n_samples_coherence_informative": n_valid_coherence})
    if feature_names is not None:
        out["gene"] = np.asarray(feature_names).astype(str)
    out["diagnostics"].update({
        "method_version": METHOD_VERSION, "backend": "numpy" if xp is np else "cupy",
        "n_cells": n_cells, "n_genes": n_genes, "n_samples": len(groups),
        "n_probe_rows": int(rows.size), "n_supported_probe_rows": int(supported.sum()),
        "n_zero_nonself_neighbor_probe_rows": int((~supported).sum()),
        "n_probe_samples": int(n_probe_samples), "probe_graph_nnz": int(a.nnz),
        "gene_chunk_size": chunk, "seed": int(seed), "damping": float(damping),
        "reward_max": float(reward_max), "penalty_max": float(penalty_max),
        "reliability_count": float(reliability_count),
        "depth_model": "within-sample intercept + log1p(full counts) + its square",
        "score_aggregation": "equal sample weights; constant scores contribute zero",
        "self_edges_used": False, "biological_labels_used": False,
        "sample_labels_used": True,
        "heldout_exclusion": "caller must exclude heldout genes from X and upstream graph fitting",
        "graph_independence_verified": False,
        "sample_probes": [{"sample": g["sample"], "n_cells": int(g["indices"].size),
                           "n_supported_probes": g["n_probe"], "depth_rank": int(g["q"].shape[1])}
                          for g in backend_groups],
        "elapsed_seconds": time.monotonic() - started,
    })
    return out
