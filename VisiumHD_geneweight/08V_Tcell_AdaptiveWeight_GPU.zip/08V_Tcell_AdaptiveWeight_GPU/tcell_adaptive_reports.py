"""08V original-count reviews, weight diagnostics and compact return bundles.

All marker assays retain their original count scale and full-library denominator.
The QC comparison explicitly evaluates both models on the same retained cells.
No expression matrix, per-cell export or large model is added to the return ZIP.
"""
from __future__ import annotations

from collections import OrderedDict
import gc
import html
import json
from pathlib import Path
import shutil
import time
import zipfile

import numpy as np
import pandas as pd

import tcell_weighted_workflow as base
import tcell_weighted_review as review
import tcell_positive_review as companions
import tcell_positive_workflow as loader

VERSION = "08V-reports-1.0.0"
GROUPS = OrderedDict([
    ("feature_scaling", ("selected_zscore", "selected_centered", "selected500_centered")),
    ("adaptive", ("broad_ratio", "broad_adaptive")),
])


def _json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _effective_features(result):
    table = result.var.copy()
    table["gene"] = result.var_names.astype(str)
    if "applied_distance_weight" in table:
        table["weight"] = table["applied_distance_weight"].to_numpy(float)
    if "weight" not in table:
        raise ValueError("Completed embedding lacks applied gene-weight provenance.")
    return table.reset_index(drop=True)


def _depth_fragmentation(methods, original_obs, keys, group):
    rows = []
    samples = original_obs["sample_id"].astype(str).to_numpy()
    depth = np.log1p(original_obs["total_counts"].to_numpy(float))
    for name, method in methods.items():
        frame = method.obs if hasattr(method, "obs") else method["obs"]
        for key in keys:
            labels = frame[key].astype(str).to_numpy()
            sizes = pd.Series(labels).value_counts()
            within = []
            for sample in pd.unique(samples):
                ix = np.flatnonzero(samples == sample)
                codes, levels = pd.factorize(labels[ix])
                if len(ix) > 1 and np.var(depth[ix]) > 0:
                    within.append(review._eta_squared(depth[ix], codes, len(levels)))
            rows.append({"review_group": group, "method": name, "clustering": key,
                         "n_cells": len(frame), "n_clusters": len(sizes),
                         "n_clusters_under_1000_cells": int((sizes < 1000).sum()),
                         "fraction_cells_in_clusters_under_1000": float(sizes[sizes < 1000].sum() / len(frame)),
                         "sample_balanced_log_depth_eta_squared": float(np.mean(within)) if within else np.nan,
                         "n_samples_with_variable_depth": len(within)})
    return pd.DataFrame(rows)


def weight_diagnostics(run_root, output_dir):
    """Describe the learned metric; labels in these plots are post-fit reviews."""
    run_root, output = Path(run_root), Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    source = run_root / "broad_adaptive" / "final_gene_weights.csv"
    if not source.is_file():
        return {"status": "unavailable", "reason": "No completed adaptive weight table."}
    table = pd.read_csv(source)
    required = {"gene", "new_weight", "ratio_prior_weight", "depth_r2", "coherence", "multiplier_vs_ratio"}
    if not required.issubset(table):
        raise ValueError(f"Adaptive weight table lacks {sorted(required - set(table))}")
    table.to_csv(output / "final_gene_weights.csv", index=False)
    ranked = table.sort_values("multiplier_vs_ratio", ascending=False)
    pd.concat([ranked.head(30).assign(direction="largest increase"),
               ranked.tail(30).assign(direction="largest decrease")]).to_csv(output / "weight_extremes.csv", index=False)
    requested = list(dict.fromkeys(review.ALL_MARKERS))
    audit = pd.DataFrame({"gene": requested}).merge(table, on="gene", how="left")
    audit["in_learned_feature_pool"] = audit["new_weight"].notna()
    audit.to_csv(output / "marker_weight_review.csv", index=False)
    plt = review._plot_style()
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.8))
    factor = table["multiplier_vs_ratio"].to_numpy(float)
    axes[0].hist(factor, bins=60, color="#386e9b", alpha=.85)
    axes[0].axvline(1, color="#4a4a4a", linestyle="--", linewidth=1)
    axes[0].set(xlabel="Final weight / ratio prior", ylabel="Genes", title="Bounded adaptive changes")
    color = np.log2(factor)
    limit = max(float(np.max(np.abs(color))), 0.05)
    points = axes[1].scatter(table["depth_r2"], table["coherence"], c=color, cmap="coolwarm",
                             vmin=-limit, vmax=limit, s=5, alpha=.5, rasterized=True)
    axes[1].set(xlabel="Within-sample depth R²", ylabel="Residual neighborhood correlation",
                title="Reward and depth association")
    fig.colorbar(points, ax=axes[1], label="log₂(final / prior)")
    axes[2].scatter(table["ratio_prior_weight"], table["new_weight"], c=color, cmap="coolwarm",
                    vmin=-limit, vmax=limit, s=5, alpha=.5, rasterized=True)
    axes[2].set(xscale="log", yscale="log", xlabel="Ratio-prior distance weight",
                ylabel="Final distance weight", title="Weight applied before PCA")
    extent = [float(min(table.ratio_prior_weight.min(), table.new_weight.min())),
              float(max(table.ratio_prior_weight.max(), table.new_weight.max()))]
    axes[2].plot(extent, extent, color="#666666", linewidth=.8, linestyle="--")
    for gene in ("Cd4", "Cd8a", "Foxp3", "Mki67", "Epcam", "Lyz2"):
        found = table[table.gene == gene]
        if len(found):
            row = found.iloc[0]
            axes[1].annotate(gene, (row.depth_r2, row.coherence), fontsize=8,
                             xytext=(4, 4), textcoords="offset points")
    fig.suptitle("Adaptive metric diagnostics · annotated genes were not manually rewarded", fontsize=13)
    fig.tight_layout()
    review._save_figure(fig, output / "adaptive_weight_diagnostics.png", plt)
    summary = {"status": "complete", "n_genes": len(table),
               "multiplier_quantiles": {str(q): float(np.quantile(factor, q)) for q in (0, .05, .5, .95, 1)},
               "n_increased_over_10_percent": int((factor > 1.1).sum()),
               "n_decreased_over_10_percent": int((factor < 1/1.1).sum()),
               "interpretation": "These are feature-distance weights, not corrected counts or proof of biological relevance."}
    base.save_json(output / "weight_summary.json", summary)
    return summary


def build_reports(plan, branches, run_root, *, primary_cluster_key="leiden_0.4",
                  cluster_keys=("leiden_0.2", "leiden_0.4", "leiden_0.6"),
                  max_plot_cells=100000, max_clusters_per_page=35):
    """Build matched reviews in small groups to bound peak memory and page width."""
    import anndata as ad
    started = time.monotonic()
    root = Path(run_root).resolve()
    out = root / "review"
    out.mkdir(parents=True, exist_ok=True)
    log, counts, genes, obs = loader.load_marker_data(plan["marker_cache_dir"])
    keys = list(cluster_keys)
    if primary_cluster_key not in keys:
        raise ValueError("Primary clustering must be among the reviewed cluster keys.")
    summaries, comparison, fragment = {}, [], []
    for group, names in GROUPS.items():
        print(f"08V original-count review: {group}", flush=True)
        methods = loader.load_methods(branches, obs, names)
        directory = out / group
        summaries[group] = review.build_review(log, counts, genes, obs, methods, directory,
            cluster_keys=keys, primary_cluster_key=primary_cluster_key,
            max_plot_cells=max_plot_cells, max_clusters_per_page=max_clusters_per_page,
            normalization_target_sum=plan["settings"]["target_sum"])
        tables = {name: _effective_features(result) for name, result in methods.items()}
        companions.build_companion_review(counts, log, genes, obs, methods, tables,
            directory / "companions", primary_cluster_key=primary_cluster_key,
            heldout_genes=plan["heldout_genes"], normalization_target_sum=plan["settings"]["target_sum"])
        comparison.append(pd.read_csv(directory / "method_comparison.csv").assign(review_group=group))
        fragment.append(_depth_fragmentation(methods, obs, keys, group))
        del methods, tables
        gc.collect()
    qc_note = "The separate QC model was not run: " + plan["qc"]["status"]
    if "qc_ratio" in branches:
        rows = np.load(plan["qc"]["selected_rows_path"], allow_pickle=False)
        retained = obs.iloc[rows].copy()
        full = ad.read_h5ad(branches["broad_ratio"])
        if not full.obs_names.equals(obs.index):
            raise ValueError("QC control model has a different full-cohort row order.")
        # No induced-subgraph comparison: retaining nodes changes its degrees.
        control = {"obs": full.obs.iloc[rows].copy(),
                   "obsm": {"X_umap": np.asarray(full.obsm["X_umap"])[rows].copy()}, "obsp": {}}
        del full
        fitted = ad.read_h5ad(branches["qc_ratio"])
        if not fitted.obs_names.equals(retained.index):
            raise ValueError("QC refit and original marker rows disagree.")
        refit = {"obs": fitted.obs, "obsm": {"X_umap": np.asarray(fitted.obsm["X_umap"])}, "obsp": {}}
        methods = OrderedDict([("full_fit_retained_cells", control), ("qc_refit", refit)])
        directory = out / "qc"
        summaries["qc"] = review.build_review(log[rows], counts[rows], genes, retained, methods, directory,
            cluster_keys=keys, primary_cluster_key=primary_cluster_key,
            max_plot_cells=max_plot_cells, max_clusters_per_page=max_clusters_per_page,
            normalization_target_sum=plan["settings"]["target_sum"])
        comparison.append(pd.read_csv(directory / "method_comparison.csv").assign(review_group="qc"))
        fragment.append(_depth_fragmentation(methods, retained, keys, "qc"))
        qc_note = ("QC plots compare the same retained cells: their original full-cohort fit versus a new fit after QC. "
                   "Feature set and ratio weights are frozen before QC. Graph concordance is omitted for both QC panels "
                   "because a retained-node subgraph and a newly fitted graph would have different neighbor support.")
        del methods, fitted, control, refit
        gc.collect()
    metric = pd.concat(comparison, ignore_index=True)
    extra = pd.concat(fragment, ignore_index=True)
    metric = metric.merge(extra, on=["review_group", "method", "clustering", "n_cells", "n_clusters"], validate="one_to_one")
    metric.to_csv(out / "method_comparison_all.csv", index=False)
    shutil.copy2(plan["qc"]["retention_path"], out / "qc_retention.csv")
    weights = weight_diagnostics(root, out / "weights")
    summary = {"version": VERSION, "n_cells": len(obs), "groups": list(summaries),
               "qc_note": qc_note, "elapsed_seconds": time.monotonic() - started,
               "primary_cluster_key": primary_cluster_key, "all_statistics_use_original_counts": True,
               "score_training_uses_marker_labels": False, "weight_diagnostics": weights,
               "index_path": str(out / "index.html"), "comparison_path": str(out / "method_comparison_all.csv")}
    base.save_json(out / "review_manifest.json", summary)
    links = []
    for group in summaries:
        links.append(f'<li><a href="{group}/review.html">{html.escape(group)}: UMAPs, original-marker dotplots and tables</a></li>')
        if group != "qc":
            links.append(f'<li><a href="{group}/companions/companion_review.html">{html.escape(group)}: held-out companion check</a></li>')
    focus = metric[metric.clustering == primary_cluster_key]
    fields = ["review_group", "method", "n_cells", "n_clusters", "fraction_cells_in_clusters_under_1000",
              "log_depth_eta_squared", "sample_balanced_log_depth_eta_squared", "observed_evidence_cluster_purity"]
    document = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>08V T-cell feature, QC and adaptive-weight review</title><style>body{{font:16px/1.55 system-ui;max-width:1400px;margin:32px auto;padding:20px;color:#18334b}}table{{border-collapse:collapse;display:block;overflow:auto}}td,th{{padding:7px;border:1px solid #ccd6e0}}img{{max-width:100%}}a{{color:#146a97}}</style></head><body>
<h1>08V: feature selection, scaling, QC and adaptive weights</h1><p>{len(obs):,} original T cell 1 + T cell 2 observations. Main comparisons retain all cells. Marker statistics use original, unweighted counts and the original full-library normalization denominator.</p>
<h2>Read the matched comparisons</h2><ul>{''.join(links)}</ul>
<p><strong>QC interpretation:</strong> {html.escape(qc_note)}</p>
<h2>Primary clustering diagnostics</h2>{focus[fields].to_html(index=False, float_format=lambda x: f'{x:.4g}', escape=True)}
<p>There is no automatic winning score. Fragmentation, depth association, sample and treatment composition, and held-out marker agreement must be considered together. More clusters can increase apparent purity mechanically. Depth can also reflect real biology.</p>
<h2>Learned gene weights</h2><a href="weights/adaptive_weight_diagnostics.png"><img src="weights/adaptive_weight_diagnostics.png" alt="Adaptive gene weight diagnostics"></a>
<p><a href="weights/final_gene_weights.csv">All learned weights and score components</a> · <a href="weights/marker_weight_review.csv">Post-fit marker audit</a> · <a href="qc_retention.csv">QC retention by sample and condition</a> · <a href="method_comparison_all.csv">All resolution diagnostics</a></p>
<h2>Scope</h2><p>This is a bounded SAM-inspired experiment. It reweights a gene-space distance before PCA, then runs GPU Harmony, neighbors, Leiden and UMAP. It does not estimate corrected transcript counts, use a handpicked positive-marker reward, or alter the global atlas labels. The graph used to learn coherence is an expression-neighbor graph. Existing environment-to-T ratios provide the contextual prior; no new physical-neighbor features are built.</p>
<p>Cd8b1, Il2ra, Ctla4, Ikzf2 and Tnfrsf18 are excluded before the first embedding in every comparison. Their original assays are used only for review. This is internal feature holdout, not external validation; original full-library size includes all transcripts. CD4 identity has no independent companion panel here.</p>
</body></html>'''
    (out / "index.html").write_text(document, encoding="utf-8")
    print(f"08V review: {out / 'index.html'}", flush=True)
    return summary


def make_return_bundle(plan, run_root=None, destination=None, *, max_bytes=25_000_000, error=None):
    """Save a bounded diagnostics/figure ZIP; never include per-cell/model arrays."""
    plan_dir = Path(plan["plan_dir"]).resolve()
    root = Path(run_root).resolve() if run_root else plan_dir
    target = Path(destination) if destination else root / "08V_return_to_chat.zip"
    target.parent.mkdir(parents=True, exist_ok=True)
    candidates = []
    seen = set()
    def add(path, archive_name, priority):
        path = Path(path)
        if path.is_file() and archive_name not in seen:
            seen.add(archive_name)
            candidates.append((priority, path, archive_name))
    for name in ("plan.json", "preparation_spec.json", "source_audit.json", "frozen_feature_panels.csv"):
        add(plan_dir / name, "preparation/" + name, 0)
    add(plan["qc"]["retention_path"], "preparation/qc_retention.csv", 0)
    for name in ("gpu_settings.json", "gpu_runtime.json", "adaptive_settings.json", "launch.json", "comparison_complete.json", "launch_error.json"):
        add(root / name, "runtime/" + name, 0)
    for name in plan.get("branches", {}):
        folder = root / name
        for file in ("result.json", "adaptive_metadata.json", "final_gene_weights.csv", "worker_error.json", "score_probe_sample_counts.csv"):
            add(folder / file, f"runtime/{name}/{file}", 0)
        for path in sorted(folder.glob("round_*/score_complete.json")):
            add(path, "runtime/" + str(path.relative_to(root)), 0)
        for path in sorted(folder.glob("round_*/gene_weight_update.csv")):
            add(path, "runtime/" + str(path.relative_to(root)), 1)
        for metadata_name in ("metadata.json", "run_metadata.json"):
            for path in folder.rglob(metadata_name):
                add(path, "runtime/" + str(path.relative_to(root)), 1)
    review_root = root / "review"
    report_manifest = review_root / "review_manifest.json"
    primary_key = _json(report_manifest).get("primary_cluster_key", "leiden_0.4") if report_manifest.is_file() else "leiden_0.4"
    primary_filename_key = review._slug(primary_key)
    excluded = {"observed_marker_evidence.csv.gz", "umap_display_cell_ids.csv.gz",
                "cell_qc_flags.csv.gz", "final_gene_weights.csv"}
    for path in sorted(review_root.rglob("*")) if review_root.is_dir() else []:
        if not path.is_file() or path.name in excluded:
            continue
        relative = "review/" + str(path.relative_to(review_root))
        if path.name.endswith((".csv", ".csv.gz", ".json")):
            add(path, relative, 0 if path.name in {"method_comparison_all.csv", "heldout_exclusion_audit.csv", "heldout_neighbor_summary.csv", "cluster_summary.csv"} else 1)
        elif path.suffix == ".png":
            priority = 2
            if "adaptive/" in relative or "weights/" in relative:
                priority = 1
            if "dotplot_" in path.name and (primary_filename_key not in path.name or "gene_scaled" in path.name):
                priority = 4
            add(path, relative, priority)
    included, omitted, logs = [], [], {}
    for path in sorted(root.glob("*/console.log")):
        logs["runtime/" + str(path.relative_to(root))] = path.read_text(errors="replace")[-60000:]
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for priority, path, name in sorted(candidates, key=lambda item: (item[0], item[2])):
            # Conservative uncompressed budgeting guarantees the final ZIP bound.
            remaining = max_bytes - archive.fp.tell() - 600000
            if path.stat().st_size > max(remaining, 0):
                omitted.append({"path": name, "bytes": path.stat().st_size})
                continue
            archive.write(path, name)
            included.append(name)
        for name, content in logs.items():
            if archive.fp.tell() + len(content.encode()) + 10000 < max_bytes:
                archive.writestr(name, content)
                included.append(name)
        info = {"version": VERSION, "included_files": included, "omitted_for_size": omitted,
                "full_results_on_instance": str(root), "maximum_bytes": max_bytes,
                "original_expression_and_per_cell_arrays_excluded": True,
                "error": str(error) if error else None}
        archive.writestr("bundle_manifest.json", json.dumps(info, indent=2))
        links = ''.join(f'<li><a href="{html.escape(name)}">{html.escape(name)}</a></li>' for name in included if name.endswith((".csv", ".csv.gz", ".json")))
        figures = ''.join(f'<h3>{html.escape(name)}</h3><img loading="lazy" src="{html.escape(name)}" alt="{html.escape(name)}">' for name in included if name.endswith(".png"))
        archive.writestr("index.html", '<!doctype html><html><head><meta charset="utf-8"><title>08V return bundle</title><style>body{font:16px/1.5 system-ui;max-width:1400px;margin:auto;padding:24px}img{max-width:100%}a{color:#176a94}</style></head><body><h1>08V compact review</h1><p>All statistics use original marker assays. This compact package omits large matrices and per-cell exports; the full reports remain in the run folder. See bundle_manifest.json for any size-based omissions.</p><h2>Tables and provenance</h2><ul>' + links + '</ul>' + figures + '</body></html>')
    if target.stat().st_size > max_bytes:
        raise RuntimeError(f"Return bundle exceeded its size bound: {target}")
    print(f"Return to chat: {target} ({target.stat().st_size / 1e6:.1f} MB)", flush=True)
    return target
