# 08V validation and practical limits

## Release 1.0.1, 18 November 2026: adaptive GPU startup

The supplied 1.0.0 failure archive shows a passed CUDA arithmetic check and a successful RAPIDS operations check. A separate adaptive parity worker hit its hard 60-second deadline. The old archive has no intermediate adaptive logs and no numerical result, so it cannot distinguish slow cold startup from a stall at a specific scoring operation. The failed invocation never reached input preparation.

1.0.1 gives that worker 600 seconds by default, streams flushed stage messages and preserves both output streams and a stage/status receipt on timeout or failure. The separate 110-minute experiment budget, weight equations, numerical tolerance (2e-5 absolute), and cache identities are unchanged. CPU-only results cannot release this gate.

Seven focused startup regression tests passed using controlled subprocesses. They cover delayed success, timeout and user interruption with stage/log retention and child cleanup, an explicitly reported numerical disagreement, malformed output, and a claimed pass without valid measurements. Real EC2 parity of the adaptive scorer is still unverified; the revised notebook tests it before opening the project data. The original GPU and RAPIDS checks that passed on the user's machine are distinct from this check.

## Previous release: 1.0.0, 17 November 2026.

## What was tested

The complete synthetic CPU validation suite passed 43 tests in 29.37 seconds, followed by an additional export-priority regression check for primary resolutions 0.4 and 0.6. All nine notebook code cells executed on a small synthetic H5AD fixture.

The synthetic notebook test ran actual input preparation, immutable cache construction, two adaptive mathematical updates, all original-count marker reviews, the same-retained-cell QC comparison, report copying and ZIP creation. Only CUDA preflight, GPU embedding computation and GPU scheduling were replaced by explicitly identified QA adapters. The synthetic embeddings are test fixtures, not real UMAPs or biological findings.

Covered checks include:

- Agreement of the adaptive score with an independent dense least-squares/correlation reference; gene-block equivalence; self-edge removal; bounded damping; rare-gene reliability; constant/sample-only neutrality; response to independent synthetic biological and depth-only signals.
- Fixed original cell order, source signatures, original-count normalization denominators, exact float64 sparse moments, and feature detection counts.
- Physical exclusion of Cd8b1, Il2ra, Ctla4, Ikzf2 and Tnfrsf18 before every initial and adaptive embedding, while retaining their original marker assays.
- Matched feature panels; unit-variance versus centered representations; frozen features across the separate QC refit; aligned retained-cell markers.
- Immutable ancestor caches, reproducible cache identity, compatible resume, and final learned-weight cache provenance.
- CUDA visibility mapping, rejection of failed GPU preflight reports, static/adaptive dependency ordering, and captured worker failures without CPU substitution in production.
- Original counts in all marker summaries; three Leiden resolutions; relative, existing HTML and notebook download links; readable figures; correct 08V titles.
- Exclusion of large matrices and per-cell exports from the return bundle; 25 MB and deliberately tight 1 MB ZIP limits with explicit omission manifests; priority for the primary raw-expression dotplots.

The full synthetic return bundle was approximately 6.38 MB. This measures the test fixture's output only; the production return bundle remains capped at 25 MB and can omit lower-priority figures. Complete reports remain on the instance.

## GPU validation boundary

No actual CUDA run, 590,247-cell training run, or EC2 performance benchmark was available in the authoring environment. No improvement in biological clustering is claimed before the experiment is run on the real data.

The notebook uses the existing GPU PCA/Harmony/neighbor/Leiden/UMAP engine. At startup it also executes a new tiny CPU-versus-CuPy parity test for the adaptive scorer, using 192 synthetic cells, eight genes, two samples, and a sparse graph. Depth R-squared, residual coherence and final weights must agree within 2e-5 absolute error. This real GPU check is performed on the user's instance before the full comparisons start. Locally, the probe's CPU fixture, import isolation, JSON failure reporting and missing-CUDA failure path were verified.

The main data stay sparse. Only narrow gene blocks are dense during scoring. Up to four separate models are scheduled on the visible GPUs, one process per device. A single model is not distributed over all four devices.

The default 110-minute budget applies to the GPU scheduling stage. Input preparation and report generation take additional time. Compatible completed stages can be reused on rerun; no end-to-end one-hour or two-hour guarantee is made.

## Scientific scope

This is a SAM-inspired exploratory metric-learning pilot, not a reproduction of SAM or a validated decontamination method. Expression-graph coherence is a proxy for organized signal and can reinforce errors in the starting graph. Sequencing depth can reflect meaningful cell size, activation or cycling as well as technical effects. The bounded penalty does not establish which component is causal.

The adaptive update does not use subtype labels or manually reward named lineage markers. The full analysis nevertheless depends on the pre-existing T-cell cohort and its environment-to-T ratio prior. It should not be described as a globally unsupervised all-lineage model.

Held-out companions are excluded from fitted feature matrices, but the unchanged full-library normalization denominator includes all transcripts. These checks are internal feature validation, not external cell-type truth. Repeatedly tuning parameters against the same held-out panel uses that panel for model selection.

Original counts, original normalized marker assays and global atlas annotations remain unchanged. Learned weights describe gene contributions to a distance used before PCA; they are not corrected transcript counts and should not be fed to a count-likelihood model as if they were observed counts.

## Reproducible source

The standalone notebook embeds the readable Python helpers in this package. MANIFEST.json records the delivered file hashes and the helper-bundle hash. The optional ZIP also includes the small synthetic test sources in qa_08V; no synthetic figures, input data, package installations or local dependency directories are included.

From the extracted ZIP root, an environment with NumPy, SciPy, pandas, AnnData, matplotlib, IPython, nbformat and pytest can run the CPU checks with:

```bash
PYTHONPATH="$PWD/08V_Tcell_AdaptiveWeight_GPU:$PWD/qa_08V" python -m pytest -q qa_08V/test_adaptive_math.py qa_08V/test_adaptive_workflow.py qa_08V/test_adaptive_runtime.py qa_08V/test_adaptive_reports.py qa_08V/test_adaptive_preflight.py
```

These tests intentionally do not certify the installed CUDA/RAPIDS stack. Use the notebook's GPU preflight for that boundary.
