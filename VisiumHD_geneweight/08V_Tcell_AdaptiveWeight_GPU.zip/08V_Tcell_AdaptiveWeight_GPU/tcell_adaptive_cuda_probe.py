"""Fresh-process CPU/CuPy parity check for the 08V adaptive score kernel.

CUDA is imported only inside main.  This is a tiny preflight, never a CPU
fallback for production analysis.  stdout contains exactly one JSON report;
failure returns a nonzero process exit code. Flushed stage entries and timing
records go to stderr so the caller can diagnose a timeout before a report exists.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager, ExitStack, redirect_stdout
import json
import sys
import time
import traceback


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gpu-device", type=int, default=0)
    args = parser.parse_args(argv)
    started = time.monotonic()
    tolerance = 2e-5
    report = {
        "probe": "08V-adaptive-score-cuda-parity-v1",
        "status": "failed",
        "n_cells": 192,
        "n_genes": 8,
        "n_samples": 2,
        "n_probes": 64,
        "gene_chunk_size": 3,
        "absolute_tolerance": tolerance,
        "gpu_logical_device": args.gpu_device,
        "production_cpu_fallback": False,
        "versions": {},
        "max_absolute_errors": {},
        "stage_seconds": {},
        "stage_status": {},
    }
    @contextmanager
    def stage(name):
        tick = time.monotonic()
        report["stage_status"][name] = "running"
        print(f"[08V parity stage] {name}", file=sys.stderr, flush=True)
        try:
            # Third-party import/progress messages must not pollute JSON stdout.
            with redirect_stdout(sys.stderr):
                yield
        except BaseException:
            report["stage_status"][name] = "failed"
            report["failure_stage"] = name
            raise
        else:
            report["stage_status"][name] = "passed"
        finally:
            elapsed = time.monotonic() - tick
            report["stage_seconds"][name] = elapsed
            print(f"[08V parity timing] {name}: {elapsed:.2f}s "
                  f"({report['stage_status'][name]})", file=sys.stderr, flush=True)

    try:
        with stage("Import CPU scoring libraries"):
            import numpy as np
            import scipy
            import scipy.sparse as sp

            import tcell_adaptive_math as maths

            report["versions"].update(
                numpy=np.__version__, scipy=scipy.__version__,
                adaptive_math=maths.METHOD_VERSION,
            )
        with stage("Build deterministic parity fixture"):
            rng = np.random.default_rng(17)
            labels = np.repeat(["sample_A", "sample_B"], 96)
            biological_group = np.tile(np.repeat([0, 1], 48), 2)
            sample_shift = np.repeat([0.0, 1.0], 96)
            total_counts = rng.integers(40, 2000, size=192).astype(np.float64)
            depth = np.log1p(total_counts)
            expression = np.column_stack([
                0.5 + 0.8 * depth,
                0.3 + 0.08 * depth * depth,
                1.0 + 2.0 * biological_group + rng.uniform(0, 0.1, 192),
                np.full(192, 3.0),
                1.0 + sample_shift,
                rng.uniform(0, 2, 192),
                (rng.uniform(size=192) < (0.1 + 0.7 * biological_group)).astype(float),
                rng.poisson(0.25, size=192).astype(float),
            ]).astype(np.float32)
            X = sp.csc_matrix(expression)
            graph_rows, graph_cols, graph_data = [], [], []
            for i in range(192):
                candidates = np.flatnonzero(
                    (labels == labels[i]) & (biological_group == biological_group[i])
                )
                candidates = candidates[candidates != i]
                neighbors = np.roll(candidates, i % candidates.size)[:8]
                graph_rows.extend([i] * 8 + [i])
                graph_cols.extend(neighbors.tolist() + [i])
                # Large diagonal weights ensure the self-edge exclusion is exercised.
                graph_data.extend([1.0] * 8 + [100.0])
            graph = sp.csr_matrix(
                (graph_data, (graph_rows, graph_cols)), shape=(192, 192), dtype=np.float32
            )
            probes = maths.select_probe_rows(
                labels, max_probe_per_sample=32, max_probe_total=64, seed=17
            )
            kwargs = dict(
                X=X, graph=graph, sample_labels=labels, total_counts=total_counts,
                base_weights=np.linspace(0.2, 1.0, 8), probe_rows=probes,
                gene_chunk_size=3, verbose=False,
            )
        with stage("CPU reference scoring"):
            cpu = maths.score_adaptive_weights(**kwargs, xp=np)

        # Import CUDA only in the child. Time the sparse backend separately.
        with stage("CuPy import"):
            import cupy as cp
            report["versions"]["cupy"] = cp.__version__
        with stage("CuPy sparse import"):
            from cupyx.scipy.sparse import csr_matrix  # noqa: F401

        with ExitStack() as devices:
            with stage("Initialize CUDA device and context"):
                report["versions"].update(
                    cuda_runtime=int(cp.cuda.runtime.runtimeGetVersion()),
                    cuda_driver=int(cp.cuda.runtime.driverGetVersion()),
                )
                count = int(cp.cuda.runtime.getDeviceCount())
                report["visible_gpu_count"] = count
                if not 0 <= args.gpu_device < count:
                    raise RuntimeError(f"Logical GPU {args.gpu_device} is unavailable; {count} devices visible.")
                devices.enter_context(cp.cuda.Device(args.gpu_device))
                properties = cp.cuda.runtime.getDeviceProperties(args.gpu_device)
                name = properties.get("name", "unknown")
                report["gpu_name"] = name.decode() if isinstance(name, bytes) else str(name)
            with stage("GPU adaptive scoring"):
                # Three tiny blocks. Log their progress on stderr without changing math.
                gpu = maths.score_adaptive_weights(**dict(kwargs, verbose=True, progress_every=1), xp=cp)
            with stage("Synchronize GPU stream"):
                cp.cuda.get_current_stream().synchronize()
            with stage("Release selected device context"):
                devices.close()

        with stage("Compare CPU and GPU results"):
            passed = True
            for key in ("depth_r2", "coherence", "new_weight"):
                expected = np.asarray(cpu[key], dtype=np.float64)
                observed = np.asarray(gpu[key], dtype=np.float64)
                if expected.shape != (8,) or observed.shape != (8,):
                    raise AssertionError(f"Unexpected {key} shape in parity results.")
                if not np.isfinite(expected).all() or not np.isfinite(observed).all():
                    raise FloatingPointError(f"Nonfinite {key} in parity results.")
                error = float(np.max(np.abs(expected - observed)))
                report["max_absolute_errors"][key] = error
                passed = passed and error <= tolerance
            if not passed:
                raise AssertionError("CPU/CuPy adaptive scores exceed the declared absolute tolerance.")
        report["status"] = "passed"
    except Exception as exc:
        report["error"] = {"type": type(exc).__name__, "message": str(exc)}
        traceback.print_exc(file=sys.stderr)
    report["elapsed_seconds"] = time.monotonic() - started
    print(json.dumps(report, sort_keys=True, allow_nan=False), flush=True)
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
