"""GPU execution for 08V: fixed comparisons and two bounded adaptive updates.

Only worker subprocesses import CUDA. Every model uses its complete declared
cell cohort. The optional probe subsample estimates gene scores only; it never
subsamples the PCA, Harmony, neighbor graph, clustering, or final UMAP.
"""
from __future__ import annotations

import argparse
from collections import OrderedDict
from datetime import datetime, timezone
import gc
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_gpu as engine
import tcell_weighted_workflow as base

VERSION = "08V-runtime-1.0.0"
ADAPTIVE_DEFAULTS = {
    "max_updates": 2,
    "gene_chunk_size": 64,
    "max_probe_per_sample": 6000,
    "max_probe_total": 72000,
    "seed": 17,
    "damping": 0.5,
    "reward_max": 3.0,
    "penalty_max": 3.0,
    "reliability_count": 500.0,
    "convergence_log_change": 0.01,
}


def _now():
    return datetime.now(timezone.utc).isoformat()


def validate_adaptive_settings(settings=None):
    cfg = dict(ADAPTIVE_DEFAULTS)
    if settings:
        extra = set(settings) - set(cfg)
        if extra:
            raise ValueError(f"Unknown adaptive settings: {sorted(extra)}")
        cfg.update(settings)
    for key in ("max_updates", "gene_chunk_size", "max_probe_per_sample", "max_probe_total", "seed"):
        value = cfg[key]
        if isinstance(value, bool) or int(value) != value or (value < 0 if key == "seed" else value < 1):
            raise ValueError(f"Invalid {key}: {value}")
        cfg[key] = int(value)
    if cfg["max_updates"] > 3:
        raise ValueError("This pilot supports at most three adaptive updates.")
    for key in ("damping", "reward_max", "penalty_max", "reliability_count", "convergence_log_change"):
        cfg[key] = float(cfg[key])
        if not np.isfinite(cfg[key]):
            raise ValueError(f"Nonfinite {key}")
    if not 0 <= cfg["damping"] <= 1:
        raise ValueError("damping must lie in [0,1].")
    if min(cfg["reward_max"], cfg["penalty_max"]) < 1 or cfg["reliability_count"] < 0 or cfg["convergence_log_change"] < 0:
        raise ValueError("Invalid adaptive bounds, reliability, or convergence setting.")
    return cfg


def _validate_seconds(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.number)):
        raise ValueError(f"{name} must be a positive finite number of seconds.")
    value = float(value)
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be a positive finite number of seconds.")
    return value


def _adaptive_parity_preflight(helper_dir, log_dir, *, timeout_seconds=600.0, heartbeat_seconds=15.0):
    """Stream progress from the *real* probe and require a valid numerical pass.

    Direct file descriptors preserve both streams even when the subprocess is
    terminated. stderr is human-readable progress; stdout is one JSON report.
    A stopping deadline controls startup time only, never the parity tolerance.
    """
    timeout_seconds = _validate_seconds(timeout_seconds, "timeout_seconds")
    heartbeat_seconds = _validate_seconds(heartbeat_seconds, "heartbeat_seconds")
    log_dir = Path(log_dir).resolve()
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout = log_dir / "adaptive_cuda_stdout.txt"
    stderr = log_dir / "adaptive_cuda_stderr.txt"
    summary = log_dir / "adaptive_cuda_probe.json"
    probe = Path(helper_dir).resolve() / "tcell_adaptive_cuda_probe.py"
    stage_prefix = "[08V parity stage] "
    info = {"status": "starting", "started_utc": _now(), "timeout_seconds": timeout_seconds,
            "heartbeat_seconds": heartbeat_seconds, "last_stage": "Python startup",
            "probe_path": str(probe), "stdout_path": str(stdout), "stderr_path": str(stderr),
            "production_cpu_fallback": False}
    started = last_heartbeat = time.monotonic()
    process = None
    pending_line = ""
    with stdout.open("w", encoding="utf-8") as out, stderr.open("w", encoding="utf-8") as err, \
            stderr.open("r", encoding="utf-8", errors="replace") as reader:
        def drain(final=False):
            nonlocal pending_line
            chunk = reader.read()
            if chunk:
                print(chunk, end="", flush=True)
            pending_line += chunk
            lines = pending_line.split("\n")
            pending_line = lines.pop()
            if final and pending_line:
                lines.append(pending_line)
                pending_line = ""
            for line in lines:
                if line.startswith(stage_prefix):
                    name = line[len(stage_prefix):].strip()
                    if name:
                        info["last_stage"] = name
                if line.strip():
                    info["last_stderr_line"] = line.strip()[-1600:]
            return bool(lines)

        base.save_json(summary, info)
        print(f"Adaptive CPU/GPU parity check: deadline {timeout_seconds:g}s; "
              f"heartbeat every {heartbeat_seconds:g}s. Live log: {stderr}", flush=True)
        try:
            process = subprocess.Popen([sys.executable, "-u", str(probe), "--gpu-device", "0"],
                env=base._process_env(), stdout=out, stderr=err, start_new_session=True)
            info.update(status="running", pid=process.pid)
            base.save_json(summary, info)
            while True:
                activity = drain()
                code = process.poll()
                now = time.monotonic()
                elapsed = now - started
                if code is not None:
                    drain(final=True)
                    break
                if elapsed >= timeout_seconds:
                    info["status"] = "timeout"
                    raise RuntimeError(f"Adaptive CUDA parity probe timed out after {timeout_seconds:g}s. "
                                       f"Last reported stage: {info['last_stage']}. See {summary}.")
                heartbeat = now - last_heartbeat >= heartbeat_seconds
                if activity or heartbeat:
                    info["elapsed_seconds"] = elapsed
                    base.save_json(summary, info)
                if heartbeat:
                    print(f"[08V parity] {elapsed:.0f}s elapsed; last reported stage: {info['last_stage']}",
                          flush=True)
                    last_heartbeat = now
                time.sleep(min(.20, heartbeat_seconds, max(.001, timeout_seconds - elapsed)))

            try:
                parity = json.loads(stdout.read_text(encoding="utf-8"))
                if not isinstance(parity, dict):
                    raise ValueError("expected a JSON object")
                # Do not insert an unserializable/nonfinite worker payload into our receipt.
                json.dumps(parity, allow_nan=False)
            except (OSError, ValueError) as exc:
                info["status"] = "failed" if code else "invalid_report"
                raise RuntimeError(f"Adaptive CUDA parity probe exited {code} without a valid JSON report. "
                                   f"Last reported stage: {info['last_stage']}. See {summary}.") from exc
            for key, value in parity.items():
                if key not in info and key not in {"pid", "returncode", "elapsed_seconds", "finished_utc"}:
                    info[key] = value
            info["probe_elapsed_seconds"] = parity.get("elapsed_seconds")
            if code or parity.get("status") != "passed":
                info["status"] = "failed"
                detail = parity.get("error")
                if isinstance(detail, dict):
                    detail = detail.get("message")
                raise RuntimeError(f"Adaptive CUDA parity check failed (exit {code}, "
                                   f"stage {info['last_stage']}). {detail or ''} See {summary}.")
            errors = parity.get("max_absolute_errors")
            required = ("depth_r2", "coherence", "new_weight")
            valid = (parity.get("production_cpu_fallback") is False and parity.get("absolute_tolerance") == 2e-5
                     and isinstance(errors, dict) and all(
                         type(errors.get(key)) in (int, float) and 0 <= errors[key] <= 2e-5 for key in required))
            if not valid:
                info["status"] = "invalid_report"
                raise RuntimeError(f"Adaptive CUDA parity result did not certify all three errors within 2e-5. See {summary}.")
            info["status"] = "passed"
        except BaseException as exc:
            if info["status"] in ("starting", "running"):
                info["status"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
            info.setdefault("error", {"type": type(exc).__name__, "message": str(exc)})
            raise
        finally:
            if process is not None:
                if process.poll() is None:
                    try:
                        base._stop_owned(process)
                    finally:
                        # _stop_owned may return as soon as the leader exits.
                        # A compiler descendant that ignored TERM may still be
                        # in this private process group. Never signal the kernel's group.
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                info["returncode"] = process.poll()
            drain(final=True)
            info.update(elapsed_seconds=time.monotonic() - started, finished_utc=_now())
            base.save_json(summary, info)
    print(f"Adaptive CPU/GPU parity passed in {info['elapsed_seconds']:.1f}s.", flush=True)
    return info


def preflight(helper_dir, log_dir, *, adaptive_timeout_seconds=600.0, heartbeat_seconds=15.0):
    """Check CUDA discovery, RAPIDS operations and the new scorer in fresh processes."""
    adaptive_timeout_seconds = _validate_seconds(adaptive_timeout_seconds, "adaptive_timeout_seconds")
    heartbeat_seconds = _validate_seconds(heartbeat_seconds, "heartbeat_seconds")
    helper_dir, log_dir = Path(helper_dir).resolve(), Path(log_dir).resolve()
    log_dir.mkdir(parents=True, exist_ok=True)
    # On repeated runs, do not bundle success/errors from stages not reached
    # this time. Only touch known preflight diagnostics, never model caches.
    for name in ("runtime.json", "cuda_probe_failure.json", "cuda_probe_stdout.txt", "cuda_probe_stderr.txt",
                 "adaptive_cuda_probe.json", "adaptive_cuda_stdout.txt", "adaptive_cuda_stderr.txt",
                 "rapids/preflight_report.json", "rapids/preflight.log", "rapids/08S_preflight_diagnostics.zip"):
        (log_dir / name).unlink(missing_ok=True)
    probe = helper_dir / "tcell_banksy_cuda_probe.py"
    command = [sys.executable, str(probe)]
    # The probe emits JSON to stdout; no CUDA import happens in this supervisor.
    try:
        result = subprocess.run(command, capture_output=True, text=True,
                                timeout=45, env=base._process_env(), check=False)
    except subprocess.TimeoutExpired as exc:
        for label, data in (("stdout", exc.stdout), ("stderr", exc.stderr)):
            if isinstance(data, bytes):
                data = data.decode("utf-8", errors="replace")
            (log_dir / f"cuda_probe_{label}.txt").write_text(data or "", encoding="utf-8")
        base.save_json(log_dir / "cuda_probe_failure.json", {
            "status": "timeout", "seconds": 45,
            "message": "CUDA startup did not finish in the fresh worker; check the running environment."})
        raise RuntimeError(f"CUDA startup timed out. Diagnostics: {log_dir}") from exc
    (log_dir / "cuda_probe_stdout.txt").write_text(result.stdout, encoding="utf-8")
    (log_dir / "cuda_probe_stderr.txt").write_text(result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"The fresh CUDA probe failed; inspect {log_dir / 'cuda_probe_stdout.txt'} before starting the large run.")
    runtime = base.preflight_gpu(helper_dir, log_dir=log_dir / "rapids", timeout_seconds=600)
    runtime["adaptive_cuda_parity"] = _adaptive_parity_preflight(
        helper_dir, log_dir, timeout_seconds=adaptive_timeout_seconds, heartbeat_seconds=heartbeat_seconds)
    base.save_json(log_dir / "runtime.json", runtime)
    return runtime


def _read_embedding(path, expected_index):
    import anndata as ad
    result = ad.read_h5ad(path)
    if not np.array_equal(result.obs_names.astype(str), expected_index.astype(str)):
        raise ValueError("Adaptive graph cell IDs/order differ from the frozen expression rows.")
    graph = result.obsp.get("connectivities", result.obsp.get("neighbors_connectivities"))
    if graph is None:
        raise ValueError("Adaptive update needs the completed sparse expression-neighbor graph.")
    return result, graph


def run_adaptive(plan, output_dir, baseline_embedding, *, gpu_settings=None,
                 adaptive_settings=None, gpu_device=0, resume=True):
    """Learn weights from an initial held-out static graph, then apply to all cells."""
    import cupy as cp
    import tcell_adaptive_math as maths
    import tcell_adaptive_workflow as workflow

    cfg = validate_adaptive_settings(adaptive_settings)
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    branch = plan["branches"]["broad_adaptive"]
    cache = Path(branch["cache_dir"])
    _, matrix_path, manifest, obs, features, base_weights, _, _ = engine._metadata_inputs(
        cache, "weighted", engine.validate_settings(gpu_settings))
    heldout = set(plan.get("heldout_genes", workflow.HELDOUT_GENES))
    active = features["weight"].to_numpy(float) > 0
    if features.loc[active, "gene"].isin(heldout).any():
        raise ValueError("Reserved companion genes must be excluded before the first adaptive graph.")
    # The workflow physically removes holdouts from the broad candidate pool.
    if not active.all():
        raise ValueError("The adaptive pool must contain only positive-weight candidate columns; exclude reserved genes during preparation.")
    # The scorer visits narrow gene blocks repeatedly; CSC avoids rescanning all
    # CSR nonzeros for every column slice. The original cache remains unchanged.
    X = sp.load_npz(matrix_path).tocsc()
    sample_labels = obs["sample_id"].astype(str).to_numpy()
    totals = pd.to_numeric(obs["total_counts"], errors="raise").to_numpy(float)
    genes = features["gene"].astype(str).to_numpy()
    detected = pd.to_numeric(features["detected_cells"], errors="raise").to_numpy(float)
    probes = maths.select_probe_rows(sample_labels, max_probe_per_sample=cfg["max_probe_per_sample"],
                                    max_probe_total=cfg["max_probe_total"], seed=cfg["seed"])
    np.save(output / "score_probe_rows.npy", probes, allow_pickle=False)
    pd.DataFrame({"sample": sample_labels[probes]}).value_counts().rename("n_probes").reset_index().to_csv(
        output / "score_probe_sample_counts.csv", index=False)
    current = np.asarray(base_weights, dtype=np.float64)
    graph_path = Path(baseline_embedding)
    rounds = []
    final_embedding = None
    metadata = {
        "version": VERSION, "math_version": getattr(maths, "VERSION", "unknown"),
        "started_utc": _now(), "settings": cfg, "n_cells": len(obs), "n_features": len(features),
        "n_score_probes": len(probes), "score_probe_only": True,
        "all_declared_cells_embedded": True, "heldout_genes": sorted(heldout),
        "guide_marker_labels_used_for_fitting": False,
        "initial_graph": str(graph_path), "count_matrix_modified": False,
        "interpretation": "Exploratory SAM-inspired nonnegative metric weights, not SAM reproduction or corrected counts.",
        "rounds": rounds,
    }
    base.save_json(output / "adaptive_metadata.json", metadata)
    with cp.cuda.Device(int(gpu_device)):
        for iteration in range(1, cfg["max_updates"] + 1):
            started = time.monotonic()
            directory = output / f"round_{iteration:02d}"
            directory.mkdir(parents=True, exist_ok=True)
            result, graph = _read_embedding(graph_path, obs.index)
            # Verify the graph was constructed with the current candidate weights.
            if not np.array_equal(result.var_names.astype(str), genes):
                raise ValueError("Adaptive graph feature order differs from candidate expression.")
            actual = result.var.get("applied_distance_weight", result.var.get("weight"))
            if actual is None or not np.allclose(np.asarray(actual, float), current, rtol=3e-6, atol=1e-8):
                raise ValueError("Adaptive graph was not built with the current weight vector.")
            graph_identity = {"path": str(graph_path.resolve()), "size": graph_path.stat().st_size,
                              "mtime_ns": graph_path.stat().st_mtime_ns}
            fp = base._digest({"cache_id": manifest["cache_id"], "graph": graph_identity,
                               "current_weights": engine._weight_hash(current), "settings": cfg,
                               "math_version": metadata["math_version"], "versions": engine._versions(),
                               "cupy": cp.__version__})
            receipt = directory / "score_complete.json"
            table_path = directory / "gene_weight_update.csv"
            if resume and receipt.is_file() and table_path.is_file() and json.loads(receipt.read_text()).get("fingerprint") == fp:
                table = pd.read_csv(table_path)
                if not np.array_equal(table["gene"].astype(str).to_numpy(), genes):
                    raise ValueError("Saved adaptive score table has different genes/order.")
                new_weights = table["new_weight"].to_numpy(float)
                diagnostics = json.loads(receipt.read_text())["diagnostics"]
                print(f"Adaptive update {iteration}: reused compatible per-gene scores.", flush=True)
            else:
                print(f"Adaptive update {iteration}: scoring {len(genes):,} genes in chunks of {cfg['gene_chunk_size']}; "
                      f"{len(probes):,} balanced probe rows from {len(obs):,} embedded cells.", flush=True)
                score_args = {k: cfg[k] for k in (
                    "gene_chunk_size", "max_probe_per_sample", "max_probe_total", "seed", "damping",
                    "reward_max", "penalty_max", "reliability_count")}
                scored = maths.score_adaptive_weights(
                    X, graph, sample_labels, totals, base_weights,
                    current_weights=current, detected_cells=detected, probe_rows=probes,
                    feature_names=genes, xp=cp, **score_args)
                diagnostics = scored.get("diagnostics", {})
                arrays = {k: v for k, v in scored.items()
                          if k != "diagnostics" and isinstance(v, np.ndarray) and v.shape == (len(genes),)}
                table = pd.DataFrame(arrays)
                table["gene"] = genes
                table["detected_cells"] = detected.astype(np.int64)
                table["ratio_prior_weight"] = base_weights
                table["previous_weight"] = current
                if "new_weight" not in table:
                    raise ValueError("Adaptive scorer did not return new_weight.")
                new_weights = table["new_weight"].to_numpy(float)
                table["multiplier_vs_ratio"] = new_weights / base_weights
                table.to_csv(table_path, index=False)
                base.save_json(receipt, {"fingerprint": fp, "diagnostics": diagnostics})
            del result, graph
            gc.collect()
            if (not np.isfinite(new_weights).all() or np.any(new_weights <= 0)
                    or np.any(new_weights < base_weights / cfg["penalty_max"] * (1 - 1e-5))
                    or np.any(new_weights > base_weights * cfg["reward_max"] * (1 + 1e-5))):
                raise ValueError("Learned weights violate the declared finite positive bounds.")
            changes = np.abs(np.log(new_weights / current))
            delta = float(np.median(changes))
            delta_p95 = float(np.quantile(changes, 0.95))
            converged = delta_p95 <= cfg["convergence_log_change"]
            last = iteration == cfg["max_updates"] or converged
            weighted_features = features.copy()
            weighted_features["weight"] = new_weights
            weighted_features["ratio_prior_weight"] = base_weights
            weighted_features["adaptive_multiplier"] = new_weights / base_weights
            next_cache = workflow.create_branch_cache(
                cache, directory / "cache", weighted_features, metadata={
                    "transform": "centered_log1p_with_adaptive_nonnegative_distance_weights",
                    "adaptive_iteration": iteration, "adaptive_score_fingerprint": fp,
                    "heldout_genes": sorted(heldout), "marker_labels_used": False}, resume=resume)
            if isinstance(next_cache, tuple):
                next_cache = next_cache[0]
            if isinstance(next_cache, dict):
                next_cache = next_cache["cache_dir"]
            graph_path = Path(engine.run_gpu_branch(
                next_cache, directory / "model", branch="weighted", gpu_device=gpu_device,
                settings=gpu_settings, resume=resume, graph_only=not last))
            rounds.append({"iteration": iteration, "median_abs_log_weight_change": delta,
                           "p95_abs_log_weight_change": delta_p95,
                           "converged": converged, "elapsed_seconds": time.monotonic() - started,
                           "score_table": str(table_path), "feature_cache": str(next_cache),
                           "model": str(graph_path), "graph_only": not last})
            current = new_weights
            metadata["rounds"] = rounds
            base.save_json(output / "adaptive_metadata.json", metadata)
            if last:
                final_embedding = graph_path
                table.to_csv(output / "final_gene_weights.csv", index=False)
                metadata["final_feature_cache"] = str(next_cache)
                break
    metadata.update(status="complete", completed_utc=_now(), embedding_path=str(final_embedding))
    base.save_json(output / "adaptive_metadata.json", metadata)
    return Path(final_embedding)


def run_worker(plan, branch_name, output_dir, gpu_settings, adaptive_settings=None, *, resume=True):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    info = plan["branches"][branch_name]
    try:
        if info.get("kind") == "adaptive":
            static_receipt = output.parent / "broad_ratio" / "result.json"
            if not static_receipt.is_file():
                raise FileNotFoundError("The matched broad_ratio graph must finish before adaptive learning.")
            static_path = json.loads(static_receipt.read_text())["embedding_path"]
            path = run_adaptive(plan, output, static_path, gpu_settings=gpu_settings,
                                adaptive_settings=adaptive_settings, gpu_device=0, resume=resume)
            fitted_cache = json.loads((output / "adaptive_metadata.json").read_text())["final_feature_cache"]
        else:
            path = engine.run_gpu_branch(info["cache_dir"], output, branch="weighted", gpu_device=0,
                                         settings=gpu_settings, resume=resume)
            fitted_cache = info["cache_dir"]
        receipt = {"branch": branch_name, "embedding_path": str(Path(path).resolve()),
                   "cache_dir": fitted_cache, "initial_cache_dir": info["cache_dir"],
                   "cohort": info.get("cohort", "all"),
                   "kind": info.get("kind", "fixed"), "completed_utc": _now(), "status": "complete"}
        base.save_json(output / "result.json", receipt)
        return Path(path)
    except BaseException as exc:
        base.save_json(output / "worker_error.json", {"type": type(exc).__name__, "message": str(exc),
                         "traceback": traceback.format_exc(), "time_utc": _now()})
        raise


def launch_experiment(plan, helper_dir, runtime, *, gpu_settings=None, adaptive_settings=None,
                      max_minutes=110, resume=True):
    """Queue independent arms across up to four visible GPUs; own processes only."""
    gpu_settings = engine.validate_settings(gpu_settings)
    adaptive_settings = validate_adaptive_settings(adaptive_settings)
    raw_count = runtime.get("visible_device_count", runtime.get("device_count", 0))
    if (runtime.get("ok") is not True or isinstance(raw_count, bool)
            or not isinstance(raw_count, (int, np.integer)) or raw_count < 1):
        raise ValueError("The preflight did not find a usable CUDA device.")
    count = int(raw_count)
    if not np.isfinite(max_minutes) or max_minutes <= 0:
        raise ValueError("max_minutes must be positive and finite.")
    root = Path(plan["plan_dir"]) / "runs" / base._digest({"gpu": gpu_settings,
                "adaptive": adaptive_settings, "runtime": VERSION,
                "plan_id": plan["plan_id"], "engine_versions": engine._versions()})[:16]
    root.mkdir(parents=True, exist_ok=True)
    plan_path, gpu_path, adaptive_path = root / "plan.json", root / "gpu_settings.json", root / "adaptive_settings.json"
    for path, value in ((plan_path, plan), (gpu_path, gpu_settings), (adaptive_path, adaptive_settings)):
        base.save_json(path, value)
    base.save_json(root / "gpu_runtime.json", runtime)
    pending = list(plan["branches"])
    if "broad_ratio" in pending:
        pending.remove("broad_ratio")
        pending.insert(0, "broad_ratio")
    active, completed, failures = {}, OrderedDict(), {}
    free = list(range(min(4, count)))
    started, last_heartbeat = time.monotonic(), 0.0
    base.save_json(root / "launch.json", {"devices": free, "version": VERSION,
                   "max_minutes": max_minutes, "started_utc": _now(), "visible_device_count": count})
    try:
        while pending or active:
            while free:
                ready = [name for name in pending if plan["branches"][name].get("kind") != "adaptive" or "broad_ratio" in completed]
                if not ready:
                    break
                name = ready[0]
                pending.remove(name)
                device = free.pop(0)
                out = root / name
                out.mkdir(parents=True, exist_ok=True)
                log = out / "console.log"
                writer = log.open("a" if resume else "w", encoding="utf-8")
                writer.write(f"\n08V worker invocation {_now()}\n")
                writer.flush()
                reader = log.open("r", encoding="utf-8")
                reader.seek(0, os.SEEK_END)
                command = [sys.executable, str(Path(helper_dir).resolve() / "tcell_adaptive_runtime.py"),
                           "--plan-json", str(plan_path), "--branch", name, "--output-dir", str(out),
                           "--gpu-settings-json", str(gpu_path), "--adaptive-settings-json", str(adaptive_path)]
                if not resume:
                    command.append("--no-resume")
                process = subprocess.Popen(command, stdout=writer, stderr=subprocess.STDOUT,
                                           env=base._process_env(device), start_new_session=True)
                active[name] = {"process": process, "writer": writer, "reader": reader, "device": device, "out": out}
                print(f"Started {name} on visible GPU {device}: {plan['branches'][name].get('label', name)}", flush=True)
            for name, state in list(active.items()):
                for line in state["reader"].readlines():
                    print(f"[{name}] {line.rstrip()}", flush=True)
                status = state["process"].poll()
                if status is None:
                    continue
                state["writer"].close()
                for line in state["reader"].readlines():
                    print(f"[{name}] {line.rstrip()}", flush=True)
                state["reader"].close()
                free.append(state["device"])
                receipt = state["out"] / "result.json"
                if status == 0 and receipt.is_file():
                    value = json.loads(receipt.read_text())
                    path = Path(value["embedding_path"])
                    if not path.is_file():
                        failures[name] = "Completed receipt references a missing embedding."
                    else:
                        completed[name] = path
                else:
                    failures[name] = f"Exit {status}; inspect {state['out'] / 'console.log'}"
                del active[name]
            if not active and pending and not any(plan["branches"][n].get("kind") != "adaptive" for n in pending):
                if "broad_ratio" not in completed:
                    failures.update({n: "Matched static baseline failed; adaptive analysis was not started." for n in pending})
                    pending.clear()
            elapsed = time.monotonic() - started
            if elapsed > max_minutes * 60:
                raise TimeoutError(f"08V GPU stage reached {max_minutes:g} minutes. Compatible checkpoints remain in {root}.")
            if elapsed - last_heartbeat > 30:
                print(f"08V: {elapsed/60:.1f} min; running {list(active)}; complete {list(completed)}; queued {pending}", flush=True)
                last_heartbeat = elapsed
            if active:
                time.sleep(0.5)
        base.save_json(root / "comparison_complete.json", {"branches": completed, "failures": failures,
                         "elapsed_seconds": time.monotonic() - started})
        if failures:
            raise RuntimeError(f"08V branches did not all finish: {failures}")
        return completed, root
    except BaseException as exc:
        setattr(exc, "run_root", root)
        base.save_json(root / "launch_error.json", {"type": type(exc).__name__, "message": str(exc),
                         "completed": completed, "traceback": traceback.format_exc()})
        raise
    finally:
        for state in active.values():
            base._stop_owned(state["process"])
            state["writer"].close()
            state["reader"].close()


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--plan-json", required=True)
    p.add_argument("--branch", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--gpu-settings-json", required=True)
    p.add_argument("--adaptive-settings-json", required=True)
    p.add_argument("--no-resume", action="store_true")
    a = p.parse_args(argv)
    run_worker(json.loads(Path(a.plan_json).read_text()), a.branch, a.output_dir,
               json.loads(Path(a.gpu_settings_json).read_text()),
               json.loads(Path(a.adaptive_settings_json).read_text()), resume=not a.no_resume)


if __name__ == "__main__":
    main()
