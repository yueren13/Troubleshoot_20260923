# Ada-14R · Tissue QC and local RNA

**78.6% of out-of-mask RNA** in the buffered region was observed in tissue-low/transcript-high squares (655,992 of 834,456 UMIs across 69,854 candidate squares).

Each percentage below is corrected panel counts divided by raw panel UMIs in the same domain and shared cells.

| Shared core group and marker panel | Cells | All in-tissue | H&E-high |
| --- | ---: | ---: | ---: |
| Pan-T-supported, near macrophages · myeloid | 297 | 41.7% of 2,589 UMIs | 60.7% of 2,583 UMIs |
| Pan-T-supported, far from macrophages · myeloid | 31 | 55.2% of 62 UMIs | 65.4% of 61 UMIs |
| Macrophage/monocyte label · myeloid | 752 | 57.7% of 4,207 UMIs | 72.3% of 4,150 UMIs |
| Pan-T-supported · pan-T | 460 | 93.1% of 826 UMIs | 100.0% of 823 UMIs |
| T label · Cd4 | 1,103 | 100.0% of 44 UMIs | 97.3% of 44 UMIs |
| T label · Cd8a/Cd8b1 | 1,103 | 89.6% of 364 UMIs | 100.0% of 362 UMIs |
| B label · B markers | 78 | 98.6% of 8 UMIs | 100.0% of 8 UMIs |

The near/far pan-T groups exclude previous macrophage/monocyte labels. See paired_coreceptors.csv for the number of cells positive for either, both, or neither coreceptor.

Stages requiring review: histology. See status.json for details.
