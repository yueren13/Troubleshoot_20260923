# Original 09B evaluation core

Readout covers 347,792 of 347,792 native disk positions and 10,284 complete footprints from 10,290 original evaluation cells. Both methods returned verified outputs on 122 tiles containing 8,037 complete footprints. An individual marker row can have a smaller denominator.

Native RNA totals use uniquely owned squares inside the disk. Cell totals use each owned complete footprint, including bins extending across tile cores or the disk boundary. The method coverage table gives raw and corrected counts for each method's available tiles and for the shared subset. The background sensitivity table compares results on tiles below and at or above 25% provisional SpotClean background, using identical paired footprints for both methods within each stratum.


## Across regions

Each pooled estimate uses the same measured cell footprints, marker genes and raw denominators for both methods. Halos supply modeling context and may overlap. Disjoint owners prevent repeated cell or disk-bin observations. Per-tile results and fit availability are tabulated separately.

- Macrophage / monocyte labels · myeloid across 102 region(s), 645 cells and 3,570 observed UMIs. SPARKLE retained 73.3% and SpotClean retained 101.2%.
- Prior T labels · Cd4 across 90 region(s), 778 cells and 31 observed UMIs. SPARKLE retained 97.6% and SpotClean retained 100.0%.
- Prior T labels · Cd8a / Cd8b1 across 90 region(s), 778 cells and 235 observed UMIs. SPARKLE retained 89.1% and SpotClean retained 101.0%.
- Pan-T supported, near macrophages · myeloid across 49 region(s), 212 cells and 1,812 observed UMIs. SPARKLE retained 65.4% and SpotClean retained 100.6%.
- Pan-T supported · pan-T markers across 58 region(s), 287 cells and 520 observed UMIs. SPARKLE retained 97.7% and SpotClean retained 100.3%.

## Interpretation

Read the two myeloid endpoints together. Loss of myeloid counts in nearby pan-T-supported cells is more persuasive when macrophage markers are retained in the same fit. These observations alone cannot assign the true source of an individual transcript.

The edge sensitivity table repeats the group counts and retention estimates for centroids within one SPARKLE donor radius of the crop border and for centroids whose full radius lies inside the window. Inspect the group sizes when comparing these two subsets (edge_sensitivity.csv).

Marker gene coverage records each gene’s fit status and observed counts in assigned and unassigned squares. An unchanged SPARKLE panel can reflect genes that failed the fit threshold. The coreceptor score table measures observed Cd4, Cd8a and Cd8b1 by mask assignment and H&E score in the inner core.

39 tile/method combinations lack a verified fit. See region_status.csv for each tile and domain_coverage.csv for coverage.
