# Original 09B evaluation core

Readout covers 347,792 of 347,792 native disk positions and 10,284 complete footprints from 10,290 original evaluation cells. Both methods returned verified outputs on 1 tiles containing 85 complete footprints. An individual marker row can have a smaller denominator.

Native RNA totals use uniquely owned squares inside the disk. Cell totals use each owned complete footprint, including bins extending across tile cores or the disk boundary. The method coverage table gives raw and corrected counts for each method's available tiles and for the shared subset. The background sensitivity table compares results on tiles below and at or above 25% provisional SpotClean background, using identical paired footprints for both methods within each stratum.


## Across regions

Each pooled estimate uses the same measured cell footprints, marker genes and raw denominators for both methods. Halos supply modeling context and may overlap. Disjoint owners prevent repeated cell or disk-bin observations. Per-tile results and fit availability are tabulated separately.

- Pan-T supported, near macrophages · myeloid across 1 region(s), 3 cells and 8 observed UMIs. SPARKLE retained 91.1% and SpotClean retained 109.4%.
- Macrophage / monocyte labels · myeloid across 1 region(s), 3 cells and 2 observed UMIs. SPARKLE retained 88.8% and SpotClean retained 105.8%.
- Pan-T supported · pan-T markers across 1 region(s), 4 cells and 8 observed UMIs. SPARKLE retained 100.0% and SpotClean retained 105.1%.
- Prior T labels · Cd4 across 1 region(s), 13 cells and 0 observed UMIs. SPARKLE retained — and SpotClean retained —.
- Prior T labels · Cd8a / Cd8b1 across 1 region(s), 13 cells and 0 observed UMIs. SPARKLE retained — and SpotClean retained —.

## Interpretation

Read the two myeloid endpoints together. Loss of myeloid counts in nearby pan-T-supported cells is more persuasive when macrophage markers are retained in the same fit. These observations alone cannot assign the true source of an individual transcript.

The edge sensitivity table repeats the group counts and retention estimates for centroids within one SPARKLE donor radius of the crop border and for centroids whose full radius lies inside the window. Inspect the group sizes when comparing these two subsets (edge_sensitivity.csv).

Marker gene coverage records each gene’s fit status and observed counts in assigned and unassigned squares. An unchanged SPARKLE panel can reflect genes that failed the fit threshold. The coreceptor score table measures observed Cd4, Cd8a and Cd8b1 by mask assignment and H&E score in the inner core.

160 tile/method combinations lack a verified fit. See region_status.csv for each tile and domain_coverage.csv for coverage.
