# Marker readout

SpotClean fit completed.

22 complete Proseg cell footprints enter the comparison. 20 have a previous cell-type label. Evaluation uses the same native squares for raw and SpotClean counts. Any cell touching the crop boundary or containing a modeled background square is excluded.

| Group and panel | Cells | Observed UMIs | SpotClean / raw |
|---|---:|---:|---:|
| Pan-T supported, near macrophages · myeloid | 0 | — | — |
| Macrophage / monocyte labels · myeloid | 3 | 16 | 107.6% |
| Pan-T supported · pan-T markers | 0 | — | — |
| Prior T labels · Cd4 | 0 | — | — |
| Prior T labels · Cd8a / Cd8b1 | 0 | — | — |

Ratios use summed counts and may exceed 100%. A dash indicates insufficient paired data or a zero denominator. Pan-T support and macrophage distances come from the previous 09B analysis. The nearby group requires pan-T support, a non-macrophage label and distance to a labeled macrophage of at most 25 µm. See marker_fit_coverage.csv for assayed and modeled genes.

## Observed coreceptor RNA in the core

- Cd4: 0 of 0 raw core UMIs outside Proseg masks
- Cd8a: 0 of 0 raw core UMIs outside Proseg masks
- Cd8b1: 0 of 0 raw core UMIs outside Proseg masks

The score table includes measured zero-count squares. An out-of-mask count identifies a candidate for segmentation review. Its cell of origin remains unknown.

## Historical SPARKLE comparison

all_in_tissue: 20 complete cells have matched square support and raw counts.
qc_retained_in_tissue: 17 complete cells have matched square support and raw counts.

paired_sparkle.csv uses shared complete cells with matching native-square domains and raw counts. The original SPARKLE fit used a wider neighborhood. A tiny or empty group has little power to distinguish retention at equivalent spillover reduction.
