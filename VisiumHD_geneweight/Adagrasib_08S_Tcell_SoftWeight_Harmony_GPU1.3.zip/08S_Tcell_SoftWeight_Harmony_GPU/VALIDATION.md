# 08S validation record

Build date: 2026-11-10. This record separates implemented behavior, local checks and on-instance verification.

## Release 1.0.3: CuPy sparse astype signature compatibility

The attached error03 notebook and diagnostic ZIP identify CuPy 14.0.1 and RAPIDS single-cell 0.15.0rc5. Imports, CUDA initialization and the release 1.0.2 array transfer complete. The shared PCA operator then fails at `matrix.astype(xp.float32, copy=True)` because CuPy's sparse `astype(t)` does not accept the `copy` keyword.

The corrected call is `matrix.astype(xp.float32)`. CuPy documents a copied result, and SciPy defaults to `copy=True`; this preserves the original sparse input and the intended float32 weighting operation without a redundant allocation. Only the shared PCA function's dtype call changes executable numerical-path code. Weighting, normalization, integration, clustering and marker review are unchanged; the preparation and numerical-engine fingerprint versions are retained because the operation and successful results are equivalent. The release and diagnostic version identifiers advance to identify the corrected code.

Five new CPU-side API-contract regressions enforce `astype(self, dtype)` rather than inheriting SciPy's more permissive method signature. They cover float32, float64 and int32 sparse inputs, retain exact input data/indices/indptr and original dtype, reject dense conversion, compare scores/variance/loadings against a directly centered dense PCA reference, and exercise the actual preflight with the strict sparse object passed into the real PCA operator. A legacy-line mutation reproduces the exact unexpected-keyword failure. The prior transfer tests alone did not enforce this sparse method signature; this is why they missed error03.

These are simulated API checks with CPU arithmetic, not an actual CUDA run. No claim is made that Harmony, graph construction or the full biological analysis has completed on the user's GPU. The attached diagnostics show one visible A10G; the existing sequential launcher behavior remains appropriate for that allocation.

**Full suite: 40 tests passed** (23 input/numerical/cache checks, 10 diagnostic-supervision checks, 2 dense CPU/GPU-transfer checks, and 5 strict sparse-dtype regressions). The emitted warnings were dependency deprecations from pytest/AnyIO and AnnData/pandas.

## Release 1.0.2: explicit dense CPU-to-GPU transfer

The error02 diagnostic log establishes the failing line: the preflight test called the CuPy sparse CSR constructor with a dense NumPy array. CuPy's documented dense initializer is a two-dimensional CuPy array; the revised call explicitly uses cp.asarray(..., dtype=cp.float32) first. The production transfer remains a supported SciPy sparse CSR input and does not require a dense full-data allocation.

The fix is limited to the synthetic startup matrix plus immediate module-version logging. Numerical methods and cache/checkpoint identity versions are unchanged. Two strict-type regression tests exercise the actual preflight function with simulated device types: they reproduce the rejected CPU-dense initializer and verify that the corrected transfer preserves the 192-by-8 float32 log1p values, reaches PCA, and completes the simulated preflight sequence. These are CPU-side API-contract tests, not real CUDA execution. Together with the prior 33 checks, the suite contains 35 tests.

The user-side log verifies successful imports and CUDA device/context setup before this initializer error. The build environment still has no CUDA device, so downstream GPU stages and real biological outcomes require the next on-instance run.

## Release 1.0.1: startup-diagnostics regression checks

The uploaded error01 notebook contains successful bootstrap and input-path discovery, but no saved exception or traceback. Its GPU startup cell has no completed execution count. No specific CUDA, Harmony, Python-version, memory or timeout cause can be established from that snapshot.

The confirmed defect was in reporting: the original parent captured child output in a pipe and displayed it only after normal completion; a 180-second timeout could bypass that display. The revision streams child output from a persistent log and reports import/GPU stages, exit status and timing, with a diagnostic ZIP on success, failure, timeout or a handled interruption.

**10 additional regression tests passed**, using small subprocesses to exercise success, failed/invalid reports, stdout and stderr retention, full traceback capture, live output before the child finishes, quiet-stage heartbeats, timeout cleanup of child and grandchild processes, handled KeyboardInterrupt cleanup, and exact archive/log/report agreement. The actual production CLI was also exercised in the build environment's expected missing-CuPy failure mode and preserved the correct failing stage and traceback.

These tests validate supervision and diagnostics, not actual CUDA execution. The original 23-test input/numerical suite is retained. Numerical engine and preparation fingerprint versions remain unchanged because this release changes startup reporting only.

## Completed local checks

The core independent synthetic test suite passed **23 tests**. These cover:

- Recovery of the actual prior 08O pointer/configuration contract, including sparse CSR and CSC count storage.
- Full-source library-size normalization and deliberate avoidance of the previously processed `X` matrix.
- Restoration of eligible genes excluded by earlier HVG/ratio masks, shuffled gene-ratio alignment, and retention of every source cell.
- Validation of counts, source library sizes, required metadata, population scope, analysis identity and gene ratios.
- Source-file immutability, source-change rejection, complete cache reuse and reuse of normalized arrays after changing the weight curve.
- Numerically stable exclusion of a truly constant normalized gene.
- Agreement of ordered cell/gene hashes across modules.
- Centered weighted sparse randomized-PCA mathematics, compared with exact dense SVD on small examples using the same operator with NumPy/SciPy.
- Completed-output validation and recovery of an interrupted metadata/assignments write.
- CUDA visibility mapping and legacy/current Harmony keyword compatibility.

The marker module was exercised separately with synthetic sparse counts, two methods, three resolutions, a deliberately unavailable marker and enough clusters to test pagination. Original-expression means and observed detection fractions were checked numerically, and incorrect row alignment was rejected. Generated plots were inspected visually. These synthetic outputs are excluded from the delivered package.

The notebook is validated as nbformat v4, and every code cell is syntax-compiled. Its embedded helper files are matched by hash to the readable delivered modules. The standalone bootstrap is checked in an isolated temporary folder so the notebook does not depend on the neighboring source copies.

## What remains to be verified on the instance

The build environment has **no CUDA device, CuPy or RAPIDS execution environment**. Therefore the full GPU pipeline, compatibility with the user's exact installed stack, real biological separation and runtime on the g5.24xlarge have not been measured here.

The notebook starts by running a **192-observation synthetic GPU check** through the actual installed PCA, Harmony, neighbors, Leiden and UMAP APIs. This occurs before the large biological H5AD is read. Production CAGRA is checked for API availability, while the tiny arithmetic check uses brute neighbors because of small-input constraints. Runtime versions, actual API arguments, timings and device memory observations are recorded in each real run.

## Interpretation limits

The ratio weights are fixed feature priorities rather than estimated clean transcript counts. The pooled T-compartment ratios are not a per-cell decontamination model. The marker-concordance diagnostics are descriptive and are not independent label validation. No real-data improvement or runtime guarantee is claimed by the local checks.
