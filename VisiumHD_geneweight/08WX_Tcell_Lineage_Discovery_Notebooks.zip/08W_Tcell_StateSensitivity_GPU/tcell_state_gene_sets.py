"""08W v1: prespecified mouse feature exclusions and descriptive readouts.

Case-insensitive exact gene-symbol matching; untranslated IDs and unknown symbols
are deliberately left unchanged. A feature mask acts on PCA inputs only.
The term 'technical' is an arm name, not a claim of technical origin.
"""

from __future__ import annotations


def _words(text):
    return tuple(text.split())


# The 13 protein-coding genes plus mt-genome rRNAs/tRNAs. Nuclear OXPHOS,
# Mrpl/Mrps genes, metallothioneins Mt1/Mt2 etc. are not mitochondrial-genome genes.
MT_ENCODED = _words("""
mt-Atp6 mt-Atp8 mt-Co1 mt-Co2 mt-Co3 mt-Cytb mt-Nd1 mt-Nd2 mt-Nd3 mt-Nd4
mt-Nd4l mt-Nd5 mt-Nd6 mt-Rnr1 mt-Rnr2 mt-Ta mt-Tc mt-Td mt-Te mt-Tf mt-Tg
mt-Th mt-Ti mt-Tk mt-Tl1 mt-Tl2 mt-Tm mt-Tn mt-Tp mt-Tq mt-Tr mt-Ts1 mt-Ts2
mt-Tt mt-Tv mt-Tw mt-Ty
""")

# Conservative cytosolic structural Rpl/Rps whitelist. Avoid Rps6ka*, Rps6kb*,
# pseudogenes, nuclear-encoded mitoribosomal proteins, assembly factors and
# ubiquitin/ribosome fusion genes such as Uba52/Fau; do not infer a complete
# ribosome biogenesis program from this score. Uba52/Fau are kept intentionally.
CYTOSOLIC_RIBOSOMAL = _words("""
Rpl3 Rpl3l Rpl4 Rpl5 Rpl6 Rpl7 Rpl7a Rpl7l1 Rpl8 Rpl9 Rpl10 Rpl10a Rpl10l
Rpl11 Rpl12 Rpl13 Rpl13a Rpl14 Rpl15 Rpl17 Rpl18 Rpl18a Rpl19 Rpl21 Rpl22
Rpl22l1 Rpl23 Rpl23a Rpl24 Rpl26 Rpl27 Rpl27a Rpl28 Rpl29 Rpl30 Rpl31 Rpl32
Rpl34 Rpl35 Rpl35a Rpl36 Rpl36a Rpl36al Rpl37 Rpl37a Rpl38 Rpl39 Rpl39l Rpl41
Rplp0 Rplp1 Rplp2 Rpsa Rps2 Rps3 Rps3a Rps3a1 Rps3a3 Rps4x Rps4y1 Rps4y2
Rps5 Rps6 Rps7 Rps8 Rps9 Rps10 Rps11 Rps12 Rps13 Rps14 Rps15 Rps15a Rps16
Rps17 Rps18 Rps19 Rps20 Rps21 Rps23 Rps24 Rps25 Rps26 Rps27 Rps27l Rps28 Rps29
""")

# Small sensitivity panel, NOT a dissociation label; AP-1 can reflect real
# receptor signalling and Hsp transcripts can mark bona fide in-situ tumor T cells.
# Authors' custom subset, not the published 17-gene score: Denisenko et al.,
# Genome Biol. 2020 https://doi.org/10.1186/s13059-020-02048-6
# and Chu et al., Nat Med. 2023 https://doi.org/10.1038/s41591-023-02371-y
ACUTE_STRESS = _words("""
Fos Fosb Jun Junb Jund Egr1 Atf3 Dusp1 Ier2 Ier3 Hspa1a Hspa1b Hspb1 Dnajb1
""")

# Mouse ThPOK and activation-dependent CD40L corroborate a helper program;
# neither is a positive/negative cell label. See https://pubmed.ncbi.nlm.nih.gov/23334788/
# and https://pmc.ncbi.nlm.nih.gov/articles/PMC3392968/.
ANCILLARY_HELPER = ("Zbtb7b", "Cd40lg")

# Checks on the original counts: overlap between readouts is allowed in principle.
# These are contextual marker panels, not labels/validation ground truth. The
# helper_naive_memory label describes a state also found in CD8 T cells.
STATE_READOUTS = {
    "exhaustion": _words("Pdcd1 Tox Lag3 Havcr2 Tigit Entpd1 Cxcl13"),
    "tcr_activation": _words("Cd69 Nr4a1 Nr4a2 Nr4a3 Icos Tnfrsf9"),
    "interferon": _words("Isg15 Ifit1 Ifit2 Ifit3 Mx1 Oas1a Irf7 Stat1"),
    "cycling": _words("Mki67 Top2a Cdk1 Ube2c Ccnb1 Ccnb2"),
    "cytotoxicity": _words("Prf1 Gzmb Gzma Gzmk Nkg7 Ccl5"),
    "helper_naive_memory": _words("Il7r Tcf7 Ccr7 Sell Lef1 Klf2"),
}

_by_symbol = {
    symbol.casefold(): label
    for label, members in (
        ("mt_encoded", MT_ENCODED),
        ("cytosolic_ribosomal", CYTOSOLIC_RIBOSOMAL),
        ("acute_stress", ACUTE_STRESS),
    )
    for symbol in members
}


def gene_module(symbol):
    """Return one prespecified group name, or the empty string if unassigned."""
    return _by_symbol.get(str(symbol).strip().casefold(), "")


def feature_exclusions(symbols, mode):
    """Return original feature symbols to omit for one sensitivity arm."""
    groups = {
        "none": (),
        "technical": ("mt_encoded", "cytosolic_ribosomal"),
        "technical_stress": ("mt_encoded", "cytosolic_ribosomal", "acute_stress"),
    }
    if mode not in groups:
        raise ValueError(f"Unknown 08W feature-exclusion mode: {mode!r}")
    return {symbol for symbol in symbols if gene_module(symbol) in groups[mode]}
