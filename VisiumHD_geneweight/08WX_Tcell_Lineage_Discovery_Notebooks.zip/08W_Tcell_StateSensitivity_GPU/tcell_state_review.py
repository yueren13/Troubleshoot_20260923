"""08W: paired graph endpoints from original assays; review one sparse graph at a time."""
from __future__ import annotations
import gc
import html
import json
import time
import zipfile
from pathlib import Path
from collections import OrderedDict
import numpy as np
import pandas as pd
import scipy.sparse as sp
import tcell_weighted_review as vr
import tcell_positive_review as cv
import tcell_positive_workflow as loader
import tcell_weighted_workflow as core
from tcell_state_gene_sets import gene_module, STATE_READOUTS

VERSION = '08W-review-1.0.0'
BLIND = ('broad_ratio_anchorblind', 'broad_no_technical_stress_anchorblind')
SUPPORT = (('Cd4','Zbtb7b'), ('Cd4','Cd40lg'), *cv.DEFAULT_GUIDE_PAIRS)
DIRECT = ('exclusive_CD4', 'exclusive_CD8')
PAIRS = OrderedDict([
    ('anchorblind_state_test', BLIND),
    ('technical_only', ('broad_ratio','broad_no_technical')),
    ('extra_acute_stress', ('broad_no_technical','broad_no_technical_stress')),
    ('full_state_exclusion', ('broad_ratio','broad_no_technical_stress')),
    ('scaled_detection_floor', ('selected_zscore','selected500_zscore')),
    ('scaling_at_500', ('selected500_centered','selected500_zscore')),
    ('scaling_on_full_panel', ('selected_centered','selected_zscore')),
])
ANCHOR_GENES = ('Cd4','Cd8a','Cd8b1')
HELPER = ('Zbtb7b','Cd40lg')
TECH_CLASSES = ('mt_encoded','cytosolic_ribosomal','acute_stress')


def _feature_use(table):
    return cv._feature_weights(table)


def _read_embedding(path):
    """Never materialize PCs, X or the distance graph when reading the all-cell fits."""
    import h5py
    with h5py.File(path, 'r') as f:
        graph_name = next((k for k in ('connectivities','neighbors_connectivities') if k in f['obsp']), None)
        if graph_name is None:
            raise ValueError(f'Missing expression-neighbor connectivities in {path}.')
        return {'obs':core._read_elem(f['obs']), 'var':core._read_elem(f['var']),
                'obsp':{'connectivities':core._read_elem(f['obsp'][graph_name])},
                'obsm':{'X_umap':core._read_elem(f['obsm/X_umap'])}}


def _read_modules(plan, obs):
    """Read the source count matrix in bounded stripes. 0 measured signal != absent assay."""
    import h5py
    inputs = plan['inputs']
    core._unchanged(inputs)
    path = inputs['baseline_path']
    with h5py.File(path,'r') as h:
        source_obs = core._read_elem(h['obs'])
        names = pd.Index(core._read_elem(h['var']).index.astype(str))
        if not source_obs.index.astype(str).equals(obs.index.astype(str)) or names.has_duplicates:
            raise ValueError('Original count axes are invalid or differ from the marker cache.')
        if not np.array_equal(source_obs.total_counts.to_numpy(), obs.total_counts.to_numpy()):
            raise ValueError('Full-library normalization denominator changed.')
        del source_obs
        groups = OrderedDict((key, [g for g in names if gene_module(g)==key]) for key in TECH_CLASSES)
        groups.update((key,list(genes)) for key,genes in STATE_READOUTS.items())
        groups.update((f'single_{gene}',[gene]) for gene in HELPER)
        genemap = {gene:i for i,gene in enumerate(names)}
        group_cols, group_rows, audit = [], [], []
        for j,(k,gs) in enumerate(groups.items()):
            for g in gs:
                present = g in genemap
                audit.append({'program':k,'gene':g,'source_assay_present':present})
                if present:
                    group_rows.append(genemap[g]);group_cols.append(j)
        W = sp.csr_matrix((np.ones(len(group_rows)),(group_rows,group_cols)),shape=(len(names),len(groups)))
        audit_frame = pd.DataFrame(audit,columns=['program','gene','source_assay_present'])
        # Include zero-assay technical categories explicitly in the coverage table.
        available = np.asarray(W.sum(axis=0)).ravel().astype(int)
        totals = np.zeros((len(obs),len(groups)),dtype=np.float64)
        layer = h['layers/counts']
        shape = tuple(layer.attrs['shape']); enc = layer.attrs['encoding-type']
        if isinstance(enc,bytes): enc = enc.decode()
        if shape != (len(obs),len(names)): raise ValueError('Invalid original sparse count dimensions.')
        p = layer['indptr'][:]
        if enc not in ('csr_matrix','csc_matrix'): raise ValueError('08W expects sparse CSR/CSC original counts.')
        if enc == 'csr_matrix':
            for start in range(0,len(obs),8192):
                end = min(start+8192,len(obs)); lo,hi=int(p[start]),int(p[end])
                arr = sp.csr_matrix((layer['data'][lo:hi],layer['indices'][lo:hi],p[start:end+1]-lo),
                                    shape=(end-start,len(names)))
                totals[start:end]= (arr @ W).toarray()
        else:
            # Read only relevant columns, streamed; one full matrix is never materialized.
            for g in np.unique(group_rows):
                lo,hi=int(p[g]),int(p[g+1])
                rows,data = layer['indices'][lo:hi],layer['data'][lo:hi]
                for j in W.indices[W.indptr[g]:W.indptr[g+1]]:
                    np.add.at(totals[:,j],rows,data)
    if np.any(~np.isfinite(totals)) or np.any(totals<0) or np.any(totals!=np.rint(totals)):
        raise ValueError('Original program/marker count sums are invalid.')
    totals[:,available==0] = np.nan
    modules = {}; extras = {}
    depth = obs['total_counts'].to_numpy(float)
    for j,(k,_) in enumerate(groups.items()):
        if k.startswith('single_'):
            extras[k[7:]]=None if available[j]==0 else totals[:,j].copy()
        else:
            # Fraction of full-source UMIs belonging to measured members of this fixed set.
            modules[k] = totals[:,j]/depth
    coverage = pd.DataFrame({'program':list(groups),'n_genes_available':available,
        'fraction_cells_any_detection':[float((totals[:,j]>0).mean()) if available[j] else np.nan for j in range(len(groups))]})
    core._unchanged(inputs)
    return modules,extras,audit_frame,coverage


def _strata_frame(obs):
    samples=obs['sample_id'].astype(str).to_numpy(); depth=pd.to_numeric(obs['total_counts']).to_numpy(float)
    _,codes,levels=cv._depth_strata(samples,depth)
    cond=obs[['sample_id','condition']].astype(str).drop_duplicates()
    if cond.sample_id.duplicated().any():
        raise ValueError('Condition is not unique within sample; cannot compute replicate-level condition summaries.')
    levels=levels.copy();levels['condition']=levels['sample'].map(cond.set_index('sample_id').condition)
    return np.asarray(codes), levels


def _endpoints(detection):
    """Return endpoint -> (positive focals, comparator focals, target neighbors, guide set, target set)."""
    d=detection
    cd4=d.get('Cd4'); a=d.get('Cd8a'); b=d.get('Cd8b1')
    ex4=ex8=None
    if cd4 is not None and a is not None and b is not None:
        ex4=cd4 & ~(a|b);ex8=(a|b)&~cd4
    endpoints=OrderedDict()
    endpoints[DIRECT[0]]=(ex4,ex8,ex4,ANCHOR_GENES,ANCHOR_GENES)
    endpoints[DIRECT[1]]=(ex8,ex4,ex8,ANCHOR_GENES,ANCHOR_GENES)
    for g,t in SUPPORT:
        guide=d.get(g)
        endpoints[f'{g}_to_{t}']=(guide,None if guide is None else ~guide,d.get(t),(g,),(t,))
    return endpoints


def _stratified_neighbors(name, graph, endpoints, strata, levels, weights, min_per_group=5):
    """Absolute probability differences vs composition expectation; excluded self; shared-focal strata handled downstream."""
    K=len(levels);n=len(strata)
    diagonal=graph.diagonal().astype(float)
    degree=np.asarray(graph.sum(axis=1,dtype=np.float64)).ravel()-diagonal
    valid=degree>1e-10
    if (degree < -1e-7).any(): raise ValueError('Invalid graph: negative neighbor mass.')
    counts=np.bincount(strata,minlength=K)
    rows=[]
    for endpoint,(case,ctrl,target,focal_g,target_g) in endpoints.items():
        measurable=all(a is not None for a in (case,ctrl,target))
        focal_in=any(weights.get(g,0)>0 for g in focal_g); target_in=any(weights.get(g,0)>0 for g in target_g)
        mat=levels.copy();mat['method']=name;mat['endpoint']=endpoint
        mat['assays_available']=measurable;mat['focal_gene_used_in_fit']=bool(focal_in)
        mat['neighbor_target_used_in_fit']=bool(target_in);mat['both_sides_held_out']=not(focal_in or target_in)
        mat['nonself_neighbor_coverage']=valid.mean()
        if not measurable:
            mat['n_focal_positive']=0;mat['n_focal_comparator']=0;mat['eligible']=False
            for field in ('raw_pp','expected_pp','excess_pp'):mat[field]=np.nan
            rows.append(mat);continue
        # One sparse graph-times-vector per endpoint; V-equivalent: subtract the neighbor's
        # own stratum detection frequency before averaging across an ego's adjacent cells.
        target=target.astype(np.float64)
        base=np.bincount(strata,weights=target,minlength=K)/counts
        expected=base[strata]
        def neighbor_vec(x):
            return np.divide(np.asarray(graph@x).ravel()-diagonal*x,degree,out=np.zeros(n),where=valid)
        raw,composition=neighbor_vec(target),neighbor_vec(expected)
        left=case & valid;right=ctrl & valid
        nleft=np.bincount(strata[left],minlength=K);nright=np.bincount(strata[right],minlength=K)
        def diff(v):
            def avg(side,N):
                return np.divide(np.bincount(strata[side],weights=v[side],minlength=K),N,
                                 out=np.full(K,np.nan),where=N>0)
            return 100.*(avg(left,nleft)-avg(right,nright))
        mat['n_focal_positive']=nleft;mat['n_focal_comparator']=nright
        mat['eligible']=(nleft>=min_per_group)&(nright>=min_per_group)
        mat['raw_pp']=diff(raw);mat['expected_pp']=diff(composition)
        mat['excess_pp']=mat['raw_pp']-mat['expected_pp']
        rows.append(mat)
    return pd.concat(rows,ignore_index=True)


def _summarize_endpoints(strata):
    keys=['endpoint','sample','depth_quintile']
    methods=strata.method.unique()
    if strata.duplicated(['method']+keys).any(): raise ValueError('Duplicate method/stratum contrasts.')
    shared=strata.groupby(keys,sort=False).eligible.agg(['all','size'])
    shared['shared_eligible']=shared['all']&(shared['size']==len(methods))
    s=strata.merge(shared[['shared_eligible']].reset_index(),on=keys,validate='many_to_one')
    group=['method','endpoint','sample','condition']
    meta=['assays_available','both_sides_held_out','focal_gene_used_in_fit','neighbor_target_used_in_fit','nonself_neighbor_coverage']
    # Keep even all-ineligible samples visible, with missing effects rather than artificial zeros.
    ds=s.groupby(group,sort=False)[meta].first().reset_index()
    good=s[s.shared_eligible].groupby(group,sort=False).agg(
        n_depth_strata=('depth_quintile','size'),n_focal_positive=('n_focal_positive','sum'),
        n_focal_comparator=('n_focal_comparator','sum'),raw_pp=('raw_pp','mean'),expected_pp=('expected_pp','mean'),
        excess_pp=('excess_pp','mean')).reset_index()
    ds=ds.merge(good,on=group,how='left',validate='one_to_one')
    countcols=['n_depth_strata','n_focal_positive','n_focal_comparator']
    ds[countcols]=ds[countcols].fillna(0).astype(int)
    # A balanced measure counts the two directional contrasts equally rather than rewarding the majority anchor.
    a=ds[ds.endpoint==DIRECT[0]].copy();b=ds[ds.endpoint==DIRECT[1]].set_index(['method','sample']).reindex(
        pd.MultiIndex.from_frame(a[['method','sample']]))
    a['endpoint']='balanced_exclusive_anchors'
    for col in ('raw_pp','expected_pp','excess_pp'):
        a[col]=(a[col].to_numpy()+b[col].to_numpy())/2
    ds=pd.concat([ds,a],ignore_index=True)
    keys=['method','endpoint']
    summary=ds.groupby(keys,sort=False).agg(n_samples_total=('sample','size'),n_samples_eligible=('excess_pp','count'),
        n_positive_samples=('excess_pp',lambda x:int((x>0).sum())),sample_balanced_excess_pp=('excess_pp','mean'),
        sample_balanced_raw_pp=('raw_pp','mean'),both_sides_held_out=('both_sides_held_out','all'),
        target_used_in_fit=('neighbor_target_used_in_fit','any'),assays_available=('assays_available','all')).reset_index()
    paired=[]
    for contrast,(reference,test) in PAIRS.items():
        if not {reference,test}.issubset(methods):continue
        k=['endpoint','sample','condition']
        cols=k+['excess_pp','n_depth_strata','both_sides_held_out']
        ref=ds.loc[ds.method.eq(reference),cols];alt=ds.loc[ds.method.eq(test),cols]
        t=ref.merge(alt,on=k,suffixes=('_reference','_test'),validate='one_to_one')
        t['contrast']=contrast;t['reference']=reference;t['test']=test
        t['paired_delta_pp']=t.excess_pp_test-t.excess_pp_reference
        paired.append(t)
    df=pd.concat(paired,ignore_index=True) if paired else pd.DataFrame()
    def delta_summary(keys):
        if df.empty:return pd.DataFrame()
        return df.groupby(keys,sort=False).agg(n_samples_total=('sample','size'),
            n_samples_eligible=('paired_delta_pp','count'),n_samples_improving=('paired_delta_pp',lambda x:int((x>0).sum())),
            mean_paired_delta_pp=('paired_delta_pp','mean'),median_paired_delta_pp=('paired_delta_pp','median')).reset_index()
    return s,ds,summary,df,delta_summary(['contrast','endpoint']),delta_summary(['contrast','condition','endpoint'])


def _program_by_population(obs, modules, strata, levels):
    """Raw T cell 1/2 program fractions plus matched depth-bin contrasts within each sample."""
    popul=obs.population.astype(str).to_numpy()
    populations=sorted(pd.unique(popul)); rec=[]
    for code,r in levels.iterrows():
        for pop in populations:
            ix=(strata==code)&(popul==pop); n=int(ix.sum())
            for program,val in modules.items():
                rec.append(dict(sample=r['sample'],condition=r['condition'],depth_quintile=r.depth_quintile,
                    population=pop,program=program,n_cells=n,
                    mean_full_library_percent=float(np.mean(val[ix])*100) if n and np.isfinite(val[0]) else np.nan))
    d=pd.DataFrame(rec)
    matches=[]
    if len(populations)==2:
        keys=['sample','condition','depth_quintile','program'];vals=keys+['n_cells','mean_full_library_percent']
        a=d.loc[d.population.eq(populations[0]),vals];b=d.loc[d.population.eq(populations[1]),vals]
        z=a.merge(b,on=keys,suffixes=('_a','_b'),validate='one_to_one')
        z['delta_pp_b_minus_a']=(z.mean_full_library_percent_b-z.mean_full_library_percent_a).where(
            (z.n_cells_a>=5)&(z.n_cells_b>=5))
        matches=z.groupby(['sample','condition','program'],sort=False).delta_pp_b_minus_a.agg(['mean','count']).reset_index()
        matches=matches.rename(columns={'mean':'mean_depth_matched_delta_pp_b_minus_a','count':'n_eligible_strata'})
        matches['population_a'],matches['population_b']=populations
    return d,pd.DataFrame(matches)


def _cluster_programs(modules, strata, levels, labels, name):
    """Within-depth-quintile association, sample-weighted; all-cell cluster means for original assay."""
    lab,categories=pd.factorize(labels,sort=True); L=len(categories);K=len(levels)
    codes=strata*L+lab; n=np.bincount(codes,minlength=K*L).reshape(K,L); levels=levels.reset_index(drop=True)
    denom=np.maximum(n,1); ng=np.maximum(n.sum(axis=1),1);nc=np.maximum(n.sum(axis=0),1)
    samples=levels['sample'].astype(str).to_numpy()
    sample_rows=[];means=[]
    for prog,v in modules.items():
        available=np.isfinite(v[0])
        if available:
            sums=np.bincount(codes,weights=v,minlength=K*L).reshape(K,L)
            sumsq=np.bincount(strata,weights=v*v,minlength=K)
            gmean=sums.sum(axis=1)/ng
            ssb=(n*(sums/denom-gmean[:,None])**2).sum(axis=1)
            sst=np.maximum(sumsq-ng*gmean**2,0.)
        for sample in pd.unique(samples):
            ix=samples==sample
            y=ssb[ix].sum()/sst[ix].sum() if available and sst[ix].sum()>1e-18 else np.nan
            sample_rows.append({'method':name,'sample':sample,'condition':levels.loc[np.flatnonzero(ix)[0],'condition'],
                   'program':prog,'cluster_eta2_within_depth_strata':float(y),'assay_available':available})
        means.extend([{'method':name,'cluster':c,'n_cells':int(nc[j]),'program':prog,
            'mean_percent_full_library':100*sums[:,j].sum()/nc[j] if available else np.nan}
            for j,c in enumerate(categories)])
    return sample_rows,means


def _quick_v(a,b):
    """Bias-adjusted Cramér's V (same expression as 08V) for compact factorized marginals."""
    a,k=pd.factorize(a);b,l=pd.factorize(b);K=len(k);L=len(l);N=len(a)
    if min(K,L)<2 or N<2:return np.nan
    H=np.bincount(a*L+b,minlength=K*L).reshape(K,L);E=H.sum(axis=0)[None,:]*H.sum(axis=1)[:,None].astype(float)/N
    phi=max(0,((H-E)**2/E).sum()/N-(K-1)*(L-1)/(N-1))
    divisor=min(K-1-(K-1)**2/(N-1),L-1-(L-1)**2/(N-1))
    return np.sqrt(phi/divisor) if divisor>0 else np.nan


def _plot_endpoints(deltas,figdir):
    if deltas.empty:return
    plt=vr._plot_style()
    a=deltas[deltas.contrast=='anchorblind_state_test'];b=deltas[deltas.contrast=='scaled_detection_floor']
    fig,axs=plt.subplots(1,2,figsize=(12.5,5.2),layout='constrained')
    for ax,tab,order,title in [(axs[0],a,[*DIRECT,'balanced_exclusive_anchors','Cd4_to_Zbtb7b','Cd4_to_Cd40lg','Cd8a_to_Cd8b1'],
                'Remove technical + acute stress genes\nBoth fits omit coreceptors and helper probes'),
            (axs[1],b,['Cd8a_to_Cd8b1',*[f'{g}_to_{t}' for g,t in SUPPORT if g=='Foxp3']],
                'Raise the gene detection floor\nBoth selected panels use unit-variance scaling')]:
        ax.axvline(0,color='#586573',lw=.9); 
        for j,ep in enumerate(order):
            v=tab.loc[tab.endpoint.eq(ep),'paired_delta_pp'].dropna().to_numpy()
            if not len(v): ax.text(.015,j,'unavailable',transform=ax.get_yaxis_transform(),color='0.5',fontsize=8);continue
            ax.scatter(v,j+np.linspace(-.12,.12,len(v)),s=22,alpha=.7,color='#29788a')
            ax.scatter(v.mean(),j,s=65,marker='D',color='#c8542e',zorder=3)
        pretty={'exclusive_CD4':'CD4 anchor','exclusive_CD8':'CD8 anchor','balanced_exclusive_anchors':'Balanced anchors'}
        ax.set_yticks(np.arange(len(order)),[pretty.get(x,x.replace('_to_',' → ')) for x in order]);ax.invert_yaxis()
        ax.set_xlabel('Paired change in excess neighbor detection (pp)');ax.set_title(title,fontsize=10);ax.grid(axis='y',alpha=.17)
    fig.suptitle('Each dot is one sample; diamonds give samples equal weight')
    vr._save_figure(fig,figdir/'paired_changes.png',plt,dpi=140)


def _plot_umaps(data,indices,anchors,figdir,methods):
    plt=vr._plot_style()
    palette=['#ced3d8','#2c75aa','#d77533','#813e88']; axnames=['No direct marker','CD4 only','CD8 only','Both']
    from matplotlib.lines import Line2D
    for group in ('selected','broad'):
        selected=[n for n in methods if n.startswith(group)]
        if not selected:continue
        cols=min(3,len(selected));nr=(len(selected)+cols-1)//cols
        fig,axes=plt.subplots(nr,cols,figsize=(4.6*cols,4.15*nr),squeeze=False)
        for ax in axes.ravel():ax.set_visible(False)
        for name,ax in zip(selected,axes.ravel()):
            ax.set_visible(True)
            xy=data[name]
            if anchors is not None:
                for level in (0,2,1,3):
                    k=anchors[indices]==level
                    ax.scatter(*xy[k].T,c=palette[level],s=1.1 if level==0 else 3.1,alpha=.28 if level==0 else .71,lw=0,rasterized=True)
            else:ax.scatter(*xy.T,c=palette[0],s=1,lw=0)
            ax.set(xlabel='UMAP 1',ylabel='UMAP 2',title=name.replace('_',' '));ax.set_aspect('equal',adjustable='datalim')
            ax.set_xticks([]);ax.set_yticks([])
        fig.legend([Line2D([0],[0],marker='o',color=c,linestyle='',markersize=5) for c in palette],axnames,
                   loc='lower center',ncol=4,frameon=False,fontsize=9)
        fig.suptitle('Original observed coreceptor evidence · identical display cells' if anchors is not None else 'Coreceptor assay incomplete')
        fig.tight_layout(rect=(0,.05,1,.96));vr._save_figure(fig,figdir/f'anchor_umaps_{group}.png',plt,dpi=130)


def _dotplots(primary_aggs, genes, figdir):
    plt=vr._plot_style()
    gmax=np.max(np.vstack([agg['mean_log'].max(axis=0) for agg in primary_aggs.values()]),axis=0)
    for name,agg in primary_aggs.items():
        for panel in ('lineage','states'):
            groups=vr.PANELS[panel]; cols=[genes.index(g) for grp in groups for g in vr.MARKER_GROUPS[grp] if g in genes]
            if not cols:continue
            vr._dotplot(agg,genes,groups,float(max(gmax[cols])),gmax,figdir/f'dotplot_{name}_{panel}.png',
                f'{name} · original {panel} markers',scaled=False,max_clusters_per_page=30,plt=plt)


def build_reports(plan, branches, run_root, *, max_plot_cells=60000, primary_cluster_key='leiden_0.4',
                  min_per_group=5):
    """All available cells, shared eligible sample/depth strata, audited feature masks. Output paths and counts returned."""
    start=time.monotonic();root=Path(run_root).resolve();out=root/'review';figdir=out/'figures';figdir.mkdir(parents=True,exist_ok=True)
    if not branches or not isinstance(min_per_group,int) or min_per_group<1 or not isinstance(max_plot_cells,int) or max_plot_cells<1:
        raise ValueError('Require completed branches and positive integer display/support limits.')
    log,counts,genes,obs=loader.load_marker_data(plan['marker_cache_dir'])
    if len(obs)!=plan['n_cells'] or core.ordered_id_hash(obs.index)!=plan['cell_order_hash']:
        raise ValueError('Original marker metadata do not match the 08W plan.')
    genes,C,L,B=vr._prepare_markers(log,counts,genes,len(obs));del log,counts
    depth=obs.total_counts.to_numpy(float)
    expected=C.multiply(float(plan['settings']['target_sum'])/depth[:,None]).tocsr();np.log1p(expected.data,out=expected.data)
    err=expected-L
    if err.nnz and np.abs(err.data).max()>2e-4:raise ValueError('Marker assays are not original full-library normalized.')
    del expected,err
    print('08W: reading original counts for technical, state and helper-marker readouts.',flush=True)
    modules,extra,readout_audit,coverage=_read_modules(plan,obs)
    # Helper probes were not always present in older marker caches.
    detector={g:B[:,genes.index(g)].toarray().ravel().astype(bool) for g in dict.fromkeys([*ANCHOR_GENES,*[x for p in SUPPORT for x in p]]) if g in genes}
    detector.update({k:None if v is None else v>0 for k,v in extra.items()})
    ends=_endpoints(detector)
    strata,levels=_strata_frame(obs)
    pop,matchpop=_program_by_population(obs,modules,strata,levels)
    for table,file in [(readout_audit,'program_gene_coverage.csv'),(coverage,'program_availability.csv'),
                       (pop,'programs_by_original_population_sample_depth.csv'),(matchpop,'programs_population_delta_by_sample.csv')]:
        vr._save_csv(table,out/file)
    rng=np.random.default_rng(17);indices=np.sort(rng.choice(len(obs),min(max_plot_cells,len(obs)),replace=False))
    anchor=None
    if ends[DIRECT[0]][0] is not None:
        anchor=detector['Cd4'].astype('uint8')+2*(detector['Cd8a']|detector['Cd8b1']).astype('uint8')
    allrows=[];summaries=[];audits=[];sampleprogram=[];clusterprogram=[];markers=[];umaps={};aggs={};composition=[];cluster_qc=[]
    depth_log=np.log1p(depth); samples=obs.sample_id.astype(str).to_numpy(); cond=obs.condition.astype(str).to_numpy()
    sample_ix={s:np.flatnonzero(samples==s) for s in pd.unique(samples)}
    for method,path in branches.items():
        print(f'08W: reviewing {method} on original evidence ({len(obs):,} cells).',flush=True)
        ad=_read_embedding(path)
        frame,graph,var=cv._method_parts(ad,obs.index,primary_cluster_key)
        if any(c not in frame or not frame[c].astype(str).reset_index(drop=True).equals(obs[c].astype(str).reset_index(drop=True))
               for c in ('sample_id','condition','population')):raise ValueError(f'Observation annotation mismatch: {method}.')
        weights=_feature_use(var)
        always=set(plan['heldout_genes'])
        required=always|set([*ANCHOR_GENES,*HELPER]) if method in BLIND else always
        active=[g for g in required if weights.get(g,0)>0]
        if active:raise ValueError(f'{method}: held-out evaluation genes were active in the fitted representation: {active}.')
        for gene in sorted(set([*required,*ANCHOR_GENES,*[g for pair in SUPPORT for g in pair]])):
            anypos=(detector.get(gene) is not None)
            audits.append({'method':method,'gene':gene,'source_assay_available':anypos,
                'n_cells_positive':int(detector[gene].sum()) if anypos else np.nan,
                'positive_weight':weights.get(gene,0)>0,'weight':weights.get(gene,0.0),'declared_holdout':gene in required})
        allrows.append(_stratified_neighbors(method,graph,ends,strata,levels,weights,min_per_group))
        um=np.asarray(ad['obsm']['X_umap'])
        if um.shape!=(len(obs),2) or not np.isfinite(um).all():raise ValueError('Invalid UMAP.')
        umaps[method]=um[indices].copy()
        keys=[c for c in frame if c.startswith('leiden_')]
        for key in keys:
            labels=frame[key].astype(str).to_numpy()
            lab,clusters=pd.factorize(labels);sz=np.bincount(lab)
            within=[vr._eta_squared(depth_log[ix],lab[ix],len(sz)) for ix in sample_ix.values()]
            finite=np.asarray(within)[np.isfinite(within)]
            summaries.append(dict(method=method,clustering=key,n_cells=len(obs),n_clusters=len(sz),n_clusters_under_1000=int((sz<1000).sum()),
                fraction_cells_in_clusters_under_1000=sz[sz<1000].sum()/len(obs),fraction_cells_in_clusters_under_100=sz[sz<100].sum()/len(obs),
                pooled_log_depth_eta_squared=vr._eta_squared(depth_log,lab,len(sz)),sample_balanced_log_depth_eta_squared=np.mean(finite) if len(finite) else np.nan,
                sample_cramers_v=_quick_v(labels,samples),condition_cramers_v=_quick_v(labels,cond),
                original_population_cramers_v=_quick_v(labels,obs.population.to_numpy())))
            if key!=primary_cluster_key:continue
            agg=vr._aggregate(labels,L,C,B,genes)
            markers.append(agg['frame'].assign(method=method,clustering=key))
            # Only cluster aggregates are retained for comparable panel color limits.
            aggs[method]={k:agg[k] for k in ('mean_log','fractions','levels','n_cells')}
            sa,cl=_cluster_programs(modules,strata,levels,labels,method);sampleprogram+=sa;clusterprogram+=cl
            t=obs[['sample_id','condition','population']].copy();t['cluster']=labels
            if anchor is not None:
                t['cd4_only']=(anchor==1);t['cd8_only']=(anchor==2);t['both']=(anchor==3)
                composition.append(t.groupby(['sample_id','condition','population','cluster'],observed=True).agg(n_cells=('cluster','size'),
                    n_cd4_only=('cd4_only','sum'),n_cd8_only=('cd8_only','sum'),n_double_positive=('both','sum')).reset_index().assign(method=method))
            else: composition.append(t.groupby(['sample_id','condition','population','cluster'],observed=True).size().rename('n_cells').reset_index().assign(method=method))
            t['full_library_counts']=depth;t['detected_genes']=obs.n_genes.to_numpy()
            cluster_qc.append(t.groupby('cluster').agg(n_cells=('cluster','size'),median_total_counts=('full_library_counts','median'),
                                  median_detected_genes=('detected_genes','median')).reset_index().assign(method=method))
        del ad,graph,var,frame,um
        gc.collect()
    tables=_summarize_endpoints(pd.concat(allrows,ignore_index=True))
    names=['neighbor_strata.csv.gz','neighbor_by_sample.csv','neighbor_summary.csv','paired_deltas_by_sample.csv','paired_delta_summary.csv','paired_deltas_by_condition.csv']
    for fname,t in zip(names,tables):vr._save_csv(t,out/fname)
    metrics=pd.DataFrame(summaries);spg=pd.DataFrame(sampleprogram)
    mt=pd.concat(markers,ignore_index=True)
    audit=pd.DataFrame(audits)
    for t,file in [(audit,'actual_holdout_audit.csv'),(metrics,'cluster_metrics.csv'),
            (mt,'cluster_marker_statistics.csv.gz'),(pd.concat(composition,ignore_index=True),'cluster_observed_anchors_by_sample.csv.gz'),
            (pd.concat(cluster_qc,ignore_index=True),'cluster_depth.csv'),(spg,'program_cluster_eta2_by_sample.csv'),
            (spg.groupby(['method','program'],sort=False).cluster_eta2_within_depth_strata.agg(['mean','count']).reset_index().rename(columns={'mean':'sample_balanced_eta2','count':'n_informative_samples'}),'program_cluster_eta2_summary.csv'),
            (pd.DataFrame(clusterprogram),'cluster_program_fractions.csv.gz')]:vr._save_csv(t,out/file)
    _plot_endpoints(tables[3],figdir);_plot_umaps(umaps,indices,anchor,figdir,branches);_dotplots(aggs,genes,figdir)
    _html_report(out,tables[4],metrics,primary_cluster_key,len(obs),len(sample_ix))
    result={'version':VERSION,'status':'complete','index_path':str(out/'index.html'),'review_dir':str(out),
        'paired_delta_summary_path':str(out/'paired_delta_summary.csv'),'n_cells':len(obs),'n_samples':len(sample_ix),
        'methods':list(branches),'primary_cluster_key':primary_cluster_key,'min_focals_per_group_per_shared_depth_stratum':min_per_group,
        'elapsed_seconds':time.monotonic()-start}
    core.save_json(out/'report_manifest.json',result)
    return result


def _html_report(out, paired, metrics, primary, n_cells, n_samples):
    """Offline report landing page; all links remain relative to the review folder."""
    out=Path(out)
    def table(df):
        if df.empty:return '<p>No shared eligible observations for this summary.</p>'
        return '<div class="scroll">'+df.to_html(index=False,na_rep='—',border=0,escape=True,float_format=lambda x:f'{x:.3f}')+'</div>'
    def image(name):
        path=out/'figures'/name
        return f'<a href="figures/{html.escape(name)}"><img loading="lazy" src="figures/{html.escape(name)}" alt="{html.escape(path.stem)}"></a>' if path.is_file() else ''
    blind=paired.loc[paired.contrast.eq('anchorblind_state_test')].copy() if not paired.empty else paired
    scaling=paired.loc[paired.contrast.eq('scaled_detection_floor') & paired.endpoint.str.contains('Foxp3|Cd8a_to_Cd8b1')].copy() if not paired.empty else paired
    cols=['endpoint','n_samples_eligible','n_samples_improving','mean_paired_delta_pp','median_paired_delta_pp']
    tabs=sorted(p for p in out.glob('*.csv*') if p.is_file())
    table_links=''.join(f'<li><a href="{html.escape(p.name)}">{html.escape(p.name)}</a></li>' for p in tabs)
    dot_links=''.join(f'<li><a href="figures/{html.escape(p.name)}">{html.escape(p.stem)}</a></li>' for p in sorted((out/'figures').glob('dotplot*.png')))
    (out/'index.html').write_text(f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>08W · T-cell lineage and state sensitivity</title><style>
body{{margin:0;background:#f4f7f7;color:#19343b;font:16px/1.55 system-ui,sans-serif}}main{{max-width:1120px;margin:auto;padding:34px 5vw 80px;background:#fff}}
h1,h2,h3{{line-height:1.23}}h2{{border-top:1px solid #bfd4d7;padding-top:22px;margin-top:38px}}a{{color:#036776}}img{{max-width:100%;height:auto}}
.scroll{{overflow-x:auto}}table{{border-collapse:collapse;font-size:.88em}}th,td{{padding:6px 9px;border-bottom:1px solid #dae4e5;text-align:left}}th{{background:#e4f2f1}}
ul.files{{columns:2;overflow-wrap:anywhere}}@media(max-width:700px){{ul.files{{columns:1}}}} small{{color:#536870}}</style></head><body><main>
<small>08W · Adagrasib mouse Visium HD</small><h1>Can we recover an independent CD4/CD8 lineage signal?</h1>
<p>{n_cells:,} cells · {n_samples} samples · {html.escape(primary)} for primary clustering summaries. Projection plots use identical sampled display cells; the quantitative analyses use all eligible observations.</p>
<h2>1 · Two-sided coreceptor holdout</h2>
<p>Compare the matched broad, anchor-blind control with its technical + acute stress mask. Both omit Cd4, Cd8a, Cd8b1, Zbtb7b and Cd40lg from distance calculations. The original four Foxp3 companions remain withheld, but Foxp3 itself can contribute. The exact fit weights are in <a href="actual_holdout_audit.csv">the audit</a>.</p>
<p>The CD4 direction asks how much more likely a nonself expression neighbor is CD4-only when the focal cell is CD4-only rather than CD8-only. The CD8 direction reverses both roles. CD8 is detection of Cd8a or Cd8b1. The balanced endpoint averages those two results. Companion checks compare guide-positive with guide-negative focal cells. All results account for the sample and depth composition of the neighbors, compare focal cases and controls within sample/depth strata, and give eligible samples equal weight. Units are percentage points. No single-cell classifications or population frequencies are inferred.</p>
{table(blind[cols] if not blind.empty else blind)}
{image('paired_changes.png')}
<h2>2 · Detection floor and Treg companions</h2><p>Test ≥500 detections within the same selected, z-scored panel. Look for a consistent preservation of all four Foxp3-companion signals alongside a reduction in cells in tiny clusters. A change in UMAP alone is insufficient.</p>
{table(scaling[cols] if not scaling.empty else scaling)}
<h2>3 · Depth, fragmentation and state</h2>
{table(metrics.loc[metrics.clustering.eq(primary),['method','n_clusters','fraction_cells_in_clusters_under_1000','sample_balanced_log_depth_eta_squared','original_population_cramers_v']])}
<p>Compare the original T cell 1 and T cell 2 <a href="programs_population_delta_by_sample.csv">within each sample after depth stratification</a>. Then check <a href="program_cluster_eta2_summary.csv">how strongly the new partitions reflect measured programs</a>, including protected exhaustion, activation, interferon, cytotoxicity and cycle panels. Program fractions use the original full library denominator. Unmeasured programs are unavailable. Changes in treatment association are descriptive, not optimization targets.</p>
<h2>4 · Original marker evidence</h2>{image('anchor_umaps_broad.png')}{image('anchor_umaps_selected.png')}
<details><summary>Leiden lineage and state marker dotplots</summary><ul class="files">{dot_links}</ul></details>
<h2>Tables</h2><ul class="files">{table_links}</ul><p><small>Zero detection is not biological absence. These are internal validation markers; do not force labels onto uninformative cells.</small></p></main></body></html>''',encoding='utf-8')


def make_return_bundle(plan, run_root, destination=None, *, max_bytes=25_000_000):
    """Write report tables, prioritized figures and receipts; no per-cell arrays or models."""
    import os, tempfile
    root=Path(run_root).resolve();out=root/'review'; pdir=Path(plan['plan_dir'])
    if not (out/'report_manifest.json').is_file():raise FileNotFoundError('08W report did not finish. The review bundle cannot be built.')
    target=Path(destination or root/'08W_return_to_chat.zip').resolve();target.parent.mkdir(parents=True,exist_ok=True)
    priority={}; omitted=[]
    def add(path,name,p):
        if Path(path).is_file():priority[name]=(p,Path(path))
    for fn in ('plan.json','branch_audit.csv','feature_audit.csv','feature_class_counts.csv','source_checks.json','preparation_spec.json'):
        add(pdir/fn,'preparation/'+fn,0)
    for key in ('audit_path','feature_class_counts_path'):
        if plan.get(key):
            path=Path(plan[key]);add(path,'preparation/'+path.name,0)
    for fn in ('comparison_complete.json','gpu_runtime.json','gpu_settings.json','launch.json'):add(root/fn,'runtime/'+fn,0)
    for path in out.rglob('*'):
        if not path.is_file():continue
        r=path.relative_to(out).as_posix()
        if r.endswith(('.csv','.csv.gz','.json')):add(path,'review/'+r,1)
        elif path.suffix=='.png':add(path,'review/'+r,2 if path.name=='paired_changes.png' else (3 if path.name.startswith('anchor_umaps_') else 4))
    included=[]
    tmpfile=tempfile.NamedTemporaryFile(prefix='08W_return_',suffix='.zip',dir=target.parent,delete=False)
    temp=Path(tmpfile.name);tmpfile.close()
    try:
        with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for name,(_priority,path) in sorted(priority.items(),key=lambda item:(item[1][0],item[0])):
                if z.fp.tell()+path.stat().st_size+120000>max_bytes:
                    omitted.append(name);continue
                z.write(path,name);included.append(name)
            manifest={'version':VERSION,'maximum_bytes':max_bytes,'files':included,'omitted_for_size':omitted,
                'full_review_on_ec2':str(out),'contains_per_cell_data_or_embeddings':False}
            z.writestr('bundle_manifest.json',json.dumps(manifest,indent=2))
            # Compact index links only to actual contents when low-priority files were omitted.
            links=''.join(f'<li><a href="{html.escape(n)}">{html.escape(n)}</a></li>' for n in included)
            z.writestr('index.html','<!doctype html><html lang="en"><head><meta charset="utf-8"><title>08W return package</title></head><body><h1>08W return package</h1><p>Open review/paired_delta_summary.csv first. The complete report stays on EC2; any size-limited omissions are listed in bundle_manifest.json.</p><ul>'+links+'</ul></body></html>')
        if temp.stat().st_size>max_bytes:raise RuntimeError('08W return archive exceeds its size limit; no partial archive was published.')
        os.replace(temp,target)
    finally:
        if temp.exists():temp.unlink()
    print(f'Return 08W results: {target} ({target.stat().st_size/1e6:.2f} MB)',flush=True)
    return target
