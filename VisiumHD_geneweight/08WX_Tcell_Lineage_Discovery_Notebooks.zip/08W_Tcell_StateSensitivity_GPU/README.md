# 08W | T-cell lineage vs cell state

Place the standalone notebook beside 08V on EC2, restart the working RAPIDS UV kernel, and Run All. No H5AD needs to be selected. Keep the original 08V run and source caches on EC2. 08W and 08X are independent. On success, return **08W_return_to_chat.zip**. On error, return **08W_failure_diagnostics.zip**.

Does a 500-cell detection floor before scaling reduce fragmentation while preserving local Foxp3-companion evidence? Compare selected500_zscore with both original selected_zscore and selected500_centered; selected_centered is the fourth corner.

Do state genes obscure CD4/CD8? Compare broad static vs technical mask, technical vs additional acute-stress mask, then both masks vs neither on a pair of graphs blind to coreceptors and CD4 helper probes. Counts and full-depth normalization remain unchanged. The original cell order, effective weights, and GPU fingerprints are checked. There are four reusable 08V controls and five new GPU fits. The checkpointed 110-minute fitting budget excludes preflight, preparation and reports. Software changes can require a control refit.

### Where to start

- paired_delta_summary.csv and paired_deltas_by_sample.csv: start with anchorblind_state_test, exclusive_CD4, exclusive_CD8, and their equal-weight mean. These are percentage-point changes in depth/sample-adjusted nonself expression-neighbor detection. Unsupported sample/depth strata are missing, not zero.
- actual_holdout_audit.csv: effective fitting weights and measured assay availability. Cd4, Cd8a, Cd8b1, Zbtb7b and Cd40lg cannot directly inform either blind graph. The four Treg companion genes were withheld in every fit.
- programs_population_delta_by_sample.csv: state programs in the ORIGINAL T cell 1 vs T cell 2, compared within sample and depth. Use this to check the premise as well as the response to masking.
- cluster_metrics.csv and the original-count dotplots, UMAPs and state tables: corroborating evidence, not cell-type accuracy.

The prespecified acute-response panel is Fos, Fosb, Jun, Junb, Jund, Egr1, Atf3, Dusp1, Ier2, Ier3, Hspa1a, Hspa1b, Hspb1 and Dnajb1. The other masks cover mitochondrial-genome symbols and structural mouse Rpl/Rps; they do not cover all translation or metabolic biology. 08V's broad panel had 13, 0 and 13 mitochondrial, canonical ribosomal, and acute-response genes, respectively. The 1,697-gene selected panel had 0, 0 and 4. Removing an absent gene cannot improve a fit.

No program score is regressed out of every gene. Exhaustion, cycling, interferon, cytotoxicity and Treg signals remain available as biological readouts. A null result does not rule out a correlated wider state. Neither a guide-positive cluster nor a majority of marker-negative cells establishes protein-defined cell identity.
