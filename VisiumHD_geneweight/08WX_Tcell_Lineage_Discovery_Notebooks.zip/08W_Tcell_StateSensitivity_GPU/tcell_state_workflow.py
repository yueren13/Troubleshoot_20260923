"""08W: read-only reuse of completed 08V inputs and matched GPU comparisons.

No feature is regressed out of the expression assay. Exact-zero PCA weights
exclude features from the pre-Harmony geometry without changing library sizes.
"""
from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
import datetime
import gc
import json
import math
import os
import subprocess
import sys
import time
import traceback
import numpy as np
import pandas as pd

import tcell_weighted_gpu as engine
import tcell_weighted_workflow as base
import tcell_adaptive_workflow as prep_v
from tcell_state_gene_sets import gene_module

VERSION = "08W-1.0.0"
REFERENCES = ("selected_zscore", "selected_centered", "selected500_centered", "broad_ratio")
BLIND = ("Cd4", "Cd8a", "Cd8b1", "Zbtb7b", "Cd40lg")
NEW = ("selected500_zscore", "broad_no_technical", "broad_no_technical_stress",
       "broad_ratio_anchorblind", "broad_no_technical_stress_anchorblind")
BROAD_MASKS = {
    "broad_no_technical": (True, False, False),
    "broad_no_technical_stress": (True, True, False),
    "broad_ratio_anchorblind": (False, False, True),
    "broad_no_technical_stress_anchorblind": (True, True, True),
}
LABELS = {
    "selected_zscore": "08V selected panel, unit variance",
    "selected_centered": "08V selected panel, centered",
    "selected500_centered": "08V selected panel with detection floor, centered",
    "broad_ratio": "08V static ratio weights",
    "selected500_zscore": "Detection-filtered selected panel, unit variance",
    "broad_no_technical": "Static ratio; mitochondrial and cytosolic ribosomal weights zero",
    "broad_no_technical_stress": "Static ratio; technical + acute stress weights zero",
    "broad_ratio_anchorblind": "Static ratio; lineage validation anchors masked",
    "broad_no_technical_stress_anchorblind": "Static ratio; anchors + technical + acute stress masked",
}
# Published 08V return archive. Prefer this verified lineage when several older
# experiments coexist; never select an unrelated 'latest' or a different cohort.
KNOWN_RUN = ("de6ba21e9e5acf0656c8", "4fb5d551e1fe0447")


def _read(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def _utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _source_ok(root):
    try:
        root = Path(root)
        p = _read(root / "plan.json")
        done = _read(root / "comparison_complete.json")
        return (str(p["version"]).startswith("08V-preparation-") and not done.get("failures")
                and all(k in done["branches"] and k in p["branches"] for k in REFERENCES)
                and (root / "gpu_settings.json").is_file())
    except (KeyError, ValueError, OSError):
        return False


def discover(project_dir=None, source_08v_run=None):
    """Locate the reviewed 08V run; an explicit completed run/receipt is authoritative."""
    user_path = Path(source_08v_run or project_dir or Path.cwd()).expanduser().resolve()
    if source_08v_run is not None or _source_ok(user_path) or user_path.name == "comparison_complete.json":
        root = user_path.parent if user_path.is_file() else user_path
        if not _source_ok(root):
            raise FileNotFoundError(f"Expected a completed original 08V GPU run directory with plan.json, gpu_settings.json and comparison_complete.json: {root}. Use the EC2 runs/<run id> directory, not the small return ZIP.")
        return root
    # Permit launching from beside 08V's already rendered review by following
    # its plan/receipt only if the actual cache on EC2 is still accessible.
    if (user_path / "runs").is_dir() and (user_path / "preparation_spec.json").is_file():
        candidates = list((user_path / "runs").glob("*/comparison_complete.json"))
    elif user_path.name == "21_tcell_feature_qc_dynamic_weights" and user_path.is_dir():
        candidates = list(user_path.glob("*/runs/*/comparison_complete.json"))
    else:
        inputs = prep_v._resolve_inputs(project_dir, ())
        v_root = Path(inputs["pointer_path"]).parent.parent / "21_tcell_feature_qc_dynamic_weights"
        candidates = list(v_root.glob("*/runs/*/comparison_complete.json"))
    valid = sorted({p.parent.resolve() for p in candidates if _source_ok(p.parent)})
    known = [p for p in valid if (p.parent.parent.name, p.name) == KNOWN_RUN]
    if len(known) == 1:
        return known[0]
    if len(valid) != 1:
        opts = "\n".join(str(p) for p in valid) or "(none found)"
        raise ValueError("Could not unambiguously identify the completed 08V run. Set SOURCE_08V_RUN to the original GPU run folder containing comparison_complete.json. Candidate directories:\n" + opts)
    return valid[0]


def _load_cache(directory, expected_cells, expected_order):
    cache = Path(directory)
    manifest = base._complete_cache(cache)
    if not manifest:
        raise ValueError(f"Missing/incomplete immutable 08V cache: {cache}. The review ZIP is insufficient; keep the original EC2 caches.")
    if manifest["n_cells"] != expected_cells or manifest.get("cell_order_hash") != expected_order:
        raise ValueError(f"08V cohort/order mismatch for {cache}")
    features = pd.read_csv(cache / "features.csv", dtype={"gene": str})
    if features.gene.isna().any() or features.gene.duplicated().any():
        raise ValueError(f"Missing/duplicate feature names: {cache}")
    if base.ordered_id_hash(features.gene) != manifest["engine_gene_ids_sha256"] or engine._weight_hash(features.weight.to_numpy(np.float32)) != manifest["engine_feature_weights_sha256"]:
        raise ValueError(f"Feature order or weights differ from the immutable 08V cache: {cache}")
    if set(features.gene) & set(prep_v.HELDOUT_GENES):
        raise ValueError(f"Original companion genes unexpectedly present in {cache}")
    return features, manifest


def prepare(project_dir=None, *, source_08v_run=None, output_root=None):
    before = time.monotonic()
    root = discover(project_dir, source_08v_run)
    v = _read(root / "plan.json")
    done = _read(root / "comparison_complete.json")
    cfg = v["settings"]
    if (set(v["heldout_genes"]) != set(prep_v.HELDOUT_GENES)
            or any(float(cfg[k]) != val for k, val in (("midpoint", .6), ("power", 2), ("target_sum", 10000), ("broad_min_detected_cells", 500)))):
        raise ValueError("The source is not the intended 0.60/2 ratio, 10,000-target, 500-cell-floor 08V comparison with the original five holdouts.")
    base._unchanged(v["inputs"])
    reference_caches = {k: Path(v["branches"][k]["cache_dir"]).resolve() for k in REFERENCES}
    tables, receipts = {}, {}
    for k, cache in reference_caches.items():
        tables[k], receipts[k] = _load_cache(cache, v["n_cells"], v["cell_order_hash"])
        if v["branches"][k].get("cohort") != "all" or receipts[k].get("all_08O_cells_retained") is not True:
            raise ValueError(f"Expected all original T cells for {k}.")
    marker_cache = Path(v["marker_cache_dir"])
    if not base._complete_cache(marker_cache):
        raise ValueError(f"The original marker cache for 08V is missing or incomplete: {marker_cache}")
    if not set(REFERENCES).issubset(done["branches"]):
        raise ValueError("The original 08V run did not complete all four controls.")
    scaled, centered, floor, broad = [tables[k] for k in REFERENCES]
    if (not np.array_equal(scaled.gene, centered.gene) or
        not np.array_equal(floor.gene, scaled.loc[scaled.detected_cells >= 500, "gene"]) or
        not (centered.weight == 1).all() or not (floor.weight == 1).all() or
        not (broad.detected_cells >= 500).all() or not (broad.weight > 0).all()):
        raise ValueError("The ordered 08V gene panels / detection floor do not match the specified scaling comparison.")
    if not np.allclose(base.soft_weights(broad.ratio.to_numpy(float), .6, 2), broad.weight.to_numpy(float), rtol=1e-6, atol=1e-8):
        raise ValueError("The candidate broad_ratio cache does not contain the 0.60 midpoint static ratio weights.")
    if not {"Cd4","Cd8a"}.issubset(set(broad.gene)):
        raise ValueError("The expected Cd4/Cd8a fit guides are absent from the original broad arm; check the 08V run.")
    gpu_settings = engine.validate_settings(_read(root / "gpu_settings.json"))
    # Keep class coverage for rare selected genes too; broad rows stay in source order.
    set_broad = set(broad.gene)
    order = list(broad.gene) + [g for g in scaled.gene if g not in set_broad]
    klass = np.array([gene_module(g) or "other" for g in order])
    if not set(klass).issubset({"mt_encoded","cytosolic_ribosomal","acute_stress","other"}):
        raise ValueError("Unrecognized gene-module classification; check the shipped definitions.")
    audit = pd.DataFrame({"gene":order, "class":klass, "in_broad_pool":[g in set_broad for g in order],
                          "technical":np.isin(klass, ["mt_encoded","cytosolic_ribosomal"]),
                          "acute_stress":klass=="acute_stress", "anchor":[g in BLIND for g in order]})
    weights = {}
    for k in REFERENCES:
        weights[k] = tables[k].weight.to_numpy(np.float32)
        audit[k] = audit.gene.isin(tables[k].loc[weights[k] > 0, "gene"])
    weights["selected500_zscore"] = scaled.set_index("gene").loc[floor.gene, "weight"].to_numpy(np.float32)
    audit["selected500_zscore"] = audit.gene.isin(floor.gene[weights["selected500_zscore"] > 0])
    for k, (use_tech, use_stress, use_anchors) in BROAD_MASKS.items():
        excluded = ((audit.technical & use_tech) | (audit.acute_stress & use_stress) | (audit.anchor & use_anchors))
        applied = broad.weight.to_numpy(dtype=np.float32, copy=True)
        applied[excluded.iloc[:len(broad)].to_numpy(dtype=bool)] = 0
        weights[k] = applied
        audit[k] = audit.gene.isin(broad.gene[applied > 0])
    spec = {"version":VERSION, "source_run":str(root), "source_plan_id":v["plan_id"],
            "source_cache_ids":{k: r["cache_id"] for k,r in receipts.items()}, "gpu_settings":gpu_settings,
            "module_classes":base.ordered_id_hash(audit.gene+":"+audit["class"]), "blind_genes":list(BLIND),
            "weights": {k:engine._weight_hash(w) for k,w in weights.items()}, "cell_order_hash":v["cell_order_hash"]}
    ident = base._digest(spec)
    default_dest = Path(v["inputs"]["pointer_path"]).parent.parent / "22_tcell_state_sensitivity"
    pdir = (Path(output_root).expanduser().resolve() if output_root is not None else default_dest) / ident[:20]
    pdir.mkdir(parents=True, exist_ok=True)
    base.save_json(pdir / "preparation_spec.json", spec)
    branches = OrderedDict((k, {"cache_dir":str(cache), "label":LABELS[k], "cohort":"all",
                                "kind":"reference", "source_embedding":str(Path(done["branches"][k]).resolve())}) for k,cache in reference_caches.items())
    for k in NEW:
        s = "selected500_centered" if k == "selected500_zscore" else "broad_ratio"
        tab = tables[s].copy()
        tab["weight"] = weights[k]
        if np.count_nonzero(weights[k]) < 4:
            raise ValueError(f"Too few positive-weight genes for {k}.")
        if np.array_equal(weights[k], weights[s]):
            cache = reference_caches[s]
        else:
            cache, _ = prep_v.create_branch_cache(reference_caches[s], pdir / "caches" / k, tab,
                        metadata={"version":VERSION,"variant":k,"source_08V_plan":v["plan_id"],"plan_id":ident,
                                  "normalization_denominator":"unchanged original full library"}, resume=True)
        branches[k] = {"cache_dir":str(cache),"cohort":"all","kind":"fixed","label":LABELS[k],
                       "reference":s,"anchorblind":bool(k.endswith("_anchorblind"))}
        print(f"08W {k}: {np.count_nonzero(weights[k]):,} active / {len(weights[k]):,} cache genes",flush=True)
    audit_path = pdir/"feature_audit.csv"
    audit.to_csv(audit_path,index=False)
    summary = []
    for k in branches:
        for c in ("cytosolic_ribosomal","mt_encoded","acute_stress","other"):
            summary.append({"method":k,"class":c,"n_active_genes":int(np.sum(audit[k] & (audit["class"] == c)))})
    pd.DataFrame(summary).to_csv(pdir/"feature_class_counts.csv",index=False)
    plan = {"version":VERSION,"plan_id":ident,"plan_dir":str(pdir),"audit_path":str(audit_path),
            "settings":dict(cfg),"source_08v_run":str(root),"source_08v_plan_id":v["plan_id"],
            "inputs":v["inputs"],"marker_cache_dir":v["marker_cache_dir"],"base_cache_dir":v["base_cache_dir"],
            "branches":branches,"heldout_genes":list(prep_v.HELDOUT_GENES),"blind_genes":list(BLIND),
            "n_cells":v["n_cells"],"cell_order_hash":v["cell_order_hash"],"gpu_settings":gpu_settings,
            "feature_class_counts_path":str(pdir/"feature_class_counts.csv"),"original_counts_modified":False,
            "no_extra_cell_QC":True, "normalization_denominator":"original full-library size",
            "preparation_seconds":round(time.monotonic()-before,3)}
    base.save_json(pdir/"plan.json",plan)
    print(f"Matched 08V run: {root}\n08W plan: {pdir}\nAll {v['n_cells']:,} cells retained.",flush=True)
    return plan


def preflight(helper_dir, log_dir):
    """Fixed 08V GPU engine only; no adaptive scorer or adaptive parity stage."""
    return base.preflight_gpu(helper_dir, log_dir=log_dir, timeout_seconds=600)


def launch(plan, helper_dir, gpu_runtime, *, max_minutes=110, resume=True):
    """Validate old results in place; new/incompatible variants use one GPU each."""
    count = gpu_runtime.get("visible_device_count")
    if gpu_runtime.get("ok") is not True or isinstance(count, bool) or not isinstance(count,int) or count < 1:
        raise ValueError("A successful GPU preflight is required; no CPU substitution.")
    if not math.isfinite(max_minutes) or max_minutes <= 0:
        raise ValueError("GPU time budget must be positive and finite.")
    cfg=engine.validate_settings(plan["gpu_settings"])
    run_id=base._digest({"plan":plan["plan_id"],"versions":engine._versions(),"engine":engine.ENGINE_VERSION,"settings":cfg})[:16]
    root=Path(plan["plan_dir"])/"runs"/run_id
    root.mkdir(parents=True,exist_ok=True)
    script=Path(helper_dir).resolve()/"tcell_weighted_gpu.py"
    if not script.is_file(): raise FileNotFoundError(script)
    cfg_path=root/"gpu_settings.json"
    base.save_json(cfg_path,cfg)
    base.save_json(root/"plan.json",plan)
    base.save_json(root/"gpu_runtime.json",gpu_runtime)
    jobs,finished,aliases,canonical,descs,origins={},{},{},{},{},{}
    pending=[]; active={}; free=list(range(min(4,count)))
    overall=time.monotonic()
    try:
        base._unchanged(plan["inputs"])
        for k, branch in plan["branches"].items():
            print(f"Checking {k} cache/receipts ...",flush=True)
            desc=engine.describe_branch(branch["cache_dir"],settings=cfg)
            if desc["n_cells"]!=plan["n_cells"] or desc["source"]["cell_ids_sha256"]!=plan["cell_order_hash"]:
                raise ValueError(f"Branch has a different cohort: {k}")
            descs[k]=desc; fp=desc["final_fingerprint"]
            if fp in canonical:
                aliases[k]=canonical[fp]
                continue
            canonical[fp]=k
            if branch.get("source_embedding") and Path(branch["source_embedding"]).name == "embedding.h5ad" and engine.is_compatible_result(Path(branch["source_embedding"]).parent, desc):
                finished[k]=Path(branch["source_embedding"]); origins[k]="verified_08V_reference"
                continue
            if resume and engine.is_compatible_result(root/k,desc):
                finished[k]=root/k/"embedding.h5ad";origins[k]="verified_08W_checkpoint";continue
            pending.append(k)
        print("08W reusing:",list(finished),"; exact duplicate masks:",aliases,"; GPU fits:",pending,flush=True)
        start=lastbeat=time.monotonic()
        base.save_json(root/"launch.json",{"started_utc":_utc(),"devices":free,"max_minutes":max_minutes,
                      "reused":dict(origins),"aliases":aliases,"queued":list(pending)})
        while pending or active:
            while free and pending:
                k=pending.pop(0);device=free.pop(0);out=root/k;out.mkdir(exist_ok=True)
                log=out/"console.log";writer=log.open("a",encoding="utf-8",buffering=1)
                writer.write(f"\n08W {k} starting {_utc()}\n"); writer.flush()
                command=[sys.executable,"-u",str(script),"--cache-dir",plan["branches"][k]["cache_dir"],
                         "--output-dir",str(out),"--branch","weighted","--gpu-device","0","--settings-json",str(cfg_path)]
                if not resume:command.append("--no-resume")
                try:
                    proc=subprocess.Popen(command,env=base._process_env(device),stdout=writer,stderr=subprocess.STDOUT,start_new_session=True)
                except BaseException:
                    writer.close();raise
                active[k]=(proc,writer,device,out);jobs[k]=time.monotonic()
                print(f"[{k}] Started on GPU {device}; {log}",flush=True)
            for k,(proc,writer,device,out) in list(active.items()):
                rc=proc.poll()
                if rc is None:continue
                writer.close(); del active[k];free.append(device)
                if rc!=0 or not engine.is_compatible_result(out,descs[k]):
                    with (out/"console.log").open("rb") as inp:
                        inp.seek(max(0,(out/"console.log").stat().st_size-3500)); tail=inp.read().decode(errors="replace")
                    raise RuntimeError(f"{k} failed or produced an invalid result (exit {rc}). Tail of {out/'console.log'}:\n{tail}")
                finished[k]=out/"embedding.h5ad";origins[k]="refit_08V_control" if k in REFERENCES else "new_08W_fit"
                print(f"[{k}] Complete in {(time.monotonic()-jobs[k])/60:.1f} min",flush=True)
            now=time.monotonic()
            if now-start>max_minutes*60 and (active or pending):raise TimeoutError(f"GPU time budget reached; resume compatible checkpoints at {root}")
            if active:
                if now-lastbeat>30:
                    print(f"08W {int((now-start)//60)} min: running {list(active)}; {len(finished)} completed; {len(pending)} queued.",flush=True)
                    lastbeat=now
                time.sleep(.45)
        for k,other in aliases.items():
            finished[k]=finished[other];origins[k]="exact_same_fingerprint_as_"+other
        ordered=OrderedDict((k,finished[k]) for k in plan["branches"])
        base.save_json(root/"comparison_complete.json",{"branches":ordered,"origins":origins,"failures":{},
            "fingerprints":{k:d["final_fingerprint"] for k,d in descs.items()},"gpu_elapsed_seconds":time.monotonic()-start,
            "elapsed_including_validation_seconds":time.monotonic()-overall})
        return ordered,root
    except BaseException as exc:
        exc.run_root=root
        base.save_json(root/"launch_error.json",{"type":type(exc).__name__,"message":str(exc),"completed":finished,"traceback":traceback.format_exc()})
        raise
    finally:
        for proc,writer,_,_ in active.values():
            base._stop_owned(proc);writer.close()
