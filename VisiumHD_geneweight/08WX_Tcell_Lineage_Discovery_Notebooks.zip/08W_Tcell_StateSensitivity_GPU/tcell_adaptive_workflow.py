"""08V: prepare matched feature, scaling, QC and adaptive-weight experiments.

Only original full-library-normalized assays are used.  No spatial-neighbor
features are rebuilt, no original labels are changed, and held-out companions
are absent from every prepared embedding matrix from the beginning.
"""
from __future__ import annotations

from collections import OrderedDict
import gc
import json
import math
import os
from pathlib import Path
import shutil
import time

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_workflow as base
import tcell_weighted_gpu as engine
import tcell_weighted_review as review
import tcell_banksy_sources as banksy


VERSION = "08V-preparation-1.0.1"
HELDOUT_GENES = ("Cd8b1", "Il2ra", "Ctla4", "Ikzf2", "Tnfrsf18")
PREPARATION_DEFAULTS = {
    "midpoint": 0.60,
    "power": 2.0,
    "target_sum": 10000.0,
    "selected_n_top_genes": 3000,
    "selected_min_detected_cells": 20,
    "broad_min_detected_cells": 500,
    "run_qc_branch": True,
    "qc_min_counts": 200,
    "qc_min_genes": 100,
    "qc_min_cells": 1000,
    "resume": True,
}


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _settings(settings):
    cfg = dict(PREPARATION_DEFAULTS)
    if settings:
        unknown = set(settings) - set(cfg)
        if unknown:
            raise ValueError("Unknown 08V preparation settings: " + ", ".join(sorted(unknown)))
        cfg.update(settings)
    for key in ("selected_n_top_genes", "selected_min_detected_cells", "broad_min_detected_cells",
                "qc_min_counts", "qc_min_genes", "qc_min_cells"):
        value = cfg[key]
        if isinstance(value, bool) or int(value) != value or int(value) < 1:
            raise ValueError(f"{key} must be a positive integer.")
        cfg[key] = int(value)
    for key in ("midpoint", "power", "target_sum"):
        value = float(cfg[key])
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"{key} must be finite and positive.")
        cfg[key] = value
    for key in ("run_qc_branch", "resume"):
        if not isinstance(cfg[key], (bool, np.bool_)):
            raise ValueError(f"{key} must be Boolean.")
        cfg[key] = bool(cfg[key])
    if cfg["broad_min_detected_cells"] < cfg["selected_min_detected_cells"]:
        raise ValueError("The broad detection floor cannot be below the base-cache detection floor.")
    return cfg


def _resolve_inputs(project_dir, explicit_caches):
    if project_dir is not None:
        try:
            return base.resolve_inputs(project_dir)
        except FileNotFoundError:
            if Path(project_dir).expanduser().resolve() != Path.cwd().resolve():
                raise
            # A Run All notebook commonly starts outside the CT26 code folder.
            # Only its cwd default may use the known same-project fallbacks.
    # Explicit cache paths are authoritative and already identify a source.
    for cache in explicit_caches:
        if cache is None:
            continue
        source = Path(cache).expanduser().resolve() / "source_inputs.json"
        if source.is_file():
            saved = _read(source)
            return base.resolve_inputs(saved["pointer_path"])
    candidates = [Path.cwd(),
                  Path("/host_root/nethome/reny28/Projects/Visium_projects/TBIO-8110/code/python"),
                  Path("/home/domino/reny28/Projects/Visium_projects/TBIO-8110/code/python")]
    for candidate in candidates:
        try:
            return base.resolve_inputs(candidate)
        except FileNotFoundError:
            continue
    raise FileNotFoundError("Set PROJECT_DIR to the same CT26 code folder used by 08T/08U, or its "
                            "completed 08O output folder. No H5AD selection is required.")


def _source_axes(inputs):
    """Read the original axes/QC metadata without loading its count matrix."""
    import h5py
    base._unchanged(inputs)
    with h5py.File(inputs["baseline_path"], "r") as handle:
        obs = base._read_elem(handle["obs"])
        var = base._read_elem(handle["var"])
        identity = base._read_elem(handle["uns/08m/analysis_id"]) if "uns/08m/analysis_id" in handle else None
        if "layers/counts" not in handle:
            raise ValueError("The completed 08O source lacks original layers['counts'].")
        shape = tuple(handle["layers/counts"].attrs["shape"])
    receipt = _read(inputs["receipt_path"])
    if identity is None or identity != receipt.get("analysis_id"):
        raise ValueError("The source H5AD and its 08O completion receipt disagree.")
    needed = ("sample", "condition", "population", "total_counts", "n_genes_by_counts")
    if any(key not in obs for key in needed) or obs[list(needed)].isna().any().any():
        raise ValueError("Original 08O sample, lineage and QC metadata must be present and nonmissing.")
    if obs.index.has_duplicates or var.index.has_duplicates:
        raise ValueError("Source cell IDs and gene symbols must be unique.")
    if shape != (len(obs), len(var)) or len(obs) != int(inputs["index"]["analyzed_cells"]):
        raise ValueError("Original 08O pointer and assay axes disagree.")
    if int(inputs["index"].get("selected_cells", len(obs))) != len(obs):
        raise ValueError("08V expects the complete selected 08O T-cell cohort.")
    if not obs["population"].astype(str).isin(base.POPULATIONS).all():
        raise ValueError("The source is not the frozen T cell 1 plus T cell 2 cohort.")
    slim = pd.DataFrame(index=pd.Index(obs.index.astype(str), name="cell_id"))
    for out, original in (("sample_id", "sample"), ("condition", "condition"),
                          ("population", "population"), ("total_counts", "total_counts"),
                          ("n_genes", "n_genes_by_counts")):
        slim[out] = obs[original].to_numpy()
    for col in ("total_counts", "n_genes"):
        values = pd.to_numeric(slim[col], errors="raise").to_numpy(dtype=float)
        if not np.isfinite(values).all() or (values < 1).any() or not np.equal(values, np.rint(values)).all():
            raise ValueError(f"Original {col} must be finite positive integer-valued QC metadata.")
    return slim, var.index.astype(str).to_numpy()


def _read_obs(cache):
    frame = pd.read_csv(Path(cache) / "obs.csv.gz", keep_default_na=False,
                        dtype={k: str for k in ("cell_id", "sample_id", "condition", "population",
                                               "source_cell_id", "unit")}).set_index("cell_id")
    if not frame.index.is_unique or frame.index.to_series().eq("").any():
        raise ValueError("Prepared cache cell IDs must be unique and nonempty.")
    return frame


def _cache_matches_source(cache, inputs, source_obs, source_genes, *, weighted=False, cfg=None):
    cache = Path(cache).expanduser().resolve()
    manifest = base._complete_cache(cache)
    if manifest is None:
        raise ValueError("No complete unchanged cache manifest.")
    if manifest.get("cell_order_hash") != base.ordered_id_hash(source_obs.index):
        raise ValueError("Source and cache cell-order identities differ.")
    saved = _read(cache / "source_inputs.json")
    for key in ("baseline_path", "ratio_path", "receipt_path"):
        if Path(saved[key]).resolve() != Path(inputs[key]).resolve():
            raise ValueError(f"Cache comes from a different {key}.")
    saved_signatures = {item["path"]: item for item in saved.get("source_signatures", [])}
    current_signatures = {item["path"]: item for item in inputs["source_signatures"]}
    for key in ("baseline_path", "ratio_path", "receipt_path"):
        path = str(Path(inputs[key]).resolve())
        if saved_signatures.get(path) != current_signatures.get(path) or path not in saved_signatures:
            raise ValueError(f"Cache source signature differs for {key}.")
    obs = _read_obs(cache)
    if not obs.index.equals(source_obs.index):
        raise ValueError("Cache row order differs from original 08O rows.")
    for key in ("sample_id", "condition", "population"):
        if not np.array_equal(obs[key].astype(str), source_obs[key].astype(str)):
            raise ValueError(f"Cache metadata differs from the source: {key}.")
    for key in ("total_counts", "n_genes"):
        if not np.array_equal(pd.to_numeric(obs[key]), pd.to_numeric(source_obs[key])):
            raise ValueError(f"Cache QC metadata differs from the source: {key}.")
    features = pd.read_csv(cache / "features.csv", dtype={"gene": str})
    if features.gene.isna().any() or features.gene.duplicated().any() or features.gene.eq("").any():
        raise ValueError("Invalid cache gene names.")
    positions = pd.Index(source_genes).get_indexer(features.gene)
    if (positions < 0).any() or np.any(np.diff(positions) <= 0):
        raise ValueError("Cache features are not in original source-gene order.")
    if manifest.get("gene_order_hash") != base.ordered_id_hash(features.gene):
        raise ValueError("Cache gene-order identity differs from its feature table.")
    with np.load(cache / "lognorm_features.npz", allow_pickle=False) as matrix:
        if tuple(matrix["shape"]) != (len(obs), len(features)):
            raise ValueError("Cache expression axes disagree with its metadata.")
    if weighted:
        if not {"ratio", "detected_cells", "variance_log1p"}.issubset(features):
            raise ValueError("A broad weighted cache needs ratios, detection counts and log variances.")
        spec = _read(cache / "preparation_settings.json")
        if int(spec["min_detected_cells"]) != cfg["selected_min_detected_cells"]:
            raise ValueError("The broad cache has a different original detection floor.")
        if not np.isclose(float(spec["target_sum"]), cfg["target_sum"], rtol=0, atol=0):
            raise ValueError("The broad cache uses a different normalization target.")
        audit = pd.read_csv(cache / "feature_audit_all_genes.csv", dtype={"gene": str})
        if "eligible_08S" not in audit:
            raise ValueError("The cache does not document broad 08S feature eligibility.")
        eligible = audit["eligible_08S"].astype(str).str.lower().eq("true")
        if not np.array_equal(audit.loc[eligible, "gene"].to_numpy(), features.gene.to_numpy()):
            raise ValueError("The cache is not the complete broad feature universe.")
    return manifest, obs, features


def _candidate_caches(root):
    root = Path(root)
    if not root.is_dir():
        return []
    return sorted({p.parent.resolve() for p in root.glob("*/cache/cache_manifest.json")}, key=str)


def _choose_cache(explicit, candidates, check, audit, label):
    if explicit is not None:
        path = Path(explicit).expanduser().resolve()
        result = check(path)
        audit.append({"cache_type": label, "path": str(path), "status": "explicit_verified"})
        return path, result
    valid = []
    for path in candidates:
        try:
            result = check(path)
            valid.append((path, result))
            audit.append({"cache_type": label, "path": str(path), "status": "verified"})
        except (OSError, KeyError, ValueError, TypeError) as exc:
            audit.append({"cache_type": label, "path": str(path), "status": "not_reused", "reason": str(exc)})
    # Matching source/axes are authoritative. Never select by newest mtime.
    return valid[0] if valid else (None, None)


def _link_immutable(source, destination):
    source, destination = Path(source).resolve(), Path(destination)
    if destination.exists():
        try:
            if os.path.samefile(source, destination):
                return
        except OSError:
            pass
        destination.unlink()
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def _sparse_log_moments(matrix):
    """Float64 mean/population variance, including implicit sparse zeros.

    Accumulate both moments ourselves: some SciPy versions perform float32
    column reduction before honoring a requested float64 output dtype.
    """
    n, p = matrix.shape
    if n < 2:
        raise ValueError("At least two rows are needed to estimate feature variance.")
    sums = np.zeros(p, dtype=np.float64)
    squares = np.zeros(p, dtype=np.float64)
    for start in range(0, matrix.nnz, 2_000_000):
        stop = min(start + 2_000_000, matrix.nnz)
        values = matrix.data[start:stop].astype(np.float64)
        columns = matrix.indices[start:stop]
        sums += np.bincount(columns, weights=values, minlength=p)
        squares += np.bincount(columns, weights=values * values, minlength=p)
    means = sums / n
    return means, np.maximum(squares / n - means ** 2, 0.0)


def _sparse_variance(matrix):
    """Population variance of log-normalized input, including implicit zeros."""
    return _sparse_log_moments(matrix)[1]


def _verify_cache_expression(matrix, features, obs, source_genes, inputs, target_sum):
    """Check deterministic original-count rows from every sample, without densifying.

    This is a sampled normalization/axis check, not a full source-file hash.
    Source signatures and complete-cache receipts are checked independently.
    """
    import h5py
    selected = []
    samples = obs.sample_id.astype(str).to_numpy()
    for sample in pd.unique(samples):
        ix = np.flatnonzero(samples == sample)
        for start in (0, max(0, len(ix) // 2 - 2), max(0, len(ix) - 4)):
            selected.extend(ix[start:start + 4].tolist())
    rows = np.unique(selected).astype(np.int64)
    columns = pd.Index(source_genes).get_indexer(features.gene)
    if (columns < 0).any():
        raise ValueError("Cache normalization check found a gene absent from the original source.")
    pieces = []
    with h5py.File(inputs["baseline_path"], "r") as handle:
        node = handle["layers/counts"]
        encoding = node.attrs.get("encoding-type", "")
        if isinstance(encoding, bytes):
            encoding = encoding.decode()
        if encoding == "csr_matrix":
            breaks = np.flatnonzero(np.diff(rows) != 1) + 1
            for run in np.split(rows, breaks):
                left, right = int(run[0]), int(run[-1]) + 1
                pointer = np.asarray(node["indptr"][left:right + 1], dtype=np.int64)
                lo, hi = int(pointer[0]), int(pointer[-1])
                piece = sp.csr_matrix((np.asarray(node["data"][lo:hi]), np.asarray(node["indices"][lo:hi]),
                                       pointer - lo), shape=(right - left, len(source_genes)))
                piece.sum_duplicates()
                piece.eliminate_zeros()
                pieces.append(piece[:, columns])
        elif encoding == "csc_matrix":
            # The legacy loader explicitly supports CSC. It is uncommon for
            # saved 08O data; use its validated loader instead of guessing axes.
            pieces = None
        else:
            raise ValueError("Original 08O counts must be CSR or CSC for cache validation.")
    if pieces is None:
        original, _, _ = base.load_original_counts(inputs)
        measured = original[rows][:, columns].tocsr()
        del original
    else:
        measured = sp.vstack(pieces, format="csr")
    expected = base.log_normalize(measured, obs.total_counts.to_numpy()[rows], target_sum)
    cached = matrix[rows].tocsr()
    if (cached.shape != expected.shape or not np.array_equal(cached.indptr, expected.indptr)
            or not np.array_equal(cached.indices, expected.indices)):
        raise ValueError("Prepared expression nonzero positions disagree with original source counts in sampled rows.")
    difference = (cached - expected).tocsr()
    max_error = float(np.max(np.abs(difference.data))) if difference.nnz else 0.0
    if max_error > 2e-4:
        raise ValueError(f"Prepared expression differs from original full-library log1p normalization: {max_error:.6g}.")
    return {"check": "deterministic original-count rows from every sample",
            "n_checked_rows": int(len(rows)), "n_samples": int(len(pd.unique(samples))),
            "row_ids_sha256": base.ordered_id_hash(obs.index[rows]),
            "all_feature_columns_checked": int(matrix.shape[1]), "max_absolute_error": max_error,
            "normalization_target_sum": float(target_sum), "full_source_library_denominator": True}


def create_branch_cache(base_cache, outdir, genesweights, rows=None, *, metadata=None,
                        resume=True, matrix=None):
    """Create an immutable engine-compatible cache with explicit ordered axes.

    ``genesweights`` is a DataFrame with ordered ``gene`` and ``weight`` columns.
    ``rows`` selects original base rows, retaining their original order.  When
    supplied, ``matrix`` is the *full base-cache CSR* and avoids repeated disk
    reads during preparation. This function never modifies it in place.

    Return value is ``(cache_path, manifest)``. A different identity must use a
    different output path, including a later learned adaptive-weight vector.
    """
    cache, output = Path(base_cache).expanduser().resolve(), Path(outdir).expanduser().resolve()
    if cache == output or cache.is_relative_to(output) or output.is_relative_to(cache):
        raise ValueError("A branch cache must be separate from its ancestor input cache.")
    parent = base._complete_cache(cache)
    if parent is None:
        raise ValueError(f"The input cache is incomplete: {cache}")
    obs = _read_obs(cache)
    source_features = pd.read_csv(cache / "features.csv", dtype={"gene": str})
    if not isinstance(genesweights, pd.DataFrame) or not {"gene", "weight"}.issubset(genesweights):
        raise TypeError("genesweights must be a DataFrame with gene and weight columns.")
    requested = genesweights.copy().reset_index(drop=True)
    if requested.gene.isna().any() or requested.gene.duplicated().any():
        raise ValueError("Branch genes must be unique and nonmissing.")
    requested["gene"] = requested.gene.astype(str)
    if requested.gene.eq("").any():
        raise ValueError("Branch genes must be nonempty.")
    positions = pd.Index(source_features.gene).get_indexer(requested.gene)
    if (positions < 0).any() or np.any(np.diff(positions) <= 0):
        raise ValueError("Branch genes must be an ordered subset of the base-cache genes.")
    weights = pd.to_numeric(requested.weight, errors="raise").to_numpy(dtype=np.float32)
    if not np.isfinite(weights).all() or (weights < 0).any() or np.count_nonzero(weights) < 4:
        raise ValueError("At least four finite positive-weight genes are required.")
    if np.any(requested.gene.isin(HELDOUT_GENES).to_numpy() & (weights > 0)):
        raise ValueError("08V held-out companion genes cannot have positive embedding weights.")
    if rows is None:
        row_indices = np.arange(len(obs), dtype=np.int64)
    else:
        array = np.asarray(rows)
        if array.dtype == bool:
            if array.shape != (len(obs),):
                raise ValueError("A Boolean row mask must have one value per base cell.")
            row_indices = np.flatnonzero(array)
        else:
            if array.ndim != 1 or not np.issubdtype(array.dtype, np.integer):
                raise ValueError("rows must be a Boolean mask or an integer row-index vector.")
            row_indices = array.astype(np.int64)
        if len(row_indices) < 4 or (row_indices < 0).any() or (row_indices >= len(obs)).any() or np.any(np.diff(row_indices) <= 0):
            raise ValueError("Branch rows must be at least four valid rows in unchanged source order.")
    same_rows = np.array_equal(row_indices, np.arange(len(obs)))
    same_genes = np.array_equal(positions, np.arange(len(source_features)))
    selected_obs = obs.iloc[row_indices].copy()
    features = source_features.iloc[positions].reset_index(drop=True).copy()
    for key in requested.columns:
        features[key] = requested[key].to_numpy()
    features["weight"] = weights
    features["applied_distance_weight"] = weights
    features["applied_column_multiplier"] = np.sqrt(weights)
    features["feature_in_embedding"] = weights > 0
    row_hash = base.ordered_id_hash(selected_obs.index)
    gene_hash = base.ordered_id_hash(features.gene)
    info = dict(metadata or {})
    data_identity = parent.get("data_identity", parent["cache_id"]) if same_rows and same_genes else base._digest({
        "version": VERSION, "parent_data_identity": parent.get("data_identity", parent["cache_id"]),
        "cell_ids": row_hash, "genes": gene_hash})
    identity = base._digest({"version": VERSION, "data_identity": data_identity,
                             "weights_sha256": engine._weight_hash(weights), "metadata": info})
    existing = base._complete_cache(output)
    if existing and existing.get("cache_id") == identity and resume:
        return output, existing
    if (output / "cache_manifest.json").is_file():
        raise ValueError(f"The branch path already contains a different or non-reusable cache: {output}")
    output.mkdir(parents=True, exist_ok=True)
    selected_matrix = None
    if same_rows and same_genes:
        _link_immutable(cache / "lognorm_features.npz", output / "lognorm_features.npz")
    else:
        original = matrix if matrix is not None else sp.load_npz(cache / "lognorm_features.npz").tocsr()
        if not sp.isspmatrix_csr(original) or original.shape != (len(obs), len(source_features)):
            raise ValueError("matrix must be the full row/column-aligned base CSR.")
        selected_matrix = original if same_rows else original[row_indices]
        selected_matrix = selected_matrix[:, positions].tocsr()
        selected_matrix.sum_duplicates()
        selected_matrix.eliminate_zeros()
        selected_matrix.sort_indices()
        base._save_npz(output / "lognorm_features.npz", selected_matrix)
        if matrix is None:
            del original
    if selected_matrix is not None:
        features["variance_log1p"] = _sparse_variance(selected_matrix)
        # Nonzero log-expression positions equal nonzero original counts.
        features["detected_cells_in_cohort"] = np.bincount(selected_matrix.indices, minlength=len(features))
    if "variance_log1p" in features:
        features["weighted_variance"] = weights * pd.to_numeric(features.variance_log1p).to_numpy()
    if same_rows:
        for filename in ("marker_counts.npz", "marker_log1p.npz", "marker_genes.csv"):
            _link_immutable(cache / filename, output / filename)
    else:
        for filename in ("marker_counts.npz", "marker_log1p.npz"):
            marker_matrix = sp.load_npz(cache / filename).tocsr()
            base._save_npz(output / filename, marker_matrix[row_indices].tocsr())
            del marker_matrix
        _link_immutable(cache / "marker_genes.csv", output / "marker_genes.csv")
    # A pure positive-weight update leaves every per-cell information field
    # unchanged. Avoid rereading a multi-GB CSR or recompressing observation
    # metadata on each adaptive iteration solely to reproduce these fields.
    reuse_information = bool(same_rows and same_genes and np.all(weights > 0)
        and np.all(pd.to_numeric(source_features.weight).to_numpy(dtype=float) > 0)
        and {"n_observed_embedding_genes", "no_observed_embedding_feature", "qc_gene_universe"}.issubset(selected_obs)
        and "nnz" in parent and "csr_bytes" in parent)
    if reuse_information:
        panel = None
        panel_nnz, panel_bytes = int(parent["nnz"]), int(parent["csr_bytes"])
    else:
        # Retain full-source totals; information fields below refer to this panel.
        panel = selected_matrix if selected_matrix is not None else (
            matrix if matrix is not None else sp.load_npz(cache / "lognorm_features.npz").tocsr())
        panel_nnz = int(panel.nnz)
        panel_bytes = int(panel.data.nbytes + panel.indices.nbytes + panel.indptr.nbytes)
    # Legacy information fields describe the ancestor's panel. Preserve them
    # under an explicit source name instead of relabelling them as this panel.
    if not same_genes:
        for key in ("eligible_feature_counts", "no_observed_eligible_feature", "no_observed_heldout_feature"):
            if key in selected_obs:
                selected_obs["source_" + key] = selected_obs.pop(key)
    if not reuse_information:
        observed_per_row = (np.diff(panel.indptr) if np.all(weights > 0)
                            else np.asarray(panel[:, weights > 0].getnnz(axis=1)).ravel())
        selected_obs["no_observed_embedding_feature"] = observed_per_row == 0
        selected_obs["n_observed_embedding_genes"] = observed_per_row
    selected_obs["qc_gene_universe"] = "original 08O common-gene universe"
    if reuse_information:
        _link_immutable(cache / "obs.csv.gz", output / "obs.csv.gz")
    else:
        selected_obs.to_csv(output / "obs.csv.gz", index=True)
    features.to_csv(output / "features.csv", index=False)
    base.save_json(output / "branch_preparation.json", {"version": VERSION, "metadata": info,
                   "parent_cache": str(cache), "parent_cache_id": parent["cache_id"],
                   "heldout_genes_excluded_from_start": list(HELDOUT_GENES),
                   "qc_gene_definition": "n_genes is detected genes in original 08O common-gene universe",
                   "original_counts_modified": False})
    for filename in ("source_inputs.json", "preparation_settings.json"):
        if (cache / filename).is_file():
            _link_immutable(cache / filename, output / filename)
    files = ["lognorm_features.npz", "obs.csv.gz", "features.csv", "marker_counts.npz",
             "marker_log1p.npz", "marker_genes.csv", "branch_preparation.json"]
    files += [name for name in ("source_inputs.json", "preparation_settings.json") if (output / name).is_file()]
    result = {"version": VERSION, "cache_id": identity, "data_identity": data_identity,
              "parent_cache_dir": str(cache), "parent_cache_id": parent["cache_id"],
              "shape": [len(selected_obs), len(features)], "n_cells": len(selected_obs),
              "n_source_genes": parent.get("n_source_genes"), "n_features": len(features),
              "n_samples": int(selected_obs.sample_id.nunique()), "n_conditions": int(selected_obs.condition.nunique()),
              "cell_order_hash": row_hash, "gene_order_hash": gene_hash,
              "engine_cell_ids_sha256": row_hash, "engine_gene_ids_sha256": gene_hash,
              "engine_feature_weights_sha256": engine._weight_hash(weights),
              "all_08O_cells_retained": bool(parent.get("all_08O_cells_retained", True) and same_rows),
              "original_counts_modified": False, "heldout_genes": list(HELDOUT_GENES),
              "normalization_denominator": "unchanged original full-source library sizes",
              "qc_gene_definition": "detected genes in original 08O common-gene universe",
              "zero_feature_cells": int(selected_obs.no_observed_embedding_feature.sum()),
              "csr_bytes": panel_bytes,
              "nnz": panel_nnz, "metadata": info,
              "files": {name: (output / name).stat().st_size for name in files}}
    base.save_json(output / "cache_manifest.json", result)
    del panel, selected_matrix
    return output, result


def _qc_audit(obs, output, cfg):
    counts = pd.to_numeric(obs.total_counts).to_numpy(dtype=float)
    genes = pd.to_numeric(obs.n_genes).to_numpy(dtype=float)
    settings = OrderedDict([("qc_100_50", (100, 50)), ("qc_200_100", (200, 100))])
    chosen_key = f"qc_{cfg['qc_min_counts']}_{cfg['qc_min_genes']}"
    settings[chosen_key] = (cfg["qc_min_counts"], cfg["qc_min_genes"])
    masks = OrderedDict((name, (counts >= min_counts) & (genes >= min_genes))
                        for name, (min_counts, min_genes) in settings.items())
    audit = obs[["sample_id", "condition", "population", "total_counts", "n_genes"]].copy()
    audit["n_genes_definition"] = "detected original 08O common genes"
    for name, mask in masks.items():
        audit[name] = mask
    audit.to_csv(output / "cell_qc_flags.csv.gz", index=True)
    rows = []
    for name, mask in masks.items():
        for scope in ("all", "sample_id", "condition"):
            levels = [("all", np.arange(len(obs)))] if scope == "all" else [
                (level, np.flatnonzero(obs[scope].astype(str).to_numpy() == level))
                for level in pd.unique(obs[scope].astype(str))]
            for level, ix in levels:
                n_keep = int(mask[ix].sum())
                rows.append({"qc_mask": name, "scope": scope, "group": level,
                             "min_total_counts": settings[name][0], "min_common_genes": settings[name][1],
                             "n_cells": len(ix), "n_retained": n_keep, "n_excluded": len(ix) - n_keep,
                             "fraction_retained": n_keep / len(ix)})
    pd.DataFrame(rows).to_csv(output / "qc_retention.csv", index=False)
    chosen = masks[chosen_key]
    np.save(output / "qc_selected_rows.npy", np.flatnonzero(chosen), allow_pickle=False)
    status = "planned"
    if not cfg["run_qc_branch"]:
        status = "disabled_by_setting"
    elif chosen.all():
        status = "skipped_all_cells_pass_identical_cohort"
    elif int(chosen.sum()) < cfg["qc_min_cells"]:
        status = "skipped_insufficient_retained_cells"
    return {"selected_mask": chosen_key, "status": status, "n_retained": int(chosen.sum()),
            "n_excluded": int((~chosen).sum()), "minimum_cells_for_run": cfg["qc_min_cells"],
            "flags_path": str(output / "cell_qc_flags.csv.gz"),
            "retention_path": str(output / "qc_retention.csv"),
            "selected_rows_path": str(output / "qc_selected_rows.npy"),
            "gene_definition": "detected original 08O common genes", "mitochondrial_filter_changed": False}, chosen


def prepare_inputs(project_dir=None, output_root=None, settings=None,
                   source_08u_cache=None, source_weighted_cache=None):
    """Prepare the five matched all-cell variants and a separate QC sensitivity.

    Only ``project_dir`` is normally needed. Existing matching 08S/08T and 08U
    caches are discovered inside the resolved CT26 run, verified, and reused.
    If no matching selected-gene cache exists, feature selection is reproduced
    from the original 08O counts without building any spatial neighborhoods.
    """
    started = time.perf_counter()
    cfg = _settings(settings)
    inputs = _resolve_inputs(project_dir, (source_weighted_cache, source_08u_cache))
    source_obs, source_genes = _source_axes(inputs)
    run_root = Path(inputs["pointer_path"]).parent.parent
    destination = Path(output_root).expanduser().resolve() if output_root is not None else run_root / "21_tcell_feature_qc_dynamic_weights"
    audit = []
    weighted, weighted_info = _choose_cache(source_weighted_cache,
        _candidate_caches(run_root / "18_tcell_soft_weight_harmony"),
        lambda path: _cache_matches_source(path, inputs, source_obs, source_genes, weighted=True, cfg=cfg),
        audit, "broad_weighted")
    if weighted is None:
        prep_inputs = dict(inputs)
        prep_inputs["output_root"] = str(destination / "prepared_broad")
        weighted, _ = base.prepare_cache(prep_inputs, review.ALL_MARKERS,
            midpoint=cfg["midpoint"], power=cfg["power"],
            min_detected_cells=cfg["selected_min_detected_cells"],
            target_sum=cfg["target_sum"], resume=cfg["resume"])
        weighted_info = _cache_matches_source(weighted, inputs, source_obs, source_genes, weighted=True, cfg=cfg)
        audit.append({"cache_type": "broad_weighted", "path": str(weighted), "status": "prepared_from_original_08O"})
    broad_manifest, obs, broad_features = weighted_info
    print(f"08V original cohort: {len(obs):,} T cells; broad normalized cache: {weighted}", flush=True)

    def check_selected(path):
        result = _cache_matches_source(path, inputs, source_obs, source_genes)
        spec = _read(Path(path) / "preparation_settings.json")
        if int(spec["n_top_genes"]) != cfg["selected_n_top_genes"] or int(spec["min_detected_cells"]) != cfg["selected_min_detected_cells"]:
            raise ValueError("08U feature-selection parameters differ from this controlled comparison.")
        if float(spec["target_sum"]) != cfg["target_sum"] or tuple(spec["heldout_genes"]) != HELDOUT_GENES:
            raise ValueError("08U normalization or reserved heldout panel differs.")
        return result

    selected_cache, selected_info = _choose_cache(source_08u_cache,
        _candidate_caches(run_root / "20_tcell_banksy_harmony"), check_selected, audit, "08U_selected")
    if selected_cache is not None:
        _, _, selected_table = selected_info
        selected_genes = selected_table.loc[~selected_table.gene.isin(HELDOUT_GENES), "gene"].tolist()
        selected_origin = {"method": "verified_original_08U_panel", "cache_dir": str(selected_cache),
                           "cache_id": selected_info[0]["cache_id"]}
    else:
        counts, genes, checked_obs = base.load_original_counts(inputs)
        if not checked_obs.index.equals(obs.index):
            raise ValueError("Original count loading changed the frozen cell order.")
        chosen, selection_audit, selection_info = banksy.select_features(counts, genes,
            obs.total_counts.to_numpy(), n_top_genes=cfg["selected_n_top_genes"],
            heldout_genes=HELDOUT_GENES, min_detected_cells=cfg["selected_min_detected_cells"],
            target_sum=cfg["target_sum"])
        selected_genes = [str(g) for g in genes[chosen] if str(g) not in HELDOUT_GENES]
        selected_origin = {"method": "reproduced_08U_selection_from_original_08O", "details": selection_info}
        del counts
        gc.collect()
    positions = pd.Index(broad_features.gene).get_indexer(selected_genes)
    if (positions < 0).any() or np.any(np.diff(positions) <= 0):
        raise ValueError("The frozen 08U reference panel is not an ordered subset of the broad source cache.")
    heldout = broad_features.gene.isin(HELDOUT_GENES).to_numpy()
    detection = pd.to_numeric(broad_features.detected_cells, errors="raise").to_numpy(dtype=np.int64)
    broad_mask = (detection >= cfg["broad_min_detected_cells"]) & ~heldout
    selected_mask = broad_features.gene.isin(selected_genes).to_numpy()
    selected500_mask = selected_mask & broad_mask
    if min(int(selected_mask.sum()), int(selected500_mask.sum()), int(broad_mask.sum())) < 4:
        raise ValueError("Fewer than four genes remain in one of the required matched feature panels.")
    spec = {"version": VERSION, "source_signatures": inputs["source_signatures"],
            "source_cache_id": broad_manifest["cache_id"], "settings": cfg,
            "cell_order_hash": base.ordered_id_hash(obs.index),
            "selected_panel_hash": base.ordered_id_hash(selected_genes),
            "heldout_genes": list(HELDOUT_GENES)}
    plan_id = base._digest(spec)
    plan_dir = destination / plan_id[:20]
    plan_dir.mkdir(parents=True, exist_ok=True)
    base.save_json(plan_dir / "preparation_spec.json", spec)
    base.save_json(plan_dir / "source_inputs.json", inputs)
    base.save_json(plan_dir / "source_audit.json", {"cache_candidates": audit,
        "selected_panel_origin": selected_origin, "original_counts_modified": False,
        "source_qc_provenance_note": "08V does not infer original atlas thresholds from run names.",
        "qc_gene_definition": "n_genes is detected genes in the original 08O common-gene universe"})
    qc_dir = plan_dir / "qc"
    qc_dir.mkdir(exist_ok=True)
    qc, qc_mask = _qc_audit(obs, qc_dir, cfg)

    matrix = sp.load_npz(weighted / "lognorm_features.npz").tocsr()
    if matrix.shape != (len(obs), len(broad_features)):
        raise ValueError("Broad expression dimensions changed during preparation.")
    source_normalization_check = _verify_cache_expression(matrix, broad_features, obs, source_genes, inputs,
                                                         cfg["target_sum"])
    cache_detections = np.bincount(matrix.indices, minlength=matrix.shape[1])
    if not np.array_equal(cache_detections, detection):
        raise ValueError("Broad cache log-expression detection counts disagree with its feature audit.")
    means, variance = _sparse_log_moments(matrix)
    legacy_variance = broad_features.variance_log1p.to_numpy(dtype=float)
    variance_differences = np.abs(variance - legacy_variance)
    variance_check = {"policy": "use recomputed float64 moments; legacy cache estimates are audit-only",
        "n_genes": int(len(variance)),
        "n_legacy_estimates_outside_tolerance": int(np.count_nonzero(
            ~np.isclose(variance, legacy_variance, rtol=2e-5, atol=2e-9))),
        "max_absolute_difference": float(np.max(variance_differences)),
        "max_relative_difference": float(np.max(variance_differences / np.maximum(variance, 1e-14))),
        "ddof": 0}
    broad_features = broad_features.copy()
    broad_features["variance_log1p"] = variance
    broad_features["heldout_from_start"] = heldout
    broad_features["in_selected_reference"] = selected_mask
    broad_features["in_selected_500_intersection"] = selected500_mask
    broad_features["in_broad_500"] = broad_mask
    broad_features.to_csv(plan_dir / "frozen_feature_panels.csv", index=False)
    ratios = pd.to_numeric(broad_features.ratio, errors="raise").to_numpy(dtype=float)
    if not np.isfinite(ratios).all() or (ratios < 0).any():
        raise ValueError("The broad cache requires finite nonnegative environment-to-T ratios.")
    ratio_weights = base.soft_weights(ratios, cfg["midpoint"], cfg["power"])
    common_meta = {"heldout_genes_excluded_from_start": list(HELDOUT_GENES),
                   "normalization_target_sum": cfg["target_sum"], "plan_id": plan_id,
                   "feature_gene_order": "unchanged source order"}

    def frame(mask, weights):
        table = broad_features.loc[mask].reset_index(drop=True).copy()
        table["weight"] = np.asarray(weights, dtype=np.float32)[mask]
        return table

    selected_pool, _ = create_branch_cache(weighted, plan_dir / "shared" / "selected_reference",
        frame(selected_mask, np.ones(len(broad_features))), metadata={**common_meta, "panel": "frozen_08U_reference"},
        matrix=matrix, resume=cfg["resume"])
    selected500_pool, _ = create_branch_cache(weighted, plan_dir / "shared" / "selected_500_intersection",
        frame(selected500_mask, np.ones(len(broad_features))), metadata={**common_meta, "panel": "frozen_reference_intersection_detection_floor"},
        matrix=matrix, resume=cfg["resume"])
    broad_pool, _ = create_branch_cache(weighted, plan_dir / "shared" / "broad_500",
        frame(broad_mask, ratio_weights), metadata={**common_meta, "panel": "broad_detection_floor"},
        matrix=matrix, resume=cfg["resume"])
    del matrix
    gc.collect()
    selected_table = pd.read_csv(selected_pool / "features.csv", dtype={"gene": str})
    selected_var = selected_table.variance_log1p.to_numpy(dtype=float)
    # Match 08U's zero-variance tolerance relative to the second moment.
    selected_mean = means[selected_mask]
    variance_threshold = 1e-12 * np.maximum(selected_var + selected_mean ** 2, 1.0)
    inverse_variance = np.divide(1.0, selected_var, out=np.zeros_like(selected_var),
                                 where=selected_var > variance_threshold)
    scaled_table = selected_table.copy()
    scaled_table["weight"] = inverse_variance
    scaled_cache, _ = create_branch_cache(selected_pool, plan_dir / "caches" / "selected_zscore",
        scaled_table, metadata={**common_meta, "variant": "selected_zscore", "transform": "pooled per-gene log-expression population z-score via inverse-variance distance weights"},
        resume=cfg["resume"])
    branches = OrderedDict()
    branches["selected_zscore"] = {"cache_dir": str(scaled_cache), "label": "08U selected genes, unit variance", "kind": "fixed", "cohort": "all"}
    branches["selected_centered"] = {"cache_dir": str(selected_pool), "label": "Same selected genes, centering only", "kind": "fixed", "cohort": "all"}
    branches["selected500_centered"] = {"cache_dir": str(selected500_pool), "label": f"Selected genes detected in at least {cfg['broad_min_detected_cells']} cells, centering only", "kind": "fixed", "cohort": "all"}
    branches["broad_ratio"] = {"cache_dir": str(broad_pool), "label": "Broad genes, ratio weights", "kind": "fixed", "cohort": "all"}
    branches["broad_adaptive"] = {"cache_dir": str(broad_pool), "label": "Broad genes, adaptive weights", "kind": "adaptive", "cohort": "all",
                                   "initial_cache_dir": str(broad_pool), "weights_status": "initial_ratio_prior_only_requires_adaptive_training"}
    if qc["status"] == "planned":
        broad_table = pd.read_csv(broad_pool / "features.csv", dtype={"gene": str})
        qc_cache, _ = create_branch_cache(broad_pool, plan_dir / "caches" / "qc_ratio",
            broad_table, rows=np.flatnonzero(qc_mask), metadata={**common_meta, "variant": "qc_ratio",
            "qc_mask": qc["selected_mask"], "min_total_counts": cfg["qc_min_counts"], "min_common_genes": cfg["qc_min_genes"],
            "feature_panel_frozen_before_cell_QC": True}, resume=cfg["resume"])
        branches["qc_ratio"] = {"cache_dir": str(qc_cache), "label": f"Ratio weights, counts >= {cfg['qc_min_counts']} and common genes >= {cfg['qc_min_genes']}",
                                "kind": "fixed", "cohort": qc["selected_mask"]}
    groups = OrderedDict()
    for name, branch in branches.items():
        groups.setdefault(branch["cohort"], []).append(name)
    plan = {"version": VERSION, "plan_id": plan_id, "plan_dir": str(plan_dir),
            "output_root": str(destination), "base_cache_dir": str(weighted), "marker_cache_dir": str(weighted),
            "settings": cfg, "inputs": inputs, "n_cells": len(obs), "cell_order_hash": base.ordered_id_hash(obs.index),
            "heldout_genes": list(HELDOUT_GENES), "branches": branches, "variants": branches,
            "review_groups": groups, "qc": qc, "selected_panel_origin": selected_origin,
            "feature_panels_path": str(plan_dir / "frozen_feature_panels.csv"),
            "source_audit_path": str(plan_dir / "source_audit.json"),
            "preparation_seconds": time.perf_counter() - started,
            "original_counts_modified": False, "new_spatial_neighbors_computed": False,
            "qc_gene_definition": "detected genes in original 08O common-gene universe",
            "comparison_note": "Every main variant excludes held-out companions from its first embedding; 08U panel comparisons use the original reference panel with those companions removed."}
    base._unchanged(inputs)
    source_audit = _read(plan_dir / "source_audit.json")
    source_audit["sampled_source_normalization_check"] = source_normalization_check
    source_audit["all_feature_detection_counts_checked"] = True
    source_audit["all_log_expression_variances_recomputed_ddof"] = 0
    source_audit["legacy_variance_comparison"] = variance_check
    base.save_json(plan_dir / "source_audit.json", source_audit)
    base.save_json(plan_dir / "plan.json", plan)
    print(f"08V prepared {len(branches)} variants; {len(obs):,} original cells in every main comparison.", flush=True)
    print(f"QC {qc['selected_mask']}: {qc['n_retained']:,} retained, {qc['n_excluded']:,} excluded; {qc['status']}.", flush=True)
    print(f"Original marker assays and atlas labels are unchanged. Plan: {plan_dir / 'plan.json'}", flush=True)
    return plan
