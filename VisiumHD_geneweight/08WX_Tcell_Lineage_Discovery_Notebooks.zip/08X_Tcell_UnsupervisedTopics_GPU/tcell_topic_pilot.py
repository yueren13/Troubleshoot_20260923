"""08X: AmortizedLDA RNA discovery on unweighted molecule counts; held-animal readouts."""
from __future__ import annotations
from pathlib import Path
import hashlib, json, os, time, zipfile, shutil, inspect, gc
import numpy as np, pandas as pd, scipy.sparse as sp
import tcell_weighted_workflow as core
from tcell_state_workflow import discover

RELEASE="08X-1.0.0"
HELD=("Cd4","Cd8a","Cd8b1","Zbtb7b","Cd40lg","Foxp3","Il2ra","Ctla4","Ikzf2","Tnfrsf18")
STATE=("Fos","Junb","Hspa1a","Pdcd1","Tox","Lag3","Ifit1","Isg15","Nkg7","Prf1","Mki67","Lyz2","Spp1","Col1a1")
def readj(p):return json.loads(Path(p).read_text())
def split_samples(obs,seed):
    design=obs[["sample_id","condition"]].astype(str).drop_duplicates()
    if design.sample_id.duplicated().any():raise ValueError("A sample has multiple conditions; the evaluation split is ambiguous.")
    split={}
    for condition,df in design.groupby("condition",sort=True):
        ids=sorted(df.sample_id,key=lambda s:hashlib.sha256((str(seed)+"|"+condition+"|"+s).encode()).digest())
        if len(ids)<2:raise ValueError(f"Need ≥2 samples in {condition} to reserve a whole sample for validation.")
        for i,s in enumerate(ids):split[s]="evaluation" if i==0 else "discovery"
    return split

def extract(project,source_run,seed,per_sample):
    import h5py
    r=discover(project,source_run); v=readj(r/"plan.json")
    core._unchanged(v["inputs"])
    if not (r/"comparison_complete.json").is_file():raise FileNotFoundError("A completed 08V run is required.")
    obs=pd.read_csv(Path(v["marker_cache_dir"])/"obs.csv.gz",index_col=0,dtype={"sample_id":str})
    obs.index=obs.index.astype(str)
    if core.ordered_id_hash(obs.index)!=v["cell_order_hash"] or len(obs)!=v["n_cells"]:raise ValueError("Marker cache row mismatch.")
    with h5py.File(v["inputs"]["baseline_path"],"r") as h:
        orig=core._read_elem(h["obs"]);genes=core._read_elem(h["var"]).index.astype(str)
        if not orig.index.astype(str).equals(obs.index) or not np.array_equal(orig.total_counts,obs.total_counts):raise ValueError("Original count source or row order changed.")
        for key,cache_key in (("sample","sample_id"),("condition","condition"),("population","population")):
            if orig[key].isna().any() or obs[cache_key].isna().any() or not np.array_equal(orig[key].astype(str),obs[cache_key].astype(str)):
                raise ValueError(f"Original sample/design metadata differs from the marker cache: {key}")
        raw=core._read_elem(h["layers/counts"])
    if not sp.issparse(raw) or not genes.is_unique or raw.shape!=(len(obs),len(genes)):raise ValueError("Expected sparse original counts with unique gene names.")
    raw=raw.tocsr();raw.sum_duplicates();raw.eliminate_zeros()
    for off in range(0,raw.nnz,3000000):
        d=raw.data[off:off+3000000]
        if not np.isfinite(d).all() or (d<0).any() or np.any(d!=np.rint(d)):raise ValueError("AmortizedLDA requires nonnegative integer counts, not a transformed matrix.")
    sample=obs.sample_id.astype(str); split=split_samples(obs,seed); discovery=sample.map(split).eq("discovery").to_numpy()
    rng=np.random.default_rng(seed)
    pilot=np.sort(np.concatenate([rng.choice(ix,min(len(ix),per_sample),replace=False) for sid in sorted(split) if split[sid]=="discovery" for ix in [np.flatnonzero(sample.to_numpy()==sid)]]))
    det=np.asarray(raw[pilot].getnnz(axis=0)).ravel()
    eligible=(det>=max(10,int(np.ceil(.001*len(pilot))))) & ~genes.isin(HELD)
    if eligible.sum()<20:raise ValueError("Too few eligible non-anchor genes to fit a topic model.")
    probes=[g for g in (*HELD,*STATE) if g in genes]
    probe_values=raw[:,genes.get_indexer(probes)].tocsc()
    measurements={g:probe_values.getcol(i).toarray().ravel() for i,g in enumerate(probes)}
    del probe_values
    if not set(HELD[:3]).issubset(measurements):raise ValueError("The CD4/CD8 evaluation assays are not all present.")
    counts=raw[:,eligible].astype(np.float32,copy=False).tocsr();del raw;gc.collect()
    informative=np.asarray(counts.sum(axis=1)).ravel()>0
    pilot=pilot[informative[pilot]]
    if not len(pilot):raise ValueError("No counts in discovery features.")
    obs=obs[["sample_id","condition","population","total_counts"]].copy()
    obs["sample_split"]=sample.map(split).to_numpy();obs["topic_fit_cell"]=False;obs.iloc[pilot,obs.columns.get_loc("topic_fit_cell")]=True
    obs["topic_informative"]=informative
    audit=pd.DataFrame({"gene":genes,"discovery_detected_cells":det,"excluded_validation_gene":genes.isin(HELD),"used_for_topics":eligible})
    core._unchanged(v["inputs"])
    return v,obs,counts,genes[eligible],pilot,measurements,audit

def call_train(model,epochs,batch=256):
    params=inspect.signature(model.train).parameters
    if "accelerator" not in params:raise RuntimeError("Unsupported AmortizedLDA.train API (missing accelerator). Use the existing modern scvi-tools UV environment.")
    kw=dict(max_epochs=epochs,accelerator="gpu",batch_size=batch,train_size=1.0)
    # The singular argument on PyroSviTrainMixin is forwarded verbatim to Lightning's plural
    # devices argument. Integer 0 means zero devices; [0] means exactly the first visible GPU.
    if "device" in params:kw["device"]=[0]
    elif "devices" in params:kw["devices"]=[0]
    else:raise RuntimeError("Unsupported AmortizedLDA.train GPU-device signature.")
    model.train(**kw)

def prepare_backend(seed):
    import torch,scvi,pyro
    if not torch.cuda.is_available():raise RuntimeError("PyTorch cannot see a CUDA device. Use the same GPU-enabled UV project as 08V.")
    if not hasattr(scvi.model,"AmortizedLDA"):raise RuntimeError("scvi.model.AmortizedLDA is unavailable in this kernel.")
    scvi.settings.seed=seed;pyro.clear_param_store()
    # Monte Carlo expectations in several scvi-tools releases run on CPU; avoid oversubscribing all 96 cores.
    torch.set_num_threads(min(8,torch.get_num_threads()))
    return scvi,torch

def fit_project(scvi,torch,obs,counts,genes,pilot,out,*,n_topics,epochs,seed):
    import anndata as ad
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    var=pd.DataFrame(index=genes);mname=out/"discovery_model"
    train=ad.AnnData(X=counts[pilot],obs=pd.DataFrame(index=obs.index[pilot]),var=var.copy())
    scvi.model.AmortizedLDA.setup_anndata(train)
    if (mname/"model.pt").exists() and (out/"trained.json").exists():
        model=scvi.model.AmortizedLDA.load(str(mname),adata=train)
    else:
        model=scvi.model.AmortizedLDA(train,n_topics=n_topics,n_hidden=128)
        call_train(model,epochs)
        model.save(str(mname),overwrite=True,save_anndata=False)
        core.save_json(out/"trained.json",{"n_fit":len(pilot),"n_topics":n_topics,"epochs":epochs})
    model.to_device("cuda:0");model.module.eval()
    gene_topics=model.get_feature_by_topic(n_samples=64)
    if (not gene_topics.index.equals(genes) or gene_topics.shape!=(len(genes),n_topics) or not np.isfinite(gene_topics.values).all()
        or (gene_topics.values<0).any() or not np.allclose(gene_topics.sum(axis=0),1,atol=1e-3)):
        raise ValueError("Invalid topic gene output, normalization or order.")
    ids=np.flatnonzero(obs.topic_informative.to_numpy())
    if (out/"projected.json").is_file():
        arr=np.load(out/"topic_proportions.npy",allow_pickle=False)
    else:
        arr=np.full((len(obs),n_topics),np.nan,np.float32)
        for start in range(0,len(ids),32768):
            ix=ids[start:start+32768]
            query=ad.AnnData(X=counts[ix],obs=pd.DataFrame(index=obs.index[ix]),var=var.copy())
            # In 1.3.x a query transferred automatically is registered only on the model
            # instance, but deregister_manager(query) also requires a class setup registration.
            scvi.model.AmortizedLDA.setup_anndata(query)
            mix=model.get_latent_representation(adata=query,n_samples=32,batch_size=256)
            if not mix.index.equals(query.obs_names) or list(mix.columns)!=list(gene_topics.columns):raise ValueError("Projection indices differ from query or topic order.")
            arr[ix]=mix.to_numpy(dtype=np.float32)
            print(f"08X projected {min(start+32768,len(ids)):,}/{len(ids):,} informative cells",flush=True)
            if hasattr(model,"deregister_manager"):model.deregister_manager(query)
            del mix,query
        np.save(out/"topic_proportions.npy",arr,allow_pickle=False)
        core.save_json(out/"projected.json",{"n_informative":len(ids)})
    if arr.shape!=(len(obs),n_topics) or not np.isfinite(arr[ids]).all() or (arr[ids]<0).any() or not np.allclose(arr[ids].sum(axis=1),1,atol=1e-3) or not np.isnan(arr[~obs.topic_informative.to_numpy()]).all():raise ValueError("Invalid topic proportions or uninformative rows.")
    return arr,gene_topics

def summarize(obs,arr,gene_topics,pilot,measurements,folder,seed):
    from sklearn.cluster import MiniBatchKMeans
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    from sklearn.metrics import roc_auc_score
    from scipy.stats import spearmanr
    import matplotlib.pyplot as plt
    from threadpoolctl import threadpool_limits
    import anndata as ad
    out=Path(folder); review=out/"review";review.mkdir(exist_ok=True)
    info=obs.topic_informative.to_numpy(); obs=obs.copy()
    ref=obs.sample_split.eq("discovery").to_numpy()
    root=np.sqrt(arr);groups=np.full(len(obs),-1,np.int16)
    with threadpool_limits(limits=4):
        km=MiniBatchKMeans(n_clusters=8,random_state=seed,batch_size=2048,n_init=5).fit(root[pilot])
        groups[info]=km.predict(root[info])
    obs["topic_cluster"]=pd.Categorical([str(i) if i>=0 else "no_fitted_gene_counts" for i in groups])
    gcinfo=obs.groupby(["sample_id","condition","sample_split","population","topic_cluster"],observed=True).size().rename("n_cells").reset_index()
    gcinfo.to_csv(review/"cluster_counts_by_sample.csv",index=False)
    cd4=measurements["Cd4"]>0;cd8=(measurements["Cd8a"]>0)|(measurements["Cd8b1"]>0)
    y=cd4.astype(int);anchor=info & (cd4 ^ cd8)
    dep=np.log1p(obs.total_counts.to_numpy(float))
    designero=np.c_[dep,dep**2]
    features={"depth_only":designero,"topics_plus_depth":np.column_stack([designero,root])}
    # Readout coefficients see discovery mice only, with each mouse & each anchor class equal total weight.
    train=np.flatnonzero(ref&anchor);sid=obs.sample_id.astype(str).to_numpy()
    if len(np.unique(y[train]))!=2:raise ValueError("Discovery samples lack both direct coreceptor anchors.")
    weights=np.zeros(len(train),float)
    for s in np.unique(sid[train]):
        for v in (0,1):
            where=(sid[train]==s)&(y[train]==v)
            if where.any():weights[where]=1/where.sum()
    weights*=len(weights)/weights.sum()
    data=[]
    for nm,x in features.items():
        model=make_pipeline(StandardScaler(),LogisticRegression(max_iter=600,C=1.,random_state=seed))
        model.fit(x[train],y[train],logisticregression__sample_weight=weights)
        # Evaluation labels are used only here, never in topic fit, graph or k-means.
        for s in np.unique(sid[~ref]):
            allix=np.flatnonzero((sid==s)&info)
            if len(allix)==0:
                data.append(dict(readout=nm,sample=s,condition=obs.condition.iloc[np.flatnonzero(sid==s)[0]],depth_bin="all",n_CD4=0,n_CD8=0,auc=np.nan))
                continue
            bins=pd.qcut(pd.Series(dep[allix]),5,labels=False,duplicates="drop").fillna(0).to_numpy(int)
            for q in [-1,*np.unique(bins)]:
                ix=allix if q==-1 else allix[bins==q]
                ix=ix[anchor[ix]]
                n4=int(y[ix].sum());n8=len(ix)-n4
                a=roc_auc_score(y[ix],model.decision_function(x[ix])) if min(n4,n8)>=5 else np.nan
                data.append(dict(readout=nm,sample=s,condition=obs.condition.iloc[allix[0]],depth_bin="all" if q==-1 else str(q),n_CD4=n4,n_CD8=n8,auc=a))
    ev=pd.DataFrame(data);ev.to_csv(review/"unseen_sample_auc_by_depth.csv",index=False)
    tab=ev[ev.depth_bin.ne("all")].pivot(index=["sample","condition","depth_bin"],columns="readout",values="auc").reindex(columns=["depth_only","topics_plus_depth"]).dropna().reset_index()
    sample=ev[["sample","condition"]].drop_duplicates().merge(tab.groupby(["sample","condition"],as_index=False)[["depth_only","topics_plus_depth"]].mean(),how="left")
    sample["delta_auc"]=sample.topics_plus_depth-sample.depth_only;sample.to_csv(review/"primary_lineage_test.csv",index=False)
    gene_topics.to_csv(review/"gene_by_topic.csv.gz")
    rankings=[]
    for topic in gene_topics:
        p=gene_topics[topic].to_numpy(); avg=gene_topics.values.mean(1)
        for name,vals in [("probability",p),("log2_specificity",np.log2((p+1e-9)/(avg+1e-9)))]:
            for rank,i in enumerate(np.argsort(-vals)[:35],1):rankings.append(dict(topic=topic,ranking=name,rank=rank,gene=gene_topics.index[i],score=vals[i],probability=p[i]))
    pd.DataFrame(rankings).to_csv(review/"top_topic_genes.csv",index=False)
    contexts=obs[["sample_id","condition","sample_split","topic_cluster"]].copy()
    for g,v in measurements.items():contexts[g]=v>0
    fr=contexts.groupby(["sample_id","condition","sample_split","topic_cluster"],observed=True)[list(measurements)].mean().reset_index()
    fr.to_csv(review/"observed_markers_by_cluster_sample.csv",index=False)
    read=[]
    for s in sorted(set(sid)):
        ix=np.flatnonzero((sid==s)&info)
        if len(ix)<2:continue
        for i,t in enumerate(gene_topics):
            vals=arr[ix,i];read.append(dict(sample=s,split=obs.sample_split.iloc[ix[0]],topic=t,
                    mean_membership=vals.mean(),spearman_full_depth=spearmanr(vals,dep[ix]).statistic if np.std(dep[ix]) and np.std(vals) else np.nan))
    pd.DataFrame(read).to_csv(review/"topic_depth_by_sample.csv",index=False)
    obs["observed_coreceptor"]=pd.Categorical(np.select([cd4&~cd8,cd8&~cd4,cd4&cd8],["CD4_only","CD8_only","both"],default="neither"))
    a=ad.AnnData(X=sp.csr_matrix((len(obs),0),dtype=np.float32),obs=obs);a.obsm["X_topics"]=arr
    a.uns["08X_note"]="Mixture proportions; no cell type assigned. Cluster - no_fitted_gene_counts means no usable evidence."
    a.write_h5ad(out/"all_cells_topics.h5ad")
    fig,axs=plt.subplots(1,2,figsize=(11,4),layout="constrained")
    for _,r in sample.iterrows():
        if pd.notna(r.delta_auc):axs[0].plot([0,1],[r.depth_only,r.topics_plus_depth],marker="o",label=str(r["sample"]))
    axs[0].axhline(.5,ls="--",c="gray");axs[0].set(xticks=[0,1],xticklabels=["Depth only","Topics + depth"],ylabel="Within-depth AUROC",title="Held-out samples · CD4-only versus CD8-only");axs[0].legend(fontsize=8)
    used=[g for g in ("Cd4","Cd8a","Cd8b1","Zbtb7b","Cd40lg","Foxp3","Il2ra","Ctla4","Pdcd1","Tox","Junb","Nkg7","Lyz2") if g in fr]
    hm=fr[fr.sample_split.eq("evaluation") & ~fr.topic_cluster.astype(str).eq("no_fitted_gene_counts")].groupby("topic_cluster",observed=True)[used].mean()
    if len(hm):
        img=axs[1].imshow(100*hm.T,aspect="auto",cmap="viridis");axs[1].set(yticks=np.arange(len(used)),yticklabels=used,xticks=np.arange(len(hm)),xticklabels=hm.index,xlabel="Unsupervised topic cluster",title="Measured marker detection · held-out samples");fig.colorbar(img,ax=axs[1],label="% positive")
    fig.savefig(review/"topic_lineage_review.png",dpi=140);plt.close(fig)
    return review

def run(project_dir=None,source_08v_run=None,*,seed=17,n_topics=12,epochs=35,per_sample=4000,output_root=None):
    if any(isinstance(v,bool) or not isinstance(v,(int,np.integer)) or v<1 for v in (n_topics,epochs,per_sample)) or n_topics<2:
        raise ValueError("Use positive integer epochs and per_sample, and at least two topics.")
    start=time.monotonic();scvi,torch=prepare_backend(seed)
    v,obs,counts,genes,pilot,m,audit=extract(project_dir,source_08v_run,seed,per_sample)
    ident=core._digest({"release":RELEASE,"impl":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"08V":v["plan_id"],"rows":v["cell_order_hash"],"features":core.ordered_id_hash(genes),
        "pilot":core.ordered_id_hash(obs.index[pilot]),"seed":seed,"n_topics":n_topics,"epochs":epochs,"per_sample":per_sample,"scvi":scvi.__version__,"torch":str(torch.__version__)})
    out=(Path(output_root) if output_root else Path(v["inputs"]["pointer_path"]).parent.parent/"23_tcell_reference_free_topics")/ident[:20]
    out.mkdir(parents=True,exist_ok=True)
    print(f"08X: {len(pilot):,} balanced discovery cells fit {n_topics} topics across {len(genes):,} unseen-marker-excluded genes; projecting {len(obs):,} original cells. Output: {out}",flush=True)
    arr,topics=fit_project(scvi,torch,obs,counts,genes,pilot,out,n_topics=n_topics,epochs=epochs,seed=seed)
    del counts;gc.collect()
    review=summarize(obs,arr,topics,pilot,m,out,seed)
    audit.to_csv(review/"feature_audit.csv.gz",index=False)
    obs.groupby(["sample_id","condition","sample_split"],observed=True).agg(n_cells=("topic_fit_cell","size"),n_fit=("topic_fit_cell","sum"),n_informative=("topic_informative","sum")).to_csv(review/"sample_design.csv")
    core.save_json(review/"receipt.json",dict(version=RELEASE,source_08v=v["plan_id"],n_cells=len(obs),n_fit=len(pilot),n_genes=len(genes),heldout=list(HELD),
        n_topics=n_topics,preset_cluster_views=8,epochs=epochs,seed=seed,elapsed_minutes=(time.monotonic()-start)/60,
        supervised_readout="only evaluation of the frozen unsupervised factors; no cell type calls",zero_rows="preserved with NA memberships",gene_counts="original sparse layer counts only; discovery-fit cells alone select genes",backend={"scvi":scvi.__version__,"torch":str(torch.__version__),"gpu":torch.cuda.get_device_name(0)}))
    zpath=out/"08X_return_to_chat.zip"
    with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(review.glob("*")):
            if p.is_file():z.write(p,p.name)
    return dict(run_root=str(out),review_dir=str(review),zip_path=str(zpath))
