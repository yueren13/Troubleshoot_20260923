"""08U notebook orchestration, isolated GPU workers, and resumable experiments."""
from __future__ import annotations

import gc
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import zipfile

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_workflow as base
import tcell_weighted_gpu as shared
import tcell_banksy_math as bm
import tcell_banksy_sources as sources

VERSION = "08U-banksy-workflow-1.0.0"
HELDOUT_GENES = sources.HELDOUT_GENES
DEFAULT_GPU_SETTINGS = dict(shared.DEFAULT_SETTINGS, pca_power_iter=2)


def _read(path):
    return json.loads(Path(path).read_text())


def _devices(runtime):
    count = int(runtime["visible_device_count"])
    if count < 1:
        raise ValueError("08U needs the working RAPIDS GPU kernel.")
    return list(range(min(count, 4)))


def _diagnostic_zip(directory, exc=None):
    directory = Path(directory)
    if exc is not None:
        shared.atomic_json(directory / "failure.json", {"type": type(exc).__name__,
            "message": str(exc), "traceback": traceback.format_exc()})
    dest = directory / "08U_diagnostics.zip"
    temp = dest.with_suffix(".zip.partial")
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(directory.rglob("*")):
            if path.is_file() and path.suffix in (".json", ".log") and path.stat().st_size < 4_000_000:
                archive.write(path, path.relative_to(directory))
    os.replace(temp, dest)
    return dest


def preflight(helper_dir, *, log_dir=None, timeout_seconds=600):
    """Check installed BANKSY mathematics and the exact GPU path in a child.

    Uses the current notebook's Python executable. No installation, upgrade,
    global CUDA reset, or biological-data load is performed by this check.
    """
    directory = Path(log_dir or Path.cwd() / "08U_diagnostics").resolve()
    directory.mkdir(parents=True, exist_ok=True)
    helper = Path(helper_dir).resolve() / "tcell_banksy_gpu.py"
    log = directory / "preflight.log"
    runtime_path = directory / "preflight_report.json"
    report = {"status": "starting", "python_executable": sys.executable,
              "helper": str(helper), "timeout_seconds": timeout_seconds, "version": VERSION}
    shared.atomic_json(runtime_path, report)
    started = time.monotonic()
    last_heartbeat = started
    process = None
    print("Checking BANKSY and RAPIDS in", sys.executable, flush=True)
    try:
        with log.open("w") as writer, log.open("r", errors="replace") as reader:
            process = subprocess.Popen([sys.executable, str(helper), "--stage", "preflight"],
                env=base._process_env(), stdout=writer, stderr=subprocess.STDOUT, start_new_session=True)
            while True:
                chunk = reader.read()
                if chunk:
                    print(chunk, end="", flush=True)
                code = process.poll()
                now = time.monotonic()
                if code is not None:
                    print(reader.read(), end="", flush=True)
                    break
                if now - started > timeout_seconds:
                    raise TimeoutError(f"BANKSY/GPU preflight exceeded {timeout_seconds:g} seconds; its log is retained.")
                if now - last_heartbeat > 15:
                    print(f"[08U startup] Still running, {now-started:.0f}s elapsed.", flush=True)
                    last_heartbeat = now
                time.sleep(.25)
            if code:
                raise RuntimeError(f"BANKSY/GPU startup worker exited with status {code}. See the captured traceback above.")
        parsed = None
        for line in reversed(log.read_text(errors="replace").splitlines()):
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict) and value.get("ok") is True:
                parsed = value
                break
        if parsed is None or int(parsed.get("visible_device_count", 0)) < 1:
            raise RuntimeError("Startup did not return a complete BANKSY/GPU success report.")
        report.update(status="passed", runtime=parsed)
        return dict(parsed, diagnostic_dir=str(directory),
                    preflight_report_path=str(runtime_path), preflight_log_path=str(log))
    except BaseException as exc:
        report.update(status="interrupted" if isinstance(exc, KeyboardInterrupt) else "failed",
                      error={"type": type(exc).__name__, "message": str(exc)})
        shared.atomic_json(runtime_path, report)
        exc.diagnostic_zip = _diagnostic_zip(directory, exc)
        print("Return this startup diagnostic ZIP:", exc.diagnostic_zip, flush=True)
        raise
    finally:
        if process is not None:
            base._stop_owned(process)
            report["returncode"] = process.poll()
        report["elapsed_seconds"] = time.monotonic() - started
        shared.atomic_json(runtime_path, report)
        _diagnostic_zip(directory)


def _run_jobs(jobs, runtime, *, max_minutes=0):
    """One isolated child per visible GPU; stop only children owned by this call."""
    pending = list(jobs)
    available = _devices(runtime)
    active = {}
    completed = {}
    readers = []
    started = time.monotonic()
    last_heartbeat = started
    try:
        while pending or active:
            while pending and available:
                job = pending.pop(0)
                device = available.pop(0)
                directory = Path(job["log_dir"])
                directory.mkdir(parents=True, exist_ok=True)
                log = directory / "console.log"
                writer = log.open("w")
                try:
                    process = subprocess.Popen(job["command"], env=base._process_env(device),
                        stdout=writer, stderr=subprocess.STDOUT, start_new_session=True)
                except BaseException:
                    writer.close()
                    raise
                reader = log.open("r", errors="replace")
                readers.append(reader)
                active[job["name"]] = dict(job=job, process=process, device=device,
                                           writer=writer, reader=reader, log=log)
                print(f"[08U] Started {job['name']} on visible GPU {device}.", flush=True)
            elapsed = time.monotonic() - started
            if max_minutes and elapsed > max_minutes * 60:
                raise TimeoutError(f"08U compute reached {max_minutes:g} minutes. Completed per-sample/PCA/graph checkpoints remain available for Run All to resume.")
            for name, state in list(active.items()):
                chunk = state["reader"].read()
                if chunk:
                    for line in chunk.splitlines():
                        print(f"[{name}] {line}", flush=True)
                code = state["process"].poll()
                if code is not None:
                    state["writer"].close()
                    tail = state["reader"].read()
                    if tail:
                        print(tail, end="", flush=True)
                    if code:
                        raise RuntimeError(f"08U worker {name!r} exited with status {code}. Log: {state['log']}")
                    receipt = Path(state["job"]["receipt"])
                    if not receipt.is_file():
                        raise RuntimeError(f"08U worker {name!r} exited without its completion record: {receipt}")
                    completed[name] = receipt
                    available.append(state["device"])
                    del active[name]
            if time.monotonic() - last_heartbeat > 30:
                print(f"[08U] {elapsed/60:.1f} min; active: {', '.join(active)}; "
                      f"{len(completed)} finished; {len(pending)} queued.", flush=True)
                last_heartbeat = time.monotonic()
            if active:
                time.sleep(.5)
        return completed, time.monotonic() - started
    finally:
        for state in active.values():
            base._stop_owned(state["process"])
            state["writer"].close()
        for reader in readers:
            reader.close()


def prepare_experiment(cache_dir, helper_dir, runtime, *, spatial_weight=.2,
                       k_geom=15, row_chunk_size=4096, gene_chunk_size=128,
                       gpu_settings=None, resume=True):
    """Cache same-sample tissue context once, then define the four paired arms."""
    cache = Path(cache_dir).resolve()
    source = _read(cache / "cache_manifest.json")
    if not 0 < float(spatial_weight) < 1:
        raise ValueError("spatial_weight must be strictly between zero and one.")
    if int(k_geom) != k_geom or k_geom < 1:
        raise ValueError("k_geom must be a positive integer.")
    cfg = shared.validate_settings(gpu_settings or DEFAULT_GPU_SETTINGS)
    helper = Path(helper_dir).resolve() / "tcell_banksy_gpu.py"
    math_version = getattr(bm, "VERSION", getattr(bm, "ENGINE_VERSION", "unknown"))
    spatial_id = base._digest({"source_cache_id": source["cache_id"], "k_geom": int(k_geom),
                               "math_version": math_version, "version": VERSION})[:20]
    spatial_dir = cache.parent / "spatial" / spatial_id
    spatial_dir.mkdir(parents=True, exist_ok=True)
    genes = source["genes"]
    jobs, spec_paths = [], []
    for number, sample in enumerate(source["samples"]):
        out = spatial_dir / f"sample_{number:02d}"
        out.mkdir(parents=True, exist_ok=True)
        job = {"sample_id": sample["sample_id"], "matrix_path": sample["x_tissue_path"],
               "coords_path": sample["coords_path"],
               "focal_local_rows_path": sample["focal_local_rows_path"],
               "focal_global_rows_path": sample["focal_global_rows_path"],
               "output_dir": str(out), "k_geom": int(k_geom), "gene_chunk_size": int(gene_chunk_size),
               "gene_names": genes, "source_cache_id": source["cache_id"], "math_version": math_version}
        job["job_fingerprint"] = base._digest({**job, "source_signatures":
            [base._signature(job[key]) for key in ("matrix_path", "coords_path", "focal_local_rows_path", "focal_global_rows_path")]})
        job_path = out / "job.json"
        shared.atomic_json(job_path, job)
        spec_path = out / "spatial_spec.json"
        spec_paths.append(spec_path)
        compatible = False
        if resume and spec_path.is_file():
            old = _read(spec_path)
            if old.get("job_fingerprint") == job["job_fingerprint"]:
                try:
                    compatible = all(Path(old[key]).is_file() for key in
                                     ("mean_path", "gradient_path", "global_rows_path"))
                except KeyError:
                    pass
        if compatible:
            print(f"[08U] Reusing physical-neighborhood features: {sample['sample_id']}", flush=True)
        else:
            jobs.append({"name": f"spatial_{number:02d}_{sample['sample_id']}",
                "log_dir": str(out), "receipt": str(spec_path),
                "command": [sys.executable, str(helper), "--stage", "spatial", "--job", str(job_path)]})
    try:
        _, spatial_seconds = _run_jobs(jobs, runtime)
        specs = [_read(path) for path in spec_paths]
        statistics_path = spatial_dir / "block_statistics.npz"
        statistics_receipt = spatial_dir / "statistics_complete.json"
        statistics_fp = base._digest({"source": source["cache_id"], "version": math_version,
            "specs": [{k: spec.get(k) for k in ("context_sha256", "job_fingerprint")} for spec in specs],
            "outputs": [base._signature(spec[key]) for spec in specs
                        for key in ("mean_path", "gradient_path", "global_rows_path")]})
        compatible_stats = (resume and statistics_path.is_file() and statistics_receipt.is_file()
            and _read(statistics_receipt).get("fingerprint") == statistics_fp
            and _read(statistics_receipt).get("size") == statistics_path.stat().st_size)
        if not compatible_stats:
            print("[08U] Standardizing BANKSY blocks across the complete T-cell population.", flush=True)
            own = sp.load_npz(source["focal_own_path"]).tocsr()
            stats = bm.fit_block_statistics(own, specs, row_chunk_size=row_chunk_size, gene_names=genes)
            bm.save_block_statistics(stats, statistics_path)
            shared.atomic_json(statistics_receipt, {"fingerprint": statistics_fp,
                               "size": statistics_path.stat().st_size})
            del own, stats
            gc.collect()
        arms = {
            "banksy_lam0": {"lambda": 0., "heldout": False},
            "banksy_lam02": {"lambda": float(spatial_weight), "heldout": False},
            "heldout_lam0": {"lambda": 0., "heldout": True},
            "heldout_lam02": {"lambda": float(spatial_weight), "heldout": True},
        }
        identity = base._digest({"source": source["cache_id"], "statistics": statistics_fp,
            "arms": arms, "settings": cfg, "version": VERSION, "math_version": math_version})
        run_dir = cache.parent / "runs" / identity[:20]
        run_dir.mkdir(parents=True, exist_ok=True)
        experiment = {"version": VERSION, "experiment_id": identity,
            "run_dir": str(run_dir), "cache_dir": str(cache), "n_cells": source["n_cells"],
            "n_features": source["n_features"], "n_tissue_cells": source["n_tissue_cells"],
            "source_manifest_path": str(cache / "cache_manifest.json"),
            "spatial_dir": str(spatial_dir), "spatial_specs": specs,
            "statistics_path": str(statistics_path), "statistics_fingerprint": statistics_fp,
            "row_chunk_size": int(row_chunk_size), "k_geom": int(k_geom),
            "spatial_weight": float(spatial_weight), "heldout_genes": list(HELDOUT_GENES),
            "gpu_settings": cfg, "arms": arms, "spatial_seconds_this_run": spatial_seconds,
            "runtime": runtime, "all_08O_cells_retained": True,
            "normalization": "original full-library log1p 10000; pooled per-gene block z scores",
            "interpretation": "Full-tissue BANKSY context for fixed T-cell focal rows; no corrected molecule counts.",
            "cell_order_sha256": source["cell_order_sha256"],
            "source_scope_by_sample": {s["sample_id"]: s["source_scope"] for s in source["samples"]}}
        shared.atomic_json(run_dir / "experiment.json", experiment)
        print(f"[08U] Four matched variants ready: {source['n_cells']:,} focal T cells, "
              f"{source['n_tissue_cells']:,} tissue context cells.", flush=True)
        return experiment
    except BaseException as exc:
        exc.diagnostic_zip = _diagnostic_zip(spatial_dir, exc)
        print("Return this spatial-stage diagnostic ZIP:", exc.diagnostic_zip, flush=True)
        raise


def launch_experiment(experiment, helper_dir, runtime, *, resume=True, max_minutes=110):
    """GPU PCA/Harmony/neighbors/Leiden/UMAP; up to four independent workers."""
    run_dir = Path(experiment["run_dir"])
    helper = Path(helper_dir).resolve() / "tcell_banksy_gpu.py"
    experiment_path = run_dir / "experiment.json"
    jobs = []
    for name in experiment["arms"]:
        command = [sys.executable, str(helper), "--stage", "branch", "--experiment",
                   str(experiment_path), "--branch", name]
        if not resume:
            command.append("--no-resume")
        jobs.append({"name": name, "command": command, "log_dir": str(run_dir / name),
                     "receipt": str(run_dir / name / "completion.json")})
    shared.atomic_json(run_dir / "launch.json", {"devices": _devices(runtime),
        "python_executable": sys.executable, "max_minutes": max_minutes,
        "experiment_id": experiment["experiment_id"]})
    try:
        completed, elapsed = _run_jobs(jobs, runtime, max_minutes=max_minutes)
        branches = {}
        for name, receipt in completed.items():
            info = _read(receipt)
            path = Path(info["embedding_path"])
            if info.get("status") != "complete" or not path.is_file():
                raise RuntimeError(f"Incomplete {name} result: {receipt}")
            branches[name] = path
        shared.atomic_json(run_dir / "comparison_complete.json", {"branches": branches,
            "elapsed_seconds": elapsed, "experiment_id": experiment["experiment_id"]})
        return branches, elapsed
    except BaseException as exc:
        exc.diagnostic_zip = _diagnostic_zip(run_dir, exc)
        print("Return this clustering diagnostic ZIP:", exc.diagnostic_zip, flush=True)
        raise


def load_methods(branches, obs):
    import anndata as ad
    methods, manifests = {}, {}
    for name, path in branches.items():
        data = ad.read_h5ad(path)
        if not np.array_equal(data.obs_names.astype(str), obs.index.astype(str)):
            raise ValueError(f"{name}: embedding cell order differs from original counts.")
        if data.uns.get("08u_stage") != "complete" or not any(
                key in data.uns for key in ("banksy_manifest", "banksy_manifest_json")):
            raise ValueError(f"{name}: missing completed BANKSY provenance.")
        methods[name] = data
        manifests[name] = _read(Path(path).parent / "feature_manifest.json")
    return methods, manifests


def resource_estimate(manifest, *, row_chunk_size=4096, n_pcs=50, oversamples=20):
    n, g = int(manifest["n_cells"]), int(manifest["n_features"])
    width = n_pcs + oversamples
    return {
        "n_focal_cells": n, "n_tissue_cells": manifest["n_tissue_cells"], "n_genes": g,
        "spatial_float32_cache_GiB": 2 * n * g * 4 / 2**30,
        "avoided_combined_dense_BANKSY_GiB": 3 * n * g * 4 / 2**30,
        "one_streamed_block_chunk_MiB": row_chunk_size * g * 4 / 2**20,
        "one_thin_PCA_array_MiB": n * width * 4 / 2**20,
        "note": "Array sizes only; exclude temporary workspace, sparse matrices, graph, Harmony and allocator overhead. Not a measured peak or runtime guarantee."}
