"""08U: immutable original T cells plus physical, full-tissue BANKSY inputs.

The completed 08O analysis determines every focal cell and its order.  Its saved
source manifest, rather than a new H5AD picker or a new annotation, determines
the full-tissue expression and physical coordinates.  Original molecule counts
are never overwritten.  Feature selection does not use contamination ratios or
manual lineage-marker boosts.
"""
from __future__ import annotations

import gc
import hashlib
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import re
import time

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_workflow as base

VERSION = "08U-banksy-sources-1.0.0"
HELDOUT_GENES = ("Cd8b1", "Il2ra", "Ctla4", "Ikzf2", "Tnfrsf18")
COORDINATE_PAIRS = (("_proseg_x_um", "_proseg_y_um"),
                    ("spatial_x_um", "spatial_y_um"))
# These names express an actual cell-level eligibility decision.  An annotation
# being unknown/not_in_scvi is NOT an exclusion criterion for spatial neighbors.
QC_COLUMNS = ("qc_pass", "pass_qc", "passes_qc", "passed_qc", "_qc_pass",
              "qc_keep", "keep_qc", "in_qc", "pass_density_qc", "pass_ct26_qc")


def _newline_hash(values):
    """08U engine identity encoding; legacy 08T hashes remain separate."""
    return hashlib.sha256("\n".join(map(str, values)).encode("utf-8")).hexdigest()


def resolve_inputs(project_dir, *, allow_known_fallback=False):
    """Use the same one-folder setup and completed 08O pointer as 08T."""
    # The unchanged legacy resolver prints its own 08S destination.  Suppress
    # that obsolete label while retaining its exact discovery/validation logic.
    with redirect_stdout(io.StringIO()):
        inputs = base.resolve_inputs(project_dir, allow_known_fallback=allow_known_fallback)
    inputs["output_root"] = str(Path(inputs["pointer_path"]).parent.parent
                                / "20_tcell_banksy_harmony")
    print("Completed 08O focal cells:", inputs["baseline_path"], flush=True)
    print("New 08U output:", inputs["output_root"], flush=True)
    return inputs


def _strings(values, name, *, unique=False):
    values = pd.Series(values, dtype="string")
    bad = (values.isna() | values.str.strip().eq("") | values.ne(values.str.strip())
           | values.str.contains(r"[\r\n\t\x00]", regex=True, na=True))
    if bool(bad.any()):
        raise ValueError(f"{name}: missing, padded, or invalid identifiers.")
    result = values.astype(str).to_numpy()
    if unique and pd.Index(result).has_duplicates:
        raise ValueError(f"{name}: duplicate identifiers; exact joins require unique IDs.")
    return result


def _vector(node):
    import h5py
    if isinstance(node, h5py.Dataset):
        return np.asarray(node.asstr()[...]) if h5py.check_string_dtype(node.dtype) else np.asarray(node[...])
    enc = node.attrs.get("encoding-type", "")
    if isinstance(enc, bytes):
        enc = enc.decode()
    if enc == "categorical" or {"codes", "categories"}.issubset(node):
        return pd.Categorical.from_codes(np.asarray(node["codes"], dtype=int),
                                         _vector(node["categories"]),
                                         ordered=bool(node.attrs.get("ordered", False)))
    if {"values", "mask"}.issubset(node):
        value = np.asarray(_vector(node["values"]), dtype=object)
        value[np.asarray(node["mask"], dtype=bool)] = pd.NA
        return value
    if enc == "null":
        return None
    raise TypeError(f"Unsupported H5AD vector encoding {enc!r} at {node.name}.")


def _h5_frame(group, columns=None):
    key = group.attrs.get("_index", "_index")
    if isinstance(key, bytes):
        key = key.decode()
    frame = pd.DataFrame(index=pd.Index(_strings(_vector(group[key]), group.name, unique=True)))
    for column in (list(group) if columns is None else columns):
        if column == key or column not in group:
            continue
        value = _vector(group[column])
        if value is not None:
            frame[column] = value
    return frame


def _read_frame(path, columns=None):
    path = Path(path)
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        schema = set(pq.read_schema(path).names)
        selected = None if columns is None else [c for c in columns if c in schema]
        return pd.read_parquet(path, columns=selected)
    if path.suffix.lower() in (".h5ad", ".h5"):
        import h5py
        with h5py.File(path, "r") as handle:
            return _h5_frame(handle["obs"], columns)
    sep = "\t" if ".tsv" in path.name else ","
    # CSV fallback preserves source IDs such as '00001'.
    return pd.read_csv(path, sep=sep, dtype=str, keep_default_na=False)


class RawReader:
    """Bounded CSR/dense row reads of the manifest's explicit original count key."""

    def __init__(self, path, matrix_key):
        import h5py
        self.path = Path(path)
        self.file = h5py.File(path, "r")
        try:
            key = str(matrix_key).strip("/")
            self.obs = _h5_frame(self.file["obs"], [])
            self.var = _h5_frame(self.file["raw/var" if key.startswith("raw/") else "var"])
            if key not in self.file:
                raise KeyError(f"{path}: recorded original count key {key!r} is missing.")
            self.node = self.file[key]
            if isinstance(self.node, h5py.Dataset):
                self.kind = "dense"
                self.shape = tuple(self.node.shape)
            else:
                encoding = self.node.attrs.get("encoding-type", "")
                if isinstance(encoding, bytes):
                    encoding = encoding.decode()
                if encoding != "csr_matrix":
                    raise ValueError(f"{path}/{key}: row streaming requires CSR or dense counts; found {encoding!r}.")
                self.kind = "csr"
                self.shape = tuple(map(int, self.node.attrs["shape"]))
            if self.shape != (len(self.obs), len(self.var)) or self.shape[1] == 0:
                raise ValueError(f"{path}: original matrix and obs/var axes disagree or no genes are present.")
        except Exception:
            self.file.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.file.close()

    def block(self, left, right):
        if self.kind == "dense":
            matrix = sp.csr_matrix(self.node[left:right, :])
        else:
            pointer = np.asarray(self.node["indptr"][left:right + 1], dtype=np.int64)
            lo, hi = int(pointer[0]), int(pointer[-1])
            matrix = sp.csr_matrix((np.asarray(self.node["data"][lo:hi]),
                                    np.asarray(self.node["indices"][lo:hi]), pointer - lo),
                                   shape=(right - left, self.shape[1]))
        matrix.sum_duplicates()
        matrix.eliminate_zeros()
        return matrix


def _normalize_source_manifest(records, relative_to):
    frame = pd.DataFrame(records)
    required = ("sample", "condition", "raw_h5ad", "matrix_key", "label_column")
    missing = sorted(set(required) - set(frame))
    if frame.empty or missing:
        raise ValueError(f"Saved 08O source manifest is empty or missing fields: {missing}.")
    defaults = {"unit": "", "annotation_file": "", "cell_id_column": "__index__",
                "sample_column": "", "gene_table": "", "gene_id_column": "__index__",
                "gene_symbol_column": "__index__", "total_counts_column": ""}
    for key, default in defaults.items():
        if key not in frame:
            frame[key] = default
        frame[key] = frame[key].fillna("").astype(str)
    frame.loc[frame["unit"].eq(""), "unit"] = frame.loc[frame["unit"].eq(""), "sample"]
    for key in (*required, "unit"):
        frame[key] = _strings(frame[key], f"source manifest {key}", unique=key == "sample")
    for key in ("raw_h5ad", "annotation_file", "gene_table"):
        frame[key] = [str(base._path(value, relative_to)) if value else "" for value in frame[key]]
        for value in frame[key]:
            if value and not Path(value).is_file():
                raise FileNotFoundError(f"An original 08O source is unavailable: {value}")
    repeated = frame["raw_h5ad"].duplicated(keep=False)
    if (repeated & frame["sample_column"].eq("")).any():
        raise ValueError("A shared raw H5AD requires the recorded sample_column; cross-sample physical neighborhoods are forbidden.")
    return frame.reset_index(drop=True)


def discover_sources(inputs):
    """Recover exactly the original full-tissue sources saved by completed 08O."""
    import h5py
    base._unchanged(inputs)
    records = None
    origin = None
    with h5py.File(inputs["baseline_path"], "r") as handle:
        key = "uns/08m_extraction/source_manifest_json"
        if key in handle:
            records = json.loads(str(base._read_elem(handle[key])))
            origin = {"kind": "08O embedded original extraction manifest", "path": inputs["baseline_path"], "h5_key": key}
    tracked = []
    if records is None:
        # The completed 08O pointer records this exact ratio run; no arbitrary
        # directory search or current/reannotated source substitution is made.
        ratio_dir = inputs.get("index", {}).get("ratio_dir")
        if ratio_dir:
            path = base._path(ratio_dir, Path(inputs["pointer_path"]).parent) / "source_manifest.csv"
            if path.is_file():
                records = pd.read_csv(path, dtype=str, keep_default_na=False).to_dict("records")
                origin = {"kind": "08O recorded ratio-run source manifest", "path": str(path)}
                tracked.append(base._signature(path))
    if records is None:
        raise ValueError("Completed 08O lacks both its embedded 08m_extraction/source_manifest_json and its recorded ratio-run source_manifest.csv. "
                         "08U needs these existing original-source records to form full-tissue physical neighborhoods; a T-only graph is not substituted.")
    frame = _normalize_source_manifest(records, Path(origin["path"]).parent)
    seen = {item["path"] for item in tracked}
    for row in frame.to_dict("records"):
        for key in ("raw_h5ad", "annotation_file", "gene_table"):
            path = row[key]
            if path and path not in seen:
                tracked.append(base._signature(path))
                seen.add(path)
    return frame, {"source_manifest_origin": origin, "source_signatures": tracked}


def _check_signatures(signatures):
    for recorded in signatures:
        if base._signature(recorded["path"]) != recorded:
            raise RuntimeError(f"An original full-tissue input changed during preparation: {recorded['path']}. Rerun input preparation with stable files.")


def _symbols(row, raw):
    if row["gene_table"]:
        table = _read_frame(row["gene_table"])
        key = row["gene_id_column"]
        if key == "__index__" and isinstance(table.index, pd.RangeIndex):
            if len(table.columns) and str(table.columns[0]).startswith("Unnamed:"):
                table = table.set_index(table.columns[0])
            else:
                raise ValueError("A CSV gene table needs explicit gene IDs; positional feature matching is not permitted.")
        ids = table.index if key == "__index__" else table[key]
        table = table.copy()
        table.index = _strings(ids, "original feature IDs", unique=True)
        if len(table) != len(raw.var) or not raw.var.index.isin(table.index).all():
            raise ValueError(f"{row['sample']}: original gene table and count feature axes disagree.")
        table = table.reindex(raw.var.index)
    else:
        table = raw.var
    key = row["gene_symbol_column"]
    return _strings(table.index if key == "__index__" else table[key], "original gene symbols")


def _as_bool(values, name):
    text = pd.Series(values).astype("string").str.lower().str.strip()
    truth = text.isin(["true", "1", "1.0", "yes", "pass", "passed"])
    false = text.isin(["false", "0", "0.0", "no", "fail", "failed"])
    if not (truth | false).all():
        raise ValueError(f"{name}: an explicit QC flag contains missing or unrecognized values.")
    return truth.to_numpy(dtype=bool)


def load_spatial_context(row, raw, focal_obs):
    """Align tissue cells to raw rows; reject every missing/misaligned focal cell.

    Unknown lineage labels remain eligible neighbors.  If no saved QC mask is
    available, the fallback is explicitly described as source-defined cells;
    no claim of independently verified QC eligibility is made.
    """
    sample = str(row["sample"])
    columns = list(dict.fromkeys([row["cell_id_column"], row["sample_column"], row["label_column"]]
                                + [c for pair in COORDINATE_PAIRS for c in pair]
                                + list(QC_COLUMNS) + ["raw_total_counts", "total_counts"]))
    columns = [c for c in columns if c and c != "__index__"]
    metadata = _read_frame(row["annotation_file"], columns) if row["annotation_file"] else _h5_frame(raw.file["obs"], columns)
    if row["sample_column"]:
        key = row["sample_column"]
        if key not in metadata:
            raise KeyError(f"{sample}: recorded sample column {key!r} is missing from spatial metadata.")
        metadata = metadata.loc[metadata[key].astype(str).eq(sample)].copy()
    if metadata.empty:
        raise ValueError(f"{sample}: no exactly matched source metadata rows.")
    id_key = row["cell_id_column"]
    ids = metadata.index if id_key == "__index__" else metadata[id_key]
    metadata = metadata.copy()
    metadata.index = _strings(ids, f"{sample} tissue source IDs", unique=True)
    positions = raw.obs.index.get_indexer(metadata.index)
    if (positions < 0).any():
        raise ValueError(f"{sample}: spatial metadata contains IDs absent from the original raw counts.")
    if "source_cell_id" not in focal_obs:
        raise ValueError("Completed 08O metadata lacks its exact original source_cell_id; no guessed ID parsing is used.")
    focal_ids = _strings(focal_obs["source_cell_id"], f"{sample} focal source IDs", unique=True)
    local = metadata.index.get_indexer(focal_ids)
    if (local < 0).any():
        raise ValueError(f"{sample}: {int((local < 0).sum())} original 08O T cells are absent from spatial metadata.")
    label_key = row["label_column"]
    if label_key not in metadata:
        raise KeyError(f"{sample}: original lineage label column {label_key!r} is missing.")
    if not np.array_equal(metadata.iloc[local][label_key].astype(str).to_numpy(), focal_obs["population"].astype(str).to_numpy()):
        raise ValueError(f"{sample}: original 08O T-cell labels and source annotation differ.")
    pair = next((pair for pair in COORDINATE_PAIRS if set(pair).issubset(metadata)), None)
    if pair is None:
        raise KeyError(f"{sample}: physical micron coordinates (_proseg_x_um/_proseg_y_um or spatial_x_um/spatial_y_um) are missing. Pixel coordinates are not silently substituted.")
    xy = metadata[list(pair)].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)
    finite = np.isfinite(xy).all(axis=1)
    if not finite[local].all():
        raise ValueError(f"{sample}: an original focal T cell has invalid physical coordinates; no focal cells can be dropped.")
    qc_columns = [c for c in QC_COLUMNS if c in metadata]
    if qc_columns:
        masks = [_as_bool(metadata[c], f"{sample}.{c}") for c in qc_columns]
        # Several masks can represent successive upstream QC stages.
        qc_mask = np.logical_and.reduce(masks)
        scope = "source cells passing all saved explicit QC flags"
    else:
        qc_mask = np.ones(len(metadata), dtype=bool)
        scope = "source-defined cells; independent QC mask unavailable"
    if not qc_mask[local].all():
        raise ValueError(f"{sample}: a recorded upstream QC mask excludes an original 08O focal T cell. Resolve the source mismatch; 08U will not change the focal cohort.")
    eligible = qc_mask & finite
    # Source row order gives deterministic row streaming; never metadata order.
    order = np.argsort(positions[eligible], kind="stable")
    chosen = np.flatnonzero(eligible)[order]
    return {"metadata": metadata, "source_rows": positions[chosen].astype(np.int64),
            "source_ids": metadata.index.to_numpy(dtype=str)[chosen], "coords_um": xy[chosen],
            "focal_ids": focal_ids,
            "summary": {"sample_id": sample, "source_scope": scope,
                        "qc_columns": qc_columns, "n_metadata_rows": len(metadata),
                        "n_failed_saved_qc": int((~qc_mask).sum()),
                        "n_invalid_nonfocal_coordinates": int((qc_mask & ~finite).sum()),
                        "coordinate_columns": list(pair), "coordinate_units": "micrometres",
                        "n_other_raw_rows": int(raw.shape[0] - len(metadata)),
                        "unknown_lineage_labels_excluded": False}}


def select_features(counts, genes, full_library_sizes, *, n_top_genes=3000,
                    heldout_genes=HELDOUT_GENES, min_detected_cells=20,
                    target_sum=10000.0, n_mean_bins=20, block_rows=20000):
    """HVG-style mean-binned dispersion with a fixed nonheldout reference.

    Means and variances use original counts scaled by full-source library size.
    Bin boundaries, dispersion calibration and the top-N cutoff use NONreserved
    genes only. Reserved genes may enter the main arm only if independently
    above that frozen cutoff; the heldout arm never uses their values in feature
    selection. No marker is forced into the embedding.
    """
    for value, name in ((n_top_genes, "n_top_genes"), (min_detected_cells, "min_detected_cells"),
                        (n_mean_bins, "n_mean_bins"), (block_rows, "block_rows")):
        if isinstance(value, bool) or int(value) != value or value < 1:
            raise ValueError(f"{name} must be a positive integer.")
    if not np.isfinite(target_sum) or target_sum <= 0:
        raise ValueError("target_sum must be finite and positive.")
    genes = _strings(genes, "baseline gene symbols", unique=True)
    full = np.asarray(full_library_sizes, dtype=np.float64)
    if counts.shape[1] != len(genes) or full.shape != (counts.shape[0],) or not np.isfinite(full).all() or (full <= 0).any():
        raise ValueError("Feature-selection gene/cell axes or full-source library sizes are invalid.")
    count = counts.shape[0]
    if count < 2:
        raise ValueError("Feature selection requires at least two focal cells.")
    sums = np.zeros(len(genes), dtype=np.float64)
    squares = np.zeros_like(sums)
    detected = np.zeros(len(genes), dtype=np.int64)
    for left in range(0, count, int(block_rows)):
        right = min(left + int(block_rows), count)
        block = counts[left:right].astype(np.float64).tocsr()
        block.sum_duplicates()
        block.eliminate_zeros()
        detected += np.bincount(block.indices, minlength=len(genes))
        block.data *= np.repeat(float(target_sum) / full[left:right], np.diff(block.indptr))
        sums += np.asarray(block.sum(axis=0)).ravel()
        block.data **= 2
        squares += np.asarray(block.sum(axis=0)).ravel()
    means = sums / count
    variances = np.maximum(0.0, (squares - sums * sums / count) / (count - 1))
    eligible = (detected >= int(min_detected_cells)) & (means > 0) & (variances > 1e-12)
    reserved = np.isin(genes, np.asarray(list(heldout_genes), dtype=str))
    reference = np.flatnonzero(eligible & ~reserved)
    if len(reference) < 3:
        raise ValueError("Fewer than three eligible nonheldout genes; inspect source counts and detection threshold.")
    log_means = np.log1p(means)
    log_dispersion = np.full(len(genes), np.nan)
    log_dispersion[eligible] = np.log(variances[eligible] / means[eligible])
    # Quantile bins avoid bins made almost empty by very abundant housekeeping
    # genes. With few reference genes, use fewer bins (at least 4 genes/bin).
    n_bins = min(int(n_mean_bins), max(1, len(reference) // 4))
    boundaries = np.unique(np.quantile(log_means[reference], np.linspace(0, 1, n_bins + 1)[1:-1]))
    bins = np.searchsorted(boundaries, log_means, side="right")
    scores = np.full(len(genes), np.nan)
    calibration = []
    global_sd = float(np.std(log_dispersion[reference], ddof=1))
    global_sd = max(global_sd, 1e-8)
    for index in range(len(boundaries) + 1):
        members = reference[bins[reference] == index]
        if not len(members):
            # Repeated means can leave a bin empty; fixed nearest reference
            # values calibrate it without consulting heldout values.
            center = boundaries[min(index, len(boundaries) - 1)] if len(boundaries) else np.median(log_means[reference])
            members = reference[np.argsort(abs(log_means[reference] - center), kind="stable")[:min(4, len(reference))]]
        mean = float(np.mean(log_dispersion[members]))
        sd = float(np.std(log_dispersion[members], ddof=1)) if len(members) > 1 else global_sd
        sd = max(sd, global_sd * 0.05, 1e-8)
        use = eligible & (bins == index)
        scores[use] = (log_dispersion[use] - mean) / sd
        calibration.append({"mean_bin": index, "reference_genes": int(len(members)), "log_dispersion_mean": mean, "log_dispersion_sd": sd})
    # Symbol tie breaking makes selection deterministic under stable statistics.
    ranked = reference[np.lexsort((genes[reference], -scores[reference]))]
    selected_reference = ranked[:min(int(n_top_genes), len(ranked))]
    threshold = float(scores[selected_reference[-1]])
    selected_reserved = np.flatnonzero(eligible & reserved & (scores >= threshold))
    # Keep source gene order throughout sparse sources and both paired arms.
    selected_mask = np.zeros(len(genes), dtype=bool)
    selected_mask[selected_reference] = True
    selected_mask[selected_reserved] = True
    selected = np.flatnonzero(selected_mask)
    rank = np.full(len(genes), np.nan)
    rank[ranked] = np.arange(1, len(ranked) + 1)
    audit = pd.DataFrame({"gene": genes, "detected_cells": detected,
                          "mean_normalized_counts": means, "variance_normalized_counts": variances,
                          "mean_bin": bins, "dispersion_score": scores,
                          "reference_rank": rank, "eligible": eligible, "heldout_reserved": reserved,
                          "main_selected": selected_mask, "heldout_selected": selected_mask & ~reserved})
    audit["selection_reason"] = np.where(~eligible, "below_detection_or_zero_variance",
        np.where(selected_mask & reserved, "reserved_independently_meets_frozen_cutoff",
        np.where(selected_mask, "top_nonreserved_dispersion", "below_frozen_cutoff")))
    info = {"feature_selection": "mean-binned dispersion of full-library normalized original counts",
            "reference_feature_count": int(len(selected_reference)), "main_feature_count": int(len(selected)),
            "heldout_feature_count": int(len(selected_reference)), "frozen_score_cutoff": threshold,
            "reserved_genes": list(map(str, heldout_genes)),
            "reserved_selected_in_main": genes[selected_reserved].tolist(),
            "reserved_unavailable": [g for g in heldout_genes if g not in set(genes)],
            "mean_bin_boundaries": boundaries.tolist(), "bin_calibration": calibration,
            "manual_gene_boosts": False, "ratio_weighting": False,
            "heldout_values_used_in_reference_feature_selection": False}
    return selected, audit, info


def _save_array(path, values):
    path = Path(path)
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("wb") as handle:
        np.save(handle, values, allow_pickle=False)
    temporary.replace(path)


def _save_sparse(path, matrix):
    path = Path(path)
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("wb") as handle:
        sp.save_npz(handle, matrix, compressed=False)
    temporary.replace(path)


def _validate_count_block(matrix):
    matrix = matrix.tocsr()
    matrix.sum_duplicates()
    matrix.eliminate_zeros()
    data = matrix.data
    if (not np.isfinite(data).all() or np.any(data < 0)
            or not np.equal(data, np.rint(data)).all()):
        raise ValueError("Original full-tissue input is not finite nonnegative integer counts.")
    totals = np.asarray(matrix.sum(axis=1, dtype=np.float64)).ravel()
    if np.any(totals > 2 ** 53) or (data.size and np.max(data) > 2 ** 24):
        raise OverflowError("Original count values exceed supported exact audit/float32 precision.")
    return matrix, totals


def _sample_cache(row, focal_obs, focal_counts, feature_genes, global_rows, destination,
                  *, target_sum, block_rows, source_signatures, source_id, resume):
    destination = Path(destination)
    done_path = destination / "sample_manifest.json"
    if resume and done_path.is_file():
        saved = json.loads(done_path.read_text())
        if saved.get("source_id") == source_id and all((destination / key).is_file() and (destination / key).stat().st_size == size for key, size in saved.get("files", {}).items()) and saved.get("files"):
            print(f"  Reusing spatial source {row['sample']}: {saved['n_tissue_cells']:,} tissue cells", flush=True)
            return saved
    destination.mkdir(parents=True, exist_ok=True)
    done_path.unlink(missing_ok=True)
    _check_signatures(source_signatures)
    with RawReader(row["raw_h5ad"], row["matrix_key"]) as raw:
        context = load_spatial_context(row, raw, focal_obs)
        symbols = _symbols(row, raw)
        gene_index = pd.Index(feature_genes)
        mapped = gene_index.get_indexer(symbols)
        include = mapped >= 0
        measured = set(symbols)
        absent = [gene for gene in feature_genes if gene not in measured]
        if absent:
            raise ValueError(f"{row['sample']}: selected common genes are missing from original source: {absent[:20]}.")
        mapper = sp.csr_matrix((np.ones(int(include.sum()), dtype=np.float32),
                               (np.flatnonzero(include), mapped[include])),
                              shape=(raw.shape[1], len(feature_genes)))
        source_rows = context["source_rows"]
        source_ids = context["source_ids"]
        expected_total = focal_obs["total_counts"].to_numpy(dtype=np.float64)
        focal_lookup = pd.Index(context["focal_ids"])
        chunks, kept_positions, positive_totals = [], [], []
        audited_focal = np.zeros(len(focal_obs), dtype=bool)
        step = int(block_rows)
        if raw.kind == "dense":
            step = min(step, max(1, 8_000_000 // raw.shape[1]))
        n_zero = 0
        # Read each original count window once. Full library totals are measured
        # BEFORE selecting genes and BEFORE summing duplicate gene symbols.
        windows = source_rows // step
        boundaries = np.r_[0, np.flatnonzero(np.diff(windows)) + 1, len(source_rows)]
        for start, stop in zip(boundaries[:-1], boundaries[1:]):
            left = int(windows[start] * step)
            right = min(left + step, raw.shape[0])
            block, totals_all = _validate_count_block(raw.block(left, right))
            selected_rows = source_rows[start:stop] - left
            totals = totals_all[selected_rows]
            selected_counts = (block[selected_rows].astype(np.float32) @ mapper).tocsr()
            selected_counts.sum_duplicates()
            selected_counts.eliminate_zeros()
            focal_positions = focal_lookup.get_indexer(source_ids[start:stop])
            focal_mask = focal_positions >= 0
            if focal_mask.any():
                positions = focal_positions[focal_mask]
                if not np.array_equal(totals[focal_mask], expected_total[positions]):
                    raise ValueError(f"{row['sample']}: full original library totals differ from saved 08O focal totals.")
                mismatch = selected_counts[focal_mask] - focal_counts[positions]
                mismatch.eliminate_zeros()
                if mismatch.nnz:
                    raise ValueError(f"{row['sample']}: selected original focal gene counts differ from completed 08O. A different source/feature mapping cannot be substituted.")
                audited_focal[positions] = True
            positive = totals > 0
            if not positive[focal_mask].all():
                raise ValueError(f"{row['sample']}: an original focal T cell has zero source library.")
            n_zero += int((~positive).sum())
            if positive.any():
                chunks.append(base.log_normalize(selected_counts[positive], totals[positive], target_sum))
                kept_positions.append(np.arange(start, stop, dtype=np.int64)[positive])
                positive_totals.append(totals[positive])
        if not audited_focal.all():
            raise RuntimeError(f"{row['sample']}: not every original T cell was audited against source counts.")
        if not chunks:
            raise ValueError(f"{row['sample']}: no positive-library source cells remain for physical neighborhoods.")
        kept = np.concatenate(kept_positions)
        matrix = sp.vstack(chunks, format="csr", dtype=np.float32)
        del chunks
        tissue_ids = source_ids[kept]
        focal_local_rows = pd.Index(tissue_ids).get_indexer(context["focal_ids"])
        if (focal_local_rows < 0).any() or len(np.unique(focal_local_rows)) != len(focal_obs):
            raise RuntimeError(f"{row['sample']}: lost or duplicated a focal row while building the tissue cache.")
        # Own focal expression comes from immutable 08O counts. Exact source
        # count/library matching above proves that source and focal assays agree.
        _save_sparse(destination / "X_tissue.npz", matrix)
        _save_array(destination / "coords_um.npy", context["coords_um"][kept])
        _save_array(destination / "focal_local_rows.npy", focal_local_rows.astype(np.int64))
        _save_array(destination / "focal_global_rows.npy", np.asarray(global_rows, dtype=np.int64))
        _save_array(destination / "source_rows.npy", source_rows[kept])
        pd.DataFrame({"source_cell_id": tissue_ids, "full_library_size": np.concatenate(positive_totals)}).to_csv(destination / "tissue_cells.csv.gz", index=False)
        files = ["X_tissue.npz", "coords_um.npy", "focal_local_rows.npy", "focal_global_rows.npy", "source_rows.npy", "tissue_cells.csv.gz"]
        result = {"version": VERSION, "source_id": source_id, "sample_id": row["sample"],
                  "condition": row["condition"], "n_tissue_cells": matrix.shape[0],
                  "n_focal_cells": len(focal_obs), "n_features": len(feature_genes),
                  "x_tissue_path": str(destination / "X_tissue.npz"),
                  "coords_path": str(destination / "coords_um.npy"),
                  "focal_local_rows_path": str(destination / "focal_local_rows.npy"),
                  "focal_global_rows_path": str(destination / "focal_global_rows.npy"),
                  "focal_source_cell_order_hash": base.ordered_id_hash(context["focal_ids"]),
                  "tissue_cell_order_hash": base.ordered_id_hash(tissue_ids),
                  "gene_order_hash": base.ordered_id_hash(feature_genes),
                  "n_zero_library_nonfocal_excluded": n_zero,
                  "csr_bytes": int(matrix.data.nbytes + matrix.indices.nbytes + matrix.indptr.nbytes),
                  "files": {name: (destination / name).stat().st_size for name in files},
                  **context["summary"]}
    _check_signatures(source_signatures)
    base.save_json(done_path, result)
    print(f"  Prepared {row['sample']}: {result['n_tissue_cells']:,} tissue cells, {result['n_focal_cells']:,} original T cells; {result['source_scope']}", flush=True)
    return result


def _complete_cache(cache, identity):
    path = Path(cache) / "cache_manifest.json"
    if not path.is_file():
        return None
    info = json.loads(path.read_text())
    if info.get("cache_id") != identity or not info.get("files"):
        return None
    for name, size in info["files"].items():
        if not (Path(cache) / name).is_file() or (Path(cache) / name).stat().st_size != size:
            return None
    for sample in info["samples"]:
        folder = Path(sample["x_tissue_path"]).parent
        if not (folder / "sample_manifest.json").is_file():
            return None
        for name, size in sample["files"].items():
            if not (folder / name).is_file() or (folder / name).stat().st_size != size:
                return None
    return info


def prepare_sources(inputs, marker_genes, *, output_root=None, n_top_genes=3000,
                    heldout_genes=HELDOUT_GENES, min_detected_cells=20,
                    target_sum=10000.0, block_rows=20000, resume=True):
    """Build resumable per-sample tissue sources and frozen all-T focal assays.

    Returns ``(cache_dir, manifest)``. ``manifest['samples']`` has paths to
    X_tissue CSR, micron coordinates, and local/global focal row maps. The global
    ``lognorm_features.npz`` contains original 08O focal expression in exactly
    ``obs.csv.gz`` row order; main and heldout feature masks share its columns.
    """
    base._unchanged(inputs)
    sources, provenance = discover_sources(inputs)
    markers = list(dict.fromkeys(map(str, marker_genes)))
    heldout = list(dict.fromkeys(map(str, heldout_genes)))
    spec = {"version": VERSION, "baseline_sources": inputs["source_signatures"],
            "full_tissue_sources": provenance["source_signatures"],
            "source_manifest": sources.to_dict("records"), "n_top_genes": int(n_top_genes),
            "min_detected_cells": int(min_detected_cells), "target_sum": float(target_sum),
            "heldout_genes": heldout, "marker_genes": markers,
            "normalization": "log1p(target_sum * count / full original source library)",
            "feature_selection_policy": "fixed nonheldout reference plus independently qualifying reserved genes"}
    identity = base._digest(spec)
    root = Path(output_root or inputs["output_root"]).expanduser().resolve()
    cache = root / identity[:20] / "cache"
    existing = _complete_cache(cache, identity) if resume else None
    if existing:
        _check_signatures(provenance["source_signatures"])
        print(f"Reusing complete 08U source cache: {cache}", flush=True)
        return cache, existing
    cache.mkdir(parents=True, exist_ok=True)
    (cache / "cache_manifest.json").unlink(missing_ok=True)
    started = time.perf_counter()
    counts, genes, obs = base.load_original_counts(inputs)
    if "source_cell_id" not in obs:
        raise ValueError("Completed 08O lacks original cell_id metadata; physical source joins require exact source IDs.")
    if set(sources["sample"]) != set(obs["sample_id"].astype(str)):
        raise ValueError("Original full-tissue source manifest and completed 08O T-cell sample sets differ.")
    for row in sources.to_dict("records"):
        part = obs.loc[obs["sample_id"].astype(str).eq(row["sample"])]
        if not part["condition"].astype(str).eq(row["condition"]).all():
            raise ValueError(f"{row['sample']}: original source and 08O condition metadata differ.")
    chosen, audit, feature_info = select_features(counts, genes, obs["total_counts"].to_numpy(),
        n_top_genes=n_top_genes, heldout_genes=heldout, min_detected_cells=min_detected_cells,
        target_sum=target_sum, block_rows=block_rows)
    feature_genes = genes[chosen]
    features = audit.iloc[chosen].reset_index(drop=True)
    features["feature_column"] = np.arange(len(features))
    features["main_use"] = True
    features["heldout_use"] = ~features["heldout_reserved"]
    features.to_csv(cache / "features.csv", index=False)
    audit.to_csv(cache / "feature_audit_all_genes.csv", index=False)
    positions = pd.Index(genes).get_indexer(markers)
    available = positions >= 0
    marker_positions = positions[available]
    observed_markers = np.asarray(markers, dtype=str)[available].tolist()
    marker_counts = counts[:, marker_positions].tocsr()
    marker_log = base.log_normalize(marker_counts, obs["total_counts"].to_numpy(), target_sum)
    _save_sparse(cache / "marker_counts.npz", marker_counts)
    _save_sparse(cache / "marker_log1p.npz", marker_log)
    pd.DataFrame({"gene": observed_markers}).to_csv(cache / "marker_genes.csv", index=False)
    pd.DataFrame({"gene": markers, "available_in_original_counts": available}).to_csv(cache / "marker_availability.csv", index=False)
    focal_counts = counts[:, chosen].tocsr()
    focal_log = base.log_normalize(focal_counts, obs["total_counts"].to_numpy(), target_sum)
    _save_sparse(cache / "lognorm_features.npz", focal_log)
    obs = obs.copy()
    obs["eligible_feature_counts"] = np.asarray(focal_counts.sum(axis=1, dtype=np.float64)).ravel()
    obs["no_observed_eligible_feature"] = obs["eligible_feature_counts"].eq(0)
    heldout_mask = features["heldout_use"].to_numpy(dtype=bool)
    obs["no_observed_heldout_feature"] = np.asarray(focal_counts[:, heldout_mask].sum(axis=1)).ravel() == 0
    obs.to_csv(cache / "obs.csv.gz", index=True)
    del counts, marker_counts, marker_log, focal_log
    gc.collect()
    samples = []
    for sample_number, row in enumerate(sources.to_dict("records")):
        global_rows = np.flatnonzero(obs["sample_id"].astype(str).to_numpy() == row["sample"])
        slug = re.sub(r"[^A-Za-z0-9_.-]+", "_", row["sample"]).strip(".") or "sample"
        destination = cache / "samples" / f"{sample_number:02d}_{slug}"
        source_id = base._digest({"cache_id": identity, "sample": row,
                                  "focal_cell_order": base.ordered_id_hash(obs.index[global_rows]),
                                  "gene_order": base.ordered_id_hash(feature_genes)})
        sample = _sample_cache(row, obs.iloc[global_rows], focal_counts[global_rows],
                              feature_genes, global_rows, destination,
                              target_sum=target_sum, block_rows=block_rows,
                              source_signatures=provenance["source_signatures"],
                              source_id=source_id, resume=resume)
        samples.append(sample)
        gc.collect()
    # Sample row maps must be a disjoint exact partition, including original
    # baseline order that is interleaved or differs from manifest sample order.
    mapped = np.concatenate([np.load(item["focal_global_rows_path"]) for item in samples])
    if not np.array_equal(np.sort(mapped), np.arange(len(obs))):
        raise RuntimeError("Sample focal row maps do not form an exact partition of original 08O cells.")
    sources.to_csv(cache / "source_manifest.csv", index=False)
    base.save_json(cache / "source_inputs.json", inputs)
    base.save_json(cache / "source_provenance.json", provenance)
    base.save_json(cache / "preparation_settings.json", spec)
    base.save_json(cache / "feature_selection.json", feature_info)
    pd.DataFrame([{k: s[k] for k in ("sample_id", "condition", "n_tissue_cells", "n_focal_cells", "source_scope", "n_zero_library_nonfocal_excluded", "n_invalid_nonfocal_coordinates")} for s in samples]).to_csv(cache / "spatial_source_audit.csv", index=False)
    files = ["features.csv", "feature_audit_all_genes.csv", "marker_counts.npz", "marker_log1p.npz",
             "marker_genes.csv", "marker_availability.csv", "lognorm_features.npz", "obs.csv.gz",
             "source_manifest.csv", "source_inputs.json", "source_provenance.json", "preparation_settings.json",
             "feature_selection.json", "spatial_source_audit.csv"]
    info = {"version": VERSION, "cache_id": identity, "data_identity": identity,
            "cache_dir": str(cache), "n_cells": len(obs), "n_source_genes": len(genes),
            "n_features": len(chosen), "shape": [len(obs), len(chosen)],
            "n_samples": len(samples), "n_conditions": int(obs["condition"].nunique()),
            "n_tissue_cells": sum(s["n_tissue_cells"] for s in samples),
            "main_feature_indices": np.arange(len(chosen)).tolist(),
            "heldout_feature_indices": np.flatnonzero(heldout_mask).tolist(),
            "genes": feature_genes.tolist(), "heldout_genes": heldout,
            "samples": samples, "sample_key": "sample_id", "condition_key": "condition",
            "focal_own_path": str(cache / "lognorm_features.npz"),
            "obs_path": str(cache / "obs.csv.gz"), "features_path": str(cache / "features.csv"),
            "cell_order_hash": base.ordered_id_hash(obs.index),
            "gene_order_hash": base.ordered_id_hash(feature_genes),
            "cell_order_sha256": _newline_hash(obs.index),
            "feature_gene_order_sha256": _newline_hash(feature_genes),
            "sha256_hash_encoding": "sha256(UTF-8 newline-joined strings)",
            "legacy_order_hash_encoding": "sha256(8-byte little-endian length-prefixed UTF-8 strings)",
            "all_08O_cells_retained": True, "original_counts_modified": False,
            "normalization_denominator": "all original source features, including genes not selected for BANKSY",
            "zero_feature_cells": int(obs["no_observed_eligible_feature"].sum()),
            "heldout_zero_feature_cells": int(obs["no_observed_heldout_feature"].sum()),
            "missing_marker_genes": np.asarray(markers, dtype=str)[~available].tolist(),
            "feature_selection": feature_info, "preparation_seconds": time.perf_counter() - started,
            "files": {name: (cache / name).stat().st_size for name in files}}
    base._unchanged(inputs)
    _check_signatures(provenance["source_signatures"])
    base.save_json(cache / "cache_manifest.json", info)
    print(f"Prepared 08U: {len(obs):,} original T cells; {info['n_tissue_cells']:,} source-defined tissue cells; {len(chosen):,} main and {heldout_mask.sum():,} heldout features.", flush=True)
    return cache, info


def load_review_data(cache_dir):
    """Original marker log expression, counts, gene names and frozen focal obs."""
    cache = Path(cache_dir)
    obs = pd.read_csv(cache / "obs.csv.gz", dtype={key: str for key in
        ("cell_id", "source_cell_id", "sample_id", "condition", "population", "unit")},
        keep_default_na=False).set_index("cell_id")
    genes = pd.read_csv(cache / "marker_genes.csv", dtype=str)["gene"].tolist()
    counts = sp.load_npz(cache / "marker_counts.npz").tocsr()
    log_expr = sp.load_npz(cache / "marker_log1p.npz").tocsr()
    if counts.shape != log_expr.shape or counts.shape != (len(obs), len(genes)) or not obs.index.is_unique:
        raise ValueError("Original marker assay dimensions/cell IDs disagree.")
    manifest = json.loads((cache / "cache_manifest.json").read_text())
    if base.ordered_id_hash(obs.index) != manifest["cell_order_hash"]:
        raise ValueError("Original marker metadata has changed order after preparation.")
    return log_expr, counts, genes, obs


# Alias follows the 08T helper's spelling for a drop-in notebook review cell.
load_marker_data = load_review_data
