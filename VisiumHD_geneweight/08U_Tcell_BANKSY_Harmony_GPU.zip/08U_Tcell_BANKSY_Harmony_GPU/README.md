# 08U — BANKSY context, GPU PCA and GPU Harmony

Project: **Adagrasib_mouse_project_VisiumHD_2026**  
Release: **1.0.0**

## Run

Put `08U_Tcell_BANKSY_Harmony_GPU.ipynb` beside the working 08T notebook or in the original project folder. Select the UV/RAPIDS kernel where Python BANKSY is installed, then choose **Run All**. Only change `PROJECT_DIR` if automatic discovery cannot find the original project. The notebook embeds every helper; this ZIP is optional and provides readable source.

No H5AD choice is needed. The completed 08O pointer fixes the original T cell 1 + T cell 2 population. The preserved extraction manifest identifies original full-tissue expression, spatial coordinates, feature mappings and annotations. New results go to `20_tcell_banksy_harmony`. Previous notebooks, original counts and global lineage annotations are not overwritten.

## Matched experiment

| Arm | Lambda | Companion exclusion |
|---|---:|---|
| `banksy_lam0` | 0 | None |
| `banksy_lam02` | 0.2 | None |
| `heldout_lam0` | 0 | Cd8b1, Il2ra, Ctla4, Ikzf2, Tnfrsf18 |
| `heldout_lam02` | 0.2 | Same five genes |

Every arm retains every original T cell. Physical neighborhoods use all retained tissue cells of the same sample, including unknown labels. Explicit original QC flags are applied if available; otherwise the source-defined scope and unavailable independent QC mask are recorded. Invalid focal IDs/counts/coordinates are rejected rather than guessed or silently removed.

Up to 3,000 eligible nonreserved genes are selected by mean-binned dispersion. Reserved genes enter the main pair only if they independently meet the same frozen cutoff. No marker is forced into the input; no ratio or handpicked positive weights are applied. Original counts are normalized by the full source library to 10,000 and log1p transformed. The validation pair retains that full-library denominator.

BANKSY uses own expression, a 15-neighbor mean and a centered 30-neighbor m=1 gradient. Each block is standardized gene by gene over the full focal T population. At lambda 0.2, the squared block coefficients are 0.8, 0.1333 and 0.0667. These feature weights are not estimated transcript-origin fractions. Both members of a pair use the same scaling and gene set.

The workflow uses up to 50 PCs, GPU Harmony by sample, 30 expression neighbors, Leiden 0.2/0.4/0.6 and GPU UMAP. Four visible GPUs can run four independent arms; one visible GPU runs them sequentially. Physical geometry is computed on CPU; neighborhood matrix products, streamed PCA and downstream clustering use the GPU.

## Memory and time

The notebook uses a chunked BANKSY-compatible implementation rather than the standard high-level wrapper. It validates graph weights, mean features, centered gradients and standardized concatenation against the installed package on synthetic data at startup. In pybanksy 1.3.5 the high-level wrapper has a positional-argument ambiguity; this workflow explicitly uses `create_nbr_matrix(center=True, variance_balance=False)`.

The full concatenated BANKSY matrix is never placed on the GPU. Spatial features are float32 per-sample arrays on disk; PCA streams row chunks and keeps thin GPU workspaces. At approximately 590,000 cells and 3,000 genes, the two spatial arrays alone are about **13.2 GiB**. Source caches, outputs and temporary workspace require additional disk and memory. The notebook prints estimates from the actual input dimensions and available output disk space.

The clustering stage has a 110-minute cap and saves compatible PCA/Harmony/graph checkpoints. Source preparation, spatial calculations and plotting are additional time. There is no measured full-dataset runtime guarantee. All stages reuse compatible completed work on rerun. The code never silently substitutes a CPU production workflow when GPU startup fails.

## Results

Open the final `review.html` link. Return the compact **`08U_return_to_chat.zip`**, capped at 25 MB. It contains aggregate reviews, diagnostics, feature audits and prioritized plots, excluding full expression matrices and large H5AD files. An omission manifest records any files left out to meet the cap.

Reports include lineage dotplots at all three resolutions for the main pair; state and environmental markers; sample/condition/depth reviews; original expression by condition; Foxp3/Ccr8 0/1/2+ count views; selected-feature information support; and sample/depth-adjusted held-out companion-neighbor comparisons. Every marker statistic uses original expression, not BANKSY features. Only display points may be subsampled.

Interpret the lambda comparison within each pair. Improved UMAP separation alone is insufficient: examine original CD4/CD8/Treg companion coherence, condition consistency, depth, low-information cells and environmental markers. The notebook does not assign cell types or claim decontamination. Prior 08T results remain a separate reference and are not recomputed.

## Validation and limitations

The delivered package includes `VALIDATION.json` with the actual checks run during preparation. Tests use real synthetic H5AD/Parquet sources and the installed official Python BANKSY functions. A CPU protocol adapter exercises notebook orchestration and report generation; it is confined to QA and is not shipped as a production fallback. CUDA execution and biological performance on the user's full dataset must be established by the notebook's on-instance preflight and run.

References:

- BANKSY paper: https://doi.org/10.1038/s41588-024-01664-3
- Official Python source: https://github.com/prabhakarlab/Banksy_py
- Official documentation: https://prabhakarlab.github.io/Banksy/
- GPU Harmony API: https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.harmony_integrate.html
