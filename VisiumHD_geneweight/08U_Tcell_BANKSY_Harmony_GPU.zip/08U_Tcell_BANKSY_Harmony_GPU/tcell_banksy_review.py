"""Original-expression review and compact reports for the 08U BANKSY test.

The four arms are two matched lambda comparisons. This module does not infer
cell types or modify counts. BANKSY provenance is audited directly from the
completed operator manifests; the older positive-weight audit is not used.
"""
from __future__ import annotations

from collections import OrderedDict
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping
import hashlib
import html
import importlib.metadata
import json
import os
import platform
import sys
import time
import traceback
import zipfile

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_review as marker_review
import tcell_positive_review as companion_review


MAIN_METHODS = ("banksy_lam0", "banksy_lam02")
HELDOUT_METHODS = ("heldout_lam0", "heldout_lam02")
METHOD_NAMES = MAIN_METHODS + HELDOUT_METHODS
HELDOUT_GENES = companion_review.DEFAULT_HELDOUT_GENES
GUIDE_PAIRS = companion_review.DEFAULT_GUIDE_PAIRS
DISPLAY_NAMES = {
    "banksy_lam0": "BANKSY lambda 0",
    "banksy_lam02": "BANKSY lambda 0.2",
    "heldout_lam0": "Companions held out; lambda 0",
    "heldout_lam02": "Companions held out; lambda 0.2",
}
BLOCK_NAMES = ("own", "mean", "gradient")
REVIEW_NOTES = [
    "Every marker measurement is an original observed count or its original full-library-normalized log1p expression. BANKSY features are not corrected counts.",
    "Compare lambda 0 against lambda 0.2 within each matched pair. The main and held-out pairs use different feature universes.",
    "The diagnostic excludes its reserved companion genes from the cell's own expression, neighborhood means, and neighborhood gradients. Their original assays remain available for evaluation.",
    "Original full-library normalization totals and QC metadata stay unchanged when companions are held out. Holding out feature columns is not an independent experiment on newly measured cells.",
    "A guide is observed Cd8a or Foxp3 transcript detection, not an independently established cell-type label. Observed-negative cells can include cells whose transcripts were not captured.",
    "Neighbor statistics exclude self-edges. Expected companion detection uses each neighbor's sample and within-sample depth quintile. Guide-positive versus guide-negative contrasts also use focal sample/depth strata.",
    "Only strata eligible in both graphs are compared; strata are averaged within samples and contributing samples receive equal weight. This is coarse depth adjustment, not exact matching.",
    "A positive held-out contrast describes stronger companion support around guide-positive cells. It is not accuracy, significance, independent CD4 validation, or proof of decontamination.",
    "Spatial continuity can reflect shared microenvironment. Read multi-gene support, sample/depth dependence, environmental markers, and original transcript counts together.",
    "The guide/companion panel follows earlier exploration of these data. This is an exploratory validation check rather than a blinded external benchmark.",
]


def _clean(value):
    if isinstance(value, Mapping):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return _clean(value.tolist())
    if isinstance(value, np.generic):
        return _clean(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def _json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_clean(value), indent=2, allow_nan=False), encoding="utf-8")
    return path


def _manifest(value):
    if isinstance(value, Mapping):
        return _clean(value)
    if isinstance(value, (str, Path)):
        text = str(value)
        if text.lstrip().startswith("{"):
            return _manifest(json.loads(text))
        return _manifest(json.loads(Path(value).read_text(encoding="utf-8")))
    raise TypeError("Each BANKSY feature manifest must be a mapping, JSON string, or JSON path.")


def _canonical(value):
    return json.dumps(_clean(value), sort_keys=True, separators=(",", ":"), allow_nan=False)


def _completed_manifest(method):
    uns = getattr(method, "uns", None)
    if uns is None and isinstance(method, Mapping):
        uns = method.get("uns", {})
    if not isinstance(uns, Mapping):
        raise ValueError("Completed BANKSY results need an uns mapping with their actual operator manifest.")
    for key in ("banksy_manifest", "banksy_manifest_json"):
        if key in uns:
            return _manifest(uns[key])
    raise ValueError("Completed result has no banksy_manifest; feature exclusion cannot be verified.")


def _symbols(values, field):
    if isinstance(values, str) or values is None:
        raise ValueError(f"{field} must be an ordered sequence of gene symbols.")
    values = [str(v) for v in values]
    if len(set(values)) != len(values) or any(not v or v in ("None", "nan") for v in values):
        raise ValueError(f"{field} contains duplicate or empty symbols.")
    return values


def audit_feature_manifests(methods, feature_manifests, obs, *, heldout_genes=HELDOUT_GENES,
                            output_dir=None):
    """Check completed BANKSY features, exact cell order, and matched-pair inputs.

    Input tables listing weights are deliberately unsupported. The manifest must
    describe the actual operator blocks and must match the manifest stored with
    the completed embedding. Inactive spatial blocks at lambda zero are recorded
    as inactive, rather than claimed to have been evaluated.
    """
    if not isinstance(obs, pd.DataFrame) or not obs.index.is_unique:
        raise ValueError("Original obs needs unique ordered cell IDs.")
    if not methods or set(methods) != set(feature_manifests):
        raise ValueError("Provide exactly one actual feature manifest for each reviewed method.")
    unknown = set(methods).difference(METHOD_NAMES)
    if unknown:
        raise ValueError(f"Unexpected BANKSY method names: {sorted(unknown)}")
    checked, feature_rows, heldout_rows, pair_rows = OrderedDict(), [], [], []
    heldout_genes = tuple(dict.fromkeys(map(str, heldout_genes)))
    for name, method in methods.items():
        frame = method.obs if hasattr(method, "obs") else method["obs"]
        if not isinstance(frame, pd.DataFrame) or not frame.index.equals(obs.index):
            raise ValueError(f"Exact original cell IDs/order differ for {name}.")
        manifest = _manifest(feature_manifests[name])
        completed = _completed_manifest(method)
        if _canonical(completed) != _canonical(manifest):
            raise ValueError(f"Supplied feature manifest disagrees with the completed embedding for {name}.")
        required = ("lambda", "feature_gene_names", "blocks", "input_gene_order_sha256",
                    "cell_order_sha256", "cell_order_hash_kind", "n_cells", "n_features", "feature_scaling",
                    "marker_boost", "ratio_weighting")
        missing = [key for key in required if key not in manifest]
        if missing:
            raise ValueError(f"Incomplete actual feature manifest for {name}: {missing}")
        if int(manifest["n_cells"]) != len(obs):
            raise ValueError(f"Feature-manifest cell count differs for {name}.")
        for key in ("input_gene_order_sha256", "cell_order_sha256"):
            digest = str(manifest[key])
            if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise ValueError(f"Missing or invalid {key} for {name}.")
        ids = [str(value) for value in obs.index]
        if any("\n" in value for value in ids) or manifest["cell_order_hash_kind"] != "cell_ids":
            raise ValueError("Feature provenance must hash the actual newline-free cell IDs, not row positions.")
        expected_cell_hash = hashlib.sha256("\n".join(ids).encode("utf-8")).hexdigest()
        if manifest["cell_order_sha256"] != expected_cell_hash:
            raise ValueError(f"Completed BANKSY cell-order hash does not match the original marker cells for {name}.")
        expected_lambda = 0.2 if name.endswith("lam02") else 0.0
        if not np.isclose(float(manifest["lambda"]), expected_lambda, rtol=0, atol=1e-12):
            raise ValueError(f"Wrong lambda in the completed {name} feature manifest.")
        if manifest["marker_boost"] is not False or manifest["ratio_weighting"] is not False:
            raise ValueError("08U matched BANKSY arms must not contain marker boosts or ratio weighting.")
        genes = _symbols(manifest["feature_gene_names"], f"{name}.feature_gene_names")
        if not genes:
            raise ValueError(f"No actual feature genes for {name}.")
        blocks = {}
        for block in manifest["blocks"]:
            if not isinstance(block, Mapping) or block.get("name") not in BLOCK_NAMES:
                raise ValueError(f"Unknown or incomplete BANKSY block for {name}.")
            key = str(block["name"])
            if key in blocks:
                raise ValueError(f"Duplicate {key} block for {name}.")
            coefficient = float(block["coefficient"])
            block_genes = _symbols(block["genes"], f"{name}.{key}.genes")
            if not np.isfinite(coefficient) or coefficient < 0 or not set(block_genes).issubset(genes):
                raise ValueError(f"Invalid active feature list or coefficient in {name}/{key}.")
            blocks[key] = (coefficient, block_genes)
        active = {key for key, (coefficient, _) in blocks.items() if coefficient > 0}
        expected_blocks = {"own"} if expected_lambda == 0 else set(BLOCK_NAMES)
        if active != expected_blocks:
            raise ValueError(f"Expected active blocks {sorted(expected_blocks)} for {name}; got {sorted(active)}.")
        own_variance = blocks["own"][0] ** 2
        spatial_variance = sum(value[0] ** 2 for key, value in blocks.items() if key != "own")
        if not np.isclose(own_variance, 1 - expected_lambda, rtol=1e-6, atol=1e-12) or not np.isclose(spatial_variance, expected_lambda, rtol=1e-6, atol=1e-12):
            raise ValueError(f"Actual block coefficients do not implement the stated lambda for {name}.")
        actual_n_features = sum(len(g) for coefficient, g in blocks.values() if coefficient > 0)
        if int(manifest["n_features"]) != actual_n_features:
            raise ValueError(f"n_features disagrees with the active feature columns for {name}.")
        completed_feature_columns_checked = False
        if "feature_names" in manifest:
            feature_names = _symbols(manifest["feature_names"], f"{name}.feature_names")
            expected_names = [f"{block['name']}::{gene}" for block in manifest["blocks"]
                              if float(block["coefficient"]) > 0 for gene in block["genes"]]
            if feature_names != expected_names:
                raise ValueError(f"Ordered BANKSY feature names disagree with block columns for {name}.")
            var = method.var if hasattr(method, "var") else method.get("var")
            if not isinstance(var, pd.DataFrame) or list(var.index.astype(str)) != feature_names:
                raise ValueError(f"Actual completed embedding feature columns disagree with the manifest for {name}.")
            if "gene" in var and list(var.gene.astype(str)) != [gene for block in manifest["blocks"] if float(block["coefficient"]) > 0 for gene in block["genes"]]:
                raise ValueError(f"Completed embedding gene annotations disagree with the manifest for {name}.")
            completed_feature_columns_checked = True
        for key in BLOCK_NAMES:
            coefficient, block_genes = blocks.get(key, (0.0, []))
            actual = next((block for block in manifest["blocks"] if block["name"] == key), {})
            effective = _symbols(actual.get("effective_genes", block_genes), f"{name}.{key}.effective_genes")
            if not set(effective).issubset(block_genes):
                raise ValueError(f"Effective genes are outside the actual {name}/{key} block columns.")
            for gene in block_genes:
                feature_rows.append({"method": name, "block": key, "gene": gene,
                                     "block_coefficient": coefficient, "active_block": coefficient > 0,
                                     "nonzero_variance": gene in effective})
        if name in HELDOUT_METHODS:
            for gene in heldout_genes:
                if gene in genes:
                    raise ValueError(f"Held-out gene {gene} is still in the actual feature universe for {name}.")
                for key in BLOCK_NAMES:
                    coefficient, block_genes = blocks.get(key, (0.0, []))
                    if gene in block_genes:
                        raise ValueError(f"Held-out gene {gene} leaks into {name}/{key}.")
                    heldout_rows.append({"method": name, "gene": gene, "block": key,
                        "active_block": coefficient > 0, "block_coefficient": coefficient,
                        "present_in_actual_block": False, "present_in_actual_gene_universe": False,
                        "excluded_from_embedding": True, "completed_embedding_manifest_checked": True,
                        "completed_feature_columns_checked": completed_feature_columns_checked,
                        "input_gene_order_sha256": manifest["input_gene_order_sha256"],
                        "cell_order_sha256": manifest["cell_order_sha256"]})
        checked[name] = manifest
    cell_hashes = {m["cell_order_sha256"] for m in checked.values()}
    if len(cell_hashes) != 1:
        raise ValueError("Reviewed methods do not share the same frozen focal-cell order hash.")
    for pair_name, pair in (("main", MAIN_METHODS), ("heldout", HELDOUT_METHODS)):
        if not all(name in checked for name in pair):
            continue
        a, b = (checked[name] for name in pair)
        keys = ("feature_gene_names", "input_gene_order_sha256", "cell_order_sha256",
                "n_cells", "feature_scaling", "k_geom")
        for key in keys:
            if key not in a or key not in b or _canonical(a[key]) != _canonical(b[key]):
                raise ValueError(f"{pair_name} lambda pair has unmatched {key}.")
        for key in ("spatial_context_sha256", "source_manifest_sha256", "source_cache_id",
                    "feature_selection", "normalization_target_sum"):
            if key in a or key in b:
                if key not in a or key not in b or _canonical(a[key]) != _canonical(b[key]):
                    raise ValueError(f"{pair_name} lambda pair has unmatched {key}.")
        own_a = next(x for x in a["blocks"] if x["name"] == "own")
        own_b = next(x for x in b["blocks"] if x["name"] == "own")
        if own_a["genes"] != own_b["genes"]:
            raise ValueError(f"{pair_name} lambda pair does not share its actual own-expression genes.")
        pair_rows.append({"pair": pair_name, "lambda0_method": pair[0], "lambda02_method": pair[1],
                          "same_cell_order": True, "same_input_gene_order": True,
                          "same_selected_genes": True, "same_own_features": True,
                          "same_scaling": True, "n_genes": len(a["feature_gene_names"]),
                          "lambda0_n_features": a["n_features"], "lambda02_n_features": b["n_features"]})
    result = {"actual_features": pd.DataFrame(feature_rows),
              "heldout_exclusion": pd.DataFrame(heldout_rows), "matched_pairs": pd.DataFrame(pair_rows),
              "manifests": checked}
    if output_dir is not None:
        directory = Path(output_dir)
        directory.mkdir(parents=True, exist_ok=True)
        for key, filename in (("actual_features", "actual_feature_blocks.csv.gz"),
                              ("heldout_exclusion", "heldout_exclusion_audit.csv"),
                              ("matched_pairs", "matched_pair_audit.csv")):
            result[key].to_csv(directory / filename, index=False)
        _json(directory / "completed_feature_manifests.json", checked)
    return result


def build_banksy_companion_review(counts, log_expr, gene_names, obs, methods, feature_manifests,
                                  output_dir, *, primary_cluster_key="leiden_0.4",
                                  heldout_genes=HELDOUT_GENES, guide_pairs=GUIDE_PAIRS,
                                  sample_key="sample_id", depth_key="total_counts",
                                  min_cells_per_guide_group=5, normalization_target_sum=10000.0):
    """Reuse the established original-count metrics with a real BANKSY audit."""
    started = time.perf_counter()
    if tuple(methods) != HELDOUT_METHODS:
        raise ValueError(f"Companion review requires the ordered matched pair {HELDOUT_METHODS}.")
    output = Path(output_dir)
    figures = output / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    audited = audit_feature_manifests(methods, feature_manifests, obs,
                                     heldout_genes=heldout_genes, output_dir=output)
    if sample_key not in obs or depth_key not in obs or obs[sample_key].isna().any():
        raise ValueError("Original sample IDs and full-library total counts are required.")
    if isinstance(min_cells_per_guide_group, bool) or int(min_cells_per_guide_group) != min_cells_per_guide_group or min_cells_per_guide_group < 1:
        raise ValueError("min_cells_per_guide_group must be a positive integer.")
    heldout_genes = tuple(dict.fromkeys(map(str, heldout_genes)))
    pairs = tuple(dict.fromkeys((str(g), str(t)) for g, t in guide_pairs if str(t) in heldout_genes))
    if not heldout_genes or not pairs or any(g in heldout_genes for g, _ in pairs):
        raise ValueError("Choose available guide/held-out pairs with no held-out guide.")
    depth = pd.to_numeric(obs[depth_key], errors="raise").to_numpy(dtype=float)
    if not np.isfinite(depth).all() or (depth <= 0).any():
        raise ValueError("Original full-library counts must be finite and positive.")
    samples = obs[sample_key].astype(str).to_numpy()
    requested = tuple(dict.fromkeys(["Cd4", "Cd8a", "Foxp3", *(g for g, _ in pairs), *heldout_genes,
                                     "Cd3d", "Cd3e", "Trbc1", "Trbc2", *companion_review.DOMINANCE_GENES]))
    genes, C, L, B = companion_review._prepare_assays(counts, log_expr, gene_names, len(obs), requested)
    if not genes:
        raise ValueError("None of the requested original marker assays is available.")
    lookup = {g: j for j, g in enumerate(genes)}
    max_error = None
    if normalization_target_sum is not None:
        if not np.isfinite(normalization_target_sum) or normalization_target_sum <= 0:
            raise ValueError("Normalization target must be finite and positive.")
        expected = C.multiply(float(normalization_target_sum) / depth[:, None]).tocsr()
        np.log1p(expected.data, out=expected.data)
        difference = expected - L
        max_error = float(np.max(np.abs(difference.data))) if difference.nnz else 0.0
        if max_error > 2e-4:
            raise ValueError("Companion assays differ from original full-library log1p normalization.")
    prepared = OrderedDict()
    for name, value in methods.items():
        frame, graph, _ = companion_review._method_parts(value, obs.index, primary_cluster_key)
        prepared[name] = (frame, graph)
    audit = audited["heldout_exclusion"].copy()
    audit["original_assay_available"] = audit.gene.isin(genes)
    positives = {g: int(B[:, j].sum()) for j, g in enumerate(genes)}
    audit["original_n_positive"] = audit.gene.map(positives)
    audit["original_fraction_positive"] = audit.original_n_positive / len(obs)
    audit.to_csv(output / "heldout_exclusion_audit.csv", index=False)
    depth_bins, strata_codes, strata_table = companion_review._depth_strata(samples, depth)
    n_strata = len(strata_table)
    stratum_sizes = np.bincount(strata_codes, minlength=n_strata)
    membership = sp.csr_matrix((np.ones(len(obs)), (strata_codes, np.arange(len(obs)))), shape=(n_strata, len(obs)))
    stratum_fractions = (membership @ B).toarray() / stratum_sizes[:, None]
    global_fractions = np.asarray(B.mean(axis=0)).ravel()
    cluster_frames, sample_frames, depth_frames, dominance_frames, pair_frames = [], [], [], [], []
    neighbor_rows, coverage = [], {}
    for method, (frame, graph) in prepared.items():
        print(f"BANKSY companion review: {method}; {len(obs):,} original-count cells.", flush=True)
        clusters = frame[primary_cluster_key].astype(str).to_numpy()
        table, codes, sizes = companion_review._group_stats([clusters], ["cluster"], C, L, B, genes)
        composition = sp.csr_matrix((np.ones(len(obs)), (codes, strata_codes)), shape=(len(sizes), n_strata))
        expected = np.asarray(composition @ stratum_fractions) / sizes[:, None]
        table["sample_depth_expected_fraction"] = expected.ravel()
        table["sample_depth_excess_fraction"] = table.fraction_positive - table.sample_depth_expected_fraction
        table["global_fraction_positive"] = np.tile(global_fractions, len(sizes))
        table["is_heldout"] = table.gene.isin(heldout_genes)
        table.insert(0, "clustering", primary_cluster_key)
        table.insert(0, "method", method)
        cluster_frames.append(table)
        for arrays, names, destination in (([clusters, samples], ["cluster", "sample"], sample_frames),
                ([clusters, samples, depth_bins], ["cluster", "sample", "depth_quintile"], depth_frames)):
            sub, _, _ = companion_review._group_stats(arrays, names, C, L, B, genes)
            sub.insert(0, "clustering", primary_cluster_key)
            sub.insert(0, "method", method)
            sub["is_heldout"] = sub.gene.isin(heldout_genes)
            destination.append(sub)
        dom = table[table.gene.isin(companion_review.DOMINANCE_GENES)].copy()
        dom["mean_count_when_detected"] = dom.mean_observed_counts.div(dom.fraction_positive.replace(0, np.nan))
        dom["near_single_transcript_pattern"] = (dom.fraction_positive >= .95) & (dom.mean_count_when_detected <= 1.5)
        dominance_frames.append(dom)
        for guide, target in pairs:
            if guide not in lookup or target not in lookup:
                continue
            a = table[table.gene == guide].set_index("cluster")
            b = table[table.gene == target].set_index("cluster")
            pair_frames.append(pd.DataFrame({"method": method, "clustering": primary_cluster_key,
                "cluster": a.index, "n_cells": a.n_cells.to_numpy(), "guide_gene": guide, "heldout_gene": target,
                "guide_fraction_positive": a.fraction_positive.to_numpy(), "heldout_fraction_positive": b.fraction_positive.to_numpy(),
                "guide_sample_depth_excess": a.sample_depth_excess_fraction.to_numpy(),
                "heldout_sample_depth_excess": b.sample_depth_excess_fraction.to_numpy()}))
        rows, fraction = companion_review._neighbor_rows(method, pairs, genes, B, graph, strata_codes,
            strata_table, stratum_fractions, int(min_cells_per_guide_group))
        neighbor_rows.extend(rows)
        coverage[method] = fraction
    strata = pd.DataFrame(neighbor_rows)
    keys = ["guide_gene", "heldout_gene", "sample", "depth_quintile"]
    strata["shared_eligible_stratum"] = strata.groupby(keys, sort=False).eligible_stratum.transform(
        lambda x: len(x) == len(prepared) and bool(x.all())).astype(bool)
    eligible = strata[strata.shared_eligible_stratum]
    by_sample = eligible.groupby(["method", "guide_gene", "heldout_gene", "sample"], as_index=False).agg(
        n_shared_depth_strata=("depth_quintile", "size"),
        n_guide_positive_with_neighbors=("n_guide_positive_with_neighbors", "sum"),
        n_guide_negative_with_neighbors=("n_guide_negative_with_neighbors", "sum"),
        raw_neighbor_difference=("raw_neighbor_difference", "mean"),
        expected_neighbor_difference=("expected_neighbor_difference", "mean"),
        neighbor_excess_difference=("neighbor_excess_difference", "mean"))
    summary_rows = []
    for method in prepared:
        for guide, target in pairs:
            use = by_sample[(by_sample.method == method) & (by_sample.guide_gene == guide) & (by_sample.heldout_gene == target)]
            summary_rows.append({"method": method, "guide_gene": guide, "heldout_gene": target,
                "marker_pair_available": guide in lookup and target in lookup,
                "graph_available": prepared[method][1] is not None,
                "n_samples_compared": len(use), "n_shared_depth_strata": int(use.n_shared_depth_strata.sum()),
                "n_guide_positive_compared": int(use.n_guide_positive_with_neighbors.sum()),
                "n_guide_negative_compared": int(use.n_guide_negative_with_neighbors.sum()),
                "global_heldout_detection_fraction": float(global_fractions[lookup[target]]) if target in lookup else np.nan,
                "sample_balanced_raw_neighbor_difference": float(use.raw_neighbor_difference.mean()) if len(use) else np.nan,
                "sample_balanced_neighbor_excess_difference": float(use.neighbor_excess_difference.mean()) if len(use) else np.nan,
                "n_samples_with_positive_excess_difference": int((use.neighbor_excess_difference > 0).sum()),
                "graph_nonself_neighbor_coverage": coverage[method]})
    summary_frame = pd.DataFrame(summary_rows)
    tables = {
        "companion_cluster_markers.csv.gz": pd.concat(cluster_frames, ignore_index=True),
        "companion_by_sample.csv.gz": pd.concat(sample_frames, ignore_index=True),
        "companion_by_sample_depth.csv.gz": pd.concat(depth_frames, ignore_index=True),
        "single_gene_dominance_audit.csv": pd.concat(dominance_frames, ignore_index=True),
        "cluster_guide_companion.csv": pd.concat(pair_frames, ignore_index=True) if pair_frames else pd.DataFrame(columns=["method", "guide_gene", "heldout_gene", "cluster"]),
        "heldout_neighbor_by_sample_depth.csv": strata,
        "heldout_neighbor_by_sample.csv": by_sample,
        "heldout_neighbor_summary.csv": summary_frame,
    }
    for filename, table in tables.items():
        table.to_csv(output / filename, index=False)
    figure = figures / "heldout_companion_concordance.png"
    companion_review._plot_summary(summary_frame, figure, list(prepared), pairs)
    summary = {"n_cells": len(obs), "n_samples": len(pd.unique(samples)),
        "primary_clustering": primary_cluster_key, "heldout_genes": heldout_genes,
        "guide_pairs": pairs, "independent_CD4_validation": False,
        "missing_assays": [g for g in requested if g not in lookup],
        "min_cells_per_guide_group": int(min_cells_per_guide_group),
        "normalization_max_absolute_error": max_error,
        "graph_nonself_neighbor_coverage": coverage, "neighbor_summary": summary_frame.to_dict(orient="records"),
        "feature_audit": "Actual own/mean/gradient blocks; verified against completed embedding manifests",
        "interpretation_notes": REVIEW_NOTES, "elapsed_seconds": time.perf_counter() - started}
    _json(output / "companion_summary.json", summary)
    _simple_html(output / "companion_review.html", "08U · Held-out BANKSY companion review",
        "<p>Original transcript evidence; lambda 0 versus lambda 0.2. Each reserved gene is excluded from every BANKSY feature block.</p>"
        + summary_frame.to_html(index=False, float_format=lambda x: f"{x:.4g}", escape=True)
        + '<img src="figures/heldout_companion_concordance.png" alt="Held-out companion coherence">'
        + "<h2>Interpretation</h2><ul>" + "".join(f"<li>{html.escape(x)}</li>" for x in REVIEW_NOTES) + "</ul>"
        + _table_links(output))
    return summary


def _simple_html(path, title, body):
    text = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><style>body{{font:16px/1.55 system-ui,sans-serif;max-width:1500px;margin:30px auto;padding:24px;color:#193047;background:#f8fafb}}h1,h2{{line-height:1.25}}img{{max-width:100%;height:auto}}table{{border-collapse:collapse;display:block;overflow:auto}}td,th{{padding:7px;border:1px solid #cbd7e1;text-align:right}}th{{background:#e9f0f5}}a{{color:#156b92}}section{{margin:28px 0}}.note{{padding:16px;background:#eef4f7}}</style></head><body><h1>{html.escape(title)}</h1>{body}</body></html>'''
    Path(path).write_text(text, encoding="utf-8")
    return Path(path)


def _table_links(directory):
    paths = sorted(p for p in Path(directory).iterdir() if p.is_file() and p.name.endswith((".csv", ".csv.gz", ".json")))
    return "<h2>Tables and provenance</h2><ul>" + "".join(
        f'<li><a href="{html.escape(p.name)}">{html.escape(p.name)}</a></li>' for p in paths) + "</ul>"


def original_count_bins(counts, gene_names, obs, methods, *, genes=("Foxp3", "Ccr8"),
                        primary_cluster_key="leiden_0.4", sample_key="sample_id", condition_key="condition"):
    """All-cell 0/1/2+ summaries, retaining genuine missing-assay information."""
    names = pd.Index([str(g) for g in gene_names])
    if not names.is_unique or counts.shape != (len(obs), len(names)):
        raise ValueError("Original counts, genes, and ordered obs are inconsistent.")
    rows, arrays, unavailable = [], {}, []
    for gene in genes:
        if gene not in names:
            unavailable.append(gene)
            continue
        values = counts[:, names.get_loc(gene)]
        values = np.asarray(values.toarray() if sp.issparse(values) else values).ravel()
        if not np.isfinite(values).all() or (values < 0).any() or not np.allclose(values, np.rint(values), rtol=0, atol=1e-4):
            raise ValueError("Raw marker bins require original nonnegative integer transcript counts.")
        bins = np.minimum(np.rint(values).astype(np.int64), 2)
        arrays[gene] = bins
        levels = [("all_cells", "all", np.ones(len(obs), dtype=bool))]
        for key in (sample_key, condition_key):
            if key and key in obs:
                labels = obs[key].astype(str).to_numpy()
                levels.extend((key, str(level), labels == level) for level in pd.unique(labels))
        for scope, level, selected in levels:
            n = int(selected.sum())
            frequencies = np.bincount(bins[selected], minlength=3)
            rows.append({"gene": gene, "method": "original_assay", "scope": scope, "group": level,
                "n_cells": n, "n_zero": int(frequencies[0]), "n_one": int(frequencies[1]),
                "n_two_or_more": int(frequencies[2]), "n_positive": int(frequencies[1:].sum()),
                "fraction_one_among_positive": float(frequencies[1] / frequencies[1:].sum()) if frequencies[1:].sum() else np.nan})
        for method, value in methods.items():
            frame = value.obs if hasattr(value, "obs") else value["obs"]
            if not frame.index.equals(obs.index):
                raise ValueError("Raw-count bin review refuses a different method cell order.")
            labels = frame[primary_cluster_key].astype(str).to_numpy()
            for level in pd.unique(labels):
                chosen = labels == level
                frequencies = np.bincount(bins[chosen], minlength=3)
                rows.append({"gene": gene, "method": method, "scope": primary_cluster_key, "group": level,
                    "n_cells": int(chosen.sum()), "n_zero": int(frequencies[0]), "n_one": int(frequencies[1]),
                    "n_two_or_more": int(frequencies[2]), "n_positive": int(frequencies[1:].sum()),
                    "fraction_one_among_positive": float(frequencies[1] / frequencies[1:].sum()) if frequencies[1:].sum() else np.nan})
    return pd.DataFrame(rows), arrays, unavailable


def build_original_expression_details(counts, log_expr, gene_names, obs, methods, output_dir, *,
                                      sample_key="sample_id", condition_key="condition",
                                      primary_cluster_key="leiden_0.4", max_plot_cells=120000,
                                      random_state=0):
    """Add raw-count maps and condition-stratified original-expression panels."""
    output = Path(output_dir)
    figures = output / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    prepared = OrderedDict((name, marker_review._get_method(value, obs.index, [primary_cluster_key]))
                           for name, value in methods.items())
    names = pd.Index([str(g) for g in gene_names])
    if counts.shape != log_expr.shape or counts.shape != (len(obs), len(names)) or not names.is_unique:
        raise ValueError("Original marker assays do not match metadata and gene names.")
    count_table, bins, unavailable = original_count_bins(counts, names, obs, methods,
        primary_cluster_key=primary_cluster_key, sample_key=sample_key, condition_key=condition_key)
    count_table.to_csv(output / "original_marker_count_bins.csv", index=False)
    rng = np.random.default_rng(random_state)
    selected = np.sort(rng.choice(len(obs), min(len(obs), int(max_plot_cells)), replace=False))
    selected = selected[rng.permutation(len(selected))]
    plt = marker_review._plot_style()
    plots = []
    if bins:
        fig, axes = plt.subplots(len(prepared), len(bins), figsize=(5.8 * len(bins), 5.0 * len(prepared)), squeeze=False)
        for col, (gene, values) in enumerate(bins.items()):
            labels = np.asarray(["0 transcripts", "1 transcript", "2+ transcripts"], dtype=object)[values]
            palette = {"0 transcripts": "#d7dce1", "1 transcript": "#c87a2c", "2+ transcripts": "#7b3ca5"}
            shown = selected[np.argsort(values[selected], kind="stable")]
            for row, (method, data) in enumerate(prepared.items()):
                marker_review._scatter_category(axes[row, col], data["umap"][shown], labels[shown],
                    f"{DISPLAY_NAMES.get(method, method)} | {gene}\n0 / 1 / 2+ original transcripts", colors=palette, legend=True)
        fig.suptitle(f"Original count bins | {len(obs):,} cells summarized; {len(selected):,} identical display cells per method", fontsize=13)
        fig.tight_layout()
        path = figures / "umap_original_Foxp3_Ccr8_count_bins.png"
        marker_review._save_figure(fig, path, plt)
        plots.append(path)
    if condition_key and condition_key in obs:
        conditions = obs[condition_key].astype(str).to_numpy()
        condition_levels = sorted(pd.unique(conditions), key=marker_review._natural_key)
        for gene in ("Cd4", "Cd8a", "Foxp3", "Ccr8"):
            if gene not in names:
                continue
            values = log_expr[:, names.get_loc(gene)]
            values = np.asarray(values.toarray() if sp.issparse(values) else values).ravel()
            if not np.isfinite(values).all() or (values < 0).any():
                raise ValueError("Original expression must be finite and nonnegative.")
            positive = values[values > 0]
            vmax = float(np.quantile(positive, .99)) if len(positive) else 1.0
            for page, start in enumerate(range(0, len(condition_levels), 4), 1):
                chosen = condition_levels[start:start + 4]
                fig, axes = plt.subplots(len(prepared), len(chosen), figsize=(5.1 * len(chosen), 4.8 * len(prepared)), squeeze=False)
                for row, (method, data) in enumerate(prepared.items()):
                    lo, hi = data["umap"].min(axis=0), data["umap"].max(axis=0)
                    pad = np.maximum((hi - lo) * .04, .05)
                    for col, condition in enumerate(chosen):
                        ix = selected[conditions[selected] == condition]
                        ax = axes[row, col]
                        sc = marker_review._scatter_continuous(ax, data["umap"][ix], values[ix],
                            f"{DISPLAY_NAMES.get(method, method)} | {condition}\n{gene}; n={int((conditions == condition).sum()):,}",
                            vmax=vmax, zero_gray=True, cmap="magma_r")
                        ax.set_xlim(lo[0] - pad[0], hi[0] + pad[0])
                        ax.set_ylim(lo[1] - pad[1], hi[1] + pad[1])
                        ax.set_aspect("equal", adjustable="box")
                        fig.colorbar(sc, ax=ax, shrink=.65, label="Original log1p expression")
                fig.suptitle("Condition-stratified original expression | same joint embedding; shared gene color limits", fontsize=13)
                fig.tight_layout()
                path = figures / f"umap_original_{gene}_by_condition_page{page:02d}.png"
                marker_review._save_figure(fig, path, plt)
                plots.append(path)
    summary = {"n_cells": len(obs), "n_displayed_cells": len(selected),
               "missing_raw_count_assays": unavailable, "all_cell_statistics": True,
               "display_sampling": "identical uniform random cells across methods; no expression-based enrichment",
               "figures": [str(path.relative_to(output)) for path in plots]}
    _json(output / "original_expression_details.json", summary)
    blocks = "".join(f'<section><h2>{html.escape(path.stem)}</h2><img loading="lazy" src="{html.escape(str(path.relative_to(output)))}" alt="Original-expression review"></section>' for path in plots)
    global_table = count_table[count_table.scope == "all_cells"].to_html(index=False, float_format=lambda x: f"{x:.4g}", escape=True) if len(count_table) else "<p>Foxp3 and Ccr8 original assays are unavailable.</p>"
    _simple_html(output / "original_expression_review.html", "08U · Original transcript-count detail",
        "<p>Count bins distinguish measured zero, one, and at least two transcripts. Zero is not evidence of biological absence. "
        "Only display points are sampled; tables use every focal T cell. Ccr8 is omitted when its original assay is unavailable.</p>"
        + global_table + blocks + _table_links(output))
    return summary


def write_main_dominance_audit(review_dir):
    directory = Path(review_dir)
    table = pd.read_csv(directory / "marker_statistics.csv.gz")
    audit = table[table.gene.isin(companion_review.DOMINANCE_GENES)].copy()
    audit["mean_count_when_detected"] = audit.mean_observed_counts.div(audit.fraction_positive.replace(0, np.nan))
    audit["near_universal_detection"] = audit.fraction_positive >= .95
    audit["low_mean_count_when_detected"] = audit.mean_count_when_detected <= 1.5
    audit["near_single_transcript_pattern"] = audit.near_universal_detection & audit.low_mean_count_when_detected
    audit.to_csv(directory / "single_gene_dominance_audit.csv", index=False)
    return audit


def build_information_support_review(obs, methods, output_dir, *, primary_cluster_key="leiden_0.4",
                                      sample_key="sample_id", max_plot_cells=120000, random_state=0):
    """Show which cells have little or no directly observed selected-gene input."""
    output = Path(output_dir)
    figures = output / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    requested = ("eligible_feature_counts", "no_observed_eligible_feature", "no_observed_heldout_feature")
    available = [key for key in requested if key in obs]
    missing = [key for key in requested if key not in obs]
    arrays = {}
    for key in available:
        if key == "eligible_feature_counts":
            values = pd.to_numeric(obs[key], errors="raise").to_numpy(dtype=float)
            if not np.isfinite(values).all() or (values < 0).any():
                raise ValueError("eligible_feature_counts must contain finite nonnegative original counts.")
            arrays[key] = values
        else:
            source = obs[key]
            if pd.api.types.is_bool_dtype(source.dtype) and not source.isna().any():
                values = source.to_numpy(dtype=bool)
            else:
                converted = source.astype(str).str.lower().map({"true": True, "false": False, "1": True, "0": False})
                if converted.isna().any():
                    raise ValueError(f"{key} must contain nonmissing Boolean values.")
                values = converted.to_numpy(dtype=bool)
            arrays[key] = values
    if "eligible_feature_counts" in arrays and "no_observed_eligible_feature" in arrays:
        if not np.array_equal(arrays["eligible_feature_counts"] == 0, arrays["no_observed_eligible_feature"]):
            raise ValueError("Zero selected-gene count flags disagree with original selected-gene counts.")
    prepared = OrderedDict((name, marker_review._get_method(value, obs.index, [primary_cluster_key]))
                           for name, value in methods.items())
    rows = []
    for method, data in prepared.items():
        labels = data["obs"][primary_cluster_key].astype(str).to_numpy()
        for cluster in pd.unique(labels):
            chosen = labels == cluster
            row = {"method": method, "clustering": primary_cluster_key, "cluster": cluster,
                   "n_cells": int(chosen.sum())}
            for key, values in arrays.items():
                if key == "eligible_feature_counts":
                    row["mean_eligible_feature_counts"] = float(values[chosen].mean())
                    row["median_eligible_feature_counts"] = float(np.median(values[chosen]))
                else:
                    row[f"n_{key}"] = int(values[chosen].sum())
                    row[f"fraction_{key}"] = float(values[chosen].mean())
            rows.append(row)
    cluster_table = pd.DataFrame(rows)
    cluster_table.to_csv(output / "original_information_by_cluster.csv", index=False)
    sample_rows = []
    if sample_key in obs:
        labels = obs[sample_key].astype(str).to_numpy()
        for sample in pd.unique(labels):
            chosen = labels == sample
            row = {"sample": sample, "n_cells": int(chosen.sum())}
            for key, values in arrays.items():
                row[("mean_" if key == "eligible_feature_counts" else "fraction_") + key] = float(values[chosen].mean())
            sample_rows.append(row)
    sample_table = pd.DataFrame(sample_rows)
    sample_table.to_csv(output / "original_information_by_sample.csv", index=False)
    plots = []
    if available:
        rng = np.random.default_rng(random_state)
        selected = np.sort(rng.choice(len(obs), min(len(obs), int(max_plot_cells)), replace=False))
        selected = selected[rng.permutation(len(selected))]
        plt = marker_review._plot_style()
        fig, axes = plt.subplots(len(prepared), len(available), figsize=(5.6 * len(available), 4.6 * len(prepared)), squeeze=False)
        for row, (method, data) in enumerate(prepared.items()):
            for col, key in enumerate(available):
                ax = axes[row, col]
                values = arrays[key]
                if key == "eligible_feature_counts":
                    values = np.log1p(values)
                    sc = marker_review._scatter_continuous(ax, data["umap"][selected], values[selected],
                        f"{DISPLAY_NAMES.get(method, method)}\nOriginal selected-gene transcript support",
                        vmax=max(float(np.quantile(values, .99)), 1e-9))
                    fig.colorbar(sc, ax=ax, shrink=.65, label="log1p original selected-gene count sum")
                else:
                    display = np.where(values, "No directly observed feature", "Observed feature present")
                    ix = selected[np.argsort(values[selected], kind="stable")]
                    title = "Main selected-gene support" if key == "no_observed_eligible_feature" else "Held-out-arm selected-gene support"
                    marker_review._scatter_category(ax, data["umap"][ix], display[ix],
                        f"{DISPLAY_NAMES.get(method, method)}\n{title}",
                        colors={"Observed feature present": "#d5dce2", "No directly observed feature": "#b54a41"}, legend=True)
        fig.suptitle("Original information available before BANKSY | all cells retained; zero means no directly observed selected-gene transcript", fontsize=13)
        fig.tight_layout()
        path = figures / "umap_original_information_support.png"
        marker_review._save_figure(fig, path, plt)
        plots.append(path)
    summary = {"n_cells": len(obs), "available_fields": available, "missing_fields": missing,
        "all_cell_statistics": True,
        "interpretation": "Zero direct input can still yield an embedding through centering, spatial neighbors, and integration. A spatially smooth position does not supply an independently measured lineage transcript.",
        "figures": [str(path.relative_to(output)) for path in plots]}
    _json(output / "original_information_summary.json", summary)
    images = "".join(f'<img loading="lazy" src="{html.escape(str(path.relative_to(output)))}" alt="Original selected-gene information support">' for path in plots)
    _simple_html(output / "information_review.html", "08U · Direct transcript support",
        f'<p>{html.escape(summary["interpretation"])}</p><p>All-cell summaries; identical random display cells across methods. '
        f'Unavailable metadata fields: {html.escape(", ".join(missing) or "None")}.</p>'
        + images + sample_table.to_html(index=False, float_format=lambda x: f"{x:.4g}", escape=True) + _table_links(output))
    return summary


def build_report_index(run_dir, experiment, review_dirs, *, timings=None, n_cells=None):
    root = Path(run_dir)
    root.mkdir(parents=True, exist_ok=True)
    descriptions = {"main": "Main BANKSY lambda 0 versus 0.2: clustering and original markers",
                    "heldout": "Matched companion-held-out lambda comparison",
                    "companion": "Held-out neighbor coherence and exact block-exclusion audit",
                    "original": "Foxp3/Ccr8 raw-count bins and condition-stratified original expression",
                    "information": "Direct transcript support and cells without observed selected-gene transcripts"}
    links = []
    for label, directory in review_dirs.items():
        directory = Path(directory)
        for filename in ("review.html", "companion_review.html", "original_expression_review.html", "information_review.html"):
            path = directory / filename
            if path.is_file():
                relative = os.path.relpath(path, root)
                links.append(f'<li><a href="{html.escape(relative)}">{html.escape(descriptions.get(label, label))}</a></li>')
                break
    n = n_cells if n_cells is not None else (experiment or {}).get("n_cells")
    count_text = f"{int(n):,} focal cells" if n is not None else "The frozen T cell 1 + T cell 2 subset"
    body = f"<p>{count_text}; original all-tissue neighborhoods within each sample; matched BANKSY lambda comparisons.</p><ol>{''.join(links)}</ol>"
    body += "<h2>How to judge this test</h2><p>Start with the main lambda pair at Leiden 0.4. Check multi-gene marker agreement and environmental markers, "
    body += "then read the held-out comparison with sample/depth coverage. Compare cluster counts and depth/sample dependence at the same resolution. "
    body += "A cleaner-looking UMAP alone is insufficient evidence of improved T-cell typing.</p>"
    body += "<p>The lambda-zero arm uses the same BANKSY feature scaling and gene universe as its lambda-0.2 partner. "
    body += "08T remains a separate previous benchmark; it is not rerun or pooled into these matched comparisons.</p>"
    body += "<h2>Limits</h2><ul>" + "".join(f"<li>{html.escape(note)}</li>" for note in REVIEW_NOTES) + "</ul>"
    main = Path(review_dirs["main"]) if "main" in review_dirs else None
    if main is not None and (main / "method_comparison.csv").is_file():
        comparison = pd.read_csv(main / "method_comparison.csv")
        keep = [key for key in ("method", "clustering", "n_cells", "n_clusters", "fraction_cells_in_clusters_under_100", "log_depth_eta_squared", "sample_cramers_v_bias_corrected") if key in comparison]
        body += "<h2>Main technical diagnostics</h2>" + comparison[keep].to_html(index=False, float_format=lambda x: f"{x:.4g}", escape=True)
    if timings is not None:
        _json(root / "notebook_timings.json", timings)
    _json(root / "review_experiment.json", experiment or {})
    body += _table_links(root)
    return _simple_html(root / "review.html", "08U · BANKSY T-cell comparison", body)


def _package_priority(path, relative=None):
    name = path.name.lower()
    parts = Path(relative).parts if relative is not None else path.parts
    is_main = "main" in parts or ("banksy_lam" in name and "heldout" not in name)
    if path.suffix.lower() in (".json", ".log", ".txt"):
        return 0
    if path.suffix.lower() == ".html":
        return 1
    if name.endswith((".csv", ".csv.gz")):
        return 2
    if is_main and ("umap_lineage_markers" in name or "umap_clusters" in name):
        return 3
    if "heldout_companion_concordance" in name or "original_foxp3_ccr8_count_bins" in name:
        return 4
    if is_main and "leiden_0_4_lineage_mean_log1p" in name:
        return 4
    if "original_information_support" in name or (is_main and "umap_sample_condition_depth" in name):
        return 5
    if "umap_original_foxp3_by_condition" in name or "leiden_0_4_background" in name:
        return 6
    if "umap_lineage_markers" in name or "umap_clusters" in name:
        return 7
    if "leiden_0_4_lineage_mean_log1p" in name or "umap_sample_condition_depth" in name:
        return 8
    return 10


def make_return_package(run_dir, experiment=None, review_dirs=None, *, max_megabytes=25,
                        filename="08U_return_to_chat.zip"):
    """Package aggregate results and prioritized figures under a strict size cap.

    Sparse/dense assays, models, embeddings, and per-cell tables are excluded.
    The cap applies to the finished ZIP, with room reserved for its index and
    omissions manifest. The complete reports remain in their original location.
    """
    root = Path(run_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    if not np.isfinite(max_megabytes) or float(max_megabytes) <= 0:
        raise ValueError("max_megabytes must be finite and positive.")
    budget = int(float(max_megabytes) * 1_000_000)
    if budget < 16_384:
        raise ValueError("Compact package budget must allow at least 16 KB for its audit/index.")
    if Path(filename).name != filename or not filename.endswith(".zip"):
        raise ValueError("Package filename must be a plain .zip basename.")
    archive = root / filename
    candidates, omitted = {}, []
    roots = [(root, "")]
    for label, directory in (review_dirs or {}).items():
        path = Path(directory).resolve()
        if path != root and root not in path.parents:
            roots.append((path, str(label) + "/"))
    if experiment:
        for key in ("experiment_dir", "source_cache_dir", "cache_dir", "spatial_dir", "run_dir"):
            value = experiment.get(key)
            if value:
                directory = Path(value).resolve()
                if directory != root and root not in directory.parents:
                    roots.append((directory, key + "/"))
    allowed = (".csv", ".csv.gz", ".json", ".log", ".txt", ".html", ".png")
    per_cell_names = {"obs.csv", "obs.csv.gz", "cell_metadata.csv", "cell_metadata.csv.gz",
                      "observed_marker_evidence.csv.gz", "umap_display_cell_ids.csv.gz",
                      "cluster_assignments.csv", "cluster_assignments.csv.gz",
                      "tissue_cells.csv", "tissue_cells.csv.gz"}
    seen_paths = set()
    for directory, prefix in roots:
        if not directory.is_dir():
            continue
        for path in directory.rglob("*"):
            if not path.is_file() or path.is_symlink() or path == archive:
                continue
            resolved = str(path.resolve())
            if resolved in seen_paths:
                continue
            # Review-root names are canonical. A later traversal of its parent
            # must not move them under run_dir/review and break HTML links.
            seen_paths.add(resolved)
            relative = prefix + path.relative_to(directory).as_posix()
            name = path.name.lower()
            if not name.endswith(allowed):
                if name.endswith((".h5ad", ".npz", ".npy", ".parquet")):
                    omitted.append({"file": relative, "reason": "matrix/model/per-cell data excluded"})
                continue
            if name in per_cell_names or any(token in name for token in ("cell_ids", "per_cell", "embeddings", "cell_metadata")):
                omitted.append({"file": relative, "reason": "per-cell table excluded; all-cell aggregate summaries included"})
                continue
            candidates[resolved] = (path, relative, _package_priority(path, relative))
    selected, total = [], 0
    reserve = min(max(8192, budget // 30), 1_000_000)
    for path, relative, priority in sorted(candidates.values(), key=lambda x: (x[2], x[1])):
        size = path.stat().st_size
        if total + size > budget - reserve:
            omitted.append({"file": relative, "reason": "compact size budget", "bytes": size})
            continue
        selected.append((path, relative))
        total += size
    def write_archive():
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as handle:
            for path, relative in selected:
                handle.write(path, relative)
            links, images = [], []
            for path, relative in selected:
                safe = html.escape(relative)
                if path.suffix.lower() == ".png":
                    images.append(f'<section><h2>{safe}</h2><img loading="lazy" src="{safe}" alt="BANKSY diagnostic figure"></section>')
                else:
                    links.append(f'<li><a href="{safe}">{safe}</a></li>')
            page = '<!doctype html><html lang="en"><meta charset="utf-8"><title>08U compact BANKSY review</title><body style="font:16px/1.5 system-ui;max-width:1500px;margin:auto;padding:25px"><h1>08U compact BANKSY review</h1><p>Original-expression diagnostics and all-cell aggregate summaries. Some figures may be omitted to meet the file-size budget; see PACKAGE_CONTENTS.json. The complete report remains on the instance.</p><ul>' + ''.join(links) + '</ul>' + ''.join(images) + '</body></html>'
            handle.writestr("compact_review.html", page)
            handle.writestr("PACKAGE_CONTENTS.json", json.dumps(_clean({
                "files": [relative for _, relative in selected], "omitted": omitted,
                "matrix_data_included": False, "per_cell_tables_included": False,
                "selected_uncompressed_bytes": sum(path.stat().st_size for path, _ in selected),
                "maximum_archive_bytes": budget, "complete_local_report": str(root / "review.html"),
            }), indent=2))
    write_archive()
    while archive.stat().st_size > budget and selected:
        path, relative = selected.pop()
        omitted.append({"file": relative, "reason": "finished ZIP size cap", "bytes": path.stat().st_size})
        write_archive()
    if archive.stat().st_size > budget:
        archive.unlink()
        raise ValueError("The package audit alone exceeds the chosen budget; increase max_megabytes.")
    print(f"08U return file: {archive} ({archive.stat().st_size / 1e6:.2f} MB)", flush=True)
    return archive


def diagnose_and_package(run_dir, error=None, *, experiment=None, review_dirs=None,
                          max_megabytes=25, extra=None):
    """Capture a failure without touching matrices, then make a small return ZIP."""
    root = Path(run_dir)
    root.mkdir(parents=True, exist_ok=True)
    versions = {}
    for package in ("pybanksy", "numpy", "scipy", "pandas", "anndata", "scanpy", "rapids-singlecell", "cupy-cuda12x", "cuml-cu12"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    current_error = error if error is not None else sys.exc_info()[1]
    trace = "".join(traceback.format_exception(type(current_error), current_error, current_error.__traceback__)) if isinstance(current_error, BaseException) else (str(current_error) if current_error is not None else None)
    _json(root / "08U_diagnostic.json", {"utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version, "platform": platform.platform(), "versions": versions,
        "error_type": type(current_error).__name__ if current_error is not None else None,
        "traceback": trace, "additional_context": extra or {},
        "instructions": "Attach this ZIP together with the notebook cell that failed. No raw assay matrices are included."})
    return make_return_package(root, experiment, review_dirs, max_megabytes=max_megabytes,
                               filename="08U_diagnostic_return.zip")


def run_banksy_reviews(counts, log_expr, gene_names, obs, methods, feature_manifests, output_dir, *,
                       experiment=None, timings=None, sample_key="sample_id", condition_key="condition",
                       depth_key="total_counts", cluster_keys=("leiden_0.2", "leiden_0.4", "leiden_0.6"),
                       primary_cluster_key="leiden_0.4", max_plot_cells=120000,
                       max_clusters_per_page=35, random_state=0, normalization_target_sum=10000.0,
                       heldout_genes=HELDOUT_GENES, max_return_megabytes=25):
    """One-call review of all four completed BANKSY arms, preserving originals.

    Methods may be lightweight AnnData objects or mappings containing ``obs``,
    ``obsm['X_umap']``, ``obsp['connectivities']``, and ``uns['banksy_manifest']``.
    CPU sparse connectivities use exactly the original focal-cell order.
    """
    if set(methods) != set(METHOD_NAMES):
        raise ValueError(f"Review requires the four completed methods: {METHOD_NAMES}.")
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    ordered = OrderedDict((name, methods[name]) for name in METHOD_NAMES)
    audit_feature_manifests(ordered, feature_manifests, obs, heldout_genes=heldout_genes,
                             output_dir=root / "feature_audit")
    directories = {key: root / key for key in ("main", "heldout", "companion", "original", "information")}
    common = dict(sample_key=sample_key, condition_key=condition_key, depth_key=depth_key,
        primary_cluster_key=primary_cluster_key, max_plot_cells=max_plot_cells,
        max_clusters_per_page=max_clusters_per_page, random_state=random_state,
        normalization_target_sum=normalization_target_sum)
    main_methods = OrderedDict((name, ordered[name]) for name in MAIN_METHODS)
    heldout_methods = OrderedDict((name, ordered[name]) for name in HELDOUT_METHODS)
    main = marker_review.build_review(log_expr, counts, gene_names, obs, main_methods,
                                     directories["main"], cluster_keys=list(cluster_keys), **common)
    heldout = marker_review.build_review(log_expr, counts, gene_names, obs, heldout_methods,
                                        directories["heldout"], cluster_keys=[primary_cluster_key], **common)
    for label in ("main", "heldout"):
        path = directories[label] / "review.html"
        if path.is_file():
            page = path.read_text(encoding="utf-8").replace("08T T-cell weighted PCA / Harmony review", "08U BANKSY / Harmony original-marker review")
            path.write_text(page, encoding="utf-8")
    write_main_dominance_audit(directories["main"])
    companion = build_banksy_companion_review(counts, log_expr, gene_names, obs, heldout_methods,
        {name: feature_manifests[name] for name in HELDOUT_METHODS}, directories["companion"],
        primary_cluster_key=primary_cluster_key, heldout_genes=heldout_genes,
        sample_key=sample_key, depth_key=depth_key, normalization_target_sum=normalization_target_sum)
    original = build_original_expression_details(counts, log_expr, gene_names, obs, main_methods,
        directories["original"], sample_key=sample_key, condition_key=condition_key,
        primary_cluster_key=primary_cluster_key, max_plot_cells=max_plot_cells, random_state=random_state)
    information = build_information_support_review(obs, ordered, directories["information"],
        primary_cluster_key=primary_cluster_key, sample_key=sample_key,
        max_plot_cells=max_plot_cells, random_state=random_state)
    report = build_report_index(root, experiment or {}, directories, timings=timings, n_cells=len(obs))
    result = {"main": main, "heldout": heldout, "companion": companion, "original": original, "information": information,
              "review_dirs": {key: str(value) for key, value in directories.items()}, "report": str(report)}
    _json(root / "08U_review_complete.json", {"n_cells": len(obs), "methods": METHOD_NAMES,
        "report": str(report), "review_dirs": result["review_dirs"], "all_original_counts": True})
    archive = make_return_package(root, experiment, directories, max_megabytes=max_return_megabytes)
    result["return_zip"] = str(archive)
    return result
