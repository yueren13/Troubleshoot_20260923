"""08U isolated workers: spatial features, streamed BANKSY PCA, and RAPIDS.

The BANKSY matrix is a feature representation. It is never a corrected count
assay. Original counts are used separately by the review module.
"""
from __future__ import annotations

import argparse
import gc
import importlib.metadata
import json
import os
from pathlib import Path
import tempfile
import time
import traceback

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_gpu as shared
import tcell_banksy_math as bm

VERSION = "08U-banksy-gpu-1.0.0"


def _read(path):
    return json.loads(Path(path).read_text())


def _valid_result(path, fingerprint, cell_ids, feature_names, *, complete=True,
                  cluster_keys=(), n_pcs=None):
    if not Path(path).is_file():
        return False
    import anndata as ad
    saved = None
    try:
        saved = ad.read_h5ad(path, backed="r")
        if (saved.uns.get("08u_fingerprint") != fingerprint
                or saved.uns.get("08u_stage") != ("complete" if complete else "graph")
                or not np.array_equal(saved.obs_names.astype(str), np.asarray(cell_ids, str))
                or not np.array_equal(saved.var_names.astype(str), np.asarray(feature_names, str))):
            return False
        for key in ("X_pca", "X_pca_harmony"):
            value = saved.obsm.get(key)
            if value is None or value.shape != (len(cell_ids), n_pcs) or not np.isfinite(value).all():
                return False
        neighbors = saved.uns.get("neighbors", {})
        for key in (neighbors.get("connectivities_key", "connectivities"),
                    neighbors.get("distances_key", "distances")):
            if key not in saved.obsp or saved.obsp[key].shape != (len(cell_ids), len(cell_ids)):
                return False
        if complete:
            if "X_umap" not in saved.obsm or saved.obsm["X_umap"].shape != (len(cell_ids), 2):
                return False
            if not np.isfinite(saved.obsm["X_umap"]).all():
                return False
            if any(k not in saved.obs or saved.obs[k].isna().any() for k in cluster_keys):
                return False
        return "banksy_manifest" in saved.uns or "banksy_manifest_json" in saved.uns
    except Exception:
        return False
    finally:
        if saved is not None:
            saved.file.close()


def spatial_worker(job_path):
    job = _read(job_path)
    print(f"[08U] Spatial context: {job['sample_id']}", flush=True)
    started = time.perf_counter()
    receipt = Path(job["output_dir"]) / "spatial_spec.json"
    # A scheduled recomputation publishes a new receipt only after both arrays
    # have been exported. Compatible completed jobs are skipped by the parent.
    receipt.unlink(missing_ok=True)
    load_started = time.perf_counter()
    matrix = sp.load_npz(job["matrix_path"]).tocsr()
    coords = np.load(job["coords_path"], allow_pickle=False)
    local_rows = np.load(job["focal_local_rows_path"], allow_pickle=False)
    global_rows = np.load(job["focal_global_rows_path"], allow_pickle=False)
    load_seconds = time.perf_counter() - load_started
    print(f"[08U] {job['sample_id']}: loaded spatial inputs in {load_seconds:.1f}s.", flush=True)
    execution = job.get("spatial_execution", {})
    if not isinstance(execution, dict):
        raise TypeError("spatial_execution must be a mapping of operational settings.")
    spec = bm.compute_sample_spatial_blocks(
        matrix, coords, local_rows, global_rows,
        job["output_dir"], job["sample_id"], k_geom=job["k_geom"],
        backend="gpu", gene_chunk_size=job.get("gene_chunk_size", 128),
        gene_names=job["gene_names"], workers=8,
        progress=lambda text: print("[08U] " + text, flush=True),
        output_staging=execution.get("output_staging", "auto"),
        max_ram_gib=execution.get("max_ram_gib", 16.0),
        concurrent_workers=execution.get("concurrent_workers", 1))
    spec["elapsed_seconds"] = time.perf_counter() - started
    spec["execution_profile"]["phase_seconds"]["load_inputs"] = load_seconds
    spec["execution_profile"]["worker_total_seconds"] = spec["elapsed_seconds"]
    spec["source_cache_id"] = job["source_cache_id"]
    spec["job_fingerprint"] = job["job_fingerprint"]
    shared.atomic_json(receipt, spec)
    print(f"[08U] Completed spatial features for {job['sample_id']}: "
          f"{spec['elapsed_seconds']:.1f}s", flush=True)
    print("[08U] Phase seconds: " + json.dumps(spec["execution_profile"]["phase_seconds"],
                                             sort_keys=True), flush=True)
    return spec


def _make_operator(experiment, arm, backend="gpu"):
    source = _read(experiment["source_manifest_path"])
    genes = pd.read_csv(source["features_path"], dtype={"gene": str}, keep_default_na=False)["gene"].tolist()
    obs = pd.read_csv(source["obs_path"], dtype={"cell_id": str, "sample_id": str,
                      "condition": str, "population": str, "source_cell_id": str,
                      "unit": str}, keep_default_na=False).set_index("cell_id")
    if shared.ordered_id_hash(obs.index) != source["cell_order_hash"]:
        raise ValueError("Prepared source cell IDs/order changed after preparation.")
    if shared.ordered_id_hash(genes) != source["gene_order_hash"]:
        raise ValueError("Prepared source gene IDs/order changed after preparation.")
    keep = np.ones(len(genes), dtype=bool)
    if arm["heldout"]:
        keep &= ~np.isin(genes, experiment["heldout_genes"])
    own = sp.load_npz(source["focal_own_path"]).tocsr()
    operator = bm.BanksyBlockOperator(
        own, experiment["spatial_specs"], genes,
        lambda_=arm["lambda"], keep_gene_mask=keep,
        stats=bm.load_block_statistics(experiment["statistics_path"]),
        backend=backend, row_chunk_size=experiment["row_chunk_size"],
        cell_ids=obs.index.astype(str).tolist())
    return operator, obs, source


def _operator_manifest(operator):
    value = operator.manifest
    return value() if callable(value) else dict(value)


def _feature_table(operator, manifest):
    rows = []
    for info in manifest["blocks"]:
        block = info["name"]
        for gene in info["genes"]:
            rows.append({"feature": f"{block}::{gene}", "block": block, "gene": gene,
                         "block_coefficient": info["coefficient"]})
    frame = pd.DataFrame(rows).set_index("feature")
    if len(frame) != operator.shape[1] or frame.index.tolist() != list(operator.feature_names):
        raise ValueError("BANKSY feature manifest does not match the PCA operator columns.")
    return frame


def run_branch(experiment_path, branch, *, resume=True):
    import anndata as ad
    import cupy as cp
    import rapids_singlecell as rsc
    experiment = _read(experiment_path)
    cfg = shared.validate_settings(experiment["gpu_settings"])
    arm = experiment["arms"][branch]
    output = Path(experiment["run_dir"]) / branch
    output.mkdir(parents=True, exist_ok=True)
    operator, obs, source = _make_operator(experiment, arm)
    manifest = _operator_manifest(operator)
    manifest.update(branch=branch, heldout=bool(arm["heldout"]),
                    heldout_genes=list(experiment["heldout_genes"]) if arm["heldout"] else [],
                    source_cache_id=source["cache_id"],
                    feature_selection=source.get("feature_selection", {}))
    var = _feature_table(operator, manifest)
    n_cells, n_features = operator.shape
    n_pcs = min(cfg["n_pcs"], n_cells - 1, operator.n_active_features)
    if n_pcs < 2:
        raise ValueError("Too few informative BANKSY features for PCA; all T cells were retained.")
    shared.atomic_json(output / "feature_manifest.json", manifest)
    versions = shared._versions()
    versions["pybanksy"] = importlib.metadata.version("pybanksy")
    pca_fp = shared._fingerprint({"experiment": experiment["experiment_id"],
        "manifest": manifest, "settings": {k: cfg[k] for k in
        ("n_pcs", "pca_oversamples", "pca_power_iter", "random_state")},
        "versions": versions, "engine": VERSION})
    harmony_fp = shared._fingerprint({"pca": pca_fp, "settings": {k: v for k, v in cfg.items()
                                     if k.startswith("harmony_")}})
    graph_fp = shared._fingerprint({"harmony": harmony_fp, "neighbors": cfg["n_neighbors"],
                                   "algorithm": cfg["neighbors_algorithm"], "seed": cfg["random_state"]})
    final_fp = shared._fingerprint({"graph": graph_fp, "settings": cfg})
    final_path = output / "embedding.h5ad"
    keys = [f"leiden_{r:g}" for r in cfg["resolutions"]]
    if resume and _valid_result(final_path, final_fp, obs.index, var.index,
                                cluster_keys=keys, n_pcs=n_pcs):
        saved = ad.read_h5ad(final_path)
        shared._write_assignments(saved, output, keys)
        shared.atomic_json(output / "completion.json", {"status": "complete", "fingerprint": final_fp,
                           "embedding_path": str(final_path), "n_cells": n_cells, "reused": True})
        print(f"[{branch}] Reusing completed compatible result.", flush=True)
        return final_path
    (output / "completion.json").unlink(missing_ok=True)
    metadata = {"engine_version": VERSION, "branch": branch, "status": "running",
                "settings": cfg, "versions": versions, "n_cells": n_cells,
                "n_features": n_features, "n_pcs": n_pcs,
                "pca_fingerprint": pca_fp, "harmony_fingerprint": harmony_fp,
                "graph_fingerprint": graph_fp, "final_fingerprint": final_fp,
                "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES", "not set"),
                "api_calls": {}, "reused_checkpoints": [], "stages": {},
                "interpretation": "BANKSY feature representation; original counts are unchanged."}
    logger = shared._StageLogger(cp, 0, metadata, output)
    logger.checkpoint()
    print(f"[{branch}] {n_cells:,} cells; {n_features:,} effective feature columns; "
          f"lambda={arm['lambda']:g}; heldout={arm['heldout']}", flush=True)
    try:
        pca_path = output / "pca_checkpoint.npz"
        if resume and shared._valid_checkpoint(pca_path, pca_fp,
                     required_keys=("scores", "loadings", "variance", "variance_ratio")):
            pca = shared._load_npz(pca_path)
            metadata["reused_checkpoints"].append("pca")
        else:
            with logger.stage("streamed_BANKSY_GPU_PCA"):
                pca = bm.randomized_pca(operator, n_components=n_pcs,
                    n_oversamples=cfg["pca_oversamples"], n_iter=cfg["pca_power_iter"],
                    random_state=cfg["random_state"])
            pca = {k: np.asarray(v) for k, v in pca.items()
                   if k in ("scores", "loadings", "variance", "variance_ratio", "mean")}
            shared.atomic_npz(pca_path, fingerprint=np.array(pca_fp), **pca)
        shared._assert_coordinates(pca["scores"], (n_cells, n_pcs), "BANKSY PCA scores")
        shared._assert_coordinates(pca["loadings"], (n_features, n_pcs), "BANKSY PCA loadings")
        analysis = ad.AnnData(X=None, obs=obs.copy(), var=var.copy())
        analysis.obsm["X_pca"] = pca["scores"].astype(np.float32, copy=False)
        analysis.varm["PCs"] = pca["loadings"].astype(np.float32, copy=False)
        analysis.uns["pca"] = {"variance": pca["variance"], "variance_ratio": pca["variance_ratio"]}
        analysis.uns["banksy_manifest_json"] = json.dumps(shared._jsonable(manifest), sort_keys=True)
        analysis.uns["08u_branch"] = branch
        metadata["pca_explained_variance_ratio_sum"] = float(np.sum(pca["variance_ratio"]))
        del pca, operator
        gc.collect()

        harmony_path = output / "harmony_checkpoint.npz"
        if resume and shared._valid_checkpoint(harmony_path, harmony_fp):
            corrected = shared._load_npz(harmony_path)["scores"]
            metadata["reused_checkpoints"].append("harmony")
        elif obs["sample_id"].nunique() == 1:
            corrected = analysis.obsm["X_pca"].copy()
            metadata["harmony_note"] = "One sample: Harmony is an identity operation."
            shared.atomic_npz(harmony_path, fingerprint=np.array(harmony_fp), scores=corrected)
        else:
            if (np.linalg.norm(analysis.obsm["X_pca"], axis=1) <= 1e-12).any():
                raise ValueError("A cell has zero-norm PCA coordinates; no cells were dropped.")
            kwargs = shared._harmony_kwargs(rsc.pp.harmony_integrate, cfg, n_cells)
            metadata["api_calls"]["harmony"] = shared._jsonable(kwargs)
            with logger.stage("gpu_Harmony"):
                rsc.pp.harmony_integrate(analysis, **kwargs)
                corrected = np.asarray(shared._to_host(analysis.obsm["X_pca_harmony"], cp), dtype=np.float32)
            shared.atomic_npz(harmony_path, fingerprint=np.array(harmony_fp), scores=corrected)
        shared._assert_coordinates(corrected, (n_cells, n_pcs), "Harmony coordinates")
        analysis.obsm["X_pca_harmony"] = corrected

        graph_path = output / "graph_checkpoint.h5ad"
        if resume and _valid_result(graph_path, graph_fp, obs.index, var.index,
                                    complete=False, n_pcs=n_pcs):
            analysis = ad.read_h5ad(graph_path)
            metadata["reused_checkpoints"].append("graph")
        else:
            kwargs = shared._required_kwargs(rsc.pp.neighbors, {
                "n_neighbors": min(cfg["n_neighbors"], n_cells - 1), "n_pcs": n_pcs,
                "use_rep": "X_pca_harmony", "algorithm": cfg["neighbors_algorithm"],
                "metric": "euclidean", "key_added": "neighbors"})
            if "method" in shared._signature(rsc.pp.neighbors):
                kwargs["method"] = "umap"
            kwargs.update(shared._seed_kw(rsc.pp.neighbors, cfg["random_state"]))
            metadata["api_calls"]["neighbors"] = kwargs
            with logger.stage("gpu_neighbors"):
                rsc.pp.neighbors(analysis, **kwargs)
            analysis = shared._cpu_adata(analysis, cp)
            analysis.uns["08u_fingerprint"] = graph_fp
            analysis.uns["08u_stage"] = "graph"
            shared._atomic_h5ad(analysis, graph_path)

        counts = {}
        for resolution in cfg["resolutions"]:
            key = f"leiden_{resolution:g}"
            label_fp = shared._fingerprint({"graph": graph_fp, "resolution": resolution,
                "iterations": cfg["leiden_n_iterations"], "seed": cfg["random_state"]})
            path = output / (key + "_checkpoint.npz")
            if resume and shared._valid_checkpoint(path, label_fp, required_keys=("codes", "categories")):
                saved = shared._load_npz(path)
                codes = np.asarray(saved["codes"], np.int32)
                categories = np.asarray(saved["categories"], str)
                if codes.shape != (n_cells,) or (codes < 0).any() or not len(categories) or codes.max() >= len(categories):
                    raise ValueError(f"Invalid labels in {path}.")
                analysis.obs[key] = pd.Categorical.from_codes(codes, categories)
                metadata["reused_checkpoints"].append(key)
            else:
                kwargs = shared._required_kwargs(rsc.tl.leiden, {"resolution": resolution,
                    "key_added": key, "n_iterations": cfg["leiden_n_iterations"],
                    "use_weights": True, "neighbors_key": "neighbors"})
                if "use_dask" in shared._signature(rsc.tl.leiden):
                    kwargs["use_dask"] = False
                kwargs.update(shared._seed_kw(rsc.tl.leiden, cfg["random_state"]))
                metadata["api_calls"][key] = kwargs
                with logger.stage("gpu_" + key):
                    rsc.tl.leiden(analysis, **kwargs)
                cat = pd.Categorical(analysis.obs[key])
                if (cat.codes < 0).any():
                    raise ValueError(f"Missing cluster assignments in {key}.")
                shared.atomic_npz(path, fingerprint=np.array(label_fp),
                    codes=np.asarray(cat.codes, np.int32), categories=np.asarray(cat.categories, str))
            counts[key] = int(analysis.obs[key].nunique())
            print(f"[{branch}] {key}: {counts[key]} clusters", flush=True)
        metadata["cluster_counts"] = counts
        kwargs = shared._required_kwargs(rsc.tl.umap, {"min_dist": cfg["umap_min_dist"],
            "spread": cfg["umap_spread"], "init_pos": "random", "neighbors_key": "neighbors",
            "maxiter": cfg["umap_maxiter"]})
        if "key_added" in shared._signature(rsc.tl.umap):
            kwargs["key_added"] = "X_umap"
        kwargs.update(shared._seed_kw(rsc.tl.umap, cfg["random_state"]))
        metadata["api_calls"]["umap"] = kwargs
        with logger.stage("gpu_UMAP"):
            rsc.tl.umap(analysis, **kwargs)
        if "X_umap" not in analysis.obsm and "umap" in analysis.obsm:
            analysis.obsm["X_umap"] = analysis.obsm["umap"]
        analysis = shared._cpu_adata(analysis, cp)
        shared._assert_coordinates(analysis.obsm["X_umap"], (n_cells, 2), "UMAP")
        analysis.uns["08u_fingerprint"] = final_fp
        analysis.uns["08u_stage"] = "complete"
        with logger.stage("save_results"):
            shared._atomic_h5ad(analysis, final_path)
            shared._write_assignments(analysis, output, keys)
        metadata["status"] = "complete"
        logger.checkpoint()
        shared.atomic_json(output / "completion.json", {"status": "complete", "fingerprint": final_fp,
            "embedding_path": str(final_path), "n_cells": n_cells})
        return final_path
    except BaseException as exc:
        metadata["status"] = "interrupted" if isinstance(exc, (KeyboardInterrupt, TimeoutError)) else "failed"
        metadata["error"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        logger.checkpoint()
        raise


def preflight():
    print("[08U preflight] Checking official BANKSY numerical equivalence", flush=True)
    check = bm.validate_against_pybanksy()
    print("[08U preflight] BANKSY check: " + json.dumps(shared._jsonable(check)), flush=True)
    runtime = shared.preflight_gpu(0)
    print("[08U preflight] Checking streamed BANKSY PCA on this GPU", flush=True)
    rng = np.random.default_rng(2718)
    x = sp.csr_matrix(np.log1p(rng.poisson(.7, size=(192, 12))).astype(np.float32))
    ids = [f"tiny_{i}" for i in range(96)]
    genes = [f"g{i}" for i in range(12)]
    with tempfile.TemporaryDirectory(prefix="08u_preflight_") as directory:
        spec = bm.compute_sample_spatial_blocks(x, rng.normal(size=(192, 2)),
            np.arange(96), np.arange(96), directory, "tiny", k_geom=5,
            backend="gpu", gene_chunk_size=4, gene_names=genes)
        stats = bm.fit_block_statistics(x[:96], [spec], row_chunk_size=24)
        op = bm.BanksyBlockOperator(x[:96], [spec], genes, lambda_=.2, stats=stats,
                                   backend="gpu", row_chunk_size=24, cell_ids=ids)
        pca = bm.randomized_pca(op, n_components=3, n_oversamples=3, n_iter=1, random_state=0)
        shared._assert_coordinates(pca["scores"], (96, 3), "Tiny streamed BANKSY PCA")
    runtime.update(banksy_equivalence=check, banksy_engine=VERSION,
                   banksy_streamed_gpu_check="passed", pybanksy_version=importlib.metadata.version("pybanksy"))
    return runtime


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("preflight", "spatial", "branch"), required=True)
    parser.add_argument("--job")
    parser.add_argument("--experiment")
    parser.add_argument("--branch")
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args(argv)
    if args.stage == "preflight":
        print(json.dumps(shared._jsonable(preflight()), sort_keys=True), flush=True)
    elif args.stage == "spatial":
        if not args.job:
            parser.error("Spatial worker requires --job.")
        spatial_worker(args.job)
    else:
        if not args.experiment or not args.branch:
            parser.error("Branch worker requires --experiment and --branch.")
        run_branch(args.experiment, args.branch, resume=not args.no_resume)


if __name__ == "__main__":
    main()
