# 08U release 1.1.0 — RAM staging for spatial features

## Run

Use `08U_Tcell_BANKSY_Harmony_GPU.ipynb` after the current 08U run finishes. Put it beside the working 08T/08U notebook, select the existing UV/RAPIDS/BANKSY kernel, and Run All. The notebook embeds all helper code. Usually PROJECT_DIR needs no edit. Do not run two copies against the same output cache concurrently.

## Why this update

The uploaded live reports show Ada-9 completing in 1,485.4 seconds. Its worker had accumulated 12.03 CPU seconds near completion. Host RAM available was approximately 359–361 GiB, memory pressure was zero, and the subsequent spatial worker was sampled waiting in `balance_dirty_pages`. The first report's host I/O pressure averaged approximately 90–92% over its trailing five-minute windows. The reports are short observations, not a complete phase profile, but they strongly indicate storage waiting.

The old implementation filled 128-gene column slices of C-order memory-mapped output arrays directly on `/stash`. Such writes revisit pages across the arrays and can interact poorly with a slow mounted filesystem. Its exact mount type was not captured; this update does not assume that `/stash` is any particular filesystem.

## Change

Build the same two float32 feature arrays in bounded RAM, then save each array once in a sequential pass to the canonical temporary filename and rename it into place. Only after outputs are complete is the completion receipt written. The GPU equations, 128-gene calculation chunks, normalization, gene selection, cell cohort, sample boundaries and downstream analysis are unchanged.

The default staging limit is 16 GiB per worker and at most half of estimated available memory divided by scheduled concurrent workers. Visible cgroup memory limits are included. If the memory budget cannot be established or is insufficient, the original disk method is used and the reason is logged. These bounds apply to output buffers, not total process peak memory.

Ada-9 needs about 1.34 GiB for the two output arrays. Four samples of that size would use about 5.37 GiB for those buffers, plus sparse inputs, graphs, chunks and other process allocations.

## GPU and CPU use

The existing scheduler already uses up to four GPUs visible to CUDA, one sample per GPU. It respects inherited CUDA/NVIDIA visibility. Four GPUs in nvidia-smi do not prove that the notebook runtime sees all four. The updated live monitor records relevant masks without changing them. CPU neighbor work retains eight workers; increasing this is not the first response to recorded storage waits.

## Cache compatibility and timing

Execution settings are excluded from the old numerical sample fingerprint. Compatible completed spatial features, pooled statistics and embeddings can be reused. A cached sample is not recomputed to test speed; its old timing remains visible. Newly executed samples record load, graph, CSC conversion, gene computation/host transfer, persistence and hashing phases, and print throttled progress.

The global observation of lower write contention must still be measured on the user's server. This release does not promise a specific speedup or a one-hour completion time. Downstream PCA/statistics still read the persisted feature files and could need a later local-storage optimization if profiling identifies repeated reads as expensive.

## Monitor the existing run

Use the separate updated `08U_live_status.py` in a JupyterLab terminal. Its default follows active samples automatically. It collects completed sibling sample timings and relevant filesystem/GPU metadata using bounded read-only checks. It does not change the running notebook or allocate GPUs.

## References

- Linux PSI: https://docs.kernel.org/accounting/psi.html
- Dirty-page writeback: https://docs.kernel.org/admin-guide/sysctl/vm.html
- CUDA_VISIBLE_DEVICES: https://docs.nvidia.com/cuda/cuda-programming-guide/05-appendices/environment-variables.html

See VALIDATION.json for the checks actually run and limitations.
