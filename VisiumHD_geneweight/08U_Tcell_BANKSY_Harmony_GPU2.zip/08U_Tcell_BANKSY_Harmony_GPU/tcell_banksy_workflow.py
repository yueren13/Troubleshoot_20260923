"""08U notebook orchestration, isolated GPU workers, and resumable experiments."""
from __future__ import annotations

import gc
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import zipfile

import numpy as np
import pandas as pd
import scipy.sparse as sp

import tcell_weighted_workflow as base
import tcell_weighted_gpu as shared
import tcell_banksy_math as bm
import tcell_banksy_sources as sources
import tcell_banksy_cuda_probe as cuda_probe

# Execution/storage updates preserve the numerical and completed-cache identity.
VERSION = "08U-banksy-workflow-1.0.0"
RELEASE_VERSION = "1.1.0"
HELDOUT_GENES = sources.HELDOUT_GENES
DEFAULT_GPU_SETTINGS = dict(shared.DEFAULT_SETTINGS, pca_power_iter=2)


def _read(path):
    return json.loads(Path(path).read_text())


def _devices(runtime):
    count = int(runtime["visible_device_count"])
    if count < 1:
        raise ValueError("08U needs the working RAPIDS GPU kernel.")
    return list(range(min(count, 4)))


def _diagnostic_zip(directory, exc=None):
    directory = Path(directory)
    if exc is not None:
        shared.atomic_json(directory / "failure.json", {"type": type(exc).__name__,
            "message": str(exc), "traceback": traceback.format_exc()})
    dest = directory / "08U_diagnostics.zip"
    temp = dest.with_suffix(".zip.partial")
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(directory.rglob("*")):
            if path.is_file() and path.suffix in (".json", ".log") and path.stat().st_size < 4_000_000:
                archive.write(path, path.relative_to(directory))
    os.replace(temp, dest)
    return dest


def _last_json_object(log_path):
    """Read the final structured report without treating earlier stages as success."""
    path = Path(log_path)
    if not path.is_file():
        return None
    for line in reversed(path.read_text(errors="replace").splitlines()):
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    return None


def _run_startup_child(command, log_path, *, env, timeout_seconds, label, echo=True):
    """Bound a fresh worker and retain output even on interruption or timeout."""
    path = Path(log_path)
    started = time.monotonic()
    last_heartbeat = started
    process = None
    receipt = {"stage": label, "command": list(command), "status": "starting",
               "timeout_seconds": float(timeout_seconds)}
    try:
        with path.open("w") as writer, path.open("r", errors="replace") as reader:
            process = subprocess.Popen(command, env=env, stdout=writer,
                stderr=subprocess.STDOUT, start_new_session=True)
            receipt.update(status="running", pid=process.pid)
            while True:
                chunk = reader.read()
                if chunk and echo:
                    print(chunk, end="", flush=True)
                code = process.poll()
                now = time.monotonic()
                if code is not None:
                    tail = reader.read()
                    if tail and echo:
                        print(tail, end="", flush=True)
                    receipt["status"] = "passed" if code == 0 else "failed"
                    return int(code)
                if now - started > timeout_seconds:
                    receipt["status"] = "timeout"
                    raise TimeoutError(f"{label} exceeded {timeout_seconds:g} seconds. "
                                       f"The owned worker was stopped and its output retained: {path}")
                if now - last_heartbeat > 15:
                    print(f"[08U {label}] Still running, {now-started:.0f}s elapsed.", flush=True)
                    last_heartbeat = now
                time.sleep(.1)
    except BaseException as exc:
        if receipt["status"] in ("starting", "running"):
            receipt["status"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
        receipt["error"] = {"type": type(exc).__name__, "message": str(exc)}
        raise
    finally:
        if process is not None:
            base._stop_owned(process)
            receipt["returncode"] = process.poll()
        receipt["elapsed_seconds"] = time.monotonic() - started
        shared.atomic_json(path.with_suffix(".process.json"), receipt)


def _positive_device_count(report):
    count = report.get("visible_device_count") if isinstance(report, dict) else None
    return isinstance(count, int) and not isinstance(count, bool) and count > 0


def preflight(helper_dir, *, log_dir=None, timeout_seconds=600, gpu_probe_timeout_seconds=45):
    """Check real CUDA access before importing BANKSY/Scanpy/RAPIDS in a worker.

    Only a whitelist of parent environment settings is collected in the
    notebook process. CuPy and all CUDA calls run in bounded fresh processes
    using this kernel's executable and its unchanged GPU visibility settings.
    The probe neither allocates workspace GPUs nor edits driver/container masks.
    """
    for name, value in (("timeout_seconds", timeout_seconds),
                        ("gpu_probe_timeout_seconds", gpu_probe_timeout_seconds)):
        if not np.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and positive.")
    directory = Path(log_dir or Path.cwd() / "08U_diagnostics").resolve()
    directory.mkdir(parents=True, exist_ok=True)
    helper = Path(helper_dir).resolve() / "tcell_banksy_gpu.py"
    probe_helper = Path(helper_dir).resolve() / "tcell_banksy_cuda_probe.py"
    log = directory / "preflight.log"
    probe_log = directory / "cuda_probe.log"
    runtime_path = directory / "preflight_report.json"
    # Replace only this check's managed records. A later successful attempt
    # must not package an obsolete failure from a previous invocation.
    for name in ("failure.json", "preflight.log", "preflight.process.json", "cuda_probe.log",
                 "cuda_probe.process.json", "cuda_probe.json", "parent_system.json",
                 "gpu_visibility_summary.json", "notebook_failure.txt", "08U_diagnostic.json"):
        (directory / name).unlink(missing_ok=True)
    report = {"status": "starting", "stage": "parent_context", "python_executable": sys.executable,
              "helper": str(helper), "probe_helper": str(probe_helper), "version": VERSION,
              "release_version": RELEASE_VERSION, "timeout_seconds": float(timeout_seconds),
              "gpu_probe_timeout_seconds": float(gpu_probe_timeout_seconds),
              "biological_data_loaded_by_check": False}
    started = time.monotonic()
    shared.atomic_json(runtime_path, report)
    print("Checking CUDA access first in", sys.executable, flush=True)
    try:
        parent = cuda_probe.collect_system_snapshot(include_commands=False)
        report["parent_system"] = parent
        shared.atomic_json(directory / "parent_system.json", parent)
        env = base._process_env()
        report["stage"] = "cuda_probe"
        shared.atomic_json(runtime_path, report)
        code = _run_startup_child([sys.executable, str(probe_helper)], probe_log,
            env=env, timeout_seconds=gpu_probe_timeout_seconds, label="CUDA visibility probe", echo=False)
        report["returncode"] = code
        probe = _last_json_object(probe_log)
        if probe is None:
            probe = {"ok": False, "status": "invalid_probe_report", "visible_device_count": None,
                     "error": {"type": "MissingProbeReport", "message":
                               f"CUDA probe exited with status {code} without a complete JSON report."}}
        report["gpu_probe"] = probe
        shared.atomic_json(directory / "cuda_probe.json", probe)
        summary = cuda_probe.summarize_probe(probe, {"system": parent})
        report["gpu_visibility_summary"] = summary
        shared.atomic_json(directory / "gpu_visibility_summary.json", summary)
        print("[08U CUDA] " + str(summary["headline"]), flush=True)
        if code != 0 or probe.get("ok") is not True or not _positive_device_count(probe):
            for line in summary.get("findings", []):
                print("  " + str(line), flush=True)
            for line in summary.get("next_steps", []):
                print("  Next: " + str(line), flush=True)
            error = probe.get("error") or {}
            detail = str(error.get("message", "CUDA was not usable in the fresh worker."))
            raise RuntimeError(f"{summary['headline']}\n{detail}\n"
                "The check stopped before BANKSY/RAPIDS imports and biological data loading. "
                "Inspect the active workspace GPU allocation and the captured visibility/driver report. "
                "A GPU-named Python environment does not by itself allocate a GPU.")

        print("CUDA is usable. Continuing with BANKSY numerical and full RAPIDS checks.", flush=True)
        report["stage"] = "banksy_rapids_preflight"
        shared.atomic_json(runtime_path, report)
        code = _run_startup_child([sys.executable, str(helper), "--stage", "preflight"], log,
            env=env, timeout_seconds=timeout_seconds, label="BANKSY/RAPIDS preflight", echo=True)
        report["returncode"] = code
        if code:
            tail = log.read_text(errors="replace").splitlines()[-16:]
            raise RuntimeError(f"BANKSY/RAPIDS preflight exited with status {code} after the early CUDA probe passed. "
                "The CUDA probe and full traceback are both retained.\n" + "\n".join(tail))
        parsed = _last_json_object(log)
        if (parsed is None or parsed.get("ok") is not True or not _positive_device_count(parsed)
                or parsed.get("banksy_streamed_gpu_check") != "passed"
                or not isinstance(parsed.get("banksy_equivalence"), dict)
                or parsed["banksy_equivalence"].get("passed") is not True):
            raise RuntimeError("Startup did not return a complete BANKSY/RAPIDS success report; "
                               "the early CUDA probe alone does not certify the full analysis path.")
        report.update(status="passed", stage="complete", runtime=parsed)
        return dict(parsed, startup_release=RELEASE_VERSION, cuda_probe=probe,
                    diagnostic_dir=str(directory), preflight_report_path=str(runtime_path),
                    preflight_log_path=str(log), cuda_probe_report_path=str(directory / "cuda_probe.json"))
    except BaseException as exc:
        process_name = ("cuda_probe.process.json" if report.get("stage") == "cuda_probe"
                        else "preflight.process.json")
        process_path = directory / process_name
        if process_path.is_file():
            process_report = _read(process_path)
            report["returncode"] = process_report.get("returncode")
            report["failed_process"] = process_report
        report.update(status=("interrupted" if isinstance(exc, KeyboardInterrupt)
                              else "timeout" if isinstance(exc, TimeoutError) else "failed"),
                      error={"type": type(exc).__name__, "message": str(exc)})
        shared.atomic_json(runtime_path, report)
        exc.diagnostic_zip = _diagnostic_zip(directory, exc)
        print("Return this startup diagnostic ZIP:", exc.diagnostic_zip, flush=True)
        raise
    finally:
        report["elapsed_seconds"] = time.monotonic() - started
        shared.atomic_json(runtime_path, report)
        _diagnostic_zip(directory)


def _run_jobs(jobs, runtime, *, max_minutes=0):
    """One isolated child per visible GPU; stop only children owned by this call."""
    pending = list(jobs)
    available = _devices(runtime)
    active = {}
    completed = {}
    readers = []
    started = time.monotonic()
    last_heartbeat = started
    try:
        while pending or active:
            while pending and available:
                job = pending.pop(0)
                device = available.pop(0)
                directory = Path(job["log_dir"])
                directory.mkdir(parents=True, exist_ok=True)
                log = directory / "console.log"
                writer = log.open("w")
                try:
                    process = subprocess.Popen(job["command"], env=base._process_env(device),
                        stdout=writer, stderr=subprocess.STDOUT, start_new_session=True)
                except BaseException:
                    writer.close()
                    raise
                reader = log.open("r", errors="replace")
                readers.append(reader)
                active[job["name"]] = dict(job=job, process=process, device=device,
                                           writer=writer, reader=reader, log=log)
                print(f"[08U] Started {job['name']} on visible GPU {device}.", flush=True)
            elapsed = time.monotonic() - started
            if max_minutes and elapsed > max_minutes * 60:
                raise TimeoutError(f"08U compute reached {max_minutes:g} minutes. Completed per-sample/PCA/graph checkpoints remain available for Run All to resume.")
            for name, state in list(active.items()):
                chunk = state["reader"].read()
                if chunk:
                    for line in chunk.splitlines():
                        print(f"[{name}] {line}", flush=True)
                code = state["process"].poll()
                if code is not None:
                    state["writer"].close()
                    tail = state["reader"].read()
                    if tail:
                        print(tail, end="", flush=True)
                    if code:
                        raise RuntimeError(f"08U worker {name!r} exited with status {code}. Log: {state['log']}")
                    receipt = Path(state["job"]["receipt"])
                    if not receipt.is_file():
                        raise RuntimeError(f"08U worker {name!r} exited without its completion record: {receipt}")
                    completed[name] = receipt
                    available.append(state["device"])
                    del active[name]
            if time.monotonic() - last_heartbeat > 30:
                print(f"[08U] {elapsed/60:.1f} min; active: {', '.join(active)}; "
                      f"{len(completed)} finished; {len(pending)} queued.", flush=True)
                last_heartbeat = time.monotonic()
            if active:
                time.sleep(.5)
        return completed, time.monotonic() - started
    finally:
        for state in active.values():
            base._stop_owned(state["process"])
            state["writer"].close()
        for reader in readers:
            reader.close()


def prepare_experiment(cache_dir, helper_dir, runtime, *, spatial_weight=.2,
                       k_geom=15, row_chunk_size=4096, gene_chunk_size=128,
                       gpu_settings=None, resume=True, spatial_execution=None):
    """Cache same-sample tissue context once, then define the four paired arms."""
    cache = Path(cache_dir).resolve()
    source = _read(cache / "cache_manifest.json")
    if not 0 < float(spatial_weight) < 1:
        raise ValueError("spatial_weight must be strictly between zero and one.")
    if int(k_geom) != k_geom or k_geom < 1:
        raise ValueError("k_geom must be a positive integer.")
    cfg = shared.validate_settings(gpu_settings or DEFAULT_GPU_SETTINGS)
    # These settings affect execution only. In particular they must not enter
    # the legacy sample fingerprint or invalidate already completed features.
    execution = {"output_staging": "auto", "max_ram_gib": 16.0}
    if spatial_execution is not None:
        unknown = set(spatial_execution) - set(execution)
        if unknown:
            raise ValueError(f"Unknown spatial execution settings: {sorted(unknown)}")
        execution.update(spatial_execution)
    if execution["output_staging"] not in ("auto", "ram", "disk"):
        raise ValueError("output_staging must be auto, ram, or disk.")
    cap = execution["max_ram_gib"]
    if isinstance(cap, bool) or not np.isfinite(float(cap)) or float(cap) <= 0:
        raise ValueError("max_ram_gib must be positive and finite.")
    execution["max_ram_gib"] = float(cap)
    execution["concurrent_workers"] = max(1, min(len(_devices(runtime)), len(source["samples"])))
    print(f"[08U] Spatial workers: up to {execution['concurrent_workers']} across "
          f"{int(runtime['visible_device_count'])} CUDA-visible GPUs; "
          f"output staging={execution['output_staging']}, RAM cap="
          f"{execution['max_ram_gib']:g} GiB per worker.", flush=True)
    helper = Path(helper_dir).resolve() / "tcell_banksy_gpu.py"
    math_version = getattr(bm, "VERSION", getattr(bm, "ENGINE_VERSION", "unknown"))
    spatial_id = base._digest({"source_cache_id": source["cache_id"], "k_geom": int(k_geom),
                               "math_version": math_version, "version": VERSION})[:20]
    spatial_dir = cache.parent / "spatial" / spatial_id
    spatial_dir.mkdir(parents=True, exist_ok=True)
    genes = source["genes"]
    jobs, spec_paths = [], []
    for number, sample in enumerate(source["samples"]):
        out = spatial_dir / f"sample_{number:02d}"
        out.mkdir(parents=True, exist_ok=True)
        job = {"sample_id": sample["sample_id"], "matrix_path": sample["x_tissue_path"],
               "coords_path": sample["coords_path"],
               "focal_local_rows_path": sample["focal_local_rows_path"],
               "focal_global_rows_path": sample["focal_global_rows_path"],
               "output_dir": str(out), "k_geom": int(k_geom), "gene_chunk_size": int(gene_chunk_size),
               "gene_names": genes, "source_cache_id": source["cache_id"], "math_version": math_version}
        job["job_fingerprint"] = base._digest({**job, "source_signatures":
            [base._signature(job[key]) for key in ("matrix_path", "coords_path", "focal_local_rows_path", "focal_global_rows_path")]})
        job["spatial_execution"] = dict(execution)
        job_path = out / "job.json"
        shared.atomic_json(job_path, job)
        spec_path = out / "spatial_spec.json"
        spec_paths.append(spec_path)
        compatible = False
        if resume and spec_path.is_file():
            old = _read(spec_path)
            if old.get("job_fingerprint") == job["job_fingerprint"]:
                try:
                    compatible = all(Path(old[key]).is_file() for key in
                                     ("mean_path", "gradient_path", "global_rows_path"))
                except KeyError:
                    pass
        if compatible:
            print(f"[08U] Reusing physical-neighborhood features: {sample['sample_id']}", flush=True)
        else:
            jobs.append({"name": f"spatial_{number:02d}_{sample['sample_id']}",
                "log_dir": str(out), "receipt": str(spec_path),
                "command": [sys.executable, str(helper), "--stage", "spatial", "--job", str(job_path)]})
    try:
        _, spatial_seconds = _run_jobs(jobs, runtime)
        specs = [_read(path) for path in spec_paths]
        statistics_path = spatial_dir / "block_statistics.npz"
        statistics_receipt = spatial_dir / "statistics_complete.json"
        statistics_fp = base._digest({"source": source["cache_id"], "version": math_version,
            "specs": [{k: spec.get(k) for k in ("context_sha256", "job_fingerprint")} for spec in specs],
            "outputs": [base._signature(spec[key]) for spec in specs
                        for key in ("mean_path", "gradient_path", "global_rows_path")]})
        compatible_stats = (resume and statistics_path.is_file() and statistics_receipt.is_file()
            and _read(statistics_receipt).get("fingerprint") == statistics_fp
            and _read(statistics_receipt).get("size") == statistics_path.stat().st_size)
        if not compatible_stats:
            print("[08U] Standardizing BANKSY blocks across the complete T-cell population.", flush=True)
            own = sp.load_npz(source["focal_own_path"]).tocsr()
            stats = bm.fit_block_statistics(own, specs, row_chunk_size=row_chunk_size, gene_names=genes)
            bm.save_block_statistics(stats, statistics_path)
            shared.atomic_json(statistics_receipt, {"fingerprint": statistics_fp,
                               "size": statistics_path.stat().st_size})
            del own, stats
            gc.collect()
        arms = {
            "banksy_lam0": {"lambda": 0., "heldout": False},
            "banksy_lam02": {"lambda": float(spatial_weight), "heldout": False},
            "heldout_lam0": {"lambda": 0., "heldout": True},
            "heldout_lam02": {"lambda": float(spatial_weight), "heldout": True},
        }
        identity = base._digest({"source": source["cache_id"], "statistics": statistics_fp,
            "arms": arms, "settings": cfg, "version": VERSION, "math_version": math_version})
        run_dir = cache.parent / "runs" / identity[:20]
        run_dir.mkdir(parents=True, exist_ok=True)
        experiment = {"version": VERSION, "experiment_id": identity,
            "run_dir": str(run_dir), "cache_dir": str(cache), "n_cells": source["n_cells"],
            "n_features": source["n_features"], "n_tissue_cells": source["n_tissue_cells"],
            "source_manifest_path": str(cache / "cache_manifest.json"),
            "spatial_dir": str(spatial_dir), "spatial_specs": specs,
            "statistics_path": str(statistics_path), "statistics_fingerprint": statistics_fp,
            "row_chunk_size": int(row_chunk_size), "k_geom": int(k_geom),
            "spatial_weight": float(spatial_weight), "heldout_genes": list(HELDOUT_GENES),
            "gpu_settings": cfg, "arms": arms, "spatial_seconds_this_run": spatial_seconds,
            "runtime": runtime, "all_08O_cells_retained": True,
            "spatial_execution_this_run": dict(execution),
            "normalization": "original full-library log1p 10000; pooled per-gene block z scores",
            "interpretation": "Full-tissue BANKSY context for fixed T-cell focal rows; no corrected molecule counts.",
            "cell_order_sha256": source["cell_order_sha256"],
            "source_scope_by_sample": {s["sample_id"]: s["source_scope"] for s in source["samples"]}}
        shared.atomic_json(run_dir / "experiment.json", experiment)
        print(f"[08U] Four matched variants ready: {source['n_cells']:,} focal T cells, "
              f"{source['n_tissue_cells']:,} tissue context cells.", flush=True)
        return experiment
    except BaseException as exc:
        exc.diagnostic_zip = _diagnostic_zip(spatial_dir, exc)
        print("Return this spatial-stage diagnostic ZIP:", exc.diagnostic_zip, flush=True)
        raise


def launch_experiment(experiment, helper_dir, runtime, *, resume=True, max_minutes=110):
    """GPU PCA/Harmony/neighbors/Leiden/UMAP; up to four independent workers."""
    run_dir = Path(experiment["run_dir"])
    helper = Path(helper_dir).resolve() / "tcell_banksy_gpu.py"
    experiment_path = run_dir / "experiment.json"
    jobs = []
    for name in experiment["arms"]:
        command = [sys.executable, str(helper), "--stage", "branch", "--experiment",
                   str(experiment_path), "--branch", name]
        if not resume:
            command.append("--no-resume")
        jobs.append({"name": name, "command": command, "log_dir": str(run_dir / name),
                     "receipt": str(run_dir / name / "completion.json")})
    shared.atomic_json(run_dir / "launch.json", {"devices": _devices(runtime),
        "python_executable": sys.executable, "max_minutes": max_minutes,
        "experiment_id": experiment["experiment_id"]})
    try:
        completed, elapsed = _run_jobs(jobs, runtime, max_minutes=max_minutes)
        branches = {}
        for name, receipt in completed.items():
            info = _read(receipt)
            path = Path(info["embedding_path"])
            if info.get("status") != "complete" or not path.is_file():
                raise RuntimeError(f"Incomplete {name} result: {receipt}")
            branches[name] = path
        shared.atomic_json(run_dir / "comparison_complete.json", {"branches": branches,
            "elapsed_seconds": elapsed, "experiment_id": experiment["experiment_id"]})
        return branches, elapsed
    except BaseException as exc:
        exc.diagnostic_zip = _diagnostic_zip(run_dir, exc)
        print("Return this clustering diagnostic ZIP:", exc.diagnostic_zip, flush=True)
        raise


def load_methods(branches, obs):
    import anndata as ad
    methods, manifests = {}, {}
    for name, path in branches.items():
        data = ad.read_h5ad(path)
        if not np.array_equal(data.obs_names.astype(str), obs.index.astype(str)):
            raise ValueError(f"{name}: embedding cell order differs from original counts.")
        if data.uns.get("08u_stage") != "complete" or not any(
                key in data.uns for key in ("banksy_manifest", "banksy_manifest_json")):
            raise ValueError(f"{name}: missing completed BANKSY provenance.")
        methods[name] = data
        manifests[name] = _read(Path(path).parent / "feature_manifest.json")
    return methods, manifests


def resource_estimate(manifest, *, row_chunk_size=4096, n_pcs=50, oversamples=20):
    n, g = int(manifest["n_cells"]), int(manifest["n_features"])
    width = n_pcs + oversamples
    return {
        "n_focal_cells": n, "n_tissue_cells": manifest["n_tissue_cells"], "n_genes": g,
        "spatial_float32_cache_GiB": 2 * n * g * 4 / 2**30,
        "avoided_combined_dense_BANKSY_GiB": 3 * n * g * 4 / 2**30,
        "one_streamed_block_chunk_MiB": row_chunk_size * g * 4 / 2**20,
        "one_thin_PCA_array_MiB": n * width * 4 / 2**20,
        "note": "Array sizes only; exclude temporary workspace, sparse matrices, graph, Harmony and allocator overhead. Not a measured peak or runtime guarantee."}
