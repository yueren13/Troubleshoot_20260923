"""Conservative, read-only RAM staging decisions for 08U spatial features.

Only host MemAvailable and visible cgroup-v2 memory limits are consulted.
Missing or ambiguous resource information selects the original disk strategy.
This module never changes limits, visibility masks, filesystems, or processes.
"""
from __future__ import annotations

import math
from pathlib import Path
import re


def _read(path):
    try:
        return Path(path).read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return None


def _unescape_mount(value):
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), value)


def memory_snapshot(*, proc_root="/proc"):
    """Return a conservative available-memory budget, or ``known=False``.

    The minimum remaining capacity across the process's visible cgroup-v2
    ancestry is combined with host MemAvailable. Limits above a namespace's
    mount root cannot be observed and are explicitly outside this snapshot.
    """
    proc = Path(proc_root)
    result = {"known": False, "host_available_bytes": None,
              "effective_available_bytes": None, "cgroup_ancestors": [],
              "scope": "host MemAvailable and visible cgroup-v2 ancestors"}
    meminfo = _read(proc / "meminfo")
    try:
        available = next(int(line.split()[1]) * 1024 for line in (meminfo or "").splitlines()
                         if line.startswith("MemAvailable:"))
        if available < 0:
            raise ValueError("negative MemAvailable")
    except (StopIteration, ValueError, IndexError):
        return dict(result, reason="Host MemAvailable could not be read.")
    result["host_available_bytes"] = available
    membership = _read(proc / "self" / "cgroup")
    paths = [line.split("::", 1)[1] for line in (membership or "").splitlines()
             if line.startswith("0::")]
    if len(paths) != 1 or not paths[0].startswith("/") or ".." in Path(paths[0]).parts:
        return dict(result, reason="The process's cgroup-v2 membership could not be resolved.")
    group = Path(paths[0])
    mounts = []
    for line in (_read(proc / "self" / "mountinfo") or "").splitlines():
        before, sep, after = line.partition(" - ")
        fields = before.split()
        if not sep or not after.startswith("cgroup2 ") or len(fields) < 5:
            continue
        root, mount = Path(_unescape_mount(fields[3])), Path(_unescape_mount(fields[4]))
        try:
            relative = group.relative_to(root)
        except ValueError:
            # A cgroup namespace reports '/' for its own root even when
            # mountinfo exposes a non-root host cgroup as the mount root.
            if group == Path("/"):
                relative = Path(".")
            else:
                continue
        current = mount / relative
        if ".." not in current.parts:
            mounts.append((mount, current))
    if len(mounts) != 1:
        return dict(result, reason="A unique readable cgroup-v2 mount could not be resolved.")
    mount, current = mounts[0]
    effective = available
    node = current
    while True:
        limit_text, usage_text = _read(node / "memory.max"), _read(node / "memory.current")
        if limit_text is None or usage_text is None:
            return dict(result, reason=f"Visible cgroup memory accounting is unavailable at {node}.")
        try:
            usage = int(usage_text.strip())
            limit = None if limit_text.strip() == "max" else int(limit_text.strip())
            if usage < 0 or (limit is not None and limit < 0):
                raise ValueError("negative memory accounting")
        except ValueError:
            return dict(result, reason=f"Visible cgroup memory accounting is invalid at {node}.")
        remaining = max(0, limit - usage) if limit is not None else None
        if remaining is not None:
            effective = min(effective, remaining)
        result["cgroup_ancestors"].append({"path": str(node), "limit_bytes": limit,
                                          "current_bytes": usage, "remaining_bytes": remaining})
        if node == mount:
            break
        parent = node.parent
        if parent == node or mount not in (parent, *parent.parents):
            return dict(result, reason="Cgroup ancestry escaped its visible mount.")
        node = parent
    result.update(known=True, effective_available_bytes=int(effective),
                  reason="Host and visible cgroup-v2 memory accounting were read.")
    return result


def staging_decision(output_bytes, *, mode="auto", max_ram_gib=16.0,
                     concurrent_workers=1, snapshot=None):
    """Choose RAM only below both the fixed and shared-available-memory caps.

    ``auto`` falls back to legacy disk memmaps if a budget is unknown or too
    small. ``ram`` is a strict diagnostic request and still enforces every
    bound. No additional cell-by-all-gene dense matrix is included in staging.
    """
    if mode not in ("auto", "ram", "disk"):
        raise ValueError("output_staging must be 'auto', 'ram', or 'disk'.")
    if isinstance(output_bytes, bool) or int(output_bytes) != output_bytes or output_bytes < 0:
        raise ValueError("output_bytes must be a nonnegative integer.")
    if isinstance(concurrent_workers, bool) or int(concurrent_workers) != concurrent_workers or concurrent_workers < 1:
        raise ValueError("concurrent_workers must be a positive integer.")
    if isinstance(max_ram_gib, bool) or not math.isfinite(float(max_ram_gib)) or float(max_ram_gib) <= 0:
        raise ValueError("max_ram_gib must be finite and positive.")
    info = memory_snapshot() if snapshot is None else dict(snapshot)
    cap = int(float(max_ram_gib) * 2**30)
    shared = (int(info["effective_available_bytes"]) // (2 * int(concurrent_workers))
              if info.get("known") and info.get("effective_available_bytes") is not None else None)
    safe = shared is not None and int(output_bytes) <= min(cap, shared)
    selected = "ram" if mode != "disk" and safe else "disk"
    reason = ("Explicit legacy disk staging." if mode == "disk" else
              "Both float32 output arrays fit the conservative RAM staging budget." if safe else
              "RAM budget is unknown or insufficient; retaining legacy disk memmaps.")
    result = {"requested": mode, "selected": selected, "output_pair_bytes": int(output_bytes),
              "max_ram_bytes_per_worker": cap, "concurrent_workers": int(concurrent_workers),
              "shared_budget_bytes_per_worker": shared, "available_fraction": 0.5,
              "reason": reason, "memory_snapshot": info}
    if mode == "ram" and not safe:
        raise MemoryError("RAM staging was explicitly requested but failed the conservative memory guard: " + reason)
    return result
