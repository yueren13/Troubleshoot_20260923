"""Small read-only CUDA visibility check for the 08U startup supervisor.

All imports at module load are from the Python standard library.  Run the full
probe in a fresh, supervised process: CuPy import and CUDA driver calls do not
provide an internal Python timeout.  The supervisor must bound that process.
The two nvidia-smi commands have individual timeouts and use no shell.

This module never installs packages, changes GPU visibility, resets CUDA, or
imports BANKSY, RAPIDS, Torch, Scanpy, or the biological source data.
"""
from __future__ import annotations

import argparse
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timezone
import glob
import importlib
import io
import json
import math
import os
import shutil
import subprocess
import sys
import time
import traceback
from typing import Any, Mapping


PROBE_VERSION = "08U-cuda-visibility-probe-1.0.0"
GPU_ENV_KEYS = (
    "CUDA_VISIBLE_DEVICES",
    "NVIDIA_VISIBLE_DEVICES",
    "NVIDIA_DRIVER_CAPABILITIES",
    "CUDA_DEVICE_ORDER",
)
COMMAND_OUTPUT_LIMIT = 12_000


def _bounded_text(value, limit=COMMAND_OUTPUT_LIMIT):
    if value is None:
        return ""
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    value = str(value)
    return value if len(value) <= limit else value[:limit] + "\n[output truncated]"


def _environment():
    # None means unset; the empty string is materially different for visibility.
    return {key: os.environ.get(key) for key in GPU_ENV_KEYS}


def _run_command(command, timeout_seconds):
    started = time.monotonic()
    result = {"command": list(command), "timeout_seconds": float(timeout_seconds)}
    try:
        completed = subprocess.run(
            command, shell=False, capture_output=True, text=True,
            encoding="utf-8", errors="replace", check=False,
            timeout=float(timeout_seconds),
        )
        result.update(status="ok" if completed.returncode == 0 else "failed",
                      returncode=int(completed.returncode),
                      stdout=_bounded_text(completed.stdout), stderr=_bounded_text(completed.stderr))
    except subprocess.TimeoutExpired as exc:
        result.update(status="timeout", returncode=None,
                      stdout=_bounded_text(exc.stdout), stderr=_bounded_text(exc.stderr))
    except OSError as exc:
        result.update(status="unavailable", returncode=None, stdout="",
                      stderr=f"{type(exc).__name__}: {exc}")
    result["elapsed_seconds"] = time.monotonic() - started
    return result


def collect_system_snapshot(*, include_commands=True, command_timeout_seconds=10.0):
    """Read only the interpreter, four GPU settings, device paths, and NVML CLI.

    No Python GPU package is imported.  ``nvidia-smi`` reports driver-visible
    devices; its success alone does not prove that this Python process can use
    CUDA.  Device-node names and access flags are recorded without reading them.
    """
    if (isinstance(command_timeout_seconds, bool)
            or not math.isfinite(float(command_timeout_seconds))
            or float(command_timeout_seconds) <= 0):
        raise ValueError("command_timeout_seconds must be positive and finite.")
    if not isinstance(include_commands, bool):
        raise ValueError("include_commands must be a boolean.")
    binary = shutil.which("nvidia-smi")
    smi = {"available": binary is not None, "path": binary, "list": None, "query": None,
           "commands_executed": bool(include_commands and binary is not None),
           "interpretation": "Driver visibility only; a successful CUDA arithmetic test is required for Python GPU usability."}
    if binary is not None and include_commands:
        smi["list"] = _run_command([binary, "-L"], command_timeout_seconds)
        smi["query"] = _run_command(
            [binary, "--query-gpu=index,uuid,name,driver_version,memory.total,memory.free", "--format=csv,noheader,nounits"],
            command_timeout_seconds,
        )
    nodes = []
    for path in sorted(glob.glob("/dev/nvidia*")):
        nodes.append({"path": path, "exists": os.path.exists(path),
                      "readable": os.access(path, os.R_OK),
                      "writable": os.access(path, os.W_OK)})
    return {
        "python_executable": sys.executable,
        "python_prefix": sys.prefix,
        "python_version": sys.version,
        "pid": os.getpid(),
        "cuda_test_performed": False,
        "cuda_status": "not_tested_in_this_process",
        "gpu_environment": _environment(),
        "nvidia_smi": smi,
        "device_nodes": nodes,
    }


def _error_record(exc):
    status = getattr(exc, "status", None)
    try:
        status = int(status) if status is not None else None
    except (ValueError, TypeError, OverflowError):
        status = str(status)
    return {"type": type(exc).__name__, "message": str(exc), "status": status,
            "traceback": _bounded_text("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)), 20_000)}


def _is_no_device(exc):
    return (getattr(exc, "status", None) == 100
            or "cudaErrorNoDevice" in str(exc)
            or "no CUDA-capable device" in str(exc))


def probe_cuda(*, include_system=True, include_commands=True, command_timeout_seconds=10.0):
    """Discover visible CUDA devices and execute a tiny synchronized GPU sum.

    Expected failures return structured evidence rather than raising.  The full
    call must run inside a separately supervised child to enforce an overall
    timeout; no timeout can be promised for a CUDA call in the notebook kernel.
    """
    started = time.monotonic()
    report = {"probe_version": PROBE_VERSION, "ok": False, "status": "starting",
              "stage": "system_snapshot", "visible_device_count": None,
              "started_utc": datetime.now(timezone.utc).isoformat(), "cuda": {}}
    if include_system:
        report["system"] = collect_system_snapshot(include_commands=include_commands,
                                                   command_timeout_seconds=command_timeout_seconds)
    else:
        report["system"] = {"python_executable": sys.executable, "python_prefix": sys.prefix,
                            "python_version": sys.version, "pid": os.getpid(),
                            "gpu_environment": _environment()}
    output = io.StringIO()
    try:
        report["stage"] = "import_cupy"
        with redirect_stdout(output), redirect_stderr(output):
            cp = importlib.import_module("cupy")
        report["cuda"]["cupy_version"] = str(getattr(cp, "__version__", "unknown"))
        report["stage"] = "device_discovery"
        count = int(cp.cuda.runtime.getDeviceCount())
        report["visible_device_count"] = count
        if count < 1:
            report.update(status="no_device", stage="device_discovery")
            report["error"] = {"type": "NoVisibleCUDADevice", "message": "CuPy reports zero CUDA-visible devices.",
                               "status": 100, "traceback": ""}
            return report
        report["stage"] = "gpu_arithmetic"
        with cp.cuda.Device(0):
            properties = cp.cuda.runtime.getDeviceProperties(0)
            name = properties.get("name", "unknown")
            if isinstance(name, bytes):
                name = name.decode("utf-8", errors="replace")
            report["cuda"].update(logical_device=0, device_name=str(name))
            values = cp.arange(8, dtype=cp.float32)
            result = float(cp.sum(values * values).item())
            cp.cuda.get_current_stream().synchronize()
            if result != 140.0:
                raise ArithmeticError(f"Tiny GPU sum-of-squares check returned {result}, expected 140.0.")
            report["cuda"]["arithmetic_result"] = result
            # Version reads add context after CUDA itself has already worked.
            for label, attribute in (("runtime_version", "runtimeGetVersion"), ("driver_version", "driverGetVersion")):
                getter = getattr(cp.cuda.runtime, attribute, None)
                if callable(getter):
                    try:
                        report["cuda"][label] = int(getter())
                    except Exception as exc:
                        report["cuda"][label + "_read_error"] = f"{type(exc).__name__}: {exc}"
            del values
        report.update(ok=True, status="ready", stage="complete")
        return report
    except Exception as exc:
        report["error"] = _error_record(exc)
        if report["stage"] == "import_cupy":
            absent = isinstance(exc, ModuleNotFoundError) and getattr(exc, "name", None) == "cupy"
            report["status"] = "cupy_missing" if absent else "cupy_import_failed"
        elif report["stage"] == "device_discovery":
            report["status"] = "no_device" if _is_no_device(exc) else "cuda_discovery_failed"
        else:
            report["status"] = "cuda_execution_failed"
        return report
    finally:
        captured = output.getvalue()
        if captured:
            report["cupy_import_output"] = _bounded_text(captured, 4000)
        report["gpu_environment_after_probe"] = _environment()
        report["elapsed_seconds"] = time.monotonic() - started


def _system(report):
    if not isinstance(report, Mapping):
        return {}
    value = report.get("system", report)
    return value if isinstance(value, Mapping) else {}


def _cuda_ready(report):
    if not isinstance(report, Mapping) or report.get("ok") is not True or report.get("status") == "system_only":
        return False
    count = report.get("visible_device_count")
    return isinstance(count, int) and not isinstance(count, bool) and count > 0


def _smi_lists_gpu(system):
    smi = system.get("nvidia_smi") or {}
    listed = smi.get("list") or {}
    queried = smi.get("query") or {}
    return (listed.get("status") == "ok" and "GPU " in listed.get("stdout", "")) or (
        queried.get("status") == "ok" and bool(queried.get("stdout", "").strip()))


def summarize_probe(child, parent=None):
    """Interpret recorded evidence without claiming an unobserved root cause.

    ``parent`` may be a full probe, a ``--system-only`` report, or the direct
    output of ``collect_system_snapshot``.  A system snapshot is never treated
    as proof that the notebook kernel can run CUDA.
    """
    if not isinstance(child, Mapping):
        raise TypeError("child must be a structured probe report.")
    system = _system(child)
    parent_system = _system(parent)
    env = system.get("gpu_environment") or {}
    parent_env = parent_system.get("gpu_environment") or {}
    differences = {key: {"parent": parent_env.get(key), "child": env.get(key)}
                   for key in GPU_ENV_KEYS if parent is not None and key in parent_env and parent_env.get(key) != env.get(key)}
    parent_executable = parent_system.get("python_executable")
    child_executable = system.get("python_executable")
    same_python = (parent_executable == child_executable
                   if parent_executable is not None and child_executable is not None else None)
    findings, next_steps = [], []
    status = str(child.get("status", "unknown"))
    cuda_mask = env.get("CUDA_VISIBLE_DEVICES")
    container_mask = env.get("NVIDIA_VISIBLE_DEVICES")
    explicit_cuda_mask = cuda_mask is not None and str(cuda_mask).strip() in ("", "-1")
    explicit_container_mask = container_mask is not None and str(container_mask).strip().lower() in ("", "none", "void")
    if _cuda_ready(child):
        classification, headline = "cuda_ready", "CUDA is usable in the fresh worker."
        findings.append(f"CuPy discovered {child['visible_device_count']} visible device(s) and completed the small GPU arithmetic check.")
        next_steps.append("Continue with the BANKSY and RAPIDS preflight.")
    elif _cuda_ready(parent):
        classification, headline = "parent_child_mismatch", "The notebook and fresh worker have different CUDA usability."
        findings.append("A parent CUDA arithmetic check succeeded, but the fresh worker probe failed.")
        next_steps.append("Compare the recorded Python executable and GPU visibility settings, then correct the workspace/kernel launch configuration and restart the kernel.")
    elif status == "cupy_missing":
        classification, headline = "cupy_missing", "The selected Python environment does not provide CuPy."
        next_steps.append("Select the working UV/RAPIDS kernel used for 08T, then rerun startup.")
    elif status == "cupy_import_failed":
        classification, headline = "cupy_import_failed", "CuPy could not import in this Python environment."
        next_steps.append("Read the captured import error and compare the selected interpreter with the working 08T environment before changing packages.")
    elif explicit_cuda_mask or explicit_container_mask:
        classification, headline = "visibility_configuration", "The recorded GPU visibility configuration can hide devices."
        if explicit_cuda_mask:
            findings.append(f"CUDA_VISIBLE_DEVICES is explicitly {cuda_mask!r} in the fresh worker.")
        if explicit_container_mask:
            findings.append(f"NVIDIA_VISIBLE_DEVICES is explicitly {container_mask!r}; this can describe a container without exposed GPU devices.")
        next_steps.append("Check the workspace's GPU allocation and kernel launch settings. Correct the allocation or intended visibility setting there, then restart the workspace/kernel.")
        next_steps.append("Do not bypass an intentional scheduler/container restriction by blindly clearing the visibility variables.")
    elif status in ("timeout", "probe_timeout"):
        classification, headline = "probe_timeout", "The isolated CUDA probe did not finish within its time limit."
        next_steps.append("Inspect the probe log and workspace GPU/driver status; a CUDA initialization stall needs a healthy GPU session before the full analysis can run.")
    elif status == "cuda_execution_failed":
        classification, headline = "cuda_execution_failed", "A CUDA device was visible but could not complete a small GPU operation."
        next_steps.append("Inspect the captured CUDA error and available GPU memory/driver status in the workspace; restart the affected session after resolving that fault.")
    elif _smi_lists_gpu(system):
        classification, headline = "driver_visible_cuda_unusable", "Driver tooling sees a GPU, but this Python worker cannot use CUDA."
        findings.append("nvidia-smi visibility is not proof of usable CUDA in the Python process.")
        next_steps.append("Compare GPU visibility, driver/runtime details, and the selected interpreter in this report. If the workspace allocation is correct, the driver/container exposure needs checking.")
    elif status == "no_device":
        classification, headline = "no_cuda_device", "The fresh worker cannot see a CUDA-capable device."
        next_steps.append("Confirm that the current workspace session is running on a GPU-backed hardware tier with GPUs exposed to the container, then restart/relaunch that session and rerun startup.")
        next_steps.append("The current evidence does not establish whether allocation, visibility configuration, or driver/container state caused the missing device.")
    else:
        classification, headline = "cuda_startup_failed", "CUDA startup did not complete successfully."
        next_steps.append("Inspect the recorded CUDA error together with the workspace allocation, GPU visibility and driver/runtime diagnostics.")
    if differences:
        findings.append("The notebook snapshot and worker have different values for: " + ", ".join(differences) + ".")
    if same_python is False:
        findings.append("The notebook snapshot and worker report different Python executables.")
    error = child.get("error") or {}
    if error.get("message"):
        findings.append("Reported error: " + str(error["message"]))
    return {"classification": classification, "headline": headline,
            "findings": findings, "next_steps": next_steps,
            "gpu_usable": _cuda_ready(child), "environment_differences": differences,
            "python_executables_match": same_python}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--system-only", action="store_true")
    parser.add_argument("--no-system", action="store_true")
    parser.add_argument("--no-commands", action="store_true",
                        help="Skip nvidia-smi commands while retaining interpreter/environment metadata.")
    parser.add_argument("--command-timeout-seconds", type=float, default=10.0)
    args = parser.parse_args(argv)
    if args.system_only and args.no_system:
        parser.error("--system-only and --no-system cannot be combined.")
    if not math.isfinite(args.command_timeout_seconds) or args.command_timeout_seconds <= 0:
        parser.error("--command-timeout-seconds must be positive and finite.")
    if args.system_only:
        report = {"probe_version": PROBE_VERSION, "ok": True, "status": "system_only",
                  "system": collect_system_snapshot(include_commands=not args.no_commands,
                                                    command_timeout_seconds=args.command_timeout_seconds)}
    else:
        report = probe_cuda(include_system=not args.no_system,
                            include_commands=not args.no_commands,
                            command_timeout_seconds=args.command_timeout_seconds)
        report["summary"] = summarize_probe(report)
    print(json.dumps(report, sort_keys=True, allow_nan=False), flush=True)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
