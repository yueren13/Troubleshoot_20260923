"""Streamed BANKSY m=1 features and PCA for the 08U focal T-cell experiment.

The feature definitions were checked against the published ``pybanksy==1.3.5``
implementation (Banksy_py, ``banksy/main.py`` and ``banksy/embed_banksy.py``).
This module changes storage and numerical linear algebra, not the BANKSY
feature definition.  It does not call BANKSY's dense whole-matrix constructor.

For a focal cell i, the mean uses k nearest OTHER tissue cells.  The m=1 AGF
uses 2*k nearest OTHER tissue cells.  Each neighborhood has its own median
distance, weights exp(-(distance/median_distance)**2), and unit weight sum.
For the AGF, multiply weights by exp(1j*theta) and subtract the UNWEIGHTED
mean expression of those 2*k neighbors before taking the weighted sum's
absolute value.  There is no division by a gene's mean expression.

Every physical graph must be built within one physical sample.  The caller
supplies all retained tissue cells, and requests only the existing focal
T-cell rows.  Own, mean and gradient features are z-scored separately over
all focal rows, with population variance (ddof=0), then scaled by
sqrt(1-lambda), sqrt(2*lambda/3), and sqrt(lambda/3).  Constant / numerically
constant features are zero.  Held-out genes are excluded by the same column
mask in ALL three feature blocks before PCA.

Primary sources:
https://github.com/prabhakarlab/Banksy_py
https://pypi.org/project/pybanksy/1.3.5/
https://www.nature.com/articles/s41588-024-01664-3
"""
from __future__ import annotations

import contextlib
import gc
import hashlib
import importlib.metadata
import io
import json
import os
import time
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import numpy as np
from scipy import sparse
from scipy.spatial import cKDTree

import tcell_banksy_resources as resources


ENGINE_VERSION = "08U.1"
REFERENCE_PYBANKSY_VERSION = "1.3.5"
BLOCK_NAMES = ("own", "mean", "gradient")


def hash_strings(values: Sequence[Any]) -> str:
    """SHA256 of UTF-8 newline-joined strings; embedded newlines are rejected."""
    strings = [str(x) for x in values]
    if any("\n" in x or "\r" in x for x in strings):
        raise ValueError("Cell/gene identifiers must not contain line breaks.")
    return hashlib.sha256("\n".join(strings).encode("utf-8")).hexdigest()


def _hash_array(h: Any, value: np.ndarray) -> None:
    arr = np.ascontiguousarray(value)
    h.update(str(arr.shape).encode("ascii"))
    h.update(arr.dtype.str.encode("ascii"))
    h.update(memoryview(arr).cast("B"))


def _resolve_backend(backend: str):
    if backend not in {"cpu", "gpu", "auto"}:
        raise ValueError("backend must be 'cpu', 'gpu', or 'auto'.")
    if backend != "cpu":
        try:
            import cupy as cp

            if cp.cuda.runtime.getDeviceCount() < 1:
                raise RuntimeError("CuPy reports no visible CUDA device.")
            cp.zeros(1, dtype=cp.float32)  # Also test the active device/context.
            return cp, "gpu"
        except Exception as exc:
            if backend == "gpu":
                raise RuntimeError(
                    "GPU BANKSY requires a working CuPy CUDA context in this "
                    "notebook kernel. CPU execution was not silently substituted."
                ) from exc
    return np, "cpu"


def _to_cpu(value, xp):
    return xp.asnumpy(value) if xp is not np else np.asarray(value)


def _csr_input(matrix, name: str = "matrix") -> sparse.csr_matrix:
    if not sparse.issparse(matrix):
        raise TypeError(f"{name} must be a SciPy sparse expression matrix.")
    result = sparse.csr_matrix(matrix, copy=False)
    if not result.has_canonical_format:
        result = result.copy()
        result.sum_duplicates()
        result.sort_indices()
    if result.ndim != 2 or not np.isfinite(result.data).all():
        raise ValueError(f"{name} must have a finite two-dimensional representation.")
    return result


def _integer_rows(value, name: str, n_rows: int | None = None) -> np.ndarray:
    result = np.asarray(value)
    if result.ndim != 1 or not np.issubdtype(result.dtype, np.integer):
        raise ValueError(f"{name} must be a one-dimensional integer array.")
    result = result.astype(np.int64, copy=False)
    if not len(result) or np.any(result < 0):
        raise ValueError(f"{name} must contain at least one nonnegative row index.")
    if n_rows is not None and np.any(result >= n_rows):
        raise ValueError(f"{name} contains row indices outside the source matrix.")
    if len(np.unique(result)) != len(result):
        raise ValueError(f"{name} contains duplicate rows.")
    return result


def build_focal_spatial_weights(
    coords: np.ndarray,
    focal_local_rows: np.ndarray,
    *,
    k_geom: int = 15,
    workers: int = -1,
) -> dict[str, Any]:
    """Build rectangular focal-by-full-tissue BANKSY spatial weight matrices.

    Returns ``mean``, centered ``gradient``, ``gradient_uncentered`` CSR
    matrices and JSON-compatible diagnostics.  The centered complex matrix
    evaluates the official AGF as ``abs(gradient @ X)`` in one sparse product.
    Identical-distance neighbor ties may choose a different valid neighbor
    than sklearn's BallTree; no-self and distance ordering are enforced.
    """
    start = time.perf_counter()
    locations = np.asarray(coords, dtype=np.float64)
    if locations.ndim != 2 or locations.shape[1] != 2:
        raise ValueError("BANKSY m=1 requires physical x,y coordinates of shape (N,2).")
    if not np.isfinite(locations).all():
        raise ValueError("Spatial coordinates contain NaN or infinite values.")
    n_tissue = len(locations)
    focal = _integer_rows(focal_local_rows, "focal_local_rows", n_tissue)
    if not isinstance(k_geom, (int, np.integer)) or k_geom < 1:
        raise ValueError("k_geom must be a positive integer.")
    if n_tissue < 2:
        raise ValueError("At least two tissue cells are needed for spatial neighbors.")
    k_mean = min(int(k_geom), n_tissue - 1)
    k_gradient = min(2 * int(k_geom), n_tissue - 1)
    tree = cKDTree(locations)
    distances, neighbors = tree.query(
        locations[focal], k=k_gradient + 1, workers=workers
    )
    other = neighbors != focal[:, None]
    keep = other & (np.cumsum(other, axis=1) <= k_gradient)
    if not np.all(keep.sum(axis=1) == k_gradient):
        raise RuntimeError("Spatial neighbor query did not produce enough non-self cells.")
    distances = distances[keep].reshape(len(focal), k_gradient)
    neighbors = neighbors[keep].reshape(len(focal), k_gradient)
    if not np.isfinite(distances).all() or np.any(neighbors == focal[:, None]):
        raise RuntimeError("Spatial graph contains an invalid distance or a self edge.")

    def make_weights(k: int, phase: bool):
        d = distances[:, :k]
        nbr = neighbors[:, :k]
        medians = np.median(d, axis=1)
        bad = ~np.isfinite(medians) | (medians <= 0)
        if bad.any():
            examples = focal[np.flatnonzero(bad)[:8]].tolist()
            raise ValueError(
                "Scaled-Gaussian BANKSY weights are undefined because a spatial "
                f"neighborhood has zero median distance (focal rows {examples}). "
                "Check duplicated/rounded coordinates and sample boundaries."
            )
        values = np.exp(-np.square(d / medians[:, None]))
        values /= values.sum(axis=1, keepdims=True)
        if phase:
            delta = locations[nbr] - locations[focal, None, :]
            # Official theta_from_spatial_graph stores angles as float32.
            theta = np.arctan2(delta[:, :, 1], delta[:, :, 0]).astype(np.float32)
            values = values * np.exp(1j * theta)
        graph = sparse.csr_matrix(
            (values.ravel(), nbr.ravel(), np.arange(len(focal) + 1) * k),
            shape=(len(focal), n_tissue),
        )
        graph.sort_indices()
        return graph, medians

    mean_weights, med_mean = make_weights(k_mean, False)
    phase_weights, med_gradient = make_weights(k_gradient, True)
    gradient_weights = phase_weights.copy()
    phase_sum = np.asarray(phase_weights.sum(axis=1)).ravel()
    # For every row: sum(w_j * (x_j - mean(x))) =
    # sum((w_j - sum(w)/degree) * x_j). The mean is UNWEIGHTED.
    gradient_weights.data -= np.repeat(phase_sum / k_gradient, k_gradient)
    diagnostics = {
        "n_tissue": int(n_tissue),
        "n_focal": int(len(focal)),
        "k_geom_requested": int(k_geom),
        "k_mean_effective": k_mean,
        "k_gradient_effective": k_gradient,
        "neighbors_reduced_for_small_sample": bool(k_gradient < 2 * k_geom),
        "decay": "scaled_gaussian",
        "self_edges": 0,
        "zero_distance_edges": int(np.count_nonzero(distances == 0)),
        "mean_median_distance": float(np.median(med_mean)),
        "gradient_median_distance": float(np.median(med_gradient)),
        "gradient_farthest_distance_quantiles": {
            str(q): float(np.quantile(distances[:, -1], q))
            for q in (0, 0.5, 0.9, 0.99, 1)
        },
        "mean_row_sum_max_error": float(
            np.max(np.abs(np.asarray(mean_weights.sum(axis=1)).ravel() - 1))
        ),
        "centered_gradient_row_sum_max_abs": float(
            np.max(np.abs(np.asarray(gradient_weights.sum(axis=1)).ravel()))
        ),
        "elapsed_seconds": float(time.perf_counter() - start),
    }
    return {
        "mean": mean_weights,
        "gradient": gradient_weights,
        "gradient_uncentered": phase_weights,
        "diagnostics": diagnostics,
    }


def compute_sample_spatial_blocks(
    X_tissue,
    coords: np.ndarray,
    focal_local_rows: np.ndarray,
    focal_global_rows: np.ndarray,
    output_dir: str | Path,
    sample_id: str,
    *,
    k_geom: int = 15,
    backend: str = "auto",
    gene_chunk_size: int = 128,
    gene_names: Sequence[str] | None = None,
    workers: int = -1,
    progress: Callable[[str], None] | None = None,
    output_staging: str = "auto",
    max_ram_gib: float = 16.0,
    concurrent_workers: int = 1,
) -> dict[str, Any]:
    """Compute one sample's focal mean/AGF feature memmaps in gene chunks.

    ``X_tissue`` is the full-tissue selected-gene sparse matrix normalized
    using original full-library sizes and log1p, before this call.  Neither
    counts nor own expression is changed. The input workspace is one gene
    chunk. The two focal output arrays may be staged in RAM when a conservative
    resource check allows it, then written sequentially; otherwise the original
    disk memmaps are used. The returned spec can be serialized as JSON and
    passed to ``BanksyBlockOperator`` in another process.
    """
    start = time.perf_counter()
    X = _csr_input(X_tissue, "X_tissue")
    if np.any(X.data < 0):
        raise ValueError("BANKSY inputs here must be nonnegative normalized expression.")
    coords = np.asarray(coords, dtype=np.float64)
    if len(coords) != X.shape[0]:
        raise ValueError("Coordinate rows and full-tissue expression rows do not match.")
    local_rows = _integer_rows(focal_local_rows, "focal_local_rows", X.shape[0])
    global_rows = _integer_rows(focal_global_rows, "focal_global_rows")
    if len(local_rows) != len(global_rows):
        raise ValueError("Local/global focal row mappings must have the same length.")
    if not isinstance(gene_chunk_size, int) or gene_chunk_size < 1:
        raise ValueError("gene_chunk_size must be a positive integer.")
    if gene_names is not None and len(gene_names) != X.shape[1]:
        raise ValueError("gene_names length does not match source gene columns.")
    directory = Path(output_dir).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    # A newly executed worker must not leave a previous receipt claiming that
    # the files being replaced are complete. Compatible caches are skipped by
    # the caller before this function is entered.
    (directory / "spatial_blocks.json").unlink(missing_ok=True)
    xp, actual_backend = _resolve_backend(backend)
    phase_seconds = {"validation_and_backend_setup": time.perf_counter() - start}
    phase_start = time.perf_counter()
    weights = build_focal_spatial_weights(
        coords, local_rows, k_geom=k_geom, workers=workers
    )
    phase_seconds["neighbor_graph"] = time.perf_counter() - phase_start
    if progress:
        progress(
            f"{sample_id}: {X.shape[0]:,} tissue cells; {len(local_rows):,} focal T "
            f"cells; k={k_geom}/{2*k_geom}; spatial products on {actual_backend}."
        )
    mean_path = directory / "mean.npy"
    gradient_path = directory / "gradient.npy"
    tmp_mean = directory / "mean.inprogress.npy"
    tmp_gradient = directory / "gradient.inprogress.npy"
    shape = (len(local_rows), X.shape[1])
    decision = resources.staging_decision(
        2 * int(shape[0]) * int(shape[1]) * np.dtype(np.float32).itemsize,
        mode=output_staging, max_ram_gib=max_ram_gib, concurrent_workers=concurrent_workers)
    phase_start = time.perf_counter()
    mean_out = gradient_out = None
    if decision["selected"] == "ram":
        try:
            mean_out = np.empty(shape, dtype=np.float32)
            gradient_out = np.empty(shape, dtype=np.float32)
        except MemoryError:
            mean_out = gradient_out = None
            gc.collect()
            if output_staging == "ram":
                raise
            decision.update(selected="disk", reason="RAM allocation failed; using legacy disk memmaps.")
    if decision["selected"] == "disk":
        mean_out = np.lib.format.open_memmap(tmp_mean, mode="w+", dtype=np.float32, shape=shape)
        gradient_out = np.lib.format.open_memmap(tmp_gradient, mode="w+", dtype=np.float32, shape=shape)
    phase_seconds["output_allocation"] = time.perf_counter() - phase_start
    if progress:
        progress(f"{sample_id}: output staging={decision['selected']}; "
                 f"two float32 arrays={decision['output_pair_bytes'] / 2**30:.2f} GiB. "
                 f"{decision['reason']}")
    phase_start = time.perf_counter()
    if actual_backend == "gpu":
        import cupyx.scipy.sparse as cpx_sparse

        W_mean = cpx_sparse.csr_matrix(weights["mean"].astype(np.float32))
        W_gradient = cpx_sparse.csr_matrix(weights["gradient"].astype(np.complex64))
    else:
        W_mean = weights["mean"]
        W_gradient = weights["gradient"]
    phase_seconds["device_graph_setup"] = time.perf_counter() - phase_start
    phase_start = time.perf_counter()
    X_csc = X.tocsc()
    phase_seconds["source_csc_conversion"] = time.perf_counter() - phase_start
    phase_start = time.perf_counter()
    last_progress = phase_start
    for start_gene in range(0, X.shape[1], gene_chunk_size):
        stop_gene = min(start_gene + gene_chunk_size, X.shape[1])
        chunk = X_csc[:, start_gene:stop_gene].toarray().astype(np.float32, copy=False)
        if actual_backend == "gpu":
            device_chunk = xp.asarray(chunk)
            mean = W_mean @ device_chunk
            gradient = xp.abs(W_gradient @ device_chunk.astype(xp.complex64))
            if not bool(xp.all(xp.isfinite(mean))) or not bool(xp.all(xp.isfinite(gradient))):
                raise FloatingPointError("Non-finite BANKSY GPU spatial feature.")
            mean_out[:, start_gene:stop_gene] = xp.asnumpy(mean)
            gradient_out[:, start_gene:stop_gene] = xp.asnumpy(gradient)
            del device_chunk, mean, gradient
        else:
            mean = W_mean @ chunk
            gradient = np.abs(W_gradient @ chunk)
            if not np.isfinite(mean).all() or not np.isfinite(gradient).all():
                raise FloatingPointError("Non-finite BANKSY spatial feature.")
            mean_out[:, start_gene:stop_gene] = mean.astype(np.float32)
            gradient_out[:, start_gene:stop_gene] = gradient.astype(np.float32)
        now = time.perf_counter()
        if progress and (now - last_progress >= 20 or stop_gene == X.shape[1]):
            progress(f"{sample_id}: completed gene chunks {stop_gene:,}/{X.shape[1]:,}; "
                     f"{now - phase_start:.1f}s in gene computation and host output assignment.")
            last_progress = now
    phase_seconds["gene_compute_and_hostcopy"] = time.perf_counter() - phase_start
    if progress:
        progress(f"{sample_id}: persisting completed spatial arrays ({decision['selected']} staging).")
    phase_start = time.perf_counter()
    if decision["selected"] == "ram":
        # Each contiguous C-order array is exported in one sequential pass;
        # no repeated gene-column updates reach the persistent filesystem.
        for path, values in ((tmp_mean, mean_out), (tmp_gradient, gradient_out)):
            with path.open("wb") as handle:
                np.save(handle, values, allow_pickle=False)
                handle.flush()
                os.fsync(handle.fileno())
    else:
        mean_out.flush()
        gradient_out.flush()
    del mean_out, gradient_out, X_csc, W_mean, W_gradient
    os.replace(tmp_mean, mean_path)
    os.replace(tmp_gradient, gradient_path)
    rows_path = directory / "focal_global_rows.npy"
    np.save(rows_path, global_rows, allow_pickle=False)
    phase_seconds["persist_outputs"] = time.perf_counter() - phase_start
    if progress:
        progress(f"{sample_id}: spatial arrays persisted in {phase_seconds['persist_outputs']:.1f}s; hashing inputs.")
    phase_start = time.perf_counter()
    h = hashlib.sha256()
    for arr in (coords, local_rows, global_rows, X.indptr, X.indices, X.data):
        _hash_array(h, arr)
    h.update(f"{ENGINE_VERSION}|k_geom={k_geom}|center=True".encode("ascii"))
    gene_hash = hash_strings(gene_names) if gene_names is not None else None
    h.update(str(gene_hash).encode("ascii"))
    phase_seconds["hash_inputs"] = time.perf_counter() - phase_start
    spec = {
        "sample_id": str(sample_id),
        "mean_path": str(mean_path),
        "gradient_path": str(gradient_path),
        "global_rows_path": str(rows_path),
        "n_tissue": int(X.shape[0]),
        "n_focal": int(len(local_rows)),
        "n_genes": int(X.shape[1]),
        "k_geom": int(k_geom),
        "input_gene_order_sha256": gene_hash,
        "context_sha256": h.hexdigest(),
        "backend": actual_backend,
        "dtype": "float32",
        "engine_version": ENGINE_VERSION,
        "graph_diagnostics": weights["diagnostics"],
        "elapsed_seconds": float(time.perf_counter() - start),
        "complete": True,
        "execution_profile": {"phase_seconds": phase_seconds,
                              "staging_decision": decision,
                              "gene_chunk_size": int(gene_chunk_size),
                              "graph_workers": int(workers),
                              "timing_note": "Wall times; gene compute includes host copies and output assignment. GPU copies synchronize each chunk."},
    }
    tmp_meta = directory / "spatial_blocks.inprogress.json"
    tmp_meta.write_text(json.dumps(spec, indent=2), encoding="utf-8")
    os.replace(tmp_meta, directory / "spatial_blocks.json")
    if actual_backend == "gpu":
        xp.get_default_memory_pool().free_all_blocks()
    return spec


def _open_specs(specs, n_cells: int, n_genes: int):
    opened = []
    seen = np.zeros(n_cells, dtype=np.uint8)
    names = set()
    for original in specs:
        spec = dict(original)
        name = str(spec["sample_id"])
        if name in names:
            raise ValueError(f"Repeated spatial sample_id: {name}")
        names.add(name)
        if spec.get("complete") is False:
            raise ValueError(f"Incomplete spatial cache for {name}.")
        rows = _integer_rows(
            np.load(spec["global_rows_path"], allow_pickle=False),
            f"{name} focal_global_rows", n_cells,
        )
        if seen[rows].any():
            raise ValueError("A focal cell occurs in more than one sample's spatial block.")
        seen[rows] = 1
        mean = np.load(spec["mean_path"], mmap_mode="r", allow_pickle=False)
        gradient = np.load(spec["gradient_path"], mmap_mode="r", allow_pickle=False)
        expected = (len(rows), n_genes)
        if mean.shape != expected or gradient.shape != expected:
            raise ValueError(f"Spatial block shape mismatch for {name}; expected {expected}.")
        if not np.issubdtype(mean.dtype, np.floating) or not np.issubdtype(gradient.dtype, np.floating):
            raise ValueError("Spatial memmaps must have real floating-point dtype.")
        opened.append({"spec": spec, "rows": rows, "mean": mean, "gradient": gradient})
    if not opened or not seen.all():
        raise ValueError(
            "Spatial blocks must cover every focal cell exactly once; "
            f"{int((seen == 0).sum()):,} cells are missing."
        )
    return opened


def _finish_statistics(sum_, sumsq, n_cells: int, variance_tolerance: float):
    mean = np.asarray(sum_, dtype=np.float64) / n_cells
    second = np.asarray(sumsq, dtype=np.float64) / n_cells
    variance = np.maximum(second - np.square(mean), 0)
    # Constant features can otherwise acquire large scales from cancellation.
    threshold = variance_tolerance * np.maximum(second, 1.0)
    active = variance > threshold
    inverse_scale = np.zeros_like(variance)
    inverse_scale[active] = 1.0 / np.sqrt(variance[active])
    return {"mean": mean, "variance": variance, "inverse_scale": inverse_scale,
            "active": active}


def fit_block_statistics(
    own_csr_global,
    spatial_specs: Sequence[Mapping[str, Any]],
    *,
    row_chunk_size: int = 8192,
    variance_tolerance: float = 1e-12,
    gene_names: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Pool per-gene population moments across all focal cells, not per sample.

    This requires at most one dense row chunk. Results can be reused for all
    lambda values and column-subset holdout arms, and saved without pickle.
    """
    X = _csr_input(own_csr_global, "own_csr_global")
    n_cells, n_genes = X.shape
    if n_cells < 2 or n_genes < 1 or row_chunk_size < 1:
        raise ValueError("Need at least two focal cells, one gene, and positive row_chunk_size.")
    if variance_tolerance < 0 or not np.isfinite(variance_tolerance):
        raise ValueError("variance_tolerance must be finite and nonnegative.")
    if gene_names is not None and len(gene_names) != n_genes:
        raise ValueError("gene_names length differs from own expression columns.")
    opened = _open_specs(spatial_specs, n_cells, n_genes)
    own_sum = np.asarray(X.sum(axis=0, dtype=np.float64)).ravel()
    own_sumsq = np.bincount(
        X.indices, weights=np.square(X.data.astype(np.float64)), minlength=n_genes
    )
    blocks = {"own": _finish_statistics(own_sum, own_sumsq, n_cells, variance_tolerance)}
    for block in ("mean", "gradient"):
        sum_ = np.zeros(n_genes, dtype=np.float64)
        sumsq = np.zeros(n_genes, dtype=np.float64)
        for item in opened:
            matrix = item[block]
            for start in range(0, len(item["rows"]), row_chunk_size):
                chunk = np.asarray(matrix[start:start + row_chunk_size])
                if not np.isfinite(chunk).all():
                    raise FloatingPointError(f"Non-finite cached {block} feature.")
                sum_ += chunk.sum(axis=0, dtype=np.float64)
                sumsq += np.einsum("ij,ij->j", chunk, chunk, dtype=np.float64)
        blocks[block] = _finish_statistics(sum_, sumsq, n_cells, variance_tolerance)
    return {
        "n_cells": n_cells, "n_genes": n_genes, "ddof": 0,
        "variance_tolerance": float(variance_tolerance), "blocks": blocks,
        "input_gene_order_sha256": hash_strings(gene_names) if gene_names is not None else None,
        "engine_version": ENGINE_VERSION,
    }


def save_block_statistics(stats: Mapping[str, Any], path: str | Path) -> None:
    """Save numeric statistics and a JSON header in a portable NPZ archive."""
    header = {key: value for key, value in stats.items() if key != "blocks"}
    arrays = {"header_json": np.array(json.dumps(header))}
    for block in BLOCK_NAMES:
        for key, value in stats["blocks"][block].items():
            arrays[f"{block}__{key}"] = np.asarray(value)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as handle:
        np.savez_compressed(handle, **arrays)


def load_block_statistics(path: str | Path) -> dict[str, Any]:
    with np.load(path, allow_pickle=False) as archive:
        stats = json.loads(str(archive["header_json"].item()))
        stats["blocks"] = {
            block: {key: np.array(archive[f"{block}__{key}"])
                    for key in ("mean", "variance", "inverse_scale", "active")}
            for block in BLOCK_NAMES
        }
    return stats


class BanksyBlockOperator:
    """Matrix-free standardized BANKSY features with CPU or GPU thin products.

    Spatial memmaps remain on host/disk; only one row chunk and the thin PCA
    workspaces are sent to GPU. ``matmat`` and ``rmatmat`` return NumPy/CuPy
    arrays according to ``backend``. A common gene mask removes held-out genes
    from every block. Own rows must follow the exact supplied ``cell_ids``.
    """

    def __init__(
        self,
        own_csr_global,
        spatial_specs: Sequence[Mapping[str, Any]],
        gene_names: Sequence[str],
        *,
        cell_ids: Sequence[str],
        lambda_: float = 0.2,
        keep_gene_mask: np.ndarray | None = None,
        stats: Mapping[str, Any] | None = None,
        backend: str = "auto",
        row_chunk_size: int = 8192,
    ):
        own = _csr_input(own_csr_global, "own_csr_global")
        self.n_cells, self.n_input_genes = own.shape
        if self.n_cells < 2 or self.n_input_genes < 1:
            raise ValueError("BANKSY PCA needs at least two focal cells and one input gene.")
        self.gene_names = [str(x) for x in gene_names]
        self.cell_ids = [str(x) for x in cell_ids]
        if len(self.gene_names) != self.n_input_genes or len(set(self.gene_names)) != len(self.gene_names):
            raise ValueError("gene_names must be unique and match expression columns.")
        if len(self.cell_ids) != self.n_cells or len(set(self.cell_ids)) != len(self.cell_ids):
            raise ValueError("cell_ids must be unique and match own-expression rows.")
        self.input_gene_order_sha256 = hash_strings(self.gene_names)
        self.cell_order_sha256 = hash_strings(self.cell_ids)
        if not np.isfinite(lambda_) or not 0 <= lambda_ <= 1:
            raise ValueError("BANKSY lambda must be in [0,1].")
        self.lambda_ = float(lambda_)
        if not isinstance(row_chunk_size, int) or row_chunk_size < 1:
            raise ValueError("row_chunk_size must be positive.")
        self.row_chunk_size = row_chunk_size
        self.xp, self.backend = _resolve_backend(backend)
        if keep_gene_mask is None:
            mask = np.ones(self.n_input_genes, dtype=bool)
        else:
            mask = np.asarray(keep_gene_mask)
            if mask.shape != (self.n_input_genes,) or mask.dtype != np.bool_:
                raise ValueError("keep_gene_mask must be a boolean vector over input genes.")
        if not mask.any():
            raise ValueError("No genes remain after feature exclusions.")
        self.keep_gene_mask = mask.copy()
        self.gene_indices = np.flatnonzero(mask)
        self.selected_gene_names = [g for g, use in zip(self.gene_names, mask) if use]
        self.excluded_genes = [g for g, use in zip(self.gene_names, mask) if not use]
        self.n_genes = int(mask.sum())
        self.own = own[:, self.gene_indices].astype(np.float32)
        self._spatial = _open_specs(spatial_specs, self.n_cells, self.n_input_genes)
        for item in self._spatial:
            cache_gene_hash = item["spec"].get("input_gene_order_sha256")
            if cache_gene_hash is not None and cache_gene_hash != self.input_gene_order_sha256:
                raise ValueError("Spatial cache gene order differs from own-expression gene order.")
        if stats is None:
            stats = fit_block_statistics(
                own, spatial_specs, row_chunk_size=row_chunk_size, gene_names=gene_names
            )
        if stats["n_cells"] != self.n_cells or stats["n_genes"] != self.n_input_genes or stats["ddof"] != 0:
            raise ValueError("Pooled feature statistics have the wrong shape or ddof.")
        if stats.get("input_gene_order_sha256") not in (None, self.input_gene_order_sha256):
            raise ValueError("Statistics were computed with a different gene order.")
        self.stats = stats
        self._coefficients = {
            "own": float(np.sqrt(1 - self.lambda_)),
            "mean": float(np.sqrt(2 * self.lambda_ / 3)),
            "gradient": float(np.sqrt(self.lambda_ / 3)),
        }
        self.active_blocks = [b for b in BLOCK_NAMES if self._coefficients[b] > 0]
        self.feature_names = [f"{b}::{g}" for b in self.active_blocks for g in self.selected_gene_names]
        self.feature_blocks = [b for b in self.active_blocks for _ in self.selected_gene_names]
        self.shape = (self.n_cells, len(self.feature_names))
        self.dtype = np.dtype(np.float32)
        self._offsets = {b: slice(i * self.n_genes, (i + 1) * self.n_genes)
                         for i, b in enumerate(self.active_blocks)}
        self._mean = {}
        self._inverse_scale = {}
        self.n_active_features = 0
        for block in self.active_blocks:
            stat = stats["blocks"][block]
            for name in ("mean", "variance", "inverse_scale", "active"):
                if np.asarray(stat[name]).shape != (self.n_input_genes,):
                    raise ValueError(f"Invalid {block} statistics array: {name}.")
            mean = np.asarray(stat["mean"])[mask]
            scale = np.asarray(stat["inverse_scale"])[mask]
            if not np.isfinite(mean).all() or not np.isfinite(scale).all() or np.any(scale < 0):
                raise ValueError("Feature statistics contain invalid centering/scaling values.")
            self._mean[block] = self.xp.asarray(mean, dtype=self.xp.float32)
            self._inverse_scale[block] = self.xp.asarray(scale, dtype=self.xp.float32)
            self.n_active_features += int(np.count_nonzero(scale))
        for item in self._spatial:
            item["device_rows"] = self.xp.asarray(item["rows"])
        self.total_variance = float(
            self.n_cells / (self.n_cells - 1) * sum(
                self._coefficients[b] ** 2 *
                np.count_nonzero(np.asarray(stats["blocks"][b]["inverse_scale"])[mask])
                for b in self.active_blocks
            )
        )
        if self.n_cells < 2 or not np.isfinite(self.total_variance) or self.total_variance <= 0:
            raise ValueError("No variable BANKSY features remain for PCA.")
        h = hashlib.sha256()
        for item in sorted(self._spatial, key=lambda x: str(x["spec"]["sample_id"])):
            spec = item["spec"]
            h.update(str(spec["sample_id"]).encode("utf-8"))
            h.update(str(spec.get("context_sha256", "unspecified")).encode("ascii"))
        self.spatial_context_sha256 = h.hexdigest()

    def _sparse_chunk(self, start: int, stop: int):
        chunk = self.own[start:stop]
        if self.backend == "gpu":
            import cupyx.scipy.sparse as cpx_sparse
            return cpx_sparse.csr_matrix(chunk)
        return chunk

    def _dense_chunk(self, item, block: str, start: int, stop: int):
        chunk = np.asarray(item[block][start:stop])
        if self.n_genes != self.n_input_genes:
            chunk = chunk[:, self.gene_indices]
        # Always a private device / CPU work array: never mutate a cache mmap.
        value = self.xp.array(chunk, dtype=self.xp.float32, copy=True, order="C")
        value -= self._mean[block]
        value *= self._inverse_scale[block]
        return value

    def matmat(self, right):
        """Return BANKSY_features @ right without constructing BANKSY_features."""
        xp = self.xp
        right = xp.asarray(right, dtype=xp.float32)
        if right.ndim != 2 or right.shape[0] != self.shape[1]:
            raise ValueError(f"Right product expects shape ({self.shape[1]},K).")
        result = xp.zeros((self.n_cells, right.shape[1]), dtype=xp.float32)
        if "own" in self.active_blocks:
            block_right = right[self._offsets["own"]]
            transformed_right = self._inverse_scale["own"][:, None] * block_right
            offset = self._mean["own"] @ transformed_right
            for start in range(0, self.n_cells, self.row_chunk_size):
                stop = min(start + self.row_chunk_size, self.n_cells)
                result[start:stop] = self._coefficients["own"] * (
                    self._sparse_chunk(start, stop) @ transformed_right - offset[None, :]
                )
        for block in ("mean", "gradient"):
            if block not in self.active_blocks:
                continue
            block_right = right[self._offsets[block]] * self._coefficients[block]
            for item in self._spatial:
                for start in range(0, len(item["rows"]), self.row_chunk_size):
                    stop = min(start + self.row_chunk_size, len(item["rows"]))
                    values = self._dense_chunk(item, block, start, stop)
                    result[item["device_rows"][start:stop]] += values @ block_right
        return result

    def rmatmat(self, left):
        """Return BANKSY_features.T @ left with the same exact row mapping."""
        xp = self.xp
        left = xp.asarray(left, dtype=xp.float32)
        if left.ndim != 2 or left.shape[0] != self.n_cells:
            raise ValueError(f"Transpose product expects shape ({self.n_cells},K).")
        result = xp.zeros((self.shape[1], left.shape[1]), dtype=xp.float32)
        if "own" in self.active_blocks:
            aggregate = xp.zeros((self.n_genes, left.shape[1]), dtype=xp.float32)
            for start in range(0, self.n_cells, self.row_chunk_size):
                stop = min(start + self.row_chunk_size, self.n_cells)
                values = left[start:stop]
                aggregate += (
                    self._sparse_chunk(start, stop).T @ values
                    - self._mean["own"][:, None] * xp.sum(values, axis=0)[None, :]
                )
            result[self._offsets["own"]] = (
                aggregate * self._inverse_scale["own"][:, None] * self._coefficients["own"]
            )
        for block in ("mean", "gradient"):
            if block not in self.active_blocks:
                continue
            aggregate = xp.zeros((self.n_genes, left.shape[1]), dtype=xp.float32)
            for item in self._spatial:
                for start in range(0, len(item["rows"]), self.row_chunk_size):
                    stop = min(start + self.row_chunk_size, len(item["rows"]))
                    values = self._dense_chunk(item, block, start, stop)
                    aggregate += values.T @ left[item["device_rows"][start:stop]]
            result[self._offsets[block]] = aggregate * self._coefficients[block]
        return result

    def manifest(self) -> dict[str, Any]:
        blocks = []
        for block in BLOCK_NAMES:
            coefficient = self._coefficients[block]
            selected_active = np.asarray(self.stats["blocks"][block]["inverse_scale"])[self.keep_gene_mask] > 0
            blocks.append({
                "name": block,
                "coefficient": coefficient,
                "variance_weight": coefficient ** 2,
                "genes": list(self.selected_gene_names) if coefficient > 0 else [],
                "effective_genes": [g for g, use in zip(self.selected_gene_names, selected_active) if use]
                                   if coefficient > 0 else [],
            })
        return {
            "method": "BANKSY m=1", "engine_version": ENGINE_VERSION,
            "reference_pybanksy_version": REFERENCE_PYBANKSY_VERSION,
            "lambda": self.lambda_, "backend": self.backend,
            "n_cells": self.n_cells, "n_features": self.shape[1],
            "n_active_features": self.n_active_features,
            "feature_gene_names": list(self.selected_gene_names),
            "feature_names": list(self.feature_names),
            "feature_blocks": list(self.feature_blocks),
            "excluded_genes": list(self.excluded_genes), "blocks": blocks,
            "input_gene_order_sha256": self.input_gene_order_sha256,
            "cell_order_sha256": self.cell_order_sha256,
            "cell_order_hash_kind": "cell_ids",
            "hash_encoding": "sha256(UTF-8 newline-joined strings)",
            "spatial_context_sha256": self.spatial_context_sha256,
            "k_geom": sorted({int(x["spec"]["k_geom"]) for x in self._spatial}),
            "feature_scaling": "pooled_focal_zscore_ddof0",
            "zero_variance_tolerance": self.stats.get("variance_tolerance", 1e-12),
            "marker_boost": False, "ratio_weighting": False,
            "agf_centering": "unweighted mean of m=1 neighbors; no expression division",
            "neighbor_scope": "all retained same-sample tissue cells; focal output only",
        }


def randomized_pca(
    operator: BanksyBlockOperator,
    n_components: int = 50,
    *,
    n_oversamples: int = 20,
    n_iter: int = 2,
    random_state: int = 0,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """QR-stabilized randomized SVD of a streamed, already-centered operator.

    The final scores are B @ loadings, rather than Q times an approximate
    score matrix. All returned arrays are CPU NumPy arrays for portable caches.
    """
    start = time.perf_counter()
    xp = operator.xp
    max_rank = min(operator.shape[0] - 1, operator.n_active_features)
    if not isinstance(n_components, int) or not 1 <= n_components <= max_rank:
        raise ValueError(f"n_components must be an integer from 1 to {max_rank}.")
    if not isinstance(n_iter, int) or n_iter < 0 or n_oversamples < 0:
        raise ValueError("n_iter and n_oversamples must be nonnegative integers.")
    width = min(n_components + int(n_oversamples), max_rank)
    rng = np.random.default_rng(random_state)
    omega = xp.asarray(rng.standard_normal((operator.shape[1], width)).astype(np.float32))
    q, _ = xp.linalg.qr(operator.matmat(omega), mode="reduced")
    del omega
    for iteration in range(n_iter):
        qt, _ = xp.linalg.qr(operator.rmatmat(q), mode="reduced")
        q, _ = xp.linalg.qr(operator.matmat(qt), mode="reduced")
        del qt
        if progress:
            progress(f"BANKSY PCA stabilized power iteration {iteration+1}/{n_iter}.")
    small = operator.rmatmat(q).T
    del q
    _, singular_values, vt = xp.linalg.svd(small, full_matrices=False)
    del small
    loadings = vt[:n_components].T.copy()
    largest = xp.argmax(xp.abs(loadings), axis=0)
    signs = xp.where(loadings[largest, xp.arange(n_components)] < 0, -1, 1)
    loadings *= signs[None, :]
    scores = operator.matmat(loadings)
    if not bool(xp.all(xp.isfinite(scores))) or not bool(xp.all(xp.isfinite(loadings))):
        raise FloatingPointError("PCA produced non-finite scores or loadings.")
    # Only the final thin score matrix is copied to host for unbiased variance.
    scores_cpu = _to_cpu(scores, xp).astype(np.float32, copy=False)
    loadings_cpu = _to_cpu(loadings, xp).astype(np.float32, copy=False)
    variance = np.var(scores_cpu, axis=0, ddof=1, dtype=np.float64)
    result = {
        "scores": scores_cpu,
        "loadings": loadings_cpu,
        "mean": np.zeros(operator.shape[1], dtype=np.float32),
        "variance": variance,
        "variance_ratio": variance / operator.total_variance,
        "singular_values_approx": _to_cpu(singular_values[:n_components], xp),
        "total_variance": operator.total_variance,
        "manifest": operator.manifest(),
        "elapsed_seconds": float(time.perf_counter() - start),
        "n_components": n_components,
        "n_oversamples": int(n_oversamples),
        "n_iter": n_iter,
        "random_state": int(random_state),
    }
    return result


def validate_against_pybanksy(
    *,
    random_state: int = 17,
    atol: float = 3e-5,
) -> dict[str, Any]:
    """Tiny preflight: compare this engine to the actual installed BANKSY API.

    This imports installed pybanksy, uses its own graph, neighborhood, and
    concatenation functions, and raises on mismatch. It is intentionally
    independent of the user's data. CPU float32 spatial-cache rounding is
    allowed; a GPU smoke test should be run separately on a visible GPU.
    """
    import tempfile
    import anndata as ad
    from banksy.main import generate_spatial_weights_fixed_nbrs, concatenate_all
    from banksy.embed_banksy import create_nbr_matrix

    rng = np.random.default_rng(random_state)
    coords = rng.uniform(size=(61, 2)).astype(np.float64)
    raw = rng.poisson(0.65, size=(61, 19)).astype(np.float32)
    raw[:, -1] = 0  # constant feature must remain finite/zero in every block.
    expression = np.log1p(raw).astype(np.float32)
    X = sparse.csr_matrix(expression)
    gene_names = [f"g{i}" for i in range(X.shape[1])]
    focal = np.array([8, 1, 42, 22, 5, 18, 59, 3, 40, 14, 7, 54, 33, 23, 4, 44])
    with contextlib.redirect_stdout(io.StringIO()), np.errstate(divide="ignore", invalid="ignore"):
        weights = {
            m: generate_spatial_weights_fixed_nbrs(
                coords, m=m, num_neighbours=5, decay_type="scaled_gaussian", verbose=False
            )[0]
            for m in (0, 1)
        }
        data = ad.AnnData(X=X)
        reference = create_nbr_matrix(
            data, {"scaled_gaussian": {"weights": weights}},
            "scaled_gaussian", 1, center=True, variance_balance=False, verbose=False,
        )
        expected = concatenate_all(
            [expression[focal], reference[0][focal], reference[1][focal]], 0.2
        )
    graphs = build_focal_spatial_weights(coords, focal, k_geom=5, workers=1)
    graph_mean_error = float(np.max(np.abs((graphs["mean"] - weights[0][focal]).toarray())))
    graph_phase_error = float(np.max(np.abs((graphs["gradient_uncentered"] - weights[1][focal]).toarray())))
    with tempfile.TemporaryDirectory(prefix="banksy-equivalence-") as tmp:
        spec = compute_sample_spatial_blocks(
            X, coords, focal, np.arange(len(focal)), tmp, "synthetic",
            k_geom=5, backend="cpu", gene_chunk_size=4, gene_names=gene_names, workers=1,
        )
        mean_actual = np.load(spec["mean_path"])
        gradient_actual = np.load(spec["gradient_path"])
        mean_error = float(np.max(np.abs(mean_actual - reference[0][focal])))
        gradient_error = float(np.max(np.abs(gradient_actual - reference[1][focal])))
        op = BanksyBlockOperator(
            X[focal], [spec], gene_names,
            cell_ids=[f"cell-{i}" for i in focal], lambda_=0.2,
            backend="cpu", row_chunk_size=5,
        )
        actual = op.matmat(np.eye(op.shape[1], dtype=np.float32))
        feature_error = float(np.max(np.abs(actual - expected)))
    checks = {
        "mean_graph_max_abs_error": graph_mean_error,
        "phase_graph_max_abs_error": graph_phase_error,
        "mean_feature_max_abs_error": mean_error,
        "gradient_feature_max_abs_error": gradient_error,
        "standardized_concatenation_max_abs_error": feature_error,
    }
    if not all(np.isfinite(value) for value in checks.values()) or max(checks.values()) > atol:
        raise AssertionError(f"Installed pybanksy numerical equivalence failed: {checks}")
    return {
        "passed": True,
        "installed_pybanksy_version": importlib.metadata.version("pybanksy"),
        "reference_pybanksy_version": REFERENCE_PYBANKSY_VERSION,
        "atol": float(atol),
        "tested_focal_subset": True,
        "full_tissue_context": True,
        "k_mean": 5, "k_gradient": 10,
        "agf_center": True,
        "reference_functions": [
            "banksy.main.generate_spatial_weights_fixed_nbrs",
            "banksy.embed_banksy.create_nbr_matrix(center=True)",
            "banksy.main.concatenate_all",
        ],
        **checks,
    }
