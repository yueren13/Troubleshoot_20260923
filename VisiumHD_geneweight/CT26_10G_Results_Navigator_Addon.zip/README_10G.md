# 10G — CT26 question-based results navigator

## Purpose

A read-only navigation and explanation layer over your completed **10A–10F** results,
including the saved sccomp contrasts and optional **10C1** labelled forest plots.
It reorganizes existing plots and tables; it does NOT rerun extraction, segmentation,
scVI/Leiden, DESeq2, sccomp/Stan, spatial statistics, or permutation tests.
It does NOT infer your biological findings from file names or automatically write
claims about treatment effects.

## Easiest installation: one notebook

`10G_CT26_Question_Based_Results_Navigator.ipynb` is **self-contained**. Its bundled
Python/UI/guide files are extracted to a small versioned `.ct26_report_runtime/`
folder. No pip/R installation is performed. Place the notebook alongside the old
characterization notebooks, or set `ANALYSIS_ADDON_DIR` to that old folder.
The separate ZIP contains readable copies of every embedded helper and UI asset.

Do not replace `tumor_characterization/` or `tumor_visibility/`. Do not put this
notebook in the original pipeline `inputs/` directory or change its `run_name`.
The notebook never invokes `open_atlas()` or any original analysis helper.

## Configuration

1. `CHARACTERIZATION_ROOT`: the path printed as **atlas['out']** by 10A. This is
   the directory containing `characterization_manifest.json`, `source_manifest.csv`,
   and subfolders such as `architecture/`, `sccomp/`, and `neighborhoods/`.
   It is NOT the notebook folder, 09A PROJECT_ROOT, or a single sccomp fit folder.
2. If no root is supplied, the notebook reads `active_characterization_project.json`
   in `ANALYSIS_ADDON_DIR` and offers available output candidates. It selects only
   when exactly one exists. It does not choose the newest directory.
3. `RUN_SELECTION`: default None for each branch selects its only completed run.
   When multiple runs exist, select an exact path/run ID or an explicit list. This
   prevents mixing different annotations, grids, LRTs or sccomp fits silently.
   Use an empty list to intentionally omit a branch.
4. `NEIGHBOR_PLOT_STYLES`: choose the exact saved 10F plot-style folder when several
   styles exist. Numeric-neighborhood and plot-style versions are kept separate.
5. `SOURCE_ADDON_DIR`: usually the old package folder. The guide definitions are
   checked against stored hashes of the supplied plotting helpers. A changed or
   unavailable local generator is disclosed; figures are not silently reinterpreted.

## Organization in the browser

### All tumor
1. Expression: condition-average patterns → individual mice → pattern curves,
   gene-distribution boxes, and mouse-level pattern scores.
2. Composition: observed mouse fractions → sccomp contrast forests and exact tables.
3. Architecture: continuous fraction maps → threshold-defined patch maps → connected
   patch summaries, Moran/Geary, and rasterized Ripley summaries.

### Tumor subgroups
4. Identity: top-5/top-10 marker dotplots and treatment-separated views.
5. Expression: choose Tumor 1–5, an LRT run and local response pattern.
6. Composition: global fraction versus within-tumor fraction remain distinct.
7. Architecture: same spatial definitions, subgroup-specific summaries.
8. Neighborhoods: treatment versus sample plots, cumulative versus annular ranges,
   and all-reviewed versus non-tumor-reviewed denominators.

### Review tools
- Pin up to four figures for side-by-side comparison.
- From a sample patch/fraction map, **Across mice** creates four treatment columns,
  each containing that condition's mouse samples at the SAME population/grid/
  threshold/run. Missing counterparts are shown as missing, not replaced.
- The image dialog has a larger original view, the calculation/denominator,
  interpretation cautions, saved settings, and links to supporting tables.
- Table previews are capped; complete saved files remain downloadable when within
  the configured copy size limit. A truncated preview is clearly indicated.
- Exact sccomp c_FDR, intervals, effect thresholds and diagnostic status are kept
  together. Display screening at c_FDR<0.05 is not new inference or FDR correction.
- Record notes per figure, pin figures, and export/import a notes JSON. Browser
  storage is optional; export before closing when local storage is unavailable.
- Search filenames, populations or methods. Pagination defaults to eight figures,
  so the report does not become another enormous image wall.

## What the example filename means

`All_tumor_cell_patches_grid25_thr0.3.png`

- All tumor cell: union of the five reviewed tumor populations.
- grid25: 25 × 25 µm tiles, not a radius.
- thr0.3: target cells / reviewed cells >= 0.30 in an eligible tile.
- The original default eligibility also required >=3 full-reference cells,
  >=3 reviewed cells and reviewed/full >=0.5; selected patch tiles needed >=2
  target cells. The report prints saved settings instead of blindly assuming them.
- 8-connectivity joins selected tiles at edges **or corners**.
- Colors represent connected-component labels, NOT cell types, expression, or
  treatment. The original tab20 palette can repeat colors.
- Blank pixels can reflect subthreshold fraction, low support/coverage, or area
  outside the observation window. They are not a diagnosis of necrosis or no tissue.
- Axes are local Proseg x/y in µm; this is not an H&E overlay.

Detailed method-specific cautions are in `PLOT_INTERPRETATION_GUIDE.md` and inline
within the report. Guides follow the actual supplied implementation, including
several distinctions easy to miss: largest cell-rich patch vs area-largest patch;
patch-supported area vs full window area; pattern gene boxes vs mouse scores;
neighbor pairs vs unique nearby cells; within-image permutation vs mouse treatment
test; and conditional Ripley reference differing for pooled tumor vs subtypes.

## Output and privacy

Default output:

```
<CHARACTERIZATION_ROOT>/results_navigator/10G_review_<timestamp>_<fingerprint>/
  index.html
  static_index.html
  navigator.js
  navigator.css
  report_data.json
  source_provenance.json
  file_inventory.csv
  figure_inventory.csv
  sccomp_original_results_with_diagnostics.csv
  missing_or_untestable.csv
  assets/figures/         # exact original image copies
  assets/thumbs/          # optional small navigation previews
  assets/tables/          # selected original tables/settings
  PLOT_INTERPRETATION_GUIDE.md
```

The folder is portable and needs no internet, CDN, analytics or application server.
It contains sample IDs and source paths for traceability; use your project's usual
confidentiality controls when sharing it. Large raw matrices, model RDS objects,
cell point clouds, image pyramids, and Stan fits are NOT copied.

Open `index.html` in a regular browser. If JupyterLab's HTML preview sanitizes scripts,
use an Open in New Browser Tab action or download/extract the ENTIRE report folder
and open it locally. Keep assets/, CSS and JS together. `static_index.html` gives a
no-JavaScript fallback. If your managed browser restricts local scripts, this fallback
still links original figures; request the appropriate approved rendering route from IT.
Do not disable corporate security controls.

`MAKE_PORTABLE_ZIP=True` packages only the report, not the original project. Report
copies take extra disk space; the notebook checks capacity before copying. Default
budget is 6 GiB total and 100 MiB per supporting table. Oversized tables are explicitly
not copied, with their original paths retained. The report never modifies the originals.

## Plot fidelity and limitations

- Original PNG pixels, axes and color scales are preserved. Thumbnails are for
  browsing; the dialog/original link uses the copied full image.
- Equal-sized browser cards do not mean equal physical tissue extent or registered
  anatomy. Compare physical axes and original scales.
- Different settings/analysis runs stay visible and selectable; no biological
  interpretation is inferred from a chosen threshold or an apparent visual sequence.
- Numerical summaries may exist without a corresponding figure (10E originally
  defaults to pooled-tumor sample maps). The navigator cannot create an absent plot
  or reconstruct missing evidence. Tables remain linked.
- Source/table preview schemas that are unknown are labeled as such; no guessed
  statistical columns or sample-treatment assignments are substituted.
- Notes are local observations, not edits to model results. Export notes to preserve
  them between computers or report versions.

## Validation

See `VALIDATION_10G.md` for executed synthetic integration and browser tests, and their
limits. Your completed server results were not available in the authoring runtime.
The report is populated from those files when you run the notebook on your server.
