# CT26 characterization plot guide — interpretation of the supplied implementation

This guide was derived from the supplied `tumor_characterization` Python helpers. It describes definitions, not study findings. Saved runtime settings remain authoritative; locally modified helper hashes are flagged by the navigator. No new inference is performed.

## The example filename

`All_tumor_cell_patches_grid25_thr0.3.png`

- **All_tumor_cell:** the union of Tumor cells 1–5.
- **grid25:** square tiles of 25 × 25 µm (area 625 µm²), not a neighborhood radius.
- **thr0.3:** target population count / reviewed cell count is at least 0.30 within a supported tile.
- **Original default support settings:** at least 3 full-reference cells, at least 3 reviewed cells, reviewed/full fraction at least 0.5, and at least 2 target cells in the patch tile. The report displays actual saved settings rather than assuming defaults.
- **Connectivity:** selected tiles touching at an edge or corner are grouped (8-connectivity).
- **Color:** connected-component ID, not cell type or expression. `tab20` colors can repeat; identical hues do not establish matching components.
- **Blank:** an unselected/masked tile; may be below threshold, insufficient coverage, or outside support. Not a diagnosis of necrosis or empty tissue.
- **Axes:** local Proseg physical coordinates in µm with image origin lower; not an H&E image.

## Suggested review order

1. Pooled tumor: condition expression → mouse expression → observed composition → sccomp evidence → fraction maps/patch maps → architecture summaries.
2. Subgroups: marker identity → treatment consistency → subgroup expression → global and within-tumor composition → subgroup architecture → neighborhoods.
3. For any striking treatment difference, inspect all three mice, the saved denominator/support settings, and relevant diagnostics. A selected visual example is not a treatment test.

## Where are the connected tumor-rich patches?

**Question:** Does the selected population form broad connected regions, smaller islands, or sparse groups at this grid and threshold?

**Calculation:** Select eligible tiles with population_count / reviewed_count ≥ fraction_threshold AND population_count ≥ min_group_cells, then label 8-connected selected tiles. Eligibility additionally uses the saved full-cell count, reviewed-cell count, reviewed fraction, and observation-window rules.

**Denominator:** Fraction threshold: reviewed annotated cells within each eligible tile; not cell area, total transcripts, the full tissue area, or a significance threshold.

- Each raster square has the side length specified by grid_um; grid25 means 25 × 25 µm, not a 25-µm neighborhood radius.
- The plotted quantity is a connected-component ID. Adjacent selected tiles share one component, including diagonal adjacency (8-connectivity).
- Colors are categorical patch labels, not tumor subtypes, expression, or treatment. The tab20 palette can repeat; matching colors do not establish that separated areas or different samples are the same patch.
- White/blank means not shown as a selected patch. It can be a low-population tile, a low-coverage tile, or outside the support. It is not proof of necrosis or absent tissue.

**Compare:** Keep population, grid, threshold, observation-window definition and support rules fixed across samples. Inspect all three mice per condition, not one illustrative image.

**Cautions:**
- The grid origin is established separately from each sample's coordinate extent; these maps are not anatomical registration across mice.
- These are raster regions, not histologically validated islands or exact polygon boundaries. Changing grid, threshold or connectivity can merge/split a region.
- Patch images use Proseg physical x/y coordinates with origin='lower', not an H&E overlay. Axes may span different extents between samples.

**Source routines:** `tumor_characterization/architecture.py:raster_reference`, `tumor_characterization/architecture.py:patch_metrics`, `tumor_characterization/architecture.py:run`

## How much of each supported tile is the selected population?

**Question:** Is tumor/subtype fraction broadly high, spatially mixed, or limited to small locations?

**Calculation:** population_count / reviewed_count on eligible tiles; source plotting uses vmin=0, vmax=1.

**Denominator:** Reviewed cells in an eligible grid tile.

- Color is population cell count divided by reviewed cell count, with the original fixed scale from 0 to 1.
- Only tiles passing the field-support/coverage criteria are colored. A blank tile is not automatically a zero population fraction.
- This continuous-fraction map is the companion to the thresholded patch map.

**Compare:** Compare this map next to the patch map at the same population and grid before interpreting a thresholded region.

**Cautions:**
- Not a tumor density per mm² and not an expression score.
- The figure is in physical Proseg coordinates, not a registered H&E background.

**Source routines:** `tumor_characterization/architecture.py:run`

## How much of the population lies in its most cell-rich patch?

**Question:** Are most target cells concentrated in one connected patch, or spread across patches/background?

**Calculation:** max(component target-cell count) / all target-cell counts in eligible tiles. This selects the cell-richest component, which need not be the largest by area.

**Denominator:** All target-population cells in the eligible tile mask, including those outside threshold-passing patches.

- Every plotted point is one independent mouse tumor; bars show the mouse mean and whiskers the SD.
- Higher values indicate more target cells in the component containing the most target cells.

**Compare:** Keep grid and fraction threshold fixed. Read with fraction_group_cells_in_patches and the patch/fraction maps.

**Cautions:**
- A lower value can reflect fragmentation, many below-threshold cells, or both.
- Not a percentage of the whole tissue area and not a treatment significance test.

**Source routines:** `tumor_characterization/architecture.py:patch_metrics`, `tumor_characterization/core.py:scalar_plot`

## What size patch contains a typical patch-associated target cell?

**Question:** Do target cells predominantly reside in large or small connected raster regions?

**Calculation:** Weighted average of component areas, weighted by target cells per component. Component area = selected tiles × grid_um².

**Denominator:** Target-cell counts inside selected components only; cells outside selected patches are not included in this weighted mean.

- The outcome is an area in µm², weighted by the target-cell count in each selected component.
- Mouse-level points are the biological observations.

**Compare:** Read together with the fraction of target cells captured by patches; the weighted mean alone hides uncaptured cells.

**Cautions:**
- Not mean single-cell area or exact histologic island area.
- Threshold/grid/coverage differences can change the value without a new biological observation.

**Source routines:** `tumor_characterization/architecture.py:patch_metrics`

## How many threshold-defined patches occur per supported area?

**Question:** Does the selected population form more/fewer connected regions at a fixed definition?

**Calculation:** number_of_components / (eligible_tile_count × grid_um²) × 10⁶.

**Denominator:** Eligible tile area passed to patch_metrics, not necessarily all occupied window area or true tissue area.

- Each point summarizes one mouse. The unit is patches per mm² of the eligible field support.
- A larger patch count is not necessarily more fragmentation if supported area, detection, or threshold capture differs.

**Compare:** Use the same grid/threshold and review coverage and component-size measures alongside this plot.

**Cautions:**
- This is not tumor-cell density or an absolute whole-tumor burden estimate.
- Default support is a cell-derived proxy, not verified viable-tissue area.

**Source routines:** `tumor_characterization/architecture.py:patch_metrics`

## Do neighboring supported tiles have similar population fractions?

**Question:** How spatially associated is the population-fraction field at the selected grid scale?

**Calculation:** Moran I from the supported tile fraction field, using each undirected adjacency once and an equivalent symmetric binary weight matrix.

**Denominator:** Reviewed cells define each tile fraction; field variance and supported edges define the statistic.

- The field is target / reviewed-cell fraction, not point density or gene expression.
- The implementation uses symmetric binary queen adjacency: horizontal, vertical and diagonal supported tile neighbors.
- Higher/lower values describe this field and weighting scheme; no fixed tumor-island size is implied.

**Compare:** Keep grid/support rules fixed and inspect fraction maps. A visually uniform tumor field can have undefined I because variance is near zero.

**Cautions:**
- Within-image permutation P values shuffle tile fractions. They are not treatment-comparison P values across mice.
- Fragmentation need not produce a monotonic decline in I; many small internally similar regions can still show local association.
- This navigator does not create missing treatment tests.

**Source routines:** `tumor_characterization/architecture.py:raster_edges`, `tumor_characterization/architecture.py:moran_geary`, `tumor_characterization/architecture.py:autocorrelation`

## How different are adjacent supported tile fractions?

**Question:** Does the population-fraction field change sharply across local tile boundaries?

**Calculation:** Normalized sum of squared differences over supported symmetric binary queen-neighbor edges.

**Denominator:** Reviewed-cell tile fractions and overall field variance.

- Geary C uses squared neighboring fraction differences in this implementation.
- The permutation reference in the original code is 1; lower values indicate smaller local differences relative to total field variance.
- A constant field can be undefined rather than zero.

**Compare:** Read with Moran I and the actual map at the same grid, not as a standalone island-size measurement.

**Cautions:**
- Coverage, support mask and grid scale affect the outcome.
- The within-image permutation test and an across-mouse treatment test answer different questions.

**Source routines:** `tumor_characterization/architecture.py:moran_geary`, `tumor_characterization/architecture.py:autocorrelation`

## What is the rasterized pair structure across distances?

**Question:** How does the selected population's point-pair pattern behave at the saved radii?

**Calculation:** FFT-based raster pair counts, self-pairs removed once, overlap-area correction, then sqrt(K/π)−r. Distinct colocated cells remain pairs.

**Denominator:** Saved observation-window area and target count; this is a raster approximation, not exact continuous-coordinate Kest.

- The ordinate is L(r)−r in µm, computed from a rasterized translation-edge-corrected K estimate.
- Thin lines show individual mouse samples; thick lines show condition means in the existing plot.
- The conditional-reference companion is needed to distinguish target arrangement from the sampled tissue geometry.

**Compare:** Use the same grid, radii and support definition. Inspect validity/overlap columns in Ripley_raster_all_samples.csv.

**Cautions:**
- The default occupied-cell window is not a validated tissue mask and may not represent acellular tissue.
- Saved radii must be at least two raster pixels; unstable window overlaps are marked invalid.
- No causal or treatment-significance claim follows from a line above/below zero alone.

**Source routines:** `tumor_characterization/architecture.py:translation_setup`, `tumor_characterization/architecture.py:raster_K`, `tumor_characterization/architecture.py:plot_summary`

## Is the target arrangement more aggregated than its label-shuffling reference?

**Question:** What pair structure remains after conditioning on the sampled cell locations and target count?

**Calculation:** Observed raster L(r)−r minus the mean of count-preserving conditional random-label simulations.

**Denominator:** Conditional background recorded per population in the result table, plus the saved observation window.

- The plotted value subtracts the mean simulated L(r)−r from the observed value.
- For All tumor cell, labels are randomized among all reviewed cells. For a tumor subtype, labels are randomized among all tumor cells.
- Those two backgrounds are different questions; their numerical values should not be treated as one interchangeable reference.

**Compare:** Compare like populations/settings across mice. Check n_permutations and invalid radii before interpreting the curve.

**Cautions:**
- Pointwise random-label envelopes/P values are not a global across-radii treatment test.
- With few permutations, the reference is exploratory and coarse.
- All-tumor and subtype null backgrounds differ.

**Source routines:** `tumor_characterization/architecture.py:random_label_K`, `tumor_characterization/architecture.py:run`

## Which significant gene-response patterns summarize this population?

**Question:** How do the original LRT-significant genes vary across the four conditions?

**Calculation:** Original LRT FDR selection, then k-means on standardized four-condition VST means; pattern ordering uses peak condition and baseline-to-combination trend.

**Denominator:** One fitted library per independent mouse. Means and row standardization are visual summaries, not new test statistics.

- Each row is a significant gene. Columns are condition means of saved VST expression, standardized within each gene across four conditions.
- The side strip labels response-pattern clusters. Block height is the number of genes, not an effect size.
- Pattern numbers are local to this population/run; Pattern 1 need not match Pattern 1 elsewhere.

**Compare:** Pair with the matching individual-mouse heatmap and pattern mouse-score plot to see whether one mouse drives the average.

**Cautions:**
- This is an expression z-score, not an LRT z statistic, fold change or contamination correction.
- Treatment order is categorical, not time, dose or evidence of a monotonic trend.
- Clipping is controlled by the saved zlim. A displayed cap changes color only.

**Source routines:** `tumor_characterization/patterns.py:pattern_matrix`, `tumor_characterization/patterns.py:run`

## Do individual mice support the condition-average response?

**Question:** Is the response shared across mice or dominated by a specimen?

**Calculation:** Per-mouse VST minus the gene's four-condition-mean center, divided by the SD of those four condition means.

**Denominator:** Independent-mouse libraries from the saved fit; not cells or ROIs.

- Rows match the condition-pattern heatmap. Columns are the saved fitted independent-mouse libraries.
- Each gene uses the SAME center and scale computed from the four condition means; mice are not separately standardized.
- Use this view to examine the combination group without removing a mouse automatically.

**Compare:** Read beside compact_conditions_pattern_heatmap and the leave-one-mouse-out profile table.

**Cautions:**
- The leave-one-out file changes displayed expression profiles only; it does not refit DESeq2 or rerun significance testing.
- High z-scores may be color-clipped at saved limits.

**Source routines:** `tumor_characterization/patterns.py:pattern_matrix`, `tumor_characterization/patterns.py:leave_one_out`

## What is this gene pattern's typical treatment profile?

**Question:** Does this block rise, fall, peak in a monotherapy, or behave nonmonotonically?

**Calculation:** Median and IQR over standardized condition-mean gene profiles within one pattern.

**Denominator:** Genes in the selected pattern, not mice.

- Line: median across genes in this pattern. Shading: gene-wise 25th–75th percentile.
- The membership gene list and mouse-level score plot are linked on the same card.

**Compare:** Open the matching pattern_mouse plot to review biological replication.

**Cautions:**
- The band is not a confidence interval over mice.
- Pattern discovery is exploratory and local to this run.

**Source routines:** `tumor_characterization/patterns.py:run`

## How variable are genes within this response pattern?

**Question:** Does the median pattern conceal heterogeneous gene trajectories?

**Calculation:** Boxplots of condition-mean gene z-scores grouped by the selected pattern.

**Denominator:** Genes, not independent mouse tumors.

- Each box summarizes standardized values across pattern genes in one condition.
- The hidden fliers setting affects drawing only; it is not a removal of biological samples.

**Compare:** Keep separate from the mouse-score figure, whose points represent mice.

**Cautions:**
- Do not interpret box width or gene count as biological replication.
- No boxplot-derived test is introduced here.

**Source routines:** `tumor_characterization/patterns.py:run`

## How consistent is this pattern score across mice?

**Question:** Does each treated mouse support the pattern, including the combination arm?

**Calculation:** Average of the same gene-wise standardized VST values for each independent unit.

**Denominator:** Independent mice with fitted libraries.

- A point is one mouse's average standardized expression across the pattern genes.
- Bars and whiskers are the mouse mean and SD; the pattern gene set is held fixed.

**Compare:** Use mouse IDs, the individual-mouse heatmap and influence tables together.

**Cautions:**
- This is a descriptive score of selected genes, not an independent validation test.
- The shared gene list was selected using the original data.

**Source routines:** `tumor_characterization/patterns.py:run`, `tumor_characterization/core.py:scalar_plot`

## What fractions were observed in each mouse?

**Question:** How consistent are the measured composition changes across the three mice per condition?

**Calculation:** Observed group count divided by the saved model-specific denominator.

**Denominator:** overall_tumor_fraction: all reviewed cells; subtypes_global_fraction: all reviewed cells; subtypes_within_tumor: all tumor cells.

- Each point is a mouse tumor. Bars are mean fraction; whiskers are SD.
- The denominator depends on the model: all reviewed cells or all tumor cells.
- This panel is descriptive. Statistical support is in the matched sccomp contrast table/forest plot.

**Compare:** Compare global and within-tumor subtype views without confusing their denominators.

**Cautions:**
- Relative fraction is not absolute cell density, tumor mass or viable tumor volume.
- Opposite global and within-tumor directions can both be correct.

**Source routines:** `tumor_characterization/composition.py:tables`, `tumor_characterization/composition.py:plot_inputs`

## Which sccomp contrasts are supported, and are the fits usable?

**Question:** Does the fitted relative-composition effect pass the saved Bayesian FDR criterion with adequate diagnostic status?

**Calculation:** Saved sccomp_test contrasts; this navigator performs no model fit, contrast recalculation or new multiplicity correction.

**Denominator:** The composition model shown on the plot; the three denominator models remain distinct.

- Effect and interval are sccomp native coefficient-scale summaries, not percentage-point changes or DESeq2 log2FC.
- The table below retains exact c_FDR and diagnostic status. A threshold-passing row with flagged diagnostics remains review-required.
- Original forest plots highlight c_FDR<0.05; the optional 10C1 figures also print values.

**Compare:** Read observed mouse fractions first, then effect direction, interval, c_FDR, effect threshold and Stan diagnostics.

**Cautions:**
- c_pH0 and c_FDR are Bayesian quantities, not frequentist P values.
- Basic diagnostic pass is not a comprehensive convergence guarantee.
- A missing, failed or untestable fit is not evidence of no treatment difference.

**Source routines:** `tumor_characterization/composition.py:plot_results`, `tumor_characterization/sccomp_backend.R`, `10C1_CT26_sccomp_StatisticalResults.ipynb`

## Which genes characterize the five tumor subgroups?

**Question:** Do each subgroup's candidate genes show adequate expression and detection against the other four tumor groups?

**Calculation:** Within-mouse pseudobulk specificity screening against all four competitors, followed by actual per-cell detection/log-normalized measurement and equal-mouse summaries.

**Denominator:** Eligible cells within each sample/subtype; mice are weighted equally in the displayed summary.

- Dot size is the mouse-averaged fraction of cells detecting the gene.
- Color is mean per-cell log1p normalized expression divided by that gene's maximum across the displayed rows.
- Genes are a screened top-up-to-N list; fewer than N is intentional when fewer meet criteria.

**Compare:** Open the treatment-separated dotplot and within-mouse contrast table using the same marker set.

**Cautions:**
- Color is gene-relative, not comparable absolute expression between genes.
- These markers characterize data-derived groups; no marker P values or independent validation are created here.
- Environmental RNA and treatment composition can influence apparent markers.

**Source routines:** `tumor_characterization/markers.py:rank_candidates`, `tumor_characterization/markers.py:measure_candidate_panel`, `tumor_characterization/markers.py:plot_markers`

## Are subtype markers stable across treatment contexts?

**Question:** Is the pooled subtype signal present in several treatments or mainly one arm?

**Calculation:** Mean per-mouse detection and log1p expression within each condition/subgroup, then per-gene maximum scaling for color.

**Denominator:** Eligible mice/cells in each condition/subgroup; missing rows remain unsupported.

- Rows are treatment × tumor subgroup, with equal-mouse summaries within each row.
- The same selected gene set is used, but gene-relative color maxima are recalculated over this figure's displayed rows.

**Compare:** Compare the pattern of detection and relative color, not raw color magnitude between the pooled and treatment figures.

**Cautions:**
- This is not a separate treatment differential-expression test.
- Missing subtypes/insufficient cells cannot be interpreted as a tested absence of expression.

**Source routines:** `tumor_characterization/markers.py:plot_markers`

## How does the selected tumor population's neighborhood composition differ by treatment?

**Question:** Which other cell types make up immediate, middle or distant surroundings under the chosen definition?

**Calculation:** Count-only radius queries around tumor centers, subtract each source cell once; divide total center–type pairs by total eligible center–neighbor pairs within each mouse, then average across mice.

**Denominator:** Pairs under the selected neighbor denominator, not unique cells in a neighborhood union.

- Bars are equal-mouse means of each mouse's pair-weighted neighbor composition.
- Cumulative 0–100 µm includes immediate neighbors; annulus 50–100 µm excludes the inner 50 µm.
- all_reviewed includes tumor neighbors; non_tumor_reviewed excludes all five tumor types from the denominator.

**Compare:** Keep center population, cumulative/ring mode, radius and denominator fixed. Compare with the matching sample-level bars.

**Cautions:**
- One neighboring cell can occur around several centers; bars do not count unique neighbor cells.
- 50/100/200 are radii, not diameters. No tissue-edge or barrier correction is applied.
- These bars are descriptive, not new treatment tests; missing denominators are NA.

**Source routines:** `tumor_characterization/neighbors.py:sample_metrics`, `tumor_characterization/neighbors.py:run`, `tumor_characterization/neighbors.py:plot`

## Do individual mice support the neighborhood difference?

**Question:** Is a treatment-average neighborhood composition driven by one sample?

**Calculation:** Per-sample total type-specific center-neighbor pairs divided by total eligible center-neighbor pairs.

**Denominator:** all_reviewed or non_tumor_reviewed neighbor pairs; source cell excluded once.

- Each bar is one independent mouse/sample, ordered within treatment in the original plot.
- Its components are pair-weighted fractions, using the radius/ring and denominator displayed on the card.

**Compare:** Read next to the treatment summary at exactly the same settings.

**Cautions:**
- Not a count, density or unique-cell fraction.
- Neighborhoods overlap; neighbors are not additional biological replicates.

**Source routines:** `tumor_characterization/neighbors.py:sample_metrics`, `tumor_characterization/neighbors.py:plot`
