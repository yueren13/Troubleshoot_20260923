"""10G: code-aware, read-only organizer for completed CT26 10A–10F outputs.
No original analysis helper is imported; no fitting, statistics, segmentation or graph
is rerun. Offline report assets are copied; original result paths and hashes remain
in the inventory. Unknown output formats are labeled, not interpreted by appearance.
"""
from __future__ import annotations
import csv, gzip, hashlib, html, io, json, math, os, re, shutil, time, zipfile
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import quote

VERSION='ct26-10G-results-navigator-1.0'
HERE=Path(__file__).resolve().parent
POOLED='All tumor cell'
TUMOR=[f'Tumor cell {i}' for i in range(1,6)]
POPS=[POOLED]+TUMOR
SLUGS={re.sub(r'[^A-Za-z0-9_.-]+','_',p).strip('._'):p for p in POPS}
CONDITIONS=['Vehicle','AntiPD1','Adagrasib','Combination']
DISPLAY={'Vehicle':'Vehicle','AntiPD1':'Anti-PD1','Adagrasib':'Adagrasib','Combination':'Adagrasib + Anti-PD1'}
MODELS=['overall_tumor_fraction','subtypes_global_fraction','subtypes_within_tumor']
QUESTIONS=[
 dict(id='overview',group='START',title='Study overview',question='What is available, and how should I read it?'),
 dict(id='pooled_expression',group='ALL TUMOR',title='1 · Expression response',question='How does the pooled tumor transcriptome respond?'),
 dict(id='pooled_composition',group='ALL TUMOR',title='2 · Composition',question='Does the tumor fraction change among reviewed cells?'),
 dict(id='pooled_architecture',group='ALL TUMOR',title='3 · Spatial architecture',question='Are tumor-rich regions connected, fragmented, or dispersed?'),
 dict(id='subtype_identity',group='TUMOR SUBGROUPS',title='4 · Subgroup identity',question='What distinguishes Tumor cells 1–5?'),
 dict(id='subtype_expression',group='TUMOR SUBGROUPS',title='5 · Expression response',question='How does each tumor subgroup respond to treatment?'),
 dict(id='subtype_composition',group='TUMOR SUBGROUPS',title='6 · Composition',question='Does a subgroup change globally or within the tumor compartment?'),
 dict(id='subtype_architecture',group='TUMOR SUBGROUPS',title='7 · Spatial architecture',question='Where and how is each tumor subgroup organized?'),
 dict(id='neighborhoods',group='TUMOR SUBGROUPS',title='8 · Neighborhoods',question='Who surrounds each tumor group at 50, 100 and 200 µm?'),
 dict(id='compare',group='REVIEW TOOLS',title='Pinned comparisons',question='Compare selected results without losing their definitions.'),
 dict(id='diagnostics',group='REVIEW TOOLS',title='Evidence & diagnostics',question='Which results are supported, missing, or flagged?'),
 dict(id='guide',group='REVIEW TOOLS',title='Plot interpretation guide',question='What is measured and what does each figure NOT show?'),
 dict(id='inventory',group='REVIEW TOOLS',title='Files & provenance',question='Find exact figures, tables, runs and source settings.')]
BRANCHES={
 'patterns':('figures/LRT_patterns','pattern_summary.csv'),
 'sccomp':('sccomp','sccomp_fit_summary.csv'),
 'markers':('markers','candidate_spec.json'),
 'architecture':('architecture','settings.json'),
 'neighbors':('neighborhoods','settings.json')}


def plain(x):
    if isinstance(x,Path):return str(x)
    if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [plain(v) for v in x]
    if isinstance(x,float) and not math.isfinite(x):return None
    return x

def dump(x,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(plain(x),ensure_ascii=False,allow_nan=False,indent=2)+'\n',encoding='utf-8')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()

def jid(x):return hashlib.sha256(json.dumps(plain(x),sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()[:16]
def slug(x):return re.sub(r'[^A-Za-z0-9_.-]+','_',str(x)).strip('._') or 'item'
def load(path,default=None):
    p=Path(path)
    if not p.is_file():return {} if default is None else default
    return json.loads(p.read_text(encoding='utf-8-sig'))
def num(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except (ValueError,TypeError):return None

def rows(path,limit=None):
    p=Path(path);op=gzip.open if p.name.endswith('.gz') else open
    with op(p,'rt',encoding='utf-8-sig',newline='') as f:
        rd=csv.DictReader(f,delimiter='\t' if '.tsv' in p.name else ',')
        output=[]
        for i,r in enumerate(rd):
            if limit is not None and i>=limit:return output,True
            output.append({str(k):v for k,v in r.items() if k is not None})
    return output,False

def write_csv(records,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    keys=list(dict.fromkeys(k for r in records for k in r))
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for r in records:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()})


def locate_characterization_root(root=None,addon_dir=None):
    if root is not None:
        p=Path(root).expanduser().resolve()
        if not (p/'characterization_manifest.json').is_file():
            raise FileNotFoundError(f'{p}: use atlas["out"] printed by 10A, not the package directory or 09A project root.')
        return p
    addon=Path(addon_dir or Path.cwd())
    candidates=[]
    pointer=addon/'active_characterization_project.json'
    if pointer.is_file():
        spec=load(pointer)
        parent=Path(spec.get('output_root') or Path(spec['visibility_project'])/'tumor_characterization')
        candidates=[p.parent.resolve() for p in parent.glob('*/characterization_manifest.json')]
    if (addon/'characterization_manifest.json').is_file():candidates.append(addon.resolve())
    candidates=sorted(set(candidates))
    if len(candidates)==1:return candidates[0]
    raise ValueError('Set CHARACTERIZATION_ROOT explicitly to atlas["out"] from 10A. '
        +'No directory is chosen by newest modification time. Candidates:\n'+'\n'.join(map(str,candidates)))


def discover_runs(root):
    root=locate_characterization_root(root);result={}
    for branch,(relative,marker) in BRANCHES.items():
        found=[]
        for m in sorted((root/relative).glob('*/'+marker)):
            p=m.parent
            settings=load(p/('model_spec.json' if branch=='sccomp' else 'settings.json'))
            record=dict(path=str(p.resolve()),run=p.name,marker=marker,n_png=len(list(p.rglob('*.png'))),settings=settings.get('settings',settings))
            if branch=='patterns':
                manifests=[load(x) for x in p.glob('*/pattern_manifest.json')]
                record['tests']=sorted({x.get('settings',{}).get('test_id','unknown') for x in manifests})
            if branch=='markers':record['settings']=load(m).get('settings',{})
            if branch=='neighbors':record['plot_styles']=[str(x.resolve()) for x in sorted((p/'figures').glob('*')) if x.is_dir()]
            found.append(record)
        result[branch]=found
    return result


def resolve_runs(root,selection=None,neighbor_plot_styles=None):
    candidates=discover_runs(root);selected={};warnings=[]
    selection=selection or {};styles=neighbor_plot_styles or {}
    for branch,options in candidates.items():
        request=selection.get(branch)
        if request is None:
            if len(options)>1:
                raise ValueError(f'{branch}: {len(options)} completed run directories. Set RUN_SELECTION[{branch!r}] explicitly to one or a list; no silent mixing:\n'+
                                 '\n'.join(x['path'] for x in options))
            selected[branch]=[Path(x['path']) for x in options]
        else:
            requested=request if isinstance(request,(list,tuple)) else [request]
            resolved=[]
            for v in requested:
                exact=[Path(x['path']) for x in options if str(v) in (x['path'],x['run']) or Path(v).expanduser().resolve()==Path(x['path'])]
                if len(exact)!=1:raise ValueError(f'{branch}: {v} does not identify one discovered completed run.')
                resolved+=exact
            if len(resolved)!=len(set(resolved)):raise ValueError('Duplicate run selection')
            selected[branch]=resolved
        if not selected[branch]:warnings.append(f'{branch}: no run selected/discovered; absence is not a negative scientific result.')
    ns={}
    for p in selected['neighbors']:
        opts=[q for q in sorted((p/'figures').glob('*')) if q.is_dir()]
        v=styles.get(p.name)
        if v is None:
            if len(opts)>1:raise ValueError(f'Neighbor run {p.name} has several plot styles; set NEIGHBOR_PLOT_STYLES[{p.name!r}] to the exact style folder name.')
            ns[str(p)]=opts
        else:
            vv=v if isinstance(v,(tuple,list)) else [v];choices=[]
            for name in vv:
                q=[o for o in opts if str(name) in (o.name,str(o)) or Path(name).expanduser().resolve()==o]
                if len(q)!=1:raise ValueError(f'Unrecognized neighbor plot style: {name}')
                choices+=q
            ns[str(p)]=choices
    return selected,ns,warnings


class Inventory:
    def __init__(self,root,run_selection=None,neighbor_plot_styles=None,source_addon=None,extra_review_roots=None):
        self.root=locate_characterization_root(root)
        self.selected,self.neighbor_styles,self.warnings=resolve_runs(self.root,run_selection,neighbor_plot_styles)
        self.manifest=load(self.root/'characterization_manifest.json')
        meta=self.root/'source_manifest.csv'
        if not meta.is_file():raise FileNotFoundError(meta)
        self.samples,_=rows(meta)
        self.samples=[{k:r.get(k,'') for k in ('sample','unit','condition')} for r in self.samples]
        if len({r['sample'] for r in self.samples})!=len(self.samples):raise ValueError('Duplicate sample rows')
        if any(r['condition'] not in CONDITIONS for r in self.samples):raise ValueError('Unrecognized condition; no sample-name inference is made')
        self.sample_lookup={slug(r['sample']):r for r in self.samples}
        self.sample_lookup.update({r['sample']:r for r in self.samples})
        self.figures=[];self.files={};self.runs=[];self.sccomp=[];self.diagnostics=[];self.missing=[]
        self.extra_roots=extra_review_roots or []
        self.code_provenance=self._code(source_addon)
        self.add_file(meta,'Study sample/unit mapping','study')
        for name in ['annotation_coverage.csv','celltype_counts.csv']:
            self.add_file(self.root/'tables'/name,name,'study')
        self.add_file(self.root/'characterization_manifest.json','Characterization identity','study')
        self.coverage=rows(self.root/'tables'/'annotation_coverage.csv')[0] if (self.root/'tables'/'annotation_coverage.csv').is_file() else []

    def _code(self,addon):
        reference=load(HERE/'reference_code.json')
        records=[]
        for rel,meta in reference.items():
            f=Path(addon)/rel if addon else None
            actual=sha(f) if f and f.is_file() else None
            status='matches_inspected_source' if actual==meta['sha256'] else 'different_source_review_needed' if actual else 'source_not_checked'
            records.append(dict(file=rel,reference_sha256=meta['sha256'],current_sha256=actual,status=status,methods=meta['methods']))
            if status=='different_source_review_needed':self.warnings.append(f'Plot generator differs from inspected source: {rel}. Check explanations against your local modifications.')
        return records

    def add_file(self,path,label='',branch='',run='',pop='',kind='support'):
        p=Path(path)
        if not p.is_file():return None
        p=p.resolve();fid=jid(str(p))
        if fid not in self.files:
            self.files[fid]=dict(id=fid,path=str(p),name=p.name,label=label or p.name,branch=branch,run_id=run,population=pop,
                                 kind=kind,size_bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns)
        return fid

    def add_figure(self,path,kind,branch,run,sections,population=None,populations=None,title=None,tables=None,**kwargs):
        p=Path(path)
        if not p.is_file():return None
        fid=self.add_file(p,p.name,branch,run,population or '',kind='figure')
        # Avoid duplicate rendered-image records even if associated with two chapters.
        old=next((x for x in self.figures if x['file_id']==fid),None)
        if old:
            old['sections']=list(dict.fromkeys(old['sections']+sections));return old
        item=dict(id=fid,file_id=fid,kind=kind,branch=branch,run_id=run,sections=sections,population=population,
            populations=populations or ([population] if population else []),title=title or p.stem.replace('_',' '),
            filename=p.name,source_path=str(p.resolve()),tables=[x for x in (tables or []) if x],sample=None,condition=None,
            grid_um=None,threshold=None,pattern=None,model=None,test_id=None,mode=None,inner_radius_um=None,
            outer_radius_um=None,denominator=None,scope='summary',metric=None,settings={})
        item.update(kwargs);self.figures.append(item);return item

    def add_run(self,p,branch,settings=None):
        rid=branch+':'+p.name
        rec=dict(id=rid,branch=branch,path=str(p),name=p.name,settings=settings or {},status='discovered')
        self.runs.append(rec);return rid

    def inspect_patterns(self):
        for root in self.selected['patterns']:
            rid=self.add_run(root,'patterns');summary=rows(root/'pattern_summary.csv')[0]
            self.add_file(root/'pattern_summary.csv','Population pattern completion status','patterns',rid)
            statuses={r['population']:r for r in summary}
            for pop in POPS:
                p=root/slug(pop);status=statuses.get(pop,{}).get('status','not_recorded')
                self.diagnostics.append(dict(branch='patterns',run_id=rid,item=pop,status=status,details=statuses.get(pop,{})))
                if status!='complete':self.missing.append(dict(section='pooled_expression' if pop==POOLED else 'subtype_expression',population=pop,status=status,run_id=rid))
                if not p.is_dir():continue
                manifest=load(p/'pattern_manifest.json');s=manifest.get('settings',{});test=s.get('test_id','unrecorded_test')
                fields=['all_LRT_significant_genes.csv','all_gene_pattern_membership.csv','condition_mean_zscores.csv','individual_unit_zscores.csv',
                    'condition_mean_VST.csv','leave_one_mouse_out_profile_influence.csv.gz','excluded_profile_rows.json','pattern_manifest.json','status.json']
                assoc={name:self.add_file(p/name,name,'patterns',rid,pop) for name in fields}
                sections=['pooled_expression'] if pop==POOLED else ['subtype_expression']
                for file,kind in [('compact_conditions_pattern_heatmap.png','lrt_conditions'),('compact_individual_mice_pattern_heatmap.png','lrt_mice')]:
                    self.add_figure(p/file,kind,'patterns',rid,sections,population=pop,test_id=test,settings=s,tables=list(assoc.values()),
                        title=pop+(' · condition-average response patterns' if kind=='lrt_conditions' else ' · individual-mouse expression'))
                for image in sorted(p.glob('pattern_*.png')):
                    m=re.fullmatch(r'pattern_(\d+)_(curve|gene_boxes|mouse_boxpoints)\.png',image.name)
                    if not m:continue
                    pattern=int(m[1]);kind={'curve':'pattern_curve','gene_boxes':'pattern_boxes','mouse_boxpoints':'pattern_mouse'}[m[2]]
                    link=[self.add_file(p/f'pattern_{pattern:02d}_genes.csv','Pattern gene membership','patterns',rid,pop),
                          self.add_file(p/f'pattern_{pattern:02d}_mouse_scores.csv','Mouse pattern scores','patterns',rid,pop),assoc['pattern_manifest.json']]
                    self.add_figure(image,kind,'patterns',rid,sections,population=pop,pattern=pattern,test_id=test,settings=s,tables=link,
                        title=f'{pop} · pattern {pattern} · '+{'curve':'gene profile','gene_boxes':'gene distribution','mouse_boxpoints':'mouse consistency'}[m[2]])

    def inspect_composition(self):
        # Observations are independent of an sccomp fit and are inventoried separately.
        for model in MODELS:
            sec=['pooled_composition'] if model==MODELS[0] else ['subtype_composition']
            source=self.root/'sccomp'/'inputs'/(model+'.csv')
            table=self.add_file(source,'Observed counts, fractions and denominators','composition','observed',kind='table')
            for img in sorted((self.root/'figures'/'composition'/model).glob('*_mouse_fractions.png')):
                name=img.name[:-len('_mouse_fractions.png')];pop=SLUGS.get(name,'Other reviewed cell' if name=='Other_reviewed_cell' else None)
                self.add_figure(img,'composition_observed','composition','observed',sec,population=pop,model=model,tables=[table],title=f'{pop or name} · observed mouse fractions')
        for root in self.selected['sccomp']:
            spec=load(root/'model_spec.json');rid=self.add_run(root,'sccomp',spec.get('settings',{}))
            self.add_file(root/'model_spec.json','sccomp model settings and versions','sccomp',rid)
            fitrows=rows(root/'sccomp_fit_summary.csv')[0]
            self.add_file(root/'sccomp_fit_summary.csv','Fit status for three denominators','sccomp',rid)
            fitmap={r.get('model',r.get('model_name','')):r for r in fitrows}
            for model in MODELS:
                p=root/model;info=load(p/'complete_R.json');status=info.get('status') or fitmap.get(model,{}).get('status','missing_completion')
                diag=dict(branch='sccomp',run_id=rid,item=model,status=status,details=info or fitmap.get(model,{}));self.diagnostics.append(diag)
                sec=['pooled_composition'] if model==MODELS[0] else ['subtype_composition']
                assoc=[self.add_file(p/f,f,'sccomp',rid) for f in ['contrasts.csv','complete_R.json','Stan_parameter_summary.csv','Stan_diagnostics.txt',
                   'fitted_composition_parameters.csv','contrast_expression_audit.csv','contrast_parser_preflight.json','R_run.log']]
                parsed=[]
                if (p/'contrasts.csv').is_file():
                    cr,_=rows(p/'contrasts.csv')
                    for r in cr:
                        v={k:num(r.get(k)) for k in ['c_effect','c_lower','c_upper','c_pH0','c_FDR']}
                        finite=all(v[k] is not None for k in ['c_effect','c_lower','c_upper'])
                        interval=finite and v['c_lower']<=v['c_effect']+1e-9 and v['c_effect']<=v['c_upper']+1e-9
                        diagnostic_pass=status=='diagnostics_pass_basic' and (p/'complete_R.json').is_file()
                        row=dict(run_id=rid,model=model,population=r.get('cell_group',''),contrast=r.get('parameter',''),**v,
                            diagnostic_status=status,effect_threshold=info.get('effect_threshold'),max_rhat=info.get('max_rhat'),
                            n_divergences=info.get('n_divergences'),interval_valid=interval,basic_gate=bool(diagnostic_pass and interval),
                            source_table_id=assoc[0],scope='Original c_FDR; no recalculation or pooled family adjustment')
                        self.sccomp.append(row);parsed.append(row)
                    for contrast in dict.fromkeys(r['contrast'] for r in parsed):
                        image=p/'figures'/(slug(contrast)+'.png')
                        groups=list(dict.fromkeys(r['population'] for r in parsed if r['contrast']==contrast))
                        self.add_figure(image,'sccomp_forest','sccomp',rid,sec,populations=groups,model=model,contrast=contrast,tables=assoc,
                            diagnostic_status=status,settings=info,title=f'{model} · {contrast}')
                else:self.missing.append(dict(section=sec[0],status='no_contrasts_table',model=model,run_id=rid))
                # Read any saved predictive-check pictures as unidentified extras: format varies by sccomp.
                for img in p.glob('*.png'):
                    self.add_figure(img,'unknown','sccomp',rid,['diagnostics'],model=model,tables=assoc,title='sccomp extra: '+img.stem)
            review_dirs=sorted((root/'statistical_results_review').glob('*')) if (root/'statistical_results_review').is_dir() else []
            if len(review_dirs)>1:self.warnings.append(f'{root.name}: several 10C1 review directories; all retained as explicitly labelled variants, never merged statistical results.')
            for review in review_dirs:
                if not (review/'all_sccomp_contrasts.csv').is_file():continue
                review_id=rid+'/review:'+review.name
                t=[self.add_file(review/n,n,'sccomp',review_id) for n in ['all_sccomp_contrasts.csv','model_diagnostic_review.csv','cFDR_pass_and_basic_diagnostics_pass.csv','cFDR_pass_but_review_required.csv','review_spec.json']]
                for model in MODELS:
                    sec=['pooled_composition'] if model==MODELS[0] else ['subtype_composition']
                    for r in [r for r in self.sccomp if r['model']==model and r['run_id']==rid]:
                        img=review/'labelled_forest_plots'/(slug(model+'__'+r['contrast'])+'.png')
                        self.add_figure(img,'sccomp_forest','sccomp',rid,sec,model=model,contrast=r['contrast'],tables=t,
                            diagnostic_status=r['diagnostic_status'],populations=list(dict.fromkeys(z['population'] for z in self.sccomp if z['model']==model and z['run_id']==rid)),
                            style_id='10C1:'+review.name,title=f'{model} · {r["contrast"]} · labelled statistics')

    def inspect_markers(self):
        for root in self.selected['markers']:
            spec=load(root/'candidate_spec.json');rid=self.add_run(root,'markers',spec.get('settings',{}))
            common=[self.add_file(root/n,n,'markers',rid) for n in ['candidate_spec.json','candidate_markers.csv','all_gene_specificity_ranking.csv.gz',
                       'candidate_within_mouse_contrasts.csv.gz','candidate_observed_expression_all_samples.csv.gz','equal_mouse_marker_means.csv']]
            for p in sorted(root.glob('top_*_markers_dotplot_*.png')):
                m=re.fullmatch(r'top_(\d+)_markers_dotplot_(pooled|by_treatment)\.png',p.name)
                if not m:continue
                links=common+[self.add_file(root/f'top_{m[1]}_specific_markers.csv','Displayed marker list','markers',rid),self.add_file(root/f'top_{m[1]}_marker_selection.json','Marker display selection','markers',rid)]
                self.add_figure(p,'marker_pooled' if m[2]=='pooled' else 'marker_treatment','markers',rid,['subtype_identity'],populations=TUMOR,
                    top_n=int(m[1]),settings={**spec.get('settings',{}),**load(root/f'top_{m[1]}_marker_selection.json')},tables=links,
                    title=f'Top up-to-{m[1]} subtype markers · '+('pooled mice' if m[2]=='pooled' else 'separated by treatment'))

    def inspect_architecture(self):
        for root in self.selected['architecture']:
            spec=load(root/'settings.json');settings=spec.get('settings',spec);rid=self.add_run(root,'architecture',settings)
            global_links={name:self.add_file(root/name,name,'architecture',rid) for name in ['settings.json','autocorrelation_all_samples.csv',
                 'patch_summary_all_samples.csv','Ripley_raster_all_samples.csv','coverage_all_samples.csv','Moran_I_independent_mouse_tests.csv',
                 'Geary_C_independent_mouse_tests.csv','largest_patch_independent_mouse_tests.csv']}
            for folder in [p for p in root.iterdir() if p.is_dir() and p.name in self.sample_lookup]:
                meta=self.sample_lookup[folder.name]
                local={name:self.add_file(folder/name,name,'architecture',rid) for name in ['autocorrelation.csv','patch_summary.csv','Ripley_raster.csv','coverage.csv','complete.json']}
                if not (folder/'complete.json').is_file():self.warnings.append(f'Architecture {rid}/{meta["sample"]}: incomplete sample marker; available files shown but not certified complete.')
                for img in sorted(folder.glob('*.png')):
                    m=re.fullmatch(r'(.+)_patches_grid([0-9.]+)_thr([0-9.]+)\.png',img.name)
                    fm=re.fullmatch(r'(.+)_fraction_grid([0-9.]+)\.png',img.name)
                    if not m and not fm:continue
                    pop=SLUGS.get((m or fm)[1]);width=float((m or fm)[2]);threshold=float(m[3]) if m else None
                    if pop is None:continue
                    sec=['pooled_architecture'] if pop==POOLED else ['subtype_architecture']
                    link=[local['coverage.csv'],local['patch_summary.csv'] if m else local['autocorrelation.csv'],global_links['settings.json']]
                    if m:link+=[self.add_file(folder/f'{slug(pop)}_grid{width:g}_thr{threshold:g}_components.csv','Patch component areas and cell counts','architecture',rid,pop)]
                    self.add_figure(img,'patch_map' if m else 'fraction_map','architecture',rid,sec,population=pop,sample=meta['sample'],condition=meta['condition'],
                        grid_um=width,threshold=threshold,settings=settings,tables=link,scope='sample',
                        title=f'{meta["sample"]} · {pop} · '+(f'patches ≥ {threshold:.0%}' if m else 'tile population fraction'))
            # Numeric completion counts, not a biological conclusion.
            for r in rows(root/'coverage_all_samples.csv')[0] if (root/'coverage_all_samples.csv').is_file() else []:
                self.diagnostics.append(dict(branch='architecture',run_id=rid,item=r.get('sample','')+' grid '+r.get('grid_um',''),
                    status=r.get('window_source','unknown_window'),details=r))
            for p in sorted((root/'figures').glob('*/*.png')):
                pop=SLUGS.get(p.parent.name)
                if pop is None:continue
                sec=['pooled_architecture'] if pop==POOLED else ['subtype_architecture']
                m=re.fullmatch(r'grid([0-9.]+)_(Moran_I|Geary_C)\.png',p.name)
                patch=re.fullmatch(r'grid([0-9.]+)_thr([0-9.]+)_(largest_patch_fraction_of_group_cells|cell_weighted_patch_area_um2|patches_per_mm2_support)\.png',p.name)
                if m:
                    kind='moran' if m[2]=='Moran_I' else 'geary'
                    self.add_figure(p,kind,'architecture',rid,sec,population=pop,grid_um=float(m[1]),metric=m[2],tables=[global_links['autocorrelation_all_samples.csv'],global_links[m[2]+'_independent_mouse_tests.csv']],settings=settings,title=f'{pop} · {m[2]} across mice')
                elif patch:
                    kind={'largest_patch_fraction_of_group_cells':'patch_largest','cell_weighted_patch_area_um2':'patch_weighted','patches_per_mm2_support':'patch_density'}[patch[3]]
                    self.add_figure(p,kind,'architecture',rid,sec,population=pop,grid_um=float(patch[1]),threshold=float(patch[2]),metric=patch[3],settings=settings,
                        tables=[global_links['patch_summary_all_samples.csv'],global_links['largest_patch_independent_mouse_tests.csv']],title=f'{pop} · {patch[3].replace("_"," ")}')
                elif p.name in ['L_minus_r_um.png','conditional_excess_L_um.png']:
                    kind='ripley_raw' if p.name=='L_minus_r_um.png' else 'ripley_conditional'
                    self.add_figure(p,kind,'architecture',rid,sec,population=pop,grid_um=settings.get('ripley_grid_um'),metric=p.stem,settings=settings,
                        tables=[global_links['Ripley_raster_all_samples.csv'],global_links['coverage_all_samples.csv']],title=f'{pop} · {p.stem.replace("_"," ")}')

    def inspect_neighbors(self):
        for root in self.selected['neighbors']:
            spec=load(root/'settings.json');rid=self.add_run(root,'neighbors',spec.get('settings',spec))
            links=[self.add_file(root/n,n,'neighbors',rid) for n in ['settings.json','all_sample_neighborhoods.csv.gz','equal_mouse_treatment_summaries.csv']]
            for style in self.neighbor_styles[str(root)]:
                for p in sorted(style.glob('*/*.png')):
                    pop=SLUGS.get(p.parent.name)
                    m=re.fullmatch(r'(cumulative|annulus)_([0-9.]+)_([0-9.]+)_(all_reviewed|non_tumor_reviewed)_(treatment|sample)\.png',p.name)
                    if not pop or not m:continue
                    self.add_figure(p,'neighbor_'+m[5],'neighbors',rid,['neighborhoods'],population=pop,mode=m[1],
                        inner_radius_um=float(m[2]),outer_radius_um=float(m[3]),denominator=m[4],style_id=style.name,
                        scope='treatment_summary' if m[5]=='treatment' else 'all_samples',settings=spec.get('settings',{}),tables=links,
                        title=f'{pop} · {m[1]} {m[2]}–{m[3]} µm · '+('treatment means' if m[5]=='treatment' else 'individual mice'))

    def collect(self):
        self.inspect_patterns();self.inspect_composition();self.inspect_markers();self.inspect_architecture();self.inspect_neighbors()
        known={Path(f['source_path']).resolve() for f in self.figures}
        # Preserve unrecognized files ONLY inside the explicitly selected runs.
        for branch,roots in self.selected.items():
            for root in roots:
                for p in sorted(root.rglob('*.png')):
                    if p.resolve() in known:continue
                    # A neighbor style not selected is deliberately excluded, not "unknown".
                    if branch=='neighbors' and not any(p.is_relative_to(s) for s in self.neighbor_styles[str(root)]):continue
                    self.add_figure(p,'unknown',branch,branch+':'+root.name,['inventory'],title='Unclassified · '+p.stem)
        kind_rank={'lrt_conditions':0,'lrt_mice':1,'pattern_curve':2,'pattern_boxes':2,'pattern_mouse':2,
                   'composition_observed':0,'sccomp_forest':1,'marker_pooled':0,'marker_treatment':1,
                   'fraction_map':0,'patch_map':1,'moran':2,'geary':3,'patch_largest':4,'patch_weighted':5,
                   'patch_density':6,'ripley_raw':7,'ripley_conditional':8,'neighbor_treatment':0,'neighbor_sample':1,'unknown':99}
        sample_order={r['sample']:i for c in CONDITIONS for i,r in enumerate([x for x in self.samples if x['condition']==c])}
        def display_order(f):
            pop_rank=POPS.index(f['population']) if f.get('population') in POPS else -1
            condition_rank=CONDITIONS.index(f['condition']) if f.get('condition') in CONDITIONS else -1
            return (pop_rank,kind_rank.get(f['kind'],99),str(f.get('run_id','')),
                    f.get('grid_um') or 0,f.get('threshold') or 0,f.get('pattern') or 0,
                    {'pattern_curve':0,'pattern_boxes':1,'pattern_mouse':2}.get(f['kind'],0),
                    f.get('outer_radius_um') or 0,condition_rank,sample_order.get(f.get('sample'),-1),f['filename'])
        self.figures.sort(key=display_order)
        if not self.figures:self.warnings.append('No completed recognized figures. Check source directory/run selections; this is not evidence of absent biological effects.')
        return self


def preview_inventory(root,selection=None,neighbor_plot_styles=None,source_addon=None):
    inv=Inventory(root,selection,neighbor_plot_styles,source_addon).collect()
    summary={q['id']:sum(q['id'] in f['sections'] for f in inv.figures) for q in QUESTIONS}
    return dict(characterization_root=str(inv.root),figure_count=len(inv.figures),table_file_count=sum(f['kind']!='figure' for f in inv.files.values()),
                section_counts=summary,runs=inv.runs,warnings=inv.warnings)


def build_report(root,selection=None,neighbor_plot_styles=None,source_addon=None,output_parent=None,
                 copy_limit_gib=6,table_copy_limit_mb=100,preview_rows=150,make_thumbnails=True,
                 report_title='CT26 · Tumor characterization navigator',demo=False):
    inv=Inventory(root,selection,neighbor_plot_styles,source_addon).collect()
    guide=load(HERE/'ct26_plot_guide.json')
    files=list(inv.files.values());size=sum(f['size_bytes'] for f in files if f['kind']=='figure' or f['size_bytes']<=table_copy_limit_mb*1024**2)
    if size>copy_limit_gib*1024**3:raise OSError(f'Report sources require {size/1024**3:.2f} GiB, above COPY_LIMIT_GIB={copy_limit_gib}. Choose fewer runs or explicitly increase the report-copy budget.')
    parent=Path(output_parent).expanduser().resolve() if output_parent else inv.root/'results_navigator'
    parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(parent).free<size*1.15+25*1024**2:raise OSError('Not enough free disk for a portable copy of selected figures/tables.')
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    fingerprint=jid(dict(version=VERSION,root=str(inv.root),files=[(f['path'],f['size_bytes'],f['mtime_ns']) for f in files],runs=inv.runs))
    dest=parent/f'10G_review_{stamp}_{fingerprint[:8]}'
    (dest/'assets'/'figures').mkdir(parents=True);(dest/'assets'/'tables').mkdir();(dest/'assets'/'thumbs').mkdir()
    thumb_ok=False
    if make_thumbnails:
        try:from PIL import Image;thumb_ok=True
        except ImportError:inv.warnings.append('Pillow is unavailable; original images are used as lazy-loaded previews.')
    for f in files:
        p=Path(f['path']);before=p.stat()
        if before.st_size!=f['size_bytes'] or before.st_mtime_ns!=f['mtime_ns']:raise RuntimeError(f'Source changed while building inventory: {p}')
        f['copied']=False;f['url']=None;f['preview']=None
        if f['kind']!='figure' and f['size_bytes']>table_copy_limit_mb*1024**2:
            f['copy_note']=f'Not copied: exceeds {table_copy_limit_mb} MiB table limit. Source path retained.';continue
        category='figures' if f['kind']=='figure' else 'tables'
        # Retain human-readable name after stable ID; spaces encoded in URLs later.
        target=dest/'assets'/category/(f['id']+'__'+p.name)
        shutil.copyfile(p,target)
        after=p.stat()
        if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise RuntimeError(f'Source changed during copy: {p}')
        f['sha256']=sha(target);f['url']=quote(target.relative_to(dest).as_posix(),safe='/');f['copied']=True
        if f['kind']=='figure':
            if thumb_ok:
                try:
                    with Image.open(target) as im:
                        f['image_width'],f['image_height']=im.size
                        thumb=im.convert('RGB');thumb.thumbnail((760,620));tp=dest/'assets'/'thumbs'/(f['id']+'.jpg')
                        thumb.save(tp,quality=86,optimize=True);f['thumbnail']=quote(tp.relative_to(dest).as_posix(),safe='/')
                except Exception as exc:f['thumbnail_warning']=str(exc)
        elif any(p.name.endswith(x) for x in ['.csv','.csv.gz','.tsv','.tsv.gz']):
            try:
                preview,truncated=rows(target,preview_rows);f['preview']={'rows':preview,'truncated':truncated,'limit':preview_rows}
            except Exception as exc:f['preview_error']=str(exc)
        elif p.suffix=='.json' and p.stat().st_size<2*1024**2:
            try:f['json_preview']=load(target)
            except Exception as exc:f['preview_error']=str(exc)
    fmap={f['id']:f for f in files}
    for f in inv.figures:
        meta=fmap[f['file_id']];f['url']=meta.get('url');f['thumbnail']=meta.get('thumbnail',meta.get('url'))
        f['image_width']=meta.get('image_width');f['image_height']=meta.get('image_height')
        # Matched comparisons require same population, statistic and scientific parameters.
        keys=['kind','branch','run_id','population','populations','grid_um','threshold','test_id','pattern','mode','inner_radius_um','outer_radius_um','denominator','model','metric']
        f['match_key']=jid({k:f.get(k) for k in keys})
    source_record=dict(root=str(inv.root),characterization_manifest=inv.manifest,selected_runs=inv.runs,code_provenance=inv.code_provenance)
    data=dict(version=VERSION,title=report_title,created=datetime.now(timezone.utc).isoformat(),demo=demo,
              study=dict(samples=inv.samples,conditions=CONDITIONS,condition_labels=DISPLAY,populations=POPS),
              questions=QUESTIONS,figures=inv.figures,files=files,guides=guide,runs=inv.runs,diagnostics=inv.diagnostics,
              sccomp=inv.sccomp,coverage=inv.coverage,missing=inv.missing,warnings=inv.warnings,source=source_record,
              report=dict(figure_count=len(inv.figures),copied_bytes=size,table_preview_limit=preview_rows,interpretations_are_results=False))
    dump(data,dest/'report_data.json');dump(source_record,dest/'source_provenance.json')
    write_csv(files,dest/'file_inventory.csv');write_csv([{k:v for k,v in f.items() if k not in ['settings']} for f in inv.figures],dest/'figure_inventory.csv')
    write_csv(inv.sccomp,dest/'sccomp_original_results_with_diagnostics.csv');write_csv(inv.missing,dest/'missing_or_untestable.csv')
    for filename in ['navigator.css','navigator.js','ct26_plot_guide.json','PLOT_INTERPRETATION_GUIDE.md']:
        shutil.copyfile(HERE/filename,dest/filename)
    encoded=json.dumps(plain(data),ensure_ascii=False,allow_nan=False,separators=(',',':')).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e')
    template=(HERE/'navigator_template.html').read_text(encoding='utf-8')
    htmlout=template.replace('@@REPORT_TITLE@@',html.escape(report_title)).replace('@@EMBEDDED_DATA@@',encoded)
    (dest/'index.html').write_text(htmlout,encoding='utf-8')
    # No-script, paginated-independent fallback: ordinary links and descriptions, no embedded image wall.
    fallback=['<!doctype html><html><head><meta charset="utf-8"><title>CT26 static index</title></head><body><h1>Static result index</h1>',
      '<p>Interactive report: <a href="index.html">index.html</a>. Source analyses were not rerun. This fallback works without JavaScript.</p>']
    for q in QUESTIONS:
        fs=[f for f in inv.figures if q['id'] in f['sections']]
        if not fs:continue
        fallback.append('<h2>'+html.escape(q['title'])+'</h2><p>'+html.escape(q['question'])+'</p><ul>')
        for f in fs:fallback.append('<li><a href="'+html.escape(f['url'] or '',quote=True)+'">'+html.escape(f['title'])+'</a> — '+html.escape(guide[f['kind']]['denominator'])+'</li>')
        fallback.append('</ul>')
    fallback.append('</body></html>');(dest/'static_index.html').write_text('\n'.join(fallback),encoding='utf-8')
    (dest/'README_OPEN_REPORT.txt').write_text('Open index.html in a regular browser. This offline report uses local JavaScript and embedded JSON, not a live server or external/CDN requests.\nIf a Jupyter preview suppresses scripts, use Open in New Browser Tab, or download/extract the entire report folder and open index.html locally.\nKeep assets/, navigator.js and navigator.css with index.html. static_index.html provides a no-JavaScript fallback.\nSource plots/tables are copied; original analyses were not rerun. Notes are saved locally only when browser storage permits; Export notes creates a portable JSON backup.\nNo biological conclusion was generated by this navigation layer.\n')
    # Confirm all embedded asset URLs point to real local files before delivery.
    for f in files:
        if f.get('url'):
            from urllib.parse import unquote
            assert (dest/unquote(f['url'])).is_file()
    print(f'Report: {dest}/index.html\nFigures: {len(inv.figures)}; copied assets: {size/1024**2:.1f} MiB\nNo original files or fitted results were changed.')
    return dest,data


def package_report(report_dir,archive=None):
    root=Path(report_dir).resolve()
    if not (root/'report_data.json').is_file() or not (root/'index.html').is_file():raise ValueError('Not a built 10G report directory')
    target=Path(archive) if archive else root.parent/(root.name+'.zip')
    if target.resolve().is_relative_to(root):raise ValueError('Archive must be outside the report folder')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file():z.write(p,arcname=(Path(root.name)/p.relative_to(root)).as_posix())
    with zipfile.ZipFile(target) as z:
        bad=z.testzip()
        if bad:raise IOError('Archive integrity failure: '+bad)
    return target
