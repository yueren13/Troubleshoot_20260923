# Validation — CT26 10G results navigator

## Executed synthetic integration tests

The test fixture used 12 synthetic mouse/sample records, four conditions, six tumor populations, and 396 PNGs using the actual 10B–10F filename/layout contracts. No real CT26 result was generated or interpreted.

- PASS: Source-aware classification, exact patch parameters, sccomp diagnostic gates and unknown outputs
- PASS: Multiple scientific runs require explicit selection; no newest-version guessing
- PASS: Portable asset copies retain exact bytes, matched 12-mouse comparison keys and original table downloads
- PASS: Offline data embedded without AJAX/network; report explicitly marked synthetic
- PASS: Portable report archive created and integrity-checked

## Browser interaction tests

- PASS: In-memory browser rendering of generated HTML/JS with embedded synthetic assets
- PASS: Question routing and exact grid/threshold filters with paginated 12-sample set
- PASS: Figure definition dialog exposes exact support rules; four-condition board has all 12 correct mice
- PASS: Cross-chapter pin board plus note JSON export/import without relying on local storage
- PASS: sccomp FDR and diagnostic-gate filters distinguish passing, flagged and missing results
- PASS: No JavaScript page errors during interactive navigation
- PASS: no external network requests occurred during the browser UI test.

## Notebook and artifact checks

- PASS: the entire self-contained notebook executed on the synthetic completed-output tree, including embedded runtime restoration, source discovery, report construction, and portable ZIP packaging.
- PASS: source files retained their byte hashes after report construction; copied full assets retained exact original bytes.
- PASS: Python helper and all notebook code cells compile; nbformat validates the notebook; node --check validates the shipped JavaScript.
- PASS: visually inspected overview, explained patch dialog, and four-treatment/mouse comparison interface.

## Limits and untested environment paths

- Actual server-resident CT26 outputs were unavailable; adapter behavior on locally modified file layouts is disclosed rather than guaranteed.
- The installed test Chromium policy blocked file:// and localhost navigation. UI tests therefore loaded the generated HTML/JavaScript in memory with synthetic images embedded, and bypassed test-only CSP restrictions. This tests routing, filters, dialogs, matching, note export/import and statistical gates; it does NOT validate your JupyterLab file serving or corporate browser policy end to end.
- The shipped report embeds its data and uses only local scripts/assets, with no AJAX, external CDN or analytics. A static no-JavaScript index is included as a fallback.
- Local browser note persistence depends on allowed storage; export/import was tested independently of localStorage.
- No scientific computation, R/Stan fit, statistical test, FDR adjustment, raw data extraction, or plot re-analysis occurs in this notebook. The guide follows the supplied helper code; current generator hashes are checked when provided.

The test files in tests/ are optional developer fixtures, not biological example results for interpretation.
