"""Synthetic integration/browser test fixtures only. No actual CT26 results.
Set CT26_TEST_OUTPUT to a scratch folder. Pillow is required only for this test.
"""
from pathlib import Path
import os,sys,tempfile,csv,json,hashlib
from PIL import Image,ImageDraw
PKG=Path(__file__).resolve().parents[1];sys.path.insert(0,str(PKG))
import ct26_results_navigator as nav
ROOT=Path(os.environ.get('CT26_TEST_OUTPUT',tempfile.mkdtemp(prefix='ct26_10G_')))
ROOT.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/'fixture_source';SOURCE.mkdir(exist_ok=True)
checks=[]
def check(name):checks.append(name);print('PASS:',name,flush=True)
def js(x,p):nav.dump(x,p)
def csvfile(records,p):nav.write_csv(records,p)
def image(path,label='Synthetic display test'):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
 canvas=Image.new('RGB',(1000,740),'white');d=ImageDraw.Draw(canvas)
 d.text((35,25),'SYNTHETIC VALIDATION - NOT CT26 RESULTS',fill='black')
 d.text((35,55),label,fill='black');d.rectangle((100,140,700,650),outline='black',width=2)
 if 'patch' in str(p):
  for bounds,fill in [((145,200,330,450),'#9cb6d0'),((400,210,480,300),'#e6b882'),((510,350,610,390),'#aabf89'),((360,500,400,540),'#ad93b9')]:d.rectangle(bounds,fill=fill)
 elif 'heatmap' in str(p):
  for y in range(150,630,20):
   for x in range(110,690,120):d.rectangle((x,y,x+115,y+15),fill=['#45749d','#eab7a8','#cf695c','#c1d7e2'][(y//20+x//120)%4])
 else:
  for k in range(4):d.rectangle((140+k*130,260+(k%2)*50,205+k*130,650),fill='#6aa4a6')
 canvas.save(p)

samples=[]
for i,c in enumerate(nav.CONDITIONS):
 for j in range(3):samples.append(dict(sample=f'S{i+1}{j+1}',unit=f'M{i+1}{j+1}',condition=c))
js(dict(project_id='SYNTHETIC-PROJECT',version='test'),SOURCE/'characterization_manifest.json')
csvfile(samples,SOURCE/'source_manifest.csv')
csvfile([{**s,'n_full':1000,'n_reviewed':900,'n_all_tumor':600,'reviewed_fraction':.9} for s in samples],SOURCE/'tables'/'annotation_coverage.csv')
csvfile([{**s,'population':'All tumor cell','n_cells':600} for s in samples],SOURCE/'tables'/'celltype_counts.csv')
P=SOURCE/'figures'/'LRT_patterns'/'runA'
csvfile([dict(population=p,status='complete',n_genes=120,n_patterns=2) for p in nav.POPS],P/'pattern_summary.csv')
for pop in nav.POPS:
 f=P/nav.slug(pop)
 js(dict(settings=dict(test_id='LRT_any_condition',alpha=.05,zlim=2,n_patterns=2)),f/'pattern_manifest.json')
 csvfile([dict(gene=f'Gene{i}',pattern=1 if i<60 else 2,padj=.01) for i in range(120)],f/'all_gene_pattern_membership.csv')
 for typ in ['conditions','individual_mice']:image(f/f'compact_{typ}_pattern_heatmap.png',pop+' | '+typ)
 for pat in [1,2]:
  csvfile([dict(gene=f'Gene{i}',pattern=pat) for i in range(6)],f/f'pattern_{pat:02d}_genes.csv')
  csvfile([dict(**s,pattern_score=1) for s in samples],f/f'pattern_{pat:02d}_mouse_scores.csv')
  for typ in ['curve','gene_boxes','mouse_boxpoints']:image(f/f'pattern_{pat:02d}_{typ}.png',pop+f' pattern {pat} {typ}')
SC=SOURCE/'sccomp'/'fitA';js(dict(settings={'effect_threshold':.1}),SC/'model_spec.json')
csvfile([dict(model=m,status='diagnostics_pass_basic') for m in nav.MODELS],SC/'sccomp_fit_summary.csv')
for i,model in enumerate(nav.MODELS):
 p=SC/model;status='diagnostics_pass_basic' if i!=2 else 'REVIEW_CONVERGENCE'
 js(dict(status=status,effect_threshold=.1,max_rhat=1.01 if i!=2 else 1.12,n_divergences=0 if i!=2 else 2),p/'complete_R.json')
 contrasts=['conditionAntiPD1 - conditionVehicle','conditionCombination - conditionVehicle']
 cats=[nav.POOLED,'Other reviewed cell'] if i==0 else nav.TUMOR
 rows=[dict(cell_group=g,parameter=c,c_effect=.5,c_lower=.2,c_upper=.8,c_pH0=.001,c_FDR=.01 if g!=cats[-1] else '') for g in cats for c in contrasts]
 csvfile(rows,p/'contrasts.csv')
 for c in contrasts:image(p/'figures'/(nav.slug(c)+'.png'),model+' '+c)
 for g in cats:image(SOURCE/'figures'/'composition'/model/(nav.slug(g)+'_mouse_fractions.png'),g+' '+model)
 csvfile([dict(**s,cell_group=g,count=60,denominator=100,fraction=.6) for s in samples for g in cats],SOURCE/'sccomp'/'inputs'/(model+'.csv'))
# One optional labelled C1 review; direct table remains native model output.
REV=SC/'statistical_results_review'/'reviewA'
csvfile([dict(model=nav.MODELS[0],parameter=contrasts[0])],REV/'all_sccomp_contrasts.csv')
image(REV/'labelled_forest_plots'/(nav.slug(nav.MODELS[0]+'__'+contrasts[0])+'.png'),'Labelled synthetic review')
MK=SOURCE/'markers'/'markersA';js(dict(settings={'min_cells_per_subtype':30}),MK/'candidate_spec.json')
for n in [5,10]:
 for typ in ['pooled','by_treatment']:image(MK/f'top_{n}_markers_dotplot_{typ}.png',f'Top {n} {typ}')
 csvfile([dict(population='Tumor cell 1',gene='Gene1')],MK/f'top_{n}_specific_markers.csv')
A=SOURCE/'architecture'/'archA';settings=dict(grid_sizes_um=[25,50],min_full_cells=3,min_reviewed_cells=3,min_reviewed_fraction=.5,min_group_cells=2,ripley_grid_um=25,ripley_radii_um=[50,100,200])
js(dict(settings=settings),A/'settings.json')
coverage=[];patch=[];autoc=[];ripley=[]
for s in samples:
 f=A/s['sample'];js(dict(status='complete'),f/'complete.json')
 for w in [25,50]:
  coverage.append(dict(**s,grid_um=w,window_source='all_reference_occupied_tiles_PROXY',n_field_tiles=40))
  image(f/f'All_tumor_cell_fraction_grid{w}.png',f"{s['sample']} fraction grid {w}")
  for t in [.3,.5]:
   image(f/f'All_tumor_cell_patches_grid{w}_thr{t}.png',f"{s['sample']} patches grid {w} fraction {t}")
   patch.append(dict(**s,population=nav.POOLED,grid_um=w,fraction_threshold=t,n_patches=4))
   csvfile([dict(component=1,area_um2=625,group_cells=8)],f/f'All_tumor_cell_grid{w}_thr{t}_components.csv')
  autoc.append(dict(**s,population=nav.POOLED,grid_um=w,Moran_I=.3,Geary_C=.7))
 for r in [50,100,200]:ripley.append(dict(**s,population=nav.POOLED,radius_um=r,L_minus_r_um=5,conditional_excess_L_um=1))
 for name,rs in [('coverage',coverage[-2:]),('patch_summary',patch[-4:]),('autocorrelation',autoc[-2:]),('Ripley_raster',ripley[-3:])]:csvfile(rs,f/(name+'.csv'))
for name,rs in [('coverage',coverage),('patch_summary',patch),('autocorrelation',autoc),('Ripley_raster',ripley)]:csvfile(rs,A/(name+'_all_samples.csv'))
for pop in nav.POPS:
 f=A/'figures'/nav.slug(pop)
 for w in [25,50]:
  for kind in ['Moran_I','Geary_C']:image(f/f'grid{w}_{kind}.png',pop+' '+kind)
  for t in ([.3,.5] if pop==nav.POOLED else [.1,.25]):
   for metric in ['largest_patch_fraction_of_group_cells','cell_weighted_patch_area_um2','patches_per_mm2_support']:image(f/f'grid{w}_thr{t}_{metric}.png',pop+' '+metric)
 for metric in ['L_minus_r_um','conditional_excess_L_um']:image(f/(metric+'.png'),pop+' '+metric)
N=SOURCE/'neighborhoods'/'neighborsA';js(dict(settings=dict(radii_um=[50,100,200])),N/'settings.json')
csvfile([dict(population=nav.POOLED,neighbor_type='T cell 1',mean_pair_fraction=.1)],N/'equal_mouse_treatment_summaries.csv')
for pop in nav.POPS:
 for mode,low,high in [('cumulative',0,50),('cumulative',0,100),('cumulative',0,200),('annulus',0,50),('annulus',50,100),('annulus',100,200)]:
  for den in ['all_reviewed','non_tumor_reviewed']:
   for view in ['sample','treatment']:image(N/'figures'/'styleA'/nav.slug(pop)/f'{mode}_{low}_{high}_{den}_{view}.png',f'{pop} {mode} {low}-{high} {den} {view}')
# Unknown outputs are identified rather than assigned a scientific meaning.
image(A/'Unrecognized_custom_plot.png','Unknown output')
original={p:nav.sha(p) for p in SOURCE.rglob('*') if p.is_file()}
inv=nav.Inventory(SOURCE,source_addon=os.environ.get('CT26_SOURCE_ADDON')).collect()
assert len(inv.samples)==12
patchf=[f for f in inv.figures if f['kind']=='patch_map' and f['grid_um']==25 and f['threshold']==.3]
assert len(patchf)==12 and len(set(f['match_key'] for f in patchf if 'match_key' in f))==0
assert len(inv.sccomp)==24
assert any(x['c_FDR'] is not None and x['c_FDR']<.05 and not x['basic_gate'] for x in inv.sccomp)
assert any(x['c_FDR'] is None for x in inv.sccomp)
assert any(x['kind']=='unknown' for x in inv.figures)
check('Source-aware classification, exact patch parameters, sccomp diagnostic gates and unknown outputs')
# Ambiguity must stop rather than choose the newest fit.
new=SOURCE/'architecture'/'otherRun';js(dict(settings=settings),new/'settings.json')
try:nav.resolve_runs(SOURCE)
except ValueError as ex:assert 'architecture' in str(ex)
else:raise AssertionError('Ambiguous runs were silently merged')
selected,_,_=nav.resolve_runs(SOURCE,{'architecture':'archA'});assert selected['architecture']==[A.resolve()]
(new/'settings.json').unlink();new.rmdir()
check('Multiple scientific runs require explicit selection; no newest-version guessing')
# Small preview limit demonstrates full-file copies are not truncated by inline tables.
report,data=nav.build_report(SOURCE,source_addon=os.environ.get('CT26_SOURCE_ADDON'),output_parent=ROOT/'reports',preview_rows=7,
 report_title='SYNTHETIC CT26 interface validation',demo=True)
assert all(nav.sha(p)==h for p,h in original.items())
assert len(data['figures'])>200
family=[f for f in data['figures'] if f['kind']=='patch_map' and f['grid_um']==25 and f['threshold']==.3]
assert len(set(f['match_key'] for f in family))==1
assert {f['condition'] for f in family}==set(nav.CONDITIONS)
assert any(f.get('preview',{}).get('truncated',False) for f in data['files'] if f.get('preview'))
for item in data['files']:
 if item['copied']:
  from urllib.parse import unquote
  assert nav.sha(report/unquote(item['url']))==nav.sha(item['path'])
check('Portable asset copies retain exact bytes, matched 12-mouse comparison keys and original table downloads')
html=(report/'index.html').read_text();assert 'fetch(' not in (report/'navigator.js').read_text()
assert 'SYNTHETIC CT26' in html and 'report-data' in html
check('Offline data embedded without AJAX/network; report explicitly marked synthetic')
z=nav.package_report(report);assert z.is_file()
check('Portable report archive created and integrity-checked')
js(dict(checks=checks,report=str(report),source=str(SOURCE),figure_count=len(data['figures']),files=len(data['files'])),ROOT/'integration_results.json')
print('REPORT_DIR='+str(report));print('ALL CHECKS',len(checks))
