from __future__ import annotations
from pathlib import Path
from itertools import combinations
import json,hashlib,os,shutil,subprocess,warnings
import numpy as np
import pandas as pd
from tumor_visibility.common import (TUMOR,ALL_TUMOR,CONDITIONS,DISPLAY,LABEL,load_json,save_json,save_csv,save_npz,signature,sha,slug,digest,bh)
from tumor_visibility import expression as tx
VERSION='ct26-characterization-1.0'
COLORS={'B cell':'#F4C17B','Dendritic cell':'#3C76AF','Endothelial cell':'#D0352B','Fibroblast cell 1':'#A65E34','Fibroblast cell 2':'#CA6627','Macrophage 1':'#643F95','Macrophage 2':'#7470AE','Mast cell':'#C6B3D4','Muscle cell':'#AECDE1','T cell 1':'#D43E88','T cell 2':'#ED9F9C','Tumor cell 1':'#CFD266','Tumor cell 2':'#BBDE93','Tumor cell 3':'#7EDD45','Tumor cell 4':'#549E3F','Tumor cell 5':'#4B9C79',ALL_TUMOR:'#CFD266','Other reviewed cell':'#AAAAAA','Unassigned':'#D9D9D9'}
PAIRS=[('AntiPD1','Vehicle'),('Adagrasib','Vehicle'),('Combination','Vehicle'),('Adagrasib','AntiPD1'),('Combination','AntiPD1'),('Combination','Adagrasib')]

def open_atlas(project_root,output_root=None,check_sources=True):
    root,j,m=tx.open_project(project_root)
    if not m['unit'].is_unique or len(m)!=12 or not m.groupby('condition').size().reindex(CONDITIONS,fill_value=0).eq(3).all():
        raise ValueError('This study was confirmed as 12 independent mouse tumors, 3 per condition. Current source map differs; review rather than silently proceed.')
    inputs=[]
    for row in m.to_dict('records'):
        p=tx.sample_cache(root,row['sample']);done=p/'complete.json'
        for name in ['allgene_compartment_sums.npz','full_reference_coordinates.csv.gz']:
            if not (p/name).is_file():raise FileNotFoundError(f'Finish 09A extraction for {row["sample"]}: {p/name}')
        if not done.is_file() or load_json(done)['project_id']!=j['project_id']:raise ValueError('09A cache lacks correct completion identity')
        inputs.append({'sample':row['sample'],'sum':signature(p/'allgene_compartment_sums.npz'),'reference':signature(p/'full_reference_coordinates.csv.gz')})
    if check_sources:
        source_specs=load_json(root/'project_spec.json')['samples']
        for item in source_specs:
            for k,old in item['files'].items():
                if signature(item['row'][k])!=old:raise RuntimeError(f'Source changed since 09A: {item["row"]["sample"]} {k}')
    spec=dict(project_id=j['project_id'],version=VERSION,sources=inputs,design='12 independent mouse tumors; three per condition; no technical replicates',core_sha=sha(__file__))
    parent=Path(output_root) if output_root else root/'tumor_characterization'
    out=parent/digest(spec)[:16]
    for d in ['tables','models','figures','markers','architecture','neighborhoods','sccomp']:(out/d).mkdir(parents=True,exist_ok=True)
    save_json(spec,out/'characterization_manifest.json');save_csv(m,out/'source_manifest.csv')
    counts=[];coverage=[]
    for row in m.to_dict('records'):
        with np.load(tx.sample_cache(root,row['sample'])/'allgene_compartment_sums.npz') as z:
            pop=z['populations'].astype(str);nc=z['n_cells'];nreview=int(nc.sum());ntum=int(nc[np.isin(pop,TUMOR)].sum())
            for name,n in zip(pop,nc):counts.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=name,n_cells=int(n),n_reviewed=nreview,n_all_tumor=ntum))
        nfull=int(load_json(tx.sample_cache(root,row['sample'])/'complete.json')['summary']['n_full_cells'])
        coverage.append(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],n_full=nfull,n_reviewed=nreview,n_all_tumor=ntum,reviewed_fraction=nreview/nfull))
    categories=list(dict.fromkeys(list(COLORS)[:-3]+[r['population'] for r in counts]))
    long=pd.DataFrame(counts);grid=pd.MultiIndex.from_product([m['sample'],[c for c in categories if c in set(long.population)]],names=['sample','population'])
    long=long.set_index(['sample','population']).reindex(grid).reset_index()
    for col in ['unit','condition']:long[col]=long['sample'].map(m.set_index('sample')[col])
    for col in ['n_reviewed','n_all_tumor']:long[col]=long['sample'].map(pd.DataFrame(coverage).set_index('sample')[col])
    long['n_cells']=long.n_cells.fillna(0).astype(int)
    long['fraction_reviewed']=long.n_cells/long.n_reviewed
    long['fraction_within_tumor']=np.where(long.population.isin(TUMOR),long.n_cells/long.n_all_tumor,np.nan)
    save_csv(long,out/'tables'/'celltype_counts.csv');save_csv(pd.DataFrame(coverage),out/'tables'/'annotation_coverage.csv')
    return dict(root=root,project=j,sources=m,out=out,counts=long,coverage=pd.DataFrame(coverage),colors=COLORS)

def read_reference(root,sample):
    p=tx.sample_cache(root,sample)/'full_reference_coordinates.csv.gz'
    x=pd.read_csv(p,dtype={'source_cell_id':str,'population':'string'},keep_default_na=False)
    x['population']=x.population.mask(x.population.str.strip().eq(''))
    if x.source_cell_id.duplicated().any() or x.source_cell_id.eq('').any():raise ValueError('Invalid source IDs')
    if not np.isfinite(x[['x_um','y_um']].to_numpy(float)).all():raise ValueError('Nonfinite physical coordinates')
    return x

def r_connection(connection_json=None,rscript='Rscript'):
    env=os.environ.copy()
    if connection_json:
        c=load_json(connection_json);rscript=c['rscript'];env.update(c['environment'])
    exe=shutil.which(str(rscript)) or (str(rscript) if Path(rscript).is_file() else None)
    if not exe:raise FileNotFoundError('Use the verified R4.5.2 r_connection.json or set the exact Rscript path')
    return exe,env

def run_r(script,job,out,connection_json=None,rscript='Rscript',extra_env=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);script=Path(script)
    exe,env=r_connection(connection_json,rscript)
    if extra_env:env.update({str(k):str(v) for k,v in extra_env.items()})
    save_json(job,out/'job.json');command=[exe,'--vanilla',str(script),str(out/'job.json')]
    with (out/'R_run.log').open('w') as handle:
        proc=subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        try:
            for line in proc.stdout:print(line,end='',flush=True);handle.write(line);handle.flush()
            code=proc.wait()
        except BaseException:proc.terminate();proc.wait();raise
    if code:raise RuntimeError(f'R failed (code {code}); see {out}/R_run.log. Completed other stages remain intact.')
    return out

def outcome_tests(frame,keys,value,out,permutations=9999,seed=17):
    """Exploratory treatment comparison of one scalar per mouse, not cells/tiles."""
    rows=[];rng=np.random.default_rng(seed)
    for endpoint,g in frame.groupby(keys,dropna=False,sort=False):
        endpoint=endpoint if isinstance(endpoint,tuple) else (endpoint,)
        record=dict(zip(keys,endpoint));g=g[np.isfinite(pd.to_numeric(g[value],errors='coerce'))]
        if g['unit'].duplicated().any():raise ValueError('Repeated unit in one endpoint; never treat tiles as independent mice')
        vals={c:g.loc[g.condition==c,value].to_numpy(float) for c in CONDITIONS}
        for a,b in PAIRS:
            x,y=vals[a],vals[b];row=dict(**record,contrast=a+' minus '+b,n_a=len(x),n_b=len(y),effect_difference=float(x.mean()-y.mean()) if len(x) and len(y) else np.nan)
            if len(x)<3 or len(y)<3:row.update(pvalue=np.nan,status='insufficient_units');rows.append(row);continue
            v=np.r_[x,y];n=len(x);N=len(v);observed=abs(x.mean()-y.mean());dist=[]
            for ix in combinations(range(N),n):
                s=v[list(ix)].sum();dist.append(abs(s/n-(v.sum()-s)/(N-n)))
            row.update(pvalue=float(np.mean(np.asarray(dist)>=observed-1e-12)),status='exact_unit_label_test');rows.append(row)
    result=pd.DataFrame(rows)
    if len(result):result['q_BH_selected_endpoints']=bh(result.pvalue)
    save_csv(result,out);return result

def savefig(fig,path,dpi=300):
    import matplotlib.pyplot as plt
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(path,dpi=dpi,bbox_inches='tight',pad_inches=.15);plt.close(fig)

def scalar_plot(frame,value,path,title,dpi=300):
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(7.5,5.2))
    for i,c in enumerate(CONDITIONS):
        g=frame.loc[frame.condition==c];v=pd.to_numeric(g[value],errors='coerce');keep=np.isfinite(v);v=v[keep]
        if len(v):
            ax.bar(i,v.mean(),width=.65,alpha=.35,yerr=v.std(ddof=1) if len(v)>1 else 0,capsize=3)
            xs=i+np.linspace(-.1,.1,len(v));ax.scatter(xs,v,c='black',s=25,zorder=3)
            for x,y,name in zip(xs,v,g.loc[keep,'sample']):ax.annotate(name,(x,y),xytext=(3,3),textcoords='offset points',fontsize=7)
    ax.set_xticks(range(4));ax.set_xticklabels([DISPLAY[c] for c in CONDITIONS],rotation=25,ha='right');ax.set(title=title,ylabel=value)
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False);savefig(fig,path,dpi)

def gallery(root):
    """Local review index of completed PNGs only; no external assets or source edits."""
    import html
    root=Path(root)
    body=['<!doctype html><html><head><meta charset="utf-8"><title>CT26 tumor characterization</title>',
          '<style>body{font-family:Arial;margin:30px;color:#222}figure{margin:30px 0;max-width:1250px}img{max-width:100%;height:auto}code{word-break:break-all}</style></head><body>',
          '<h1>CT26 tumor characterization</h1><p>Expression patterns, composition, markers, spatial architecture and neighborhoods. '
          'Mouse tumors are the biological replicates. Expression standardization is not LRT effect size; '
          'spatial raster statistics depend on the documented support window, grid and thresholds.</p>']
    for p in sorted(root.rglob('*.png')):
        rel=p.relative_to(root).as_posix();escaped=html.escape(rel,quote=True)
        body.append(f'<figure><figcaption>{escaped}</figcaption><a href="{escaped}"><img loading="lazy" src="{escaped}"></a></figure>')
    body.append('</body></html>');(root/'index.html').write_text('\n'.join(body));return root/'index.html'
