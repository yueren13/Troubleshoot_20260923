"""Descriptive tumor subtype specificity: replicate-aware pseudobulk screen + observed dotplots.
No cell-level P values; no claim of unique identity beyond these five data-derived groups.
"""
from pathlib import Path
import gc,re
import numpy as np
import pandas as pd
import scipy.sparse as sp
from .core import *
from tumor_visibility.common import RawReader,annotation,source_symbols,validate_counts
from tumor_visibility.expression import _projection,sample_cache

def rank_candidates(atlas,settings):
    s=dict(min_cells_per_subtype=30,min_informative_mice=6,min_pairwise_log2fc=.5,min_consistent_fraction=.70,
           min_cpm=2.,pseudocount_cpm=.5,candidates_per_subtype=150,exclude_technical_genes=True)
    s.update(settings or {})
    genes=atlas['project']['genes'];C=[];N=[];P=[]
    for r in atlas['sources'].to_dict('records'):
        with np.load(sample_cache(atlas['root'],r['sample'])/'allgene_compartment_sums.npz') as z:
            if z['genes'].tolist()!=genes:raise ValueError('All-gene axis mismatch')
            ix=[z['populations'].tolist().index(t) for t in TUMOR]
            C.append(z['counts'][ix]);N.append(z['n_cells'][ix]);P.append(z['present'])
    C=np.asarray(C);N=np.asarray(N);P=np.asarray(P)
    totals=C.sum(axis=2);cpm=np.divide(C*1e6,totals[:,:,None],out=np.full(C.shape,np.nan),where=totals[:,:,None]>0)
    log=np.log2(cpm+s['pseudocount_cpm']);rows=[];contrasts=[]
    technical=np.array([bool(re.match(r'^(mt[-_]|Rpl\d|Rps\d|Hba-|Hbb-)',g,re.I)) for g in genes])
    for i,target in enumerate(TUMOR):
        effects=[];support=[];pairn=[]
        for j,other in enumerate(TUMOR):
            if j==i:continue
            valid=(N[:,i]>=s['min_cells_per_subtype'])&(N[:,j]>=s['min_cells_per_subtype'])
            measured=P[valid].all(axis=0) if valid.any() else np.zeros(len(genes),bool)
            delta=log[valid,i]-log[valid,j]
            med=np.nanmedian(delta,axis=0) if valid.any() else np.full(len(genes),np.nan)
            consistency=(delta>0).mean(axis=0) if valid.any() else np.full(len(genes),np.nan)
            med=np.where(measured,med,np.nan);consistency=np.where(measured,consistency,np.nan)
            effects.append(med);support.append(consistency);pairn.append(int(valid.sum()))
        valid=(N[:,i]>=s['min_cells_per_subtype']);mean=np.nanmean(cpm[valid,i],axis=0) if valid.any() else np.full(len(genes),np.nan)
        eff=np.min(np.asarray(effects),axis=0);cons=np.min(np.asarray(support),axis=0)
        eligible=(min(pairn)>=s['min_informative_mice'])&np.isfinite(eff)&(eff>=s['min_pairwise_log2fc'])&(cons>=s['min_consistent_fraction'])&(mean>=s['min_cpm'])
        if s['exclude_technical_genes']:eligible &= ~technical
        tab=pd.DataFrame(dict(population=target,gene=genes,min_pairwise_median_log2CPM_difference=eff,
            minimum_pairwise_consistent_fraction=cons,minimum_informative_mice=min(pairn),mean_target_CPM=mean,
            technical_flag=technical,eligible=eligible))
        tab=tab.sort_values(['eligible','min_pairwise_median_log2CPM_difference','mean_target_CPM','gene'],ascending=[False,False,False,True],kind='stable')
        rows.append(tab)
    result=pd.concat(rows,ignore_index=True)
    candidates=result.loc[result.eligible].groupby('population',sort=False).head(s['candidates_per_subtype'])
    ids=list(dict.fromkeys(candidates.gene))
    # Exact within-mouse contrasts for candidate panel, all competitors and treatments.
    lut={g:i for i,g in enumerate(genes)}
    for i,target in enumerate(TUMOR):
        keep=candidates.loc[candidates.population==target,'gene']
        for j,other in enumerate(TUMOR):
            if i==j:continue
            for k,r in enumerate(atlas['sources'].to_dict('records')):
                if min(N[k,i],N[k,j])<s['min_cells_per_subtype']:continue
                for g in keep:
                    z=lut[g]
                    if P[k,z]:contrasts.append(dict(sample=r['sample'],unit=r['unit'],condition=r['condition'],target=target,reference=other,gene=g,log2CPM_difference=float(log[k,i,z]-log[k,j,z])))
    out=atlas['out']/'markers'/digest(dict(settings=s,root=str(atlas['root']),helper=sha(__file__)))[:12];out.mkdir(parents=True,exist_ok=True)
    save_csv(result,out/'all_gene_specificity_ranking.csv.gz');save_csv(candidates,out/'candidate_markers.csv')
    save_csv(pd.DataFrame(contrasts),out/'candidate_within_mouse_contrasts.csv.gz');save_json(dict(settings=s,candidate_genes=ids),out/'candidate_spec.json')
    return out,candidates

def measure_candidate_panel(atlas,out,chunk=10000,target_sum=10000.):
    out=Path(out);genes=load_json(out/'candidate_spec.json')['candidate_genes'];allrows=[]
    if not genes:raise ValueError('No genes meet specificity screen. Inspect ranking; relax explicitly rather than forcing top genes.')
    for r in atlas['sources'].to_dict('records'):
        dest=out/'sample_cache'/slug(r['sample']);dest.mkdir(parents=True,exist_ok=True)
        signature_spec=dict(genes=genes,raw=signature(r['raw_h5ad']),annotation=signature(r['annotation_file']),target_sum=target_sum,helper=sha(__file__))
        key=digest(signature_spec);done=dest/'complete.json';file=dest/'candidate_observed_expression.csv.gz'
        if done.exists() and load_json(done)['key']==key and file.is_file():allrows.append(pd.read_csv(file));continue
        with RawReader(r['raw_h5ad'],r['matrix_key']) as raw:
            a=annotation(r,raw);a=a.loc[a.population.isin(TUMOR)].copy();sym=source_symbols(r,raw);symset=set(sym);proj=_projection(sym,genes)
            code=pd.Categorical(a.population,categories=TUMOR).codes;n=np.bincount(code,minlength=5)
            det=np.zeros((5,len(genes)),np.int64);logs=np.zeros((5,len(genes)),float);seen=np.zeros(len(a),bool)
            for pos,x in raw.selected(a.index,chunk):
                x=validate_counts(x);total=np.asarray(x.sum(axis=1)).ravel()
                if not np.allclose(total,a.raw_total_counts.iloc[pos],atol=1e-4,rtol=0) or (total<=0).any():raise ValueError('Raw/QC total mismatch for marker extraction')
                selected=(x@proj).tocsr();group=sp.csr_matrix((np.ones(len(pos)),(code[pos],np.arange(len(pos)))),shape=(5,len(pos)))
                detected=selected.copy();detected.data=np.ones_like(detected.data);det+=np.asarray((group@detected).toarray(),np.int64)
                values=selected.astype(float);values=sp.diags(target_sum/total)@values;values.data=np.log1p(values.data)
                logs+=(group@values).toarray()
                if seen[pos].any():raise ValueError('Duplicate tumor cell read')
                seen[pos]=True
            if not seen.all():raise ValueError('Missing selected tumor cells')
            rows=[]
            for i,t in enumerate(TUMOR):
                for j,g in enumerate(genes):rows.append(dict(sample=r['sample'],unit=r['unit'],condition=r['condition'],population=t,gene=g,n_cells=int(n[i]),source_present=g in symset,fraction_detected=det[i,j]/n[i] if n[i] and g in symset else np.nan,mean_log1p=logs[i,j]/n[i] if n[i] and g in symset else np.nan))
            tab=pd.DataFrame(rows);save_csv(tab,file);save_json(dict(key=key),done);allrows.append(tab)
        gc.collect()
    full=pd.concat(allrows,ignore_index=True);save_csv(full,out/'candidate_observed_expression_all_samples.csv.gz');return full

def plot_markers(out,top_n=10,min_detection=.10,min_cells=30,dpi=300):
    import matplotlib.pyplot as plt
    out=Path(out);cand=pd.read_csv(out/'candidate_markers.csv');obs=pd.read_csv(out/'candidate_observed_expression_all_samples.csv.gz')
    eligible=obs.loc[obs.n_cells>=min_cells];means=eligible.groupby(['population','gene'])[['mean_log1p','fraction_detected']].mean()
    lists={};selected=[]
    for t in TUMOR:
        tab=cand.loc[cand.population==t].copy();tab['target_mean_detection']=[means.loc[(t,g),'fraction_detected'] if (t,g) in means.index else np.nan for g in tab.gene]
        tab=tab.loc[tab.target_mean_detection>=min_detection].head(top_n);lists[t]=list(tab.gene);selected.extend(tab.to_dict('records'))
    genes=list(dict.fromkeys(g for t in TUMOR for g in lists[t]));save_csv(pd.DataFrame(selected),out/f'top_{top_n}_specific_markers.csv')
    save_json(dict(marker_lists=lists,top_n=top_n,min_detection=min_detection,meaning='Descriptive specificity among these five inferred clusters, not external validation or intrinsic origin',equal_mouse_weight=True),out/f'top_{top_n}_marker_selection.json')
    if not genes:raise ValueError('No markers pass detection threshold. No filler genes plotted.')
    def dot(grouptable,row_keys,names,path):
        M=np.full((len(row_keys),len(genes)),np.nan);D=M.copy()
        for i,key in enumerate(row_keys):
            for j,g in enumerate(genes):
                if (*key,g) in grouptable.index:M[i,j]=grouptable.loc[(*key,g),'mean_log1p'];D[i,j]=grouptable.loc[(*key,g),'fraction_detected']
        mx=np.nanmax(M,axis=0);colors=np.divide(M,mx[None,:],out=np.zeros_like(M),where=mx[None,:]>0)
        fig,ax=plt.subplots(figsize=(max(10,.24*len(genes)+3),max(4,.28*len(names)+2.8)))
        for i in range(len(names)):
            ok=np.isfinite(D[i])&np.isfinite(M[i]);ax.scatter(np.flatnonzero(ok),np.full(ok.sum(),i),s=180*D[i,ok],c=colors[i,ok],cmap='viridis',vmin=0,vmax=1,linewidths=.1,edgecolors='black')
        ax.set_xticks(range(len(genes)));ax.set_xticklabels(genes,rotation=90,fontsize=8);ax.set_yticks(range(len(names)));ax.set_yticklabels(names,fontsize=9);ax.invert_yaxis()
        from matplotlib.cm import ScalarMappable
        fig.colorbar(ScalarMappable(cmap='viridis',norm=plt.Normalize(0,1)),ax=ax,label='Mean log1p expression / gene maximum',fraction=.025)
        for f in [.1,.5,1.]:ax.scatter([],[],s=180*f,c='0.6',label=f'{f:.0%} detected')
        ax.legend(bbox_to_anchor=(1.12,1),loc='upper left',frameon=False,fontsize=8)
        ax.set_title(f'Top up-to-{top_n} tumor subtype markers | equal mouse weighting')
        savefig(fig,path,dpi)
    dot(means,[(t,) for t in TUMOR],TUMOR,out/f'top_{top_n}_markers_dotplot_pooled.png')
    separate=eligible.groupby(['condition','population','gene'])[['mean_log1p','fraction_detected']].mean()
    keys=[(c,t) for c in CONDITIONS for t in TUMOR];dot(separate,keys,[DISPLAY[c]+' | '+t for c,t in keys],out/f'top_{top_n}_markers_dotplot_by_treatment.png')
    save_csv(means.reset_index(),out/'equal_mouse_marker_means.csv');return pd.DataFrame(selected)
