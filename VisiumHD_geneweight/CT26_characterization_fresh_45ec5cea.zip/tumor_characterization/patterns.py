"""Compact LRT-significant treatment patterns. Reuses saved DESeq2 output, no refit here."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.cluster.vq import kmeans2
from .core import *

def find_model_root(atlas,override=None):
    if override:p=Path(override)
    else:
        f=atlas['root']/'latest_tumor_model_pointer.json'
        if not f.is_file():raise FileNotFoundError('Complete 09B, run the optional model cell, or provide MODEL_ROOT explicitly.')
        p=Path(load_json(f)['model_root'])
    if not (p/'fit_status.csv').is_file():raise FileNotFoundError(p/'fit_status.csv')
    inp=p.parent.parent/'input_spec.json'
    if inp.is_file() and load_json(inp)['project_id']!=atlas['project']['project_id']:raise ValueError('Model belongs to a different 09A project/annotation')
    return p

def pattern_matrix(vst,meta,n_patterns=6,seed=17):
    if meta.library_id.duplicated().any() or set(meta.condition)!=set(CONDITIONS):raise ValueError('Expected unique libraries in four conditions')
    means=pd.DataFrame({c:vst.loc[:,meta.loc[meta.condition==c,'library_id']].mean(axis=1) for c in CONDITIONS})
    sd=means.std(axis=1,ddof=0);keep=(sd>1e-10)&np.isfinite(means).all(axis=1)
    means=means.loc[keep];vst=vst.loc[keep];center=means.mean(axis=1);sd=sd[keep]
    Z=means.sub(center,axis=0).div(sd,axis=0)
    units=vst.sub(center,axis=0).div(sd,axis=0)
    if not len(Z):return Z,units,pd.Series([],dtype=int),means
    k=min(int(n_patterns),len(Z),len(np.unique(np.round(Z.values,8),axis=0)))
    if k<1:raise ValueError('Positive pattern count required')
    if k==1:labels=np.zeros(len(Z),int)
    else:
        best=None
        for offset in range(8):
            cent,labs=kmeans2(Z.values,k,iter=60,minit='++',seed=seed+offset,missing='warn')
            score=float(((Z.values-cent[labs])**2).sum())
            if np.isfinite(score) and (best is None or score<best[0]):best=(score,labs)
        if best is None:raise RuntimeError('Pattern clustering failed')
        labels=best[1]
    # Order patterns reproducibly by peak condition and then baseline-to-combination trend.
    used=sorted(set(labels));summ={i:Z.iloc[labels==i].mean().to_numpy() for i in used}
    order=sorted(used,key=lambda i:(int(np.argmax(summ[i])),float(summ[i][-1]-summ[i][0])))
    labels=pd.Series([order.index(i)+1 for i in labels],index=Z.index,name='pattern')
    return Z,units,labels,means

def leave_one_out(vst,meta,full_Z):
    """Influence diagnostic only; DESeq2 is NOT refitted by this procedure."""
    records=[]
    for r in meta.itertuples():
        remaining=meta.loc[meta.library_id!=r.library_id]
        m=pd.DataFrame({c:vst.loc[:,remaining.loc[remaining.condition==c,'library_id']].mean(axis=1) for c in CONDITIONS})
        sd=m.std(axis=1,ddof=0);z=m.sub(m.mean(axis=1),axis=0).div(sd.where(sd>1e-10),axis=0)
        original=full_Z.loc[z.index];den=np.linalg.norm(original,axis=1)*np.linalg.norm(z,axis=1)
        cosine=np.divide((original*z).sum(axis=1),den,out=np.full(len(z),np.nan),where=den>0)
        records.append(pd.DataFrame({'gene':z.index,'removed_library':r.library_id,'removed_unit':r.independent_unit,'removed_condition':r.condition,
            'profile_cosine':cosine,'max_abs_z_change':np.max(np.abs(original.values-z.values),axis=1)}))
    return pd.concat(records,ignore_index=True)

def run(atlas,model_root,settings=None):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    from matplotlib.colors import ListedColormap
    s=dict(alpha=.05,n_patterns=6,zlim=2.,dpi=300,show_gene_names=False,test_id='LRT_any_condition',seed=17,max_genes=None)
    s.update(settings or {})
    if s['test_id'] not in ['LRT_any_condition','LRT_PD1_by_Adagrasib']:raise ValueError('Use a saved LRT test ID')
    model=Path(model_root);statuses=pd.read_csv(model/'fit_status.csv',keep_default_na=False)
    source_files=[]
    for r in statuses.loc[statuses.status=='complete'].to_dict('records'):
        old=Path(r['directory']);base=model/old.name if (model/old.name/'result_index.csv').is_file() else old
        ix=pd.read_csv(base/'result_index.csv');selected=ix.loc[ix.test_id==s['test_id']]
        if len(selected)==1:
            source_files.extend(signature(base/f) for f in ['result_index.csv','vst_expression.tsv.gz','fitted_library_metadata.csv',selected.iloc[0].file])
    spec=dict(model=signature(model/'fit_status.csv'),source_files=source_files,settings=s,helper_sha=sha(__file__))
    out=atlas['out']/'figures'/'LRT_patterns'/digest(spec)[:12];out.mkdir(parents=True,exist_ok=True)
    records=[]
    for pop in [ALL_TUMOR]+TUMOR:
        match=statuses.loc[statuses.population==pop]
        if len(match)!=1 or match.iloc[0].status!='complete':
            records.append(dict(population=pop,status='not_testable_or_not_fitted'));continue
        old=Path(match.iloc[0].directory);base=model/old.name if (model/old.name/'result_index.csv').is_file() else old
        idx=pd.read_csv(base/'result_index.csv');q=idx.loc[idx.test_id==s['test_id']]
        if len(q)!=1:raise ValueError('LRT table not uniquely available')
        f=pd.read_csv(base/q.iloc[0].file,sep='\t').set_index('gene',drop=False)
        vst=pd.read_csv(base/'vst_expression.tsv.gz',sep='\t',index_col=0)
        meta=pd.read_csv(base/'fitted_library_metadata.csv',keep_default_na=False)
        meta['condition']=pd.Categorical(meta.condition,categories=CONDITIONS,ordered=True)
        meta=meta.sort_values(['condition','independent_unit']).reset_index(drop=True)
        if not meta.independent_unit.is_unique:raise ValueError('Mouse-level fitted libraries expected, no cell pseudo-replicates')
        sig=f.loc[np.isfinite(f.padj)&(f.padj<s['alpha'])].sort_values('padj',kind='stable')
        path=out/slug(pop);path.mkdir(exist_ok=True)
        save_csv(sig.reset_index(drop=True),path/'all_LRT_significant_genes.csv')
        if s['max_genes'] is not None:sig=sig.head(int(s['max_genes']))
        missing=set(sig.index)-set(vst.index)
        if missing:raise ValueError('Significant genes lack saved VST rows')
        if not len(sig):
            records.append(dict(population=pop,status='no_significant_genes'));save_json(dict(status='no_significant_genes'),path/'status.json');continue
        vals=vst.loc[sig.index,meta.library_id]
        if not np.isfinite(vals).all().all():raise ValueError('Nonfinite VST values')
        Z,U,labels,means=pattern_matrix(vals,meta,s['n_patterns'],s['seed'])
        if not len(Z):records.append(dict(population=pop,status='no_variable_profiles'));continue
        dropped=sorted(set(vals.index)-set(Z.index));save_json(dict(constant_or_invalid_profiles=dropped),path/'excluded_profile_rows.json')
        order=[]
        for k in sorted(labels.unique()):
            ids=labels.index[labels==k];center=Z.loc[ids].mean().values
            order+=list(ids[np.argsort(np.sum((Z.loc[ids].values-center)**2,axis=1),kind='stable')])
        Z=Z.loc[order];U=U.loc[order];labels=labels.loc[order];means=means.loc[order]
        members=sig.loc[order].copy();members['pattern']=labels;members['pattern_name']=['Pattern '+str(i) for i in labels]
        save_csv(members.reset_index(drop=True),path/'all_gene_pattern_membership.csv');save_csv(Z,path/'condition_mean_zscores.csv',True)
        save_csv(U,path/'individual_unit_zscores.csv',True);save_csv(means,path/'condition_mean_VST.csv',True)
        loo=leave_one_out(vals.loc[order],meta,Z);save_csv(loo,path/'leave_one_mouse_out_profile_influence.csv.gz')
        cmap=plt.get_cmap('tab10');pc={k:cmap((k-1)%10) for k in sorted(labels.unique())}
        # Compact, one image no row names. Pattern blocks sized by number of genes.
        for typ,matrix in [('conditions',Z),('individual_mice',U)]:
            fig=plt.figure(figsize=(7.5 if typ=='conditions' else 12,8.5))
            strip=fig.add_axes([.07,.18,.035,.67]);ax=fig.add_axes([.115,.18,.57 if typ=='conditions' else .64,.67])
            strip.imshow(labels.to_numpy()[:,None]-1,aspect='auto',interpolation='nearest',cmap=ListedColormap([pc[k] for k in pc]),vmin=0,vmax=max(pc)-1)
            strip.set_xticks([]);strip.set_yticks([])
            im=ax.imshow(matrix.values,aspect='auto',interpolation='nearest',cmap='RdBu_r',vmin=-s['zlim'],vmax=s['zlim']);ax.set_yticks([])
            col=[DISPLAY[c] for c in CONDITIONS] if typ=='conditions' else [DISPLAY[str(r.condition)]+'\n'+str(r.independent_unit) for r in meta.itertuples()]
            ax.set_xticks(range(len(col)));ax.set_xticklabels(col,rotation=35 if typ=='conditions' else 75,ha='right',fontsize=9 if typ=='conditions' else 8)
            bounds=np.flatnonzero(np.diff(labels.to_numpy()))+.5
            for b in bounds:ax.axhline(b,color='white',lw=.7);strip.axhline(b,color='white',lw=.7)
            legend=[Patch(color=pc[k],label=f'Pattern {k} (n={(labels==k).sum():,})') for k in pc]
            fig.legend(handles=legend,loc='upper left',bbox_to_anchor=(.79,.83),frameon=False,fontsize=9)
            cax=fig.add_axes([.80,.27,.025,.22]);fig.colorbar(im,cax=cax,label='Within-gene expression z-score')
            fig.suptitle(f'{pop} | {s["test_id"]}\n{len(Z):,} significant genes; response patterns',fontsize=12)
            fig.text(.07,.025,'Expression z-score, not an LRT effect size or significance statistic.\nTreatment order is categorical, not time/dose. Patterns are exploratory.',fontsize=8)
            savefig(fig,path/f'compact_{typ}_pattern_heatmap.png',s['dpi'])
        for k in sorted(labels.unique()):
            ids=labels.index[labels==k];zs=Z.loc[ids]
            save_csv(members.loc[ids].reset_index(drop=True),path/f'pattern_{k:02d}_genes.csv')
            fig,ax=plt.subplots(figsize=(6.8,4.6));v=zs.to_numpy()
            ax.fill_between(range(4),np.quantile(v,.25,axis=0),np.quantile(v,.75,axis=0),color=pc[k],alpha=.2)
            ax.plot(range(4),np.median(v,axis=0),color=pc[k],marker='o',lw=2)
            ax.set_xticks(range(4));ax.set_xticklabels([DISPLAY[c] for c in CONDITIONS],rotation=25,ha='right')
            ax.set(title=f'{pop} | Pattern {k}: {len(ids)} genes',ylabel='Standardized condition-mean expression')
            fig.text(.02,.015,'Median and IQR across genes; not a mouse-level confidence interval.',fontsize=8);savefig(fig,path/f'pattern_{k:02d}_curve.png',s['dpi'])
            fig,ax=plt.subplots(figsize=(6.8,4.6));ax.boxplot([v[:,i] for i in range(4)],showfliers=False)
            ax.set_xticks(range(1,5));ax.set_xticklabels([DISPLAY[c] for c in CONDITIONS],rotation=25,ha='right')
            ax.set(title=f'{pop} | Pattern {k}: gene-distribution boxes',ylabel='Standardized condition-mean expression')
            fig.text(.02,.015,'Each value is a gene, not an independent animal. Descriptive only.',fontsize=8);savefig(fig,path/f'pattern_{k:02d}_gene_boxes.png',s['dpi'])
            # Mouse robustness: each dot is average standardized expression over pattern genes in ONE mouse.
            scores=U.loc[ids].mean(axis=0);table=meta.copy();table['pattern']=k;table['pattern_score']=table.library_id.map(scores)
            table['sample']=table['independent_unit'];save_csv(table,path/f'pattern_{k:02d}_mouse_scores.csv')
            scalar_plot(table,'pattern_score',path/f'pattern_{k:02d}_mouse_boxpoints.png',f'{pop} | Pattern {k} | independent mice',s['dpi'])
        save_json(dict(settings=s,source_result=signature(base/q.iloc[0].file),n_significant_total=int((f.padj<s['alpha']).sum()),n_displayed=len(Z),n_patterns=int(labels.nunique()),z_definition='Within gene: standardize the 4 equal-unit condition-mean VST values. Individual units use same gene center/scale; not a test statistic.'),path/'pattern_manifest.json')
        records.append(dict(population=pop,status='complete',n_genes=len(Z),n_patterns=labels.nunique(),directory=str(path)))
    result=pd.DataFrame(records);save_csv(result,out/'pattern_summary.csv');return out,result
