"""Read-only extension of the supplied CT26 tumor_visibility project."""
