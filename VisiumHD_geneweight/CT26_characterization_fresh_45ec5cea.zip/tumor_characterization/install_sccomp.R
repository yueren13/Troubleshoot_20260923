#!/usr/bin/env Rscript
# Explicit optional installer. Input job uses existing R4.5.2 connection environment.
a<-commandArgs(trailingOnly=TRUE)
if(length(a)!=1)stop('Pass job.json')
if(!requireNamespace('jsonlite',quietly=TRUE))stop('Existing verified R library must provide jsonlite')
j<-jsonlite::fromJSON(a[1]);root<-j$environment_root
if(getRversion()<'4.5.0'||getRversion()>='4.6.0')stop('Use R4.5.x for this Bioconductor3.22 setup')
lib<-file.path(root,'library');dir.create(lib,recursive=TRUE,showWarnings=FALSE)
.libPaths(c(lib,.libPaths()));options(timeout=1800,Ncpus=as.integer(j$cores),repos=c(CRAN='https://cloud.r-project.org'))
if(!requireNamespace('BiocManager',quietly=TRUE))install.packages('BiocManager',lib=lib)
# Install only the release compatible with the existing R. Do not upgrade old DESeq2 libraries.
BiocManager::install('sccomp',version='3.22',lib=lib,ask=FALSE,update=FALSE,dependencies=c('Depends','Imports','LinkingTo'))
if(!requireNamespace('cmdstanr',quietly=TRUE))install.packages('cmdstanr',lib=lib,repos=c('https://stan-dev.r-universe.dev',getOption('repos')),dependencies=c('Depends','Imports','LinkingTo'))
if(!requireNamespace('sccomp',quietly=TRUE)||!requireNamespace('cmdstanr',quietly=TRUE))stop('Installation incomplete')
cmdstanr::check_cmdstan_toolchain(fix=FALSE)
if(nzchar(j$existing_cmdstan_path)){
 cmdstanr::set_cmdstan_path(j$existing_cmdstan_path)
}else{
 dir.create(file.path(root,'cmdstan'),recursive=TRUE,showWarnings=FALSE)
 version<-j$cmdstan_version
 target<-file.path(root,'cmdstan',paste0('cmdstan-',version))
 if(!file.exists(file.path(target,'bin','stanc')))cmdstanr::install_cmdstan(dir=file.path(root,'cmdstan'),version=version,cores=as.integer(j$cores),quiet=FALSE,overwrite=FALSE)
 cmdstanr::set_cmdstan_path(target)
}
path<-cmdstanr::cmdstan_path();writeLines(capture.output(sessionInfo()),file.path(root,'installation_sessionInfo.txt'))
write.csv(installed.packages(lib.loc=.libPaths())[,c('Package','Version','LibPath'),drop=FALSE],file.path(root,'installed_packages.csv'),row.names=FALSE)
jsonlite::write_json(list(R_version=R.version.string,rscript=file.path(R.home('bin'),'Rscript'),
 sccomp=as.character(packageVersion('sccomp')),cmdstanr=as.character(packageVersion('cmdstanr')),
 cmdstan=as.character(cmdstanr::cmdstan_version()),cmdstan_path=path,
 environment=list(R_LIBS=paste(.libPaths(),collapse=.Platform$path.sep),R_LIBS_USER=paste(.libPaths(),collapse=.Platform$path.sep),CMDSTAN=path),
 stan_cache=file.path(root,'compiled_sccomp_models')),file.path(root,'sccomp_connection.json'),auto_unbox=TRUE,pretty=TRUE)
cat('Package/backend installed. Run the synthetic sccomp smoke-test cell next.\n')
