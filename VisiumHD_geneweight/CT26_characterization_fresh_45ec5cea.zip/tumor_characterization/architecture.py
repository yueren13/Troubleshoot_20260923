"""Tumor architecture at fixed physical scales. No cell/subtype is a treatment replicate.
Default window is the all-reference occupied raster, not a histological tissue mask.
Moran/Geary use field values on supported adjacent tiles. K is rasterized translation
corrected; conditional random-label envelopes preserve counts and sampling geometry.
"""
from pathlib import Path
import gc
import numpy as np
import pandas as pd
from scipy import ndimage as ndi
from scipy.signal import fftconvolve
from .core import *

def raster_reference(frame,width,max_grid_pixels=3000000):
    xy=frame[['x_um','y_um']].to_numpy(float)
    if width<=0 or not len(xy) or not np.isfinite(xy).all():raise ValueError('Invalid physical raster inputs')
    low=np.floor(xy.min(axis=0)/width)*width
    coords=np.floor((xy-low)/width).astype(np.int64);shape=tuple((coords.max(axis=0)+1)[::-1])
    if np.prod(shape)>max_grid_pixels:raise MemoryError(f'Grid has {np.prod(shape):,} pixels; inspect coordinate units or explicitly increase grid size limit')
    flat=np.ravel_multi_index((coords[:,1],coords[:,0]),shape)
    labels=frame.population.astype('string');reviewed=labels.notna().to_numpy()
    full=np.bincount(flat,minlength=np.prod(shape)).reshape(shape)
    known=np.bincount(flat[reviewed],minlength=np.prod(shape)).reshape(shape)
    groups={ALL_TUMOR:labels.isin(TUMOR).to_numpy(),**{t:labels.eq(t).fillna(False).to_numpy() for t in TUMOR}}
    arrays={g:np.bincount(flat[mask],minlength=np.prod(shape)).reshape(shape) for g,mask in groups.items()}
    return dict(origin=low,width=width,shape=shape,full=full,reviewed=known,groups=arrays)

def get_window(grid,override=None):
    default=grid['full']>0
    if override is None:return default,'all_reference_occupied_tiles_PROXY'
    # A validated tissue footprint override has exactly the same physical grid.
    with np.load(override) as z:
        mask=z['mask'].astype(bool)
        if mask.shape!=grid['shape'] or not np.allclose(z['origin_um'],grid['origin']) or not np.isclose(float(z['pixel_size_um']),grid['width']):raise ValueError('Mask grid/origin/physical scale do not match. No resizing or guessed alignment.')
    if not mask.any():raise ValueError('Empty external observation window')
    return mask,'explicit_registered_mask'

def raster_edges(mask,queen=True):
    labels=np.full(mask.shape,-1,np.int64);labels[mask]=np.arange(mask.sum());a=[];b=[]
    offsets=[(0,1),(1,0)]+([(1,1),(1,-1)] if queen else [])
    h,w=mask.shape
    for dy,dx in offsets:
        yy=slice(max(0,-dy),min(h,h-dy));xx=slice(max(0,-dx),min(w,w-dx))
        y2=slice(max(0,dy),min(h,h+dy));x2=slice(max(0,dx),min(w,w+dx))
        p=labels[yy,xx];q=labels[y2,x2];ok=(p>=0)&(q>=0);a.extend(p[ok]);b.extend(q[ok])
    return np.asarray(a,np.int64),np.asarray(b,np.int64)

def moran_geary(values,edges):
    y=np.asarray(values,float);a,b=edges;n=len(y)
    if len(a)==0 or n<3 or not np.isfinite(y).all():return np.nan,np.nan
    z=y-y.mean();ss=float(z@z)
    if ss<=np.finfo(float).eps*n:return np.nan,np.nan
    # Edges are undirected once; equivalent to symmetric binary W with S0=2*E.
    I=n/len(a)*np.sum(z[a]*z[b])/ss
    C=(n-1)/(2*len(a))*np.sum((y[a]-y[b])**2)/ss
    return float(I),float(C)

def autocorrelation(field,mask,n_permutations,seed,queen=True):
    edges=raster_edges(mask,queen);y=field[mask];I,C=moran_geary(y,edges)
    record=dict(n_tiles=len(y),n_undirected_edges=len(edges[0]),Moran_I=I,Geary_C=C,
                weights='symmetric_binary_queen' if queen else 'symmetric_binary_rook')
    if not np.isfinite(I):return {**record,'status':'constant_field_or_insufficient_neighbors','Moran_p':np.nan,'Geary_p':np.nan},pd.DataFrame()
    rng=np.random.default_rng(seed);null=np.array([moran_geary(rng.permutation(y),edges) for _ in range(n_permutations)])
    if len(null):
        for j,(name,val,expected) in enumerate([('Moran',I,-1/(len(y)-1)),('Geary',C,1.)]):
            record[name+'_p']=(1+np.sum(np.abs(null[:,j]-expected)>=abs(val-expected)-1e-12))/(n_permutations+1)
            record[name+'_null_mean']=float(null[:,j].mean());record[name+'_null_sd']=float(null[:,j].std(ddof=1)) if len(null)>1 else np.nan
    else:record.update(Moran_p=np.nan,Geary_p=np.nan)
    return {**record,'status':'ok'},pd.DataFrame(null,columns=['Moran_I','Geary_C'])

def patch_metrics(counts,denominator,mask,width,threshold,min_group_cells,connectivity=8):
    frac=np.divide(counts,denominator,out=np.full(counts.shape,np.nan),where=denominator>0)
    selected=mask&(denominator>0)&(counts>=min_group_cells)&(frac>=threshold)
    structure=np.ones((3,3),int) if connectivity==8 else ndi.generate_binary_structure(2,1)
    components,n=ndi.label(selected,structure=structure)
    areas=np.bincount(components.ravel(),minlength=n+1)[1:]*width**2
    mass=np.bincount(components.ravel(),weights=counts.ravel(),minlength=n+1)[1:]
    total=int(counts[mask].sum());selected_mass=float(mass.sum())
    # Edge density is defined on the raster mask, not true polygon perimeter.
    horizontal=np.count_nonzero(selected[:,1:]!=selected[:,:-1]);vertical=np.count_nonzero(selected[1:,:]!=selected[:-1,:])
    records=[]
    for k,(area,cellmass) in enumerate(zip(areas,mass),1):records.append(dict(component=k,area_um2=float(area),group_cells=float(cellmass),equivalent_diameter_um=float(2*np.sqrt(area/np.pi))))
    overall=dict(n_patches=int(n),patch_area_um2=float(areas.sum()),observation_area_um2=float(mask.sum()*width**2),
        largest_patch_area_um2=float(areas.max()) if n else 0.,median_patch_area_um2=float(np.median(areas)) if n else np.nan,
        cell_weighted_patch_area_um2=float(np.average(areas,weights=mass)) if n and mass.sum()>0 else np.nan,
        largest_patch_fraction_of_group_cells=float(mass.max()/total) if n and total else 0. if total else np.nan,
        fraction_group_cells_in_patches=selected_mass/total if total else np.nan,
        patches_per_mm2_support=n/(mask.sum()*width**2)*1e6 if mask.any() else np.nan,
        raster_interface_length_per_mm2=(horizontal+vertical)*width/(mask.sum()*width**2)*1e6 if mask.any() else np.nan,
        n_group_cells_in_window=total)
    return overall,pd.DataFrame(records,columns=['component','area_um2','group_cells','equivalent_diameter_um']),components

def translation_setup(mask,width,radii,min_overlap_fraction=.05):
    mask=np.asarray(mask,bool);h,w=mask.shape;area=float(mask.sum()*width**2)
    if not mask.any() or not np.isfinite(width) or width<=0:raise ValueError('Ripley observation window must be nonempty with positive physical pixel size')
    overlaps=np.rint(fftconvolve(mask.astype(float),mask[::-1,::-1].astype(float),mode='full')).astype(np.int64)
    yy,xx=np.indices(overlaps.shape);dist=np.sqrt((yy-(h-1))**2+(xx-(w-1))**2)*width
    # Validity at each radius: overlapping shifts with very small common window are unstable.
    out=[]
    for r in radii:
        if r<2*width:raise ValueError('Rasterized Ripley radii must be >=2 pixels; use a finer grid for smaller distances')
        selected=(dist<=r)&(overlaps>0);minfrac=float(overlaps[selected].min()/mask.sum()) if selected.any() else 0.
        valid=minfrac>=min_overlap_fraction
        out.append(dict(radius_um=float(r),valid=valid,min_overlap_fraction=minfrac,selected=selected))
    return dict(overlap=overlaps,distances=dist,area=area,width=width,mask=mask,metrics=out)

def raster_K(counts,setup):
    x=np.where(setup['mask'],counts,0).astype(np.float64);n=int(x.sum());h,w=x.shape
    corr=np.rint(fftconvolve(x,x[::-1,::-1],mode='full'))
    corr[h-1,w-1]-=n # exclude each point's self-pair once; colocated distinct cells remain.
    corr=np.maximum(corr,0)
    weights=np.divide(corr,setup['overlap']*setup['width']**2,out=np.zeros_like(corr),where=setup['overlap']>0)
    result=[]
    for item in setup['metrics']:
        valid=item['valid'] and n>=2
        K=setup['area']**2/(n*(n-1))*weights[item['selected']].sum() if valid else np.nan
        result.append(dict(radius_um=item['radius_um'],n_points=n,K_um2=float(K),L_minus_r_um=float(np.sqrt(K/np.pi)-item['radius_um']) if valid else np.nan,
            valid=valid,min_window_overlap_fraction=item['min_overlap_fraction'],status='ok' if valid else 'too_few_points_or_unstable_window_overlap'))
    return pd.DataFrame(result)

def random_label_K(counts,background,setup,n_permutations,seed):
    observed=raster_K(counts,setup);mask=setup['mask'];pop=np.asarray(background[mask],np.int64);n=int(counts[mask].sum())
    if n>pop.sum() or np.any(counts[mask]>background[mask]):raise ValueError('Target count exceeds conditional-label background')
    rng=np.random.default_rng(seed);null=[]
    for rep in range(n_permutations):
        sample=rng.multivariate_hypergeometric(pop,n,method='marginals')
        x=np.zeros(mask.shape,np.int64);x[mask]=sample
        null.append(raster_K(x,setup).L_minus_r_um.to_numpy())
    null=np.asarray(null)
    if n_permutations:
        for i,row in observed.iterrows():
            v=null[:,i];v=v[np.isfinite(v)]
            if not len(v):continue
            mean=v.mean();sd=v.std(ddof=1) if len(v)>1 else np.nan
            observed.loc[i,'conditional_null_mean_L_minus_r']=mean
            observed.loc[i,'conditional_null_q025']=np.quantile(v,.025);observed.loc[i,'conditional_null_q975']=np.quantile(v,.975)
            observed.loc[i,'conditional_excess_L_um']=row.L_minus_r_um-mean
            observed.loc[i,'conditional_z']=((row.L_minus_r_um-mean)/sd) if sd>1e-12 else np.nan
            observed.loc[i,'conditional_pointwise_p']=(1+np.sum(np.abs(v-mean)>=abs(row.L_minus_r_um-mean)-1e-12))/(len(v)+1)
    return observed,null

def run(atlas,settings=None,mask_overrides=None):
    import matplotlib.pyplot as plt
    s=dict(grid_sizes_um=[25.,50.],min_full_cells=3,min_reviewed_fraction=.5,min_reviewed_cells=3,
           pooled_thresholds=[.3,.5,.7],subtype_thresholds=[.1,.25,.5],min_group_cells=2,
           autocorrelation_permutations=199,ripley_permutations=39,ripley_radii_um=[50.,100.,200.],
           ripley_grid_um=25.,min_overlap_fraction=.05,seed=17,plot_populations=[ALL_TUMOR],dpi=300,max_grid_pixels=3000000)
    s.update(settings or {});overrides=mask_overrides or {}
    if min(s['grid_sizes_um'])<=0 or min(s['ripley_radii_um'])<=0:raise ValueError('Physical raster sizes and radii must be positive')
    if s['autocorrelation_permutations']<0 or s['ripley_permutations']<0:raise ValueError('Permutation counts cannot be negative')
    spec=dict(settings=s,project_id=atlas['project']['project_id'],helper=sha(__file__),masks={k:signature(v) for k,v in overrides.items()})
    out=atlas['out']/'architecture'/digest(spec)[:12];out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'settings.json')
    global_rows=[];patchrows=[];kr=[];coverage=[]
    for row in atlas['sources'].to_dict('records'):
        folder=out/slug(row['sample']);folder.mkdir(exist_ok=True);done=folder/'complete.json'
        if done.exists():
            global_rows.append(pd.read_csv(folder/'autocorrelation.csv'));patchrows.append(pd.read_csv(folder/'patch_summary.csv'));kr.append(pd.read_csv(folder/'Ripley_raster.csv'));coverage.append(pd.read_csv(folder/'coverage.csv'));continue
        print('Architecture:',row['sample'],flush=True);ref=read_reference(atlas['root'],row['sample']);ar=[];pr=[];rr=[];cv=[]
        for width in s['grid_sizes_um']:
            grid=raster_reference(ref,float(width),s['max_grid_pixels']);window,source=get_window(grid,overrides.get(row['sample']+'__'+f'{width:g}'))
            eligible=window&(grid['full']>=s['min_full_cells'])&(grid['reviewed']>=s['min_reviewed_cells'])&((grid['reviewed']/np.maximum(grid['full'],1))>=s['min_reviewed_fraction'])
            cv.append(dict(**{k:row[k] for k in ['sample','unit','condition']},grid_um=width,window_source=source,
                support_area_um2=window.sum()*width**2,n_field_tiles=int(eligible.sum()),n_window_tiles=int(window.sum()),n_full_cells_in_window=int(grid['full'][window].sum()),n_full_cells_total=len(ref)))
            for group in [ALL_TUMOR]+TUMOR:
                counts=grid['groups'][group];field=np.divide(counts,grid['reviewed'],out=np.full(counts.shape,np.nan),where=grid['reviewed']>0)
                autoc,null=autocorrelation(field,eligible,s['autocorrelation_permutations'],s['seed'])
                ar.append(dict(**{k:row[k] for k in ['sample','unit','condition']},population=group,grid_um=width,window_source=source,field_denominator='reviewed_cells',**autoc))
                thresholds=s['pooled_thresholds'] if group==ALL_TUMOR else s['subtype_thresholds']
                for threshold in thresholds:
                    summary,components,label=patch_metrics(counts,grid['reviewed'],eligible,width,threshold,s['min_group_cells'])
                    identity=dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=group,grid_um=width,fraction_threshold=threshold)
                    pr.append(dict(**identity,**summary));save_csv(components,folder/(slug(group)+f'_grid{width:g}_thr{threshold:g}_components.csv'))
                    if group in s['plot_populations']:
                        fig,ax=plt.subplots(figsize=(8,7));shown=np.ma.masked_where(label==0,label)
                        ax.imshow(shown,origin='lower',extent=[grid['origin'][0],grid['origin'][0]+grid['shape'][1]*width,grid['origin'][1],grid['origin'][1]+grid['shape'][0]*width],interpolation='nearest',cmap='tab20')
                        ax.set_aspect('equal');ax.set(title=f'{row["sample"]} | {group}\nPatch fraction ≥{threshold}; grid {width:g} µm',xlabel='Proseg x (µm)',ylabel='Proseg y (µm)')
                        savefig(fig,folder/(slug(group)+f'_patches_grid{width:g}_thr{threshold:g}.png'),s['dpi'])
                if group in s['plot_populations']:
                    fig,ax=plt.subplots(figsize=(8,7));im=ax.imshow(np.ma.masked_where(~eligible,field),origin='lower',vmin=0,vmax=1,cmap='viridis',extent=[grid['origin'][0],grid['origin'][0]+grid['shape'][1]*width,grid['origin'][1],grid['origin'][1]+grid['shape'][0]*width]);ax.set_aspect('equal');fig.colorbar(im,ax=ax,label='Fraction among reviewed cells');ax.set(title=f'{row["sample"]} | {group} | {width:g} µm grid',xlabel='Proseg x (µm)',ylabel='Proseg y (µm)');savefig(fig,folder/(slug(group)+f'_fraction_grid{width:g}.png'),s['dpi'])
            save_npz(folder/f'grid_{width:g}um.npz',full=grid['full'],reviewed=grid['reviewed'],mask=window,field_mask=eligible,origin_um=grid['origin'],pixel_size_um=np.array(width),**{slug(k):v for k,v in grid['groups'].items()})
            if np.isclose(width,s['ripley_grid_um']):
                setup=translation_setup(window,width,s['ripley_radii_um'],s['min_overlap_fraction'])
                for group in [ALL_TUMOR]+TUMOR:
                    background=grid['reviewed'] if group==ALL_TUMOR else grid['groups'][ALL_TUMOR]
                    kt,kn=random_label_K(grid['groups'][group],background,setup,s['ripley_permutations'],s['seed'])
                    for k in ['sample','unit','condition']:kt[k]=row[k]
                    kt['population']=group;kt['grid_um']=width;kt['window_source']=source;kt['conditional_background']='all_reviewed_cells' if group==ALL_TUMOR else 'all_tumor_cells'
                    rr.append(kt);save_npz(folder/(slug(group)+'_Ripley_random_labels.npz'),null_L_minus_r=kn,radii_um=np.array(s['ripley_radii_um']))
            del grid;gc.collect()
        if not rr:raise ValueError('ripley_grid_um must be included in grid_sizes_um')
        for name,x in [('autocorrelation',pd.DataFrame(ar)),('patch_summary',pd.DataFrame(pr)),('Ripley_raster',pd.concat(rr,ignore_index=True)),('coverage',pd.DataFrame(cv))]:save_csv(x,folder/(name+'.csv'))
        save_json(dict(status='complete',sample=row['sample']),done)
        global_rows.append(pd.DataFrame(ar));patchrows.append(pd.DataFrame(pr));kr.append(pd.concat(rr));coverage.append(pd.DataFrame(cv))
    tables={'autocorrelation':pd.concat(global_rows,ignore_index=True),'patch_summary':pd.concat(patchrows,ignore_index=True),'Ripley_raster':pd.concat(kr,ignore_index=True),'coverage':pd.concat(coverage,ignore_index=True)}
    for name,x in tables.items():save_csv(x,out/(name+'_all_samples.csv'))
    return out,tables

def plot_summary(out,tables,populations=None,dpi=300):
    import matplotlib.pyplot as plt
    out=Path(out);populations=populations or [ALL_TUMOR]+TUMOR
    for (pop,w),f in tables['autocorrelation'].groupby(['population','grid_um']):
        if pop not in populations:continue
        for value in ['Moran_I','Geary_C']:scalar_plot(f,value,out/'figures'/slug(pop)/(f'grid{w:g}_{value}.png'),f'{pop}: {value} (grid {w:g} µm)',dpi)
    for (pop,w,t),f in tables['patch_summary'].groupby(['population','grid_um','fraction_threshold']):
        if pop not in populations:continue
        for value in ['largest_patch_fraction_of_group_cells','cell_weighted_patch_area_um2','patches_per_mm2_support']:
            scalar_plot(f,value,out/'figures'/slug(pop)/(f'grid{w:g}_thr{t:g}_{value}.png'),f'{pop} | threshold {t:g} | grid {w:g}',dpi)
    for pop,f in tables['Ripley_raster'].groupby('population'):
        if pop not in populations:continue
        for value in ['L_minus_r_um','conditional_excess_L_um']:
            if value not in f:continue
            fig,ax=plt.subplots(figsize=(7.5,5));colors=plt.rcParams['axes.prop_cycle'].by_key()['color']
            for i,c in enumerate(CONDITIONS):
                subset=f.loc[f.condition==c]
                for sample,g in subset.groupby('sample'):ax.plot(g.radius_um,g[value],color=colors[i],lw=.7,alpha=.3)
                mean=subset.groupby('radius_um')[value].mean();ax.plot(mean.index,mean,color=colors[i],marker='o',label=DISPLAY[c],lw=2)
            ax.axhline(0,color='gray',lw=.7);ax.set(title=pop+' | rasterized Ripley summary',xlabel='Radius (µm)',ylabel=value);ax.legend(frameon=False);savefig(fig,out/'figures'/slug(pop)/(value+'.png'),dpi)
    return out/'figures'
