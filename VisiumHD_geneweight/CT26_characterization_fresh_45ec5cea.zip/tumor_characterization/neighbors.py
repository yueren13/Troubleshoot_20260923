"""Exact per-sample count-only neighborhoods at 50/100/200 µm radii plus disjoint shells."""
from pathlib import Path
import gc
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from .core import *

def count_within(tree,points,r,chunk,workers):
    out=np.zeros(len(points),np.int64)
    if tree is not None:
        for a in range(0,len(points),chunk):out[a:a+chunk]=tree.query_ball_point(points[a:a+chunk],r,eps=0,return_length=True,workers=workers)
    return out

def sample_metrics(frame,categories,radii,workers=8,chunk=20000):
    xyz=frame[['x_um','y_um']].to_numpy(float);labels=frame.population.astype('string')
    if not np.isfinite(xyz).all() or frame.source_cell_id.duplicated().any():raise ValueError('Invalid coordinates/source IDs')
    centers=labels.isin(TUMOR).to_numpy();pos=xyz[centers];center_labels=labels[centers].astype(str).to_numpy();n=len(pos)
    cats=list(categories)+['Unassigned'];codes=pd.Categorical(labels.fillna('Unassigned'),categories=cats).codes
    if (codes<0).any():raise ValueError('Unknown reviewed labels; use full cohort vocabulary')
    global_counts=np.bincount(codes,minlength=len(cats));cat_index={c:i for i,c in enumerate(cats)}
    global_reviewed=int(global_counts[:-1].sum());global_nontumor=int(sum(global_counts[i] for i,c in enumerate(cats[:-1]) if c not in TUMOR))
    center_codes=codes[centers];groups={ALL_TUMOR:np.ones(n,bool),**{t:center_labels==t for t in TUMOR}}
    tree_cache=[cKDTree(xyz[codes==i]) if np.any(codes==i) else None for i in range(len(cats))]
    previous=np.zeros((n,len(cats)),np.int64);records=[]
    for radius in radii:
        current=np.zeros_like(previous)
        for j,tree in enumerate(tree_cache):current[:,j]=count_within(tree,pos,radius,chunk,workers)
        # Remove query object exactly once by its own subtype, not all colocated objects.
        if n:current[np.arange(n),center_codes]-=1
        if np.any(current<0) or np.any(current<previous):raise AssertionError('Radius/self-count invariants failed')
        inner=0. if radius==radii[0] else radii[list(radii).index(radius)-1]
        for mode,mat,lower in [('cumulative',current,0.),('annulus',current-previous,inner)]:
            all_counts=mat.sum(axis=1);reviewed=mat[:,:-1].sum(axis=1)
            non_ix=[i for i,c in enumerate(cats[:-1]) if c not in TUMOR]
            non_counts=mat[:,non_ix].sum(axis=1)
            for group,mask in groups.items():
                N=int(mask.sum())
                for denom_name,denom,eligible_types in [('all_reviewed',reviewed,cats[:-1]),('non_tumor_reviewed',non_counts,[cats[i] for i in non_ix])]:
                    d=denom[mask];valid=d>0
                    for c in eligible_types:
                        j=cat_index[c];v=mat[mask,j]
                        total_global=global_reviewed if denom_name=='all_reviewed' else global_nontumor
                        global_fraction=float(global_counts[j]/total_global) if total_global else np.nan
                        frac=v.sum()/d.sum() if d.sum() else np.nan
                        records.append(dict(population=group,neighbor_type=c,mode=mode,inner_radius_um=lower,outer_radius_um=radius,denominator=denom_name,n_centers=N,
                            n_centers_with_any_denominator=int(valid.sum()),total_neighbor_pairs=int(v.sum()),mean_neighbors_per_center=float(v.mean()) if N else np.nan,
                            fraction_centers_with_type=float((v>0).mean()) if N else np.nan,
                            pair_weighted_fraction=frac,equal_active_center_fraction=float((v[valid]/d[valid]).mean()) if valid.any() else np.nan,
                            global_denominator_fraction=global_fraction,composition_ratio_to_global=frac/global_fraction if global_fraction>0 else np.nan,
                            mean_all_segmented_neighbors=float(all_counts[mask].mean()) if N else np.nan,
                            reviewed_neighbor_coverage=float(reviewed[mask].sum()/all_counts[mask].sum()) if all_counts[mask].sum() else np.nan))
        previous=current
    return pd.DataFrame(records)

def run(atlas,settings=None):
    s=dict(radii_um=[50.,100.,200.],workers=8,chunk_centers=20000,dpi=300)
    s.update(settings or {});s['radii_um']=sorted(set(map(float,s['radii_um'])))
    if not s['radii_um'] or min(s['radii_um'])<=0:raise ValueError('Positive neighborhood radii required')
    categories=list(dict.fromkeys(atlas['counts'].population));spec=dict(settings=s,project_id=atlas['project']['project_id'],helper=sha(__file__),categories=categories)
    out=atlas['out']/'neighborhoods'/digest(spec)[:12];out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'settings.json');allrows=[]
    for r in atlas['sources'].to_dict('records'):
        file=out/(slug(r['sample'])+'_neighbors.csv.gz');done=out/(slug(r['sample'])+'_complete.json')
        if file.is_file() and done.is_file():x=pd.read_csv(file)
        else:
            print('50/100/200 µm tumor neighborhoods:',r['sample'],flush=True);ref=read_reference(atlas['root'],r['sample'])
            x=sample_metrics(ref,categories,s['radii_um'],s['workers'],s['chunk_centers'])
            for k in ['sample','unit','condition']:x[k]=r[k]
            save_csv(x,file);save_json(dict(settings=s,source=signature(tx.sample_cache(atlas['root'],r['sample'])/'full_reference_coordinates.csv.gz')),done)
            del ref;gc.collect()
        allrows.append(x)
    tab=pd.concat(allrows,ignore_index=True);save_csv(tab,out/'all_sample_neighborhoods.csv.gz')
    keys=['condition','population','neighbor_type','mode','inner_radius_um','outer_radius_um','denominator']
    mean=tab.groupby(keys,observed=True).agg(mean_neighbor_count=('mean_neighbors_per_center','mean'),
       mean_pair_fraction=('pair_weighted_fraction','mean'),sd_pair_fraction=('pair_weighted_fraction','std'),n_mice=('pair_weighted_fraction','count')).reset_index()
    save_csv(mean,out/'equal_mouse_treatment_summaries.csv');return out,tab,mean

def plot(out,tab,atlas,settings=None):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    s=dict(dpi=300,modes=['cumulative','annulus'],denominators=['all_reviewed','non_tumor_reviewed'],populations=[ALL_TUMOR]+TUMOR)
    s.update(settings or {});out=Path(out);root=out/'figures'/digest(s)[:12];root.mkdir(parents=True,exist_ok=True)
    cats=list(dict.fromkeys(atlas['counts'].population));colors={c:atlas['colors'].get(c,'#999999') for c in cats}
    samples=[r['sample'] for c in CONDITIONS for r in atlas['sources'].loc[atlas['sources'].condition==c].to_dict('records')]
    for (pop,mode,low,high,den),f in tab.groupby(['population','mode','inner_radius_um','outer_radius_um','denominator'],sort=False):
        if pop not in s['populations'] or mode not in s['modes'] or den not in s['denominators']:continue
        allowed=[c for c in cats if c in set(f.neighbor_type)]
        for view in ['treatment','sample']:
            by='condition' if view=='treatment' else 'sample';ordered=CONDITIONS if view=='treatment' else samples
            table=f.groupby([by,'neighbor_type']).pair_weighted_fraction.mean().unstack('neighbor_type').reindex(index=ordered,columns=allowed)
            n=len(table);left=.9;body=.48*n;right=3.8;fig=plt.figure(figsize=(left+body+right,6.6));ax=fig.add_axes([left/(left+body+right),.31,body/(left+body+right),.52]);bottom=np.zeros(n)
            for c in allowed:
                values=table[c].fillna(0).to_numpy();ax.bar(np.arange(n),values,bottom=bottom,width=.65,color=colors[c],linewidth=0);bottom+=values
            empty=table.isna().all(axis=1)
            for i in np.flatnonzero(empty):ax.text(i,.5,'NA',ha='center')
            ax.set_xlim(-.5,n-.5);ax.set_ylim(0,1.02);ax.set_xticks(range(n));ax.set_xticklabels([DISPLAY[x] for x in table.index] if view=='treatment' else table.index,rotation=90,fontsize=8)
            ax.set_ylabel('Neighbor composition (fraction)');ax.legend(handles=[Patch(color=colors[c],label=c) for c in allowed],bbox_to_anchor=(1.03,1),loc='upper left',frameon=False,fontsize=8)
            fig.suptitle(f'{pop} | {mode} {low:g}–{high:g} µm | {den}\n'+('Equal mouse means' if view=='treatment' else 'Individual mice ordered by treatment'),fontsize=10)
            fig.text(.04,.02,'Actual circular radii; source cell excluded once. No tissue-edge correction.\nCounts are pairs, not unique cells in a union. Mice, not neighbors, are the treatment replicates.',fontsize=8)
            p=root/slug(pop)/f'{mode}_{low:g}_{high:g}_{den}_{view}.png';p.parent.mkdir(parents=True,exist_ok=True)
            fig.savefig(p,dpi=s['dpi'],facecolor='white');plt.close(fig)
    return root
