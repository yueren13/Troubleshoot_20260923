from pathlib import Path
import subprocess,json
import numpy as np
import pandas as pd
from .core import *

def tables(atlas):
    x=atlas['counts'];rows=[]
    for sample,g in x.groupby('sample',sort=False):
        info=atlas['sources'].set_index('sample').loc[sample];total=int(g.n_cells.sum());t=g.loc[g.population.isin(TUMOR)].set_index('population').n_cells.reindex(TUMOR,fill_value=0)
        tumor=int(t.sum());common=dict(sample=sample,unit=info['unit'],condition=info['condition'])
        for group,count in [(ALL_TUMOR,tumor),('Other reviewed cell',total-tumor)]:rows.append(dict(**common,model='overall_tumor_fraction',cell_group=group,count=count,denominator=total))
        for group,count in list(t.items())+[('Other reviewed cell',total-tumor)]:rows.append(dict(**common,model='subtypes_global_fraction',cell_group=group,count=int(count),denominator=total))
        for group,count in t.items():rows.append(dict(**common,model='subtypes_within_tumor',cell_group=group,count=int(count),denominator=tumor))
    data=pd.DataFrame(rows);data['fraction']=np.divide(data['count'],data.denominator,out=np.full(len(data),np.nan),where=data.denominator>0)
    path=atlas['out']/'sccomp'/'inputs';path.mkdir(exist_ok=True)
    for name,g in data.groupby('model',sort=False):save_csv(g,path/(name+'.csv'))
    save_csv(data,path/'all_model_denominators.csv');return path,data

def preflight(connection_json):
    exe,env=r_connection(connection_json);script=Path(__file__).with_name('sccomp_backend.R')
    p=subprocess.run([exe,'--vanilla',str(script),'--check'],env=env,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stdout+'\n'+p.stderr)
    return json.loads(p.stdout.strip().splitlines()[-1])

def smoke_test(root,connection_json,cores=2):
    root=Path(root);rng=np.random.default_rng(17);rows=[]
    for i,condition in enumerate(np.repeat(CONDITIONS,3)):
        p=np.array([.7,.2,.1]) if condition=='Vehicle' else np.array([.4,.35,.25])
        p=rng.dirichlet(p*100)
        counts=rng.multinomial(3000,p)
        for group,n in zip(['synthetic_A','synthetic_B','synthetic_C'],counts):rows.append(dict(sample=f'S{i:02d}',condition=condition,cell_group=group,count=int(n)))
    version=preflight(connection_json);out=root/'synthetic_sccomp_smoke'/digest(version)[:12];out.mkdir(parents=True,exist_ok=True)
    if (out/'complete_R.json').is_file():return load_json(out/'complete_R.json')
    save_csv(pd.DataFrame(rows),out/'counts.csv');conn=load_json(connection_json)
    job=dict(job_id=digest(version),model_name='SYNTHETIC_ONLY_NOT_CT26',counts=str(out/'counts.csv'),output=str(out),stan_cache=conn['stan_cache'],
        settings=dict(cores=cores,seed=17,max_sampling_iterations=2000,effect_threshold=.1,posterior_predictive_plots=False))
    run_r(Path(__file__).with_name('sccomp_backend.R'),job,out,connection_json)
    return load_json(out/'complete_R.json')

def fit(atlas,connection_json,settings=None):
    s=dict(cores=4,seed=17,max_sampling_iterations=8000,effect_threshold=.1,posterior_predictive_plots=True)
    s.update(settings or {});inputs,data=tables(atlas);versions=preflight(connection_json);connection=load_json(connection_json)
    spec=dict(settings=s,versions=versions,input_sha=sha(inputs/'all_model_denominators.csv'),r_sha=sha(Path(__file__).with_name('sccomp_backend.R')))
    out=atlas['out']/'sccomp'/digest(spec)[:12];out.mkdir(exist_ok=True);save_json(spec,out/'model_spec.json');reports=[]
    for name,g in data.groupby('model',sort=False):
        path=out/name;path.mkdir(exist_ok=True)
        if (g.denominator<=0).any():
            reports.append(dict(model=name,status='not_testable_zero_denominator',directory=str(path)));continue
        done=path/'complete_R.json'
        job=dict(job_id=digest(dict(spec=spec,model=name)),model_name=name,counts=str(inputs/(name+'.csv')),output=str(path),stan_cache=connection['stan_cache'],settings=s)
        if done.is_file() and load_json(done).get('job_id')==job['job_id']:report=load_json(done)
        else:
            try:run_r(Path(__file__).with_name('sccomp_backend.R'),job,path,connection_json);report=load_json(done)
            except Exception as e:reports.append(dict(model=name,status='FAILED',detail=str(e),directory=str(path)));continue
        reports.append({**report,'model':name,'directory':str(path)})
    result=pd.DataFrame(reports);save_csv(result,out/'sccomp_fit_summary.csv');return out,result

def plot_inputs(atlas,data,dpi=300):
    import matplotlib.pyplot as plt
    root=atlas['out']/'figures'/'composition';root.mkdir(exist_ok=True)
    for (model,group),g in data.groupby(['model','cell_group'],sort=False):
        scalar_plot(g,'fraction',root/slug(model)/(slug(group)+'_mouse_fractions.png'),f'{group} | {model}',dpi)
    return root

def plot_results(root,dpi=300):
    import matplotlib.pyplot as plt
    root=Path(root);status=pd.read_csv(root/'sccomp_fit_summary.csv',keep_default_na=False)
    for r in status.to_dict('records'):
        path=Path(r['directory']);f=path/'contrasts.csv'
        if not f.is_file():continue
        x=pd.read_csv(f);needed={'cell_group','parameter','c_effect','c_lower','c_upper','c_FDR'}
        if not needed.issubset(x):raise ValueError('Installed sccomp result columns differ; inspect contrasts.csv')
        for contrast,g in x.groupby('parameter',sort=False):
            g=g.sort_values('c_effect');fig,ax=plt.subplots(figsize=(8,max(3.5,.4*len(g)+1.5)))
            for i,row in enumerate(g.itertuples()):
                ax.plot([row.c_lower,row.c_upper],[i,i],color='0.35');ax.scatter(row.c_effect,i,s=40,color='#D43E88' if row.c_FDR<.05 else '#999999')
            ax.axvline(0,color='black',lw=.6);ax.set_yticks(range(len(g)));ax.set_yticklabels(g.cell_group)
            ax.set(title=f'{r["model"]}\n{contrast}\n{r["status"]}',xlabel='sccomp composition coefficient contrast (native model scale)')
            fig.text(.01,.01,'Intervals: Bayesian 95% credible intervals; highlighted: c_FDR < 0.05. Check convergence first.',fontsize=8)
            savefig(fig,path/'figures'/(slug(contrast)+'.png'),dpi)
    return root
