# Method references and implementation scope

## Existing project inputs
The supplied CT26 tumor-visibility 09A–09D package defines source manifests,
raw HDF5 streaming, annotation matching, physical coordinates, and DESeq2 output
contracts. The new notebooks reuse those definitions. `tumor_visibility/` is bundled
unchanged from the supplied ZIP; it is not a new replacement of the original run.
The user confirmed 12 independent mouse tumors, three per condition, no technical
replicates. The specified tumor/state labels and treatments are not inferred.

## Expression
- Reference DESeq2 vignette: https://bioconductor.org/packages/3.22/bioc/vignettes/DESeq2/inst/doc/DESeq2.html
- HBC LRT patterns: https://hbctraining.github.io/DGE_workshop/lessons/08_DGE_LRT.html

LRT selects significant genes. Four-condition VST row standardization and K-means
response patterns are descriptive choices implemented here, not a signed LRT
statistic, a monotonic trend test, or exact DEGreport::degPatterns reproduction.
The leave-one-mouse-out table measures profile influence, not refitted DE significance.

## sccomp / R backend
- sccomp project: https://github.com/MangiolaLaboratory/sccomp
- Bioconductor 3.22 release source (sccomp 2.2.x API):
  https://raw.githubusercontent.com/bioconductor-source/sccomp/RELEASE_3_22/R/sccomp_estimate.R
  https://raw.githubusercontent.com/bioconductor-source/sccomp/RELEASE_3_22/R/sccomp_test.R
- Mangiola et al., sccomp: Robust differential composition and variability analysis
  for single-cell data. PNAS (2023), doi:10.1073/pnas.2203828120.
- CmdStanr installation/toolchain:
  https://mc-stan.org/cmdstanr/reference/install_cmdstan.html

Composition/variability formulas, effect thresholds, HMC inference and explicit
zero-inclusive count tables follow the package's documented interfaces. The
overall fraction / global subtype / conditional subtype models are three separate
estimands, not three independent validation datasets. Bayesian FDR is retained as
reported by sccomp, not relabeled as frequentist P value.

## Spatial
- PySAL Moran and Geary API/source documentation:
  https://pysal.org/esda/stable/user-guide/global_morans_i.html
  https://pysal.org/esda/stable/user-guide/geary.html
  (API locations may change; implementation is directly formula-tested.)
- SciPy exact count-only spatial tree:
  https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.cKDTree.query_ball_point.html
- spatstat point-pattern window/edge correction explanations:
  https://spatstat.org/FAQ.html
  https://spatstat.org/explainKplot.html

Moran/Geary are implemented for symmetric binary raster adjacency and checked
against direct W formulas. Patches are connected physical-grid components under
explicit density/fraction thresholds, not a named validated histological-island
classifier. Translation-corrected K is a count-raster FFT approximation with a
clearly recorded observation window. Conditional target-label permutations preserve
cell abundance and observed sampling locations. No exact continuous-point,
edge-free or tissue-mask-corrected claim is made for a proxy support window.

The generated marker specificity score, raster component definitions and proposed
thresholds are analysis choices to inspect, not results established by these papers.
