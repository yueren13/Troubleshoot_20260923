# Validation — CT26 general tumor characterization

## Executed locally

The tests used 12 explicitly synthetic mouse tumors in four conditions. Actual
sparse CSR HDF5 count sources and CSV annotations were read using the supplied 09A
helpers, with shuffled cell IDs, duplicate feature symbols, and a missing subtype
in one sample. No real CT26 measurements were available in this runtime.

- PASS: Supplied 09A code created actual synthetic HDF5/CSV caches; 10A resolves and validates exact sources/units
- PASS: Three sccomp denominator tables conserve counts; observed subtype zero retained without pseudocounts
- PASS: Compact pattern heatmaps, full membership, expression z-scores, per-mouse and leave-one-out diagnostics validated
- PASS: Replicate-aware candidate specificity and actual duplicate-symbol detection/log expression match raw truth
- PASS: Symmetric-queen Moran I and Geary C agree with direct matrix formulas; constants return NA
- PASS: Raster translation-corrected K matches direct ordered-pair edge weights; random-label counts yield reproducible curves
- PASS: Island descriptors separate equal-area connected and fragmented synthetic patterns
- PASS: 50/100/200 radius counts match brute force; disjoint rings sum to cumulative, source cells excluded once
- PASS: Whole-cohort architecture computation/maps/cache checks and independent-mouse summaries execute
- PASS: All-group neighborhood caches and treatment-first/per-sample stacked figures render
- PASS: Mouse-level exact tests preserve 3-vs-3 P-value resolution
- PASS: Final 300-dpi compact LRT heatmaps rendered and visually inspected
- PASS: Empty eligible patch support returns undefined density; empty Ripley observation window is rejected
- PASS: All seven notebook schemas and Python code cells compile; no saved execution outputs
- PASS: Bundled supplied tumor_visibility Python/R dependency is byte-identical to uploaded source
- PASS: R script delimiters balanced by lexical inspection only (R parser/runtime unavailable)

## Plot checks

A compact four-condition heatmap with a colored response-pattern strip and a
20-row treatment-separated marker dotplot were visually inspected. Final compact
heatmaps were rendered at 300 dpi. The remaining synthetic figure tests mostly
used 70/80 dpi for speed; the delivered notebooks default to 300 dpi.
Synthetic LRT P values were fixture inputs for plotting, NOT generated DESeq2
results. Pattern membership/standardization and influence diagnostics were tested
against the known synthetic expression matrices.

## Important unexecuted parts

- No Rscript/R/DESeq2/sccomp/CmdStan backend is available in this authoring runtime.
  Real statistical fits, CmdStan compilation, HMC convergence, and package
  installation were NOT executed. R scripts were reviewed against the official
  Bioconductor 3.22 API and checked lexically, not by an R parser.
- 10C0 includes a real on-server synthetic sccomp smoke test. Its result has not
  already been obtained here, and it does not guarantee real-data convergence.
- Parquet source routes were NOT exercised (pyarrow unavailable). The actual
  RawReader HDF5 CSR and CSV annotation/gene-table routes were exercised.
- New spatial calculations use saved physical coordinates; new H&E registration
  or image reads are not part of this add-on. Existing histology should be used
  to validate raster patches and the observation-window choice.
- The default support window is a proxy based on occupied all-reference-cell
  pixels, not a verified histological tissue mask. The K/L results are deliberately
  raster approximations with explicit physical grids and conditional-label nulls.

## Reproducing the CPU tests

From the extracted folder:

```bash
CT26_CHARACTERIZATION_TEST_ROOT=/your/scratch/ct26_characterization_test \
python tests/test_characterization.py
```

The test writes synthetic fixtures and figures to scratch, not study inputs.
It does not run R or install software. The bundled source dependency is preserved
unchanged. The notebooks and code contain no claims of completed real-data fits
or new biological findings.
