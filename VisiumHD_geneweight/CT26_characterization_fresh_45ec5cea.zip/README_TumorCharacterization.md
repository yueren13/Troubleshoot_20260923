# CT26 tumor characterization: expression, composition, architecture and neighbors

## Start here

Extract the **entire package into a new analysis folder**, preserving the
`tumor_characterization/` and bundled `tumor_visibility/` directories. The latter
is the unchanged helper package from the supplied 09A–09D tumor-visibility ZIP;
it provides the existing source contracts and optional DESeq2 runner.

Do not copy files into the original fingerprinted `inputs/` directory, replace
`ct26_common.py`, change the upstream `run_name`, or overwrite the old 09 package.
No segmentation, scVI, annotation, Leiden clustering, or new per-cell QC filtering
is performed here. Use a fresh Python/CPU kernel after switching add-on versions.

**10A requires completed 09A extraction**, specifically the existing PROJECT_ROOT
containing `project.json`, `source_manifest.csv`, and completed per-sample caches.
Set `VISIBILITY_PROJECT_ROOT` to the path printed by 09A. Alternatively, point
`PREVIOUS_09_ADDON_DIR` to the old add-on folder containing
`active_tumor_visibility_project.json`. There is no guess based on the newest folder.

The design is already confirmed: **12 separate mouse tumors, three per condition**,
with no technical replicates. It is checked against the actual source metadata.
Every treatment-level summary uses mice, not cells/tiles/islands, as replicates.

## Notebook sequence

| Notebook | Purpose | Requirements |
|---|---|---|
| 10A | Source/annotation coverage and composition denominator audit | Completed 09A caches |
| 10B | Pooled and subtype LRT patterns, compact heatmaps, gene lists, curves and boxplots | Completed 09B fits, or the existing R DESeq2 environment to create them |
| 10C0 | Install sccomp/CmdStan and run a synthetic model smoke test | R 4.5.x / Bioconductor 3.22, writable library and C++ toolchain |
| 10C | Overall tumor and subtype composition models | 10C0 backend or another verified sccomp connection |
| 10D | Top 5/10 subtype markers and dotplots | Existing raw H5AD sources for one candidate-gene scan |
| 10E | Spatial autocorrelation, raster patches and rasterized Ripley summaries | 09A physical coordinates; optional registered tissue mask |
| 10F | 50/100/200 µm neighborhoods and disjoint rings | 09A physical coordinates |

After 10A, the expression, composition, marker and spatial branches are independent.
You do not need to wait for sccomp before generating marker/spatial figures.
A local `index.html` gallery is refreshed after each analysis notebook.

## New output directory

Default:

```
<09A PROJECT_ROOT>/tumor_characterization/<input_fingerprint>/
  characterization_manifest.json
  source_manifest.csv
  tables/
  figures/
  markers/
  sccomp/
  architecture/
  neighborhoods/
  index.html
```

`OUTPUT_ROOT_OVERRIDE` in 10A can place new output on fast persistent local storage.
It does not move or modify sources. Fingerprints distinguish changed settings,
annotations, source metadata and code; completed compatible per-sample calculations
are reused. Existing raw files/annotation signatures are checked before proceeding.

# 10B — compact expression-pattern heatmaps

The existing 09B model already fits **All tumor cell** and **Tumor cell 1–5** with
sample-level raw pseudobulk. 10B reuses its saved `fit_status.csv`, overall LRT,
VST expression, and fitted library metadata. If no 09B model pointer exists, an
optional cell uses the bundled unchanged 09B model runner to create the fits using
your verified R connection. It disables Hallmark testing for this general first pass.
Failed/untestable subtype fits remain explicitly reported, not invented or substituted.

## What the z-score means

For each gene:
1. Average its saved VST expression across independent mice in each condition.
2. Center and standardize those **four condition means** within that gene.
3. Cluster those four-element profiles into an editable number of patterns.

This is an **expression z-score**, not a signed LRT effect, Wald statistic, gene
significance score, or evidence of temporal change. Original LRT adjusted P values
select the genes; significance is not recalculated after selecting a pattern.

Default: `LRT_any_condition`, `padj < 0.05`, **all significant genes**, six exploratory
patterns, 300-dpi PNGs. `max_genes=None` means no silent top-gene limit. `n_patterns`
is an analyst-controlled resolution, not an automatically discovered biological truth.
K-means operates on four-condition standardized profiles, with eight reproducible
starts; it avoids an all-genes pairwise clustering matrix. Empty/constant profiles
are audited. Pattern colors/numbers are local to each population; Pattern 2 in one
subtype is not automatically the same biological program as Pattern 2 in another.

Treatment order is Vehicle, Anti-PD1, Adagrasib, Combination. Monotonic, transient,
monotherapy-specific, combination-specific and reversing responses are all allowed.
No filter selects only a desired sequential trend.

## Plots and tables per population

- One **compact four-condition heatmap**, with no gene-row names and a colored
  pattern strip. Each block's height reflects its number of genes.
- A matching **12-mouse heatmap** with the same rows/order and the same gene
  center/scale used for the condition plot. Values outside the color limit are
  visually clipped, but saved matrices retain their full values.
- Separate per-pattern median/IQR curves and gene-distribution boxplots.
- A separate mouse-level pattern-score plot with each mouse labeled. Pattern boxes
  summarize genes; mouse dots are the independent experimental units.
- Full significant-gene table, pattern membership, per-pattern gene lists,
  four-condition VST means, standardized matrices and mouse scores.
- **Leave-one-mouse-out profile influence**: recompute the displayed mean-expression
  profile after leaving one mouse out, and report similarity/max standardized change.
  This does NOT refit DESeq2, recalibrate its P values or validate cluster stability.

The mouse-resolved view and leave-one-out table are intended to help determine
whether the combination patterns are coherent across all three tumors or are
strongly influenced by one specimen. They do not automatically remove that mouse.

# 10C0 / 10C — sccomp composition

## Installation

sccomp requires an R package plus the CmdStan backend/toolchain. 10C0 uses your
existing R 4.5.2 connection JSON and explicitly installs the **Bioconductor 3.22**
sccomp release into a separate library overlay. It does not request mass updates
of the existing DESeq2 library or install/upgrade Python packages.

Defaults:

```
BASE_R_CONNECTION:
  .../env/R452_Bioc322_DESeq2_ashr/r_connection.json
SCCOMP_ENV_ROOT:
  .../env/R452_Bioc322_sccomp/
CmdStan version: 2.37.0
```

An existing valid CmdStan directory can be specified instead of downloading it.
The installer checks the C++ toolchain without attempting privileged system fixes.
Network access and compilation prerequisites must be supplied by the environment.
No package installation happens unless the explicit installation cell is run.

The resulting `sccomp_connection.json` supplies R library paths and CMDSTAN to
fresh `Rscript --vanilla` processes. A synthetic 12-sample model checks the actual
backend on your server. API formals and package versions are recorded; unknown
interfaces stop rather than silently substituting another composition method.

The backend uses the Bioconductor 3.22 `sccomp_estimate` and `sccomp_test` interface.
It explicitly requests HMC, keeps raw counts including observed zeros, and does
not automatically remove sample/cell-group outliers (only three mice per arm).
Posterior variability is modeled with `~1`; a treatment-specific variability model
is not added to this small design by default. Composition uses `~0+condition` and
all six pairwise condition contrasts. The effect threshold defaults to 0.1 in the
package's native threshold scale; the actual argument name is recorded.

Outputs include native coefficient contrasts/credible intervals, package FDR,
RDS fit objects, Stan diagnostics and attempted posterior-predictive plots. The
plots show convergence status. `REVIEW_CONVERGENCE` means do not interpret an
apparent discovery without inspecting the fit. Bayesian `c_pH0`/`c_FDR` are not
DESeq2 P values or frequentist LRT results. With three mice, priors and uncertainty
are important; no cell-level sample-size inflation is used.

## Three distinct denominator models

1. **overall_tumor_fraction**: All tumor cell / Other reviewed cell (2 parts).
   Denominator: all reviewed labeled cells in each sample.
2. **subtypes_global_fraction**: Tumor 1–5 / Other reviewed cell (6 parts).
   Denominator: all reviewed labeled cells.
3. **subtypes_within_tumor**: Tumor 1–5 only (5 parts).
   Denominator: all five tumor populations.

The second and third answer different questions: a subtype can gain share among
tumor cells while losing share among all reviewed cells. Each composition sums to
one within its own denominator. Categories absent in a sample are real observed
zeros, not pseudocounts. A zero TOTAL denominator is undefined and blocks that
model. Completely absent categories are documented/dropped, not regularized by
adding fake cells. Unassigned/excluded cells remain in the separate coverage audit.

These are **relative composition estimates**, not absolute tumor mass, viable tumor
volume, proliferation rate or cell density. Section area, annotation coverage and
sampling remain relevant. The package does not label composition shifts as
pharmacologic synergy or infer a single omnibus “all composition changed” LRT.

# 10D — top tumor-subtype markers

The goal is descriptive discrimination among these five data-derived tumor groups,
not independent validation of five biologically distinct cell types.

1. Use cached all-gene pseudobulk counts to compare each subtype against **each of
   the other four** within matched mice.
2. Rank by the weakest of those four median within-mouse log2-CPM differences;
   require consistent direction and adequate support. This is more specific than
   simply ranking each subtype against every non-tumor cell.
3. Select candidate genes, then make one additional chunked source-count pass over
   tumor cells for actual raw detection fractions and mean per-cell log1p expression.
4. Produce top-5 and top-10 dotplots, plus treatment-separated versions using the
   same genes. The primary overview uses equal mouse weighting, not pooled-cell
   weighting. Raw counts and all-source library totals define the dot measurements.

Starting thresholds: >=30 cells in each compared subtype/mouse, >=6 informative
mice per pair, minimum pairwise median log2-CPM difference >=0.5, >=70% same-direction
support, mean target CPM >=2, and mean detection >=10% for the plotted shortlist.
The CPM pseudocount of 0.5 is for ranking only; it never enters a DESeq2 count fit.
Mitochondrial/ribosomal/hemoglobin patterns are excluded from the identity shortlist
but remain in the full audit/ranking. No count rounding or symbol case guessing.

The plot shows **up to** 5/10 passing genes per subtype. The helper does not fill a
short list with nonspecific genes just to reach ten. Thresholds are editable and
recorded. Cell-level P values are not reported as evidence across animals.
The dotplot mean-log1p colors are scaled relative to each gene's maximum for display;
absolute values and detection rates are exported. Absent populations/genes remain
NA, not zeros. Original raw/annotation files are untouched.

# 10E — tumor/subtype spatial architecture

## Why more than one metric

An image with many compact tumor islands may retain strong short-range spatial
clustering. A lower tumor fraction, smaller islands and a lower Moran's I are not
interchangeable claims. We therefore measure abundance, autocorrelation, direct
raster components and scale-dependent pair structure separately. No assumption
forces every metric to decrease Vehicle → Anti-PD1 → Adagrasib → Combination.

All analyses run separately for each physical mouse section and for pooled tumor
and all five subtypes. Numeric results use all available cells. Two grid widths,
25 and 50 µm, and multiple abundance thresholds supply a sensitivity check.

## Observation window — essential limitation

By default, the support window is the **occupied raster of ALL full-reference
segmented cells**, not a bounding rectangle, not a hull of tumor cells, and **not
an independently registered histological tissue mask**. It preserves observed
holes at the grid scale but cannot distinguish acellular necrosis, blank tissue,
and unobserved/background regions that have no segmented cells.

Each result records `all_reference_occupied_tiles_PROXY`. A validated binary tissue
mask can override it through `MASK_OVERRIDES`, indexed by sample and grid width.
NPZ must contain `mask` (bool H×W), `origin_um` ([x0,y0]) and `pixel_size_um`, exactly
matching the saved grid. No resizing or guessed registration is performed. Exported
grid metadata helps build and verify that override. A mask of only tumor patches
would be an inappropriate observation window for testing tumor distribution.

For tile-fraction autocorrelation and patches, the default field additionally
requires >=3 full cells, >=3 reviewed cells and >=50% reviewed coverage. Unsupported
cells/tiles are not interpreted as zero tumor fraction. The eligible support area,
full-cell coverage, and window source are saved per sample.

## Moran's I and Geary's C

Field: group count / reviewed-cell count on eligible physical tiles.
Weights: symmetric binary 8-neighbor (queen) adjacency, no cross-gap neighbors and
no sample mixing. Both formulas are checked against a direct dense-W calculation.
Constant fields return NA instead of dividing by zero. This can occur when a
Vehicle field is almost uniformly tumor: NA is not automatically a failed analysis.

199 within-image value-shuffle permutations are descriptive spatial-null checks,
not treatment P values. Treatment comparison uses one scalar per independent mouse.
Grid width, field coverage and global group abundance can affect the statistics.

## Island/patch measurements

Foreground tiles meet a fixed population-fraction threshold and >=2 target cells.
Default pooled thresholds: 0.3/0.5/0.7; subtype thresholds: 0.1/0.25/0.5.
8-connected components define **raster patches**, not histologist-drawn tumor nests.
No smoothing, hole filling, dilation or morphological closing is applied.

Per-sample measurements include:
- patch number and number per eligible-support area;
- median/largest patch area and cell-weighted patch area;
- fraction of all eligible target cells belonging to the largest patch;
- fraction of target cells captured by the thresholded patch mask;
- raster interface-length density (not a true polygon perimeter).

Each threshold/grid has a preview map and a component table. Inspect whether these
maps capture the visually described islands. Finer dispersed groups may fall below
the threshold/min-count rule; retained fractions and sensitivity settings make that
visible rather than hiding it. Absolute island area depends on physical grid size.

## Rasterized Ripley K/L

To avoid an enormous continuous point-pair graph, K is computed from FFT count-raster
autocorrelation with translation-overlap edge weights. It is a **raster approximation**:
points in one pixel are colocated at that resolution. Only radii >=2 pixels are allowed.
Default K grid 25 µm, radii 50/100/200 µm; self-pairs are removed, distinct colocated
objects remain. Sparse/tiny window overlap is flagged and the radius returns NA.

The implementation was checked against direct ordered-pair translation weights on
synthetic grids. It is not claimed to reproduce exact continuous-coordinate
`spatstat::Kest` values at arbitrarily small radii.

Conditional random-label envelopes preserve target cell count and the full sampled
spatial geometry. Pooled tumor is randomized among reviewed cells; each tumor subtype
is randomized among all tumor cells. This separates some effects of total density/
coverage and subtype abundance from additional spatial arrangement, without claiming
a complete inhomogeneous point-process model. The default 39 simulations produce
coarse pointwise exploratory envelopes, not a global multi-radius significance test.
L(r)-r, conditional excess, window source and overlap diagnostics are exported.
A subtype absent from a sample gives undefined K/L, not a zero-distance or uniform
population.

Optional treatment tests compare independent mice, not points or components. For
3 versus 3 mice, the minimum two-sided exact absolute-mean-difference P value is
0.10; millions of cells cannot remove that replication limit. Multiple endpoint
comparisons are corrected within the selected output family.

# 10F — immediate/mid/far neighborhoods

For this request **50, 100, 200 µm are radii** (not the previous 50/100-µm diameter
QC windows). Two definitions are always reported:

- cumulative: within 50, within 100, within 200 µm;
- annular: 0–50, >50–100, >100–200 µm.

A cumulative 200-µm neighborhood includes immediate cells; the 100–200 ring isolates
the more distant surroundings. Source objects are excluded exactly once, while other
objects with identical centroids remain valid neighbors. Every target subtype and
pooled tumor are analyzed, with exact count-only queries, per sample. No spatial
edges can connect different mice.

Two denominator views:
- `all_reviewed`: all reviewed neighboring cell types, including tumor states;
- `non_tumor_reviewed`: only non-tumor reviewed neighbors, to reveal immune/stromal
  composition without tumor cells dominating the plot.

Tables include mean neighbor counts per center, fraction of centers with a type,
pair-weighted fractions, equal-active-center fractions, global-composition ratios
and annotation coverage. Neighbors may contribute around several source cells;
these are center-neighbor pairs, not unique cells in a union. Empty neighborhoods
remain defined as zero counts but have no fractional composition; absent target
populations remain NA.

Default bar plots show treatment equal-mouse mean composition first, and individual
samples ordered within treatment. Native plot widths keep the same physical bar
width across 4-condition and 12-sample figures. Plot settings can restrict selected
populations or rings without repeating the numeric calculations. No border/hole
correction or tissue-constrained/geodesic distance is claimed.

## Dependencies and validation scope

Python: numpy, pandas, scipy, matplotlib, h5py, nbformat (for notebook validation),
and pyarrow if the real source annotations/gene tables are Parquet. No GPU/RAPIDS
or AnnData load of the giant scVI graph is needed. R is only needed for sccomp and
for tumor DESeq2 fits that do not already exist.

The included Python tests use synthetic 12-mouse data with real sparse HDF5/CSV
raw-count extraction through the supplied 09A helpers. Statistical R fits and actual
CT26 measurements were **not** executed in the creation environment. Read
`VALIDATION.md` and `METHOD_REFERENCES.md` for exact scope and method sources.
