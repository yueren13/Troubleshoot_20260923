"""Synthetic CPU integration tests. No real study data or actual R fits."""
from pathlib import Path
import os,sys,tempfile,json
import numpy as np,pandas as pd,h5py,scipy.sparse as sp
from scipy.spatial.distance import cdist
from scipy import ndimage as ndi
import matplotlib;matplotlib.use('Agg')
PACKAGE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(PACKAGE))
from tumor_visibility import common as tv,expression as tx
from tumor_characterization import core as tc,patterns as pat,markers as mk,architecture as ar,neighbors as nb,composition as cc
ROOT=Path(os.environ.get('CT26_CHARACTERIZATION_TEST_ROOT',tempfile.mkdtemp(prefix='ct26_characterization_')));ROOT.mkdir(exist_ok=True,parents=True)
checks=[]
def ok(t):checks.append(t);print('PASS:',t,flush=True)
def vector(g,k,v):
 v=np.asarray(v);g.create_dataset(k,data=v.astype(object),dtype=h5py.string_dtype()) if v.dtype.kind in 'OU' else g.create_dataset(k,data=v)
def frame(g,df):
 g.attrs.update({'encoding-type':'dataframe','encoding-version':'0.2.0','_index':'_index'});vector(g,'_index',df.index.astype(str))
 for c in df:vector(g,c,df[c].to_numpy())
rng=np.random.default_rng(4);manifest=[];truth={}
genes=[f'Type{k}_marker{z:02d}' for k in range(1,6) for z in range(20)]+[f'Common{j:03d}' for j in range(100)]
for i in range(12):
 sample=f'SYN{i:02d}';path=ROOT/sample;path.mkdir(exist_ok=True)
 labels=np.array(sum(([g]*35 for g in tc.TUMOR),[])+['T cell 1']*20+['T cell 2']*20+['Macrophage 1']*15+['Fibroblast cell 1']*15+['']*8,object)
 if i==0:labels=labels[labels!='Tumor cell 5']
 n=len(labels);xy=rng.uniform(0,400,(n,2));xy[:,0]+=i*50
 # Treatment-associated fragmented positions are fixture geometry, not a biological finding.
 C=rng.poisson(2,(n,len(genes)+1)).astype(np.int64);C[rng.random(C.shape)<.30]=0
 for k,g in enumerate(tc.TUMOR):C[np.ix_(labels==g,np.arange(k*20,(k+1)*20))]+=rng.poisson(35,(np.sum(labels==g),20))
 C[:,-1]=C[:,0]//2;symbols=genes+[genes[0]]
 ids=[f'cell{j:05d}' for j in range(n)];raw=path/'raw.h5ad'
 with h5py.File(raw,'w') as h:
  frame(h.create_group('obs'),pd.DataFrame(index=ids));frame(h.create_group('var'),pd.DataFrame({'gene_symbol':symbols},index=[f'f{j}' for j in range(len(symbols))]))
  X=sp.csr_matrix(C);g=h.create_group('X');g.attrs.update({'encoding-type':'csr_matrix','shape':X.shape})
  for key,v in [('data',X.data),('indices',X.indices),('indptr',X.indptr)]:g.create_dataset(key,data=v)
 a=pd.DataFrame({'source_cell_id':ids,'sample':sample,'preliminary_annotation':labels,'centroid_x':xy[:,0],'centroid_y':xy[:,1],
                 'raw_total_counts':C.sum(axis=1),'is_in_scvi_graph':labels!=''})
 a=a.sample(frac=1,random_state=18);ann=path/'ann.csv';a.to_csv(ann,index=False)
 manifest.append(dict(sample=sample,unit=sample,condition=tc.CONDITIONS[i//3],raw_h5ad=str(raw),matrix_key='X',annotation_file=str(ann),gene_table='',gene_symbol_column='gene_symbol',cell_id_column='source_cell_id',sample_column='sample',label_column='preliminary_annotation',total_counts_column='raw_total_counts'))
 truth[sample]=(C,symbols,labels,xy,ids)
program=ROOT/'programs.json';program.write_text(json.dumps(dict(panels={'AP_MHCI_core':genes[:5],'IFN_core_exploratory':genes[5:10]},individual_genes=genes[:2],spatial_ifn_exclusion_genes=genes[:2])))
project=tx.create_project(pd.DataFrame(manifest),ROOT/'09_project',program,settings={'chunk_cells':31})
tx.extract(project);atlas=tc.open_atlas(project)
assert len(atlas['sources'])==12 and atlas['sources'].unit.is_unique
assert atlas['coverage'].n_full.sum()==sum(len(t[2]) for t in truth.values())
ok('Supplied 09A code created actual synthetic HDF5/CSV caches; 10A resolves and validates exact sources/units')
inputs,comps=cc.tables(atlas)
for sample,g in comps.groupby('sample'):
 overall=g[g.model=='overall_tumor_fraction'];within=g[g.model=='subtypes_within_tumor'];glob=g[g.model=='subtypes_global_fraction']
 assert overall['count'].sum()==glob['count'].sum()
 assert within['count'].sum()==overall.set_index('cell_group').loc[tc.ALL_TUMOR,'count']
 assert np.isclose(within.fraction.sum(),1) and np.isclose(overall.fraction.sum(),1)
assert comps.loc[(comps['sample']=='SYN00')&(comps.cell_group=='Tumor cell 5'),'count'].eq(0).all()
ok('Three sccomp denominator tables conserve counts; observed subtype zero retained without pseudocounts')
# Generate synthetic 09B-format fits ONLY for pattern plotting; no actual DESeq2 tests are simulated as real.
model=ROOT/'synthetic_models';model.mkdir(exist_ok=True);statuses=[]
for pop in [tc.ALL_TUMOR,'Tumor cell 1']:
 p=model/tc.slug(pop);p.mkdir(exist_ok=True)
 meta=pd.DataFrame({'library_id':[f'U{i:02d}' for i in range(12)],'independent_unit':[f'SYN{i:02d}' for i in range(12)],'condition':np.repeat(tc.CONDITIONS,3)})
 meta.to_csv(p/'fitted_library_metadata.csv',index=False)
 profiles=np.array([[-2,-1,1,2],[2,1,-1,-2],[0,2,0,-1],[0,0,0,3],[0,-1,2,0]])
 values=np.array([profiles[j%5].repeat(3)+rng.normal(0,.2,12)+10 for j in range(100)])
 # Strong single combo-mouse deviation to test influence visibility.
 values[0,-1]+=5
 vst=pd.DataFrame(values,index=genes[:100],columns=meta.library_id);vst.index.name='gene';vst.to_csv(p/'vst_expression.tsv.gz',sep='\t')
 result=pd.DataFrame({'gene':genes[:100],'baseMean':20.,'stat':20.,'pvalue':.001,'padj':.01});result.to_csv(p/'LRT_any_condition.tsv.gz',sep='\t',index=False)
 pd.DataFrame([dict(test_id='LRT_any_condition',file='LRT_any_condition.tsv.gz')]).to_csv(p/'result_index.csv',index=False)
 statuses.append(dict(population=pop,status='complete',directory=str(p)))
pd.DataFrame(statuses).to_csv(model/'fit_status.csv',index=False)
pr,ps=pat.run(atlas,model,{'dpi':80,'n_patterns':5})
assert len(ps[ps.status=='complete'])==2
for pop in [tc.ALL_TUMOR,'Tumor cell 1']:
 z=pd.read_csv(pr/tc.slug(pop)/'condition_mean_zscores.csv',index_col=0)
 np.testing.assert_allclose(z.mean(axis=1),0,atol=1e-12);np.testing.assert_allclose(z.std(axis=1,ddof=0),1,atol=1e-12)
 assert len(z)==100
 loo=pd.read_csv(pr/tc.slug(pop)/'leave_one_mouse_out_profile_influence.csv.gz');assert len(loo)==1200
 assert (pr/tc.slug(pop)/'compact_conditions_pattern_heatmap.png').exists()
ok('Compact pattern heatmaps, full membership, expression z-scores, per-mouse and leave-one-out diagnostics validated')
mr,cand=mk.rank_candidates(atlas,dict(min_cells_per_subtype=10,min_informative_mice=6,min_pairwise_log2fc=.5,min_consistent_fraction=.7,candidates_per_subtype=40))
assert len(cand)>50
for group,g in cand.groupby('population'):
 num=int(group[-1]);assert g.head(10).gene.str.startswith(f'Type{num}_').all()
obs=mk.measure_candidate_panel(atlas,mr,chunk=23)
assert obs.fraction_detected.dropna().between(0,1).all()
assert obs.loc[(obs['sample']=='SYN00') & (obs.population=='Tumor cell 5'),'fraction_detected'].isna().all()
selected=mk.plot_markers(mr,top_n=5,min_detection=.1,min_cells=10,dpi=80)
assert len(selected)==25
s='SYN03';g='Type1_marker00';v=obs[(obs['sample']==s)&(obs.population=='Tumor cell 1')&(obs.gene==g)].iloc[0]
C,S,L,XY,IDs=truth[s];idx=[i for i,x in enumerate(S) if x==g];raw=C[L=='Tumor cell 1'][:,idx].sum(axis=1);total=C[L=='Tumor cell 1'].sum(axis=1)
np.testing.assert_allclose(v.fraction_detected,(raw>0).mean());np.testing.assert_allclose(v.mean_log1p,np.log1p(raw*10000/total).mean())
ok('Replicate-aware candidate specificity and actual duplicate-symbol detection/log expression match raw truth')
# Explicit Moran/Geary formula check.
mask=np.ones((4,5),bool);y=rng.normal(size=mask.sum());edge=ar.raster_edges(mask);I,Cc=ar.moran_geary(y,edge)
W=np.zeros((len(y),len(y)));W[edge]=1;W[(edge[1],edge[0])]=1;z=y-y.mean()
np.testing.assert_allclose(I,len(y)/W.sum()*(z@W@z)/(z@z))
np.testing.assert_allclose(Cc,(len(y)-1)/(2*W.sum())*(W*(y[:,None]-y[None,:])**2).sum()/(z@z))
assert np.isnan(ar.moran_geary(np.ones(len(y)),edge)[0])
ok('Symmetric-queen Moran I and Geary C agree with direct matrix formulas; constants return NA')
# Exact calculation of rasterized translation K with brute force at pixel positions.
counts=rng.integers(0,4,(4,5));setup=ar.translation_setup(mask,1.,[2.,3.],min_overlap_fraction=0.)
kt=ar.raster_K(counts,setup);points=np.repeat(np.argwhere(mask),counts[mask],axis=0);A=mask.sum();N=len(points)
for radius in [2.,3.]:
 score=0
 for i in range(N):
  for j in range(N):
   if i==j:continue
   dy,dx=points[j]-points[i]
   if np.hypot(dy,dx)<=radius:score+=1/((4-abs(dy))*(5-abs(dx)))
 expect=A*A/(N*(N-1))*score
 np.testing.assert_allclose(kt.loc[kt.radius_um==radius,'K_um2'],expect)
observed,null=ar.random_label_K(counts,counts+2,setup,9,17);assert null.shape==(9,2)
ok('Raster translation-corrected K matches direct ordered-pair edge weights; random-label counts yield reproducible curves')
# Fragmentation test: same foreground tile count, connected patch vs separated islands.
m=np.ones((20,20),bool);den=np.ones((20,20),int)*10;dense=np.zeros_like(den);dense[2:10,2:10]=10
islands=np.zeros_like(den)
for a,b in [(1,1),(1,13),(13,1),(13,13)]:islands[a:a+4,b:b+4]=10
one,_,_=ar.patch_metrics(dense,den,m,10,.5,1);many,_,_=ar.patch_metrics(islands,den,m,10,.5,1)
assert one['n_patches']==1 and many['n_patches']==4
assert one['patch_area_um2']==many['patch_area_um2'] and many['largest_patch_fraction_of_group_cells']==.25
ok('Island descriptors separate equal-area connected and fragmented synthetic patterns')
# Neighborhoods match brute force and exclude self while retaining colocated distinct cells.
r=tc.read_reference(project,'SYN02');categories=list(dict.fromkeys(atlas['counts'].population));nm=nb.sample_metrics(r,categories,[50.,100.,200.],workers=1,chunk=13)
xy=r[['x_um','y_um']].to_numpy();la=r.population.fillna('Unassigned').to_numpy();cm=np.isin(la,tc.TUMOR);dist=cdist(xy[cm],xy)
center_rows=np.flatnonzero(cm)
for radius in [50.,100.,200.]:
 inside=dist<=radius;inside[np.arange(len(center_rows)),center_rows]=False
 for kind in ['T cell 1','Tumor cell 1']:
  expected=inside[:,la==kind].sum(axis=1)
  result=nm[(nm.population==tc.ALL_TUMOR)&(nm.neighbor_type==kind)&(nm.outer_radius_um==radius)&(nm['mode']=='cumulative')&(nm.denominator=='all_reviewed')].iloc[0]
  np.testing.assert_allclose(result.mean_neighbors_per_center,expected.mean())
for group in [tc.ALL_TUMOR]+tc.TUMOR:
 for neighbor in ['T cell 1','Tumor cell 1']:
  f=nm[(nm.population==group)&(nm.neighbor_type==neighbor)&(nm.denominator=='all_reviewed')]
  np.testing.assert_allclose(f.loc[f['mode']=='annulus','total_neighbor_pairs'].sum(),f.loc[(f['mode']=='cumulative')&(f.outer_radius_um==200),'total_neighbor_pairs'].iloc[0])
ok('50/100/200 radius counts match brute force; disjoint rings sum to cumulative, source cells excluded once')
# Full cohort architecture at lightweight synthetic settings + cache reuse.
AR_SETTINGS=dict(grid_sizes_um=[25.],min_full_cells=1,min_reviewed_cells=1,min_reviewed_fraction=.3,pooled_thresholds=[.3,.5],subtype_thresholds=[.1],min_group_cells=1,
 autocorrelation_permutations=9,ripley_grid_um=25.,ripley_radii_um=[50.,100.],ripley_permutations=3,min_overlap_fraction=0.,plot_populations=[tc.ALL_TUMOR],dpi=70)
arch,atable=ar.run(atlas,AR_SETTINGS);assert len(atable['coverage'])==12 and len(atable['autocorrelation'])==72
before={p:p.stat().st_mtime_ns for p in arch.glob('*/complete.json')};ar.run(atlas,AR_SETTINGS);assert all(p.stat().st_mtime_ns==t for p,t in before.items())
ar.plot_summary(arch,atable,populations=[tc.ALL_TUMOR],dpi=70)
ok('Whole-cohort architecture computation/maps/cache checks and independent-mouse summaries execute')
nroot,ntable,tmeans=nb.run(atlas,dict(workers=1,chunk_centers=20));assert len(tmeans)>0
nb.plot(nroot,ntable,atlas,dict(dpi=70,populations=[tc.ALL_TUMOR],modes=['annulus'],denominators=['all_reviewed']))
ok('All-group neighborhood caches and treatment-first/per-sample stacked figures render')
cc.plot_inputs(atlas,comps,dpi=70)
# Unit tests: 3 versus 3 exact p minimum .1, never use cells.
small=pd.DataFrame({'sample':[str(i) for i in range(12)],'unit':[str(i) for i in range(12)],'condition':np.repeat(tc.CONDITIONS,3),'population':'All tumor cell','metric':np.r_[np.zeros(3),np.ones(3),np.ones(3)*2,np.ones(3)*3]})
test=tc.outcome_tests(small,['population'],'metric',ROOT/'synthetic_unit_tests.csv');assert (test.pvalue>=.1).all()
ok('Mouse-level exact tests preserve 3-vs-3 P-value resolution')
report=dict(checks=checks,n_checks=len(checks),project_root=str(project),pattern_root=str(pr),marker_root=str(mr),architecture_root=str(arch),neighborhood_root=str(nroot),
 limitations=['Synthetic data only.','Actual R/sccomp/CmdStan/DESeq2 execution unavailable here.','Real Parquet data not tested; actual CSR HDF5 and CSV routes used.','Compact LRT plots used simulated result statistics, not computed R results.','Most test PNGs rendered at 70/80 dpi; delivery defaults use 300 dpi.'])
(ROOT/'test_report.json').write_text(json.dumps(report,indent=2));print('ALL PASSED:',len(checks),'REPORT:',ROOT/'test_report.json')
