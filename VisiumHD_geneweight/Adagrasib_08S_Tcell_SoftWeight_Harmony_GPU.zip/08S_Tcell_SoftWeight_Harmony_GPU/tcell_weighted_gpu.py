"""08S: fixed gene-weighted GPU PCA, joint GPU Harmony, and T-cell clustering.

The input is a prepared sparse, full-library-normalized log1p expression matrix.
Weights are feature priorities, NOT inferred endogenous transcript fractions.
PCA uses standard randomized range finding with implicit centering, thin QR,
and a small SVD, all on the selected GPU. No dense cells-by-genes array or
gene covariance matrix is constructed. Harmony/graph/UMAP/Leiden use RAPIDS.

CLI example (launch a fresh process for each branch):
    python tcell_weighted_gpu.py --cache-dir cache --output-dir runs/weighted \
        --branch weighted --gpu-device 0 --settings-json settings.json

References:
https://doi.org/10.1137/090771806 (randomized matrix decompositions)
https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.harmony_integrate.html
https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.neighbors.html
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import gc
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import resource
import threading
import time
import traceback
import uuid

import numpy as np
import pandas as pd
import scipy.sparse as sp


ENGINE_VERSION = "08S-2026-11-10.1"
DEFAULT_SETTINGS = {
    "n_pcs": 50,
    "pca_oversamples": 20,
    "pca_power_iter": 3,
    "random_state": 0,
    "n_neighbors": 30,
    "neighbors_algorithm": "cagra",
    "resolutions": [0.2, 0.4, 0.6],
    "leiden_n_iterations": 100,
    "harmony_theta": 1.0,
    "harmony_max_iter": 10,
    "harmony_cluster_max_iter": 20,
    "harmony_n_clusters": 100,
    "umap_min_dist": 0.3,
    "umap_spread": 1.0,
    "umap_maxiter": 200,
    "max_wall_minutes": 110,
}


def _jsonable(value):
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, type):
        return value.__name__
    return value


def atomic_json(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temp.open("w", encoding="utf-8") as stream:
            json.dump(_jsonable(content), stream, indent=2, allow_nan=False)
            stream.write("\n")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def atomic_npz(path, **arrays):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temp.open("wb") as stream:
            # Uncompressed checkpoints avoid repeatedly compressing dense PCs.
            np.savez(stream, **arrays)
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _atomic_h5ad(adata, path):
    path = Path(path)
    temp = path.with_name(path.stem + ".tmp-" + uuid.uuid4().hex + ".h5ad")
    try:
        adata.write_h5ad(temp, compression="lzf")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def ordered_id_hash(values):
    """Hash ordered identifiers without ambiguity from embedded delimiters."""
    digest = hashlib.sha256()
    for value in values:
        data = str(value).encode("utf-8")
        digest.update(len(data).to_bytes(8, "little"))
        digest.update(data)
    return digest.hexdigest()


def _fingerprint(obj):
    encoded = json.dumps(_jsonable(obj), sort_keys=True, separators=(",", ":"),
                         allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _weight_hash(weights):
    return hashlib.sha256(np.asarray(weights, dtype="<f4").tobytes()).hexdigest()


def _versions():
    result = {}
    for name in ["rapids-singlecell", "anndata", "numpy", "scipy", "pandas",
                 "cupy-cuda12x", "cupy-cuda11x", "cupy", "cuml-cu12",
                 "cugraph-cu12", "cuvs-cu12"]:
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    return result


def validate_settings(settings=None):
    cfg = dict(DEFAULT_SETTINGS)
    supplied = {} if settings is None else dict(settings)
    unknown = set(supplied) - set(cfg)
    if unknown:
        raise ValueError("Unknown GPU settings: " + ", ".join(sorted(unknown)))
    cfg.update(supplied)
    for key in ["n_pcs", "pca_oversamples", "pca_power_iter", "random_state",
                "n_neighbors", "leiden_n_iterations", "harmony_max_iter",
                "harmony_cluster_max_iter", "harmony_n_clusters", "umap_maxiter"]:
        value = cfg[key]
        if isinstance(value, bool) or int(value) != value or int(value) < 0:
            raise ValueError(f"{key} must be a nonnegative integer.")
        cfg[key] = int(value)
    if cfg["n_pcs"] < 2 or cfg["n_neighbors"] < 2:
        raise ValueError("n_pcs and n_neighbors must be >= 2.")
    for key in ["leiden_n_iterations", "harmony_max_iter", "harmony_cluster_max_iter",
                "harmony_n_clusters", "umap_maxiter"]:
        if cfg[key] < 1:
            raise ValueError(f"{key} must be positive.")
    for key in ["harmony_theta", "umap_min_dist", "umap_spread", "max_wall_minutes"]:
        cfg[key] = float(cfg[key])
        if not np.isfinite(cfg[key]) or cfg[key] < 0:
            raise ValueError(f"{key} must be finite and nonnegative.")
    if cfg["umap_spread"] <= 0 or cfg["umap_min_dist"] > cfg["umap_spread"]:
        raise ValueError("UMAP requires spread > 0 and min_dist <= spread.")
    if cfg["neighbors_algorithm"] not in {"cagra", "brute", "ivfflat", "ivfpq", "nn_descent"}:
        raise ValueError("Unsupported neighbors_algorithm.")
    cfg["resolutions"] = [float(v) for v in cfg["resolutions"]]
    if not cfg["resolutions"] or any(not np.isfinite(v) or v <= 0 for v in cfg["resolutions"]):
        raise ValueError("resolutions must contain finite positive values.")
    if len(set(cfg["resolutions"])) != len(cfg["resolutions"]):
        raise ValueError("Duplicate Leiden resolutions are not allowed.")
    return cfg


def _metadata_inputs(cache_dir, branch, cfg):
    cache_dir = Path(cache_dir).expanduser().resolve()
    matrix_path = cache_dir / "lognorm_features.npz"
    names = [matrix_path, cache_dir / "obs.csv.gz", cache_dir / "features.csv",
             cache_dir / "cache_manifest.json"]
    missing = [str(p) for p in names if not p.is_file()]
    if missing:
        raise FileNotFoundError("Prepare the 08S input cache first. Missing: " + ", ".join(missing))
    manifest = json.loads(names[3].read_text(encoding="utf-8"))
    if not manifest.get("cache_id"):
        raise ValueError("cache_manifest.json must contain a nonempty cache_id.")
    obs = pd.read_csv(names[1], dtype={"cell_id": str, "sample_id": str, "condition": str},
                      keep_default_na=False)
    for key in ["cell_id", "sample_id"]:
        if key not in obs or obs[key].eq("").any():
            raise ValueError(f"obs.csv.gz needs a nonempty {key} for every row.")
    if obs["cell_id"].duplicated().any():
        raise ValueError("Cell IDs in the cache are not unique.")
    obs.index = pd.Index(obs.pop("cell_id").astype(str), name="cell_id")
    for key in ["sample_id", "condition"]:
        if key in obs:
            obs[key] = pd.Categorical(obs[key].astype(str))
    features = pd.read_csv(names[2], dtype={"gene": str})
    if "gene" not in features or features["gene"].isna().any() or features["gene"].duplicated().any():
        raise ValueError("features.csv must have unique, nonmissing gene names.")
    if features["gene"].eq("").any() or "weight" not in features:
        raise ValueError("features.csv needs nonempty gene names and a weight column.")
    weights = pd.to_numeric(features["weight"], errors="raise").to_numpy(dtype=np.float32)
    if not np.isfinite(weights).all() or (weights <= 0).any() or (weights > 1).any():
        raise ValueError("Distance weights must be finite and in (0, 1].")
    if branch not in {"weighted", "unweighted"}:
        raise ValueError("branch must be 'weighted' or 'unweighted'.")
    weights = weights if branch == "weighted" else np.ones(len(features), dtype=np.float32)
    with np.load(matrix_path, allow_pickle=False) as data:
        shape = tuple(int(v) for v in data["shape"])
    if shape != (len(obs), len(features)):
        raise ValueError("Cached expression shape does not match ordered obs/features files.")
    if min(shape) < 4:
        raise ValueError("At least four cells and four eligible genes are required.")
    row_hash, gene_hash = ordered_id_hash(obs.index), ordered_id_hash(features["gene"])
    # These explicit fields use this module's documented hash convention.
    for key, actual in [("engine_cell_ids_sha256", row_hash), ("engine_gene_ids_sha256", gene_hash)]:
        if key in manifest and manifest[key] != actual:
            raise ValueError(f"Cache identity mismatch: {key}.")
    stat = matrix_path.stat()
    source = {"data_identity": str(manifest.get("data_identity", manifest["cache_id"])), "shape": shape,
              "matrix_size_bytes": stat.st_size, "matrix_mtime_ns": stat.st_mtime_ns,
              "cell_ids_sha256": row_hash, "gene_ids_sha256": gene_hash,
              "sample_ids_sha256": ordered_id_hash(obs["sample_id"])}
    k = min(cfg["n_pcs"], shape[0] - 1, shape[1] - 1)
    return cache_dir, matrix_path, manifest, obs, features, weights, source, k


def _prepare_csr(matrix):
    matrix = sp.csr_matrix(matrix, dtype=np.float32, copy=False)
    if not matrix.has_canonical_format:
        matrix.sum_duplicates()
    matrix.sort_indices()
    matrix.eliminate_zeros()
    for start in range(0, matrix.nnz, 5_000_000):
        values = matrix.data[start:start + 5_000_000]
        if not np.isfinite(values).all() or (values < 0).any():
            raise ValueError("Prepared log expression must be finite and nonnegative.")
    if matrix.nnz == 0:
        raise ValueError("The feature matrix is empty.")
    # The selected data size should be well below the int32 CSR entry limit.
    if matrix.nnz < np.iinfo(np.int32).max and max(matrix.shape) < np.iinfo(np.int32).max:
        matrix = sp.csr_matrix((matrix.data, matrix.indices.astype(np.int32, copy=False),
                                matrix.indptr.astype(np.int32, copy=False)),
                               shape=matrix.shape, copy=False)
    return matrix


def randomized_pca_operator(matrix, n_components, weights, *, xp,
                            n_oversamples=20, n_iter=3, random_state=0):
    """Centered, weighted randomized PCA without a dense cell-by-gene array.

    Production passes a CuPy CSR matrix and xp=cupy. xp=numpy with a SciPy CSR
    is available solely for deterministic mathematical validation on small data.
    No internal fallback changes xp or the device. The input sparse data are
    copied before weighting, preserving the cache and original matrix.

    Returned scores equal (weighted_X - mean) @ loadings; variance is measured
    from those projected scores. The approximate leading basis is obtained by
    reorthogonalized randomized range finding and a thin SVD.
    """
    n, p = matrix.shape
    k = int(n_components)
    if not 1 <= k < min(n, p):
        raise ValueError("PCA component count must be smaller than both dimensions.")
    if int(n_oversamples) < 0 or int(n_iter) < 0:
        raise ValueError("Randomized PCA iteration and oversampling counts must be nonnegative.")
    amplitudes = xp.sqrt(xp.asarray(weights, dtype=xp.float32))
    if amplitudes.shape != (p,):
        raise ValueError("The weight vector must align exactly with all feature columns.")
    weighted = matrix.astype(xp.float32, copy=True)
    weighted.data *= amplitudes[weighted.indices]
    mean = xp.asarray(weighted.mean(axis=0)).reshape(-1).astype(xp.float32)
    width = min(k + int(n_oversamples), p, n - 1)

    def forward(v):
        result = weighted @ v
        result -= (mean @ v)[None, :]
        return result

    def transpose(v):
        result = weighted.T @ v
        result -= mean[:, None] * xp.sum(v, axis=0, dtype=xp.float32)[None, :]
        return result

    # NumPy creates only G x width random numbers; this gives the same random
    # starting subspace to both branches and across NumPy/CuPy QA runs.
    omega_cpu = np.random.default_rng(int(random_state)).standard_normal((p, width)).astype(np.float32)
    omega = xp.asarray(omega_cpu)
    q, _ = xp.linalg.qr(forward(omega), mode="reduced")
    del omega, omega_cpu
    for _ in range(int(n_iter)):
        q_t, _ = xp.linalg.qr(transpose(q), mode="reduced")
        q, _ = xp.linalg.qr(forward(q_t), mode="reduced")
        del q_t
    small = transpose(q).T
    _, singular, vt = xp.linalg.svd(small, full_matrices=False)
    loadings = vt[:k].T.copy()
    # Resolve the arbitrary SVD component sign with the largest loading.
    maxima = xp.argmax(xp.abs(loadings), axis=0)
    signs = xp.sign(loadings[maxima, xp.arange(k)])
    signs = xp.where(signs == 0, xp.float32(1), signs).astype(xp.float32)
    loadings *= signs[None, :]
    scores = forward(loadings)
    variance = xp.var(scores, axis=0, ddof=1, dtype=xp.float64)
    # Log-expression magnitudes are bounded; accumulate squared float32 values
    # in float64 without allocating a full float64 nonzero-value copy.
    sumsq = xp.sum(weighted.data * weighted.data, dtype=xp.float64)
    mean64 = mean.astype(xp.float64)
    total_variance = (sumsq - n * xp.sum(mean64 * mean64)) / (n - 1)
    if not bool(xp.isfinite(total_variance)) or float(total_variance) <= 0:
        raise ValueError("The prepared features have no positive finite centered variance.")
    ratio = variance / total_variance
    result = {"scores": scores.astype(xp.float32, copy=False),
              "loadings": loadings.astype(xp.float32, copy=False),
              "mean": mean,
              "variance": variance,
              "variance_ratio": ratio,
              "singular_values_approx": singular[:k],
              "total_variance": total_variance}
    for key in ["scores", "loadings", "mean", "variance", "variance_ratio"]:
        if not bool(xp.isfinite(result[key]).all()):
            raise FloatingPointError(f"Nonfinite values returned by GPU PCA: {key}.")
    return result


def _signature(function):
    return inspect.signature(function).parameters


def _seed_kw(function, seed):
    params = _signature(function)
    if "rng" in params:
        return {"rng": int(seed)}
    if "random_state" in params:
        return {"random_state": int(seed)}
    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
        return {"random_state": int(seed)}
    raise RuntimeError(f"{function.__name__} has no supported seed argument. Check the RAPIDS version.")


def _required_kwargs(function, values):
    params = _signature(function)
    accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())
    absent = [key for key in values if key not in params and not accepts_kwargs]
    if absent:
        raise RuntimeError(f"{function.__name__} lacks required parameters {absent}; "
                           "the installed RAPIDS API is incompatible with this notebook.")
    return dict(values)


def _harmony_kwargs(function, cfg, n_cells):
    params = _signature(function)
    result = _required_kwargs(function, {
        "key": "sample_id", "basis": "X_pca", "adjusted_basis": "X_pca_harmony",
        "theta": cfg["harmony_theta"],
        "max_iter_harmony": cfg["harmony_max_iter"],
        "max_iter_clustering": cfg["harmony_cluster_max_iter"],
        "n_clusters": min(cfg["harmony_n_clusters"], max(2, n_cells // 30)),
    })
    # Use original Harmony when new releases also expose Harmony2. Legacy
    # releases without a flavor parameter implement the original algorithm.
    if "flavor" in params:
        result["flavor"] = "harmony1"
    if "dtype" in params:
        result["dtype"] = np.float32
    if "verbose" in params:
        result["verbose"] = True
    if "multi_gpu" in params:
        result["multi_gpu"] = False
    result.update(_seed_kw(function, cfg["random_state"]))
    return result


def preflight_gpu(gpu_device=0):
    """Small GPU/API check suitable for a fresh child before reading any H5AD."""
    try:
        import cupy as cp
        import cupyx.scipy.sparse as cpsp
        import rapids_singlecell as rsc
        import anndata
    except ImportError as exc:
        raise ImportError("Use the RAPIDS environment that ran the previous GPU notebook. "
                          "CuPy, rapids-singlecell, and anndata are required.") from exc
    count = int(cp.cuda.runtime.getDeviceCount())
    if not 0 <= int(gpu_device) < count:
        raise ValueError(f"GPU {gpu_device} is unavailable; {count} device(s) are visible.")
    cfg = validate_settings()
    api = {}
    for group, name in [("pp", "harmony_integrate"), ("pp", "neighbors"),
                        ("tl", "leiden"), ("tl", "umap")]:
        function = getattr(getattr(rsc, group), name, None)
        if not callable(function):
            raise RuntimeError(f"rapids_singlecell.{group}.{name} is unavailable.")
        api[group + "." + name] = {"parameters": list(_signature(function)),
                                  "seed_argument": list(_seed_kw(function, 0))[0]}
    # Catch incompatible Harmony wrappers before loading large inputs.
    harmony_args = _harmony_kwargs(rsc.pp.harmony_integrate, cfg, 600)
    _required_kwargs(rsc.pp.neighbors, {"n_neighbors": 20, "n_pcs": 10,
        "use_rep": "X_pca_harmony", "algorithm": "cagra", "metric": "euclidean", "key_added": "neighbors"})
    _required_kwargs(rsc.tl.leiden, {"resolution": 0.4, "key_added": "leiden_0.4",
        "n_iterations": 100, "use_weights": True, "neighbors_key": "neighbors"})
    _required_kwargs(rsc.tl.umap, {"min_dist": 0.3, "spread": 1.0,
        "init_pos": "random", "neighbors_key": "neighbors", "maxiter": 200})
    with cp.cuda.Device(int(gpu_device)):
        info = cp.cuda.runtime.getDeviceProperties(int(gpu_device))
        name = info.get("name", "unknown")
        # Exercise the full GPU path before reading a large biological file.
        # Tiny brute-neighbor testing avoids CAGRA's small-input constraints;
        # production retains the configured CAGRA algorithm.
        test = np.random.default_rng(17).poisson(1.5, size=(192, 8)).astype(np.float32)
        gpu = cpsp.csr_matrix(np.log1p(test))
        check = randomized_pca_operator(gpu, 3, np.linspace(0.2, 1, 8, dtype=np.float32),
                                        xp=cp, n_oversamples=3, n_iter=1, random_state=0)
        cp.cuda.get_current_stream().synchronize()
        if not bool(cp.isfinite(check["scores"]).all()):
            raise RuntimeError("Tiny GPU PCA arithmetic check failed.")
        tiny = anndata.AnnData(X=None,
            obs=pd.DataFrame({"sample_id": pd.Categorical(["sample_A"] * 96 + ["sample_B"] * 96)},
                             index=[f"preflight_{i}" for i in range(192)]),
            var=pd.DataFrame(index=[f"g{i}" for i in range(8)]))
        tiny.obsm["X_pca"] = cp.asnumpy(check["scores"])
        tiny_cfg = dict(cfg, harmony_max_iter=2, harmony_cluster_max_iter=3,
                        harmony_n_clusters=3)
        rsc.pp.harmony_integrate(tiny, **_harmony_kwargs(rsc.pp.harmony_integrate, tiny_cfg, 192))
        neighbor_args = {"n_neighbors": 10, "n_pcs": 3, "use_rep": "X_pca_harmony",
                         "algorithm": "brute", "metric": "euclidean", "key_added": "neighbors"}
        neighbor_args.update(_seed_kw(rsc.pp.neighbors, 0))
        rsc.pp.neighbors(tiny, **neighbor_args)
        leiden_args = {"resolution": 0.4, "key_added": "preflight_leiden", "n_iterations": 5,
                       "use_weights": True, "neighbors_key": "neighbors"}
        if "use_dask" in _signature(rsc.tl.leiden):
            leiden_args["use_dask"] = False
        leiden_args.update(_seed_kw(rsc.tl.leiden, 0))
        rsc.tl.leiden(tiny, **leiden_args)
        umap_args = {"min_dist": 0.3, "spread": 1.0, "init_pos": "random",
                     "neighbors_key": "neighbors", "maxiter": 20}
        if "key_added" in _signature(rsc.tl.umap):
            umap_args["key_added"] = "X_umap"
        umap_args.update(_seed_kw(rsc.tl.umap, 0))
        rsc.tl.umap(tiny, **umap_args)
        umap_key = "X_umap" if "X_umap" in tiny.obsm else "umap"
        if not np.isfinite(np.asarray(_to_host(tiny.obsm[umap_key], cp))).all():
            raise RuntimeError("Tiny GPU graph/UMAP check returned nonfinite coordinates.")
        if tiny.obs["preflight_leiden"].isna().any():
            raise RuntimeError("Tiny GPU Leiden check did not label every observation.")
        cp.cuda.get_current_stream().synchronize()
        del tiny
        del check, gpu
        free, total = cp.cuda.runtime.memGetInfo()
    return {"ok": True, "engine_version": ENGINE_VERSION,
            "visible_device_count": count, "gpu_logical_device": int(gpu_device),
            "gpu_name": name.decode() if isinstance(name, bytes) else str(name),
            "free_device_bytes": int(free), "total_device_bytes": int(total),
            "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES", "not set"),
            "versions": _versions(), "cupy_version": cp.__version__,
            "rapids_singlecell_version": getattr(rsc, "__version__", "unknown"),
            "api": api, "harmony_arguments": _jsonable(harmony_args),
            "arithmetic_check": "192-cell GPU centered PCA, Harmony, brute neighbors, Leiden and short UMAP passed"}


def _to_host(value, cp):
    if isinstance(value, cp.ndarray):
        return cp.asnumpy(value)
    if value.__class__.__module__.startswith("cupyx.scipy.sparse"):
        return value.get()
    if isinstance(value, dict):
        return {key: _to_host(v, cp) for key, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_to_host(v, cp) for v in value]
    return value


def _cpu_adata(adata, cp):
    # Only the small representations and sparse graph are present here.
    for key in list(adata.obsm):
        adata.obsm[key] = _to_host(adata.obsm[key], cp)
    for key in list(adata.varm):
        adata.varm[key] = _to_host(adata.varm[key], cp)
    for key in list(adata.obsp):
        adata.obsp[key] = _to_host(adata.obsp[key], cp)
    for key in list(adata.uns):
        adata.uns[key] = _to_host(adata.uns[key], cp)
    return adata


class _StageLogger:
    def __init__(self, cp, device, metadata, output_dir):
        self.cp, self.device = cp, int(device)
        self.metadata, self.output_dir = metadata, Path(output_dir)
        self.started = time.perf_counter()

    def checkpoint(self):
        self.metadata["elapsed_this_process_seconds"] = time.perf_counter() - self.started
        self.metadata["host_process_maxrss_MiB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
        atomic_json(self.output_dir / "run_metadata.json", self.metadata)

    def budget_guard(self, next_stage):
        minutes = self.metadata["settings"]["max_wall_minutes"]
        if minutes and (time.perf_counter() - self.started) > minutes * 60:
            raise TimeoutError(f"The {minutes:g}-minute stage-boundary budget was reached before {next_stage}. "
                               "Completed checkpoints are saved; no cells were dropped. Increase the budget to resume.")

    @contextmanager
    def stage(self, name):
        # Save completed GPU work even if the most recent kernel crossed the
        # stage-boundary budget. The launcher can enforce a harder wall cap.
        if name != "save_results":
            self.budget_guard(name)
        print(f"[{self.metadata['branch']}] {name}: starting", flush=True)
        stop = threading.Event()
        samples = []

        def sample_memory():
            try:
                with self.cp.cuda.Device(self.device):
                    while not stop.is_set():
                        free, total = self.cp.cuda.runtime.memGetInfo()
                        samples.append(int(total - free))
                        stop.wait(0.5)
            except Exception:
                pass  # Monitoring must not change the computation outcome.

        monitor = threading.Thread(target=sample_memory, daemon=True)
        monitor.start()
        start = time.perf_counter()
        succeeded = False
        try:
            yield
            self.cp.cuda.get_current_stream().synchronize()
            succeeded = True
        finally:
            seconds = time.perf_counter() - start
            stop.set()
            monitor.join(timeout=2)
            self.metadata.setdefault("stages", {})[name] = {
                "seconds": seconds, "completed": succeeded,
                "sampled_peak_device_used_MiB": max(samples, default=0) / 2**20,
                "memory_note": "Sampled driver-wide device use includes other processes; not a guaranteed kernel peak.",
            }
            self.metadata["last_stage"] = name
            self.checkpoint()
            print(f"[{self.metadata['branch']}] {name}: {'done' if succeeded else 'failed'} in {seconds:.1f}s", flush=True)


def _valid_checkpoint(path, expected, required_keys=("scores",)):
    path = Path(path)
    if not path.is_file():
        return False
    try:
        with np.load(path, allow_pickle=False) as data:
            return (str(data["fingerprint"].item()) == expected
                    and all(key in data.files for key in required_keys))
    except Exception:
        return False


def _load_npz(path):
    with np.load(path, allow_pickle=False) as data:
        return {key: data[key] for key in data.files if key != "fingerprint"}


def _valid_embedding(path, expected, ad, n_cells, n_genes, row_hash, gene_hash, status,
                     n_pcs=None, cluster_keys=()):
    if not Path(path).is_file():
        return False
    try:
        saved = ad.read_h5ad(path, backed="r")
        try:
            if not (saved.uns.get("08s_fingerprint") == expected
                    and saved.uns.get("08s_stage") == status
                    and saved.shape == (n_cells, n_genes)
                    and ordered_id_hash(saved.obs_names) == row_hash
                    and ordered_id_hash(saved.var_names) == gene_hash):
                return False
            for key in ["X_pca", "X_pca_harmony"]:
                if key not in saved.obsm or saved.obsm[key].shape[0] != n_cells:
                    return False
                if n_pcs is not None and saved.obsm[key].shape[1] != n_pcs:
                    return False
                if not np.isfinite(saved.obsm[key]).all():
                    return False
            if "PCs" not in saved.varm or "pca_feature_mean" not in saved.var:
                return False
            neighbors = saved.uns.get("neighbors", {})
            for key in [neighbors.get("connectivities_key", "connectivities"),
                        neighbors.get("distances_key", "distances")]:
                if key not in saved.obsp or saved.obsp[key].shape != (n_cells, n_cells):
                    return False
            if status == "complete":
                if "X_umap" not in saved.obsm or saved.obsm["X_umap"].shape != (n_cells, 2):
                    return False
                if not np.isfinite(saved.obsm["X_umap"]).all():
                    return False
                if any(key not in saved.obs or saved.obs[key].isna().any() for key in cluster_keys):
                    return False
            return True
        finally:
            saved.file.close()
    except Exception:
        return False


def _assert_coordinates(array, shape, label):
    if tuple(array.shape) != tuple(shape) or not np.isfinite(array).all():
        raise ValueError(f"{label} has unexpected shape or nonfinite coordinates.")


def _write_assignments(analysis, output_dir, cluster_keys):
    output_dir = Path(output_dir)
    columns = ["sample_id"] + (["condition"] if "condition" in analysis.obs else []) + list(cluster_keys)
    temp = output_dir / ("cluster_assignments.tmp-" + uuid.uuid4().hex + ".csv.gz")
    try:
        analysis.obs[columns].to_csv(temp, index=True, compression="gzip")
        os.replace(temp, output_dir / "cluster_assignments.csv.gz")
    finally:
        temp.unlink(missing_ok=True)


def _completion_receipt(output_dir, fingerprint):
    output_dir = Path(output_dir)
    atomic_json(output_dir / "completion.json", {
        "status": "complete", "fingerprint": fingerprint,
        "embedding": "embedding.h5ad", "assignments": "cluster_assignments.csv.gz",
        "metadata": "run_metadata.json", "completed_utc": datetime.now(timezone.utc).isoformat(),
    })


def _has_complete_receipt(output_dir, fingerprint):
    output_dir = Path(output_dir)
    try:
        receipt = json.loads((output_dir / "completion.json").read_text(encoding="utf-8"))
        metadata = json.loads((output_dir / "run_metadata.json").read_text(encoding="utf-8"))
        return (receipt.get("fingerprint") == fingerprint and receipt.get("status") == "complete"
                and metadata.get("final_fingerprint") == fingerprint and metadata.get("status") == "complete"
                and (output_dir / "cluster_assignments.csv.gz").stat().st_size > 0)
    except (OSError, ValueError, KeyError):
        return False


def _repair_completion(output_dir, fingerprint, ad, cluster_keys):
    """Finish an interrupted output transaction without recomputing the graph."""
    output_dir = Path(output_dir)
    result = ad.read_h5ad(output_dir / "embedding.h5ad")
    try:
        metadata = json.loads(result.uns["08s_metadata_json"])
    except (KeyError, ValueError, TypeError):
        metadata = {"engine_version": ENGINE_VERSION}
    _write_assignments(result, output_dir, cluster_keys)
    metadata.update({"status": "complete", "final_fingerprint": fingerprint,
                     "completed_utc": datetime.now(timezone.utc).isoformat(),
                     "embedding_path": str(output_dir / "embedding.h5ad"),
                     "recovered_output_transaction": True})
    atomic_json(output_dir / "run_metadata.json", metadata)
    _completion_receipt(output_dir, fingerprint)


def run_gpu_branch(cache_dir, output_dir, branch="weighted", gpu_device=0,
                   settings=None, resume=True):
    """Run one matched analysis on all cached T cells; return embedding path.

    A fresh subprocess is recommended. CUDA_VISIBLE_DEVICES, if used, must be
    set by the launcher before imports; gpu_device then refers to its logical
    device number. This function never resets the CUDA allocator or empties
    another analysis's global memory pool. Interrupted PCA/Harmony/graph stages
    resume from compatible saved checkpoints. max_wall_minutes is checked at
    stage boundaries; it cannot interrupt a currently running CUDA operation.
    """
    cfg = validate_settings(settings)
    (cache_dir, matrix_path, manifest, obs, features, weights,
     source, n_pcs) = _metadata_inputs(cache_dir, branch, cfg)
    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    import anndata as ad

    n_cells, n_genes = len(obs), len(features)
    versions = _versions()
    pca_settings = {key: cfg[key] for key in ["pca_oversamples", "pca_power_iter", "random_state"]}
    pca_settings.update({"n_pcs_used": n_pcs, "solver": "randomized_gpu", "zero_center": True,
                         "gene_standardization": "none", "column_multiplier": "sqrt(distance_weight)"})
    pca_fp = _fingerprint({"engine": ENGINE_VERSION, "source": source,
                           "weights_sha256": _weight_hash(weights), "settings": pca_settings,
                           "numerics_versions": versions})
    harmony_settings = {key: cfg[key] for key in cfg if key.startswith("harmony_")}
    harmony_fp = _fingerprint({"pca": pca_fp, "settings": harmony_settings, "flavor": "harmony1"})
    graph_settings = {key: cfg[key] for key in ["n_neighbors", "neighbors_algorithm", "random_state"]}
    graph_fp = _fingerprint({"harmony": harmony_fp, "settings": graph_settings})
    final_settings = {key: cfg[key] for key in ["resolutions", "leiden_n_iterations", "umap_min_dist",
                                               "umap_spread", "umap_maxiter", "random_state"]}
    final_fp = _fingerprint({"graph": graph_fp, "settings": final_settings})
    final_path = output_dir / "embedding.h5ad"
    cluster_keys = [f"leiden_{resolution:g}" for resolution in cfg["resolutions"]]
    if resume and _valid_embedding(final_path, final_fp, ad, n_cells, n_genes,
                                   source["cell_ids_sha256"], source["gene_ids_sha256"], "complete",
                                   n_pcs=n_pcs, cluster_keys=cluster_keys):
        if not _has_complete_receipt(output_dir, final_fp):
            _repair_completion(output_dir, final_fp, ad, cluster_keys)
            print(f"[{branch}] Recovered interrupted CSV/metadata write from the complete embedding.", flush=True)
        print(f"[{branch}] Reusing complete compatible result: {final_path}", flush=True)
        return final_path

    # This invocation will create a new completed result transaction.
    (output_dir / "completion.json").unlink(missing_ok=True)

    # GPU dependencies are imported only here, after the CLI device is selected.
    try:
        import cupy as cp
        import cupyx.scipy.sparse as cpsp
        import rapids_singlecell as rsc
    except ImportError as exc:
        raise ImportError("08S GPU analysis requires CuPy and rapids-singlecell in this Jupyter environment. "
                          "No CPU backend is substituted. Use the working RAPIDS environment from 08M/08O.") from exc
    if int(gpu_device) < 0 or int(gpu_device) >= cp.cuda.runtime.getDeviceCount():
        raise ValueError(f"GPU logical device {gpu_device} is not available to this process.")

    metadata = {"engine_version": ENGINE_VERSION, "branch": branch, "status": "running",
                "started_utc": datetime.now(timezone.utc).isoformat(), "settings": cfg,
                "pca_settings": pca_settings, "source": source, "versions": versions,
                "input_cache_id": str(manifest["cache_id"]),
                "input_cache_dir": str(cache_dir), "feature_matrix_path": str(matrix_path),
                "gpu_logical_device": int(gpu_device),
                "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES", "not set"),
                "n_cells": n_cells, "n_genes": n_genes, "n_pcs_used": n_pcs,
                "sample_counts": obs["sample_id"].value_counts().to_dict(),
                "pca_fingerprint": pca_fp, "harmony_fingerprint": harmony_fp,
                "graph_fingerprint": graph_fp, "final_fingerprint": final_fp,
                "interpretation": "Fixed gene feature weighting, not corrected transcript counts. "
                                  "Marker review must use original counts/unweighted normalized expression.",
                "api_calls": {}, "reused_checkpoints": [], "stages": {}}
    var = features.set_index("gene").copy()
    var.index = pd.Index(var.index.astype(str), name="gene")
    # The reusable unweighted control is independent of the proposed curve.
    # All weight columns in its embedding therefore describe applied ones.
    var["weight"] = weights
    var["applied_distance_weight"] = weights
    var["applied_column_multiplier"] = np.sqrt(weights)
    if "variance_log1p" in var:
        var["weighted_variance"] = pd.to_numeric(var["variance_log1p"], errors="raise").to_numpy() * weights
    elif "weighted_variance" in var:
        # Without the unweighted variance there is no safe way to reinterpret
        # a proposed-curve value for the reusable unweighted control.
        var = var.drop(columns="weighted_variance")

    with cp.cuda.Device(int(gpu_device)):
        properties = cp.cuda.runtime.getDeviceProperties(int(gpu_device))
        name = properties.get("name", "unknown")
        metadata["gpu_name"] = name.decode() if isinstance(name, bytes) else str(name)
        free, total = cp.cuda.runtime.memGetInfo()
        metadata["device_free_bytes_at_start"] = int(free)
        metadata["device_total_bytes"] = int(total)
        metadata["actual_cupy_version"] = cp.__version__
        metadata["actual_rapids_singlecell_version"] = getattr(rsc, "__version__", "unknown")
        logger = _StageLogger(cp, gpu_device, metadata, output_dir)
        logger.checkpoint()
        print(f"[{branch}] {n_cells:,} cells × {n_genes:,} genes on {metadata['gpu_name']}; "
              f"{free / 2**30:.2f} GiB currently free. All cells retained.", flush=True)
        analysis = None
        try:
            pca_path = output_dir / "pca_checkpoint.npz"
            if resume and _valid_checkpoint(pca_path, pca_fp, required_keys=(
                    "scores", "loadings", "mean", "variance", "variance_ratio")):
                pca = _load_npz(pca_path)
                metadata["reused_checkpoints"].append("pca")
                print(f"[{branch}] Reusing shared-PCA checkpoint.", flush=True)
            else:
                with logger.stage("load_and_transfer_features"):
                    matrix = _prepare_csr(sp.load_npz(matrix_path))
                    if matrix.shape != (n_cells, n_genes):
                        raise ValueError("Sparse matrix shape changed after input validation.")
                    metadata["input_nnz"] = int(matrix.nnz)
                    metadata["input_csr_bytes"] = int(matrix.data.nbytes + matrix.indices.nbytes + matrix.indptr.nbytes)
                    width = min(n_pcs + cfg["pca_oversamples"], n_genes, n_cells - 1)
                    # Estimate includes sparse input/copy and several thin QR arrays;
                    # this is informative, not a claimed exact allocation bound.
                    estimated = 3 * metadata["input_csr_bytes"] + 7 * n_cells * width * 4 + 8 * n_genes * width * 4
                    metadata["pca_working_memory_estimate_bytes"] = int(estimated)
                    print(f"[{branch}] CSR {metadata['input_csr_bytes'] / 2**30:.2f} GiB; "
                          f"PCA working estimate {estimated / 2**30:.2f} GiB (workspace estimate).", flush=True)
                    gpu_matrix = cpsp.csr_matrix(matrix)
                    del matrix
                with logger.stage("centered_randomized_gpu_pca"):
                    computed = randomized_pca_operator(gpu_matrix, n_pcs, weights, xp=cp,
                                                      n_oversamples=cfg["pca_oversamples"],
                                                      n_iter=cfg["pca_power_iter"], random_state=cfg["random_state"])
                    pca = {key: np.asarray(_to_host(value, cp)) for key, value in computed.items()}
                    del computed, gpu_matrix
                    gc.collect()
                atomic_npz(pca_path, fingerprint=np.array(pca_fp), **pca)
            _assert_coordinates(pca["scores"], (n_cells, n_pcs), "PCA scores")
            _assert_coordinates(pca["loadings"], (n_genes, n_pcs), "PCA loadings")
            metadata["pca_explained_variance_ratio_sum"] = float(np.sum(pca["variance_ratio"]))
            analysis = ad.AnnData(X=None, obs=obs.copy(), var=var.copy())
            analysis.obsm["X_pca"] = pca["scores"].astype(np.float32, copy=False)
            analysis.varm["PCs"] = pca["loadings"].astype(np.float32, copy=False)
            analysis.var["pca_feature_mean"] = pca["mean"].astype(np.float32, copy=False)
            analysis.uns["pca"] = {"variance": pca["variance"], "variance_ratio": pca["variance_ratio"],
                                    "params": pca_settings}
            del pca

            harmony_path = output_dir / "harmony_checkpoint.npz"
            if resume and _valid_checkpoint(harmony_path, harmony_fp):
                corrected = _load_npz(harmony_path)["scores"]
                metadata["reused_checkpoints"].append("harmony")
                print(f"[{branch}] Reusing Harmony checkpoint.", flush=True)
            elif obs["sample_id"].nunique() < 2:
                corrected = analysis.obsm["X_pca"].copy()
                metadata["harmony_note"] = "Only one sample is present; Harmony is an identity operation."
                atomic_npz(harmony_path, fingerprint=np.array(harmony_fp), scores=corrected)
            else:
                if (np.linalg.norm(analysis.obsm["X_pca"], axis=1) <= 1e-12).any():
                    raise ValueError("Some cells have zero-norm PCA coordinates. Inspect feature information before Harmony; no cells were dropped.")
                kwargs = _harmony_kwargs(rsc.pp.harmony_integrate, cfg, n_cells)
                metadata["api_calls"]["harmony"] = _jsonable(kwargs)
                with logger.stage("gpu_harmony"):
                    rsc.pp.harmony_integrate(analysis, **kwargs)
                    corrected = np.asarray(_to_host(analysis.obsm["X_pca_harmony"], cp), dtype=np.float32)
                atomic_npz(harmony_path, fingerprint=np.array(harmony_fp), scores=corrected)
            _assert_coordinates(corrected, (n_cells, n_pcs), "Harmony coordinates")
            analysis.obsm["X_pca_harmony"] = corrected

            graph_path = output_dir / "graph_checkpoint.h5ad"
            if resume and _valid_embedding(graph_path, graph_fp, ad, n_cells, n_genes,
                                            source["cell_ids_sha256"], source["gene_ids_sha256"], "graph", n_pcs=n_pcs):
                analysis = ad.read_h5ad(graph_path)
                metadata["reused_checkpoints"].append("graph")
                print(f"[{branch}] Reusing neighbor graph checkpoint.", flush=True)
            else:
                algorithm = cfg["neighbors_algorithm"]
                if algorithm == "cagra" and n_cells <= 128:
                    raise ValueError("For a tiny (<129-cell) validation dataset, explicitly set neighbors_algorithm='brute'. "
                                     "The all-cell production run uses CAGRA.")
                kwargs = _required_kwargs(rsc.pp.neighbors, {
                    "n_neighbors": min(cfg["n_neighbors"], n_cells - 1), "n_pcs": n_pcs,
                    "use_rep": "X_pca_harmony", "algorithm": algorithm,
                    "metric": "euclidean", "key_added": "neighbors",
                })
                if "method" in _signature(rsc.pp.neighbors):
                    kwargs["method"] = "umap"
                kwargs.update(_seed_kw(rsc.pp.neighbors, cfg["random_state"]))
                metadata["api_calls"]["neighbors"] = kwargs
                with logger.stage("gpu_neighbors"):
                    rsc.pp.neighbors(analysis, **kwargs)
                analysis = _cpu_adata(analysis, cp)
                analysis.uns["08s_fingerprint"] = graph_fp
                analysis.uns["08s_stage"] = "graph"
                _atomic_h5ad(analysis, graph_path)

            labels = {}
            for resolution in cfg["resolutions"]:
                key = f"leiden_{resolution:g}"
                label_path = output_dir / (key + "_checkpoint.npz")
                label_fp = _fingerprint({"graph": graph_fp, "resolution": resolution,
                    "n_iterations": cfg["leiden_n_iterations"], "seed": cfg["random_state"]})
                if resume and _valid_checkpoint(label_path, label_fp, required_keys=("codes", "categories")):
                    saved_labels = _load_npz(label_path)
                    codes = np.asarray(saved_labels["codes"], dtype=np.int32)
                    categories = np.asarray(saved_labels["categories"], dtype=str)
                    if (codes.shape != (n_cells,) or (codes < 0).any()
                            or len(categories) == 0 or int(codes.max()) >= len(categories)):
                        raise ValueError(f"Invalid saved clustering checkpoint: {label_path}.")
                    analysis.obs[key] = pd.Categorical.from_codes(codes, categories=categories)
                    if "uns_json" in saved_labels:
                        analysis.uns[key] = json.loads(str(saved_labels["uns_json"].item()))
                    labels[key] = int(analysis.obs[key].nunique())
                    metadata["reused_checkpoints"].append(key)
                    print(f"[{branch}] Reusing {key}: {labels[key]} clusters.", flush=True)
                    continue
                kwargs = _required_kwargs(rsc.tl.leiden, {
                    "resolution": resolution, "key_added": key,
                    "n_iterations": cfg["leiden_n_iterations"],
                    "use_weights": True, "neighbors_key": "neighbors",
                })
                if "use_dask" in _signature(rsc.tl.leiden):
                    kwargs["use_dask"] = False
                kwargs.update(_seed_kw(rsc.tl.leiden, cfg["random_state"]))
                metadata["api_calls"][key] = kwargs
                with logger.stage("gpu_" + key):
                    rsc.tl.leiden(analysis, **kwargs)
                categorical = pd.Categorical(analysis.obs[key])
                if (categorical.codes < 0).any():
                    raise ValueError(f"Missing cluster assignment in {key}.")
                atomic_npz(label_path, fingerprint=np.array(label_fp),
                           codes=np.asarray(categorical.codes, dtype=np.int32),
                           categories=np.asarray(categorical.categories, dtype=str),
                           uns_json=np.array(json.dumps(_jsonable(_to_host(analysis.uns.get(key, {}), cp)))))
                labels[key] = int(analysis.obs[key].nunique())
                print(f"[{branch}] {key}: {labels[key]} clusters", flush=True)
            metadata["cluster_counts"] = labels

            kwargs = _required_kwargs(rsc.tl.umap, {
                "min_dist": cfg["umap_min_dist"], "spread": cfg["umap_spread"],
                "init_pos": "random", "neighbors_key": "neighbors",
                "maxiter": cfg["umap_maxiter"],
            })
            if "key_added" in _signature(rsc.tl.umap):
                kwargs["key_added"] = "X_umap"
            kwargs.update(_seed_kw(rsc.tl.umap, cfg["random_state"]))
            metadata["api_calls"]["umap"] = kwargs
            with logger.stage("gpu_umap"):
                rsc.tl.umap(analysis, **kwargs)
            # Some releases/presets use 'umap' when no explicit key is available.
            if "X_umap" not in analysis.obsm and "umap" in analysis.obsm:
                analysis.obsm["X_umap"] = analysis.obsm["umap"]
            analysis = _cpu_adata(analysis, cp)
            _assert_coordinates(analysis.obsm["X_umap"], (n_cells, 2), "UMAP")
            for key in labels:
                if analysis.obs[key].isna().any():
                    raise ValueError(f"Missing cluster assignment in {key}.")
            analysis.uns["08s_fingerprint"] = final_fp
            analysis.uns["08s_stage"] = "complete"
            analysis.uns["08s_branch"] = branch
            analysis.uns["08s_interpretation"] = metadata["interpretation"]
            analysis.uns["08s_metadata_json"] = json.dumps(_jsonable(metadata), sort_keys=True)
            with logger.stage("save_results"):
                _atomic_h5ad(analysis, final_path)
                # CSV is a convenient small return item; expression is not duplicated.
                _write_assignments(analysis, output_dir, labels)
            metadata["status"] = "complete"
            metadata["completed_utc"] = datetime.now(timezone.utc).isoformat()
            metadata["embedding_path"] = str(final_path)
            logger.checkpoint()
            _completion_receipt(output_dir, final_fp)
            print(f"[{branch}] Complete: {final_path}", flush=True)
            return final_path
        except BaseException as exc:
            metadata["status"] = "interrupted" if isinstance(exc, (KeyboardInterrupt, TimeoutError)) else "failed"
            metadata["error"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
            logger.checkpoint()
            raise
        finally:
            analysis = None
            gc.collect()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-dir")
    parser.add_argument("--output-dir")
    parser.add_argument("--branch", choices=["unweighted", "weighted"])
    parser.add_argument("--gpu-device", type=int, default=0)
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--settings-json")
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args(argv)
    if args.preflight_only:
        print(json.dumps(preflight_gpu(args.gpu_device), sort_keys=True), flush=True)
        return
    if not args.cache_dir or not args.output_dir or not args.branch:
        parser.error("--cache-dir, --output-dir, and --branch are required unless --preflight-only is used.")
    settings = None
    if args.settings_json:
        settings = json.loads(Path(args.settings_json).read_text(encoding="utf-8"))
    run_gpu_branch(args.cache_dir, args.output_dir, branch=args.branch,
                   gpu_device=args.gpu_device, settings=settings, resume=not args.no_resume)


if __name__ == "__main__":
    main()
