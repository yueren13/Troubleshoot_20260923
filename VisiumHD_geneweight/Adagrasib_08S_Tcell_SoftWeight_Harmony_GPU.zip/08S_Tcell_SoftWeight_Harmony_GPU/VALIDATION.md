# 08S validation record

Build date: 2026-11-10. This record separates implemented behavior, local checks and on-instance verification.

## Completed local checks

The core independent synthetic test suite passed **23 tests**. These cover:

- Recovery of the actual prior 08O pointer/configuration contract, including sparse CSR and CSC count storage.
- Full-source library-size normalization and deliberate avoidance of the previously processed `X` matrix.
- Restoration of eligible genes excluded by earlier HVG/ratio masks, shuffled gene-ratio alignment, and retention of every source cell.
- Validation of counts, source library sizes, required metadata, population scope, analysis identity and gene ratios.
- Source-file immutability, source-change rejection, complete cache reuse and reuse of normalized arrays after changing the weight curve.
- Numerically stable exclusion of a truly constant normalized gene.
- Agreement of ordered cell/gene hashes across modules.
- Centered weighted sparse randomized-PCA mathematics, compared with exact dense SVD on small examples using the same operator with NumPy/SciPy.
- Completed-output validation and recovery of an interrupted metadata/assignments write.
- CUDA visibility mapping and legacy/current Harmony keyword compatibility.

The marker module was exercised separately with synthetic sparse counts, two methods, three resolutions, a deliberately unavailable marker and enough clusters to test pagination. Original-expression means and observed detection fractions were checked numerically, and incorrect row alignment was rejected. Generated plots were inspected visually. These synthetic outputs are excluded from the delivered package.

The notebook is validated as nbformat v4, and every code cell is syntax-compiled. Its embedded helper files are matched by hash to the readable delivered modules. The standalone bootstrap is checked in an isolated temporary folder so the notebook does not depend on the neighboring source copies.

## What remains to be verified on the instance

The build environment has **no CUDA device, CuPy or RAPIDS execution environment**. Therefore the full GPU pipeline, compatibility with the user's exact installed stack, real biological separation and runtime on the g5.24xlarge have not been measured here.

The notebook starts by running a **192-observation synthetic GPU check** through the actual installed PCA, Harmony, neighbors, Leiden and UMAP APIs. This occurs before the large biological H5AD is read. Production CAGRA is checked for API availability, while the tiny arithmetic check uses brute neighbors because of small-input constraints. Runtime versions, actual API arguments, timings and device memory observations are recorded in each real run.

## Interpretation limits

The ratio weights are fixed feature priorities rather than estimated clean transcript counts. The pooled T-compartment ratios are not a per-cell decontamination model. The marker-concordance diagnostics are descriptive and are not independent label validation. No real-data improvement or runtime guarantee is claimed by the local checks.
