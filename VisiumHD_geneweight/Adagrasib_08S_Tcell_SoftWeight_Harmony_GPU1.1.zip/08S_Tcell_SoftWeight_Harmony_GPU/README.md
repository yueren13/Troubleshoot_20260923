# 08S: T-cell soft gene weighting with GPU PCA and Harmony

Project: **Adagrasib_mouse_project_VisiumHD_2026**  
Release: 1.0.1 · 2026-11-10

This notebook tests whether smooth gene weighting improves CD4/CD8/Treg-associated structure in the complete, previously analyzed T cell 1 + T cell 2 population. It makes a matched comparison of unweighted and ratio-weighted features through GPU PCA, Harmony, neighbor graphs, Leiden clustering and UMAP, followed by original-expression marker review.

## Run it

1. Place `08S_Tcell_SoftWeight_Harmony_GPU.ipynb` in the original project folder used by 08O/08Q, or a subfolder of it. The notebook is standalone; it contains the three helper modules.
2. Select the working RAPIDS GPU Python kernel used for your previous GPU analysis.
3. Leave `PROJECT_DIR = Path.cwd()` and `WEIGHT_MIDPOINT = 0.75` unchanged for the first test and choose **Run All**. If discovery fails, set `PROJECT_DIR` to the folder containing `ct26_analysis_config.json` and `inputs/pipeline_config.json`. You may also point it to the 08O output folder containing `08O_latest_result.json`.
4. Inspect the plots and complete HTML report linked at the end.
5. Return the generated **08S_return_to_chat.zip** for joint review. It is capped at approximately 25 MB of selected files before compression and excludes the large expression and embedding matrices.

The existing default project location is tried only when the setup uses the current working folder. An explicitly supplied alternative path is respected. The notebook prints the exact input and output paths before reading large data.

## Startup diagnostics update

The attached error01 notebook saved successful helper setup and input-path discovery, then stopped at the GPU preflight cell. It contained no saved Python exception, traceback, stderr, or later biological-analysis output. That snapshot locates the interruption but does not identify the underlying GPU failure.

Release 1.0.1 corrects the startup reporting: child stdout/stderr are written directly to a persistent log and shown while the child is running. Each package import and GPU stage prints START/OK or FAILED, quiet stages receive a 15-second status update, and timeout/interruption cleanup preserves the output. The startup time allowance is 600 seconds instead of 180 seconds; the longer ceiling allows initial imports/compilation without implying that a timeout caused the reported incident.

If startup stops, its notebook cell links **08S_preflight_diagnostics.zip**. This contains preflight.log and preflight_report.json, including the failed stage, versions when available, exit status and captured traceback. It contains no biological matrices. Return that ZIP to diagnose the actual failure. A direct hard kill of the entire notebook process can prevent the final ZIP from being created; the running log and initial status report are still written under 08S_diagnostics/.

The source-count preparation, weighting, GPU numerical settings and cache fingerprints are unchanged. Use the same project folder and GPU kernel, and run the updated notebook from the top. The prior 08O analysis does not need to be rerun.

## Inputs

The workflow follows the completed `08O_latest_result.json`. It reads the associated H5AD's sparse `layers['counts']`, original cell metadata, `ratio_filter_in_analysis.csv`, and matching `complete.json` receipt. Every input cell must have the existing population label `T cell 1` or `T cell 2`. The analysis uses all cells in that completed subset, with no additional cell subsampling for PCA, integration, clustering or marker statistics.

The ratio table already summarizes non-T environmental expression relative to T-cell expression. This pilot reuses that **pooled T-compartment vector** and applies the same vector to every T cell. It does not recalculate per-cell or per-sample contamination fractions.

## What differs between the matched analyses

Let `r` be the existing neighbor-to-T gene ratio. The default distance weight is:

`w = 1 / (1 + (r / 0.75)**2)`

The normalized feature is `log1p(10000 * count / original_full_source_library_size)`. The weighted branch multiplies each feature by `sqrt(w)` and centers it implicitly for PCA. The control uses weights of one. There is no subsequent per-gene unit-variance scaling. The weights express feature importance; they are not corrected molecule counts.

The same broad gene set is used in both branches. Genes must be detected in at least 20 cells and have nonzero normalized variance. Previous HVG and ratio-pass masks are ignored. Missing or invalid ratios for eligible genes produce an explicit error. Original counts and preexisting global annotations remain available unchanged.

| Parameter | Default |
|---|---|
| Weight midpoint / exponent | 0.75 / 2 |
| PCA | 50 PCs, centered sparse randomized GPU PCA |
| Randomized PCA accuracy | 20 extra dimensions, 3 power iterations |
| Harmony | Shared PCA, sample_id, theta 1.0, original Harmony flavor |
| Harmony limits | 100 internal clusters, 10 outer and 20 inner iterations |
| Graph | CAGRA on GPU, 30 neighbors |
| Leiden | 0.2, 0.4, 0.6 |
| UMAP | GPU, 200 iterations, minimum distance 0.3 |
| Seed | 0 |
| Display only | At most 120,000 identical display cells in both UMAPs |
| Main review | Resolution 0.4, with lineage dotplots at every resolution |

All samples enter one joint PCA per branch. Harmony corrects the shared representation for `sample_id`; condition is retained for review. The workflow does not concatenate independently fitted sample PCA axes.

## GPU and time behavior

A small 192-observation synthetic check exercises GPU PCA, Harmony, a tiny neighbor graph, Leiden and UMAP before the biological matrix is read. It is an environment check, not a reduced biological pilot. It uses brute neighbors solely for the tiny check; production uses CAGRA.

The first two visible GPUs run the matched branches concurrently in fresh processes. With only one visible GPU they run sequentially. Each branch uses one card; VRAM is not combined across cards. The sparse gene matrix, thin PCA working arrays and shared PC coordinates avoid a full dense cell-by-gene allocation. Preparation, file I/O and marker reports use CPU memory. CUDA visibility restrictions from your environment are respected.

The GPU stage has a 100-minute wall-clock budget. Preparation, review and exports take additional time; the 1–2 hour goal is not a measured guarantee. The parent notebook supervises only its own child processes. PCA, Harmony, graphs and each Leiden resolution have checkpoints. If interrupted, rerun the same notebook settings to resume completed work. A time limit during an unfinished GPU stage can require that stage to rerun.

For a second curve test, change only `WEIGHT_MIDPOINT` to `0.60` and Run All. Compatible normalized arrays and the unweighted control are reused. A smaller midpoint downweights environmental genes more strongly. The curve and full audit are displayed before analysis. There is no automatic search for a resolution that forces the desired biological labels.

## Marker and technical review

Dot color is mean **original, unweighted log1p expression**, including zeros. Dot size is the fraction with **original counts greater than zero**. Both branches share color limits. Missing genes are reported as unavailable. All clusters appear in paginated dotplots, even if the run fragments strongly.

Panels include:

- T lineage: Cd3d, Cd3e, Trac, Trbc1/2.
- CD4/CD8 transcripts: Cd4, Cd8a, Cd8b1.
- Treg-associated: Foxp3, Il2ra, Ctla4, Ikzf2, Tnfrsf18, Icos.
- Naive/memory, cytotoxic, activation/dysfunction and cycling programs.
- NK-associated and other lineage/environmental markers.

The report also provides sample/condition/count/detected-gene UMAPs, condition-stratified cluster views, marker co-occurrence, by-sample and within-sample depth-stratified marker summaries, cluster sizes and small-cluster fractions. Descriptive marker-evidence concordance is not independent classification accuracy: the evidence groups are incomplete and some constituent genes also contribute to the PCA. T-cell state markers can overlap between lineages, and absent transcripts are not definitive biological absence.

Assess whether weighting produces separate CD4- and CD8-associated groups with T-lineage support, a coherent Foxp3-supported Treg-like pattern, less concentration of all markers into one count-rich group, and support across samples and depth strata. A prettier UMAP or higher marker purity alone is insufficient.

## Output locations and return file

Results are written under the current run's `18_tcell_soft_weight_harmony` folder. A versioned cache contains the sparse normalized features, feature audit and compact original marker matrices. Each branch produces a lightweight `embedding.h5ad` (no duplicated expression assay), `cluster_assignments.csv.gz`, metadata and checkpoints. A shared unweighted-control folder allows reuse across curves.

The review contains `review.html`, all figure PNGs, `method_comparison.csv`, `cluster_summary.csv`, full marker statistics, sample/condition composition and depth-stratified tables. The notebook copies the complete review and the return ZIP into `08S_results/<run ID>/` under its working folder for convenient Jupyter links.

`08S_return_to_chat.zip` contains selected small diagnostics. Omitted files are listed in `PACKAGE_CONTENTS.json`; the complete local report remains available. You do not need to upload the original H5AD or large cell metadata table.

## Scope for the eventual all-cell project

This experiment is the T-cell feasibility test. A useful result would support designing sample-aware, lineage-specific weights for the wider dataset. This T-centric vector should be interpreted within the T-cell compartment; an all-lineage extension needs corresponding compartment definitions and a shared integration strategy.

## Included files

- `08S_Tcell_SoftWeight_Harmony_GPU.ipynb`: standalone notebook, with helper source embedded.
- `tcell_weighted_workflow.py`: input discovery, sparse preparation, launching and compact return package.
- `tcell_weighted_gpu.py`: GPU PCA, Harmony, graph, clustering, UMAP and checkpoints.
- `tcell_weighted_review.py`: original-expression markers, technical summaries and HTML review.
- `VALIDATION.md`: checks performed and their limits.
- `MANIFEST.json`: exact source and file hashes.

## References

- Halko, Martinsson and Tropp, randomized matrix decompositions: https://arxiv.org/abs/0909.4061
- RAPIDS Harmony integration: https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.harmony_integrate.html
- RAPIDS neighbors: https://rapids-singlecell.scverse.org/en/stable/api/generated/rapids_singlecell.pp.neighbors.html
- SAM, the inspiration for feature-weighted manifold analysis: https://github.com/atarashansky/self-assembling-manifold

The HTML report and review module contain additional primary sources for the mouse T-cell marker programs.
