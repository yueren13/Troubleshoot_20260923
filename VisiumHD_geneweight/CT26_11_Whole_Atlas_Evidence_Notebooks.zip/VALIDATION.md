# Validation of whole-atlas evidence workflow

Final synthetic 12-mouse run passed the following checks. All inputs and results were synthetic and are not claims about the CT26 study. The final test built 78 indexed figures and 443 indexed datasets using selected fixture plots/settings, not the entire production-scale plot count.

- PASS: 09A cache receipts, 16/9/20 hierarchy, partition counts, source identities and reopen
- PASS: All-gene leaf sums conserved, absent subtype and duplicate raw symbols
- PASS: All population input preparation; pooled sums exact; missing subtype library untestable
- PASS: Simulated saved result fixture: LRT profiles, Wald boards, full gene/test summaries
- PASS: Six composition partitions, exact mouse-level test resolution
- PASS: Simulated sccomp forest labels and diagnostic flags
- PASS: Actual chunked HDF5 candidate scan; pooled detection/log expression match direct counts
- PASS: Moran/Geary direct formulas; constant field NA
- PASS: All-population architecture and absent target NA; matched-mouse figures
- PASS: Exact cumulative/ring counts, pooled lineages, self exclusion, colocated distinct cells
- PASS: Whole-cohort 20-anchor neighborhood cache and treatment/sample boards
- PASS: Offline release, linked figure/table IDs, dataset checksums, ZIP integrity, no raw objects, source bytes unchanged; JS syntax
- PASS: Small catalogue and selected question packet: full linked data copied, original hashes preserved, explicit figure/byte budget refusal
- PASS: Derived input mutation rejected; original restored and atlas reopens

## Scope limits

- Synthetic only; actual R/DESeq2/sccomp/CmdStan not run.
- Actual CSR-HDF5 and CSV source routes tested; no real Parquet or CT26.
- R fit outputs simulated explicitly for plot/export contracts; no inferential validation.
- Small grids and low dpi fixture plots; no server-scale performance benchmark.
- JavaScript syntax checked, browser interaction not exercised.
- No actual production result archive has been generated. 11G creates it on the analysis server.
- Visual inspection of synthetic matched-mouse fraction board, LRT pattern heatmap and neighborhood board; adjusted the treatment-label layout, then reran the full synthetic suite.
- R runner is the existing tested-on-user-server DESeq2 backend adapted for this input contract and the repaired sccomp backend; no local R execution possible. No new package install or GitHub writes.

Run optional local synthetic tests with `python tests/test_atlas_synthetic.py` from this package. The test uses a fresh temporary folder unless CT26_ATLAS_TEST_DIR is provided.
