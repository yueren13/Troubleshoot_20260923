"""Synthetic CPU checks; R output fixtures are not computed biological results."""
from pathlib import Path
import sys,tempfile,os,json,re,shutil,subprocess
import numpy as np,pandas as pd,h5py,scipy.sparse as sp
from scipy.spatial.distance import cdist
import matplotlib;matplotlib.use('Agg')
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P))
from ct26_atlas import core as ac,models,composition as cp,markers as mk,architecture as ar,neighborhoods as nb,patterns,export
root=Path(os.environ.get('CT26_ATLAS_TEST_DIR',tempfile.mkdtemp(prefix='ct26_atlas_')));root.mkdir(parents=True,exist_ok=True);checks=[]
def ok(x):checks.append(x);print('PASS:',x,flush=True)
def h5frame(g,df):
 g.attrs['_index']='_index';g.attrs['encoding-type']='dataframe'
 for k,v in [('_index',df.index.astype(str)),*[(k,df[k]) for k in df]]:
  v=np.asarray(v)
  if v.dtype.kind in 'OU':g.create_dataset(k,data=v.astype(object),dtype=h5py.string_dtype())
  else:g.create_dataset(k,data=v)
rng=np.random.default_rng(19);genes=sorted([f'Leaf{i:02d}_gene{j:02d}' for i in range(16) for j in range(6)]+[f'Common{j:03d}' for j in range(60)]);truth={};sources=[];spec=[];project=root/'synthetic_09A';project.mkdir(exist_ok=True)
for i,cond in enumerate(np.repeat(ac.CONDITIONS,3)):
 sample=f'SIM{i:02d}';p=project/'sample_cache'/sample;p.mkdir(parents=True,exist_ok=True)
 counts=np.full(16,12)
 if i==0:counts[-1]=0
 labels=np.array([g for g,n in zip(ac.LEAVES,counts) for _ in range(n)]+['']*4,object);n=len(labels);xy=rng.uniform(0,350,(n,2));xy[1]=xy[0]
 symbols=genes.copy()+[genes[0]];C=rng.poisson(2,(n,len(symbols))).astype(np.int64);C[rng.random(C.shape)<.3]=0
 for j,g in enumerate(ac.LEAVES):
  ix=[k for k,x in enumerate(symbols) if x.startswith(f'Leaf{j:02d}_')];C[np.ix_(labels==g,ix)]+=rng.poisson(35,(int((labels==g).sum()),len(ix)))
 ids=[f'{sample}_c{j:04d}' for j in range(n)];raw=root/(sample+'_raw.h5ad')
 with h5py.File(raw,'w') as f:
  h5frame(f.create_group('obs'),pd.DataFrame(index=ids));h5frame(f.create_group('var'),pd.DataFrame({'gene_symbol':symbols},index=[f'F{j}' for j in range(len(symbols))]));x=sp.csr_matrix(C);g=f.create_group('X');g.attrs.update({'encoding-type':'csr_matrix','shape':x.shape})
  for name,a in [('data',x.data),('indices',x.indices),('indptr',x.indptr)]:g.create_dataset(name,data=a)
 a=pd.DataFrame(dict(source_cell_id=ids,sample=sample,preliminary_annotation=labels,centroid_x=xy[:,0],centroid_y=xy[:,1],raw_total_counts=C.sum(axis=1),is_in_scvi_graph=labels!=''));ann=root/(sample+'_ann.csv');a.sample(frac=1,random_state=3).to_csv(ann,index=False)
 row=dict(sample=sample,unit=sample,condition=cond,raw_h5ad=str(raw),matrix_key='X',annotation_file=str(ann),gene_table='',gene_symbol_column='gene_symbol',cell_id_column='source_cell_id',sample_column='sample',label_column='preliminary_annotation',total_counts_column='raw_total_counts',coordinates_to_um=1.0)
 sources.append(row);spec.append(dict(row=row,files={k:ac.signature(row[k]) for k in ['raw_h5ad','annotation_file']}));truth[sample]=(C,symbols,labels,xy)
 # 09A-format fixture sufficient statistics, built from direct dense truth.
 obs=list(dict.fromkeys(ac.TUMOR+[x for x in ac.LEAVES if (labels==x).any()]));pb=np.zeros((len(obs),len(genes)),np.int64);nc=np.array([(labels==g).sum() for g in obs],np.int64)
 for j,g in enumerate(obs):
  for z,gene in enumerate(genes):pb[j,z]=C[labels==g][:,[a for a,s in enumerate(symbols) if s==gene]].sum()
 np.savez_compressed(p/'allgene_compartment_sums.npz',counts=pb,n_cells=nc,all_source_totals=pb.sum(axis=1),populations=np.array(obs),genes=np.array(genes),present=np.ones(len(genes),bool))
 pd.DataFrame(dict(source_cell_id=ids,population=labels,x_um=xy[:,0],y_um=xy[:,1],in_reviewed_annotation=labels!='')).to_csv(p/'full_reference_coordinates.csv.gz',index=False)
 ac.save_json(dict(project_id='SIMULATED_09A_ONLY',summary=dict(n_full_cells=n,n_reviewed=int((labels!='').sum())),outputs={f.name:dict(size=f.stat().st_size,sha256=ac.sha(f)) for f in p.iterdir() if f.name!='complete.json'}),p/'complete.json')
pd.DataFrame(sources).to_csv(project/'source_manifest.csv',index=False);ac.save_json(dict(project_id='SIMULATED_09A_ONLY',genes=genes),project/'project.json');ac.save_json(dict(samples=spec),project/'project_spec.json')
original={str(p):ac.sha(p) for p in project.rglob('*') if p.is_file()};original.update({str(p):ac.sha(p) for p in root.glob('*_raw.h5ad')});original.update({str(p):ac.sha(p) for p in root.glob('*_ann.csv')})
atlas=ac.open_atlas(project);atlas=ac.reopen_atlas(atlas['out'])
assert len(ac.LINEAGES)==9 and len(ac.LEAVES)==16 and len(ac.POPS)==20
assert np.array_equal(atlas['N'].sum(axis=1),atlas['coverage'].n_reviewed)
for sample,g in atlas['counts'].groupby('sample'):assert g.loc[g.is_lineage,'n_cells'].sum()==g.n_reviewed.iloc[0]==g.loc[g.is_leaf,'n_cells'].sum()
ok('09A cache receipts, 16/9/20 hierarchy, partition counts, source identities and reopen')
for i,(sample,(C,S,L,XY)) in enumerate(truth.items()):
 for j,g in enumerate(ac.LEAVES):np.testing.assert_array_equal([C[L==g][:,[a for a,v in enumerate(S) if v==gene]].sum() for gene in genes],atlas['C'][i,j])
ok('All-gene leaf sums conserved, absent subtype and duplicate raw symbols')
ms=dict(min_cells=5,min_library_counts=10,min_gene_count=1,min_gene_units=3,min_tested_genes=50)
inp,manifest=models.prepare(atlas,ms);assert len(manifest)==20;assert manifest.set_index('population').loc['Tumor cell 5','status']=='not_testable'
counts=pd.read_csv(inp/ac.slug('All T cell')/'counts.tsv.gz',sep='\t',index_col=0);meta=pd.read_csv(inp/ac.slug('All T cell')/'coldata.tsv',sep='\t');v,_=ac.group_arrays(atlas,['All T cell']);t=pd.DataFrame(v[:,0].T,index=genes,columns=atlas['sources']['sample']);np.testing.assert_array_equal(counts.to_numpy(),t.loc[counts.index,meta['sample']].to_numpy())
ok('All population input preparation; pooled sums exact; missing subtype library untestable')
# Simulated result-format tables, not actual R fits.
model=ac.stage(atlas,'expression',dict(model={**models.DEFAULT_MODEL,**ms},input_id=inp.name,versions={'DESeq2':'SIMULATED_NOT_R'}));statuses=[]
for pop in ac.POPS:
 p=model/ac.slug(pop);p.mkdir(exist_ok=True);status='complete' if pop in ['All T cell','All tumor cell'] else 'not_testable';statuses.append(dict(population=pop,directory=str(p),n_eligible_units=12,n_genes=len(genes),status=status,detail='SIMULATED_FIXTURE_ONLY'))
 if status!='complete':continue
 meta=pd.read_csv(inp/ac.slug(pop)/'coldata.tsv',sep='\t');meta.to_csv(p/'fitted_library_metadata.csv',index=False);libs=meta.library_id.tolist();v=rng.normal(8,1,(len(genes),len(libs)));v[:20]+=np.repeat([0,1,2,3],3);V=pd.DataFrame(v,index=genes,columns=libs);V.index.name='gene';V.to_csv(p/'vst_expression.tsv.gz',sep='\t');(2**V).to_csv(p/'normalized_counts.tsv.gz',sep='\t')
 pd.DataFrame(dict(library_id=libs,size_factor=1.,library_counts=1000)).to_csv(p/'size_factors.csv',index=False);pd.DataFrame(dict(gene=genes,baseMean=20.,dispersion=.1)).to_csv(p/'gene_fit_diagnostics.csv',index=False);pd.DataFrame(dict(gene=genes,AntiPD1_vs_Vehicle_log2FC=0.,Adagrasib_vs_Vehicle_log2FC=0.,Combination_vs_Vehicle_log2FC=0.)).to_csv(p/'Vehicle_baseline_effect_profiles.tsv.gz',sep='\t',index=False)
 idx=[]
 for a,b in ac.PAIRS:
  test=f'{a}_vs_{b}';f=pd.DataFrame(dict(gene=genes,baseMean=20.,stat=rng.normal(0,2,len(genes)),pvalue=.02,padj=.04,log2FoldChange=rng.normal(0,1,len(genes)),lfcSE=.5,lfc_shrunken=rng.normal(0,.5,len(genes)),lfcSE_shrunken=.3));f.to_csv(p/(test+'.tsv.gz'),sep='\t',index=False);idx.append(dict(family='wald_pairwise',test_id=test,numerator=a,denominator=b,df=1,file=test+'.tsv.gz'))
 for test,family,df in [('LRT_any_condition','lrt_omnibus',3),('LRT_PD1_by_Adagrasib','lrt_interaction',1),('Interaction_difference_of_differences','wald_interaction',1)]:
  f=pd.DataFrame(dict(gene=genes,baseMean=20.,stat=10.,pvalue=.02,padj=np.r_[np.full(20,.01),np.full(len(genes)-20,.5)]));f.to_csv(p/(test+'.tsv.gz'),sep='\t',index=False);idx.append(dict(family=family,test_id=test,numerator='',denominator='',df=df,file=test+'.tsv.gz'))
 pd.DataFrame(idx).to_csv(p/'result_index.csv',index=False);ac.save_json(dict(status='SIMULATED'),p/'complete_R.json');ac.save_json(dict(model_id='SIMULATED',hashes={f.name:ac.sha(f) for f in p.iterdir()}),p/'complete.json')
pd.DataFrame(statuses).to_csv(model/'fit_status.csv',index=False);ac.register(atlas,'expression',model);models.summarize(atlas,model);models.plot_wald_boards(model,dpi=65);pr,ps=patterns.run(atlas,model,dict(dpi=65,n_patterns=3,populations=ac.POPS));assert ps.status.eq('complete').sum()==2
z=pd.read_csv(pr/ac.slug('All T cell')/'condition_mean_zscores.csv',index_col=0);np.testing.assert_allclose(z.mean(axis=1),0,atol=1e-9);np.testing.assert_allclose(z.std(axis=1,ddof=0),1,atol=1e-9)
ok('Simulated saved result fixture: LRT profiles, Wald boards, full gene/test summaries')
comp,st,con=cp.run(atlas,None,run_sccomp=False,run_exact_tests=True,exchangeability_note='Synthetic exchangeable fixture only',dpi=65);tab=pd.read_csv(comp/'all_model_denominators.csv');assert tab.model.nunique()==6
for (modelname,sample),g in tab.groupby(['model','sample']):assert g['count'].sum()==g.denominator.iloc[0] and np.isclose(g.fraction.sum(),1)
pv=pd.read_csv(comp/'exploratory_exact_mouse_fraction_tests.csv');assert pv.pvalue.dropna().ge(.1-1e-10).all()
ok('Six composition partitions, exact mouse-level test resolution')
p=comp/'major_lineages';rows=[]
for a,b in ac.PAIRS:
 for i,g in enumerate(ac.LINEAGES):rows.append(dict(cell_group=g,parameter=f'condition{a} - condition{b}',c_effect=i*.02-.1,c_lower=-.2,c_upper=.2,c_pH0=.01,c_FDR=.02 if i==0 else .5,model='major_lineages',diagnostic_status='REVIEW_CONVERGENCE',effect_threshold=.1))
f=pd.DataFrame(rows);f.to_csv(p/'contrasts.csv',index=False);f.to_csv(comp/'all_sccomp_contrasts.csv',index=False);f[f.c_FDR<.05].to_csv(comp/'cFDR_pass.csv',index=False);f.to_csv(p/'parameter_estimates.csv',index=False);pd.DataFrame({'contrast':[f'condition{a} - condition{b}' for a,b in ac.PAIRS]}).to_csv(p/'contrast_expression_audit.csv',index=False);ac.save_json(dict(status='REVIEW_CONVERGENCE',effect_threshold=.1),p/'complete_R.json');ac.save_json(dict(job_id='SIMULATED',hashes={name:ac.sha(p/name) for name in ['contrasts.csv','parameter_estimates.csv','contrast_expression_audit.csv','complete_R.json']}),p/'fit_receipt.json');st.loc[st.model=='major_lineages','status']='REVIEW_CONVERGENCE';st.to_csv(comp/'sccomp_fit_summary.csv',index=False);cp.forest(f,p,'major_lineages','REVIEW_CONVERGENCE',65)
ok('Simulated sccomp forest labels and diagnostic flags')
mr,mst=mk.run(atlas,dict(min_cells=5,min_informative_mice=6,min_log2cpm_difference=.1,min_consistency=.65,min_cpm=1,candidates_per_target=10,min_detection=.05,chunk_cells=23,top_ns=[5],dpi=65));assert len(mst)>0
obs=pd.read_csv(mr/'candidate_observed_expression_all_samples.csv.gz');row=obs[(obs['sample']=='SIM03')&(obs.population=='All T cell')].iloc[0];C,S,L,XY=truth['SIM03'];mask=np.isin(L,ac.HIERARCHY['All T cell']);raw=C[mask][:,[i for i,g in enumerate(S) if g==row.gene]].sum(axis=1);np.testing.assert_allclose(row.fraction_detected,(raw>0).mean());np.testing.assert_allclose(row.mean_log1p,np.log1p(raw*10000/C[mask].sum(axis=1)).mean())
ok('Actual chunked HDF5 candidate scan; pooled detection/log expression match direct counts')
mask=np.ones((4,5),bool);y=rng.normal(size=mask.sum());edge=ar.raster_edges(mask);I,G=ar.moran_geary(y,edge);W=np.zeros((len(y),len(y)));W[edge]=1;W[(edge[1],edge[0])]=1;z=y-y.mean();np.testing.assert_allclose(I,len(y)/W.sum()*(z@W@z)/(z@z));np.testing.assert_allclose(G,(len(y)-1)/(2*W.sum())*(W*(y[:,None]-y[None,:])**2).sum()/(z@z));assert np.isnan(ar.moran_geary(np.ones(len(y)),edge)[0])
ok('Moran/Geary direct formulas; constant field NA')
a,at=ar.run(atlas,dict(grid_sizes_um=[25.],min_full_cells=1,min_reviewed_cells=1,min_reviewed_fraction=.3,thresholds=[0.,.1],min_group_cells=1,autocorrelation_permutations=2,ripley_permutations=2,ripley_radii_um=[50.,100.],min_overlap_fraction=0.,min_points_for_ripley=2,populations=ac.POPS));assert len(at['autocorrelation'])==240;assert len(at['patch_summary'])==480
assert at['patch_summary'].loc[(at['patch_summary']['sample']=='SIM00')&(at['patch_summary'].population=='Tumor cell 5'),'n_patches'].isna().all();ar.plot(atlas,a,at,dict(grid_um=25.,fraction_threshold=.1,populations=['All T cell','All tumor cell'],dpi=65))
ok('All-population architecture and absent target NA; matched-mouse figures')
ns={**nb.DEFAULTS,'workers':1,'chunk_centers':1000};ref=ac.read_reference(project,'SIM03');f=nb.sample_metrics(ref,ns);xy=ref[['x_um','y_um']].to_numpy();label=ref.population.fillna('Unassigned').to_numpy();mask=np.isin(label,ac.HIERARCHY['All T cell']);d=cdist(xy[mask],xy);near=d<=100;near[np.arange(mask.sum()),np.flatnonzero(mask)]=False;expected=near[:,np.isin(label,ac.HIERARCHY['All Macrophage'])].sum(axis=1)
q=f[(f.population=='All T cell')&(f.neighbor_type=='All Macrophage')&(f.neighbor_view=='lineage')&(f.denominator=='all_reviewed')&(f['mode']=='cumulative')&(f.outer_radius_um==100)].iloc[0];np.testing.assert_allclose(q.mean_neighbors_per_center,expected.mean())
for k,g in f.groupby(['population','neighbor_type','neighbor_view','denominator']):assert g.loc[g['mode']=='annulus','total_neighbor_pairs'].sum()==g.loc[(g['mode']=='cumulative')&(g.outer_radius_um==200),'total_neighbor_pairs'].iloc[0]
ok('Exact cumulative/ring counts, pooled lineages, self exclusion, colocated distinct cells')
nroot,nt,nm=nb.run(atlas,dict(workers=1,chunk_centers=1000));nb.plot(atlas,nroot,nt,dict(dpi=65,populations=['All T cell','All tumor cell'],modes=['annulus'],neighbor_views=['lineage'],denominators=['all_reviewed']))
ok('Whole-cohort 20-anchor neighborhood cache and treatment/sample boards')
release,archive=export.build(atlas,max_total_mib=500,make_zip=True,require_all_stages=True);e=[json.loads(x) for x in (release/'evidence_index.jsonl').read_text().splitlines()];datasets=[json.loads(x) for x in (release/'dataset_index.jsonl').read_text().splitlines()];export.validate_release(release,e,datasets)
assert not list(release.rglob('*.h5ad')) and not list(release.rglob('*.rds')) and not list(release.rglob('*full_reference_coordinates*'));assert all(ac.sha(p)==v for p,v in original.items());assert any(x['plot_kind']=='composition_sccomp' and x['status']=='REVIEW_CONVERGENCE' for x in e)
assert all((release/x).is_file() for f in e for x in f['data_paths']);import zipfile
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
js=re.findall(r'<script>(.*?)</script>',(release/'index.html').read_text(),re.S)[-1];(root/'portal.js').write_text(js)
if shutil.which('node'):subprocess.run(['node','--check',str(root/'portal.js')],check=True)
ok('Offline release, linked figure/table IDs, dataset checksums, ZIP integrity, no raw objects, source bytes unchanged; JS syntax')
report=dict(n_checks=len(checks),checks=checks,n_figures=len(e),n_datasets=len(datasets),root=str(root),release=str(release),limitations=['Synthetic only; actual R/DESeq2/sccomp/CmdStan not run.','Actual CSR-HDF5 and CSV source routes tested; no real Parquet or CT26.','R fit outputs simulated explicitly for plot/export contracts; no inferential validation.','Small grids and low dpi fixture plots; no server-scale performance benchmark.','JavaScript syntax checked, browser interaction not exercised.'])
ac.save_json(report,root/'validation_report.json');print('ALL PASSED',len(checks),root,flush=True)
