"""Small replot/query examples for a frozen evidence release. No raw or R data needed.
Run from the extracted release or import and supply a root. Writes only a new example folder.
"""
from pathlib import Path
import json
import pandas as pd
import numpy as np


def find_figures(root,chapter=None,population=None,query=None):
    root=Path(root);rows=[json.loads(line) for line in (root/'evidence_index.jsonl').read_text().splitlines() if line.strip()]
    return pd.DataFrame([x for x in rows if (chapter is None or x['chapter']==chapter) and (population is None or x['population']==population) and (query is None or query.casefold() in json.dumps(x).casefold())])


def composition(root,model='major_lineages',group='All Macrophage'):
    root=Path(root);x=pd.read_csv(root/'data/composition/all_model_denominators.csv');x=x[(x.model==model)&(x.cell_group==group)]
    c=pd.read_csv(root/'data/composition/all_sccomp_contrasts.csv');c=c[(c.model==model)&(c.cell_group==group)]
    return x,c


def neighborhood(root,population='Tumor cell 3',radius=100,inner=50):
    x=pd.read_csv(Path(root)/'data/spatial/neighborhoods/all_sample_neighborhoods.csv.gz')
    return x[(x.population==population)&(x['mode']=='annulus')&(x.outer_radius_um==radius)&(x.inner_radius_um==inner)&(x.neighbor_view=='lineage')&(x.denominator=='outside_anchor_lineage')]


def pooled_raw_counts(root,lineage):
    root=Path(root);mapping=pd.read_csv(root/'data/study/hierarchy.csv');leaves=mapping.loc[mapping.lineage==lineage,'population'].tolist()
    if not leaves:raise ValueError('Unknown lineage')
    data=pd.read_csv(root/'data/study/leaf_pseudobulk_counts.tsv.gz',sep='\t');avail=pd.read_csv(root/'data/study/gene_source_availability.tsv.gz',sep='\t').set_index('gene')
    counts=data[data.population.isin(leaves)].drop(columns='population').groupby('gene').sum();return counts.where(avail.reindex(index=counts.index,columns=counts.columns))


def plot_mouse_fractions(root,model='major_lineages',group='All Macrophage',out=None):
    import matplotlib.pyplot as plt
    root=Path(root);x,_=composition(root,model,group);order=pd.read_csv(root/'data/study/treatment_order.csv').sort_values('order');fig,ax=plt.subplots(figsize=(7,5))
    for i,c in enumerate(order.condition):
        d=x[x.condition==c].dropna(subset=['fraction']);v=d.fraction.to_numpy()
        if len(v):
            ax.scatter(i+np.linspace(-.1,.1,len(v)),v,c='black');ax.plot([i-.2,i+.2],[v.mean(),v.mean()],c='C0')
    ax.set_xticks(range(4),order.display_name,rotation=25,ha='right');ax.set(ylabel='Observed cell fraction',title=group+' | '+model);fig.tight_layout()
    if out is not None:fig.savefig(out,dpi=300)
    return fig
