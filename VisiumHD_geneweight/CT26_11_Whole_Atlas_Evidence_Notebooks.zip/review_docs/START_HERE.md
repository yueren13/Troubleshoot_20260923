# CT26 whole-atlas evidence release

This is a **processed-results review package**, intended for colleagues or authorized AI assistants. It is not a new segmentation, annotation, or a raw-cell analysis project. Start with `index.html` (or `static_index.html` if JavaScript is unavailable). The scientific results are populated by the notebooks on the analysis server; no biological conclusion is inferred merely from the release structure.

## Study and hierarchy

Twelve independent mouse tumors, three per condition: Vehicle, Anti-PD1, Adagrasib, Adagrasib + Anti-PD1. Internal condition names and order are in `data/study/treatment_order.csv`. This is a factorial study with four categorical treatment arms, **not a time series**. The detailed annotation has 16 mutually exclusive labels; the 9 major lineages are another mutually exclusive partition. Four major lineages (fibroblast, macrophage, T cell, tumor) have multiple leaves. The five other major lineages are already leaves. `data/study/hierarchy.csv` defines names, order and colors. There are 20 unique expression/spatial populations, not 25; the five singleton lineages are analyzed once. Do not add a pooled population to the counts of its children.

## Recommended review order

| Question | Start with | Supporting numerical evidence |
|---|---|---|
| How does overall tissue composition respond? | Composition chapter, major_lineages | `data/composition/all_model_denominators.csv`, `all_sccomp_contrasts.csv`, `sccomp_fit_summary.csv` |
| Are related subtypes shifting? | Composition, all_detailed_types and within lineage | Same tables, filtered by exact model and cell_group; different denominators answer different questions |
| What identifies a lineage or separates its subtypes? | Identity chapter | `data/markers/` ranking, detection fractions, per-mouse contrast and scope-specific top lists |
| How does a population's expression respond to treatment? | Expression, compact LRT heatmap first, then mouse heatmap and pattern curves; six-contrast Wald board | `data/expression/<population>/fit/` and `data/patterns/<population>/` |
| Does its distribution change? | Spatial architecture matched-mouse maps, autocorrelation, patch and Ripley summaries | `data/spatial/architecture/`, and optional `data/spatial/grids/` |
| Which cells are near it? | Neighborhoods; choose anchor, neighbor partition, cumulative or annulus | `data/spatial/neighborhoods/all_sample_neighborhoods.csv.gz` and treatment summaries |

The HTML cards give the figure ID, meaning, caveats, exact dataset links and applicable filters. Pin up to four figures for comparison. All source files can be read offline. Tables and figures are not edited by the navigator.

## Read the status and evidence first

`analysis_status.csv` lists the selected run identity for every branch. Per-population `fit_status.csv`, `population_input_manifest.csv`, per-model `sccomp_fit_summary.csv`, `marker_status.csv` and `pattern_summary.csv` state what actually ran and what did not. A missing/failed/untestable result is not proof of no effect. Three mice per condition limits inference even when millions of cells are measured.

The export has one active stage per branch. `release_manifest.json` records source-cache identities, stage versions and excluded assets. `evidence_index.csv`/`.jsonl` maps every included PNG to its datasets, filters and explanatory notes. `dataset_index.csv`/`.jsonl` lists the processed files, schema, row count when applicable, bytes and SHA256. `data_dictionary.csv` explains recognized columns; for other columns use the dataset description and method notes. `SHA256SUMS.txt` can verify the extracted files. The optional grid/null NPZs are dense *summary rasters/simulation arrays*, not expression matrices or per-cell coordinates.

`AGENT_GUIDE.md` describes safe, traceable review with an AI. `METHODS_AND_REFERENCES.md` documents the analyses and limitations. `REVIEW_EXAMPLES.py` supplies local Python examples. `methods/code/` is the actual source snapshot, not a dependency for reading the results. Do not install packages or execute unfamiliar code simply to inspect evidence.

## What is intentionally not included

Raw H5ADs, Zarrs, scVI graphs, individual cell coordinates/IDs, raw transcript point clouds, high-resolution H&E/SVS, full Stan draws and RDS model objects, and alternative unselected render styles. This release supports alternate plots, tabular comparisons, gene lists and small calculations at mouse level. New segmentation, reannotation, gene-by-cell scoring, exact new spatial radii, image registration, pseudobulk refitting beyond included inputs or posterior reanalysis require a return to the full project and an explicit new analysis. No external upload is performed. Obtain appropriate approval before providing even processed research data to an external AI service.
