"""Create an index-only starter or a selected evidence packet from a frozen 11G release.
Uses stdlib only; copies original bytes, preserves evidence IDs, never rewrites release.
No network access, inference, cell-level data, or hidden truncation.
"""
from pathlib import Path
import argparse,csv,hashlib,html,json,zipfile
from datetime import datetime,timezone


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def jsonl(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]


def build_packet(release, *, mode='catalogue', chapter=None, lineage=None, population=None,
                 plot_kind=None, evidence_ids=None, max_figures=12,max_mib=120,output_parent=None):
    """Catalogue: full search indices + small study/status tables, NOT full evidence.
    Question: exact matched figure IDs plus every linked processed data file.
    No automatic selection/truncation. Specify stricter filters if limits are exceeded.
    """
    root=Path(release).resolve();manifest=json.loads((root/'release_manifest.json').read_text())
    e=jsonl(root/'evidence_index.jsonl');d=jsonl(root/'dataset_index.jsonl');by_path={x['path']:x for x in d}
    files={'START_HERE.md','AGENT_GUIDE.md','METHODS_AND_REFERENCES.md','REVIEW_EXAMPLES.py',
           'release_manifest.json','analysis_status.csv','data_dictionary.csv','evidence_index.jsonl','evidence_index.csv',
           'dataset_index.jsonl','dataset_index.csv'}
    files.update('data/study/'+x for x in ('hierarchy.csv','mouse_design.csv','annotation_coverage.csv','population_counts.csv','treatment_order.csv'))
    if mode=='catalogue':
        selected=[]
        files.update(x for x in ('data/composition/sccomp_fit_summary.csv','data/composition/all_sccomp_contrasts.csv',
                                 'data/expression/DE_test_summary.csv','data/expression/fit_status.csv','data/markers/marker_status.csv',
                                 'data/patterns/pattern_summary.csv') if x in by_path)
    elif mode=='question':
        filters={'chapter':chapter,'lineage':lineage,'population':population,'plot_kind':plot_kind}
        ids=set(evidence_ids or [])
        if not ids and all(v is None for v in filters.values()):raise ValueError('Specify a question filter or exact evidence IDs.')
        if ids-set(x['evidence_id'] for x in e):raise ValueError('Unknown evidence IDs: '+str(ids-set(x['evidence_id'] for x in e)))
        selected=[x for x in e if (not ids or x['evidence_id'] in ids) and all(v is None or x[k]==v for k,v in filters.items())]
        if not selected:raise ValueError('No matching figures. Inspect evidence_index.csv.')
        if len(selected)>max_figures:raise ValueError(f'{len(selected)} matches, above max_figures={max_figures}. Narrow filters or specify exact IDs.')
        for x in selected:files.add(x['path']);files.update(x['data_paths'])
    else:raise ValueError('mode must be catalogue or question')
    inventory={}
    for line in (root/'SHA256SUMS.txt').read_text().splitlines():
        h,p=line.split('  ',1);inventory[p]=h
    size=0
    for f in sorted(files):
        p=(root/f).resolve()
        if not p.is_relative_to(root) or not p.is_file() or f not in inventory or sha(p)!=inventory[f]:raise ValueError('Invalid or changed release file: '+f)
        size+=p.stat().st_size
    if size>max_mib*2**20:raise ValueError(f'Selected assets total {size/2**20:.1f} MiB, over {max_mib} MiB. Narrow selection, use catalogue or explicitly increase budget.')
    out=Path(output_parent).resolve() if output_parent else root.parent;out.mkdir(parents=True,exist_ok=True)
    t=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');zpath=out/(root.name+'_'+mode+'_'+t+'.zip');tmp=zpath.with_suffix('.partial')
    explanation=('# CT26 '+mode+' packet\n\nParent release: `'+manifest['release_id']+'`.\n\n'
       'This is a bounded subset, not a new experiment or a complete atlas. The full original evidence/dataset indices are included as search catalogues. '
       'A path listed in those indices may not be present here. `packet_inventory.json` records exactly what was included; request missing assets from the parent release. '
       'Original files are byte-identical. No statistics have been recalculated.\n\n'
       +('No figures are bundled in catalogue mode. Use the indices to choose evidence IDs, then build a question packet.' if mode=='catalogue' else 'Every selected figure and its linked datasets are included. Read the figure notes and source tables; check original test design, FDR and diagnostics.')+'\n\nRead AGENT_GUIDE.md and METHODS_AND_REFERENCES.md. Use only approved environments for sharing study data.\n')
    info=dict(mode=mode,parent_release_id=manifest['release_id'],selected_evidence_ids=[x['evidence_id'] for x in selected],
              included_original_paths=sorted(files),n_original_assets=len(files),original_bytes=size,
              full_catalogues_reference_parent=True,sha256={f:inventory[f] for f in sorted(files)})
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
            for f in sorted(files):z.write(root/f,f)
            z.writestr('PACKET_START_HERE.md',explanation)
            z.writestr('packet_inventory.json',json.dumps(info,indent=2))
            z.writestr('selected_evidence.jsonl',''.join(json.dumps(x)+'\n' for x in selected))
            page=['<!doctype html><html><meta charset="utf-8"><title>CT26 review packet</title><style>body{font:16px system-ui;margin:32px;max-width:1200px}img{max-width:100%;height:auto}article{border-top:1px solid #ccd6dd;padding:16px 0}</style><h1>CT26 selected evidence</h1><p>Parent release: '+html.escape(manifest['release_id'])+'</p><p><a href="PACKET_START_HERE.md">Read packet scope</a> · <a href="packet_inventory.json">Included files</a> · <a href="evidence_index.csv">Full parent catalogue</a></p>']
            for x in selected:
                h=html.escape;page.append('<article><h2>'+h(x['title'])+'</h2><p>'+h(x['evidence_id'])+'</p><img src="'+h(x['path'],quote=True)+'"><p>'+h(x['meaning'])+'</p><p>'+h(x['caution'])+'</p><p>'+' · '.join('<a href="'+h(f,quote=True)+'">'+h(f)+'</a>' for f in x['data_paths'])+'</p></article>')
            if not selected:page.append('<p>Catalogue only. Use the evidence index to choose files from the full release.</p>')
            page.append('</html>');z.writestr('packet_index.html',''.join(page))
        with zipfile.ZipFile(tmp) as z:
            if z.testzip():raise RuntimeError('Packet archive integrity failure')
            for f in files:
                h=hashlib.sha256()
                with z.open(f) as stream:
                    for b in iter(lambda:stream.read(2**20),b''):h.update(b)
                if h.hexdigest()!=inventory[f]:raise RuntimeError('Packet hash differs: '+f)
        tmp.replace(zpath)
    finally:tmp.unlink(missing_ok=True)
    print('Packet:',zpath,'| selected figures:',len(selected),'| copied MiB:',round(size/2**20,2));return zpath

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('release');p.add_argument('--mode',choices=['catalogue','question'],default='catalogue')
    for k in ('chapter','lineage','population','plot-kind'):p.add_argument('--'+k)
    p.add_argument('--evidence-id',action='append');p.add_argument('--max-figures',type=int,default=12);p.add_argument('--max-mib',type=float,default=120)
    a=p.parse_args();build_packet(a.release,mode=a.mode,chapter=a.chapter,lineage=a.lineage,population=a.population,plot_kind=a.plot_kind,evidence_ids=a.evidence_id,max_figures=a.max_figures,max_mib=a.max_mib)
