"""Exact sample-isolated centroid neighborhoods. No giant adjacency list, no cross-mouse distances."""
from .core import *
from scipy.spatial import cKDTree
DEFAULTS=dict(radii_um=[50.,100.,200.],workers=8,chunk_centers=50000,populations=POPS,neighbor_views=['lineage','detailed'],denominators=['all_reviewed','outside_anchor_lineage'])

def count_within(tree,points,r,chunk,workers):
    out=np.zeros(len(points),np.int32)
    if tree is not None:
        for a in range(0,len(points),chunk):out[a:a+chunk]=tree.query_ball_point(points[a:a+chunk],r,eps=0,return_length=True,workers=workers)
    return out

def sample_metrics(frame,settings):
    s=settings;xyz=frame[['x_um','y_um']].to_numpy(float);labels=frame.population.astype('string');cats=LEAVES+['Unassigned'];codes=pd.Categorical(labels.fillna('Unassigned'),categories=cats).codes
    if len(xyz)>=np.iinfo(np.int32).max or (codes<0).any() or not np.isfinite(xyz).all() or frame.source_cell_id.duplicated().any():raise ValueError('Invalid physical coordinates/labels or IDs')
    mask=codes<len(LEAVES);pos=xyz[mask];center_codes=codes[mask];n=len(pos);global_counts=np.bincount(codes,minlength=len(cats));global_leaf=global_counts[:-1]
    group_ix={g:[LEAVES.index(t) for t in leaves] for g,leaves in GROUPS.items()};anchor_masks={g:np.isin(center_codes,group_ix[g]) for g in s['populations']}
    trees=[cKDTree(xyz[codes==i]) if np.any(codes==i) else None for i in range(len(cats))];previous=np.zeros((n,len(cats)),np.int32);records=[];lower=0.
    for radius in s['radii_um']:
        current=np.column_stack([count_within(tr,pos,radius,s['chunk_centers'],s['workers']) for tr in trees]);current[np.arange(n),center_codes]-=1
        if (current<0).any() or (current<previous).any():raise AssertionError('Self exclusion/cumulative invariant failed')
        for mode,mat,low in [('cumulative',current,0.),('annulus',current-previous,lower)]:
            allcounts=mat.sum(axis=1,dtype=np.int64);reviewed=mat[:,:-1].sum(axis=1,dtype=np.int64)
            lineage_mat=np.column_stack([mat[:,group_ix[g]].sum(axis=1,dtype=np.int64) for g in LINEAGES])
            for group,am in anchor_masks.items():
                parent=group if group in LINEAGES else PARENT[group];parent_ix=group_ix[parent];nn=int(am.sum());allpairs=int(allcounts[am].sum());reviewpairs=int(reviewed[am].sum())
                for denom in s['denominators']:
                    excluded=set(parent_ix) if denom=='outside_anchor_lineage' else set()
                    di=[i for i in range(len(LEAVES)) if i not in excluded];d=mat[am][:,di].sum(axis=1,dtype=np.int64);active=d>0;total=int(d.sum());globalden=int(global_leaf[di].sum())
                    for view in s['neighbor_views']:
                        names=LEAVES if view=='detailed' else LINEAGES;vmat=mat[:,:-1] if view=='detailed' else lineage_mat
                        for j,neighbor in enumerate(names):
                            ix=group_ix[neighbor]
                            if set(ix)&excluded:continue
                            v=vmat[am,j];vsum=int(v.sum());gf=float(global_leaf[ix].sum()/globalden) if globalden else np.nan;frac=vsum/total if total else np.nan
                            records.append(dict(population=group,lineage=parent,neighbor_type=neighbor,neighbor_view=view,mode=mode,inner_radius_um=low,outer_radius_um=radius,denominator=denom,n_centers=nn,n_centers_with_any_denominator=int(active.sum()),total_neighbor_pairs=vsum,total_eligible_neighbor_pairs=total,mean_neighbors_per_center=vsum/nn if nn else np.nan,fraction_centers_with_type=float((v>0).mean()) if nn else np.nan,pair_weighted_fraction=frac,equal_active_center_fraction=float((v[active]/d[active]).mean()) if active.any() else np.nan,global_denominator_fraction=gf,composition_ratio_to_global=frac/gf if gf>0 else np.nan,mean_all_segmented_neighbors=allpairs/nn if nn else np.nan,reviewed_neighbor_coverage=reviewpairs/allpairs if allpairs else np.nan,status='ok' if total else 'no_eligible_neighbors' if nn else 'no_centers'))
                        # Explicit conservation of the selected neighbor partition.
                        if sum(r['total_neighbor_pairs'] for r in records[-sum(not bool(set(group_ix[x])&excluded) for x in names):])!=total:raise AssertionError('Neighbor view does not conserve eligible pairs')
        previous=current;lower=radius
    return pd.DataFrame(records)

def run(atlas,settings=None):
    s={**DEFAULTS,**(settings or {})};s['radii_um']=sorted(set(map(float,s['radii_um'])))
    if not s['radii_um'] or not np.isfinite(s['radii_um']).all() or min(s['radii_um'])<=0 or s['chunk_centers']<=0 or s['workers']==0 or s['workers']<-1 or not set(s['populations']).issubset(POPS) or not set(s['neighbor_views']).issubset({'lineage','detailed'}) or not set(s['denominators']).issubset({'all_reviewed','outside_anchor_lineage'}):raise ValueError('Invalid neighborhood configuration')
    out=stage(atlas,'neighborhoods',s);cache=out/'sample_cache';cache.mkdir(exist_ok=True);tabs=[]
    for row in atlas['sources'].to_dict('records'):
        file=cache/(slug(row['sample'])+'.csv.gz');done=cache/(slug(row['sample'])+'.json')
        if done.is_file():
            if load_json(done)['sha256']!=sha(file):raise ValueError('Changed completed neighborhood output')
            t=pd.read_csv(file);print('Reusing neighborhoods:',row['sample'],flush=True)
        else:
            print('Exact all-lineage neighborhoods:',row['sample'],flush=True);ref=read_reference(atlas['root'],row['sample']);t=sample_metrics(ref,s)
            for k in ['sample','unit','condition']:t[k]=row[k]
            save_csv(t,file);save_json(dict(sha256=sha(file)),done);del ref;gc.collect()
        tabs.append(t)
    t=pd.concat(tabs,ignore_index=True);save_csv(t,out/'all_sample_neighborhoods.csv.gz')
    keys=['condition','population','lineage','neighbor_type','neighbor_view','mode','inner_radius_um','outer_radius_um','denominator']
    means=t.groupby(keys,sort=False,observed=True).agg(mean_pair_fraction=('pair_weighted_fraction','mean'),sd_pair_fraction=('pair_weighted_fraction','std'),n_mice=('pair_weighted_fraction','count'),mean_neighbors_per_center=('mean_neighbors_per_center','mean'),mean_equal_active_center_fraction=('equal_active_center_fraction','mean'),mean_fraction_centers_with_type=('fraction_centers_with_type','mean'),mean_reviewed_coverage=('reviewed_neighbor_coverage','mean')).reset_index()
    save_csv(means,out/'equal_mouse_treatment_summaries.csv.gz');register(atlas,'neighborhoods',out);return out,t,means

def plot(atlas,root,table,settings=None):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    from matplotlib.ticker import PercentFormatter
    s=dict(dpi=300,populations=POPS,modes=['cumulative','annulus'],neighbor_views=['lineage','detailed'],denominators=['all_reviewed'],value='pair_weighted_fraction');s.update(settings or {})
    if s['value'] not in ['pair_weighted_fraction','equal_active_center_fraction','mean_neighbors_per_center']:raise ValueError('Unsupported plot metric')
    root=Path(root);path=root/'figures'/digest(s)[:12];path.mkdir(parents=True,exist_ok=True);save_json(s,path/'plot_settings.json')
    sample_order=[r for c in CONDITIONS for r in atlas['sources'].loc[atlas['sources'].condition==c,'sample']]
    # One 3-panel board per population, neighbor view, mode, denominator and sample/treatment view.
    for (g,view,mode,den),sub in table.groupby(['population','neighbor_view','mode','denominator'],sort=False):
        if g not in s['populations'] or view not in s['neighbor_views'] or mode not in s['modes'] or den not in s['denominators']:continue
        names=[x for x in (LINEAGES if view=='lineage' else LEAVES) if x in set(sub.neighbor_type)];radii=sorted(sub.outer_radius_um.unique());dest=path/slug(g);dest.mkdir(exist_ok=True)
        for level in ['treatment','sample']:
            by='condition' if level=='treatment' else 'sample';order=CONDITIONS if level=='treatment' else sample_order;n=len(order);width=.52*n;left=1.1;right=3.5;fw=left+width+right;fh=4.1*len(radii)+1.0
            fig=plt.figure(figsize=(fw,fh));handles=[Patch(color=COLORS[x],label=x) for x in names]
            for k,radius in enumerate(radii):
                v=sub[sub.outer_radius_um==radius];m=v.groupby([by,'neighbor_type'])[s['value']].mean().unstack().reindex(index=order,columns=names)
                empty=m.isna().all(axis=1)
                if (~m.notna().all(axis=1)&~empty).any():raise ValueError('Partially missing neighbor partition')
                ax=fig.add_axes([left/fw,(fh-1.25-4.1*k-2.45)/fh,width/fw,2.45/fh]);bottom=np.zeros(n)
                for name in names:
                    a=m[name].fillna(0).to_numpy();ax.bar(np.arange(n),a,bottom=bottom,color=COLORS[name],linewidth=0,width=.68);bottom+=a
                for i in np.flatnonzero(empty):ax.text(i,.5,'NA',transform=ax.get_xaxis_transform(),ha='center')
                ax.set_xlim(-.5,n-.5);ax.set_xticks(range(n),[DISPLAY[c].replace(' + ',' +\n') for c in order] if level=='treatment' else order,rotation=90,fontsize=8)
                if s['value'].endswith('fraction'):ax.set_ylim(0,1.02);ax.yaxis.set_major_formatter(PercentFormatter(1))
                ax.set_ylabel('Fraction' if s['value'].endswith('fraction') else 'Mean count');ax.set_title(f'{mode}: {v.inner_radius_um.iloc[0]:g}–{radius:g} µm',fontsize=10)
                if level=='sample':
                    for i in [2.5,5.5,8.5]:ax.axvline(i,color='.55',ls=':',lw=.6)
            fig.legend(handles=handles,loc='upper left',bbox_to_anchor=((left+width+.25)/fw,.90),frameon=False,fontsize=8)
            fig.suptitle(f'{g} | {view} neighbors | {den}\n{level}: {s["value"]}',fontsize=11);fig.text(.04,.008,'Treatment means give each defined mouse equal weight. Counts are ordered center-neighbor pairs.\nSelf excluded once; overlapping neighborhoods are not independent mice. NA is not zero.',fontsize=8)
            file=dest/f'{view}_{mode}_{den}_{level}.png';fig.savefig(file,dpi=s['dpi'],facecolor='white');plt.close(fig)
    save_json(dict(path=path.relative_to(root).as_posix(),settings=s),root/'active_figures.json');return path
