"""Conservative descriptive specificity using paired-mouse raw pseudobulk, then actual cell detection."""
from .core import *
import scipy.sparse as sp
SCOPES={'major_lineages':LINEAGES,**{'within_'+slug(g):v for g,v in MULTI.items()}}
DEFAULTS=dict(min_cells=30,min_informative_mice=6,min_log2cpm_difference=.5,min_consistency=.70,min_cpm=2.,pseudocount_cpm=.5,candidates_per_target=100,min_detection=.10,exclude_technical_from_top=True,chunk_cells=15000,target_sum=10000.,top_ns=[5,10],dpi=300)

def rank(atlas,s):
    genes=np.array(atlas['genes']);P=atlas['P'].all(axis=0);technical=np.array([bool(re.match(r'^(mt[-_]|Rpl\d|Rps\d|Hba-|Hbb-)',g,re.I)) for g in genes]);frames=[];comparisons=[]
    for scope,groups in SCOPES.items():
        C,N=group_arrays(atlas,groups);tot=C.sum(axis=2);valid=(N>=s['min_cells'])&(tot>0)
        cpm=np.divide(C.astype(float)*1e6,tot[:,:,None],out=np.full(C.shape,np.nan),where=tot[:,:,None]>0);log=np.log2(cpm+s['pseudocount_cpm'])
        for i,g in enumerate(groups):
            effects=[];cons=[];nums=[]
            for j,other in enumerate(groups):
                if i==j:continue
                use=valid[:,i]&valid[:,j];d=log[use,i]-log[use,j];n=int(use.sum());nums.append(n)
                med=np.median(d,axis=0) if n else np.full(len(genes),np.nan);frac=(d>0).mean(axis=0) if n else np.full(len(genes),np.nan)
                effects.append(med);cons.append(frac);comparisons.append(dict(scope=scope,target=g,reference=other,n_paired_mice=n))
            effect=np.min(effects,axis=0);consistent=np.min(cons,axis=0);mean=cpm[valid[:,i],i].mean(axis=0) if valid[:,i].any() else np.full(len(genes),np.nan)
            eligible=P&(min(nums)>=s['min_informative_mice'])&(effect>=s['min_log2cpm_difference'])&(consistent>=s['min_consistency'])&(mean>=s['min_cpm'])
            if s['exclude_technical_from_top']:eligible &= ~technical
            frames.append(pd.DataFrame(dict(scope=scope,population=g,gene=genes,measured_all_samples=P,technical_flag=technical,min_paired_mice=min(nums),min_pairwise_median_log2CPM_difference=effect,min_pairwise_direction_fraction=consistent,mean_target_CPM=mean,eligible=eligible)).sort_values(['eligible','min_pairwise_median_log2CPM_difference','mean_target_CPM','gene'],ascending=[False,False,False,True],kind='stable'))
    ranks=pd.concat(frames,ignore_index=True);candidates=ranks[ranks.eligible].groupby(['scope','population'],sort=False).head(s['candidates_per_target']).copy();return ranks,candidates,pd.DataFrame(comparisons)

def projection(symbols,genes):
    lut={g:i for i,g in enumerate(genes)};rr=[];cc=[]
    for i,g in enumerate(symbols):
        if g in lut:rr.append(i);cc.append(lut[g])
    return sp.csr_matrix((np.ones(len(rr),np.int64),(rr,cc)),shape=(len(symbols),len(genes)))

def measure_sample(row,genes,settings,expected_n,source_spec):
    # Raw read only in this stage; reject changed raw count/annotation/gene sources.
    for k,old in source_spec['files'].items():
        if signature(row[k])!=old:raise RuntimeError('Original 09A raw source changed: '+row['sample']+' '+k)
    with RawReader(row['raw_h5ad'],row['matrix_key']) as raw:
        a=annotation(row,raw);a=a.loc[a.population.notna()].copy();sym=source_symbols(row,raw);available=set(sym);proj=projection(sym,genes)
        code=pd.Categorical(a.population,categories=LEAVES).codes
        if (code<0).any():raise ValueError('Unexpected leaf in raw source')
        n=np.bincount(code,minlength=len(LEAVES));det=np.zeros((len(LEAVES),len(genes)),np.int64);logs=np.zeros_like(det,dtype=float);seen=np.zeros(len(a),bool)
        if not np.array_equal(n,expected_n):raise ValueError('Raw marker selection differs from verified 09A annotation')
        for pos,x in raw.selected(a.index,settings['chunk_cells']):
            x=validate_counts(x);total=np.asarray(x.sum(axis=1)).ravel()
            if (total<=0).any() or not np.allclose(total,a.raw_total_counts.iloc[pos],atol=1e-4,rtol=0):raise ValueError('Raw/QC totals mismatch')
            sub=(x@proj).tocsr();sub.eliminate_zeros();g=sp.csr_matrix((np.ones(len(pos),np.int64),(code[pos],np.arange(len(pos)))),shape=(len(LEAVES),len(pos)))
            detected=sub.copy();detected.data=np.ones_like(detected.data);det+=(g@detected).toarray()
            v=sp.diags(settings['target_sum']/total)@sub.astype(float);v.data=np.log1p(v.data);logs+=(g@v).toarray()
            if seen[pos].any():raise ValueError('Duplicate marker cell reads')
            seen[pos]=True
        if not seen.all():raise ValueError('Missing marker cell reads')
    return n,det,logs,np.array([g in available for g in genes],bool)

def observed_rows(row,genes,n,det,logs,measured):
    rows=[]
    for g,leaves in GROUPS.items():
        ix=[LEAVES.index(x) for x in leaves];N=int(n[ix].sum());d=det[ix].sum(axis=0);l=logs[ix].sum(axis=0)
        rows.append(pd.DataFrame(dict(sample=row['sample'],unit=row['unit'],condition=row['condition'],population=g,gene=genes,n_cells=N,source_present=measured,detected_cells=np.where(measured,d,np.nan),sum_log_normalized=np.where(measured,l,np.nan),fraction_detected=np.where(measured&bool(N),d/max(N,1),np.nan),mean_log1p=np.where(measured&bool(N),l/max(N,1),np.nan))))
    return pd.concat(rows,ignore_index=True)

def run(atlas,settings=None):
    s={**DEFAULTS,**(settings or {})}
    if s['min_cells']<1 or s['min_informative_mice']<1 or s['candidates_per_target']<1 or s['pseudocount_cpm']<=0 or s['target_sum']<=0 or s['chunk_cells']<1 or not 0<=s['min_detection']<=1 or not 0<=s['min_consistency']<=1:raise ValueError('Invalid marker settings')
    out=stage(atlas,'markers',s);ranks,cand,comparisons=rank(atlas,s);save_csv(ranks,out/'all_gene_specificity_ranking.csv.gz');save_csv(cand,out/'candidate_markers.csv');save_csv(comparisons,out/'paired_mouse_availability.csv')
    genes=list(dict.fromkeys(cand.gene));save_json(dict(genes=genes,settings=s),out/'candidate_panel.json')
    if not genes:save_csv(pd.DataFrame([dict(status='no_qualifying_markers')]),out/'marker_status.csv');register(atlas,'markers',out);return out,pd.DataFrame()
    tables=[];cache=out/'sample_cache';cache.mkdir(exist_ok=True)
    for i,row in enumerate(atlas['sources'].to_dict('records')):
        f=cache/(slug(row['sample'])+'.npz');done=cache/(slug(row['sample'])+'.json')
        if done.is_file():
            rec=load_json(done)
            if rec['sha256']!=sha(f):raise ValueError('Marker cache hash mismatch')
            with np.load(f,allow_pickle=False) as z:
                if z['genes'].tolist()!=genes:raise ValueError('Marker gene axis mismatch')
                n,det,logs,p=z['n'],z['det'],z['logs'],z['present']
        else:
            print('Actual cell detection and log-normalized means:',row['sample'],flush=True)
            n,det,logs,p=measure_sample(row,genes,s,atlas['N'][i],atlas['source_spec'][row['sample']]);save_npz(f,n=n,det=det,logs=logs,present=p,genes=np.array(genes));save_json(dict(sha256=sha(f)),done)
        tables.append(observed_rows(row,genes,n,det,logs,p));gc.collect()
    obs=pd.concat(tables,ignore_index=True);save_csv(obs,out/'candidate_observed_expression_all_samples.csv.gz')
    # Pairwise actual within-mouse differences for ranked candidates (preserves true treatment identity).
    contrasts=[]
    for scope,groups in SCOPES.items():
        C,N=group_arrays(atlas,groups);tot=C.sum(axis=2);valid=(N>=s['min_cells'])&(tot>0);log=np.log2(np.divide(C*1e6,tot[:,:,None],out=np.full(C.shape,np.nan),where=tot[:,:,None]>0)+s['pseudocount_cpm']);lut={g:i for i,g in enumerate(atlas['genes'])}
        for i,g in enumerate(groups):
            panel=cand.loc[(cand.scope==scope)&(cand.population==g),'gene'].tolist();ix=[lut[x] for x in panel]
            if not panel:continue
            for j,other in enumerate(groups):
                if i==j:continue
                for k,row in enumerate(atlas['sources'].to_dict('records')):
                    if not (valid[k,i]&valid[k,j]):continue
                    contrasts.append(pd.DataFrame(dict(scope=scope,population=g,reference=other,sample=row['sample'],unit=row['unit'],condition=row['condition'],gene=panel,log2CPM_difference=log[k,i,ix]-log[k,j,ix])))
    if contrasts:save_csv(pd.concat(contrasts,ignore_index=True),out/'candidate_within_mouse_contrasts.csv.gz')
    selection=plots(out,obs,cand,s);save_csv(selection,out/'marker_status.csv');register(atlas,'markers',out);return out,selection

def plots(out,obs,cand,s):
    import matplotlib.pyplot as plt
    from matplotlib.cm import ScalarMappable
    status=[]
    for scope,groups in SCOPES.items():
        p=out/scope;p.mkdir(exist_ok=True)
        data=obs[obs.population.isin(groups)&(obs.n_cells>=s['min_cells'])&obs.source_present].copy()
        # Within lineages, use mice with adequate counts for every sibling for comparable dots.
        # Across 9 lineages use available eligible mice per lineage (rare cell types can lack a complete panel).
        if scope!='major_lineages':
            ok=data[['sample','population']].drop_duplicates().groupby('sample').size();data=data[data['sample'].isin(ok[ok==len(groups)].index)]
        mean=data.groupby(['population','gene'],sort=False).agg(mean_log1p=('mean_log1p','mean'),fraction_detected=('fraction_detected','mean'),n_mice=('mean_log1p','count')).reset_index()
        for top in s['top_ns']:
            selected=[]
            for g in groups:
                c=cand[(cand.scope==scope)&(cand.population==g)].merge(mean[mean.population==g][['gene','fraction_detected','n_mice']],on='gene',how='left',validate='one_to_one')
                c=c[(c.fraction_detected>=s['min_detection'])&(c.n_mice>=s['min_informative_mice'])].head(top);selected.append(c)
                status.append(dict(scope=scope,population=g,top_n=top,n_selected=len(c),status='complete' if len(c) else 'no_qualifying_markers'))
            chosen=pd.concat(selected,ignore_index=True);save_csv(chosen,p/f'top_{top}_markers.csv');genes=list(dict.fromkeys(chosen.gene))
            if not genes:continue
            # One color scale per gene from pooled overview; treatment plots share it, clip at 1 only for display.
            gmax=mean[mean.gene.isin(genes)].groupby('gene').mean_log1p.max()
            for view,groupkeys,keys in [('pooled',['population'],[(g,) for g in groups]),('by_treatment',['condition','population'],[(c,g) for c in CONDITIONS for g in groups])]:
                t=data[data.gene.isin(genes)].groupby(groupkeys+['gene'],sort=False).agg(mean_log1p=('mean_log1p','mean'),fraction_detected=('fraction_detected','mean'),n_mice=('mean_log1p','count')).reset_index();t['relative_color_unclipped']=t.mean_log1p/t.gene.map(gmax).replace(0,np.nan);t['relative_color']=t.relative_color_unclipped.clip(0,1);save_csv(t,p/f'top_{top}_{view}_dotplot_values.csv')
                ti=t.set_index(groupkeys+['gene']);names=[' | '.join(DISPLAY.get(x,x) for x in k) for k in keys]
                for start in range(0,len(genes),45):
                    panel=genes[start:start+45];fig,ax=plt.subplots(figsize=(max(8,.27*len(panel)+4),max(4,.32*len(keys)+2.5)))
                    for a,k in enumerate(keys):
                        subset=ti.reindex(pd.MultiIndex.from_tuples([(*k,gene) for gene in panel],names=ti.index.names))
                        valid=np.isfinite(subset.fraction_detected)&np.isfinite(subset.relative_color)
                        ax.scatter(np.flatnonzero(valid),np.repeat(a,int(valid.sum())),s=180*subset.loc[valid,'fraction_detected'],c=subset.loc[valid,'relative_color'],cmap='viridis',vmin=0,vmax=1,linewidths=.15,edgecolors='black')
                    ax.set_xticks(range(len(panel)),panel,rotation=90,fontsize=8);ax.set_yticks(range(len(keys)),names,fontsize=8);ax.invert_yaxis();ax.set_xlim(-.6,len(panel)-.4)
                    fig.colorbar(ScalarMappable(cmap='viridis',norm=plt.Normalize(0,1)),ax=ax,label='Mean log-normalized expression / pooled gene max',fraction=.03)
                    for f in [.1,.5,1.]:ax.scatter([],[],s=180*f,c='0.5',label=f'{f:.0%} detected')
                    ax.legend(bbox_to_anchor=(1.13,1),loc='upper left',frameon=False,fontsize=8);ax.set_title(f'{scope} | up to {top} markers per type | {view}')
                    fig.text(.02,.015,'Equal-mouse means; missing measurement omitted. Descriptive cluster markers, not independent validation.\nTreatment color values above pooled maximum are clipped; exact values and n mice are exported.',fontsize=8)
                    savefig(fig,p/f'top_{top}_{view}_dotplot_page{start//45+1:02d}.png',s['dpi'])
    return pd.DataFrame(status)
