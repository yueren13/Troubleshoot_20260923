"""Tumor architecture at fixed physical scales. No cell/subtype is a treatment replicate.
Default window is the all-reference occupied raster, not a histological tissue mask.
Moran/Geary use field values on supported adjacent tiles. K is rasterized translation
corrected; conditional random-label envelopes preserve counts and sampling geometry.
"""
from pathlib import Path
import gc
import numpy as np
import pandas as pd
from scipy import ndimage as ndi
from scipy.signal import fftconvolve
from .core import *

def raster_reference(frame,width,max_grid_pixels=3000000):
    xy=frame[['x_um','y_um']].to_numpy(float)
    if width<=0 or not len(xy) or not np.isfinite(xy).all():raise ValueError('Invalid physical raster inputs')
    low=np.floor(xy.min(axis=0)/width)*width
    coords=np.floor((xy-low)/width).astype(np.int64);shape=tuple((coords.max(axis=0)+1)[::-1])
    if np.prod(shape)>max_grid_pixels:raise MemoryError(f'Grid has {np.prod(shape):,} pixels; inspect coordinate units or explicitly increase grid size limit')
    flat=np.ravel_multi_index((coords[:,1],coords[:,0]),shape)
    labels=frame.population.astype('string');reviewed=labels.notna().to_numpy()
    full=np.bincount(flat,minlength=np.prod(shape)).reshape(shape)
    known=np.bincount(flat[reviewed],minlength=np.prod(shape)).reshape(shape)
    groups={g:labels.isin(m).to_numpy() for g,m in GROUPS.items()}
    arrays={g:np.bincount(flat[mask],minlength=np.prod(shape)).reshape(shape) for g,mask in groups.items()}
    return dict(origin=low,width=width,shape=shape,full=full,reviewed=known,groups=arrays)

def get_window(grid,override=None):
    default=grid['full']>0
    if override is None:return default,'all_reference_occupied_tiles_PROXY'
    # A validated tissue footprint override has exactly the same physical grid.
    with np.load(override) as z:
        mask=z['mask'].astype(bool)
        if mask.shape!=grid['shape'] or not np.allclose(z['origin_um'],grid['origin']) or not np.isclose(float(z['pixel_size_um']),grid['width']):raise ValueError('Mask grid/origin/physical scale do not match. No resizing or guessed alignment.')
    if not mask.any():raise ValueError('Empty external observation window')
    return mask,'explicit_registered_mask'

def raster_edges(mask,queen=True):
    labels=np.full(mask.shape,-1,np.int64);labels[mask]=np.arange(mask.sum());a=[];b=[]
    offsets=[(0,1),(1,0)]+([(1,1),(1,-1)] if queen else [])
    h,w=mask.shape
    for dy,dx in offsets:
        yy=slice(max(0,-dy),min(h,h-dy));xx=slice(max(0,-dx),min(w,w-dx))
        y2=slice(max(0,dy),min(h,h+dy));x2=slice(max(0,dx),min(w,w+dx))
        p=labels[yy,xx];q=labels[y2,x2];ok=(p>=0)&(q>=0);a.extend(p[ok]);b.extend(q[ok])
    return np.asarray(a,np.int64),np.asarray(b,np.int64)

def moran_geary(values,edges):
    y=np.asarray(values,float);a,b=edges;n=len(y)
    if len(a)==0 or n<3 or not np.isfinite(y).all():return np.nan,np.nan
    z=y-y.mean();ss=float(z@z)
    if ss<=np.finfo(float).eps*n:return np.nan,np.nan
    # Edges are undirected once; equivalent to symmetric binary W with S0=2*E.
    I=n/len(a)*np.sum(z[a]*z[b])/ss
    C=(n-1)/(2*len(a))*np.sum((y[a]-y[b])**2)/ss
    return float(I),float(C)

def autocorrelation(field,mask,n_permutations,seed,queen=True):
    edges=raster_edges(mask,queen);y=field[mask];I,C=moran_geary(y,edges)
    record=dict(n_tiles=len(y),n_undirected_edges=len(edges[0]),Moran_I=I,Geary_C=C,
                weights='symmetric_binary_queen' if queen else 'symmetric_binary_rook')
    if not np.isfinite(I):return {**record,'status':'constant_field_or_insufficient_neighbors','Moran_p':np.nan,'Geary_p':np.nan},pd.DataFrame()
    rng=np.random.default_rng(seed);null=np.array([moran_geary(rng.permutation(y),edges) for _ in range(n_permutations)])
    if len(null):
        for j,(name,val,expected) in enumerate([('Moran',I,-1/(len(y)-1)),('Geary',C,1.)]):
            record[name+'_p']=(1+np.sum(np.abs(null[:,j]-expected)>=abs(val-expected)-1e-12))/(n_permutations+1)
            record[name+'_null_mean']=float(null[:,j].mean());record[name+'_null_sd']=float(null[:,j].std(ddof=1)) if len(null)>1 else np.nan
    else:record.update(Moran_p=np.nan,Geary_p=np.nan)
    return {**record,'status':'ok'},pd.DataFrame(null,columns=['Moran_I','Geary_C'])

def patch_metrics(counts,denominator,mask,width,threshold,min_group_cells,connectivity=8):
    frac=np.divide(counts,denominator,out=np.full(counts.shape,np.nan),where=denominator>0)
    selected=mask&(denominator>0)&(counts>=min_group_cells)&(frac>=threshold)
    structure=np.ones((3,3),int) if connectivity==8 else ndi.generate_binary_structure(2,1)
    components,n=ndi.label(selected,structure=structure)
    areas=np.bincount(components.ravel(),minlength=n+1)[1:]*width**2
    mass=np.bincount(components.ravel(),weights=counts.ravel(),minlength=n+1)[1:]
    total=int(counts[mask].sum());selected_mass=float(mass.sum())
    # Edge density is defined on the raster mask, not true polygon perimeter.
    horizontal=np.count_nonzero(selected[:,1:]!=selected[:,:-1]);vertical=np.count_nonzero(selected[1:,:]!=selected[:-1,:])
    records=[]
    for k,(area,cellmass) in enumerate(zip(areas,mass),1):records.append(dict(component=k,area_um2=float(area),group_cells=float(cellmass),equivalent_diameter_um=float(2*np.sqrt(area/np.pi))))
    overall=dict(n_patches=int(n),patch_area_um2=float(areas.sum()),observation_area_um2=float(mask.sum()*width**2),
        largest_patch_area_um2=float(areas.max()) if n else 0.,median_patch_area_um2=float(np.median(areas)) if n else np.nan,
        cell_weighted_patch_area_um2=float(np.average(areas,weights=mass)) if n and mass.sum()>0 else np.nan,
        largest_patch_fraction_of_group_cells=float(mass.max()/total) if n and total else 0. if total else np.nan,
        fraction_group_cells_in_patches=selected_mass/total if total else np.nan,
        patches_per_mm2_support=n/(mask.sum()*width**2)*1e6 if mask.any() else np.nan,
        raster_interface_length_per_mm2=(horizontal+vertical)*width/(mask.sum()*width**2)*1e6 if mask.any() else np.nan,
        n_group_cells_in_window=total)
    return overall,pd.DataFrame(records,columns=['component','area_um2','group_cells','equivalent_diameter_um']),components

def translation_setup(mask,width,radii,min_overlap_fraction=.05):
    mask=np.asarray(mask,bool);h,w=mask.shape;area=float(mask.sum()*width**2)
    if not mask.any() or not np.isfinite(width) or width<=0:raise ValueError('Ripley observation window must be nonempty with positive physical pixel size')
    overlaps=np.rint(fftconvolve(mask.astype(float),mask[::-1,::-1].astype(float),mode='full')).astype(np.int64)
    yy,xx=np.indices(overlaps.shape);dist=np.sqrt((yy-(h-1))**2+(xx-(w-1))**2)*width
    # Validity at each radius: overlapping shifts with very small common window are unstable.
    out=[]
    for r in radii:
        if r<2*width:raise ValueError('Rasterized Ripley radii must be >=2 pixels; use a finer grid for smaller distances')
        selected=(dist<=r)&(overlaps>0);minfrac=float(overlaps[selected].min()/mask.sum()) if selected.any() else 0.
        valid=minfrac>=min_overlap_fraction
        out.append(dict(radius_um=float(r),valid=valid,min_overlap_fraction=minfrac,selected=selected))
    return dict(overlap=overlaps,distances=dist,area=area,width=width,mask=mask,metrics=out)

def raster_K(counts,setup):
    x=np.where(setup['mask'],counts,0).astype(np.float64);n=int(x.sum());h,w=x.shape
    corr=np.rint(fftconvolve(x,x[::-1,::-1],mode='full'))
    corr[h-1,w-1]-=n # exclude each point's self-pair once; colocated distinct cells remain.
    corr=np.maximum(corr,0)
    weights=np.divide(corr,setup['overlap']*setup['width']**2,out=np.zeros_like(corr),where=setup['overlap']>0)
    result=[]
    for item in setup['metrics']:
        valid=item['valid'] and n>=2
        K=setup['area']**2/(n*(n-1))*weights[item['selected']].sum() if valid else np.nan
        result.append(dict(radius_um=item['radius_um'],n_points=n,K_um2=float(K),L_minus_r_um=float(np.sqrt(K/np.pi)-item['radius_um']) if valid else np.nan,
            valid=valid,min_window_overlap_fraction=item['min_overlap_fraction'],status='ok' if valid else 'too_few_points_or_unstable_window_overlap'))
    return pd.DataFrame(result)

def random_label_K(counts,background,setup,n_permutations,seed):
    observed=raster_K(counts,setup);mask=setup['mask'];pop=np.asarray(background[mask],np.int64);n=int(counts[mask].sum())
    if n>pop.sum() or np.any(counts[mask]>background[mask]):raise ValueError('Target count exceeds conditional-label background')
    rng=np.random.default_rng(seed);null=[]
    for rep in range(n_permutations):
        sample=rng.multivariate_hypergeometric(pop,n,method='marginals')
        x=np.zeros(mask.shape,np.int64);x[mask]=sample
        null.append(raster_K(x,setup).L_minus_r_um.to_numpy())
    null=np.asarray(null)
    if n_permutations:
        for i,row in observed.iterrows():
            v=null[:,i];v=v[np.isfinite(v)]
            if not len(v):continue
            mean=v.mean();sd=v.std(ddof=1) if len(v)>1 else np.nan
            observed.loc[i,'conditional_null_mean_L_minus_r']=mean
            observed.loc[i,'conditional_null_q025']=np.quantile(v,.025);observed.loc[i,'conditional_null_q975']=np.quantile(v,.975)
            observed.loc[i,'conditional_excess_L_um']=row.L_minus_r_um-mean
            observed.loc[i,'conditional_z']=((row.L_minus_r_um-mean)/sd) if sd>1e-12 else np.nan
            observed.loc[i,'conditional_pointwise_p']=(1+np.sum(np.abs(v-mean)>=abs(row.L_minus_r_um-mean)-1e-12))/(len(v)+1)
    return observed,null


DEFAULTS=dict(grid_sizes_um=[25.,50.],min_full_cells=3,min_reviewed_fraction=.5,min_reviewed_cells=3,
    thresholds=[0.,.1,.3,.5],min_group_cells=2,autocorrelation_permutations=199,ripley_permutations=39,
    ripley_radii_um=[50.,100.,200.],ripley_grid_um=25.,min_overlap_fraction=.05,seed=17,max_grid_pixels=3000000,
    min_points_for_ripley=20,populations=POPS)


def run(atlas,settings=None,mask_overrides=None):
    s={**DEFAULTS,**(settings or {})};overrides=mask_overrides or {}
    if not s['grid_sizes_um'] or min(s['grid_sizes_um'])<=0 or s['ripley_grid_um'] not in s['grid_sizes_um'] or not s['ripley_radii_um'] or min(s['ripley_radii_um'])<2*s['ripley_grid_um']:raise ValueError('Invalid physical grid/radius')
    if any(not 0<=t<=1 for t in s['thresholds']) or s['min_group_cells']<1 or s['min_full_cells']<1 or s['min_reviewed_cells']<1 or not 0<=s['min_reviewed_fraction']<=1:raise ValueError('Invalid tile criteria')
    if s['autocorrelation_permutations']<0 or s['ripley_permutations']<0 or not set(s['populations']).issubset(POPS):raise ValueError('Invalid settings')
    out=stage(atlas,'architecture',dict(architecture=s,mask_overrides={k:signature(v) for k,v in overrides.items()}));combined={k:[] for k in ['autocorrelation','patch_summary','Ripley_raster','coverage','components']}
    for row in atlas['sources'].to_dict('records'):
        sample=row['sample'];folder=out/'sample_cache'/slug(sample);folder.mkdir(parents=True,exist_ok=True);done=folder/'complete.json'
        if done.is_file():
            rec=load_json(done)
            if not all((folder/f).is_file() and sha(folder/f)==h for f,h in rec['hashes'].items()):raise ValueError('Changed architecture cache '+sample)
            for k in combined:combined[k].append(pd.read_csv(folder/(k+'.csv.gz')))
            print('Reusing architecture:',sample,flush=True);continue
        print('Architecture:',sample,flush=True);ref=read_reference(atlas['root'],sample);ar=[];pr=[];rr=[];cv=[];cc=[];identity={k:row[k] for k in ['sample','unit','condition']}
        for width in s['grid_sizes_um']:
            grid=raster_reference(ref,float(width),s['max_grid_pixels']);window,source=get_window(grid,overrides.get(sample+'__'+f'{width:g}'))
            eligible=window&(grid['full']>=s['min_full_cells'])&(grid['reviewed']>=s['min_reviewed_cells'])&(grid['reviewed']/np.maximum(grid['full'],1)>=s['min_reviewed_fraction'])
            cv.append(dict(**identity,grid_um=width,window_source=source,support_area_um2=int(window.sum())*width**2,n_field_tiles=int(eligible.sum()),n_window_tiles=int(window.sum()),n_full_cells_in_window=int(grid['full'][window].sum()),n_full_cells_total=len(ref)))
            for g in s['populations']:
                counts=grid['groups'][g];field=np.divide(counts,grid['reviewed'],out=np.full(counts.shape,np.nan),where=grid['reviewed']>0)
                base=dict(**identity,population=g,grid_um=width,window_source=source,field_denominator='all_reviewed_cells',n_group_cells_total=int(counts.sum()),n_group_cells_supported=int(counts[eligible].sum()))
                autoc,_=autocorrelation(field,eligible,s['autocorrelation_permutations'],s['seed']);ar.append(dict(**base,**autoc))
                for threshold in s['thresholds']:
                    summ,components,_=patch_metrics(counts,grid['reviewed'],eligible,width,threshold,s['min_group_cells'])
                    # An absent population is not a zero-valued biological fragmentation outcome.
                    if not counts[eligible].sum():
                        for k in ['n_patches','patch_area_um2','largest_patch_area_um2','median_patch_area_um2','cell_weighted_patch_area_um2','patches_per_mm2_support','raster_interface_length_per_mm2','largest_patch_fraction_of_group_cells','fraction_group_cells_in_patches']:summ[k]=np.nan
                    pr.append(dict(**base,fraction_threshold=threshold,status='ok' if counts[eligible].sum()>0 else 'no_supported_target_cells',**summ))
                    for k,v in {**identity,'population':g,'grid_um':width,'fraction_threshold':threshold}.items():components[k]=v
                    cc.append(components)
            # Compact sufficient statistics for all spatial fraction/patch maps and alternate threshold replot.
            save_npz(folder/f'grid_{width:g}um.npz',full=grid['full'],reviewed=grid['reviewed'],mask=window,field_mask=eligible,origin_um=grid['origin'],pixel_size_um=np.array(width),**{slug(k):v for k,v in grid['groups'].items()})
            if np.isclose(width,s['ripley_grid_um']):
                setup=translation_setup(window,width,s['ripley_radii_um'],s['min_overlap_fraction'])
                for g in s['populations']:
                    background=grid['reviewed'] if g in LINEAGES else grid['groups'][PARENT[g]];counts=grid['groups'][g];n=int(counts[window].sum())
                    ref_name='all_reviewed_cells' if g in LINEAGES else PARENT[g]
                    if n<s['min_points_for_ripley']:
                        kt=raster_K(counts,setup);kt[['K_um2','L_minus_r_um']]=np.nan;kt['valid']=False;kt['status']='too_few_target_cells_for_ripley';kn=np.empty((0,len(kt)))
                    else:kt,kn=random_label_K(counts,background,setup,s['ripley_permutations'],s['seed'])
                    for k,v in {**identity,'population':g,'grid_um':width,'window_source':source,'conditional_background':ref_name}.items():kt[k]=v
                    rr.append(kt);save_npz(folder/(slug(g)+'_Ripley_null.npz'),null_L_minus_r=kn,radii_um=np.array(s['ripley_radii_um']))
            del grid;gc.collect()
        tabs=dict(autocorrelation=pd.DataFrame(ar),patch_summary=pd.DataFrame(pr),Ripley_raster=pd.concat(rr,ignore_index=True),coverage=pd.DataFrame(cv),components=pd.concat(cc,ignore_index=True))
        for k,t in tabs.items():save_csv(t,folder/(k+'.csv.gz'));combined[k].append(t)
        save_json(dict(hashes={p.name:sha(p) for p in folder.iterdir() if p.suffix in ('.npz','.gz')}),done)
        del ref;gc.collect()
    tables={k:pd.concat(v,ignore_index=True) for k,v in combined.items()}
    for k,t in tables.items():save_csv(t,out/(k+'_all_samples.csv.gz'))
    register(atlas,'architecture',out);return out,tables


def plot(atlas,root,tables,settings=None):
    import matplotlib.pyplot as plt
    from matplotlib.cm import ScalarMappable
    from matplotlib.colors import Normalize
    s=dict(grid_um=50.,fraction_threshold=.1,populations=POPS,dpi=300);s.update(settings or {})
    root=Path(root);arch=load_json(root/'settings.json')['settings']['architecture'];width=s['grid_um'];threshold=s['fraction_threshold']
    if width not in arch['grid_sizes_um'] or threshold not in arch['thresholds']:raise ValueError('Plot settings must match computed grid/threshold; change computation settings explicitly for new metrics')
    path=root/'figures'/digest(s)[:12];path.mkdir(parents=True,exist_ok=True);save_json(s,path/'plot_settings.json')
    for pop in s['populations']:
        if pop not in arch['populations']:raise ValueError('Population was not computed: '+pop)
        dest=path/slug(pop);dest.mkdir(exist_ok=True)
        for kind in ['fraction','patch']:
            fig,axes=plt.subplots(3,4,figsize=(15.8,11.3));fig.subplots_adjust(left=.06,right=.92,bottom=.08,top=.88,wspace=.22,hspace=.35)
            for i,c in enumerate(CONDITIONS):
                samples=atlas['sources'].loc[atlas['sources'].condition==c,'sample'].tolist()
                for j,sample in enumerate(samples):
                    ax=axes[j,i];file=root/'sample_cache'/slug(sample)/f'grid_{width:g}um.npz'
                    with np.load(file,allow_pickle=False) as z:
                        counts=z[slug(pop)];den=z['reviewed'];elig=z['field_mask'];origin=z['origin_um'];h,w=den.shape;extent=[origin[0],origin[0]+w*width,origin[1],origin[1]+h*width]
                        if kind=='fraction':v=np.divide(counts,den,out=np.full(den.shape,np.nan),where=den>0);ax.imshow(np.ma.masked_where(~elig,v),origin='lower',extent=extent,vmin=0,vmax=1,cmap='viridis',interpolation='nearest')
                        else:
                            _,_,labels=patch_metrics(counts,den,elig,width,threshold,arch['min_group_cells']);ax.imshow(np.ma.masked_where(labels==0,labels%20),origin='lower',extent=extent,cmap='tab20',vmin=0,vmax=19,interpolation='nearest')
                        ax.set_title((DISPLAY[c]+'\n' if j==0 else '')+sample+f' | n={counts.sum():,}',fontsize=9);ax.set_aspect('equal');ax.tick_params(labelsize=6)
            if kind=='fraction':fig.colorbar(ScalarMappable(norm=Normalize(0,1),cmap='viridis'),ax=axes.ravel().tolist(),shrink=.65,label='Target fraction among reviewed cells')
            fig.suptitle(f'{pop} | {kind} maps | {width:g} µm tiles'+(f' | fraction ≥ {threshold:g}, ≥ {arch["min_group_cells"]} target cells/tile' if kind=='patch' else ''),fontsize=13)
            fig.text(.04,.025,'Independent tumors, physical Proseg axes (µm), not co-registered H&E. Blank = unsupported or below threshold for patches.\nPatch colors are component IDs modulo palette, not cell types or shared identities. Default window is occupied-cell proxy.',fontsize=9)
            savefig(fig,dest/(kind+'_matched_mice.png'),s['dpi'])
        # One compact panel per summary family (not hundreds of near-duplicate scalar plots).
        for table,key,metrics,title in [('autocorrelation','grid_um',['Moran_I','Geary_C'],'Tile fraction autocorrelation'),('patch_summary','grid_um',['n_patches','largest_patch_fraction_of_group_cells','cell_weighted_patch_area_um2','fraction_group_cells_in_patches'],'Connected raster patches')]:
            f=tables[table];f=f[(f.population==pop)&(f.grid_um==width)]
            if table=='patch_summary':f=f[f.fraction_threshold==threshold]
            fig,axs=plt.subplots(1,len(metrics),figsize=(4.2*len(metrics),5.3),squeeze=False)
            for ax,metric in zip(axs[0],metrics):
                for i,c in enumerate(CONDITIONS):
                    g=f[f.condition==c];v=pd.to_numeric(g[metric],errors='coerce');ok=np.isfinite(v);v=v[ok]
                    if len(v):ax.bar(i,v.mean(),color='#8A9DB4',alpha=.5,width=.65,yerr=v.std(ddof=1) if len(v)>1 else 0,capsize=3);ax.scatter(i+np.linspace(-.12,.12,len(v)),v,s=18,c='black')
                    else:ax.text(i,.5,'NA',transform=ax.get_xaxis_transform(),ha='center',fontsize=8)
                ax.set_xticks(range(4),[DISPLAY[c] for c in CONDITIONS],rotation=65,ha='right',fontsize=8);ax.set_title(metric.replace('_',' '),fontsize=9);ax.spines[['top','right']].set_visible(False)
            fig.suptitle(f'{pop} | {title} | grid {width:g} µm'+(f', threshold {threshold:g}' if table=='patch_summary' else ''));fig.text(.03,.01,'Dots: independent mice. Bars: mean ± SD. Undefined values are omitted and explicitly retained in tables.',fontsize=8);fig.tight_layout(rect=[0,.05,1,.94]);savefig(fig,dest/(table+'_summary.png'),s['dpi'])
        f=tables['Ripley_raster'];f=f[f.population==pop];metrics=['L_minus_r_um','conditional_excess_L_um'];fig,axs=plt.subplots(1,2,figsize=(12,5))
        for ax,metric in zip(axs,metrics):
            if metric not in f:ax.text(.5,.5,'Not calculated',transform=ax.transAxes,ha='center');continue
            for i,c in enumerate(CONDITIONS):
                g=f[f.condition==c]
                for _,u in g.groupby('sample'):ax.plot(u.radius_um,u[metric],color=f'C{i}',alpha=.3,lw=.8)
                mean=g.groupby('radius_um')[metric].mean();ax.plot(mean.index,mean,marker='o',color=f'C{i}',label=DISPLAY[c],lw=2)
            ax.axhline(0,color='0.5',lw=.6);ax.set(xlabel='Radius (µm)',ylabel=metric);ax.legend(frameon=False,fontsize=8)
        fig.suptitle(f'{pop} | rasterized Ripley K/L | random-label background: '+('all reviewed cells' if pop in LINEAGES else PARENT[pop]));fig.text(.04,.01,'Approximation on grid; thin lines are mice. Conditional envelopes/geometry are exploratory, not treatment-replicate tests.',fontsize=8);fig.tight_layout(rect=[0,.04,1,.92]);savefig(fig,dest/'ripley_summary.png',s['dpi'])
    save_json(dict(path=path.relative_to(root).as_posix(),settings=s),root/'active_figures.json');return path
