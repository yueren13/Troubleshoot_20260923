"""Build a controlled shallow-dive release: relative paths, plot/data joins, no raw cell matrices."""
from .core import *
from datetime import datetime,timezone
import html,zipfile,platform,importlib.metadata

NOTES={
 'composition_observed':('Composition, observed','Observed counts or fractions in the stated mutually exclusive partition. Treatment means are means of mice, not cell-weighted pools.','Counts depend on sampled area and segmentation yield; fractions are relative, not absolute tumor mass.'),
 'composition_sccomp':('Composition, sccomp','Native composition-coefficient effects, 95% posterior intervals and c_FDR labels, per contrast.','Check effect threshold, c_pH0/c_FDR scope and Stan diagnostics. Bayesian quantities are not frequentist P values; not percentage-point effects.'),
 'composition_ppc':('Composition, posterior predictive','Posterior predictive check of the fitted sccomp composition model.','Assess observed vs model-predicted distributions; a successful render does not prove convergence or adequate fit.'),
 'wald_board':('Expression, pairwise Wald','Six directional contrasts; x = configured fold-change estimate, y = original adjusted P; display cap marks triangles.','Separate population/test FDR; no new tests or environmental RNA correction. Positive effect means numerator higher.'),
 'lrt_heatmap':('Expression, LRT patterns','Original LRT-significant genes; within-gene standardized four condition-mean VST, or mouse VST using the same center/scale.','Color is expression z-score, not signed LRT effect or significance. Pattern numbers are population-local. Conditions are categorical, not time.'),
 'lrt_curve':('Expression, pattern curves/boxes','Median/IQR curve or distribution across genes assigned to one expression pattern.','Genes in a pattern are not biological replicates; no new treatment test follows from the curve.'),
 'lrt_mouse':('Expression, mouse-level pattern scores','Each mouse score averages standardized expression over the pattern genes. Bars show mean and SD.','Exploratory post-LRT pattern summary. Individual mice, not cells or genes, are the study units.'),
 'marker_dotplot':('Identity, marker dotplots','Dot size: mean observed detection fraction; color: mean per-cell log1p(normalized counts) relative to pooled gene maximum.','Direct descriptive specificity screen. Selection uses same expression-derived labels; not independent validation. Missing dots are not measured zeros.'),
 'fraction_map':('Spatial, fraction map','Fraction of target population among reviewed cells in supported physical tiles; one board, 12 independent mouse tumors.','Same 0–1 color scale, distinct local coordinate systems. Blank is unsupported, not necessarily absent tissue. Not H&E or registered anatomical matches.'),
 'patch_map':('Spatial, patch map','8-connected supported tiles meeting the recorded fraction and minimum target-count criteria. Component ID colors repeat.','Not a histologically validated island; threshold/grid dependent. Blank can mean unsupported or below threshold. Colors do not encode cell types or significance.'),
 'autocorrelation':('Spatial, Moran I / Geary C','Binary symmetric queen-neighbor spatial autocorrelation of target fractions among reviewed cells on supported tiles.','Not direct island size; constant fields undefined. Within-image permutation P values do not test treatment differences.'),
 'patch_summary':('Spatial, patch summaries','Raster patch number, area weighted by target-cell count, largest component cell-mass share, fraction of supported target cells captured.','Patch metrics conditional on support and threshold. A rare population can fail thresholds without being biologically absent.'),
 'ripley':('Spatial, rasterized Ripley','Translation-edge-corrected raster K/L approximation and excess over conditional random labels, at recorded radii.','Major lineage conditional on all reviewed cells; subtype conditional on its own lineage. Window is occupied-cell proxy unless explicitly overridden. Pointwise within-image null, not treatment significance.'),
 'neighborhoods':('Spatial, multiscale neighbors','Ordered center–neighbor pairs, exact centroid radii; cumulative or disjoint rings; leaf or lineage partition, with recorded denominator.','Self excluded exactly once. Overlapping neighborhoods are not replicates. No tissue-edge correction. Mean treatment fractions give each defined mouse equal weight.'),
}
COLUMN_HELP={
 'sample':'Physical sample; exactly one independent mouse tumor here.','unit':'Independent biological unit (mouse).','independent_unit':'Independent biological unit (mouse).','library_id':'DESeq2 library key, unique within population fit. Join to fitted_library_metadata.csv.',
 'condition':'Internal four-condition code; see mouse_design.csv and treatment_order.csv.','population':'Reviewed leaf or lineage pool; see hierarchy.csv. Overlapping levels must not be summed.','lineage':'Parent lineage; singleton lineages have the same leaf name.','cell_group':'Part of the mutually exclusive composition model.','count':'Observed reviewed cells of this part, not transcript count.','denominator':'Eligible cell denominator or its named definition, according to table.','fraction':'Observed count / denominator; blank when denominator is zero.','n_cells':'Number of reviewed cells contributing to the named population.','n_full':'All full-reference segmented cells, including unassigned/excluded.','n_reviewed':'Reviewed cells only.','n_unassigned':'Full-reference cells without reviewed labels.','fraction_reviewed':'Population count / reviewed cells in sample.','fraction_within_lineage':'Leaf count / parent lineage count, NA if parent absent.','gene':'Exact mouse gene symbol; duplicate source features with identical symbol summed.','pvalue':'Original test P value; test-specific meaning in family/test_id. In spatial tables distinguish within-image vs between-mouse tests.','padj':'Original DESeq2 adjusted P value for the population/test; NA is not nonsignificance.','stat':'Original DESeq2 statistic; LRT is unsigned, Wald is signed.','log2FoldChange':'Unshrunken DESeq2 log2 expression effect, numerator over denominator.','lfc_shrunken':'ashr-shrunken log2 fold change; original Wald P values unchanged.','c_effect':'sccomp native composition coefficient contrast; not percentages or DESeq2 LFC.','c_lower':'Posterior 2.5% quantile of composition contrast.','c_upper':'Posterior 97.5% quantile of composition contrast.','c_pH0':'sccomp posterior threshold-based directional error measure, not frequentist P.','c_FDR':'sccomp Bayesian FDR, within contrast and model.','diagnostic_status':'Recorded basic Stan convergence gate. Review diagnostics and PPC even when passed.','status':'Execution/eligibility or measurement status; read stage-specific notes.','grid_um':'Square tile side in micrometers, not a circular radius.','fraction_threshold':'Minimum target fraction among reviewed cells per supported patch tile.','Moran_I':'Moran I of supported tile fractions, symmetric binary adjacency.','Geary_C':'Geary C of supported tile fractions, symmetric binary adjacency.','Moran_p':'Within-image tile-label permutation diagnostic, not treatment significance.','Geary_p':'Within-image tile-label permutation diagnostic, not treatment significance.','K_um2':'Rasterized translation-corrected K approximation (µm²).','L_minus_r_um':'sqrt(K/pi) minus radius, in microns.','conditional_excess_L_um':'Observed L−r minus random-label null mean.','conditional_pointwise_p':'Within-image conditional pointwise permutation diagnostic, not treatment inference.','conditional_background':'Population whose locations are retained during random-label reference.','n_patches':'Number of connected above-threshold raster components. Undefined if target absent in supported tiles.','largest_patch_fraction_of_group_cells':'Target cells in component with most target cells / target cells in supported tiles.','cell_weighted_patch_area_um2':'Component area averaged with target-cell mass as weights.','fraction_group_cells_in_patches':'Target cells captured by selected patch tiles / target cells in supported tiles.','patch_area_um2':'Selected tile area; not cell polygon area.','inner_radius_um':'Inner bound in microns; annuli exclude inner radius except first interval.','outer_radius_um':'Outer inclusive radius in microns.','mode':'Cumulative or nonoverlapping annulus.','neighbor_view':'Mutually exclusive detailed or lineage neighbor partition.','neighbor_type':'Neighbor identity within that partition.','total_neighbor_pairs':'Number of ordered center-to-neighbor pairs of this type.','total_eligible_neighbor_pairs':'All eligible ordered pairs for this anchor/denominator.','n_centers':'Number of reviewed anchor cells in the target group.','mean_neighbors_per_center':'Pair count divided by all anchor cells, including anchors with zero neighbors.','pair_weighted_fraction':'Type pairs / eligible pairs, NA when no eligible pairs.','equal_active_center_fraction':'Mean of per-center proportions across centers with eligible neighbors.','reviewed_neighbor_coverage':'Reviewed neighbor pairs / all segmented neighbor pairs, self excluded.','fraction_detected':'Fraction with positive observed raw gene count.','mean_log1p':'Mean per-cell log1p(count / full raw library × target sum).','relative_color':'Plotted marker color normalized to pooled gene maximum; clipped display only.','min_pairwise_median_log2CPM_difference':'Minimum over all comparator groups of median within-mouse log2(CPM + pseudocount) difference.','min_pairwise_direction_fraction':'Smallest positive-direction fraction among within-mouse competitor comparisons.','pattern':'Population-local expression profile cluster ID.','pattern_score':'Mean standardized expression across genes in one selected pattern for one mouse.','n_mice':'Number of defined mouse measurements used in this summary.'}

STAGES=['expression_inputs','expression','patterns','composition','markers','architecture','neighborhoods']

class Release:
    def __init__(self,root,atlas,max_bytes):
        self.root=Path(root);self.atlas=atlas;self.max_bytes=max_bytes;self.total=0;self.datasets=[];self.evidence=[];self.files={};self.counted=set()
    def _reserve(self,n):
        if self.total+n>self.max_bytes:raise RuntimeError(f'Export exceeds configured {self.max_bytes/2**20:,.0f} MiB budget. Increase explicitly or choose fewer optional assets; no silent truncation.')
        self.total+=n
    def copy(self,src,rel):
        src=Path(src);dest=self.root/rel
        if not src.is_file():raise FileNotFoundError(src)
        if dest.is_file():
            if sha(dest)!=sha(src):raise ValueError('Two different sources claim '+str(rel))
            return rel
        self._reserve(src.stat().st_size);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);return rel
    def generated(self,path):
        path=Path(path);rel=path.relative_to(self.root).as_posix()
        if rel not in self.counted:self._reserve(path.stat().st_size);self.counted.add(rel)
        return rel
    def data(self,src,rel,stage_name,description):
        self.copy(src,rel);self.add_dataset(rel,stage_name,description);return rel
    def add_dataset(self,rel,stage_name,description):
        if rel in {x['path'] for x in self.datasets}:return
        p=self.root/rel;name=p.name;cols=[];n=None
        if name.endswith(('.csv','.csv.gz','.tsv','.tsv.gz')):
            sep='\t' if '.tsv' in name else ',';n=0
            try:
                for chunk in pd.read_csv(p,sep=sep,chunksize=100000,low_memory=False):
                    cols=list(chunk.columns);n+=len(chunk)
            except pd.errors.EmptyDataError:cols=[];n=0
        self.datasets.append(dict(dataset_id='D-'+digest(rel)[:12],path=rel,stage=stage_name,description=description,rows=n,columns=cols,size_bytes=p.stat().st_size,sha256=sha(p)))
    def generated_table(self,frame,rel,stage_name,description,index=False):
        p=self.root/rel;save_csv(frame,p,index);self.generated(p);self.add_dataset(rel,stage_name,description);return rel
    def fig(self,src,rel,chapter,population,kind,data_paths,filters=None,status='available',settings=None):
        if any(not (self.root/p).is_file() for p in data_paths):raise ValueError('Evidence references unavailable dataset: '+str(data_paths))
        self.copy(src,rel);title,meaning,caution=NOTES[kind];fid='F-'+digest(dict(path=rel,chapter=chapter,population=population))[:12]
        parent=population if population in LINEAGES else PARENT.get(population,'Across atlas')
        self.evidence.append(dict(evidence_id=fid,path=rel,title=title+' | '+population+' | '+Path(rel).stem,chapter=chapter,population=population,lineage=parent,plot_kind=kind,meaning=meaning,caution=caution,status=status,data_paths=data_paths,filters=filters or {},settings=settings or {},sha256=sha(self.root/rel)))
    def write_indices(self):
        ev=pd.DataFrame(self.evidence);data=pd.DataFrame(self.datasets)
        for name,rows in [('evidence_index',self.evidence),('dataset_index',self.datasets)]:
            p=self.root/(name+'.jsonl');p.write_text(''.join(json.dumps(jsonable(r),ensure_ascii=False,allow_nan=False)+'\n' for r in rows));self.generated(p)
            table=pd.DataFrame(rows).copy()
            for c in table.columns:
                if table[c].map(lambda x:isinstance(x,(dict,list))).any():table[c]=table[c].map(lambda x:json.dumps(jsonable(x),ensure_ascii=False) if isinstance(x,(dict,list)) else x)
            save_csv(table,self.root/(name+'.csv'));self.generated(self.root/(name+'.csv'))
        dd=[]
        for d in self.datasets:
            for c in d['columns']:dd.append(dict(dataset_id=d['dataset_id'],path=d['path'],column=c,description=COLUMN_HELP.get(c,'See dataset description, method notes and original header; no inferred units.' if c not in CONDITIONS else 'Condition column: '+DISPLAY[c])))
        save_csv(pd.DataFrame(dd),self.root/'data_dictionary.csv');self.generated(self.root/'data_dictionary.csv')


def _rel_settings(data):
    # Internal source locations are not necessary for shared review. Retain content identity/hash.
    if isinstance(data,dict):return {k:_rel_settings(v) for k,v in data.items() if k not in ('environment','stan_cache','cmdstan_path','rscript','executable')}
    if isinstance(data,list):return [_rel_settings(v) for v in data]
    if isinstance(data,str) and data.startswith('/'):return '<source-path-redacted>/'+Path(data).name
    return data


def build(atlas,output_parent=None,include_spatial_grids=True,include_ripley_null=True,make_zip=True,max_total_mib=1200,require_all_stages=True):
    selected={name:registered(atlas,name) for name in STAGES};missing=[k for k,v in selected.items() if v is None]
    if missing and require_all_stages:raise ValueError('Finish missing stages before release, or explicitly allow partial: '+str(missing))
    # A pattern figure set cannot be silently paired with statistics from another fit.
    if selected['patterns'] and selected['expression']:
        pat=load_json(selected['patterns']/'settings.json')['settings']['model']
        if signature(selected['expression']/'fit_status.csv')!=pat:raise ValueError('Pattern results belong to a different fit_status; rerun pattern stage for selected expression model.')
    if selected['expression'] and selected['expression_inputs']:
        wanted=load_json(selected['expression']/'settings.json')['settings']['input_id']
        if wanted!=selected['expression_inputs'].name:raise ValueError('Selected expression-input pointer differs from fitted model. Restore correct pointer or refit.')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');spec=dict(atlas=atlas['out'].name,stages={k:v.name if v else None for k,v in selected.items()},grids=include_spatial_grids,ripley_null=include_ripley_null)
    root=(Path(output_parent) if output_parent else atlas['out']/'releases')/f'CT26_evidence_{stamp}_{digest(spec)[:9]}';root.mkdir(parents=True,exist_ok=False);r=Release(root,atlas,int(max_total_mib*2**20));statuses=[]
    # Shared processed tables and 16 disjoint leaf counts; pooled counts can be exactly reconstructed.
    for f,desc in [('mouse_design.csv','Study design and unit IDs'),('hierarchy.csv','Authoritative leaf to major lineage mapping and colors'),('annotation_coverage.csv','Full-reference, reviewed and unassigned counts per mouse'),('population_counts.csv','All 20 distinct populations; flags separate lineages and detailed leaves')]:r.data(atlas['out']/f,'data/study/'+f,'study',desc)
    r.generated_table(pd.DataFrame({'condition':CONDITIONS,'display_name':[DISPLAY[c] for c in CONDITIONS],'order':range(4)}),'data/study/treatment_order.csv','study','Treatment display order (categorical, not temporal)')
    genes=atlas['genes'];m=atlas['sources'];columns=m['sample'].tolist();counts=[]
    for i,leaf in enumerate(LEAVES):
        f=pd.DataFrame(atlas['C'][:,i].T,columns=columns);f.insert(0,'gene',genes);f.insert(0,'population',leaf);counts.append(f)
    r.generated_table(pd.concat(counts,ignore_index=True),'data/study/leaf_pseudobulk_counts.tsv.gz','study','Unfiltered raw integer sums for 16 disjoint leaf populations; gene missing in source must be interpreted using availability table. Columns are physical samples.')
    p=pd.DataFrame(atlas['P'].T,columns=columns);p.insert(0,'gene',genes);r.generated_table(p,'data/study/gene_source_availability.tsv.gz','study','True indicates the gene exists in that sample source; false is unavailable, not measured zero.')
    for name,path in selected.items():
        rec=load_json(atlas['out']/('active_'+name+'.json')) if path else {};statuses.append(dict(stage=name,status=rec.get('status','not_run'),run_id=path.name if path else '',notes='See stage-specific status tables for failed/untestable populations.'))
        if path:
            target=root/'provenance'/name/'settings.json';save_json(_rel_settings(load_json(path/'settings.json')),target);r.generated(target)
    inp=selected['expression_inputs'];model=selected['expression'];patterns=selected['patterns']
    if inp:
        r.data(inp/'population_input_manifest.csv','data/expression/population_input_manifest.csv','expression','Population eligibility and modeled gene/library counts')
        for pop in POPS:
            p=inp/slug(pop)
            if not p.is_dir():continue
            for f in ['unit_QC.csv','gene_filter.csv','counts.tsv.gz','coldata.tsv']:
                if (p/f).is_file():r.data(p/f,f'data/expression/{slug(pop)}/input/{f}','expression','Filtered raw DESeq2 inputs and gene/unit QC for '+pop)
    if model:
        st=pd.read_csv(model/'fit_status.csv',keep_default_na=False);st['directory']=st.population.map(lambda x:slug(x));st['detail']=st.detail.map(lambda x:'See original server run log' if str(x).startswith('R failed') else x)
        r.generated_table(st,'data/expression/fit_status.csv','expression','Status of each population: complete, failed or not_testable.')
        for f in ['DE_test_summary.csv','supplementary_family_FDR.tsv.gz']:
            if (model/f).is_file():r.data(model/f,'data/expression/'+f,'expression','Population/test summary or supplementary BH across family; primary padj remains per test.')
        for row in st.itertuples():
            if row.status!='complete':continue
            pop=row.population;base=model/slug(pop);pref=f'data/expression/{slug(pop)}';receipt=load_json(base/'complete.json')
            if not all((base/f).is_file() and sha(base/f)==h for f,h in receipt['hashes'].items()):raise ValueError('Changed fitted result: '+pop)
            idx=pd.read_csv(base/'result_index.csv',keep_default_na=False)
            for f in ['result_index.csv','normalized_counts.tsv.gz','vst_expression.tsv.gz','fitted_library_metadata.csv','size_factors.csv','gene_fit_diagnostics.csv','Vehicle_baseline_effect_profiles.tsv.gz',*idx.file.tolist()]:r.data(base/f,pref+'/fit/'+f,'expression','Saved reference DESeq2 result or exact visualization input for '+pop+'. LRT unsigned; Wald numerator/denominator in result_index.csv.')
            if (base/'Wald_six_contrasts.png').is_file():
                board_settings=load_json(model/'Wald_board_settings.json')
                files=[pref+'/fit/'+f'{a}_vs_{b}.tsv.gz' for a,b in PAIRS]+[pref+'/fit/result_index.csv']
                r.fig(base/'Wald_six_contrasts.png',f'figures/expression/{slug(pop)}/Wald_six_contrasts.png','Expression',pop,'wald_board',files,dict(population=pop,test_family='wald_pairwise'),settings=board_settings)
    if patterns:
        ps=pd.read_csv(patterns/'pattern_summary.csv',keep_default_na=False)
        if 'directory' in ps:ps['directory']=ps.population.map(slug)
        r.generated_table(ps,'data/patterns/pattern_summary.csv','expression','Status and number of significant genes/patterns; pattern IDs local to population')
        for pop in POPS:
            p=patterns/slug(pop);pref=f'data/patterns/{slug(pop)}'
            if not p.is_dir():continue
            data=[]
            for f in sorted(p.iterdir()):
                if f.name.endswith(('.csv','.csv.gz')):data.append(r.data(f,pref+'/'+f.name,'expression','LRT-significant pattern membership, condition/mouse VST and z-scores, curve/box inputs, or influence audit for '+pop))
            for f in p.glob('*.json'):
                dest=root/'provenance'/'patterns'/slug(pop)/f.name;save_json(_rel_settings(load_json(f)),dest);r.generated(dest)
            for f in sorted(p.glob('*.png')):
                kind='lrt_heatmap' if f.name.startswith('compact') else 'lrt_mouse' if 'mouse_boxpoints' in f.name else 'lrt_curve';match=re.search(r'pattern_(\d+)',f.name);filters={'population':pop,'test_id':load_json(patterns/'settings.json')['settings']['settings']['test_id']}
                if match and kind!='lrt_heatmap':filters['pattern']=int(match.group(1))
                specific=[x for x in data if (kind=='lrt_heatmap' and any(k in x for k in ['zscores','all_gene_pattern_membership','condition_mean_VST'])) or (match and (f'pattern_{int(match.group(1)):02d}_' in x or 'condition_mean_zscores' in x or 'all_gene_pattern_membership' in x))]
                stat_path=f'data/expression/{slug(pop)}/fit/{filters["test_id"]}.tsv.gz';meta_path=f'data/expression/{slug(pop)}/fit/fitted_library_metadata.csv'
                links=specific or data;links=links+[x for x in [stat_path,meta_path] if (root/x).is_file()]
                r.fig(f,f'figures/expression/{slug(pop)}/{f.name}','Expression',pop,kind,links,filters)
    comp=selected['composition']
    if comp:
        from .composition import MODELS,MODEL_DESCRIPTIONS
        for f in ['all_model_denominators.csv','equal_mouse_composition_summaries.csv','all_sccomp_contrasts.csv','cFDR_pass.csv','exploratory_exact_mouse_fraction_tests.csv','sccomp_fit_summary.csv']:
            if (comp/f).is_file():r.data(comp/f,'data/composition/'+f,'composition','Composition counts, equal-mouse fractions, Bayesian contrasts/diagnostics or explicitly exploratory exact mouse tests.')
        st=pd.read_csv(comp/'sccomp_fit_summary.csv',keep_default_na=False).set_index('model');allcon='data/composition/all_sccomp_contrasts.csv'
        for name,parts in MODELS.items():
            p=comp/name;pop='Across atlas' if not name.startswith('within_') else next(g for g in MULTI if name=='within_'+slug(g));pref=f'data/composition/{name}'
            if not p.is_dir():continue
            obs=r.data(p/'observed_counts_fractions.csv',pref+'/observed_counts_fractions.csv','composition',MODEL_DESCRIPTIONS[name]);stat=st.loc[name,'status'] if name in st.index else 'not_run'
            # Only published completed contrasts are copied; incomplete/failed R artifacts are not treated as valid tests.
            con=None
            if stat in ('diagnostics_pass_basic','REVIEW_CONVERGENCE'):
                receipt=load_json(p/'fit_receipt.json')
                if not all((p/f).is_file() and sha(p/f)==h for f,h in receipt['hashes'].items()):raise ValueError('Changed sccomp output: '+name)
                for f in ['contrasts.csv','parameter_estimates.csv','absent_groups.csv','contrast_expression_audit.csv','Stan_parameter_summary.csv','Stan_diagnostics.txt','complete_R.json','posterior_predictive_plot_error.txt']:
                    if (p/f).is_file():
                        if f=='contrasts.csv':con=r.data(p/f,pref+'/'+f,'composition','Original sccomp Bayesian composition/variability result: '+name)
                        else:r.data(p/f,pref+'/'+f,'composition','Fitted model diagnostics/parameters or threshold provenance')
            for f in sorted(p.glob('*.png')):
                if f.name.startswith('observed_'):kind='composition_observed';paths=[obs,'data/composition/equal_mouse_composition_summaries.csv'];filter_={'model':name,'denominator':MODEL_DESCRIPTIONS[name]}
                elif f.name.startswith('contrast_') and con:
                    kind='composition_sccomp';paths=[con,allcon,obs,'data/composition/sccomp_fit_summary.csv'];filter_={'model':name,'parameter':next((z for z in [f'condition{a} - condition{b}' for a,b in PAIRS] if 'contrast_'+slug(z)==f.stem),'unmatched')}
                    if filter_['parameter']=='unmatched':raise ValueError('Unrecognized sccomp forest file '+f.name)
                elif f.name.startswith('posterior_predictive') and con:kind='composition_ppc';paths=[obs,con,'data/composition/sccomp_fit_summary.csv'];filter_={'model':name}
                else:continue
                r.fig(f,f'figures/composition/{name}/{f.name}','Composition',pop,kind,paths,filter_,stat if kind!='composition_observed' else 'descriptive')
    marker=selected['markers']
    if marker:
        for f in ['all_gene_specificity_ranking.csv.gz','candidate_markers.csv','paired_mouse_availability.csv','candidate_observed_expression_all_samples.csv.gz','candidate_within_mouse_contrasts.csv.gz','marker_status.csv']:
            if (marker/f).is_file():r.data(marker/f,'data/markers/'+f,'identity','Descriptive specificity, actual detection/log-normalized expression, matched-mouse contrasts, or marker status.')
        from .markers import SCOPES
        for scope,groups in SCOPES.items():
            p=marker/scope;pop='Across atlas' if scope=='major_lineages' else next(g for g in MULTI if scope=='within_'+slug(g));pref=f'data/markers/{scope}'
            if not p.is_dir():continue
            for f in p.glob('*.csv'):r.data(f,pref+'/'+f.name,'identity','Top selected markers and exact plotted values with n_mice: '+scope)
            for f in p.glob('*.png'):
                match=re.fullmatch(r'top_(\d+)_(pooled|by_treatment)_dotplot_page(\d+)',f.stem)
                if not match:continue
                n,view,page=match.groups();genes=pd.read_csv(p/f'top_{n}_markers.csv').gene.astype(str).drop_duplicates().tolist();shown=genes[(int(page)-1)*45:int(page)*45]
                paths=[pref+f'/top_{n}_markers.csv',pref+f'/top_{n}_{view}_dotplot_values.csv','data/markers/candidate_observed_expression_all_samples.csv.gz']
                r.fig(f,f'figures/identity/{scope}/{f.name}','Identity',pop,'marker_dotplot',paths,dict(scope=scope,top_n=int(n),view=view,page=int(page),genes=shown))
    arch=selected['architecture']
    if arch:
        for f in ['autocorrelation','patch_summary','Ripley_raster','coverage','components']:
            r.data(arch/(f+'_all_samples.csv.gz'),f'data/spatial/architecture/{f}_all_samples.csv.gz','architecture','Sample-level architecture measurement or component table; all grids/thresholds retained.')
        grid_paths=[];null_paths=[]
        if include_spatial_grids or include_ripley_null:
            for row in atlas['sources'].to_dict('records'):
                p=arch/'sample_cache'/slug(row['sample']);rec=load_json(p/'complete.json')
                for f in sorted(p.glob('*.npz')):
                    if f.name.startswith('grid_') and include_spatial_grids:
                        if rec['hashes'][f.name]!=sha(f):raise ValueError('Changed architecture grid')
                        grid_paths.append(r.data(f,f'data/spatial/grids/{slug(row["sample"])}/{f.name}','architecture','Physical raster arrays: full, reviewed, window mask, supported field mask, origin_um, pixel_size_um, population-count arrays. No cell IDs.'))
                    elif f.name.endswith('_Ripley_null.npz') and include_ripley_null:
                        if rec['hashes'][f.name]!=sha(f):raise ValueError('Changed Ripley null')
                        null_paths.append(r.data(f,f'data/spatial/ripley_null/{slug(row["sample"])}/{f.name}','architecture','Pointwise conditional random-label L−r simulation values and radii; not treatment permutations.'))
        fp=arch/'active_figures.json'
        if fp.is_file():
            j=load_json(fp);p=arch/j['path'];s=j['settings']
            kinds={'fraction_matched_mice':'fraction_map','patch_matched_mice':'patch_map','autocorrelation_summary':'autocorrelation','patch_summary_summary':'patch_summary','ripley_summary':'ripley'}
            for pop in POPS:
                for f in (p/slug(pop)).glob('*.png'):
                    kind=kinds.get(f.stem)
                    if not kind:continue
                    base='data/spatial/architecture/';links=[base+'coverage_all_samples.csv.gz'];filters={'population':pop}
                    if kind in ('fraction_map','patch_map','patch_summary','autocorrelation'):filters['grid_um']=s['grid_um']
                    if kind in ('patch_map','patch_summary'):filters['fraction_threshold']=s['fraction_threshold'];links+=[base+'patch_summary_all_samples.csv.gz',base+'components_all_samples.csv.gz']
                    if kind in ('fraction_map','autocorrelation'):links+=[base+'autocorrelation_all_samples.csv.gz']
                    if kind in ('fraction_map','patch_map'):links +=[x for x in grid_paths if Path(x).name==f'grid_{s["grid_um"]:g}um.npz']
                    if kind=='ripley':links +=[base+'Ripley_raster_all_samples.csv.gz']+[x for x in null_paths if Path(x).name==slug(pop)+'_Ripley_null.npz']
                    r.fig(f,f'figures/spatial/{slug(pop)}/{f.name}','Spatial architecture',pop,kind,links,filters,settings=s)
    nb=selected['neighborhoods']
    if nb:
        for f in ['all_sample_neighborhoods.csv.gz','equal_mouse_treatment_summaries.csv.gz']:
            r.data(nb/f,'data/spatial/neighborhoods/'+f,'neighborhoods','Exact center-neighbor counts/fractions by mouse, radii/mode/denominator/view; equal-mouse treatment summaries.')
        fp=nb/'active_figures.json'
        if fp.is_file():
            j=load_json(fp);p=nb/j['path'];s=j['settings']
            for pop in POPS:
                for f in (p/slug(pop)).glob('*.png'):
                    match=re.fullmatch(r'(lineage|detailed)_(cumulative|annulus)_(all_reviewed|outside_anchor_lineage)_(treatment|sample)',f.stem)
                    if not match:raise ValueError('Unrecognized neighborhood plot '+f.name)
                    view,mode,den,level=match.groups();filters=dict(population=pop,neighbor_view=view,mode=mode,denominator=den,display_level=level,value=s['value'])
                    r.fig(f,f'figures/neighborhoods/{slug(pop)}/{f.name}','Neighborhoods',pop,'neighborhoods',['data/spatial/neighborhoods/all_sample_neighborhoods.csv.gz','data/spatial/neighborhoods/equal_mouse_treatment_summaries.csv.gz'],filters,settings=s)
    # Machine-readable stage status and reproducibility. No raw cell metadata or model objects copied.
    r.generated_table(pd.DataFrame(statuses),'analysis_status.csv','provenance','Active stage identities and completion status; inspect population/model-level status separately.')
    manifest=dict(release_id=root.name,scope='Controlled shallow review; not a raw-cell reanalysis package',**spec,study_design='12 independent mice, 3 per condition',n_figures=len(r.evidence),n_datasets=len(r.datasets),excluded=['raw H5AD/Zarr','individual cell coordinates/IDs/count matrices','original H&E/SVS','Stan draws and RDS','scVI model/graph','uncopied alternative plot styles'],source_cache_ids=[{'sample':i['sample'],'sha256':{k:v['sha256'] for k,v in i['files'].items()}} for i in load_json(atlas['out']/'atlas_manifest.json')['inputs']],code_hash=code_hash(),python=platform.python_version(),packages={p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','matplotlib','h5py']})
    save_json(manifest,root/'release_manifest.json');r.generated(root/'release_manifest.json')
    r.write_indices()
    for name in ['START_HERE.md','AGENT_GUIDE.md','METHODS_AND_REFERENCES.md','REVIEW_EXAMPLES.py']:
        r.copy(Path(__file__).parent.parent/'review_docs'/name,name)
    # Actual source for reproducibility, not a dependency for reading the release.
    for f in sorted(Path(__file__).parent.iterdir()):
        if f.suffix in ('.py','.R'):r.copy(f,'methods/code/'+f.name)
    make_portal(root,r.evidence,r.datasets,statuses)
    for name in ['index.html','static_index.html']:r.generated(root/name)
    validate_release(root,r.evidence,r.datasets)
    # Full checksum inventory for any alternate extraction / AI ingestion.
    files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt'];(root/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(root).as_posix()+'\n' for p in files));r.generated(root/'SHA256SUMS.txt')
    archive=None
    if make_zip:
        archive=root.with_suffix('.zip');temp=archive.with_name(archive.name+'.partial')
        with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
            for p in sorted(root.rglob('*')):
                if p.is_file():z.write(p,arcname=root.name+'/'+p.relative_to(root).as_posix())
        with zipfile.ZipFile(temp) as z:
            if z.testzip():raise RuntimeError('ZIP integrity check failed')
        temp.replace(archive)
    print('Release:',root,'| figures:',len(r.evidence),'| datasets:',len(r.datasets),'| MiB:',round(r.total/2**20,1));return root,archive


def validate_release(root,evidence,datasets):
    root=Path(root).resolve();paths={d['path'] for d in datasets};ids=set()
    for x in evidence:
        if x['evidence_id'] in ids:raise ValueError('Duplicate evidence ID')
        ids.add(x['evidence_id'])
        if not set(x['data_paths']).issubset(paths):raise ValueError('Dangling evidence links')
    for x in [*datasets,*evidence]:
        p=(root/x['path']).resolve()
        if not p.is_relative_to(root) or not p.is_file() or sha(p)!=x['sha256']:raise ValueError('Invalid released file '+x['path'])


def make_portal(root,evidence,datasets,statuses):
    """Static local HTML with embedded catalogue, no external CDN or data-fetch requests."""
    payload=json.dumps(jsonable(dict(evidence=evidence,datasets=datasets,status=statuses)),ensure_ascii=False,allow_nan=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    page=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CT26 Whole Atlas | Evidence Review</title>
<style>
:root{font-family:system-ui,sans-serif;color:#193041;background:#f5f7f9;line-height:1.45}*{box-sizing:border-box}body{margin:0}header{background:#20394b;color:#fff;padding:20px 28px}header h1{font-size:22px;margin:0 0 4px}header p{margin:0;color:#d5e3eb;font-size:13px}main{max-width:1600px;margin:auto;padding:20px}a{color:#165d88;overflow-wrap:anywhere}header a{color:#d6f0ff}button,select,input{font:inherit;padding:8px 10px;border:1px solid #bdcbd5;border-radius:6px;background:#fff;color:#193041}button{cursor:pointer}button:hover{background:#e5edf3}button:disabled{opacity:.45;cursor:default}.guide,.controls,.status,.pinarea{background:white;border:1px solid #d9e2e9;border-radius:9px;padding:14px 17px;margin-bottom:14px}.guide h2,.pinarea h2{font-size:16px;margin:0 0 6px}.controls{display:flex;gap:10px;align-items:end;flex-wrap:wrap;position:sticky;top:0;z-index:3;box-shadow:0 2px 8px #1c415115}.controls label{display:flex;flex-direction:column;font-size:12px;color:#456172;gap:3px}.controls input{width:min(340px,80vw)}.controls select{max-width:235px}.nav{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:14px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(410px,100%),1fr));gap:16px}.card{background:#fff;border:1px solid #d9e2e9;border-radius:8px;overflow:hidden;display:flex;flex-direction:column;padding:12px;gap:7px}.card h3{font-size:14px;margin:0;overflow-wrap:anywhere}.card p{font-size:12px;margin:0}.meta{font:11px ui-monospace,monospace;color:#627788;overflow-wrap:anywhere}.card img{width:100%;max-height:430px;object-fit:contain;background:#fff;border:1px solid #eef1f4}.card details{font-size:12px}.card summary{cursor:pointer}.card ul{padding-left:19px}.caution{border-left:3px solid #c6a174;padding-left:8px;color:#6b543d}.buttons{display:flex;gap:7px;flex-wrap:wrap}.pinned{border-color:#406c8b}.tablewrap{overflow-x:auto}table{width:100%;border-collapse:collapse;font-size:12px;background:white}th,td{padding:7px;border-bottom:1px solid #e1e8ed;text-align:left;vertical-align:top}th{color:#456172}#dataSection{display:none}.muted{color:#607080;font-size:12px}pre{white-space:pre-wrap;font-size:11px}footer{padding:20px 25px;color:#526b7b;font-size:12px}
</style></head><body><header><h1>CT26 Whole Atlas — Evidence Review</h1><p>9 major lineages · 16 detailed populations · 12 independent mouse tumors · four categorical treatments</p><p><a href="START_HERE.md">Start here</a> · <a href="AGENT_GUIDE.md">AI-agent guide</a> · <a href="METHODS_AND_REFERENCES.md">Methods &amp; references</a> · <a href="static_index.html">Static index</a> · <a href="evidence_index.csv">Figure catalogue CSV</a></p></header>
<main><section class="guide"><h2>Choose a biological question</h2><p class="muted">Composition: start with the atlas-wide mutually exclusive partitions. Identity: compare lineages, then siblings. Expression: inspect compact LRT pattern heatmaps and the mouse-level plots. Spatial: compare matched-mouse maps and numerical summaries, then explore 50/100/200 µm neighbors. Use the data links for alternative plotting; this is not a raw-cell reanalysis package.</p></section>
<details class="status"><summary>Stage status and caveats (open before interpreting evidence)</summary><div id="statusTable" class="tablewrap"></div><p class="muted">Untestable, failed and missing results are not negative findings. Read population-specific fit/QC tables, original FDR scope and sccomp convergence diagnostics. Pooled and leaf results overlap.</p></details>
<div class="controls"><label>Chapter<select id="chapter"></select></label><label>Lineage<select id="lineage"></select></label><label>Population<select id="population"></select></label><label>Search (ID, term, filter)<input id="search" placeholder="e.g. T cell, annulus, LRT"></label><button id="clear">Reset</button><button id="toggleData">Data catalogue</button></div>
<div id="figureSection"><section class="pinarea" id="pinsArea" hidden><h2>Pinned comparison board</h2><p class="muted">Check the grid, denominator, analysis run, population and metric before comparing.</p><div id="pins" class="grid"></div><button id="clearPins">Clear pins</button></section><div class="nav"><span id="count"></span><button id="prev">Previous</button><button id="next">Next</button><label class="muted">Per page <select id="pageSize"><option>8</option><option selected>12</option><option>24</option></select></label></div><div id="cards" class="grid"></div><div class="nav"><button id="prevBottom">Previous</button><button id="nextBottom">Next</button></div></div>
<div id="dataSection"><h2 style="font-size:18px">Machine-readable datasets</h2><p class="muted">Search by stage, path, column, or description. Full file contents are available through links. <a href="dataset_index.csv">Dataset index CSV</a> · <a href="data_dictionary.csv">Column dictionary CSV</a></p><input id="dataSearch" placeholder="Filter datasets"><div class="nav"><span id="dataCount"></span><button id="dataPrev">Previous</button><button id="dataNext">Next</button></div><div class="tablewrap" id="dataRows"></div></div></main><footer>All relative paths point to the frozen release. See release_manifest.json and SHA256SUMS.txt. No external requests, no model fitting in this page.</footer>
<script id="atlas-data" type="application/json">__DATA__</script><script>
const D=JSON.parse(document.getElementById('atlas-data').textContent), E=D.evidence, DS=D.datasets;const $=s=>document.getElementById(s);let page=0,dp=0,pins=[];
function el(tag,text,cls){const x=document.createElement(tag);if(text!==undefined)x.textContent=text;if(cls)x.className=cls;return x}
function link(path,text){const a=el('a',text||path);a.href=path;a.target='_blank';a.rel='noopener';return a}
function options(id,items,first){const x=$(id);x.replaceChildren();const all=el('option',first||'All');all.value='';x.append(all);for(const v of items){const o=el('option',v);o.value=v;x.append(o)}}
options('chapter',[...new Set(E.map(x=>x.chapter))],'All chapters');options('lineage',[...new Set(E.map(x=>x.lineage))],'All lineages');options('population',[...new Set(E.map(x=>x.population))],'All populations');
function table(rows,cols){const t=el('table'),head=el('tr');cols.forEach(c=>head.append(el('th',c)));t.append(head);for(const row of rows){const tr=el('tr');cols.forEach(c=>{const td=el('td');if(c==='path')td.append(link(row[c]));else td.textContent=Array.isArray(row[c])?row[c].join(', '):String(row[c]??'');tr.append(td)});t.append(tr)}return t}
$('statusTable').append(table(D.status,['stage','status','run_id','notes']));
function card(e,pinned=false){const a=el('article',undefined,'card'+(pinned?' pinned':''));a.append(el('h3',e.title),el('div',e.evidence_id+' · '+e.status,'meta'));const img=el('img');img.src=e.path;img.alt=e.title;img.loading='lazy';const im=link(e.path,'');im.replaceChildren(img);a.append(im,el('p',e.meaning),el('p',e.caution,'caution'));const det=el('details');det.append(el('summary','Supporting tables, filters and settings'));const ul=el('ul');for(const path of e.data_paths){const li=el('li');li.append(link(path));ul.append(li)}det.append(ul,el('pre',JSON.stringify({filters:e.filters,settings:e.settings},null,2)));a.append(det);const btn=el('button',pins.includes(e.evidence_id)?'Unpin':'Pin');btn.onclick=()=>{if(pins.includes(e.evidence_id))pins=pins.filter(p=>p!==e.evidence_id);else if(pins.length<4)pins.push(e.evidence_id);else{alert('Pin up to four figures. Remove one before adding another.');return}render()};const buttons=el('div',undefined,'buttons');buttons.append(btn,link(e.path,'Open original PNG'));a.append(buttons);return a}
function current(){const q=$('search').value.trim().toLowerCase();return E.filter(e=>(!$('chapter').value||e.chapter===$('chapter').value)&&(!$('lineage').value||e.lineage===$('lineage').value)&&(!$('population').value||e.population===$('population').value)&&(!q||JSON.stringify(e).toLowerCase().includes(q)))}
function render(){const arr=current(),n=Number($('pageSize').value);page=Math.max(0,Math.min(page,Math.ceil(arr.length/n)-1));$('cards').replaceChildren(...arr.slice(page*n,(page+1)*n).map(e=>card(e)));$('count').textContent=arr.length?`${page*n+1}–${Math.min((page+1)*n,arr.length)} of ${arr.length} figures`:'No matched figures. Change filters or inspect stage status.';for(const i of ['prev','prevBottom'])$(i).disabled=page===0;for(const i of ['next','nextBottom'])$(i).disabled=(page+1)*n>=arr.length;$('pinsArea').hidden=pins.length===0;$('pins').replaceChildren(...pins.map(id=>card(E.find(x=>x.evidence_id===id),true)))}
for(const id of ['chapter','lineage','population','pageSize'])$(id).onchange=()=>{page=0;render()};$('search').oninput=()=>{page=0;render()};$('clear').onclick=()=>{for(const id of ['chapter','lineage','population','search'])$(id).value='';page=0;render()};for(const i of ['prev','prevBottom'])$(i).onclick=()=>{page--;render()};for(const i of ['next','nextBottom'])$(i).onclick=()=>{page++;render()};$('clearPins').onclick=()=>{pins=[];render()};
function renderData(){const q=$('dataSearch').value.toLowerCase(),rows=DS.filter(d=>JSON.stringify(d).toLowerCase().includes(q));dp=Math.max(0,Math.min(dp,Math.ceil(rows.length/40)-1));$('dataRows').replaceChildren(table(rows.slice(dp*40,(dp+1)*40),['dataset_id','stage','path','description','rows','columns','size_bytes']));$('dataCount').textContent=`${rows.length} matched datasets · page ${dp+1}`;$('dataPrev').disabled=dp===0;$('dataNext').disabled=(dp+1)*40>=rows.length};$('dataSearch').oninput=()=>{dp=0;renderData()};$('dataPrev').onclick=()=>{dp--;renderData()};$('dataNext').onclick=()=>{dp++;renderData()};$('toggleData').onclick=()=>{const show=$('dataSection').style.display!=='block';$('dataSection').style.display=show?'block':'none';$('figureSection').style.display=show?'none':'block';$('toggleData').textContent=show?'Figure browser':'Data catalogue';if(show)renderData()};render();
</script></body></html>'''
    (Path(root)/'index.html').write_text(page.replace('__DATA__',payload),encoding='utf-8')
    body=['<!doctype html><html><head><meta charset="utf-8"><title>CT26 static evidence index</title><style>body{font-family:system-ui;margin:25px;line-height:1.5}li{margin:10px 0}small{color:#546477}</style></head><body><h1>CT26 evidence — static index</h1><p>All links work without JavaScript. <a href="index.html">Interactive navigator</a> · <a href="dataset_index.csv">Dataset catalogue</a> · <a href="AGENT_GUIDE.md">AI-agent guide</a></p>']
    for chapter in dict.fromkeys(x['chapter'] for x in evidence):
        body.append('<h2>'+html.escape(chapter)+'</h2><ul>')
        for x in evidence:
            if x['chapter']!=chapter:continue
            links=' · '.join('<a href="'+html.escape(p,quote=True)+'">'+html.escape(Path(p).name)+'</a>' for p in x['data_paths'])
            body.append('<li><a href="'+html.escape(x['path'],quote=True)+'">'+html.escape(x['evidence_id']+' '+x['title'])+'</a><br><small>'+html.escape(x['meaning']+' '+x['caution'])+'<br>'+links+'</small></li>')
        body.append('</ul>')
    body.append('</body></html>');(Path(root)/'static_index.html').write_text(''.join(body),encoding='utf-8')
