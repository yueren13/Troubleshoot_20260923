"""Raw observed mouse-level pseudobulks for all lineages and reviewed subtypes."""
from .core import *
DEFAULT_MODEL=dict(min_cells=50,min_library_counts=1000,min_gene_count=10,min_gene_units=3,
 min_units_per_condition=3,min_tested_genes=50,alpha=.05,sf_type='poscounts',fit_type='parametric',shrinkage='ashr',
 run_hallmark=False,hallmark_min_size=15,hallmark_max_size=500,populations=POPS,
 design_note='One independent tumor per mouse; three mice per condition; no technical replicates.')

def prepare(atlas,settings=None):
    s={**DEFAULT_MODEL,**(settings or {})}
    if len(set(s['populations']))!=len(s['populations']) or set(s['populations'])-set(POPS):raise ValueError('Unknown or duplicate populations')
    if any(s[k]<1 for k in ['min_cells','min_library_counts','min_gene_count','min_gene_units','min_units_per_condition','min_tested_genes']):raise ValueError('Invalid filtering settings')
    if not 2<=s['min_units_per_condition']<=3 or s['run_hallmark']:raise ValueError('This branch uses 2–3 independent mice per arm and no Hallmark fit; use 08J for enrichment')
    out=stage(atlas,'expression_inputs',s);C,N=group_arrays(atlas,s['populations']);m=atlas['sources'];genes=np.asarray(atlas['genes']);manifest=[]
    for i,pop in enumerate(s['populations']):
        d=out/slug(pop);d.mkdir(exist_ok=True);c=C[:,i];n=N[:,i];meta=m[['sample','unit','condition']].rename(columns={'unit':'independent_unit'}).copy()
        meta.insert(0,'library_id',[f'U{a+1:03d}' for a in range(len(meta))]);meta['n_cells']=n;meta['library_counts']=c.sum(axis=1)
        meta['eligible']=(meta.n_cells>=s['min_cells'])&(meta.library_counts>=s['min_library_counts']);use=meta.eligible.to_numpy();ns=meta.loc[use].groupby('condition').size().reindex(CONDITIONS,fill_value=0)
        available=atlas['P'][use].all(axis=0) if use.any() else np.zeros(len(genes),bool);enough=(c[use]>=s['min_gene_count']).sum(axis=0)>=s['min_gene_units'];keep=available&enough
        save_csv(meta,d/'unit_QC.csv');save_csv(pd.DataFrame(dict(gene=genes,present_all_eligible_units=available,count_filter_pass=enough,tested=keep)),d/'gene_filter.csv')
        ok=(ns>=s['min_units_per_condition']).all() and keep.sum()>=s['min_tested_genes']
        reason='' if ok else f'Insufficient eligible units/genes: {ns.to_dict()}; {int(keep.sum())} genes'
        if ok:
            ids=np.flatnonzero(use);ids=sorted(ids,key=lambda a:(CONDITIONS.index(meta.condition.iloc[a]),meta.independent_unit.iloc[a]));u=meta.iloc[ids].copy();x=c[ids][:,keep]
            if x.max()>np.iinfo(np.int32).max or np.any(x.sum(axis=1)==0):ok=False;reason='Integer overflow or empty fitted library'
            else:
                frame=pd.DataFrame(x.T,index=genes[keep],columns=u.library_id);frame.index.name='gene';save_csv(frame,d/'counts.tsv.gz',True);save_csv(u,d/'coldata.tsv')
        manifest.append(dict(population=pop,status='ready' if ok else 'not_testable',reason=reason,directory=slug(pop),n_eligible_units=int(use.sum()),n_genes=int(keep.sum()),**{f'n_{k}':int(v) for k,v in ns.items()}))
    table=pd.DataFrame(manifest);save_csv(table,out/'population_input_manifest.csv');register(atlas,'expression_inputs',out);return out,table

def fit(atlas,input_root,connection_json):
    inp=Path(input_root);s=load_json(inp/'settings.json')['settings'];script=Path(__file__).with_name('deseq2_backend.R');versions=r_check(script,connection_json)
    if s['shrinkage']=='ashr' and not versions['ashr_available']:raise RuntimeError('ashr missing from selected R library')
    inputs=pd.read_csv(inp/'population_input_manifest.csv',keep_default_na=False);hashes={}
    for r in inputs.itertuples():
        if r.status=='ready':hashes[r.population]={n:sha(inp/r.directory/n) for n in ['counts.tsv.gz','coldata.tsv']}
    out=stage(atlas,'expression',dict(model=s,input_id=inp.name,versions=versions,input_hashes=hashes));statuses=[]
    for r in inputs.itertuples():
        dest=out/slug(r.population);dest.mkdir(exist_ok=True)
        base=dict(population=r.population,directory=str(dest),n_eligible_units=r.n_eligible_units,n_genes=r.n_genes)
        if r.status!='ready':statuses.append(dict(**base,status='not_testable',detail=r.reason));continue
        ident=digest(dict(stage=out.name,population=r.population));done=dest/'complete.json'
        if done.is_file():
            rec=load_json(done)
            if rec.get('model_id')!=ident or not all((dest/f).is_file() and sha(dest/f)==h for f,h in rec['hashes'].items()):raise RuntimeError('Completed DESeq2 output changed: '+str(dest))
            print('Reusing completed fit:',r.population,flush=True);statuses.append(dict(**base,status='complete',detail='reused'));continue
        job=dict(model_id=ident,population=r.population,counts=str(inp/r.directory/'counts.tsv.gz'),metadata=str(inp/r.directory/'coldata.tsv'),output=str(dest),settings=s,run_hallmark=False,gmt='',primary_contrasts=[f'{a}_vs_{b}' for a,b in PRIMARY])
        print('DESeq2:',r.population,flush=True)
        try:
            (dest/'complete_R.json').unlink(missing_ok=True);run_r(script,job,dest,connection_json)
            rr=load_json(dest/'complete_R.json');index=pd.read_csv(dest/'result_index.csv')
            if rr['model_id']!=ident or len(index)!=9 or set(index.test_id)!={f'{a}_vs_{b}' for a,b in PAIRS}|{'Interaction_difference_of_differences','LRT_any_condition','LRT_PD1_by_Adagrasib'}:raise ValueError('Incomplete DESeq2 result inventory')
            names=['result_index.csv','normalized_counts.tsv.gz','vst_expression.tsv.gz','fitted_library_metadata.csv','size_factors.csv','gene_fit_diagnostics.csv','Vehicle_baseline_effect_profiles.tsv.gz',*index.file.tolist(),'complete_R.json']
            save_json(dict(model_id=ident,hashes={f:sha(dest/f) for f in names}),done);statuses.append(dict(**base,status='complete',detail='new fit'))
        except Exception as e:statuses.append(dict(**base,status='failed',detail=str(e)))
        save_csv(pd.DataFrame(statuses),out/'fit_status.csv')
    table=pd.DataFrame(statuses);save_csv(table,out/'fit_status.csv');register(atlas,'expression',out,'partial_or_failed' if table.status.eq('failed').any() else 'complete');return out,table

def summarize(atlas,model_root):
    root=Path(model_root);status=pd.read_csv(root/'fit_status.csv',keep_default_na=False);summary=[];all_results=[]
    alpha=load_json(root/'settings.json')['settings']['model']['alpha']
    for r in status.itertuples():
        if r.status!='complete':summary.append(dict(population=r.population,status=r.status,test_id='',n_tested=0,n_significant=np.nan));continue
        base=root/slug(r.population);idx=pd.read_csv(base/'result_index.csv',keep_default_na=False)
        for row in idx.itertuples():
            f=pd.read_csv(base/row.file,sep='\t');good=f.padj.notna()&(f.padj<alpha);summary.append(dict(population=r.population,status='complete',family=row.family,test_id=row.test_id,n_tested=len(f),n_valid_pvalues=int(f.pvalue.notna().sum()),n_valid_FDR=int(f.padj.notna().sum()),n_significant=int(good.sum())))
            f.insert(0,'population',r.population);f.insert(1,'test_id',row.test_id);f.insert(2,'family',row.family);all_results.append(f[['population','test_id','family','gene','pvalue']])
    summary=pd.DataFrame(summary);save_csv(summary,root/'DE_test_summary.csv')
    if all_results:
        tab=pd.concat(all_results,ignore_index=True);tab['padj_across_population_test_family']=np.nan
        for _,ix in tab.groupby('family').groups.items():tab.loc[ix,'padj_across_population_test_family']=bh(tab.loc[ix,'pvalue'])
        save_csv(tab,root/'supplementary_family_FDR.tsv.gz')
    return summary


def plot_wald_boards(model_root,dpi=300,y_cap=40.):
    """One compact six-contrast board per population, not hundreds of redundant volcanoes."""
    import matplotlib.pyplot as plt
    root=Path(model_root);s=load_json(root/'settings.json')['settings']['model'];alpha=s['alpha'];lfc='lfc_shrunken' if s['shrinkage']=='ashr' else 'log2FoldChange'
    st=pd.read_csv(root/'fit_status.csv',keep_default_na=False)
    if y_cap<=-np.log10(alpha):raise ValueError('Volcano y cap below cutoff')
    for row in st.itertuples():
        if row.status!='complete':continue
        p=root/slug(row.population);pairs=[f'{a}_vs_{b}' for a,b in PAIRS];data=[]
        for test in pairs:
            f=pd.read_csv(p/(test+'.tsv.gz'),sep='\t');f=f[np.isfinite(f[lfc])&np.isfinite(f.padj)].copy();f['y']=-np.log10(f.padj.clip(1e-300,1));f['x']=f[lfc];data.append(f)
        limit=max(1.,max((float(f.x.abs().max()) for f in data if len(f)),default=1.)*1.05)
        fig,axs=plt.subplots(2,3,figsize=(14,8.5),sharex=True,sharey=True)
        for ax,f,(a,b) in zip(axs.ravel(),data,PAIRS):
            sig=f.padj<alpha;colors=np.where(sig,np.where(f.x>=0,'#B2182B','#2166AC'),'#BDBDBD');ax.scatter(f.x,f.y.clip(upper=y_cap),c=colors,s=5,alpha=.7,linewidths=0,rasterized=True)
            cap=f[f.y>y_cap];ax.scatter(cap.x,np.repeat(y_cap,len(cap)),marker='^',s=15,c='0.3',linewidths=0)
            ax.axhline(-np.log10(alpha),color='0.4',linestyle='--',lw=.6);ax.axvline(0,color='0.5',lw=.5);ax.set_xlim(-limit,limit);ax.set_ylim(0,y_cap*1.03);ax.set_title(f'{DISPLAY[a]} vs {DISPLAY[b]}\nup {(sig&(f.x>0)).sum():,} | down {(sig&(f.x<0)).sum():,}',fontsize=9);ax.spines[['top','right']].set_visible(False)
        fig.supxlabel(lfc+' (numerator / denominator)');fig.supylabel('−log10 original DESeq2 padj');fig.suptitle(row.population+' | six pairwise Wald contrasts');fig.text(.03,.015,f'FDR < {alpha}; triangle = above displayed y cap. All finite tested genes retained. Original statistics, not new tests.',fontsize=8);fig.tight_layout(rect=[.01,.04,1,.94]);savefig(fig,p/'Wald_six_contrasts.png',dpi)
    save_json(dict(alpha=alpha,lfc_column=lfc,y_cap=y_cap,dpi=dpi),root/'Wald_board_settings.json');return root
