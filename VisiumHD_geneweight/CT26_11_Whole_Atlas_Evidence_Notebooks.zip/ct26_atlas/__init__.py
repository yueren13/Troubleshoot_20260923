"""CT26 whole-atlas analysis. Isolated namespace; original notebooks remain unchanged."""
