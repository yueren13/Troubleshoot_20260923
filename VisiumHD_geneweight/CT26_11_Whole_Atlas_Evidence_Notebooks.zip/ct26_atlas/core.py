"""Verified 09A cache adapter and one mutually exclusive two-level hierarchy."""
from pathlib import Path
from itertools import combinations
import json, os, shutil, subprocess, gc, re, hashlib, sys, warnings
import numpy as np
import pandas as pd
from .source_io import *

LEAVES=['B cell','Dendritic cell','Endothelial cell','Fibroblast cell 1','Fibroblast cell 2','Macrophage 1','Macrophage 2','Mast cell','Muscle cell','T cell 1','T cell 2',*TUMOR]
HIERARCHY={'B cell':['B cell'],'Dendritic cell':['Dendritic cell'],'Endothelial cell':['Endothelial cell'],
    'All Fibroblast':['Fibroblast cell 1','Fibroblast cell 2'],'All Macrophage':['Macrophage 1','Macrophage 2'],
    'Mast cell':['Mast cell'],'Muscle cell':['Muscle cell'],'All T cell':['T cell 1','T cell 2'],ALL_TUMOR:list(TUMOR)}
LINEAGES=list(HIERARCHY); PARENT={leaf:g for g,m in HIERARCHY.items() for leaf in m}
GROUPS={**HIERARCHY,**{x:[x] for x in LEAVES if x not in HIERARCHY}}
POPS=list(GROUPS); MULTI={g:m for g,m in HIERARCHY.items() if len(m)>1}
COLORS=dict(zip(LEAVES,['#F4C17B','#3C76AF','#D0352B','#A65E34','#CA6627','#643F95','#7470AE','#C6B3D4','#AECDE1','#D43E88','#ED9F9C','#CFD266','#BBDE93','#7EDD45','#549E3F','#4B9C79']))
COLORS.update({g:COLORS[m[0]] for g,m in HIERARCHY.items()});COLORS['Unassigned']='#D9D9D9'
PAIRS=[('AntiPD1','Vehicle'),('Adagrasib','Vehicle'),('Combination','Vehicle'),('Adagrasib','AntiPD1'),('Combination','AntiPD1'),('Combination','Adagrasib')]
assert len(LEAVES)==16 and len(LINEAGES)==9 and len(POPS)==20 and set(PARENT)==set(LEAVES)
assert len([x for m in HIERARCHY.values() for x in m])==16
VERSION='ct26-whole-atlas-v1.0'

def sample_cache(root,sample):return Path(root)/'sample_cache'/slug(sample)

def code_hash():return digest({p.name:sha(p) for p in sorted(Path(__file__).parent.iterdir()) if p.suffix in ('.py','.R')})

def read_reference(root,sample):
    p=sample_cache(root,sample)/'full_reference_coordinates.csv.gz'
    x=pd.read_csv(p,dtype={'source_cell_id':str,'population':'string'},keep_default_na=False)
    x['population']=x.population.mask(x.population.str.strip().eq(''))
    if x.source_cell_id.duplicated().any() or x.source_cell_id.eq('').any():raise ValueError(f'{sample}: invalid source IDs')
    if set(x.population.dropna())-set(LEAVES):raise ValueError(f'{sample}: unexpected reviewed labels')
    if not np.isfinite(x[['x_um','y_um']].to_numpy(float)).all():raise ValueError('Invalid physical coordinates')
    return x

def open_atlas(visibility_root,output_parent=None,verify_hashes=True):
    root=Path(visibility_root).expanduser().resolve();j=load_json(root/'project.json');project_spec=load_json(root/'project_spec.json')
    m=pd.read_csv(root/'source_manifest.csv',keep_default_na=False,dtype={'sample':str,'unit':str,'condition':str})
    if len(m)!=12 or not m['unit'].is_unique or not m['sample'].is_unique or set(m.condition)!=set(CONDITIONS) or not m.groupby('condition').size().reindex(CONDITIONS).eq(3).all():
        raise ValueError('Expected confirmed design: 12 distinct mouse tumors, 3 per condition. Review metadata, do not fabricate replicates.')
    if m[['sample','unit']].apply(lambda c:c.str.strip().eq('')).any().any():raise ValueError('Missing sample/unit ID')
    # Original source signatures are retained for future raw marker reads; allgene/cache hashes checked separately.
    source_map={x['row']['sample']:x for x in project_spec['samples']}
    if set(source_map)!=set(m['sample']):raise ValueError('09A source manifest mismatch')
    for row in m.to_dict('records'):
        recorded=source_map[row['sample']]['row']
        for field in ('sample','unit','condition','raw_h5ad','matrix_key','annotation_file','gene_table','gene_symbol_column','cell_id_column','sample_column','label_column','total_counts_column'):
            if field in recorded and str(row.get(field,''))!=str(recorded[field] if recorded[field] is not None else ''):
                raise ValueError(f'{row["sample"]}: source manifest differs from 09A spec at {field}')
    source_metadata_hashes={name:sha(root/name) for name in ('project.json','project_spec.json','source_manifest.csv')}
    genes=list(j['genes']);strings(genes,'09A gene axis',True)
    cube=[];n_cells=[];present=[];coverage=[];inputs=[]
    for row in m.to_dict('records'):
        sample=row['sample'];p=sample_cache(root,sample);receipt=load_json(p/'complete.json')
        if receipt['project_id']!=j['project_id']:raise ValueError('Wrong 09A project')
        files={}
        for name in ['allgene_compartment_sums.npz','full_reference_coordinates.csv.gz']:
            f=p/name;rec=receipt['outputs'][name]
            if not f.is_file() or f.stat().st_size!=rec['size'] or (verify_hashes and sha(f)!=rec['sha256']):raise ValueError(f'{sample}: 09A cache changed/incomplete: {name}')
            files[name]={'sha256':rec['sha256'],'signature':signature(f)}
        with np.load(p/'allgene_compartment_sums.npz',allow_pickle=False) as z:
            labels=z['populations'].astype(str).tolist();counts=z['counts'];n=z['n_cells'];avail=z['present'].astype(bool)
            if len(set(labels))!=len(labels) or set(labels)-set(LEAVES):raise ValueError(f'{sample}: unknown/duplicate leaf labels')
            if z['genes'].tolist()!=genes or counts.shape!=(len(labels),len(genes)) or n.shape!=(len(labels),) or avail.shape!=(len(genes),):raise ValueError('09A array axes mismatch')
            if not np.issubdtype(counts.dtype,np.integer) or np.any(counts<0) or not np.issubdtype(n.dtype,np.integer) or np.any(n<0):raise ValueError('Counts must be nonnegative integers')
            if np.any(counts[:,~avail]!=0) or not np.array_equal(counts.sum(axis=1,dtype=np.int64),z['all_source_totals']):raise ValueError('Raw total/feature availability mismatch')
            if np.any(counts[n==0]!=0):raise ValueError('Absent cells have nonzero counts')
            a=np.zeros((len(LEAVES),len(genes)),np.int64);b=np.zeros(len(LEAVES),np.int64)
            for i,label in enumerate(labels):a[LEAVES.index(label)]=counts[i];b[LEAVES.index(label)]=n[i]
        ref=read_reference(root,sample);observed=ref.population.value_counts().reindex(LEAVES,fill_value=0).to_numpy(int)
        if not np.array_equal(b,observed) or len(ref)!=receipt['summary']['n_full_cells'] or b.sum()!=receipt['summary']['n_reviewed']:raise ValueError(f'{sample}: expression / coordinate annotation counts disagree')
        if b.sum()==0:raise ValueError('No reviewed cells in a sample')
        cube.append(a);n_cells.append(b);present.append(avail);coverage.append(dict(sample=sample,unit=row['unit'],condition=row['condition'],n_full=len(ref),n_reviewed=int(b.sum()),n_unassigned=len(ref)-int(b.sum()),reviewed_fraction=float(b.sum()/len(ref))))
        inputs.append(dict(sample=sample,files=files));del ref;gc.collect();print('Verified 09A cache:',sample,flush=True)
    C=np.stack(cube);N=np.stack(n_cells);P=np.stack(present)
    spec=dict(version=VERSION,project_id=j['project_id'],inputs=inputs,design='12 independent mouse tumors, 3 per condition; no technical replicates',hierarchy=HIERARCHY,code_hash=code_hash(),verified_cache_hashes=verify_hashes,source_metadata_hashes=source_metadata_hashes)
    out=(Path(output_parent).expanduser().resolve() if output_parent else root/'whole_atlas_review')/digest(spec)[:16]
    out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'atlas_manifest.json');save_csv(m,out/'source_manifest.csv')
    save_csv(m[['sample','unit','condition']],out/'mouse_design.csv');save_csv(pd.DataFrame(coverage),out/'annotation_coverage.csv')
    save_csv(pd.DataFrame([dict(lineage=g,population=t,color=COLORS[t],lineage_color=COLORS[g],lineage_has_subtypes=len(ts)>1) for g,ts in HIERARCHY.items() for t in ts]),out/'hierarchy.csv')
    save_npz(out/'leaf_pseudobulk.npz',counts=C,n_cells=N,present=P,genes=np.array(genes),leaves=np.array(LEAVES),samples=m['sample'].to_numpy(str))
    rows=[]
    for i,r in enumerate(m.to_dict('records')):
        for g in POPS:
            inds=[LEAVES.index(t) for t in GROUPS[g]];count=int(N[i,inds].sum());parent=g if g in HIERARCHY else PARENT[g]
            den=int(N[i,[LEAVES.index(t) for t in HIERARCHY[parent]]].sum())
            rows.append(dict(sample=r['sample'],unit=r['unit'],condition=r['condition'],population=g,lineage=parent,is_lineage=g in HIERARCHY,is_leaf=g in LEAVES,n_cells=count,n_reviewed=int(N[i].sum()),n_parent=den,total_raw_counts=int(C[i,inds].sum()),fraction_reviewed=count/N[i].sum(),fraction_within_lineage=count/den if den else np.nan))
    counts=pd.DataFrame(rows);save_csv(counts,out/'population_counts.csv')
    save_json({name:sha(out/name) for name in ('source_manifest.csv','mouse_design.csv','annotation_coverage.csv','hierarchy.csv','leaf_pseudobulk.npz','population_counts.csv')},out/'verified_atlas_outputs.json')
    return dict(root=root,project=j,sources=m,out=out,counts=counts,coverage=pd.DataFrame(coverage),colors=COLORS,C=C,N=N,P=P,genes=genes,source_spec=source_map)

def reopen_atlas(out):
    out=Path(out).resolve();spec=load_json(out/'atlas_manifest.json')
    if spec['code_hash']!=code_hash():raise RuntimeError('Atlas helper changed since 11A. Rerun 11A to create a separate consistent run; do not mix code versions.')
    # Path recovered from recorded cache signature, not guessed from newest timestamp.
    root=Path(spec['inputs'][0]['files']['allgene_compartment_sums.npz']['signature']['path']).parents[2]
    j=load_json(root/'project.json');m=pd.read_csv(out/'source_manifest.csv',keep_default_na=False,dtype={'sample':str,'unit':str,'condition':str})
    if j['project_id']!=spec['project_id']:raise ValueError('Source project identity changed')
    for name,h in spec['source_metadata_hashes'].items():
        if sha(root/name)!=h:raise ValueError('09A source metadata changed since 11A: '+name)
    for name,h in load_json(out/'verified_atlas_outputs.json').items():
        if sha(out/name)!=h:raise ValueError('Derived atlas input changed since 11A: '+name)
    for item in spec['inputs']:
        for v in item['files'].values():
            old=v['signature']
            if signature(old['path'])!=old:raise ValueError('Source cache changed since 11A')
    with np.load(out/'leaf_pseudobulk.npz',allow_pickle=False) as z:
        if z['leaves'].tolist()!=LEAVES or z['samples'].tolist()!=m['sample'].tolist() or z['genes'].tolist()!=j['genes']:raise ValueError('Atlas axes differ')
        C=z['counts'];N=z['n_cells'];P=z['present']
    return dict(root=root,project=j,sources=m,out=out,counts=pd.read_csv(out/'population_counts.csv'),coverage=pd.read_csv(out/'annotation_coverage.csv'),colors=COLORS,C=C,N=N,P=P,genes=j['genes'],source_spec={x['row']['sample']:x for x in load_json(root/'project_spec.json')['samples']})

def group_arrays(atlas,groups):
    C=np.stack([atlas['C'][:,[LEAVES.index(t) for t in GROUPS[g]]].sum(axis=1,dtype=np.int64) for g in groups],axis=1)
    N=np.stack([atlas['N'][:,[LEAVES.index(t) for t in GROUPS[g]]].sum(axis=1,dtype=np.int64) for g in groups],axis=1)
    return C,N

def stage(atlas,name,settings):
    spec=dict(atlas_id=atlas['out'].name,settings=settings,code_hash=code_hash(),stage=name)
    out=atlas['out']/name/digest(spec)[:14];out.mkdir(parents=True,exist_ok=True);save_json(spec,out/'settings.json');return out

def register(atlas,name,path,status='complete'):
    p=Path(path).resolve();base=atlas['out'].resolve()
    if not p.is_relative_to(base):raise ValueError('Stage must be beneath atlas output')
    save_json(dict(stage=name,path=p.relative_to(base).as_posix(),status=status,settings_sha256=sha(p/'settings.json')),base/('active_'+name+'.json'))

def registered(atlas,name):
    f=atlas['out']/('active_'+name+'.json')
    if not f.is_file():return None
    j=load_json(f);p=(atlas['out']/j['path']).resolve()
    if not p.is_relative_to(atlas['out'].resolve()) or not p.is_dir() or sha(p/'settings.json')!=j['settings_sha256']:raise ValueError('Invalid stage pointer: '+name)
    return p

def r_connection(connection_json=None,rscript='Rscript'):
    env=os.environ.copy()
    if connection_json:
        c=load_json(connection_json);rscript=c['rscript'];env.update(c['environment'])
    exe=shutil.which(str(rscript)) or (str(rscript) if Path(rscript).is_file() else None)
    if not exe:raise FileNotFoundError('Set verified R connection JSON')
    return exe,env

def r_check(script,connection):
    exe,env=r_connection(connection);p=subprocess.run([exe,'--vanilla',str(script),'--check'],env=env,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stdout+'\n'+p.stderr)
    return json.loads(p.stdout.strip().splitlines()[-1])

def run_r(script,job,out,connection_json):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);exe,env=r_connection(connection_json)
    save_json(job,out/'job.json');command=[exe,'--vanilla',str(script),str(out/'job.json')]
    with (out/'R_run.log').open('w') as log:
        proc=subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        try:
            for line in proc.stdout:print(line,end='',flush=True);log.write(line);log.flush()
            ret=proc.wait()
        except BaseException:proc.terminate();proc.wait();raise
    if ret:raise RuntimeError(f'R failed (code {ret}); see {out}/R_run.log')

def exact_unit_tests(frame,keys,value):
    """Independent mouse-label allocations, two-sided absolute difference in means."""
    rows=[]
    for endpoint,g in frame.groupby(keys,dropna=False,sort=False):
        endpoint=endpoint if isinstance(endpoint,tuple) else (endpoint,);base=dict(zip(keys,endpoint))
        if g['unit'].duplicated().any():raise ValueError('Duplicate unit per endpoint')
        g=g[np.isfinite(pd.to_numeric(g[value],errors='coerce'))];vals={c:g.loc[g.condition==c,value].to_numpy(float) for c in CONDITIONS}
        for a,b in PAIRS:
            x,y=vals[a],vals[b];d=dict(**base,contrast=a+' minus '+b,n_a=len(x),n_b=len(y),effect_difference=float(x.mean()-y.mean()) if len(x) and len(y) else np.nan)
            if len(x)<3 or len(y)<3:rows.append(dict(**d,pvalue=np.nan,status='insufficient_units'));continue
            v=np.r_[x,y];n=len(x);observed=abs(x.mean()-y.mean());null=[abs(v[list(ix)].sum()/n-(v.sum()-v[list(ix)].sum())/len(y)) for ix in combinations(range(len(v)),n)]
            rows.append(dict(**d,pvalue=float(np.mean(np.asarray(null)>=observed-1e-12)),status='exact_mouse_label_test'))
    result=pd.DataFrame(rows)
    if len(result):result['q_BH_all_selected_endpoints']=bh(result.pvalue)
    return result

def savefig(fig,path,dpi=300):
    import matplotlib.pyplot as plt
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p,dpi=dpi,bbox_inches='tight',pad_inches=.15,facecolor='white');plt.close(fig)

def scalar_plot(frame,value,path,title,dpi=300):
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(7.8,5.2));cols=['#64748B','#507EB0','#DB8D38','#8557A3']
    for i,c in enumerate(CONDITIONS):
        g=frame.loc[frame.condition==c];v=pd.to_numeric(g[value],errors='coerce');good=np.isfinite(v);v=v[good]
        if len(v):
            ax.bar(i,v.mean(),width=.66,color=cols[i],alpha=.45,yerr=v.std(ddof=1) if len(v)>1 else 0,capsize=3)
            xs=i+np.linspace(-.11,.11,len(v));ax.scatter(xs,v,c=cols[i],s=28,zorder=3,edgecolors='black',linewidths=.3)
            for x,y,name in zip(xs,v,g.loc[good,'sample']):ax.annotate(name,(x,y),xytext=(3,3),textcoords='offset points',fontsize=7)
        else:ax.text(i,.45,'NA',transform=ax.get_xaxis_transform(),ha='center')
    ax.set_xticks(range(4),[DISPLAY[c] for c in CONDITIONS],rotation=25,ha='right');ax.set(title=title,ylabel=value);ax.spines[['top','right']].set_visible(False)
    savefig(fig,path,dpi)

def stacked(table,path,title,ylabel,dpi=300,percentage=False):
    """Same physical bar width irrespective of 4 or 12 bars; no tight bbox rescale."""
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    from matplotlib.ticker import PercentFormatter
    n=len(table);left=1.;body=.52*n;right=3.5;fw=left+body+right
    fig=plt.figure(figsize=(fw,6.4));ax=fig.add_axes([left/fw,.32,body/fw,.51]);bottom=np.zeros(n)
    values=table.to_numpy(float);empty=~np.isfinite(values).any(axis=1)
    if np.any(~np.isfinite(values).all(axis=1)&~empty):raise ValueError('Partially missing composition row, no silently filled fractions')
    for c in table.columns:
        v=table[c].fillna(0).to_numpy();ax.bar(np.arange(n),v,bottom=bottom,width=.68,color=COLORS[c],linewidth=0);bottom+=v
    for i in np.flatnonzero(empty):ax.text(i,.5,'NA',transform=ax.get_xaxis_transform(),ha='center')
    ax.set_xlim(-.5,n-.5);ax.set_xticks(np.arange(n),list(table.index),rotation=90,fontsize=8);ax.set_ylabel(ylabel)
    if percentage:ax.set_ylim(0,1.02);ax.yaxis.set_major_formatter(PercentFormatter(1))
    ax.legend(handles=[Patch(color=COLORS[c],label=c) for c in table.columns],bbox_to_anchor=(1.02,1),loc='upper left',frameon=False,fontsize=8)
    fig.suptitle(title,fontsize=11);fig.text(.06,.025,'One partition only; pooled labels are alternatives, not extra cells. Missing rows = NA.',fontsize=8)
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p,dpi=dpi,facecolor='white');plt.close(fig)
