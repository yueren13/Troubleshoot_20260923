"""Six sccomp partitions; no overlapping lineage and subtype categories in a fit."""
from .core import *

MODELS={'major_lineages':LINEAGES,'all_detailed_types':LEAVES,**{'within_'+slug(g):ls for g,ls in MULTI.items()}}
MODEL_DESCRIPTIONS={k:('All reviewed cells' if k in ('major_lineages','all_detailed_types') else 'Reviewed cells within '+next(g for g in MULTI if k=='within_'+slug(g))) for k in MODELS}

def counts_table(atlas):
    tab=[]
    for model,parts in MODELS.items():
        _,N=group_arrays(atlas,parts)
        for i,r in enumerate(atlas['sources'].to_dict('records')):
            den=int(N[i].sum());expected=int(atlas['N'][i].sum()) if model in ('major_lineages','all_detailed_types') else int(atlas['N'][i,[LEAVES.index(x) for x in parts]].sum())
            if den!=expected:raise AssertionError('Composition partition does not conserve count')
            for g,n in zip(parts,N[i]):tab.append(dict(model=model,sample=r['sample'],unit=r['unit'],condition=r['condition'],cell_group=g,count=int(n),denominator=den,fraction=float(n/den) if den else np.nan,denominator_definition=MODEL_DESCRIPTIONS[model]))
    return pd.DataFrame(tab)

def run(atlas,connection,settings=None,run_sccomp=True,run_exact_tests=False,exchangeability_note='',dpi=300):
    s=dict(cores=4,seed=17,max_sampling_iterations=8000,effect_threshold=.1,posterior_predictive_plots=True);s.update(settings or {})
    if run_exact_tests and not str(exchangeability_note).strip():raise ValueError('Confirm why independent mouse treatment labels are exchangeable before exact tests')
    if s['effect_threshold']<0 or s['cores']<1:raise ValueError('Invalid sccomp settings')
    script=Path(__file__).with_name('sccomp_backend.R');versions=r_check(script,connection) if run_sccomp else None
    conn=load_json(connection) if run_sccomp else {};tab=counts_table(atlas)
    out=stage(atlas,'composition',dict(sccomp=s,versions=versions,run_sccomp=run_sccomp,exact_tests=run_exact_tests,exchangeability_note=exchangeability_note,dpi=dpi));save_csv(tab,out/'all_model_denominators.csv')
    statuses=[];contrasts=[];means=[]
    for model,parts in MODELS.items():
        g=tab[tab.model==model].copy();path=out/model;path.mkdir(exist_ok=True);save_csv(g,path/'observed_counts_fractions.csv')
        # These four figures use the same source rows and physical bar widths.
        order=[v for c in CONDITIONS for v in atlas['sources'].loc[atlas['sources'].condition==c,'sample']]
        for value,pct in [('count',False),('fraction',True)]:
            matrix=g.pivot(index='sample',columns='cell_group',values=value).reindex(index=order,columns=parts)
            if pct:matrix.loc[g.loc[g.denominator==0,'sample'].unique()]=np.nan
            stacked(matrix,path/f'observed_{value}_by_sample.png',model+' | individual mice', 'Fraction' if pct else 'Observed cells',dpi,pct)
            means_table=g.groupby(['condition','cell_group'])[value].mean().unstack().reindex(index=CONDITIONS,columns=parts)
            # Mean only defined fraction rows; coverage of each mean is exported.
            means_table.index=[DISPLAY[c] for c in means_table.index];stacked(means_table,path/f'observed_{value}_equal_mouse_mean.png',model+' | equal-mouse mean','Mean fraction' if pct else 'Mean cells per mouse',dpi,pct)
        means.append(g.groupby(['condition','model','cell_group'],sort=False).agg(mean_count=('count','mean'),mean_fraction=('fraction','mean'),sd_fraction=('fraction','std'),n_valid_mice=('fraction','count')).reset_index())
        row=dict(model=model,directory=model,n_categories=len(parts),denominator_definition=MODEL_DESCRIPTIONS[model]);done=path/'complete_R.json';receipt=path/'fit_receipt.json'
        if not run_sccomp:statuses.append(dict(**row,status='not_run'));continue
        if (g.denominator<=0).any():statuses.append(dict(**row,status='not_testable_zero_denominator'));continue
        observed=g.groupby('cell_group')['count'].sum();active=observed[observed>0].index.tolist()
        if len(active)<2:statuses.append(dict(**row,status='not_testable_fewer_than_two_observed_parts'));continue
        ident=digest(dict(stage=out.name,model=model,counts_sha=sha(path/'observed_counts_fractions.csv')))
        try:
            if receipt.is_file():
                r=load_json(receipt)
                if r['job_id']!=ident or not all((path/f).is_file() and sha(path/f)==h for f,h in r['hashes'].items()):raise RuntimeError('Completed sccomp files changed; inspect before reusing')
                print('Reusing sccomp:',model,flush=True)
            else:
                done.unlink(missing_ok=True);job=dict(job_id=ident,model_name=model,counts=str(path/'observed_counts_fractions.csv'),output=str(path),stan_cache=conn['stan_cache'],settings=s)
                run_r(script,job,path,connection)
            d=load_json(done);res=pd.read_csv(path/'contrasts.csv')
            if d['job_id']!=ident or not {'cell_group','parameter','c_effect','c_lower','c_upper','c_pH0','c_FDR'}.issubset(res):raise ValueError('Unexpected sccomp output schema')
            expected={f'condition{a} - condition{b}' for a,b in PAIRS}
            if set(res.parameter)!=expected or set(res.cell_group)!=set(active) or res.duplicated(['cell_group','parameter']).any() or len(res)!=len(active)*6:raise ValueError('Incomplete six-contrast output; check R log')
            names=['complete_R.json','contrasts.csv','contrast_expression_audit.csv','parameter_estimates.csv']
            save_json(dict(job_id=ident,hashes={f:sha(path/f) for f in names}),receipt)
            res['model']=model;res['diagnostic_status']=d['status'];res['effect_threshold']=d['effect_threshold'];res['fdr_pass']=res.c_FDR<.05
            res['interpretation_status']=np.where(res.c_FDR.isna(),'undefined_FDR',np.where(res.fdr_pass,np.where(res.diagnostic_status=='diagnostics_pass_basic','candidate_supported','review_convergence'),'does_not_pass_FDR'))
            contrasts.append(res)
            statuses.append({**row,**d,'directory':model})
            try:forest(res,path,model,d['status'],dpi)
            except Exception as plot_error:save_json(dict(error=str(plot_error)),path/'forest_plot_error.json')
        except Exception as e:statuses.append(dict(**row,status='failed',detail=str(e)));print('sccomp failed:',model,str(e),flush=True)
        save_csv(pd.DataFrame(statuses),out/'sccomp_fit_summary.csv')
    st=pd.DataFrame(statuses);save_csv(st,out/'sccomp_fit_summary.csv');save_csv(pd.concat(means,ignore_index=True),out/'equal_mouse_composition_summaries.csv')
    con=pd.concat(contrasts,ignore_index=True) if contrasts else pd.DataFrame(columns=['model','cell_group','parameter','c_effect','c_lower','c_upper','c_pH0','c_FDR','diagnostic_status','interpretation_status'])
    save_csv(con,out/'all_sccomp_contrasts.csv');save_csv(con.loc[con.c_FDR<.05],out/'cFDR_pass.csv')
    if run_exact_tests:save_csv(exact_unit_tests(tab,['model','cell_group'],'fraction'),out/'exploratory_exact_mouse_fraction_tests.csv')
    register(atlas,'composition',out,'partial_or_failed' if st.status.eq('failed').any() or not run_sccomp else 'complete');return out,st,con

def forest(res,path,model,status,dpi):
    import matplotlib.pyplot as plt
    for contrast,g in res.groupby('parameter',sort=False):
        g=g.copy();order=[p for p in MODELS[model] if p in set(g.cell_group)];g=g.set_index('cell_group').reindex(order).reset_index()
        fig,ax=plt.subplots(figsize=(10,max(3.8,.42*len(g)+2)));fig.subplots_adjust(left=.28,right=.75,bottom=.21,top=.84)
        for i,r in enumerate(g.itertuples()):
            if np.isfinite(r.c_effect) and np.isfinite(r.c_lower) and np.isfinite(r.c_upper):
                ax.plot([r.c_lower,r.c_upper],[i,i],color='0.45');ax.scatter(r.c_effect,i,color='#B12B78' if r.c_FDR<.05 else '0.45',s=38,marker='D' if r.c_FDR<.05 else 'o')
            q='NA' if not np.isfinite(r.c_FDR) else f'{r.c_FDR:.3g}'+(' *' if r.c_FDR<.05 else '')
            ax.text(1.03,i,q,transform=ax.get_yaxis_transform(),va='center',fontsize=9)
        ax.axvline(0,color='black',lw=.7);ax.set_yticks(range(len(g)),g.cell_group);ax.invert_yaxis();ax.set_xlabel('sccomp effect (native coefficient scale)');ax.set_title(model+' | '+contrast+'\n'+status);ax.text(1.03,1.03,'c_FDR',transform=ax.transAxes,fontsize=9,weight='bold')
        fig.text(.05,.04,'95% credible intervals; * Bayesian c_FDR < 0.05. c_pH0/c_FDR are not frequentist P values.\nReview convergence and observed fractions; native coefficient effect is not a percentage-point difference.',fontsize=8)
        savefig(fig,path/('contrast_'+slug(contrast)+'.png'),dpi)
