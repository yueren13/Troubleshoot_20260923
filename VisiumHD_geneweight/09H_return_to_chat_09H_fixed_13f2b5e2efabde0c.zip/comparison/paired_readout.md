# Side-by-side correction on complete Proseg footprints

Percentages divide each method’s summed corrected marker counts by observed counts on the same cells, genes and native squares. SpotClean can return values above 100%. A dash indicates unavailable data or zero observed counts.

| Region | Group and panel | Cells | Observed UMIs | SPARKLE | SpotClean |
|---|---|---:|---:|---:|---:|
| region_0001 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0001 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0001 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0001 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0001 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0002 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0002 | Macrophage / monocyte labels · myeloid | 4 | 35 | 59.4% | — |
| region_0002 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0002 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0002 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0003 | Pan-T supported, near macrophages · myeloid | 2 | 7 | 65.9% | — |
| region_0003 | Macrophage / monocyte labels · myeloid | 10 | 93 | 60.4% | — |
| region_0003 | Pan-T supported · pan-T markers | 3 | 4 | 100.0% | — |
| region_0003 | Prior T labels · Cd4 | 13 | 0 | — | — |
| region_0003 | Prior T labels · Cd8a / Cd8b1 | 13 | 2 | 98.5% | — |
| region_0004 | Pan-T supported, near macrophages · myeloid | 15 | 121 | 73.4% | — |
| region_0004 | Macrophage / monocyte labels · myeloid | 13 | 170 | 72.7% | — |
| region_0004 | Pan-T supported · pan-T markers | 16 | 34 | 100.0% | — |
| region_0004 | Prior T labels · Cd4 | 48 | 1 | 100.0% | — |
| region_0004 | Prior T labels · Cd8a / Cd8b1 | 48 | 13 | 100.0% | — |
| region_0005 | Pan-T supported, near macrophages · myeloid | 20 | 223 | 52.9% | — |
| region_0005 | Macrophage / monocyte labels · myeloid | 17 | 167 | 50.5% | — |
| region_0005 | Pan-T supported · pan-T markers | 20 | 36 | 93.8% | — |
| region_0005 | Prior T labels · Cd4 | 47 | 5 | 88.7% | — |
| region_0005 | Prior T labels · Cd8a / Cd8b1 | 47 | 29 | 48.2% | — |
| region_0006 | Pan-T supported, near macrophages · myeloid | 24 | 202 | 60.6% | — |
| region_0006 | Macrophage / monocyte labels · myeloid | 9 | 45 | 62.4% | — |
| region_0006 | Pan-T supported · pan-T markers | 33 | 65 | 88.6% | — |
| region_0006 | Prior T labels · Cd4 | 43 | 4 | 100.0% | — |
| region_0006 | Prior T labels · Cd8a / Cd8b1 | 43 | 30 | 100.0% | — |
| region_0007 | Pan-T supported, near macrophages · myeloid | 17 | 189 | 68.9% | — |
| region_0007 | Macrophage / monocyte labels · myeloid | 2 | 11 | 54.5% | — |
| region_0007 | Pan-T supported · pan-T markers | 31 | 69 | 93.4% | — |
| region_0007 | Prior T labels · Cd4 | 39 | 5 | 28.1% | — |
| region_0007 | Prior T labels · Cd8a / Cd8b1 | 39 | 29 | 100.0% | — |
| region_0008 | Pan-T supported, near macrophages · myeloid | 3 | 16 | 77.2% | — |
| region_0008 | Macrophage / monocyte labels · myeloid | 1 | 13 | 66.7% | — |
| region_0008 | Pan-T supported · pan-T markers | 3 | 4 | 100.0% | — |
| region_0008 | Prior T labels · Cd4 | 14 | 0 | — | — |
| region_0008 | Prior T labels · Cd8a / Cd8b1 | 14 | 6 | 100.0% | — |
| region_0009 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0009 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0009 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0009 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0009 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0010 | Pan-T supported, near macrophages · myeloid | 3 | 13 | 39.9% | — |
| region_0010 | Macrophage / monocyte labels · myeloid | 3 | 17 | 66.5% | — |
| region_0010 | Pan-T supported · pan-T markers | 3 | 6 | 98.8% | — |
| region_0010 | Prior T labels · Cd4 | 7 | 0 | — | — |
| region_0010 | Prior T labels · Cd8a / Cd8b1 | 7 | 0 | — | — |
| region_0011 | Pan-T supported, near macrophages · myeloid | 1 | 1 | 62.8% | — |
| region_0011 | Macrophage / monocyte labels · myeloid | 1 | 7 | 91.3% | — |
| region_0011 | Pan-T supported · pan-T markers | 2 | 2 | 100.0% | — |
| region_0011 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0011 | Prior T labels · Cd8a / Cd8b1 | 4 | 0 | — | — |
| region_0012 | Pan-T supported, near macrophages · myeloid | 1 | 15 | 65.8% | — |
| region_0012 | Macrophage / monocyte labels · myeloid | 4 | 6 | 96.9% | — |
| region_0012 | Pan-T supported · pan-T markers | 1 | 5 | 100.0% | — |
| region_0012 | Prior T labels · Cd4 | 5 | 0 | — | — |
| region_0012 | Prior T labels · Cd8a / Cd8b1 | 5 | 5 | 100.0% | — |
| region_0013 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0013 | Macrophage / monocyte labels · myeloid | 6 | 17 | 100.0% | — |
| region_0013 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0013 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0013 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0014 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0014 | Macrophage / monocyte labels · myeloid | 5 | 9 | 89.5% | — |
| region_0014 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0014 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0014 | Prior T labels · Cd8a / Cd8b1 | 4 | 0 | — | — |
| region_0015 | Pan-T supported, near macrophages · myeloid | 6 | 54 | 56.4% | — |
| region_0015 | Macrophage / monocyte labels · myeloid | 6 | 33 | 74.5% | — |
| region_0015 | Pan-T supported · pan-T markers | 6 | 10 | 96.4% | — |
| region_0015 | Prior T labels · Cd4 | 17 | 0 | — | — |
| region_0015 | Prior T labels · Cd8a / Cd8b1 | 17 | 1 | 100.0% | — |
| region_0016 | Pan-T supported, near macrophages · myeloid | 14 | 175 | 63.9% | — |
| region_0016 | Macrophage / monocyte labels · myeloid | 11 | 135 | 67.6% | — |
| region_0016 | Pan-T supported · pan-T markers | 15 | 30 | 100.0% | — |
| region_0016 | Prior T labels · Cd4 | 32 | 4 | 100.0% | — |
| region_0016 | Prior T labels · Cd8a / Cd8b1 | 32 | 14 | 100.0% | — |
| region_0017 | Pan-T supported, near macrophages · myeloid | 24 | 282 | 65.5% | — |
| region_0017 | Macrophage / monocyte labels · myeloid | 14 | 136 | 66.9% | — |
| region_0017 | Pan-T supported · pan-T markers | 38 | 80 | 100.0% | — |
| region_0017 | Prior T labels · Cd4 | 86 | 4 | 100.0% | — |
| region_0017 | Prior T labels · Cd8a / Cd8b1 | 86 | 55 | 100.0% | — |
| region_0018 | Pan-T supported, near macrophages · myeloid | 9 | 79 | 60.3% | — |
| region_0018 | Macrophage / monocyte labels · myeloid | 2 | 19 | 54.2% | — |
| region_0018 | Pan-T supported · pan-T markers | 15 | 30 | 100.0% | — |
| region_0018 | Prior T labels · Cd4 | 37 | 1 | 100.0% | — |
| region_0018 | Prior T labels · Cd8a / Cd8b1 | 37 | 17 | 100.0% | — |
| region_0019 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0019 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0019 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0019 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0019 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0020 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0020 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0020 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0020 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0020 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0021 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0021 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0021 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0021 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0021 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0022 | Pan-T supported, near macrophages · myeloid | 1 | 0 | — | — |
| region_0022 | Macrophage / monocyte labels · myeloid | 2 | 6 | 77.1% | — |
| region_0022 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0022 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0022 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0023 | Pan-T supported, near macrophages · myeloid | 1 | 0 | — | — |
| region_0023 | Macrophage / monocyte labels · myeloid | 4 | 5 | 98.3% | — |
| region_0023 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0023 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0023 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0024 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0024 | Macrophage / monocyte labels · myeloid | 2 | 4 | 93.9% | — |
| region_0024 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0024 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0024 | Prior T labels · Cd8a / Cd8b1 | 1 | 1 | 100.0% | — |
| region_0025 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0025 | Macrophage / monocyte labels · myeloid | 3 | 5 | 86.3% | — |
| region_0025 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0025 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0025 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0026 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0026 | Macrophage / monocyte labels · myeloid | 4 | 9 | 97.8% | — |
| region_0026 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0026 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0026 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0027 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0027 | Macrophage / monocyte labels · myeloid | 4 | 15 | 98.5% | — |
| region_0027 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0027 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0027 | Prior T labels · Cd8a / Cd8b1 | 3 | 1 | 100.0% | — |
| region_0028 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0028 | Macrophage / monocyte labels · myeloid | 2 | 14 | 80.0% | — |
| region_0028 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0028 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0028 | Prior T labels · Cd8a / Cd8b1 | 4 | 0 | — | — |
| region_0029 | Pan-T supported, near macrophages · myeloid | 2 | 14 | 74.2% | — |
| region_0029 | Macrophage / monocyte labels · myeloid | 3 | 30 | 82.1% | — |
| region_0029 | Pan-T supported · pan-T markers | 2 | 3 | 100.0% | — |
| region_0029 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0029 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0030 | Pan-T supported, near macrophages · myeloid | 7 | 125 | 75.0% | — |
| region_0030 | Macrophage / monocyte labels · myeloid | 6 | 57 | 75.6% | — |
| region_0030 | Pan-T supported · pan-T markers | 7 | 10 | 100.0% | — |
| region_0030 | Prior T labels · Cd4 | 15 | 1 | 100.0% | — |
| region_0030 | Prior T labels · Cd8a / Cd8b1 | 15 | 9 | 100.0% | — |
| region_0031 | Pan-T supported, near macrophages · myeloid | 4 | 40 | 82.6% | — |
| region_0031 | Macrophage / monocyte labels · myeloid | 4 | 24 | 86.0% | — |
| region_0031 | Pan-T supported · pan-T markers | 4 | 8 | 81.4% | — |
| region_0031 | Prior T labels · Cd4 | 17 | 1 | 100.0% | — |
| region_0031 | Prior T labels · Cd8a / Cd8b1 | 17 | 6 | 100.0% | — |
| region_0032 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0032 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0032 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0032 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0032 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0033 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0033 | Macrophage / monocyte labels · myeloid | 1 | 1 | 98.8% | — |
| region_0033 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0033 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0033 | Prior T labels · Cd8a / Cd8b1 | 4 | 0 | — | — |
| region_0034 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0034 | Macrophage / monocyte labels · myeloid | 2 | 2 | 100.0% | — |
| region_0034 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0034 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0034 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0035 | Pan-T supported, near macrophages · myeloid | 2 | 2 | 100.0% | — |
| region_0035 | Macrophage / monocyte labels · myeloid | 5 | 1 | 94.4% | — |
| region_0035 | Pan-T supported · pan-T markers | 3 | 6 | 99.4% | — |
| region_0035 | Prior T labels · Cd4 | 14 | 0 | — | — |
| region_0035 | Prior T labels · Cd8a / Cd8b1 | 14 | 0 | — | — |
| region_0036 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0036 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0036 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0036 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0036 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0037 | Pan-T supported, near macrophages · myeloid | 1 | 0 | — | — |
| region_0037 | Macrophage / monocyte labels · myeloid | 2 | 2 | 94.9% | — |
| region_0037 | Pan-T supported · pan-T markers | 1 | 3 | 100.0% | — |
| region_0037 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0037 | Prior T labels · Cd8a / Cd8b1 | 2 | 2 | 100.0% | — |
| region_0038 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0038 | Macrophage / monocyte labels · myeloid | 3 | 1 | 76.0% | — |
| region_0038 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0038 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0038 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0039 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0039 | Macrophage / monocyte labels · myeloid | 2 | 12 | 91.7% | — |
| region_0039 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0039 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0039 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0040 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0040 | Macrophage / monocyte labels · myeloid | 6 | 2 | 100.0% | — |
| region_0040 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0040 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0040 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0041 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0041 | Macrophage / monocyte labels · myeloid | 6 | 19 | 100.0% | — |
| region_0041 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0041 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0041 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0042 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0042 | Macrophage / monocyte labels · myeloid | 12 | 37 | 67.7% | — |
| region_0042 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0042 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0042 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0043 | Pan-T supported, near macrophages · myeloid | 2 | 13 | 39.7% | — |
| region_0043 | Macrophage / monocyte labels · myeloid | 1 | 24 | 96.2% | — |
| region_0043 | Pan-T supported · pan-T markers | 3 | 4 | 100.0% | — |
| region_0043 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0043 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0044 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0044 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0044 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0044 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0044 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0045 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0045 | Macrophage / monocyte labels · myeloid | 3 | 5 | 92.6% | — |
| region_0045 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0045 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0045 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0046 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0046 | Macrophage / monocyte labels · myeloid | 1 | 1 | 84.2% | — |
| region_0046 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0046 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0046 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0047 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0047 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0047 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0047 | Prior T labels · Cd4 | 5 | 0 | — | — |
| region_0047 | Prior T labels · Cd8a / Cd8b1 | 5 | 0 | — | — |
| region_0048 | Pan-T supported, near macrophages · myeloid | 3 | 6 | 99.4% | — |
| region_0048 | Macrophage / monocyte labels · myeloid | 2 | 1 | 90.9% | — |
| region_0048 | Pan-T supported · pan-T markers | 3 | 4 | 100.0% | — |
| region_0048 | Prior T labels · Cd4 | 10 | 0 | — | — |
| region_0048 | Prior T labels · Cd8a / Cd8b1 | 10 | 1 | 100.0% | — |
| region_0049 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0049 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0049 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0049 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0049 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0050 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0050 | Macrophage / monocyte labels · myeloid | 5 | 1 | 100.0% | — |
| region_0050 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0050 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0050 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0051 | Pan-T supported, near macrophages · myeloid | 1 | 32 | 91.8% | — |
| region_0051 | Macrophage / monocyte labels · myeloid | 10 | 22 | 93.3% | — |
| region_0051 | Pan-T supported · pan-T markers | 1 | 2 | 100.0% | — |
| region_0051 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0051 | Prior T labels · Cd8a / Cd8b1 | 4 | 0 | — | — |
| region_0052 | Pan-T supported, near macrophages · myeloid | 2 | 17 | 91.6% | — |
| region_0052 | Macrophage / monocyte labels · myeloid | 15 | 66 | 86.9% | — |
| region_0052 | Pan-T supported · pan-T markers | 2 | 5 | 100.0% | — |
| region_0052 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0052 | Prior T labels · Cd8a / Cd8b1 | 4 | 3 | 100.0% | — |
| region_0053 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0053 | Macrophage / monocyte labels · myeloid | 8 | 38 | 98.7% | — |
| region_0053 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0053 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0053 | Prior T labels · Cd8a / Cd8b1 | 2 | 2 | 100.0% | — |
| region_0054 | Pan-T supported, near macrophages · myeloid | 3 | 45 | 51.8% | — |
| region_0054 | Macrophage / monocyte labels · myeloid | 23 | 149 | 59.8% | — |
| region_0054 | Pan-T supported · pan-T markers | 4 | 6 | 81.3% | — |
| region_0054 | Prior T labels · Cd4 | 8 | 0 | — | — |
| region_0054 | Prior T labels · Cd8a / Cd8b1 | 8 | 1 | 100.0% | — |
| region_0055 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0055 | Macrophage / monocyte labels · myeloid | 32 | 275 | 53.4% | — |
| region_0055 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0055 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0055 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0056 | Pan-T supported, near macrophages · myeloid | 1 | 8 | 56.0% | — |
| region_0056 | Macrophage / monocyte labels · myeloid | 8 | 38 | 68.5% | — |
| region_0056 | Pan-T supported · pan-T markers | 1 | 3 | 92.2% | — |
| region_0056 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0056 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0057 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0057 | Macrophage / monocyte labels · myeloid | 1 | 15 | 98.5% | — |
| region_0057 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0057 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0057 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0058 | Pan-T supported, near macrophages · myeloid | 2 | 5 | 100.0% | — |
| region_0058 | Macrophage / monocyte labels · myeloid | 3 | 4 | 100.0% | — |
| region_0058 | Pan-T supported · pan-T markers | 4 | 7 | 100.0% | — |
| region_0058 | Prior T labels · Cd4 | 22 | 2 | 91.8% | — |
| region_0058 | Prior T labels · Cd8a / Cd8b1 | 22 | 7 | 100.0% | — |
| region_0059 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0059 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0059 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0059 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0059 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0060 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0060 | Macrophage / monocyte labels · myeloid | 1 | 0 | — | — |
| region_0060 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0060 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0060 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0061 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0061 | Macrophage / monocyte labels · myeloid | 1 | 1 | 100.0% | — |
| region_0061 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0061 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0061 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0062 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0062 | Macrophage / monocyte labels · myeloid | 1 | 0 | — | — |
| region_0062 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0062 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0062 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0063 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0063 | Macrophage / monocyte labels · myeloid | 5 | 5 | 75.6% | — |
| region_0063 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0063 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0063 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0064 | Pan-T supported, near macrophages · myeloid | 1 | 13 | 73.0% | — |
| region_0064 | Macrophage / monocyte labels · myeloid | 10 | 54 | 60.6% | — |
| region_0064 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0064 | Prior T labels · Cd4 | 9 | 0 | — | — |
| region_0064 | Prior T labels · Cd8a / Cd8b1 | 9 | 2 | 100.0% | — |
| region_0065 | Pan-T supported, near macrophages · myeloid | 1 | 4 | 25.0% | — |
| region_0065 | Macrophage / monocyte labels · myeloid | 6 | 10 | 35.4% | — |
| region_0065 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0065 | Prior T labels · Cd4 | 6 | 0 | — | — |
| region_0065 | Prior T labels · Cd8a / Cd8b1 | 6 | 3 | 100.0% | — |
| region_0066 | Pan-T supported, near macrophages · myeloid | 1 | 8 | 100.0% | — |
| region_0066 | Macrophage / monocyte labels · myeloid | 5 | 18 | 100.0% | — |
| region_0066 | Pan-T supported · pan-T markers | 3 | 3 | 100.0% | — |
| region_0066 | Prior T labels · Cd4 | 11 | 0 | — | — |
| region_0066 | Prior T labels · Cd8a / Cd8b1 | 11 | 0 | — | — |
| region_0067 | Pan-T supported, near macrophages · myeloid | 2 | 6 | 100.0% | — |
| region_0067 | Macrophage / monocyte labels · myeloid | 5 | 20 | 100.0% | — |
| region_0067 | Pan-T supported · pan-T markers | 2 | 1 | 100.0% | — |
| region_0067 | Prior T labels · Cd4 | 22 | 0 | — | — |
| region_0067 | Prior T labels · Cd8a / Cd8b1 | 22 | 5 | 100.0% | — |
| region_0068 | Pan-T supported, near macrophages · myeloid | 2 | 6 | 93.3% | — |
| region_0068 | Macrophage / monocyte labels · myeloid | 26 | 150 | 84.1% | — |
| region_0068 | Pan-T supported · pan-T markers | 2 | 4 | 100.0% | — |
| region_0068 | Prior T labels · Cd4 | 9 | 0 | — | — |
| region_0068 | Prior T labels · Cd8a / Cd8b1 | 9 | 3 | 100.0% | — |
| region_0069 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0069 | Macrophage / monocyte labels · myeloid | 13 | 68 | 74.4% | — |
| region_0069 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0069 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0069 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0070 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0070 | Macrophage / monocyte labels · myeloid | 8 | 25 | 86.9% | — |
| region_0070 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0070 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0070 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0071 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0071 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0071 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0071 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0071 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0072 | Pan-T supported, near macrophages · myeloid | 3 | 8 | 91.1% | — |
| region_0072 | Macrophage / monocyte labels · myeloid | 3 | 2 | 88.8% | — |
| region_0072 | Pan-T supported · pan-T markers | 4 | 8 | 100.0% | — |
| region_0072 | Prior T labels · Cd4 | 11 | 0 | — | — |
| region_0072 | Prior T labels · Cd8a / Cd8b1 | 11 | 0 | — | — |
| region_0073 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0073 | Macrophage / monocyte labels · myeloid | 2 | 0 | — | — |
| region_0073 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0073 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0073 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0074 | Pan-T supported, near macrophages · myeloid | 2 | 3 | 100.0% | — |
| region_0074 | Macrophage / monocyte labels · myeloid | 3 | 0 | — | — |
| region_0074 | Pan-T supported · pan-T markers | 3 | 3 | 100.0% | — |
| region_0074 | Prior T labels · Cd4 | 9 | 5 | 100.0% | — |
| region_0074 | Prior T labels · Cd8a / Cd8b1 | 9 | 0 | — | — |
| region_0075 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0075 | Macrophage / monocyte labels · myeloid | 3 | 1 | 100.0% | — |
| region_0075 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0075 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0075 | Prior T labels · Cd8a / Cd8b1 | 4 | 0 | — | — |
| region_0076 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0076 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0076 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0076 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0076 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0077 | Pan-T supported, near macrophages · myeloid | 2 | 23 | 70.6% | — |
| region_0077 | Macrophage / monocyte labels · myeloid | 10 | 70 | 68.2% | — |
| region_0077 | Pan-T supported · pan-T markers | 2 | 3 | 100.0% | — |
| region_0077 | Prior T labels · Cd4 | 10 | 0 | — | — |
| region_0077 | Prior T labels · Cd8a / Cd8b1 | 10 | 0 | — | — |
| region_0078 | Pan-T supported, near macrophages · myeloid | 7 | 62 | 51.6% | — |
| region_0078 | Macrophage / monocyte labels · myeloid | 8 | 28 | 61.4% | — |
| region_0078 | Pan-T supported · pan-T markers | 11 | 22 | 89.0% | — |
| region_0078 | Prior T labels · Cd4 | 26 | 2 | 100.0% | — |
| region_0078 | Prior T labels · Cd8a / Cd8b1 | 26 | 10 | 100.0% | — |
| region_0079 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0079 | Macrophage / monocyte labels · myeloid | 1 | 0 | — | — |
| region_0079 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0079 | Prior T labels · Cd4 | 6 | 0 | — | — |
| region_0079 | Prior T labels · Cd8a / Cd8b1 | 6 | 0 | — | — |
| region_0080 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0080 | Macrophage / monocyte labels · myeloid | 2 | 1 | 73.4% | — |
| region_0080 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0080 | Prior T labels · Cd4 | 7 | 0 | — | — |
| region_0080 | Prior T labels · Cd8a / Cd8b1 | 7 | 0 | — | — |
| region_0081 | Pan-T supported, near macrophages · myeloid | 1 | 8 | 87.5% | — |
| region_0081 | Macrophage / monocyte labels · myeloid | 3 | 18 | 85.8% | — |
| region_0081 | Pan-T supported · pan-T markers | 6 | 7 | 100.0% | — |
| region_0081 | Prior T labels · Cd4 | 16 | 0 | — | — |
| region_0081 | Prior T labels · Cd8a / Cd8b1 | 16 | 5 | 100.0% | — |
| region_0082 | Pan-T supported, near macrophages · myeloid | 3 | 32 | 73.8% | — |
| region_0082 | Macrophage / monocyte labels · myeloid | 12 | 78 | 70.4% | — |
| region_0082 | Pan-T supported · pan-T markers | 4 | 6 | 100.0% | — |
| region_0082 | Prior T labels · Cd4 | 12 | 1 | 100.0% | — |
| region_0082 | Prior T labels · Cd8a / Cd8b1 | 12 | 3 | 100.0% | — |
| region_0083 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0083 | Macrophage / monocyte labels · myeloid | 13 | 62 | 60.2% | — |
| region_0083 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0083 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0083 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0084 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0084 | Macrophage / monocyte labels · myeloid | 10 | 18 | 90.5% | — |
| region_0084 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0084 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0084 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0085 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0085 | Macrophage / monocyte labels · myeloid | 1 | 1 | 54.7% | — |
| region_0085 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0085 | Prior T labels · Cd4 | 4 | 0 | — | — |
| region_0085 | Prior T labels · Cd8a / Cd8b1 | 4 | 0 | — | — |
| region_0086 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0086 | Macrophage / monocyte labels · myeloid | 2 | 1 | 100.0% | — |
| region_0086 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0086 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0086 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0087 | Pan-T supported, near macrophages · myeloid | 1 | 1 | 59.8% | — |
| region_0087 | Macrophage / monocyte labels · myeloid | 3 | 3 | 97.4% | — |
| region_0087 | Pan-T supported · pan-T markers | 1 | 2 | 100.0% | — |
| region_0087 | Prior T labels · Cd4 | 10 | 0 | — | — |
| region_0087 | Prior T labels · Cd8a / Cd8b1 | 10 | 0 | — | — |
| region_0088 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0088 | Macrophage / monocyte labels · myeloid | 5 | 1 | 100.0% | — |
| region_0088 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0088 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0088 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0089 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0089 | Macrophage / monocyte labels · myeloid | 4 | 1 | 91.2% | — |
| region_0089 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0089 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0089 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0090 | Pan-T supported, near macrophages · myeloid | 3 | 47 | 100.0% | — |
| region_0090 | Macrophage / monocyte labels · myeloid | 20 | 156 | 100.0% | — |
| region_0090 | Pan-T supported · pan-T markers | 4 | 5 | 100.0% | — |
| region_0090 | Prior T labels · Cd4 | 11 | 0 | — | — |
| region_0090 | Prior T labels · Cd8a / Cd8b1 | 11 | 1 | 100.0% | — |
| region_0091 | Pan-T supported, near macrophages · myeloid | 1 | 3 | 78.2% | — |
| region_0091 | Macrophage / monocyte labels · myeloid | 4 | 37 | 72.0% | — |
| region_0091 | Pan-T supported · pan-T markers | 6 | 9 | 100.0% | — |
| region_0091 | Prior T labels · Cd4 | 5 | 0 | — | — |
| region_0091 | Prior T labels · Cd8a / Cd8b1 | 5 | 2 | 100.0% | — |
| region_0092 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0092 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0092 | Pan-T supported · pan-T markers | 1 | 3 | 100.0% | — |
| region_0092 | Prior T labels · Cd4 | 6 | 0 | — | — |
| region_0092 | Prior T labels · Cd8a / Cd8b1 | 6 | 0 | — | — |
| region_0093 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0093 | Macrophage / monocyte labels · myeloid | 2 | 1 | 78.0% | — |
| region_0093 | Pan-T supported · pan-T markers | 1 | 3 | 100.0% | — |
| region_0093 | Prior T labels · Cd4 | 8 | 0 | — | — |
| region_0093 | Prior T labels · Cd8a / Cd8b1 | 8 | 0 | — | — |
| region_0094 | Pan-T supported, near macrophages · myeloid | 2 | 3 | 100.0% | — |
| region_0094 | Macrophage / monocyte labels · myeloid | 2 | 4 | 100.0% | — |
| region_0094 | Pan-T supported · pan-T markers | 8 | 10 | 100.0% | — |
| region_0094 | Prior T labels · Cd4 | 8 | 0 | — | — |
| region_0094 | Prior T labels · Cd8a / Cd8b1 | 8 | 1 | 100.0% | — |
| region_0095 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0095 | Macrophage / monocyte labels · myeloid | 7 | 20 | 46.1% | — |
| region_0095 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0095 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0095 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0096 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0096 | Macrophage / monocyte labels · myeloid | 4 | 8 | 76.4% | — |
| region_0096 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0096 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0096 | Prior T labels · Cd8a / Cd8b1 | 2 | 1 | 100.0% | — |
| region_0097 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0097 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0097 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0097 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0097 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0098 | Pan-T supported, near macrophages · myeloid | 1 | 1 | 60.1% | — |
| region_0098 | Macrophage / monocyte labels · myeloid | 1 | 7 | 72.1% | — |
| region_0098 | Pan-T supported · pan-T markers | 4 | 6 | 99.0% | — |
| region_0098 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0098 | Prior T labels · Cd8a / Cd8b1 | 3 | 2 | 100.0% | — |
| region_0099 | Pan-T supported, near macrophages · myeloid | 5 | 19 | 53.0% | — |
| region_0099 | Macrophage / monocyte labels · myeloid | 5 | 9 | 71.4% | — |
| region_0099 | Pan-T supported · pan-T markers | 7 | 13 | 97.3% | — |
| region_0099 | Prior T labels · Cd4 | 18 | 0 | — | — |
| region_0099 | Prior T labels · Cd8a / Cd8b1 | 18 | 5 | 95.1% | — |
| region_0100 | Pan-T supported, near macrophages · myeloid | 1 | 0 | — | — |
| region_0100 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0100 | Pan-T supported · pan-T markers | 3 | 5 | 100.0% | — |
| region_0100 | Prior T labels · Cd4 | 3 | 1 | 100.0% | — |
| region_0100 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0101 | Pan-T supported, near macrophages · myeloid | 3 | 2 | 88.7% | — |
| region_0101 | Macrophage / monocyte labels · myeloid | 4 | 2 | 99.9% | — |
| region_0101 | Pan-T supported · pan-T markers | 3 | 5 | 100.0% | — |
| region_0101 | Prior T labels · Cd4 | 10 | 0 | — | — |
| region_0101 | Prior T labels · Cd8a / Cd8b1 | 10 | 1 | 100.0% | — |
| region_0102 | Pan-T supported, near macrophages · myeloid | 1 | 3 | 50.4% | — |
| region_0102 | Macrophage / monocyte labels · myeloid | 8 | 8 | 96.0% | — |
| region_0102 | Pan-T supported · pan-T markers | 1 | 0 | — | — |
| region_0102 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0102 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0103 | Pan-T supported, near macrophages · myeloid | 1 | 10 | 100.0% | — |
| region_0103 | Macrophage / monocyte labels · myeloid | 16 | 156 | 100.0% | — |
| region_0103 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0103 | Prior T labels · Cd4 | 7 | 0 | — | — |
| region_0103 | Prior T labels · Cd8a / Cd8b1 | 7 | 0 | — | — |
| region_0104 | Pan-T supported, near macrophages · myeloid | 1 | 9 | 16.2% | — |
| region_0104 | Macrophage / monocyte labels · myeloid | 1 | 0 | — | — |
| region_0104 | Pan-T supported · pan-T markers | 1 | 6 | 100.0% | — |
| region_0104 | Prior T labels · Cd4 | 8 | 0 | — | — |
| region_0104 | Prior T labels · Cd8a / Cd8b1 | 8 | 0 | — | — |
| region_0105 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0105 | Macrophage / monocyte labels · myeloid | 1 | 0 | — | — |
| region_0105 | Pan-T supported · pan-T markers | 3 | 6 | 100.0% | — |
| region_0105 | Prior T labels · Cd4 | 9 | 0 | — | — |
| region_0105 | Prior T labels · Cd8a / Cd8b1 | 9 | 1 | 100.0% | — |
| region_0106 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0106 | Macrophage / monocyte labels · myeloid | 1 | 1 | 0.0% | — |
| region_0106 | Pan-T supported · pan-T markers | 9 | 9 | 100.0% | — |
| region_0106 | Prior T labels · Cd4 | 13 | 0 | — | — |
| region_0106 | Prior T labels · Cd8a / Cd8b1 | 13 | 2 | 100.0% | — |
| region_0107 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0107 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0107 | Pan-T supported · pan-T markers | 9 | 12 | 100.0% | — |
| region_0107 | Prior T labels · Cd4 | 10 | 0 | — | — |
| region_0107 | Prior T labels · Cd8a / Cd8b1 | 10 | 6 | 100.0% | — |
| region_0108 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0108 | Macrophage / monocyte labels · myeloid | 9 | 63 | 77.9% | — |
| region_0108 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0108 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0108 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0109 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0109 | Macrophage / monocyte labels · myeloid | 1 | 2 | 0.0% | — |
| region_0109 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0109 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0109 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0110 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0110 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0110 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0110 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0110 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0111 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0111 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0111 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0111 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0111 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0112 | Pan-T supported, near macrophages · myeloid | 7 | 13 | 71.0% | — |
| region_0112 | Macrophage / monocyte labels · myeloid | 3 | 8 | 51.3% | — |
| region_0112 | Pan-T supported · pan-T markers | 11 | 30 | 98.9% | — |
| region_0112 | Prior T labels · Cd4 | 16 | 0 | — | — |
| region_0112 | Prior T labels · Cd8a / Cd8b1 | 16 | 2 | 100.0% | — |
| region_0113 | Pan-T supported, near macrophages · myeloid | 2 | 2 | 50.7% | — |
| region_0113 | Macrophage / monocyte labels · myeloid | 5 | 5 | 88.5% | — |
| region_0113 | Pan-T supported · pan-T markers | 2 | 3 | 100.0% | — |
| region_0113 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0113 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0114 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0114 | Macrophage / monocyte labels · myeloid | 6 | 8 | 100.0% | — |
| region_0114 | Pan-T supported · pan-T markers | 1 | 1 | 77.7% | — |
| region_0114 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0114 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0115 | Pan-T supported, near macrophages · myeloid | 1 | 3 | 31.0% | — |
| region_0115 | Macrophage / monocyte labels · myeloid | 2 | 3 | 96.4% | — |
| region_0115 | Pan-T supported · pan-T markers | 2 | 3 | 86.4% | — |
| region_0115 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0115 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0116 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0116 | Macrophage / monocyte labels · myeloid | 19 | 115 | 95.3% | — |
| region_0116 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0116 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0116 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0117 | Pan-T supported, near macrophages · myeloid | 1 | 3 | 41.3% | — |
| region_0117 | Macrophage / monocyte labels · myeloid | 1 | 4 | 80.9% | — |
| region_0117 | Pan-T supported · pan-T markers | 2 | 2 | 100.0% | — |
| region_0117 | Prior T labels · Cd4 | 8 | 0 | — | — |
| region_0117 | Prior T labels · Cd8a / Cd8b1 | 8 | 1 | 100.0% | — |
| region_0118 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0118 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0118 | Pan-T supported · pan-T markers | 4 | 6 | 100.0% | — |
| region_0118 | Prior T labels · Cd4 | 10 | 0 | — | — |
| region_0118 | Prior T labels · Cd8a / Cd8b1 | 10 | 1 | 100.0% | — |
| region_0119 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0119 | Macrophage / monocyte labels · myeloid | 1 | 8 | 100.0% | — |
| region_0119 | Pan-T supported · pan-T markers | 6 | 8 | 100.0% | — |
| region_0119 | Prior T labels · Cd4 | 11 | 0 | — | — |
| region_0119 | Prior T labels · Cd8a / Cd8b1 | 11 | 0 | — | — |
| region_0120 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0120 | Macrophage / monocyte labels · myeloid | 4 | 17 | 60.2% | — |
| region_0120 | Pan-T supported · pan-T markers | 1 | 0 | — | — |
| region_0120 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0120 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0121 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0121 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0121 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0121 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0121 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0122 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0122 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0122 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0122 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0122 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0123 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0123 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0123 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0123 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0123 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0124 | Pan-T supported, near macrophages · myeloid | 2 | 7 | 33.2% | — |
| region_0124 | Macrophage / monocyte labels · myeloid | 3 | 22 | 83.4% | — |
| region_0124 | Pan-T supported · pan-T markers | 3 | 4 | 96.0% | — |
| region_0124 | Prior T labels · Cd4 | 14 | 1 | 100.0% | — |
| region_0124 | Prior T labels · Cd8a / Cd8b1 | 14 | 2 | 89.8% | — |
| region_0125 | Pan-T supported, near macrophages · myeloid | 2 | 5 | 74.5% | — |
| region_0125 | Macrophage / monocyte labels · myeloid | 3 | 7 | 53.9% | — |
| region_0125 | Pan-T supported · pan-T markers | 3 | 2 | 100.0% | — |
| region_0125 | Prior T labels · Cd4 | 8 | 0 | — | — |
| region_0125 | Prior T labels · Cd8a / Cd8b1 | 8 | 2 | 100.0% | — |
| region_0126 | Pan-T supported, near macrophages · myeloid | 5 | 12 | 56.2% | — |
| region_0126 | Macrophage / monocyte labels · myeloid | 10 | 55 | 82.2% | — |
| region_0126 | Pan-T supported · pan-T markers | 6 | 7 | 99.8% | — |
| region_0126 | Prior T labels · Cd4 | 11 | 0 | — | — |
| region_0126 | Prior T labels · Cd8a / Cd8b1 | 11 | 1 | 78.5% | — |
| region_0127 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0127 | Macrophage / monocyte labels · myeloid | 2 | 14 | 97.6% | — |
| region_0127 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0127 | Prior T labels · Cd4 | 2 | 0 | — | — |
| region_0127 | Prior T labels · Cd8a / Cd8b1 | 2 | 0 | — | — |
| region_0128 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0128 | Macrophage / monocyte labels · myeloid | 3 | 16 | 94.8% | — |
| region_0128 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0128 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0128 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0129 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0129 | Macrophage / monocyte labels · myeloid | 4 | 26 | 59.3% | — |
| region_0129 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0129 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0129 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0130 | Pan-T supported, near macrophages · myeloid | 1 | 10 | 47.2% | — |
| region_0130 | Macrophage / monocyte labels · myeloid | 5 | 34 | 76.8% | — |
| region_0130 | Pan-T supported · pan-T markers | 1 | 2 | 100.0% | — |
| region_0130 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0130 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0131 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0131 | Macrophage / monocyte labels · myeloid | 3 | 28 | 50.1% | — |
| region_0131 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0131 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0131 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0132 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0132 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0132 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0132 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0132 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0133 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0133 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0133 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0133 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0133 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0134 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0134 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0134 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0134 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0134 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0135 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0135 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0135 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0135 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0135 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0136 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0136 | Macrophage / monocyte labels · myeloid | 1 | 1 | 100.0% | — |
| region_0136 | Pan-T supported · pan-T markers | 1 | 1 | 100.0% | — |
| region_0136 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0136 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0137 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0137 | Macrophage / monocyte labels · myeloid | 4 | 14 | 92.8% | — |
| region_0137 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0137 | Prior T labels · Cd4 | 10 | 0 | — | — |
| region_0137 | Prior T labels · Cd8a / Cd8b1 | 10 | 2 | 98.7% | — |
| region_0138 | Pan-T supported, near macrophages · myeloid | 1 | 0 | — | — |
| region_0138 | Macrophage / monocyte labels · myeloid | 3 | 4 | 99.3% | — |
| region_0138 | Pan-T supported · pan-T markers | 2 | 4 | 100.0% | — |
| region_0138 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0138 | Prior T labels · Cd8a / Cd8b1 | 3 | 2 | 100.0% | — |
| region_0139 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0139 | Macrophage / monocyte labels · myeloid | 4 | 4 | 91.5% | — |
| region_0139 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0139 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0139 | Prior T labels · Cd8a / Cd8b1 | 1 | 0 | — | — |
| region_0140 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0140 | Macrophage / monocyte labels · myeloid | 3 | 9 | 84.0% | — |
| region_0140 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0140 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0140 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0141 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0141 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0141 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0141 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0141 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0142 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0142 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0142 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0142 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0142 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0143 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0143 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0143 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0143 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0143 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0144 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0144 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0144 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0144 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0144 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0145 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0145 | Macrophage / monocyte labels · myeloid | 1 | 2 | 56.1% | — |
| region_0145 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0145 | Prior T labels · Cd4 | 3 | 0 | — | — |
| region_0145 | Prior T labels · Cd8a / Cd8b1 | 3 | 0 | — | — |
| region_0146 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0146 | Macrophage / monocyte labels · myeloid | 4 | 20 | 93.7% | — |
| region_0146 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0146 | Prior T labels · Cd4 | 1 | 0 | — | — |
| region_0146 | Prior T labels · Cd8a / Cd8b1 | 1 | 1 | 100.0% | — |
| region_0147 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0147 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0147 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0147 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0147 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0148 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0148 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0148 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0148 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0148 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0149 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0149 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0149 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0149 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0149 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0150 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0150 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0150 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0150 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0150 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |
| region_0151 | Pan-T supported, near macrophages · myeloid | 0 | — | — | — |
| region_0151 | Macrophage / monocyte labels · myeloid | 0 | — | — | — |
| region_0151 | Pan-T supported · pan-T markers | 0 | — | — | — |
| region_0151 | Prior T labels · Cd4 | 0 | — | — | — |
| region_0151 | Prior T labels · Cd8a / Cd8b1 | 0 | — | — | — |

## Across regions

The pooled table sums observed and corrected counts across nonoverlapping regions with both fits available for the same gene panel. It reports its contributing regions and cell count. A region with more observed UMIs contributes more to the pooled fraction. These are selected regions within a specimen, so variation across them is descriptive.


## Interpretation

Read the first two rows of each region together. Loss of myeloid counts in nearby pan-T-supported cells is more persuasive when macrophage markers are retained in the same fit. These observations alone cannot assign the true source of an individual transcript.

The edge sensitivity table repeats the group counts and retention estimates for centroids within one SPARKLE donor radius of the crop border and for centroids whose full radius lies inside the window. Inspect the group sizes when comparing these two subsets (edge_sensitivity.csv).

Marker gene coverage records each gene’s fit status and observed counts in assigned and unassigned squares. An unchanged SPARKLE panel can reflect genes that failed the fit threshold. The coreceptor score table measures observed Cd4, Cd8a and Cd8b1 by mask assignment and H&E score in the inner core.

## Model availability

- region_0001 · spotclean unavailable
- region_0002 · spotclean unavailable
- region_0003 · spotclean unavailable
- region_0004 · spotclean unavailable
- region_0005 · spotclean unavailable
- region_0006 · spotclean unavailable
- region_0007 · spotclean unavailable
- region_0008 · spotclean unavailable
- region_0009 · spotclean unavailable
- region_0010 · spotclean unavailable
- region_0011 · spotclean unavailable
- region_0012 · spotclean unavailable
- region_0013 · spotclean unavailable
- region_0014 · spotclean unavailable
- region_0015 · spotclean unavailable
- region_0016 · spotclean unavailable
- region_0017 · spotclean unavailable
- region_0018 · spotclean unavailable
- region_0019 · spotclean unavailable
- region_0020 · spotclean unavailable
- region_0021 · spotclean unavailable
- region_0022 · spotclean unavailable
- region_0023 · spotclean unavailable
- region_0024 · spotclean unavailable
- region_0025 · spotclean unavailable
- region_0026 · spotclean unavailable
- region_0027 · spotclean unavailable
- region_0028 · spotclean unavailable
- region_0029 · spotclean unavailable
- region_0030 · spotclean unavailable
- region_0031 · spotclean unavailable
- region_0032 · spotclean unavailable
- region_0033 · spotclean unavailable
- region_0034 · spotclean unavailable
- region_0035 · spotclean unavailable
- region_0036 · spotclean unavailable
- region_0037 · spotclean unavailable
- region_0038 · spotclean unavailable
- region_0039 · spotclean unavailable
- region_0040 · spotclean unavailable
- region_0041 · spotclean unavailable
- region_0042 · spotclean unavailable
- region_0043 · spotclean unavailable
- region_0044 · spotclean unavailable
- region_0045 · spotclean unavailable
- region_0046 · spotclean unavailable
- region_0047 · spotclean unavailable
- region_0048 · spotclean unavailable
- region_0049 · spotclean unavailable
- region_0050 · spotclean unavailable
- region_0051 · spotclean unavailable
- region_0052 · spotclean unavailable
- region_0053 · spotclean unavailable
- region_0054 · spotclean unavailable
- region_0055 · spotclean unavailable
- region_0056 · spotclean unavailable
- region_0057 · spotclean unavailable
- region_0058 · spotclean unavailable
- region_0059 · spotclean unavailable
- region_0060 · spotclean unavailable
- region_0061 · spotclean unavailable
- region_0062 · spotclean unavailable
- region_0063 · spotclean unavailable
- region_0064 · spotclean unavailable
- region_0065 · spotclean unavailable
- region_0066 · spotclean unavailable
- region_0067 · spotclean unavailable
- region_0068 · spotclean unavailable
- region_0069 · spotclean unavailable
- region_0070 · spotclean unavailable
- region_0071 · spotclean unavailable
- region_0072 · spotclean unavailable
- region_0073 · spotclean unavailable
- region_0074 · spotclean unavailable
- region_0075 · spotclean unavailable
- region_0076 · spotclean unavailable
- region_0077 · spotclean unavailable
- region_0078 · spotclean unavailable
- region_0079 · spotclean unavailable
- region_0080 · spotclean unavailable
- region_0081 · spotclean unavailable
- region_0082 · spotclean unavailable
- region_0083 · spotclean unavailable
- region_0084 · spotclean unavailable
- region_0085 · spotclean unavailable
- region_0086 · spotclean unavailable
- region_0087 · spotclean unavailable
- region_0088 · spotclean unavailable
- region_0089 · spotclean unavailable
- region_0090 · spotclean unavailable
- region_0091 · spotclean unavailable
- region_0092 · spotclean unavailable
- region_0093 · spotclean unavailable
- region_0094 · spotclean unavailable
- region_0095 · spotclean unavailable
- region_0096 · spotclean unavailable
- region_0097 · spotclean unavailable
- region_0098 · spotclean unavailable
- region_0099 · spotclean unavailable
- region_0100 · spotclean unavailable
- region_0101 · spotclean unavailable
- region_0102 · spotclean unavailable
- region_0103 · spotclean unavailable
- region_0104 · spotclean unavailable
- region_0105 · spotclean unavailable
- region_0106 · spotclean unavailable
- region_0107 · spotclean unavailable
- region_0108 · spotclean unavailable
- region_0109 · spotclean unavailable
- region_0110 · sparkle unavailable
- region_0110 · spotclean unavailable
- region_0111 · spotclean unavailable
- region_0112 · spotclean unavailable
- region_0113 · spotclean unavailable
- region_0114 · spotclean unavailable
- region_0115 · spotclean unavailable
- region_0116 · spotclean unavailable
- region_0117 · spotclean unavailable
- region_0118 · spotclean unavailable
- region_0119 · spotclean unavailable
- region_0120 · spotclean unavailable
- region_0121 · spotclean unavailable
- region_0122 · sparkle unavailable
- region_0122 · spotclean unavailable
- region_0123 · sparkle unavailable
- region_0123 · spotclean unavailable
- region_0124 · spotclean unavailable
- region_0125 · spotclean unavailable
- region_0126 · spotclean unavailable
- region_0127 · spotclean unavailable
- region_0128 · spotclean unavailable
- region_0129 · spotclean unavailable
- region_0130 · spotclean unavailable
- region_0131 · spotclean unavailable
- region_0132 · spotclean unavailable
- region_0133 · sparkle unavailable
- region_0133 · spotclean unavailable
- region_0134 · sparkle unavailable
- region_0134 · spotclean unavailable
- region_0135 · spotclean unavailable
- region_0136 · spotclean unavailable
- region_0137 · spotclean unavailable
- region_0138 · spotclean unavailable
- region_0139 · spotclean unavailable
- region_0140 · spotclean unavailable
- region_0141 · spotclean unavailable
- region_0142 · spotclean unavailable
- region_0143 · sparkle unavailable
- region_0143 · spotclean unavailable
- region_0144 · sparkle unavailable
- region_0144 · spotclean unavailable
- region_0145 · spotclean unavailable
- region_0146 · spotclean unavailable
- region_0147 · spotclean unavailable
- region_0148 · spotclean unavailable
- region_0149 · sparkle unavailable
- region_0149 · spotclean unavailable
- region_0150 · sparkle unavailable
- region_0150 · spotclean unavailable
- region_0151 · sparkle unavailable
- region_0151 · spotclean unavailable
