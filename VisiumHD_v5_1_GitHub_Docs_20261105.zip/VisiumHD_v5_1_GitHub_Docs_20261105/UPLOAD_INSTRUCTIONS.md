# Add the documentation to your internal repository

1. Extract this ZIP on your computer. Do not upload only the ZIP if the goal is in-browser reading.
2. Copy its `docs/visiumhd/` directory into your repository, preserving all subdirectories. Review existing files first; this directory is not intended to replace your repository's other documentation.
3. Add the text from `README_SNIPPET.md` to your existing **repository-root** `README.md`. Do not replace the rest of your README. If that README lives elsewhere, adjust the relative path accordingly.
4. Commit/upload the new files through your normal internal GitHub process, then click the documentation link in the rendered README. Open the Markdown Preview/rendered view rather than Raw/Code.

The paths are relative; no internal hostname, organization or repository name needs to be substituted. No GitHub Pages site, external HTML preview service, browser-security change or new pipeline dependency is required. Source snapshots are reference-only, not installation code. The PDF is optional; all primary documentation works without it.

```text
repository/
├── README.md                     # retain your existing content; add the snippet
└── docs/
    └── visiumhd/
        ├── README.md             # documentation landing page
        ├── PIPELINE_HANDBOOK.md
        ├── MODULE_INDEX.md
        ├── MODULE_REFERENCE.md
        ├── SOURCE_INDEX.md
        ├── VisiumHD_v5_1_Handbook.pdf
        ├── metadata_examples/
        └── source_snapshot/      # retain to preserve versioned code references
```

This package was prepared locally; no private/internal repository was accessed or changed. In-repository rendering must still be confirmed on your organization's instance.
