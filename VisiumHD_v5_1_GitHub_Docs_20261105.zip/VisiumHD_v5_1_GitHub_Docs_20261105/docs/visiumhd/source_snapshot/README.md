# Documentation source snapshot

**Reference only. Do not install or execute this directory as a pipeline.**

These files replace the exact-source HTML browser from the November 4 handbook. They preserve the audited source bytes and line numbers so documentation links remain tied to the stated baseline, regardless of where this documentation folder is placed in the repository.

See the [source index](../SOURCE_INDEX.md), [module reference](../MODULE_REFERENCE.md), and [documented baseline](../PIPELINE_HANDBOOK.md).
