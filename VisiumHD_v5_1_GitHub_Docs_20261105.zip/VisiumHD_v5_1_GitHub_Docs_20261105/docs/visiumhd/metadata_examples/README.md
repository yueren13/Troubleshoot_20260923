# Metadata input examples — documentation only

These examples restore an explicit metadata demonstration for v5.1. They do not replace your installed example catalog or change a current Project Center. Sample names, values and /data paths are invented.

## 01_inline_sample_metadata

In **Create a new project from sample and asset sheets**, select `samples.csv` here. Leave the optional asset field blank (or use the supplied header-only assets.csv). Leave Metadata CSV blank. Optional profile: `profile.json`. Choose your own existing approved output root and a new controller workspace.

All extra columns are descriptors. Species is handled specially by the reader; treatment, donor_id and timepoint become sample metadata. Strings such as 001 remain text. Replace the illustrative input paths before scientific execution.

## 02_separate_metadata_csv

Select this folder's `samples.csv`. Set **Metadata CSV (optional)** to this folder's `sample_metadata.csv` and **Metadata ID column** to `Sample`. The IDs must exactly match the sample IDs. Optional asset/profile/output controls are as above.

The table is joined by ID, never by row order. Default descriptor types are strings, including baseline_tumor_volume_mm3. Blank separate-CSV values become missing by default. Duplicate keys, missing required sample matches and conflicting repeated descriptors fail. Do not duplicate a field in both sheets unnecessarily.

## 03_typed_full_config_reference

`settings_fragment.json` is NOT a complete profile or complete settings file. It illustrates the existing full configuration's `sample_metadata` section, including explicit float parsing of the source heading baseline_tumor_volume_mm3. Merge it into a reviewed full settings file before choosing **Import existing pipeline configuration**. Resolve its path relative to that full settings file.

The simple new-project metadata form currently supplies only the CSV path and ID heading. It does not expose the typed reader's full configuration, and its separate-CSV branch replaces that block rather than merging all typed options from the optional profile. Do not use this fragment as a workaround in a live managed workspace.

## Empty template

`sample_metadata.template.csv` contains the same headings without invented sample records. You can change the descriptive headings, provided they do not collide with protected pipeline columns. Sample IDs should be unique for the ordinary new-project join.

## Existing workspace

Opening an existing center restores saved metadata values. It does not live-rejoin an edited original CSV. The current UI has no general metadata-update panel. Never edit the managed engine CSVs or project_state.json to force an update.
