# Documentation source audit

Date: November 4, 2026. This is a documentation inspection, not a new scientific run.

- Base ZIP SHA-256: `bcfffae8c0781c542ef34427f8172ab5e4a14a2b619dc5437bc9f440d8cd1ff6`.
- Scoped-fix ZIP SHA-256: `e4410bf10c14405e16d31cec56d391f6eb5d6307c998c4b304d147b5682ada3c`.
- The fix installer was applied only to an isolated extraction under the documentation working directory. Original ZIPs and the user's installed code/data were not changed.
- 86 production Python modules, 13 tools files and one CLI file were indexed, including namespace initializers and a tool-local regression module.
- `source_inventory.json` contains exact documented module hashes, definitions and static import relationships.
- Inline sample metadata and separate CSV joins both remain implemented. The earlier dedicated metadata example was absent from the consolidated catalog; the catalog instead embeds descriptors in the sample sheets.
- Simple metadata form: path + ID heading and default strings. Advanced full configuration: selected columns, explicit types, renames and composite join options.
- No new general metadata editor, scientific algorithm or approval path was installed by producing this handbook.

## vhd/center/ui.py · lines 378–399

SHA-256: `91fde8983b404cc66ff30393abece278e00c60bc29ddb39b0c4eddd7e23375f0`

```text
378:     mode=W.Dropdown(options=[('Open an existing Project Center','open'),('Import existing pipeline configuration','import'),
379:                              ('Create a new project from sample and asset sheets','sheets')],value='sheets',description='Operation',style=style,layout=layout)
380:     workspace=W.Text(value=str(root.parent/'VisiumHD_Project_Center'),description='Controller workspace',style=style,layout=layout)
381:     title=W.Text(value='Visium HD Project Center',description='Project title',style=style,layout=layout)
382:     manifest=W.Text(value=str(default/'samples.csv'),description='Existing samples.csv',style=style,layout=layout)
383:     settings=W.Text(value=str(default/'settings.json'),description='Existing settings.json',style=style,layout=layout)
384:     sample_sheet=W.Text(value=str(root/'examples/new_project/samples.csv'),description='Sample sheet',style=style,layout=layout)
385:     asset_sheet=W.Text(value=str(root/'examples/new_project/assets.csv'),description='Asset sheet (optional)',style=style,layout=layout)
386:     output_root=W.Text(value='',description='Approved output root',placeholder='Existing project directory; no mount is created',style=style,layout=layout)
387:     profile=W.Text(value='',description='Settings profile (optional)',style=style,layout=layout)
388:     run=W.Text(value='run01',description='New-project run ID',style=style,layout=layout)
389:     metadata=W.Text(value='',description='Metadata CSV (optional)',style=style,layout=layout)
390:     meta_id=W.Text(value='sample_id',description='Metadata ID column',style=style,layout=layout)
391:     import_box=W.VBox([manifest,settings]);new_box=W.VBox([sample_sheet,asset_sheet,metadata,meta_id,output_root,profile,run])
392:     consent=W.Checkbox(value=False,description='Create managed copies in this workspace; keep the original inputs unchanged.',indent=False)
393:     messages=W.Output();live=W.Output();button=W.Button(description='Open / create Project Center',button_style='primary',layout=W.Layout(width='auto'))
394:     busy={'value':False}
395:     def fields(change=None):
396:         import_box.layout.display='flex' if mode.value=='import' else 'none'
397:         new_box.layout.display='flex' if mode.value=='sheets' else 'none'
398:         consent.layout.display='none' if mode.value=='open' else 'flex'
399:         button.disabled=busy['value'] or (mode.value!='open' and not consent.value)
```

## vhd/center/importers.py · lines 153–171

SHA-256: `c830b7976f5eda4d070fde7077618ddb83bf110bbd9bee97b4d121018c27ab94`

```text
153:         meta={k:v for k,v in raw.items() if k not in recognized and v!=''}
154:         if raw.get('species'):meta['species']=raw['species']
155:         r['_sample_metadata']=meta;r['_sample_metadata_provenance']={'source':str(Path(samples).absolute()),'match':'sample_id','imported_at':now()}
156:         rows.append(r)
157:     if not rows or len({r['sample_key'] for r in rows})!=len(rows):raise ValueError('No enabled samples, or duplicate sample identities.')
158:     if metadata_table:
159:         from ..control.sample_metadata import resolve_project_metadata
160:         original=[dict(r.get('_sample_metadata',{})) for r in rows]
161:         config={'path':str(Path(metadata_table).absolute()),'sample_id_column':metadata_id_column}
162:         joined,join_report=resolve_project_metadata(rows,config,base)
163:         for r,old in zip(joined,original):
164:             for k,v in old.items():
165:                 if k in r['_sample_metadata'] and r['_sample_metadata'][k]!=v:
166:                     raise ValueError(f"{r['sample_id']}: conflicting metadata {k!r} between sample and metadata sheets.")
167:                 r['_sample_metadata'][k]=v
168:         rows=joined;cfg['sample_metadata']=config
169:     # Used only to snapshot a minimal settings profile. The caller supplies a workspace.
170:     return {'manifest_path':str(Path(samples).absolute()),'settings_path':str(Path(profile).absolute()) if profile else '',
171:             'rows':rows,'settings':cfg,'metadata_report':{'source':'sample_sheet_extra_columns','matched':len(rows)}}
```

## vhd/control/sample_metadata.py · lines 133–166

SHA-256: `c6fab7809ce0b6c66b80da5284232014bb4d3f42569b4b8f83f908fd98edb303`

```text
133: def read_metadata_csv(path, config=None):
134:     """Read and validate a table, retaining original headings unless renamed.
135: 
136:     Defaults: sample_id key, all non-key columns, string values, only empty cells
137:     considered missing. Explicit column types are keyed by the SOURCE heading.
138:     """
139:     config = copy.deepcopy(config or {})
140:     unknown = set(config) - OPTIONS
141:     if unknown:
142:         raise ValueError(f'Unknown sample_metadata options: {sorted(unknown)}')
143:     sid = config.get('sample_id_column', 'sample_id')
144:     did = config.get('dataset_id_column')
145:     skey = config.get('sample_key_column')
146:     if skey and (did or ('sample_id_column' in config and sid)):
147:         raise ValueError('Use sample_key_column OR sample_id_column (+ optional dataset_id_column).')
148:     keys = [skey] if skey else ([did, sid] if did else [sid])
149:     if any(not isinstance(k, str) or not k for k in keys) or len(set(keys)) != len(keys):
150:         raise ValueError('Supply distinct nonempty metadata join-column names.')
151:     raw_bytes = Path(path).read_bytes()
152:     if b'\x00' in raw_bytes:
153:         raise ValueError('Metadata CSV contains NUL bytes; export as CSV UTF-8, not UTF-16/Excel binary.')
154:     try:
155:         text = raw_bytes.decode('utf-8-sig')
156:     except UnicodeDecodeError as error:
157:         raise ValueError('Metadata CSV must be UTF-8 (Excel CSV UTF-8 is supported).') from error
158:     reader = csv.reader(io.StringIO(text, newline=''), strict=True)
159:     try:
160:         header = next(reader)
161:     except StopIteration:
162:         raise ValueError('Metadata CSV is empty.') from None
163:     if (not header or any(not h or h != h.strip() for h in header) or
164:             len(header) != len(set(header))):
165:         raise ValueError('Metadata CSV requires unique, nonblank headers without surrounding whitespace.')
166:     if set(keys) - set(header):
```

## vhd/control/sample_metadata.py · lines 178–192

SHA-256: `c6fab7809ce0b6c66b80da5284232014bb4d3f42569b4b8f83f908fd98edb303`

```text
178:     if not isinstance(rename, dict) or not isinstance(declared, dict):
179:         raise ValueError('sample_metadata.rename and types must be JSON objects.')
180:     if (set(rename) | set(declared)) - set(columns):
181:         raise ValueError('rename/types must refer to selected SOURCE columns, not output names.')
182:     outputs = [rename.get(c, c) for c in columns]
183:     for name in outputs:
184:         validate_field_name(name)
185:     if len(set(outputs)) != len(outputs):
186:         raise ValueError('Metadata column renaming creates duplicate output names.')
187:     default_type = config.get('default_type', 'string')
188:     if default_type not in TYPES or any(v not in TYPES for v in declared.values()):
189:         raise ValueError(f'Metadata types must be one of {sorted(TYPES)}.')
190:     missing = config.get('missing_values', [''])
191:     if not isinstance(missing, list) or any(not isinstance(v, str) for v in missing):
192:         raise ValueError('missing_values must be a list of exact text tokens.')
```

## vhd/control/sample_metadata.py · lines 261–310

SHA-256: `c6fab7809ce0b6c66b80da5284232014bb4d3f42569b4b8f83f908fd98edb303`

```text
261:     require = _boolean_option(config, 'require_all_samples', True)
262:     allow_extra = _boolean_option(config, 'allow_extra_samples', True)
263:     conflict = config.get('json_conflicts', 'error')
264:     if conflict not in ('error', 'csv_wins', 'json_wins'):
265:         raise ValueError('json_conflicts must be error, csv_wins or json_wins.')
266:     key_kind = ('sample_key' if config.get('sample_key_column') else
267:                 'composite' if config.get('dataset_id_column') else 'sample_id')
268:     used, out = set(), []
269:     simple_ids = [r['sample_id'] for r in rows]
270:     if path and key_kind == 'sample_id' and len(simple_ids) != len(set(simple_ids)):
271:         raise ValueError('Enabled samples repeat sample_id across datasets. Configure dataset_id_column '
272:                          'or sample_key_column, or use unique sample IDs; path names are not join keys.')
273:     for row in rows:
274:         key = ((row['sample_key'],) if key_kind == 'sample_key' else
275:                (row['dataset_id'], row['sample_id']) if key_kind == 'composite' else (row['sample_id'],))
276:         legacy, json_source = _json_metadata(row.get('metadata_json', ''))
277:         csv_values = values.get(key, {})
278:         overrides = []
279:         if path:
280:             if key in values:
281:                 used.add(key); report['matched_samples'].append(row['sample_key'])
282:             else:
283:                 report['missing_samples'].append(row['sample_key'])
284:         merged = dict(legacy)
285:         for name, value in csv_values.items():
286:             if name in merged and (merged[name] != value or
287:                     (isinstance(merged[name], bool) != isinstance(value, bool))):
288:                 if conflict == 'error':
289:                     raise ValueError(f"{row['sample_key']}: metadata conflict for {name!r} between CSV "
290:                                      "and metadata_json. Remove the duplicate source or explicitly set "
291:                                      "json_conflicts.")
292:                 overrides.append(name)
293:                 if conflict == 'json_wins':
294:                     continue
295:             merged[name] = value
296:         validate_values(merged)
297:         if json_source:
298:             report['n_json_samples'] += 1
299:         provenance = {
300:             'schema': SCHEMA_VERSION, 'sample_key': row['sample_key'],
301:             'metadata_signature': value_digest(merged), 'matched_csv_row': key in values,
302:             'csv': None if source is None else {**source, 'line': lines.get(key), 'join_value': list(key)},
303:             'json': json_source, 'json_conflicts': conflict, 'conflict_columns': overrides,
304:         }
305:         new = dict(row)
306:         new['_sample_metadata'] = merged
307:         new['_sample_metadata_provenance'] = provenance
308:         out.append(new)
309:     report['unused_metadata_keys'] = [list(k) for k in values if k not in used]
310:     report['n_matched_samples'] = len(report['matched_samples'])
```

## vhd/control/manifest.py · lines 326–337

SHA-256: `f99efe542ac8588dc17756f3567606175884f28fb9552cc6f9843a2976102563`

```text
326:     from .sample_metadata import metadata_for_row
327:     spec={'sample':row['sample_key'],'sample_id':row['sample_id'],'dataset_id':row['dataset_id'],
328:           'outs':row['spaceranger_outs'],'image':row['segmentation_image'],
329:           'tenx_to_image_affine':numbers(row['tenx_to_image_affine'],[1,0,0,0,1,0]),
330:           'image_mpp_override':([float(row['image_mpp_x']),float(row['image_mpp_y'])]
331:                                 if row['image_mpp_x'] and row['image_mpp_y'] else None),
332:           'source_mpp_override':float(row['source_mpp']) if row['source_mpp'] else None,
333:           'coordinates_reviewed':as_bool(row['coordinates_reviewed']),
334:           'fresh_qc_reviewed':as_bool(row['fresh_qc_reviewed']),
335:           'metadata':metadata_for_row(row),
336:           'metadata_provenance':copy.deepcopy(row.get('_sample_metadata_provenance',{})),
337:           '_analysis_qc':copy.deepcopy(settings.get('analysis_qc',{})),
```

## vhd/sample_metadata.py · lines 49–58

SHA-256: `6d04a1714fed1bd0302b473127a7823373ad6c89e0530bcc474bbe6ffdde3569`

```text
49: def _constant(value, index):
50:     if value is None:
51:         return pd.Series(np.nan, index=index, dtype='float64')
52:     if isinstance(value, str):
53:         # One category per sample is substantially cheaper than millions of copies.
54:         return pd.Series(pd.Categorical.from_codes(np.zeros(len(index), dtype=np.int8),
55:                          categories=pd.Index([value], dtype=object)), index=index)
56:     dtype = 'bool' if isinstance(value, bool) else 'int64' if isinstance(value, int) else 'float64'
57:     return pd.Series(value, index=index, dtype=dtype)
58: 
```

## vhd/sample_metadata.py · lines 113–144

SHA-256: `6d04a1714fed1bd0302b473127a7823373ad6c89e0530bcc474bbe6ffdde3569`

```text
113: def attach_sample_metadata(adata, spec):
114:     """Attach to a newly created in-memory AnnData; inputs/counts stay unchanged."""
115:     if not spec.get('metadata') and RECORD_KEY not in adata.uns:
116:         return {'add_or_replace': [], 'writes_expression': False}
117:     changed, drop, record, plan = plan_sample_metadata(adata.obs, adata.uns, spec)
118:     if drop:
119:         raise AssertionError('Default attachment does not prune metadata.')
120:     for key in changed:
121:         adata.obs[key] = changed[key]
122:     if plan['record_changed']:
123:         adata.uns[RECORD_KEY] = record
124:     return plan
125: 
126: 
127: def sync_sample_metadata(cfg, spec, *, execute=False, replace_owned=False, prune_owned=False):
128:     """Preview or persist sample metadata on already assembled bins/cells only.
129: 
130:     Does not run import, segmentation or normalization. Preview reads obs/var and
131:     the one provenance key, never X/layers or full image arrays. Actual writes
132:     rewrite obs/selected uns components via the existing recoverable writer.
133:     """
134:     from .core import sample_paths
135:     from .io import table_metadata
136:     from .persistence import update_table_metadata
137:     from .persistence.spatial import open_group
138:     from anndata.io import read_elem
139:     row = spec.get('_row', {})
140:     if row.get('goal') == 'export_only':
141:         return {'status': 'export_only_unchanged', 'tables': [], 'writes_expression': False}
142:     p = sample_paths(cfg, spec)
143:     plans = []
144:     for table in ('bins_2um', 'cells', 'proseg', 'bin2cell'):
```

## vhd/persistence/spatial.py · lines 28–65

SHA-256: `2335d77c1d0cd78510c497bffbb73d8b7c642901fa9035e61badd927ddb98a91`

```text
28: def refresh_metadata(store, *, table_names=()):
29:     """Refresh only explicitly changed tables, then the container's root cache.
30: 
31:     Consolidating a table rewrites that table's metadata even when its counts
32:     are unchanged. Never iterate over all tables: doing so mutates unrelated
33:     elements and invalidates their tracked size/mtime fingerprints.
34: 
35:     The default is ROOT ONLY (appropriate for image/shape/root-attribute edits).
36:     A table-data or table-metadata writer must pass its affected table names.
37:     The store writer lock / single-writer acknowledgement is managed by callers.
38:     This function does not load or rewrite expression/image array payloads.
39:     """
40:     import zarr
41:     p=Path(store)
42:     if isinstance(table_names,str):
43:         table_names=(table_names,)
44:     if table_names is None:
45:         raise ValueError('Pass explicit changed table_names, or () for root only.')
46:     tables=[]
47:     for name in table_names:
48:         if (not isinstance(name,str) or not name or name in ('.','..')
49:                 or '/' in name or '\\' in name):
50:             raise ValueError('Invalid table name for metadata refresh: '+repr(name))
51:         t=p/'tables'/name
52:         if t.is_symlink() or not t.resolve().is_relative_to(p.resolve()):
53:             raise ValueError('Refusing symlinked/escaped table metadata refresh: '+name)
54:         if not t.is_dir() or not ((t/'.zgroup').is_file() or (t/'zarr.json').is_file()):
55:             raise FileNotFoundError('Table Zarr group is absent: '+str(t))
56:         if t not in tables:
57:             tables.append(t)
58:     # Validate every explicit target before starting any metadata writes.
59:     format_number(p)
60:     for t in tables:
61:         zarr.consolidate_metadata(str(t))
62:     # Zarr's public consolidation writes metadata at the root passed here;
63:     # it does not separately reconsolidate each table's on-disk root.
64:     zarr.consolidate_metadata(str(p))
65: 
```
