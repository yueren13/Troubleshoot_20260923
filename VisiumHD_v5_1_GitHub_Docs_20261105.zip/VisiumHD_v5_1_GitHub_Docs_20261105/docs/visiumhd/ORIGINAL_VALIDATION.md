# Historical handbook validation record

This is the original November 4 handbook validation record, retained for provenance. It is **not** a report of new scientific tests for this format conversion. See [CONVERSION_NOTES.md](CONVERSION_NOTES.md) for the checks performed on this repository edition.

---

# Documentation validation and scope

Date: November 4, 2026.

This delivery is a handbook, source reference, and illustrative metadata-input examples. It is not a pipeline upgrade and contains no production-code installer. No user configuration, scientific source file, master object, or approval was modified.

## Documented code

- Base: `VisiumHD_Pipeline_v5_1_Dual_Method_20261104.zip` (0.5.1rc1).
- Applied to an isolated documentation extraction: `scoped-metadata-refresh-20261104-v1`.
- Original ZIPs remain unchanged. See `SOURCE_AUDIT.md` for exact hashes and evidence excerpts.
- Catalog coverage: all **86** Python files under `vhd/`, all **13** under `tools/`, and **1** under `scripts/`: **100** files total, including package initializers and a tool-local test module.
- The source browser includes those Python files and four selected configuration examples. It displays escaped source text; it does not execute the displayed Python.
- **170** narrative source links were resolved against exact source line anchors. Imports and importing-module relationships were collected by static AST inspection, including imports inside functions. This is not a measured runtime call graph and is not a claim that every defined helper executes on every route.

## Executed checks

**102 passed; zero skipped or failed** in the documentation validation command. These comprise **18** new documentation/example tests and the retained sample-metadata/Project-Center tests selected for this task. The log is `validation/documentation_tests.log`.

The new checks use the actual pipeline configuration/metadata/controller functions and tiny invented CSVs. They verify:

- Inline sample-sheet descriptors reach `_sample_metadata` and the sample specification.
- Separate metadata CSVs join on the declared ID column rather than row order.
- Leading-zero IDs remain strings; default numeric-looking metadata remains string-valued.
- Explicit numeric types work through the full metadata-reader configuration.
- The compact new-project form replaces its optional profile's metadata section with path/ID settings. This limitation is documented, not silently fixed.
- Blank values, literal `NA`, duplicate/missing keys, conflicting metadata and protected field names have the described behavior.
- A controller workspace can save/reopen the imported metadata while input files remain unchanged and no H5AD/Zarr master is created.
- The real metadata-attachment function operates on a small **AnnData-like test container**, preserving its expression sentinel. This is not an actual AnnData serialization test.
- All indexed Python file hashes match the inspected source; source anchors and module navigation are valid.
- The scoped metadata-refresh patch is the expected source version.

The retained Project Center tests include explicit substitutes for scientific dispatch; none of these 102 passes is claimed as full biological execution or a live-widget test.

### Reproducing the documentation checks

Use an isolated checkout matching the documented source, with its scoped fix already installed. The tests require that checkout's normal lightweight test dependencies plus Beautiful Soup. They do not install packages. Set `VHD_SOURCE_ROOT` to that checkout, then run:

```bash
export VHD_SOURCE_ROOT="/path/to/patched/VisiumHD_Pipeline_v5_1_Dual_Method_20261104"
export HANDBOOK_ROOT="/path/to/VisiumHD_v5_1_Handbook_20261104"
PYTHONPATH="$VHD_SOURCE_ROOT" python -m pytest -q -ra -p no:cacheprovider \
  "$HANDBOOK_ROOT/validation/test_handbook_contracts.py" \
  "$VHD_SOURCE_ROOT/tests/test_sample_metadata.py" \
  "$VHD_SOURCE_ROOT/tests/test_project_center.py"
```

The handbook checks intentionally bind the documented source hashes. A future code revision can fail these checks even if it is a valid new release; revise the documentation deliberately rather than changing the checks blindly.

## Presentation checks

- The Word handbook was rendered to **23 pages**. Every page image was visually inspected for clipping, overlapping content, table breakage and header/footer placement. Rendered QA images/PDF are not part of this delivery.
- Six HTML pages were rendered with Chromium. Search narrowed the module catalog to the two sample-metadata modules, and the source-fragment script opened a requested line in the corresponding source panel.
- Desktop layout was checked at 1440 px and four principal pages at 390 px; no document-level horizontal overflow was detected. Wide code panels scroll internally.
- No page-script errors were observed. See `validation/browser_checks.json`.
- The build container's browser policy prevented direct file/local-URL navigation. The renderer loaded the HTML through Playwright `set_content`; inter-page file links were checked structurally, not by a complete downloaded-site navigation session.
- HTML/Markdown references and the example tables are included together in the ZIP. Extract the complete pack and open `index.html` to keep relative source/example links available.

## Not tested or asserted here

No full scientific suite rerun, real tissue execution, Proseg inference, StarDist GPU inference, actual Bin2cell/SpatialData roundtrip, institutional mounted-store behavior, or live Jupyter widget interaction was performed for this documentation task. The user's earlier report that both target smoke tests passed is recorded as a user-reported target-environment result, not as a new local test.

The handbook documents current limitations, including no general post-creation metadata-edit/bulk-import UI, no implicit scientific revision branching, and no claim that a parsed/valid geometry establishes biological registration. It does not install missing functionality.
