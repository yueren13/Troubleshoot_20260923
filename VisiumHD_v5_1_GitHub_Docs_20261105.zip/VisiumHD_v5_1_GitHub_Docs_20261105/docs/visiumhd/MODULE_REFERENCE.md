[Documentation home](README.md) · [Handbook](PIPELINE_HANDBOOK.md) · [Module index](MODULE_INDEX.md) · [Source index](SOURCE_INDEX.md)

> **Repository edition.** The 100 original module entries are retained. Use the [grouped module index](MODULE_INDEX.md), your browser's Find command, or GitHub's heading outline instead of the previous JavaScript search box. Source files are frozen documentation references, not another pipeline installation.

# Python module reference

Baseline: 0.5.1rc1 plus scoped-metadata-refresh-20261104-v1. Static imports are dependencies, not proof of runtime calls. Dynamic subprocess/runpy edges are documented in the handbook.

## `scripts/run_pipeline.py`

Optional synchronous lower-level CLI. Its explicit --action list is narrower than the Project Center and does not expose all dual-method operations.

Source: [scripts/run_pipeline.py:1–27](source_snapshot/scripts/run_pipeline.py#L1-L27)

- `main` (lines 10–25): `main()`

Observed internal imports: `vhd/compute/launch.py`, `vhd/control/manifest.py`


Observed importing files: None found statically.

## `tools/audit_share_bundle.py`

Read-only package hygiene/path-pattern audit. Not a full security, privacy or license certification.

Source: [tools/audit_share_bundle.py:1–39](source_snapshot/tools/audit_share_bundle.py#L1-L39)

- `audit` (lines 11–37): `audit(root)`

Observed internal imports: None found statically.


Observed importing files: None found statically.

## `tools/check_project_center_environment.py`

Read-only package/resource/interface inventory, used by notebook 99. Does not install dependencies or launch sample jobs.

Source: [tools/check_project_center_environment.py:1–26](source_snapshot/tools/check_project_center_environment.py#L1-L26)

- `check` (lines 9–23): `check()`

Observed internal imports: `vhd/center/resources.py`


Observed importing files: None found statically.

## `tools/demo_annotation_signal_contract.py`

Generates a small synthetic annotation/signal contract demonstration in a new directory. Not a biological sample test.

Source: [tools/demo_annotation_signal_contract.py:1–67](source_snapshot/tools/demo_annotation_signal_contract.py#L1-L67)

- `xml_square` (lines 21–26): `xml_square(outer=90, negative=True)`
- `run` (lines 29–63): `run(output)`

Observed internal imports: `vhd/annotations/geometry.py`, `vhd/annotations/raster.py`, `vhd/annotations/transfer.py`, `vhd/annotations/workflow.py`, `vhd/he/fixed.py`, `vhd/plots.py`


Observed importing files: None found statically.

## `tools/demo_discovery_first.py`

Synthetic discovery and native-signal-summary example. Leaves generated choices unselected; does not approve real sources.

Source: [tools/demo_discovery_first.py:1–100](source_snapshot/tools/demo_discovery_first.py#L1-L100)

- `run` (lines 15–95): `run(output)`

Observed internal imports: `vhd/annotations/alignment.py`, `vhd/annotations/area_sampling.py`, `vhd/annotations/discovery.py`, `vhd/annotations/geometry.py`, `vhd/annotations/raster.py`, `vhd/annotations/transfer.py`, `vhd/annotations/workflow.py`


Observed importing files: None found statically.

## `tools/demo_project_center_reports.py`

Synthetic report-layout demonstration; the displayed demo plots are not products of real segmentation or clustering.

Source: [tools/demo_project_center_reports.py:1–55](source_snapshot/tools/demo_project_center_reports.py#L1-L55)

- `build_demo` (lines 11–50): `build_demo(destination)`

Observed internal imports: `vhd/center/__init__.py`, `vhd/control/manifest.py`


Observed importing files: None found statically.

## `tools/inspect_annotation_geometry.py`

Standalone original region-inspection entry point; analogous functionality is also packaged in annotations/region_inspection.py for center use.

Source: [tools/inspect_annotation_geometry.py:1–287](source_snapshot/tools/inspect_annotation_geometry.py#L1-L287)

- `_leaf_types` (lines 42–52): `_leaf_types(geometry: Any) -> dict[str, int]` — Count all candidate leaf types; never discard lines/points/empty parts.
- `_number` (lines 55–57): `_number(value: Any) -> float | None`
- `inspect_xml_regions` (lines 60–194): `inspect_xml_regions(path: str | Path, *, sample_key: str='', asset_id: str='', source_kind: str='annotation', check_repair_candidates: bool=False) -> dict[str, Any]` — Inspect every XML Region, not just the first invalid one.
- `inspect_project_annotations` (lines 197–249): `inspect_project_annotations(project: dict[str, Any], sample_keys: list[str] | None=None, *, check_repair_candidates: bool=False) -> dict[str, Any]` — Inspect selected samples' enabled ImageScope sources and XML coverage files.
- `print_diagnostic_summary` (lines 252–287): `print_diagnostic_summary(audit: dict[str, Any], max_issues: int | None=30) -> None` — Print source identity, counts and full validity reasons without truncating cells.

Observed internal imports: `vhd/annotations/workflow.py`, `vhd/control/manifest.py`


Observed importing files: None found statically.

## `tools/inspect_bin_grid.py`

Command-line coordinate-only diagnostic entry point; delegates to the grid modules.

Source: [tools/inspect_bin_grid.py:1–29](source_snapshot/tools/inspect_bin_grid.py#L1-L29)

- `main` (lines 9–25): `main()`

Observed internal imports: `vhd/control/manifest.py`, `vhd/grid_diagnostics.py`


Observed importing files: None found statically.

## `tools/preview_assets_on_he.py`

Visual-First H&E/annotation/raw-signal gallery, called from the controller through runpy. Display changes do not grant scientific approval.

Source: [tools/preview_assets_on_he.py:1–658](source_snapshot/tools/preview_assets_on_he.py#L1-L658)

- `_stamp` (lines 26–31): `_stamp(path)`
- `_matrix` (lines 34–40): `_matrix(a)`
- `_xy` (lines 43–45): `_xy(a, matrix)`
- `_safe_stem` (lines 48–49): `_safe_stem(value)`
- `_Field` (lines 52–82): `class _Field()` — Explicit yx / yxc / cyx scalar selection; no casting or thresholding.
- `_Field.__init__` (lines 54–70): `__init__(self, array, axes, channel)`
- `_Field.__getitem__` (lines 72–82): `__getitem__(self, key)`
- `_open_field` (lines 86–144): `_open_field(asset, max_eager_bytes=256 * 1024 ** 2)` — Read-only base-level TIFF/NPY/PNG. Bounded eager fallback, never a temp mmap.
- `_native_valid` (lines 147–154): `_native_valid(block, asset)`
- `_signal_scan` (lines 157–223): `_signal_scan(asset, max_side=1800, tile_size=512, unique_limit=512)` — Exact one-pass native-plane inventory + uniform nearest-neighbor display.
- `_polygon_rings` (lines 226–235): `_polygon_rings(geom)`
- `_raw_xml_layers` (lines 238–273): `_raw_xml_layers(asset, transform)` — Unrepaired outlines only; useful errors may not hide the rest of the file.
- `_load_polygon_layers` (lines 276–300): `_load_polygon_layers(asset, transform)`
- `_background` (lines 303–319): `_background(geometry, max_side)`
- `_resolve_for_preview` (lines 322–353): `_resolve_for_preview(asset, geometry)` — Same configured convention as v4.1; bounded reader for auto-extent shape.
- `_capture_outline` (lines 356–371): `_capture_outline(geometry)`
- `_signal_display_options` (lines 374–385): `_signal_display_options(signal_alpha, signal_zero_transparent)` — Validate display-only options before reading inputs or creating reports.
- `_signal_display_array` (lines 388–395): `_signal_display_array(array, zero_transparent)` — Independent display copy: never mutate source values or its validity mask.
- `_plot` (lines 398–463): `_plot(thumb, geometry, layers, signals, path, title, *, roi=None, dpi=160, signal_alpha=0.85, signal_zero_transparent=False)`
- `_render_html` (lines 466–520): `_render_html(summary, images, root)`
- `preview_assets_on_he` (lines 523–658): `preview_assets_on_he(project, sample_keys=None, *, max_side=2000, dpi=160, individual_categories=True, show=True, signal_alpha=0.85, signal_zero_transparent=False)` — Render all enabled source categories and raw single-channel signals on H&E.

Observed internal imports: `vhd/annotations/alignment.py`, `vhd/annotations/discovery.py`, `vhd/annotations/workflow.py`, `vhd/control/manifest.py`, `vhd/control/paths_v3.py`, `vhd/images.py`


Observed importing files: None found statically.

## `tools/reference_inspector.py`

Retained standalone copy of the original region inspector. It is not another mandatory annotation processing stage.

Source: [tools/reference_inspector.py:1–287](source_snapshot/tools/reference_inspector.py#L1-L287)

- `_leaf_types` (lines 42–52): `_leaf_types(geometry: Any) -> dict[str, int]` — Count all candidate leaf types; never discard lines/points/empty parts.
- `_number` (lines 55–57): `_number(value: Any) -> float | None`
- `inspect_xml_regions` (lines 60–194): `inspect_xml_regions(path: str | Path, *, sample_key: str='', asset_id: str='', source_kind: str='annotation', check_repair_candidates: bool=False) -> dict[str, Any]` — Inspect every XML Region, not just the first invalid one.
- `inspect_project_annotations` (lines 197–249): `inspect_project_annotations(project: dict[str, Any], sample_keys: list[str] | None=None, *, check_repair_candidates: bool=False) -> dict[str, Any]` — Inspect selected samples' enabled ImageScope sources and XML coverage files.
- `print_diagnostic_summary` (lines 252–287): `print_diagnostic_summary(audit: dict[str, Any], max_issues: int | None=30) -> None` — Print source identity, counts and full validity reasons without truncating cells.

Observed internal imports: `vhd/annotations/workflow.py`, `vhd/control/manifest.py`


Observed importing files: None found statically.

## `tools/review_annotation_candidates.py`

Standalone candidate-gallery helper retained for direct use and tests; the center uses its packaged counterpart in annotations/region_review.py.

Source: [tools/review_annotation_candidates.py:1–430](source_snapshot/tools/review_annotation_candidates.py#L1-L430)

- `_hash` (lines 31–32): `_hash(data: bytes) -> str`
- `_leaves` (lines 35–41): `_leaves(geometry)` — Retain every component, including empty/lower-dimensional results.
- `_polygon_parts` (lines 44–46): `_polygon_parts(geometry)`
- `_candidate_info` (lines 49–64): `_candidate_info(geometry)`
- `_read_snapshot` (lines 67–121): `_read_snapshot(path: Path, expected_sha256: str | None=None)`
- `_propose` (lines 124–143): `_propose(rec, compare_structure)` — Linework matches the original inspector's default; no best-method choice.
- `_compose_annotation` (lines 146–185): `_compose_annotation(records, method='linework')` — Candidate-only union of positive areas minus negative areas in ONE Annotation.
- `_intersection_point` (lines 188–193): `_intersection_point(reason)`
- `_plot_candidate_geometry` (lines 196–216): `_plot_candidate_geometry(ax, geometry, label, *, fill=True)` — Matplotlib defaults; each Polygon preserves interior holes in its patch.
- `_draw_region` (lines 219–259): `_draw_region(rec, folder, dpi, zoom_radius)`
- `_draw_category` (lines 262–293): `_draw_category(records, folder, dpi)`
- `_public_record` (lines 296–297): `_public_record(rec)`
- `write_candidate_review` (lines 300–403): `write_candidate_review(audit, output_parent, *, sample_key=None, asset_id=None, compare_structure=False, zoom_radius=100.0, dpi=180, max_invalid_regions=50)` — Write a NEW candidate-only visual report from the existing audit.
- `_write_html` (lines 406–430): `_write_html(result, path)`

Observed internal imports: None found statically.


Observed importing files: None found statically.

## `tools/strip_source_notebooks.py`

Explicit source-only notebook/code bundle utility. Does not execute notebook code; never point packaging tools at active working products casually.

Source: [tools/strip_source_notebooks.py:1–63](source_snapshot/tools/strip_source_notebooks.py#L1-L63)

- `main` (lines 11–59): `main()`

Observed internal imports: None found statically.


Observed importing files: None found statically.

## `tools/test_review_annotation_candidates.py`

Regression tests for the standalone review helper, despite residing under tools/. Not an operator-facing processing script.

Source: [tools/test_review_annotation_candidates.py:1–217](source_snapshot/tools/test_review_annotation_candidates.py#L1-L217)

- `write_source` (lines 22–32): `write_source(path, annos)`
- `audit_for` (lines 35–38): `audit_for(path)`
- `test_selfcrossing_not_cross_category_overlap` (lines 41–45): `test_selfcrossing_not_cross_category_overlap(tmp_path)`
- `test_source_hash_blocks_stale_audit` (lines 48–53): `test_source_hash_blocks_stale_audit(tmp_path)`
- `test_negative_split_keeps_all_components` (lines 56–66): `test_negative_split_keeps_all_components(tmp_path)`
- `test_collection_lower_components_retained_as_unapproved` (lines 69–79): `test_collection_lower_components_retained_as_unapproved(tmp_path)`
- `test_method_comparison_valid_candidates_only` (lines 82–86): `test_method_comparison_valid_candidates_only(tmp_path)`
- `test_no_auto_largest_component` (lines 89–93): `test_no_auto_largest_component(tmp_path)`
- `test_pure_lower_dimension_rejected_in_composition` (lines 96–100): `test_pure_lower_dimension_rejected_in_composition(tmp_path)`
- `test_categories_never_unioned_together` (lines 103–107): `test_categories_never_unioned_together(tmp_path)`
- `test_negative_without_parent_rejected` (lines 110–114): `test_negative_without_parent_rejected(tmp_path)`
- `test_exact_coordinate_duplicate_check` (lines 117–121): `test_exact_coordinate_duplicate_check(tmp_path)`
- `test_original_area_is_explicitly_unreliable` (lines 124–129): `test_original_area_is_explicitly_unreliable(tmp_path)`
- `test_bad_vertices_no_reports` (lines 133–137): `test_bad_vertices_no_reports(tmp_path, coords)`
- `test_zoom_point` (lines 140–142): `test_zoom_point()`
- `test_strict_snapshot_and_standalone_no_vhd_dependency` (lines 145–149): `test_strict_snapshot_and_standalone_no_vhd_dependency(tmp_path)`
- `test_visual_report_preserves_inputs_and_all_components` (lines 152–169): `test_visual_report_preserves_inputs_and_all_components(tmp_path)`
- `test_repeated_report_does_not_overwrite` (lines 172–177): `test_repeated_report_does_not_overwrite(tmp_path)`
- `test_no_match_fails_without_writes` (lines 181–185): `test_no_match_fails_without_writes(tmp_path, kwargs)`
- `test_report_limit_no_silent_truncation` (lines 188–192): `test_report_limit_no_silent_truncation(tmp_path)`
- `test_partial_report_is_explicit` (lines 195–203): `test_partial_report_is_explicit(tmp_path, monkeypatch)`
- `test_real_previous_diagnostic_schema` (lines 206–217): `test_real_previous_diagnostic_schema(tmp_path)`

Observed internal imports: None found statically.


Observed importing files: None found statically.

## `tools/validate_repository.py`

Static Python/notebook/CSV validation. Repository mode rejects saved notebook execution state; working mode permits it without clearing or executing it.

Source: [tools/validate_repository.py:1–114](source_snapshot/tools/validate_repository.py#L1-L114)

- `validate` (lines 17–101): `validate(root: Path, mode: str='repository') -> dict`
- `main` (lines 104–110): `main() -> None`

Observed internal imports: None found statically.


Observed importing files: None found statically.

## `vhd/__init__.py`

Visium HD Project Center; existing scientific cache versions are preserved.

Source: [vhd/__init__.py:1–2](source_snapshot/vhd/__init__.py#L1-L2)


Observed internal imports: None found statically.


Observed importing files: None found statically.

## `vhd/adapters/__init__.py`

Package namespace initializer; no stage implementation is defined here.

Source: [vhd/adapters/__init__.py:1–0](source_snapshot/vhd/adapters/__init__.py)


Observed internal imports: None found statically.


Observed importing files: None found statically.

## `vhd/adapters/anndata_input.py`

Selective AnnData metadata/count-matrix access for H5AD, AnnData-Zarr and named SpatialData tables. Avoids loading unrelated matrices/layers.

Source: [vhd/adapters/anndata_input.py:1–62](source_snapshot/vhd/adapters/anndata_input.py#L1-L62)

- `open_anndata_group` (lines 9–29): `open_anndata_group(path, kind='auto', table='')`
- `metadata` (lines 32–35): `metadata(path, kind='auto', table='')`
- `matrix_element` (lines 38–41): `matrix_element(root, source)`
- `read_selected` (lines 44–62): `read_selected(path, kind='auto', table='', source='X', *, max_matrix_gib=100, counts=True, embeddings=True)`

Observed internal imports: `vhd/core.py`


Observed importing files: `vhd/adapters/bins.py`, `vhd/adapters/cells.py`, `vhd/control/runner.py`

## `vhd/adapters/assemble.py`

Assembles actual bin-only, cell-only or bin-plus-cell SpatialData with truthful geometry and metadata linkage; validates the stored product.

Source: [vhd/adapters/assemble.py:1–135](source_snapshot/vhd/adapters/assemble.py#L1-L135)

- `validate_product` (lines 15–42): `validate_product(store)`
- `assemble` (lines 45–135): `assemble(cfg, spec)`

Observed internal imports: `vhd/compact_images.py`, `vhd/core.py`, `vhd/images.py`, `vhd/io.py`, `vhd/master.py`, `vhd/projective_grid.py`, `vhd/projective_storage.py`, `vhd/sample_metadata.py`, `vhd/storage.py`


Observed importing files: `vhd/bin_master.py`, `vhd/master.py`

## `vhd/adapters/bins.py`

Imports an existing bin table from the declared count source, uses original coordinate columns, and resolves/reuses supplied QC rather than guessing a new registration.

Source: [vhd/adapters/bins.py:1–112](source_snapshot/vhd/adapters/bins.py#L1-L112)

- `import_bins` (lines 18–84): `import_bins(cfg, spec)`
- `reuse_qc` (lines 87–112): `reuse_qc(cfg, spec)`

Observed internal imports: `vhd/adapters/anndata_input.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/grid_diagnostics.py`, `vhd/images.py`, `vhd/io.py`, `vhd/plots.py`, `vhd/projective_grid.py`


Observed importing files: `vhd/control/runner.py`

## `vhd/adapters/cells.py`

Imports standalone cells from declared raw counts/coordinates, using actual supplied boundaries where available. Does not fabricate biological cell outlines.

Source: [vhd/adapters/cells.py:1–182](source_snapshot/vhd/adapters/cells.py#L1-L182)

- `geometry_context` (lines 18–31): `geometry_context(cfg, spec)`
- `cell_matrix` (lines 34–41): `cell_matrix(mode, geom, explicit='')`
- `import_cells` (lines 44–182): `import_cells(cfg, spec)`

Observed internal imports: `vhd/adapters/anndata_input.py`, `vhd/cells.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/images.py`, `vhd/io.py`, `vhd/master.py`, `vhd/plots.py`, `vhd/sample_metadata.py`


Observed importing files: `vhd/control/runner.py`

## `vhd/analysis_qc.py`

Non-destructive raw-count cell/gene eligibility for analysis, including species-dependent mitochondrial limits and keyed source signatures. Does not replace cell reconstruction QC.

Source: [vhd/analysis_qc.py:1–138](source_snapshot/vhd/analysis_qc.py#L1-L138)

- `profile` (lines 13–30): `profile(cfg, spec)`
- `cell_metrics` (lines 33–62): `cell_metrics(counts, obs, var, p)`
- `gene_minimum` (lines 65–69): `gene_minimum(cfg)`
- `source_signature` (lines 72–78): `source_signature(cfg)`
- `run_analysis_qc` (lines 81–119): `run_analysis_qc(cfg)`
- `require_analysis_qc` (lines 122–131): `require_analysis_qc(cfg)`
- `analysis_mask` (lines 134–138): `analysis_mask(cfg, sample, index)`

Observed internal imports: `vhd/core.py`, `vhd/integration.py`, `vhd/io.py`, `vhd/plots.py`


Observed importing files: `vhd/center/single_sample.py`, `vhd/compute/integration_worker.py`, `vhd/integration.py`

## `vhd/annotations/__init__.py`

Explicit annotation geometry, coverage, and metadata transfer. No RNA reaggregation.

Source: [vhd/annotations/__init__.py:1–3](source_snapshot/vhd/annotations/__init__.py#L1-L3)


Observed internal imports: `vhd/annotations/geometry.py`, `vhd/annotations/transfer.py`


Observed importing files: `vhd/annotations/reviewed_geometry.py`

## `vhd/annotations/alignment.py`

Explicit source-to-H&E alignment from reference pixels, transforms, dimensions or landmarks; dimension matching requires same-extent confirmation.

Source: [vhd/annotations/alignment.py:1–93](source_snapshot/vhd/annotations/alignment.py#L1-L93)

- `extent_affine` (lines 14–28): `extent_affine(source_shape, reference_shape, *, pixel_convention='edges')` — Shapes are (height, width); coordinates are array-index pixel centers.
- `fit_landmarks` (lines 31–47): `fit_landmarks(path, max_error_px=2.0)`
- `resolve_alignment` (lines 50–93): `resolve_alignment(asset, geometry)` — Return a copy with resolved source-index -> Space Ranger fullres affine.

Observed internal imports: `vhd/annotations/raster.py`, `vhd/core.py`


Observed importing files: `tools/demo_discovery_first.py`, `tools/preview_assets_on_he.py`, `vhd/annotations/discovery.py`, `vhd/annotations/review.py`, `vhd/annotations/visual_approval.py`, `vhd/annotations/workflow.py`, `vhd/center/asset_report_navigation.py`

## `vhd/annotations/area_sampling.py`

Exact overlap-weighted sampling of a piecewise-constant source-pixel field over affine bin footprints.

Source: [vhd/annotations/area_sampling.py:1–103](source_snapshot/vhd/annotations/area_sampling.py#L1-L103)

- `_read_pairs` (lines 15–25): `_read_pairs(field, ys, xs, tile_size)` — Read pairs through the slice-only Raster interface, not a full image.
- `summarize_footprints` (lines 28–103): `summarize_footprints(field, xy_fullres, *, source_to_fullres, bin_basis_fullres, methods=('mean',), min_valid_fraction=0.0, chunk_size=20000, max_pairs=1000000, max_pixels_per_bin=4096, tile_size=512, coverage_source=None)` — Return metric arrays plus in-bounds/valid coverage for the actual bins.

Observed internal imports: `vhd/core.py`


Observed importing files: `tools/demo_discovery_first.py`, `vhd/annotations/projective_sampling.py`, `vhd/annotations/workflow.py`

## `vhd/annotations/discovery.py`

Discovers categories, merges current choices, compiles selected outputs and QC rules, and supports original source-preview approvals. Managed center saves coordinate the current normal route.

Source: [vhd/annotations/discovery.py:1–300](source_snapshot/vhd/annotations/discovery.py#L1-L300)

- `read_choices` (lines 21–32): `read_choices(path)`
- `atomic_choices` (lines 35–49): `atomic_choices(path, rows)` — Replace only this small, explicit config file; retain prior version.
- `selected_choices` (lines 52–55): `selected_choices(asset)`
- `has_active_choices` (lines 58–59): `has_active_choices(asset)`
- `source_geometry` (lines 62–71): `source_geometry(project, row)`
- `choice_key` (lines 74–75): `choice_key(category)`
- `output_name` (lines 78–80): `output_name(asset_id, category)`
- `discover_one` (lines 83–113): `discover_one(asset, geometry, sample_key)`
- `merge_choices` (lines 116–131): `merge_choices(existing, discovered, scopes)` — Keep choices, never approvals, across changed source signatures.
- `discover_assets` (lines 134–158): `discover_assets(project, sample_keys=None, execute=False)`
- `choice_signature` (lines 161–163): `choice_signature(choice, source_signature)`
- `expand_choices` (lines 166–212): `expand_choices(asset, geometry, require_approval=True, *, source_signature=None)`
- `review_prior_settings` (lines 215–225): `review_prior_settings(assets, settings)`
- `approve_choices` (lines 228–264): `approve_choices(project, selections, execute=False)` — Explicit {sample_key:[source_asset_ids]} selection; approve selected rows only.
- `preview_selected_plan` (lines 267–300): `preview_selected_plan(project, sample_keys=None, *, require_approval=False)` — Read-only plan: report pending approvals by default, never approve or import.

Observed internal imports: `vhd/annotations/alignment.py`, `vhd/annotations/raster.py`, `vhd/annotations/workflow.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/images.py`


Observed importing files: `tools/demo_discovery_first.py`, `tools/preview_assets_on_he.py`, `vhd/annotations/preview_categories.py`, `vhd/annotations/visual_approval.py`, `vhd/annotations/workflow.py`, `vhd/center/controller.py`, `vhd/center/importers.py`

## `vhd/annotations/geometry.py`

ImageScope XML reading, per-parent positive-minus-negative composition, transformed polygon geometry and independent bin-center membership with coverage semantics.

Source: [vhd/annotations/geometry.py:1–92](source_snapshot/vhd/annotations/geometry.py#L1-L92)

- `read_imagescope_annotation_xml` (lines 11–52): `read_imagescope_annotation_xml(path, um_per_px_x=None, um_per_px_y=None, dissolve_by_annotation=True, *, repair_invalid=False)`
- `transform_polygons` (lines 55–58): `transform_polygons(g, matrix)`
- `membership` (lines 61–68): `membership(xy, polygon, chunk_size=250000)`
- `classify_polygons` (lines 71–92): `classify_polygons(xy, g, *, category_column='name', categories=None, coverage=None, exhaustive=False, mode='membership')` — Always return fresh values. Positive-only coverage leaves outside unknown.

Observed internal imports: `vhd/core.py`


Observed importing files: `tools/demo_annotation_signal_contract.py`, `tools/demo_discovery_first.py`, `vhd/annotations/__init__.py`, `vhd/annotations/preview_categories.py`, `vhd/annotations/workflow.py`, `vhd/master.py`

## `vhd/annotations/preview_categories.py`

Per-category H&E views from one physical source without loading expression data.

Source: [vhd/annotations/preview_categories.py:1–24](source_snapshot/vhd/annotations/preview_categories.py#L1-L24)

- `preview_categories` (lines 11–24): `preview_categories(asset, cfg, spec, geometry)`

Observed internal imports: `vhd/annotations/discovery.py`, `vhd/annotations/geometry.py`, `vhd/annotations/workflow.py`, `vhd/core.py`, `vhd/images.py`


Observed importing files: `vhd/annotations/workflow.py`

## `vhd/annotations/projective_sampling.py`

Equivalent source-pixel-overlap summaries using each projective bin's quadrilateral rather than a shared affine basis.

Source: [vhd/annotations/projective_sampling.py:1–82](source_snapshot/vhd/annotations/projective_sampling.py#L1-L82)

- `summarize_projective_bins` (lines 13–82): `summarize_projective_bins(field, rows, cols, *, grid_index_to_fullres, source_to_fullres, methods=('mean',), min_valid_fraction=0.0, chunk_size=20000, max_pairs=1000000, max_pixels_per_bin=4096, tile_size=512, coverage_source=None)`

Observed internal imports: `vhd/annotations/area_sampling.py`, `vhd/core.py`, `vhd/projective_grid.py`


Observed importing files: `vhd/annotations/workflow.py`

## `vhd/annotations/raster.py`

Explicit-axis/channel lazy raster readers and selected-plane value checks, with small PNG fallback. Scientific binary validation is separate from display.

Source: [vhd/annotations/raster.py:1–83](source_snapshot/vhd/annotations/raster.py#L1-L83)

- `Raster` (lines 7–16): `class Raster()`
- `Raster.__init__` (lines 8–11): `__init__(self, arr, axes, channel)`
- `Raster.__getitem__` (lines 12–16): `__getitem__(self, key)`
- `open_raster` (lines 20–39): `open_raster(path, axes, channel=None)`
- `_tile` (lines 42–46): `_tile(path, axes, channel, y, x, h, w)`
- `spatial_image` (lines 49–70): `spatial_image(path, axes, channel, index_to_fullres, channel_name, tile_size=512)`
- `validate_signal_encoding` (lines 73–83): `validate_signal_encoding(asset, tile_size=512)` — Inspect ALL native pixels tile-wise; preserve raw values in stored image.

Observed internal imports: `vhd/annotations/workflow.py`, `vhd/core.py`


Observed importing files: `tools/demo_annotation_signal_contract.py`, `tools/demo_discovery_first.py`, `vhd/annotations/alignment.py`, `vhd/annotations/discovery.py`, `vhd/annotations/visual_approval.py`, `vhd/annotations/workflow.py`, `vhd/he/workflow.py`, `vhd/master.py`

## `vhd/annotations/region_inspection.py`

Formal in-package read-only invalid-region inventory and mathematical repair-candidate statistics; does not accept candidates.

Source: [vhd/annotations/region_inspection.py:1–287](source_snapshot/vhd/annotations/region_inspection.py#L1-L287)

- `_leaf_types` (lines 42–52): `_leaf_types(geometry: Any) -> dict[str, int]` — Count all candidate leaf types; never discard lines/points/empty parts.
- `_number` (lines 55–57): `_number(value: Any) -> float | None`
- `inspect_xml_regions` (lines 60–194): `inspect_xml_regions(path: str | Path, *, sample_key: str='', asset_id: str='', source_kind: str='annotation', check_repair_candidates: bool=False) -> dict[str, Any]` — Inspect every XML Region, not just the first invalid one.
- `inspect_project_annotations` (lines 197–249): `inspect_project_annotations(project: dict[str, Any], sample_keys: list[str] | None=None, *, check_repair_candidates: bool=False) -> dict[str, Any]` — Inspect selected samples' enabled ImageScope sources and XML coverage files.
- `print_diagnostic_summary` (lines 252–287): `print_diagnostic_summary(audit: dict[str, Any], max_issues: int | None=30) -> None` — Print source identity, counts and full validity reasons without truncating cells.

Observed internal imports: `vhd/annotations/workflow.py`, `vhd/control/manifest.py`


Observed importing files: `vhd/annotations/reviewed_geometry.py`

## `vhd/annotations/region_review.py`

In-package visual comparisons and composition of unapproved repair candidates in XML coordinates, not an H&E registration check.

Source: [vhd/annotations/region_review.py:1–430](source_snapshot/vhd/annotations/region_review.py#L1-L430)

- `_hash` (lines 31–32): `_hash(data: bytes) -> str`
- `_leaves` (lines 35–41): `_leaves(geometry)` — Retain every component, including empty/lower-dimensional results.
- `_polygon_parts` (lines 44–46): `_polygon_parts(geometry)`
- `_candidate_info` (lines 49–64): `_candidate_info(geometry)`
- `_read_snapshot` (lines 67–121): `_read_snapshot(path: Path, expected_sha256: str | None=None)`
- `_propose` (lines 124–143): `_propose(rec, compare_structure)` — Linework matches the original inspector's default; no best-method choice.
- `_compose_annotation` (lines 146–185): `_compose_annotation(records, method='linework')` — Candidate-only union of positive areas minus negative areas in ONE Annotation.
- `_intersection_point` (lines 188–193): `_intersection_point(reason)`
- `_plot_candidate_geometry` (lines 196–216): `_plot_candidate_geometry(ax, geometry, label, *, fill=True)` — Matplotlib defaults; each Polygon preserves interior holes in its patch.
- `_draw_region` (lines 219–259): `_draw_region(rec, folder, dpi, zoom_radius)`
- `_draw_category` (lines 262–293): `_draw_category(records, folder, dpi)`
- `_public_record` (lines 296–297): `_public_record(rec)`
- `write_candidate_review` (lines 300–403): `write_candidate_review(audit, output_parent, *, sample_key=None, asset_id=None, compare_structure=False, zoom_radius=100.0, dpi=180, max_invalid_regions=50)` — Write a NEW candidate-only visual report from the existing audit.
- `_write_html` (lines 406–430): `_write_html(result, path)`

Observed internal imports: None found statically.


Observed importing files: `vhd/annotations/reviewed_geometry.py`

## `vhd/annotations/review.py`

Legacy file-level asset approval API. Retained for old role-based manifests; not an extra form required after the Project Center visual-first save.

Source: [vhd/annotations/review.py:1–42](source_snapshot/vhd/annotations/review.py#L1-L42)

- `approve_assets` (lines 8–42): `approve_assets(project, selections, execute=False)` — selections={sample_key:[asset_ids]}; empty means no approval, not all.

Observed internal imports: `vhd/annotations/alignment.py`, `vhd/annotations/workflow.py`, `vhd/control/manifest.py`


Observed importing files: None found statically.

## `vhd/annotations/reviewed_geometry.py`

Source-bound explicit adoption and activation of derived polygon-only geometry, preserving holes, negative roles and all polygon components.

Source: [vhd/annotations/reviewed_geometry.py:1–390](source_snapshot/vhd/annotations/reviewed_geometry.py#L1-L390)

- `_bytes` (lines 30–32): `_bytes(value)`
- `_sha` (lines 35–36): `_sha(data)`
- `_check_bool` (lines 39–41): `_check_bool(value, name)`
- `_same` (lines 44–60): `_same(actual, expected, label)` — Compare recomputed numeric report data, allowing only floating-point noise.
- `assert_closed_polygonal` (lines 63–77): `assert_closed_polygonal(geometry, label='geometry')` — Validate entire exterior AND interior rings; do not patch or round vertices.
- `polygonal_candidate` (lines 80–105): `polygonal_candidate(candidate)` — Keep ALL already-closed polygon components; separate standalone lines.
- `_source_report` (lines 108–121): `_source_report(path, sample_key, asset_id)`
- `compile_reviewed_source` (lines 124–209): `compile_reviewed_source(review_json, *, sample_key, asset_id)` — Read-only: reproduce the exact reported repair and category composition.
- `_context` (lines 212–222): `_context(project, sample_key, asset_id)`
- `prepare_geometry_review` (lines 225–238): `prepare_geometry_review(project, sample_key, asset_id, *, execute=False)` — Formal report step. Preview has no writes; execute creates a new review folder.
- `reviewed_geometry_plan` (lines 241–264): `reviewed_geometry_plan(project, sample_key, asset_id, review_json)`
- `accept_reviewed_geometry` (lines 267–303): `accept_reviewed_geometry(project, sample_key, asset_id, review_json, *, expected_plan_digest, reviewer='', approve=False, allow_remove_lines=False, execute=False)` — Explicit adoption of ALL reported region candidates, not future/unseen inputs.
- `_load_document` (lines 306–320): `_load_document(path)`
- `read_reviewed_polygons` (lines 323–339): `read_reviewed_polygons(path)` — Read a typed microscopy document without assigning a geographic CRS.
- `activate_reviewed_geometry` (lines 342–390): `activate_reviewed_geometry(project, sample_key, asset_id, derived_path, *, execute=False)` — Back up and update only this asset's path, format and category_column.

Observed internal imports: `vhd/annotations/__init__.py`, `vhd/annotations/region_inspection.py`, `vhd/annotations/region_review.py`, `vhd/annotations/workflow.py`, `vhd/control/manifest.py`, `vhd/control/paths_v3.py`


Observed importing files: `vhd/annotations/workflow.py`, `vhd/center/controller.py`

## `vhd/annotations/transfer.py`

Coverage-aware cell summaries from bin assignments and annotation-based segmentation eligibility. Keeps independent category truth values and valid-bin coverage; geometric assignment is not molecule reassignment.

Source: [vhd/annotations/transfer.py:1–105](source_snapshot/vhd/annotations/transfer.py#L1-L105)

- `aggregate_annotations` (lines 6–52): `aggregate_annotations(obs, assignment, n_cells, spec)`
- `segmentation_decisions` (lines 55–84): `segmentation_decisions(obs, settings)`
- `gate_pathology` (lines 87–105): `gate_pathology(mask, xy, obs, output, settings)`

Observed internal imports: `vhd/segmentation.py`


Observed importing files: `tools/demo_annotation_signal_contract.py`, `tools/demo_discovery_first.py`, `vhd/annotations/__init__.py`, `vhd/annotations/workflow.py`, `vhd/cells.py`, `vhd/master.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/reconstruction/storage.py`, `vhd/segmentation.py`

## `vhd/annotations/visual_approval.py`

Bridges reviewed Visual-First galleries to choice signatures and real transfer prerequisites. Separates visual acceptance from an actual stored-source receipt.

Source: [vhd/annotations/visual_approval.py:1–536](source_snapshot/vhd/annotations/visual_approval.py#L1-L536)

- `_sha_bytes` (lines 29–30): `_sha_bytes(data)`
- `_sha_file` (lines 33–38): `_sha_file(path)`
- `_stamp` (lines 41–46): `_stamp(path)`
- `_same_stamp` (lines 49–55): `_same_stamp(recorded, path, label)`
- `_read_csv` (lines 58–70): `_read_csv(path)`
- `_csv_bytes` (lines 73–77): `_csv_bytes(fields, rows)`
- `_file_update` (lines 80–85): `_file_update(updates, path)`
- `_atomic_bytes` (lines 88–101): `_atomic_bytes(path, content)`
- `_canonical_map` (lines 104–112): `_canonical_map(project, mapping)`
- `list_visual_reviews` (lines 115–134): `list_visual_reviews(project, sample_keys=None)` — List saved galleries only; never choose or approve the newest automatically.
- `_evidence` (lines 137–162): `_evidence(summary_path, sample_key)`
- `_verify_view` (lines 165–201): `_verify_view(summary, asset, geometry, selected_categories)`
- `_signal_summary_check` (lines 204–218): `_signal_summary_check(shown, asset)` — Preview from recorded all-pixel inventory. Execute also validates native pixels.
- `_prospective_signal` (lines 221–236): `_prospective_signal(asset, mode)`
- `_receipt_path` (lines 239–242): `_receipt_path(report_dir, asset_id)`
- `approve_visual_choices` (lines 245–430): `approve_visual_choices(project, selections, *, review_reports, signal_interpretations=None, execute=False, reviewer='', confirm_plan=None)` — Preview/record approval from selected H&E galleries; no old import receipt needed.
- `_valid_stored` (lines 433–440): `_valid_stored(paths, source_id, signature)`
- `validate_visual_receipt` (lines 443–461): `validate_visual_receipt(paths, source_id, signature, items)`
- `ensure_transfer_sources` (lines 464–509): `ensure_transfer_sources(cfg, spec, assets, alignments, *, paths=None)` — Validate visual approval and perform missing REAL imports, never fabricate receipts.
- `print_approval_plan` (lines 512–536): `print_approval_plan(plan)` — Compact notebook view. The complete audit remains in the returned dictionary.

Observed internal imports: `vhd/annotations/alignment.py`, `vhd/annotations/discovery.py`, `vhd/annotations/raster.py`, `vhd/annotations/workflow.py`, `vhd/control/manifest.py`, `vhd/control/paths_v3.py`, `vhd/core.py`


Observed importing files: `vhd/annotations/workflow.py`, `vhd/center/controller.py`

## `vhd/annotations/workflow.py`

Asset CSV contract, source/transform signatures, native signal interpretation, polygon loaders, real spatial-source import and per-bin metadata transfer.

Source: [vhd/annotations/workflow.py:1–360](source_snapshot/vhd/annotations/workflow.py#L1-L360)

- `read_assets` (lines 24–90): `read_assets(path, dataset, sample)` — Read old v4 assets or discovery-first sources. dataset_id is optional.
- `fingerprint` (lines 93–95): `fingerprint(path)`
- `alignment_signature` (lines 98–106): `alignment_signature(asset, geometry)`
- `active_assets` (lines 109–112): `active_assets(assets)`
- `asset_specification` (lines 115–129): `asset_specification(cfg, spec)`
- `validate_prior_sources` (lines 132–139): `validate_prior_sources(assets, settings)`
- `signal_values` (lines 142–149): `signal_values(value, asset)`
- `MeasurementRaster` (lines 152–155): `class MeasurementRaster()` — Convert declared binary/NoData values BEFORE interpolation, not afterward.
- `MeasurementRaster.__init__` (lines 154–154): `__init__(self, raster, asset)`
- `MeasurementRaster.__getitem__` (lines 155–155): `__getitem__(self, key)`
- `polygons` (lines 158–169): `polygons(asset, coverage=False)`
- `preview` (lines 172–196): `preview(asset, cfg, spec)`
- `import_assets` (lines 199–260): `import_assets(cfg, spec)`
- `transfer_assets` (lines 263–360): `transfer_assets(cfg, spec)`

Observed internal imports: `vhd/annotations/alignment.py`, `vhd/annotations/area_sampling.py`, `vhd/annotations/discovery.py`, `vhd/annotations/geometry.py`, `vhd/annotations/preview_categories.py`, `vhd/annotations/projective_sampling.py`, `vhd/annotations/raster.py`, `vhd/annotations/reviewed_geometry.py`, `vhd/annotations/transfer.py`, `vhd/annotations/visual_approval.py`, `vhd/bin_master.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/he/fixed.py`, `vhd/images.py`, `vhd/io.py`, `vhd/master.py`, `vhd/persistence/__init__.py`, `vhd/persistence/spatial.py`, `vhd/persistence/transaction.py`, `vhd/projective_grid.py`


Observed importing files: `tools/demo_annotation_signal_contract.py`, `tools/demo_discovery_first.py`, `tools/inspect_annotation_geometry.py`, `tools/preview_assets_on_he.py`, `tools/reference_inspector.py`, `vhd/annotations/discovery.py`, `vhd/annotations/preview_categories.py`, `vhd/annotations/raster.py`, `vhd/annotations/region_inspection.py`, `vhd/annotations/review.py`, `vhd/annotations/reviewed_geometry.py`, `vhd/annotations/visual_approval.py`, `vhd/center/asset_report_navigation.py`, `vhd/center/importers.py`, `vhd/center/ui.py`, `vhd/control/manifest.py`, `vhd/control/prechecks.py`, `vhd/control/runner.py`, `vhd/master.py`

## `vhd/bin_master.py`

Sample/store identity checks and the explicit reusable bin-master checkpoint. Validates tracked sources/observations and refuses unrelated or incomplete destinations.

Source: [vhd/bin_master.py:1–306](source_snapshot/vhd/bin_master.py#L1-L306)

- `_read_json` (lines 16–27): `_read_json(path, limit=16 * 1024 ** 2)`
- `_paths` (lines 30–40): `_paths(cfg, spec)`
- `root_identity` (lines 43–64): `root_identity(store)` — Read authoritative root metadata, without opening scientific arrays.
- `assert_destination_identity` (lines 67–82): `assert_destination_identity(cfg, spec)` — A missing destination is allowed. A foreign/unknown existing master is not.
- `check_project_destinations` (lines 85–99): `check_project_destinations(project, row)` — Catch duplicate/overlapping outputs and foreign stores before a worker writes.
- `_stamp` (lines 102–110): `_stamp(path)`
- `signature` (lines 113–121): `signature(cfg, spec)`
- `_assert_transactions_idle` (lines 124–135): `_assert_transactions_idle(store)`
- `_assert_tracked` (lines 138–152): `_assert_tracked(cfg, spec)`
- `_verify_he_maps` (lines 156–168): `_verify_he_maps(cfg, spec)`
- `checkpoint_reusable` (lines 171–187): `checkpoint_reusable(cfg, spec)` — Cheap inventory after a prior full check; not a fresh matrix-integrity test.
- `center_contract` (lines 190–192): `center_contract(project, row)`
- `center_done` (lines 195–197): `center_done(project, row)`
- `_verify_base_obs` (lines 200–223): `_verify_base_obs(cfg, spec)` — Check base QC columns and observation population; never load X/layers here.
- `ensure_bin_master` (lines 226–278): `ensure_bin_master(cfg, spec)` — Assemble or validate a real base-bin master regardless of external assets.
- `sync_optional_prior` (lines 281–306): `sync_optional_prior(cfg, spec)` — Retain the native optional nuclei label when early assembly precedes StarDist.

Observed internal imports: `vhd/adapters/assemble.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/io.py`, `vhd/master.py`, `vhd/persistence/__init__.py`, `vhd/storage.py`


Observed importing files: `vhd/annotations/workflow.py`, `vhd/center/controller.py`, `vhd/center/stages.py`, `vhd/control/runner.py`, `vhd/master.py`, `vhd/reconstruction/storage.py`

## `vhd/cells.py`

Converts durable Proseg output to prepared cells: read polygons/counts, reconcile features, transform boundaries, compute QC/cell cycle and summarize bin-derived metadata.

Source: [vhd/cells.py:1–349](source_snapshot/vhd/cells.py#L1-L349)

- `clean_local_geometry` (lines 20–25): `clean_local_geometry(gdf)` — Never interpret microscopy microns or pixels as longitude/latitude.
- `transform_polygons` (lines 28–34): `transform_polygons(gdf, matrix)`
- `read_polygons` (lines 37–63): `read_polygons(path, id_column='cell')`
- `read_durable_proseg` (lines 66–101): `read_durable_proseg(files, orientation='cells_by_genes')`
- `canonical_features` (lines 104–128): `canonical_features(a, reference_var, names_are='auto_exact')` — Map by exact stable ID or historical Scanpy-unique symbols; ambiguity is an error.
- `geometric_assign` (lines 131–147): `geometric_assign(xy, polygons, chunk_size=250000)` — Bin-center containment. -1=unassigned, -2=ambiguous overlap; never nearest-neighbor fill.
- `cycle_scores` (lines 153–173): `cycle_scores(a, settings)` — Optional species-specific, user-supplied gene-symbol lists. Counts X stays unchanged.
- `build_cells` (lines 176–349): `build_cells(cfg, spec)`

Observed internal imports: `vhd/annotations/transfer.py`, `vhd/core.py`, `vhd/images.py`, `vhd/io.py`, `vhd/master.py`, `vhd/plots.py`, `vhd/sample_metadata.py`, `vhd/segmentation.py`


Observed importing files: `vhd/adapters/cells.py`, `vhd/control/runner.py`, `vhd/master.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/reconstruction/storage.py`, `vhd/segmentation.py`

## `vhd/center/__init__.py`

Persistent, review-first interface over the uploaded Visium HD scientific engine.

Source: [vhd/center/__init__.py:1–5](source_snapshot/vhd/center/__init__.py#L1-L5)


Observed internal imports: `vhd/center/controller.py`


Observed importing files: `tools/demo_project_center_reports.py`, `vhd/center/ui.py`

## `vhd/center/asset_report_navigation.py`

Read-only gallery/repair-report inventory, identity checks, image selectors and display. Viewing a report does not approve its geometry or scientific use.

Source: [vhd/center/asset_report_navigation.py:1–328](source_snapshot/vhd/center/asset_report_navigation.py#L1-L328)

- `_read_json` (lines 22–31): `_read_json(path)`
- `_in_directory` (lines 34–43): `_in_directory(path, parent)`
- `_image_path` (lines 46–53): `_image_path(directory, relative)`
- `_sha_file` (lines 56–61): `_sha_file(path)`
- `_stamp_matches` (lines 64–71): `_stamp_matches(record, path)`
- `_context` (lines 74–91): `_context(center, sample, assets=None)`
- `image_entries` (lines 94–115): `image_entries(summary, kind)` — Return every report-declared image; no scientific rasters are enumerated.
- `inspect_he_report` (lines 118–169): `inspect_he_report(path, *, sample_key, assets, geometry)` — Cheap freshness checks, not a replacement for native source approval.
- `inspect_repair_report` (lines 172–213): `inspect_repair_report(path, *, sample_key, asset, digest_cache=None)`
- `inventory` (lines 216–243): `inventory(center, sample, assets=None)` — Inventory only this run's report directory; never import another run's evidence.
- `choose` (lines 246–249): `choose(records, preferred=None)` — Preselect a still-current previous choice, else newest candidate; no approval.
- `selector_options` (lines 252–254): `selector_options(records)`
- `status_html` (lines 257–266): `status_html(found)`
- `show_report` (lines 269–328): `show_report(center, sample, summary_path, *, kind, asset_id=None)` — Show all report-declared images via a selector. Only selected image bytes load.

Observed internal imports: `vhd/annotations/alignment.py`, `vhd/annotations/workflow.py`, `vhd/control/manifest.py`


Observed importing files: `vhd/center/ui.py`

## `vhd/center/controller.py`

Persistent coordination API: project creation/opening, managed hashes, route planning, review gates, explicit saves, processing, resource caps, reports, methods and analysis groups.

Source: [vhd/center/controller.py:1–702](source_snapshot/vhd/center/controller.py#L1-L702)

- `ProjectCenter` (lines 17–702): `class ProjectCenter()`
- `ProjectCenter.__init__` (lines 18–20): `__init__(self, workspace)`
- `ProjectCenter.import_config` (lines 23–38): `import_config(cls, manifest, settings, workspace, *, title='Visium HD Project Center')`
- `ProjectCenter.from_sheets` (lines 41–58): `from_sheets(cls, samples, assets, output_root, workspace, *, profile=None, run_id='run01', namespace='Project', title='Visium HD Project Center', metadata_table=None, metadata_id_column='sample_id')`
- `ProjectCenter.open` (lines 61–62): `open(cls, workspace)`
- `ProjectCenter._check_workspace` (lines 65–75): `_check_workspace(workspace, project)`
- `ProjectCenter._managed_hashes` (lines 77–79): `_managed_hashes(self)`
- `ProjectCenter.snapshot` (lines 81–86): `snapshot(self)`
- `ProjectCenter.project` (lines 89–89): `project(self)`
- `ProjectCenter.key` (lines 91–93): `key(self, sample, project=None)`
- `ProjectCenter.row` (lines 95–97): `row(self, sample, project=None)`
- `ProjectCenter._write_project_exports` (lines 99–103): `_write_project_exports(self, d)`
- `ProjectCenter._commit` (lines 105–115): `_commit(self, d, event, *, export=False)`
- `ProjectCenter._route` (lines 117–119): `_route(self, d, row, endpoint=None)`
- `ProjectCenter.refresh` (lines 121–128): `refresh(self)`
- `ProjectCenter.hardware` (lines 130–135): `hardware(self)`
- `ProjectCenter.set_resource_limits` (lines 137–143): `set_resource_limits(self, limits)`
- `ProjectCenter.save_startup_settings` (lines 145–159): `save_startup_settings(self, values, *, confirmed=False)` — Save runtime-only startup settings; scientific contracts are unchanged.
- `ProjectCenter.set_endpoint` (lines 161–166): `set_endpoint(self, sample, endpoint)`
- `ProjectCenter.select_resume` (lines 168–185): `select_resume(self, sample, start_action, *, acknowledge_existing=False)` — Skip earlier route positions only after inventory; backend still validates its dependencies.
- `ProjectCenter._contract` (lines 187–222): `_contract(self, d, row, action)` — Controller cache contract; the scientific engine retains its own signature checks.
- `ProjectCenter._done` (lines 224–231): `_done(self, d, row, action)`
- `ProjectCenter._review_ready` (lines 233–264): `_review_ready(self, d, row, gate)`
- `ProjectCenter.plan` (lines 266–291): `plan(self, samples=None)`
- `ProjectCenter.save_bin_settings` (lines 293–312): `save_bin_settings(self, sample, *, tissue_score, transcripts, expected_revision=None)`
- `ProjectCenter.accept_review` (lines 314–341): `accept_review(self, sample, gate, *, reviewer, confirmed=False)`
- `ProjectCenter.acknowledge_writer` (lines 343–353): `acknowledge_writer(self, *, confirmed=False)`
- `ProjectCenter.choices` (lines 355–358): `choices(self, sample)`
- `ProjectCenter.galleries` (lines 360–362): `galleries(self, sample)`
- `ProjectCenter.discover` (lines 364–370): `discover(self, sample)`
- `ProjectCenter.generate_asset_gallery` (lines 372–377): `generate_asset_gallery(self, sample, *, alpha=0.85)`
- `ProjectCenter.save_asset_review` (lines 379–438): `save_asset_review(self, sample, *, gallery_summary, edits, extent_confirmations, signal_interpretations=None, scale_hints=None, reviewer='', confirmed=False, expected_revision=None)` — One UI operation: refresh changed discovery, restore form choices/extent, validate, approve.
- `ProjectCenter.generate_geometry_review` (lines 440–444): `generate_geometry_review(self, sample, asset_id)`
- `ProjectCenter.accept_geometry` (lines 446–459): `accept_geometry(self, sample, asset_id, review_json, *, reviewer, confirm_all=False, remove_lines=False)`
- `ProjectCenter.build_qc_distributions` (lines 461–465): `build_qc_distributions(self, sample)`
- `ProjectCenter.stop_after_current` (lines 467–468): `stop_after_current(self)`
- `ProjectCenter.run_until_review` (lines 470–535): `run_until_review(self, samples=None, *, confirmed=False, max_actions=30)` — Blocking notebook operation; releases resources at review barriers.
- `ProjectCenter.view` (lines 537–549): `view(self, sample=None, stage='bin_qc')`
- `ProjectCenter.export_report` (lines 551–557): `export_report(self, destination)`
- `ProjectCenter.show` (lines 559–561): `show(self)`
- `ProjectCenter.save_analysis_settings` (lines 563–572): `save_analysis_settings(self, settings)`
- `ProjectCenter.define_integration_group` (lines 574–588): `define_integration_group(self, name, samples, *, confirmed=False)`
- `ProjectCenter.integration_plan` (lines 590–596): `integration_plan(self, group)`
- `ProjectCenter.run_integration` (lines 598–620): `run_integration(self, group, phase, *, confirmed=False)`
- `ProjectCenter.frontend_check` (lines 622–626): `frontend_check(self)`
- `ProjectCenter.acknowledge_stopped_job` (lines 628–636): `acknowledge_stopped_job(self, sample, action, *, confirmed=False, reviewer='')` — Acknowledge externally checked interruption; never kills workers or removes locks/products.
- `ProjectCenter.save_runtime_settings` (lines 638–656): `save_runtime_settings(self, values)` — Change explicit worker locations through the UI; no environment installation or process launch.
- `ProjectCenter.save_reconstruction` (lines 659–702): `save_reconstruction(self, sample, *, methods, analysis_method, prob_thresh=0.02, nms_thresh=0.3, max_bin_distance=2, secondary=False, confirmed=False, expected_revision=None)` — Record method choices; this does not run segmentation or mutate a master.

Observed internal imports: `vhd/annotations/discovery.py`, `vhd/annotations/reviewed_geometry.py`, `vhd/annotations/visual_approval.py`, `vhd/bin_master.py`, `vhd/center/importers.py`, `vhd/center/reports.py`, `vhd/center/resources.py`, `vhd/center/single_sample.py`, `vhd/center/stages.py`, `vhd/center/state.py`, `vhd/center/ui.py`, `vhd/compute/launch.py`, `vhd/compute/startup_support.py`, `vhd/control/manifest.py`, `vhd/control/runner.py`, `vhd/he/qc_review.py`, `vhd/reconstruction/config.py`


Observed importing files: `vhd/center/__init__.py`, `vhd/center/ui.py`

## `vhd/center/importers.py`

Compact sample/asset-sheet parsing, optional descriptor-CSV join and small managed configuration copies. Extra sample-sheet columns become resolved sample metadata; this is not the strict manifest reader.

Source: [vhd/center/importers.py:1–171](source_snapshot/vhd/center/importers.py#L1-L171)

- `read_csv` (lines 9–16): `read_csv(path)`
- `csv_text` (lines 19–22): `csv_text(fields, rows)`
- `serialize_asset` (lines 25–34): `serialize_asset(asset)`
- `clone_project` (lines 37–92): `clone_project(project, workspace)` — Small copies only. Biological paths/run identity remain the supplied ones.
- `project_from_sheets` (lines 95–171): `project_from_sheets(samples, assets, output_root, *, profile=None, run_id='run01', namespace='Project', metadata_table=None, metadata_id_column='sample_id')` — Read a compact sample sheet; extra columns become sample metadata.

Observed internal imports: `vhd/annotations/discovery.py`, `vhd/annotations/workflow.py`, `vhd/center/state.py`, `vhd/control/manifest.py`, `vhd/control/sample_metadata.py`, `vhd/reconstruction/config.py`


Observed importing files: `vhd/center/controller.py`

## `vhd/center/reports.py`

Registers known scientific reports and renders fixed project/sample/group HTML summaries with bounded image/table content. Does not generate missing biological results.

Source: [vhd/center/reports.py:1–167](source_snapshot/vhd/center/reports.py#L1-L167)

- `list_reports` (lines 34–53): `list_reports(project, row)`
- `_thumbnail` (lines 56–63): `_thumbnail(p, max_side=1300)`
- `document` (lines 66–67): `document(title, body, subtitle='Read-only snapshot • decisions are saved through the live Project Center')`
- `stage_html` (lines 70–101): `stage_html(sample, stage, artifacts, statuses=None)`
- `write_center_reports` (lines 104–153): `write_center_reports(state, workspace, *, refresh_samples=None)` — Fixed HTML index plus cached per-sample stage pages. Only changed pages rewrite.
- `write_group_report` (lines 156–167): `write_group_report(cfg, group, workspace, states=None)`

Observed internal imports: `vhd/center/state.py`, `vhd/control/manifest.py`


Observed importing files: `vhd/center/controller.py`, `vhd/reconstruction/reports.py`

## `vhd/center/resources.py`

Available-resource observation including visible cgroups, optional allocation caps and conservative runtime settings. Does not reserve GPUs or learn a validated memory model.

Source: [vhd/center/resources.py:1–125](source_snapshot/vhd/center/resources.py#L1-L125)

- `cgroup_limits` (lines 7–47): `cgroup_limits(cgroup_file='/proc/self/cgroup', mount='/sys/fs/cgroup')` — Read visible v2 ancestor constraints plus common v1 root constraints.
- `parse_gpu_csv` (lines 50–64): `parse_gpu_csv(text, visible=None)`
- `detect_resources` (lines 67–85): `detect_resources()`
- `runtime_project` (lines 88–125): `runtime_project(project, limits=None, inventory=None)` — Produce a worker-config copy, honoring detected capacity and explicit caps.

Observed internal imports: None found statically.


Observed importing files: `tools/check_project_center_environment.py`, `vhd/center/controller.py`, `vhd/reconstruction/bin2cell_adapter.py`

## `vhd/center/single_sample.py`

Explicit independent CPU Scanpy PCA/neighbors/UMAP/Leiden workflow on one selected cell table; produces method-partitioned companion metadata/embedding results.

Source: [vhd/center/single_sample.py:1–116](source_snapshot/vhd/center/single_sample.py#L1-L116)

- `run_individual` (lines 11–95): `run_individual(project, sample_key, settings)`
- `launch_individual` (lines 98–111): `launch_individual(project, sample_key, settings, *, execute=False)`

Observed internal imports: `vhd/analysis_qc.py`, `vhd/compute/launch.py`, `vhd/compute/runtime_checks.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/io.py`, `vhd/palette.py`, `vhd/plots.py`


Observed importing files: `vhd/center/controller.py`

## `vhd/center/stages.py`

Human-readable stage labels, selected endpoint routes, expected output locations and bounded inventory. Presence is not proof of scientific correctness.

Source: [vhd/center/stages.py:1–94](source_snapshot/vhd/center/stages.py#L1-L94)

- `route` (lines 32–57): `route(row, endpoint=None, cfg=None)`
- `output_paths` (lines 60–82): `output_paths(project, row, action)`
- `observed` (lines 85–94): `observed(project, row, action)`

Observed internal imports: `vhd/bin_master.py`, `vhd/control/manifest.py`, `vhd/reconstruction/config.py`


Observed importing files: `vhd/center/controller.py`

## `vhd/center/state.py`

Small JSON controller ledger with revision history, fingerprints and an advisory POSIX lock. Contains no RNA arrays and does not lock unrelated external readers.

Source: [vhd/center/state.py:1–115](source_snapshot/vhd/center/state.py#L1-L115)

- `now` (lines 17–18): `now()`
- `stable` (lines 21–22): `stable(value)`
- `fingerprint` (lines 25–26): `fingerprint(value)`
- `file_fingerprint` (lines 29–34): `file_fingerprint(path)`
- `stamp` (lines 37–43): `stamp(path)`
- `atomic_write` (lines 46–58): `atomic_write(path, content)`
- `StateStore` (lines 61–115): `class StateStore()`
- `StateStore.__init__` (lines 62–65): `__init__(self, directory)`
- `StateStore.exclusive` (lines 68–83): `exclusive(self)`
- `StateStore.read` (lines 85–89): `read(self)`
- `StateStore.initialize` (lines 91–99): `initialize(self, data)`
- `StateStore.save_locked` (lines 101–115): `save_locked(self, data, expected_revision, event)` — Caller holds exclusive(). Revision prevents silent stale-page overwrites.

Observed internal imports: None found statically.


Observed importing files: `vhd/center/controller.py`, `vhd/center/importers.py`, `vhd/center/reports.py`, `vhd/center/ui.py`

## `vhd/center/ui.py`

Connected Jupyter widget interface and setup form. Buttons call the controller; its HTML report display is distinct from a disconnected exported HTML file.

Source: [vhd/center/ui.py:1–435](source_snapshot/vhd/center/ui.py#L1-L435)

- `validate_choice_form` (lines 11–23): `validate_choice_form(edits)`
- `show_center` (lines 26–360): `show_center(center)`
- `launch_setup` (lines 363–435): `launch_setup(root)` — Display the one-time import / reopen form. Nothing writes until its button is clicked.

Observed internal imports: `vhd/annotations/workflow.py`, `vhd/center/__init__.py`, `vhd/center/asset_report_navigation.py`, `vhd/center/controller.py`, `vhd/center/state.py`, `vhd/compute/startup_support.py`, `vhd/control/manifest.py`, `vhd/reconstruction/config.py`


Observed importing files: `vhd/center/controller.py`

## `vhd/compact_images.py`

Selects and constructs compact master images with explicit mappings back to full resolution, and validates their storage contract.

Source: [vhd/compact_images.py:1–99](source_snapshot/vhd/compact_images.py#L1-L99)

- `compact_sources` (lines 9–35): `compact_sources(cfg, spec)`
- `build_images` (lines 39–77): `build_images(cfg, spec, geometry)`
- `validate_images` (lines 80–99): `validate_images(sdata)`

Observed internal imports: `vhd/core.py`, `vhd/images.py`, `vhd/spaceranger_images.py`, `vhd/storage.py`


Observed importing files: `vhd/adapters/assemble.py`, `vhd/he/source.py`, `vhd/master.py`, `vhd/storage.py`

## `vhd/compute/__init__.py`

Package namespace initializer; no stage implementation is defined here.

Source: [vhd/compute/__init__.py:1–0](source_snapshot/vhd/compute/__init__.py)


Observed internal imports: None found statically.


Observed importing files: None found statically.

## `vhd/compute/clustering.py`

Configured CPU or RAPIDS graph/UMAP/Leiden backend, with optional Dask multi-GPU Leiden path. Different from the independent CPU analysis module.

Source: [vhd/compute/clustering.py:1–86](source_snapshot/vhd/compute/clustering.py#L1-L86)

- `seed_kw` (lines 12–16): `seed_kw(function, seed)`
- `graph_and_cluster` (lines 19–86): `graph_and_cluster(adata, cfg, resolutions)`

Observed internal imports: None found statically.


Observed importing files: `vhd/integration.py`

## `vhd/compute/integration_worker.py`

Separate worker for prepare/cluster/diagnostics/writeback integration phases using the selected interpreter.

Source: [vhd/compute/integration_worker.py:1–19](source_snapshot/vhd/compute/integration_worker.py#L1-L19)

- `main` (lines 5–17): `main()`

Observed internal imports: `vhd/analysis_qc.py`, `vhd/integration.py`


Observed importing files: None found statically.

## `vhd/compute/launch.py`

Chooses action-specific interpreters, creates worker environments, computes concurrency budgets, performs probes and submits/monitors sample or integration subprocesses.

Source: [vhd/compute/launch.py:1–236](source_snapshot/vhd/compute/launch.py#L1-L236)

- `cpu_count` (lines 19–20): `cpu_count()`
- `concurrency_budget` (lines 22–39): `concurrency_budget(requested, threads, ram_per_job_gib=None, available_gib=None, reserve_cpus=8, reserve_gib=40)` — Unknown per-job RAM => one pilot process, never four blind whole-slide allocations.
- `worker_env` (lines 41–55): `worker_env(tmp, gpus, threads)` — Explicit writable caches under approved scratch; no credentials copied to config.
- `run_logged` (lines 57–92): `run_logged(command, env, log)`
- `launch_samples` (lines 94–189): `launch_samples(project, actions, execute=False, sample_keys=None)` — Actions are barriers; GPUs are exclusive tokens, not an unsafe round-robin assignment.
- `scvi_command` (lines 191–196): `scvi_command(executable, config_path, mode, devices)`
- `launch_integration` (lines 198–236): `launch_integration(project, group, phase, execute=False)`

Observed internal imports: `vhd/compute/runtime_checks.py`, `vhd/compute/startup_support.py`, `vhd/control/manifest.py`, `vhd/control/prechecks.py`, `vhd/control/runner.py`, `vhd/core.py`


Observed importing files: `scripts/run_pipeline.py`, `vhd/center/controller.py`, `vhd/center/single_sample.py`

## `vhd/compute/probe.py`

Legacy/lightweight software/host/NVIDIA inventory without importing deep-learning frameworks into the notebook process.

Source: [vhd/compute/probe.py:1–25](source_snapshot/vhd/compute/probe.py#L1-L25)

- `hardware_inventory` (lines 10–21): `hardware_inventory()`

Observed internal imports: `vhd/core.py`


Observed importing files: None found statically.

## `vhd/compute/runtime_checks.py`

Preserves worker executable invocation, identifies required imports for each action and probes those imports in the selected environment.

Source: [vhd/compute/runtime_checks.py:1–144](source_snapshot/vhd/compute/runtime_checks.py#L1-L144)

- `executable_path` (lines 16–33): `executable_path(value, base)` — Make an executable path absolute WITHOUT dereferencing symlinks.
- `action_imports` (lines 36–60): `action_imports(action, *, backend=None)`
- `preflight_python` (lines 94–144): `preflight_python(executable, modules, *, env=None, cwd=None, timeout=None, log_path=None, require_gpu=False, stack_dump_interval_seconds=60, heartbeat_seconds=30)` — Timed and logged startup; no success cache and no scientific timeout.

Observed internal imports: `vhd/compute/startup_support.py`


Observed importing files: `vhd/center/single_sample.py`, `vhd/compute/launch.py`, `vhd/control/manifest.py`

## `vhd/compute/scvi_state.py`

Dependency-light classification of absent, partial, model-ready and complete scVI artifacts. Prevents unsafe model reuse or overwrite.

Source: [vhd/compute/scvi_state.py:1–47](source_snapshot/vhd/compute/scvi_state.py#L1-L47)

- `record_model_receipt` (lines 7–13): `record_model_receipt(path, signature, **details)`
- `classify_training_state` (lines 16–47): `classify_training_state(path, signature, phase)`

Observed internal imports: `vhd/core.py`


Observed importing files: `vhd/compute/scvi_worker.py`

## `vhd/compute/scvi_worker.py`

Script/DDP training and separate single-writer latent inference, using declared raw counts and sample batch labels; records model/history/inference receipts.

Source: [vhd/compute/scvi_worker.py:1–99](source_snapshot/vhd/compute/scvi_worker.py#L1-L99)

- `execute` (lines 13–91): `execute(cfg, phase)`
- `main` (lines 94–97): `main()`

Observed internal imports: `vhd/compute/scvi_state.py`, `vhd/core.py`, `vhd/integration.py`, `vhd/plots.py`


Observed importing files: `vhd/integration.py`

## `vhd/compute/startup_support.py`

Persistent startup/cache controls, bounded isolated probes, timeout handling and Proseg executable inspection. Runtime controls are separated from scientific settings.

Source: [vhd/compute/startup_support.py:1–323](source_snapshot/vhd/compute/startup_support.py#L1-L323)

- `validate_startup_settings` (lines 42–65): `validate_startup_settings(values=None)`
- `settings_for_project` (lines 68–69): `settings_for_project(project)`
- `validate_cache_root` (lines 72–91): `validate_cache_root(project, root)` — Allow a separate runtime cache, never a scientific source/master or code root.
- `atomic_json` (lines 94–102): `atomic_json(path, value)`
- `startup_directory` (lines 105–111): `startup_directory(report_dir, action)`
- `prepare_environment` (lines 114–146): `prepare_environment(env, executable, scratch, settings, *, create=True)` — Change only MPLCONFIGDIR; preserve GPU visibility and scientific caches.
- `_tail` (lines 149–153): `_tail(path, nbytes=24000)`
- `_stop_probe` (lines 156–181): `_stop_probe(process)` — Stop only this newly created probe/session, never an existing worker.
- `run_probe` (lines 184–254): `run_probe(command, *, env, cwd, timeout, log_path, heartbeat_seconds=30)` — Run bounded startup only, stream output and retain a per-attempt receipt.
- `preflight_proseg` (lines 315–323): `preflight_proseg(python_executable, proseg_executable, *, env, cwd, settings, log_path)` — Check the exact configured binary in the actual worker Python environment.

Observed internal imports: None found statically.


Observed importing files: `vhd/center/controller.py`, `vhd/center/ui.py`, `vhd/compute/launch.py`, `vhd/compute/runtime_checks.py`

## `vhd/compute/worker.py`

Fresh sample-worker module invoked with python -m; reads a resolved project snapshot and dispatches one action.

Source: [vhd/compute/worker.py:1–15](source_snapshot/vhd/compute/worker.py#L1-L15)

- `main` (lines 5–13): `main()`

Observed internal imports: `vhd/control/runner.py`


Observed importing files: None found statically.

## `vhd/control/__init__.py`

Package namespace initializer; no stage implementation is defined here.

Source: [vhd/control/__init__.py:1–0](source_snapshot/vhd/control/__init__.py)


Observed internal imports: None found statically.


Observed importing files: None found statically.

## `vhd/control/manifest.py`

Strict full-manifest reader, global/per-sample configuration merge, storage-policy checks, resolved sample paths, action plans and worker snapshots. The compact new-project sheet is parsed elsewhere.

Source: [vhd/control/manifest.py:1–385](source_snapshot/vhd/control/manifest.py#L1-L385)

- `as_bool` (lines 35–40): `as_bool(value, default=False)`
- `normalize_stage` (lines 42–44): `normalize_stage(value)`
- `is_remote` (lines 46–47): `is_remote(value)`
- `path_value` (lines 49–62): `path_value(value, base)`
- `under` (lines 64–68): `under(child, root)`
- `numbers` (lines 70–74): `numbers(value, default=None)`
- `row_plan` (lines 76–91): `row_plan(row)` — Source stage is an entry point, NOT permission to skip validation.
- `validate_row` (lines 93–160): `validate_row(row)`
- `read_manifest` (lines 162–190): `read_manifest(path, default_dataset_id='Project')`
- `deep_update` (lines 192–196): `deep_update(base, extra)`
- `load_project` (lines 198–272): `load_project(manifest_path, settings_path)`
- `check_policy` (lines 274–305): `check_policy(project)`
- `sample_layout` (lines 307–313): `sample_layout(project, row)`
- `row_config` (lines 315–350): `row_config(project, row)`
- `save_plan` (lines 352–363): `save_plan(project)`
- `scientific_row` (lines 366–371): `scientific_row(row)` — Review sign-offs and publication destinations do not invalidate imported expression.
- `resolve_sample_keys` (lines 374–385): `resolve_sample_keys(project, selection)` — Accept canonical keys or unambiguous sample_id aliases; never use folder names.

Observed internal imports: `vhd/annotations/workflow.py`, `vhd/compute/runtime_checks.py`, `vhd/control/paths_v3.py`, `vhd/control/sample_metadata.py`, `vhd/core.py`, `vhd/reconstruction/config.py`


Observed importing files: `scripts/run_pipeline.py`, `tools/demo_project_center_reports.py`, `tools/inspect_annotation_geometry.py`, `tools/inspect_bin_grid.py`, `tools/preview_assets_on_he.py`, `tools/reference_inspector.py`, `vhd/adapters/bins.py`, `vhd/adapters/cells.py`, `vhd/annotations/discovery.py`, `vhd/annotations/region_inspection.py`, `vhd/annotations/review.py`, `vhd/annotations/reviewed_geometry.py`, `vhd/annotations/visual_approval.py`, `vhd/annotations/workflow.py`, `vhd/bin_master.py`, `vhd/center/asset_report_navigation.py`, `vhd/center/controller.py`, `vhd/center/importers.py`, `vhd/center/reports.py`, `vhd/center/single_sample.py`, `vhd/center/stages.py`, `vhd/center/ui.py`, `vhd/compute/launch.py`, `vhd/control/notebook_runtime.py`, `vhd/control/prechecks.py`, `vhd/control/runner.py`, `vhd/control/sample_metadata.py`, `vhd/control/storage.py`, `vhd/grid_diagnostics.py`, `vhd/he/qc_review.py`, `vhd/he/source.py`

## `vhd/control/notebook_runtime.py`

Explicit preview/execute, sample-selection and action-description helpers retained for direct notebook/advanced workflows.

Source: [vhd/control/notebook_runtime.py:1–95](source_snapshot/vhd/control/notebook_runtime.py#L1-L95)

- `describe_run` (lines 8–41): `describe_run(project, *, execute, sample_keys=None, allow_all=False, kind='sample')`
- `output_status` (lines 44–75): `output_status(project, sample_keys=None)` — Read small receipts and check paths; do not read matrices or change files.
- `output_index` (lines 78–95): `output_index(project, sample_keys=None, save=False)` — Expected and existing paths; optional small CSV under the approved control root.

Observed internal imports: `vhd/control/manifest.py`


Observed importing files: None found statically.

## `vhd/control/paths_v3.py`

Retained path helper despite its historical filename: path expansion, required roots/sentinels, overlap checks, layout and optional mounted-source staging.

Source: [vhd/control/paths_v3.py:1–68](source_snapshot/vhd/control/paths_v3.py#L1-L68)

- `expand_path` (lines 8–12): `expand_path(value)`
- `under` (lines 15–19): `under(child, root)`
- `require_roots` (lines 22–27): `require_roots(policy)`
- `assert_target` (lines 30–33): `assert_target(path, roots, sources=())`
- `storage_profile` (lines 36–38): `storage_profile(path, policy)`
- `actual_layout` (lines 41–45): `actual_layout(row, run)`
- `stage_mounted` (lines 48–68): `stage_mounted(source, cache, policy)` — Opt-in retained copy, source SHA256 plus readback. Expensive by design, no eviction.

Observed internal imports: `vhd/control/storage.py`, `vhd/core.py`


Observed importing files: `tools/preview_assets_on_he.py`, `vhd/annotations/reviewed_geometry.py`, `vhd/annotations/visual_approval.py`, `vhd/control/manifest.py`, `vhd/control/runner.py`, `vhd/he/qc_review.py`, `vhd/persistence/spatial.py`, `vhd/persistence/transaction.py`

## `vhd/control/prechecks.py`

Checks action-specific inputs and small receipts before launching a batch; not a complete scientific execution test.

Source: [vhd/control/prechecks.py:1–39](source_snapshot/vhd/control/prechecks.py#L1-L39)

- `check_action_inputs` (lines 6–39): `check_action_inputs(project, rows, action)`

Observed internal imports: `vhd/annotations/workflow.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/master.py`


Observed importing files: `vhd/compute/launch.py`

## `vhd/control/runner.py`

Prepares localized sample contexts, dispatches scientific actions, records status, separates report categories and handles sample/group publication.

Source: [vhd/control/runner.py:1–231](source_snapshot/vhd/control/runner.py#L1-L231)

- `prepare_context` (lines 13–37): `prepare_context(project, row, action)`
- `export_existing` (lines 40–60): `export_existing(cfg, spec)`
- `run_action` (lines 63–150): `run_action(project, sample_key, action)`
- `copy_reports` (lines 153–160): `copy_reports(p)` — Only plot files go to plot output; metadata/tables/logs go to data output.
- `publish_sample` (lines 163–180): `publish_sample(project, row, execute=False)`
- `integration_config` (lines 183–209): `integration_config(project, group)`
- `publish_integration` (lines 212–231): `publish_integration(project, group, execute=False)`

Observed internal imports: `vhd/adapters/anndata_input.py`, `vhd/adapters/bins.py`, `vhd/adapters/cells.py`, `vhd/annotations/workflow.py`, `vhd/bin_master.py`, `vhd/cells.py`, `vhd/control/manifest.py`, `vhd/control/paths_v3.py`, `vhd/control/storage.py`, `vhd/core.py`, `vhd/he/workflow.py`, `vhd/integration.py`, `vhd/io.py`, `vhd/master.py`, `vhd/plots.py`, `vhd/qc.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/reconstruction/storage.py`, `vhd/segmentation.py`


Observed importing files: `vhd/center/controller.py`, `vhd/compute/launch.py`, `vhd/compute/worker.py`

## `vhd/control/sample_metadata.py`

Reads and joins descriptor CSVs using exact sample identities, validates scalar values/reserved names and optional types/renames, resolves legacy metadata JSON and builds provenance.

Source: [vhd/control/sample_metadata.py:1–324](source_snapshot/vhd/control/sample_metadata.py#L1-L324)

- `value_digest` (lines 38–40): `value_digest(value: Any) -> str`
- `validate_field_name` (lines 43–50): `validate_field_name(name: str) -> None`
- `validate_values` (lines 53–64): `validate_values(values: dict) -> dict`
- `_boolean_option` (lines 67–71): `_boolean_option(config, name, default)`
- `_identifier` (lines 74–79): `_identifier(value, column, line)`
- `_parse_value` (lines 82–110): `_parse_value(text, kind, missing, column, line)`
- `_infer_type` (lines 113–130): `_infer_type(texts)` — Opt-in conservative whole-column inference; dates/leading zeros stay text.
- `read_metadata_csv` (lines 133–226): `read_metadata_csv(path, config=None)` — Read and validate a table, retaining original headings unless renamed.
- `_json_metadata` (lines 229–235): `_json_metadata(path)`
- `metadata_for_row` (lines 238–242): `metadata_for_row(row)` — Use the immutable values in a project snapshot; legacy constructed rows work too.
- `resolve_project_metadata` (lines 245–317): `resolve_project_metadata(rows, config, base)` — Resolve all enabled samples once; no filesystem writes or expression reads.
- `metadata_preview` (lines 320–324): `metadata_preview(project)` — Small per-sample table, not a bin/cell matrix; suitable for notebook 00.

Observed internal imports: `vhd/control/manifest.py`


Observed importing files: `vhd/center/importers.py`, `vhd/control/manifest.py`, `vhd/sample_metadata.py`

## `vhd/control/storage.py`

Explicit local/remote staging, free-space checks, inventories and immutable publication under declared policy. No input mutation or mount operations.

Source: [vhd/control/storage.py:1–148](source_snapshot/vhd/control/storage.py#L1-L148)

- `join_uri` (lines 13–14): `join_uri(root, *parts)`
- `sha256` (lines 17–21): `sha256(path)`
- `free_space_gate` (lines 24–29): `free_space_gate(directory, required_bytes=0, reserve_gib=20)`
- `fs_for` (lines 32–35): `fs_for(uri)`
- `localize` (lines 38–87): `localize(uri, scratch, policy)`
- `inventory` (lines 90–95): `inventory(source)`
- `publish_tree` (lines 98–148): `publish_tree(source, destination, policy, *, execute=False)` — A category is committed only after all payload files are copied and verified.

Observed internal imports: `vhd/control/manifest.py`, `vhd/core.py`


Observed importing files: `vhd/control/paths_v3.py`, `vhd/control/runner.py`, `vhd/he/workflow.py`, `vhd/persistence/transaction.py`

## `vhd/core.py`

Shared numerical, identity and cache contracts: JSON serialization, signatures, stage locks, raw integer-CSR checks, QC metrics, coordinate transforms, H5AD-safe values and environment reports.

Source: [vhd/core.py:1–341](source_snapshot/vhd/core.py#L1-L341)

- `jsonable` (lines 25–36): `jsonable(value: Any) -> Any`
- `dump_json` (lines 39–44): `dump_json(value: Any, path: str | Path) -> None`
- `digest` (lines 47–48): `digest(value: Any) -> str`
- `dataframe_digest` (lines 52–60): `dataframe_digest(df, chunk_rows=250000)` — Hash a large metadata frame without expanding millions of uint64 hashes into Python ints.
- `file_stamp` (lines 63–83): `file_stamp(path: str | Path, full_hash: bool=False) -> dict` — Default size/mtime fingerprint is cheap; full_hash=True reads the entire file.
- `load_config` (lines 86–103): `load_config(path: str | Path) -> dict`
- `sample_paths` (lines 106–125): `sample_paths(cfg: dict, spec: dict) -> dict[str, Path]`
- `require_review` (lines 128–134): `require_review(cfg: dict, spec: dict, fresh_qc: bool=True) -> None`
- `stage_lock` (lines 138–148): `stage_lock(directory: str | Path, stage: str)` — One writer per stage/sample. A stale lock requires deliberate manual review.
- `reusable` (lines 151–164): `reusable(marker: Path, signature: str, required: list[Path]) -> bool`
- `completed` (lines 167–169): `completed(marker: Path, signature: str, required: list[Path], **details) -> None`
- `integer_csr` (lines 172–190): `integer_csr(x, tolerance: float=1e-06)`
- `qc_metrics` (lines 193–205): `qc_metrics(x, gene_symbols) -> pd.DataFrame`
- `canonical_qc` (lines 208–214): `canonical_qc(values) -> pd.Series`
- `affine` (lines 217–225): `affine(values) -> np.ndarray`
- `translate` (lines 228–229): `translate(x, y)`
- `transform_xy` (lines 232–237): `transform_xy(xy, matrix)`
- `fit_grid_affine` (lines 240–250): `fit_grid_affine(rows, cols, fullres_xy, tolerance_px=0.1, seed=42, *, rounding_policy='verified_integer')` — Validate a strict affine or an all-bin integer-rounding witness.
- `proseg_to_fullres` (lines 253–265): `proseg_to_fullres(mode: str, geom: dict, explicit=None)`
- `crop_mask_transform` (lines 268–271): `crop_mask_transform(left, top, source_width, source_height, output_width, output_height)` — Mask INDEX centers -> original-image INDEX centers, including resize half-pixel offsets.
- `safe_uns` (lines 274–292): `safe_uns(value)` — Keep arbitrary legacy .uns portable without heterogeneous arrays of dictionaries.
- `safe_frame` (lines 295–307): `safe_frame(df)`
- `write_h5ad` (lines 310–327): `write_h5ad(adata, path: Path)`
- `environment_report` (lines 330–341): `environment_report()`

Observed internal imports: `vhd/grid_geometry.py`


Observed importing files: `vhd/adapters/anndata_input.py`, `vhd/adapters/assemble.py`, `vhd/adapters/bins.py`, `vhd/adapters/cells.py`, `vhd/analysis_qc.py`, `vhd/annotations/alignment.py`, `vhd/annotations/area_sampling.py`, `vhd/annotations/discovery.py`, `vhd/annotations/geometry.py`, `vhd/annotations/preview_categories.py`, `vhd/annotations/projective_sampling.py`, `vhd/annotations/raster.py`, `vhd/annotations/visual_approval.py`, `vhd/annotations/workflow.py`, `vhd/bin_master.py`, `vhd/cells.py`, `vhd/center/single_sample.py`, `vhd/compact_images.py`, `vhd/compute/launch.py`, `vhd/compute/probe.py`, `vhd/compute/scvi_state.py`, `vhd/compute/scvi_worker.py`, `vhd/control/manifest.py`, `vhd/control/paths_v3.py`, `vhd/control/prechecks.py`, `vhd/control/runner.py`, `vhd/control/storage.py`, `vhd/grid_diagnostics.py`, `vhd/he/fixed.py`, `vhd/he/source.py`, `vhd/he/workflow.py`, `vhd/images.py`, `vhd/integration.py`, `vhd/io.py`, `vhd/master.py`, `vhd/persistence/spatial.py`, `vhd/persistence/transaction.py`, `vhd/plots.py`, `vhd/preflight.py`, `vhd/projective_storage.py`, `vhd/qc.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/reconstruction/geometry.py`, `vhd/reconstruction/reports.py`, `vhd/reconstruction/storage.py`, `vhd/sample_metadata.py`, `vhd/segmentation.py`, `vhd/storage.py`

## `vhd/count_display.py`

Count-axis presentation transforms and labels only; does not normalize or modify the scientific values.

Source: [vhd/count_display.py:1–25](source_snapshot/vhd/count_display.py#L1-L25)

- `transform` (lines 5–9): `transform(values, base=10)`
- `ticks` (lines 12–18): `ticks(maximum, base=10)`
- `label_axis` (lines 21–25): `label_axis(ax, axis, maximum, label, base=10)`

Observed internal imports: None found statically.


Observed importing files: `vhd/plots.py`

## `vhd/grid_diagnostics.py`

Coordinate-only inspection using position tables and barcode order before count/image arrays; writes diagnostic reports only through explicit report operations.

Source: [vhd/grid_diagnostics.py:1–174](source_snapshot/vhd/grid_diagnostics.py#L1-L174)

- `read_matrix_barcodes` (lines 21–44): `read_matrix_barcodes(matrix)`
- `positions_for_matrix` (lines 47–69): `positions_for_matrix(sr)` — Reproduce the original exact barcode join, but before expression loading.
- `fit_and_report` (lines 72–99): `fit_and_report(rows, cols, xy, coordinate_settings, *, report_path=None, source=None, source_mpp=None, context=None, source_column_dtypes=None)` — Use the same check in diagnostics, raw import, and existing-bin import.
- `_physical_units` (lines 102–109): `_physical_units(report, source_mpp)`
- `prepare_raw_grid` (lines 112–121): `prepare_raw_grid(sr, cfg, spec, *, report_path=None)`
- `diagnose_project` (lines 124–159): `diagnose_project(project, sample_keys=None, *, write_reports=False)` — Inspect selected raw inputs only. No workers, expression, images or data writes.
- `report_summary` (lines 162–174): `report_summary(reports)`

Observed internal imports: `vhd/control/manifest.py`, `vhd/core.py`, `vhd/grid_geometry.py`, `vhd/io.py`, `vhd/projective_grid.py`


Observed importing files: `tools/inspect_bin_grid.py`, `vhd/adapters/bins.py`, `vhd/io.py`

## `vhd/grid_geometry.py`

Checks affine fits and verified integer-rounding cases without changing the source coordinates. Exposes projective diagnostic evidence for the model-selection layer.

Source: [vhd/grid_geometry.py:1–261](source_snapshot/vhd/grid_geometry.py#L1-L261)

- `GridGeometryError` (lines 20–24): `class GridGeometryError(ValueError)` — A failed grid check with a JSON-serializable diagnostic report.
- `GridGeometryError.__init__` (lines 22–24): `__init__(self, message, report)`
- `_inputs` (lines 27–49): `_inputs(rows, cols, fullres_xy, tolerance_px, chunk_size)`
- `_design` (lines 52–55): `_design(rows, cols, indices, center, scale)`
- `_matrix` (lines 58–64): `_matrix(coef, center, scale)`
- `_metrics` (lines 67–98): `_metrics(rows, cols, xy, a, chunk_size)`
- `_axis_witness` (lines 101–147): `_axis_witness(rows, cols, xy, axis, initial, center, scale, chunk_size, seed)` — Small cutting-plane LP; every proposed witness is checked over ALL bins.
- `_projective_diagnostic` (lines 150–189): `_projective_diagnostic(rows, cols, xy, selected, center, scale, chunk_size)` — Report a candidate projective fit; NEVER authorize it as raster geometry.
- `fit_grid_affine_checked` (lines 192–261): `fit_grid_affine_checked(rows, cols, fullres_xy, tolerance_px=0.1, seed=42, *, rounding_policy='verified_integer', chunk_size=250000, diagnose_projective=True)` — Return affine plus audit, or fail with GridGeometryError.report.

Observed internal imports: None found statically.


Observed importing files: `vhd/core.py`, `vhd/grid_diagnostics.py`, `vhd/projective_grid.py`

## `vhd/he/__init__.py`

Quantitative fixed-reference H&E; display normalization is kept separate.

Source: [vhd/he/__init__.py:1–2](source_snapshot/vhd/he/__init__.py#L1-L2)


Observed internal imports: `vhd/he/fixed.py`


Observed importing files: None found statically.

## `vhd/he/display_legacy.py`

Retained display-oriented Macenko normalizer with repaired return contracts. Eager display preprocessing, not the fixed-reference quantitative tissue-score definition.

Source: [vhd/he/display_legacy.py:1–339](source_snapshot/vhd/he/display_legacy.py#L1-L339)

- `_as_hwc` (lines 10–20): `_as_hwc(img_cyx: np.ndarray) -> np.ndarray` — Convert SpatialData-style image from (c, y, x) to (y, x, c). Keeps only first 3 channels if RGBA.
- `_as_cyx` (lines 22–31): `_as_cyx(img_hwc: np.ndarray) -> np.ndarray` — Convert image from (y, x, c) to (c, y, x).
- `_auto_Io` (lines 33–51): `_auto_Io(img: np.ndarray) -> float` — Pick a robust transmitted-light / white intensity for OD computation. Works for uint8, uint16, and float images.
- `_batch_lstsq` (lines 53–65): `_batch_lstsq(HE: np.ndarray, Y: np.ndarray, batch: int=100000) -> np.ndarray` — Solve C = argmin ||HE*C - Y|| in batches.
- `macenko_normalize_visiumhd` (lines 67–339): `macenko_normalize_visiumhd(img, mask=None, Io='auto', alpha=1.0, beta=0.15, sample_max=200000, lstsq_batch=200000, return_HE_H_E=False, stain_mode='both', basis_mode='auto', output_basis='hybrid', concentration_percentile=99, clip_concentrations=False, random_state=0, return_concentrations=False, concentration_output='normalized')` — Macenko H&E normalization adapted for Visium HD / SpatialData images.

Observed internal imports: None found statically.


Observed importing files: None found statically.

## `vhd/he/fixed.py`

Quantitative fixed-reference H/E extraction, fixed scaling, combination and center sampling. Keep separate from slide-wise display normalization.

Source: [vhd/he/fixed.py:1–150](source_snapshot/vhd/he/fixed.py#L1-L150)

- `positive_int` (lines 14–17): `positive_int(value, name)`
- `rgb255` (lines 20–44): `rgb255(img, *, channel_axis=None, intensity_range=None, alpha='reject')`
- `estimate_background_Io_rgb` (lines 47–57): `estimate_background_Io_rgb(img_hwc, *, sat_max=0.08, value_quantile=90, io_quantile=99.5, fallback=255, min_pixels=1000)` — Call ONCE per source/calibration ROI, store result, never estimate per tile.
- `extract_he_concentrations_reference` (lines 60–75): `extract_he_concentrations_reference(img, *, Io=255.0, white_balance=False, clip_concentrations=True, lstsq_batch=200000, channel_axis=None, intensity_range=None, reference=HE_REFERENCE, alpha='reject')`
- `combine_he_fixed_tissue_signal` (lines 78–96): `combine_he_fixed_tissue_signal(H_fixed, E_fixed, *, method='soft_union', h_weight=1.0, e_weight=1.0, score_threshold=None, h_threshold=None, e_threshold=None)`
- `fixed_scale_he_tissue_score` (lines 99–105): `fixed_scale_he_tissue_score(H_conc, E_conc, *, h_limit=1.9705, e_limit=1.0308, h_weight=1.0, e_weight=1.0, method='soft_union')`
- `combine_he_tissue_signal` (lines 108–111): `combine_he_tissue_signal(H_u8, E_u8, **kwargs)` — Legacy display-only wrapper. Do not feed per-image percentile-scaled maps.
- `sample_field` (lines 114–139): `sample_field(field, xy, *, source_to_fullres, interpolation='linear', chunk_size=250000, tile_size=512)` — Interpolate image pixel-CENTER indices at bin centers, not area averages.
- `map_hires_image_to_visiumhd_bins` (lines 142–150): `map_hires_image_to_visiumhd_bins(adata, image_2d, *, tissue_hires_scalef, out_key, spatial_key='spatial', interpolation='linear', chunk_size=1000000, show_progress=True)`

Observed internal imports: `vhd/core.py`


Observed importing files: `tools/demo_annotation_signal_contract.py`, `vhd/annotations/workflow.py`, `vhd/he/__init__.py`, `vhd/he/workflow.py`

## `vhd/he/qc_review.py`

Streaming score/count histograms, sampled scatter and all-valid-bin density plots from existing measurement metadata, with threshold inspection helpers.

Source: [vhd/he/qc_review.py:1–607](source_snapshot/vhd/he/qc_review.py#L1-L607)

- `_positive_int` (lines 29–32): `_positive_int(value, name)`
- `_cutoff` (lines 35–43): `_cutoff(value, name, upper=None)`
- `_thresholds` (lines 46–77): `_thresholds(settings, candidate=None)` — Candidate values affect report overlays only, never PROJECT or JSON.
- `_validated_arrays` (lines 80–95): `_validated_arrays(batch)`
- `_PointSample` (lines 98–122): `class _PointSample()` — Uniform random-priority subset without a full-data index allocation.
- `_PointSample.__init__` (lines 100–105): `__init__(self, size, seed)`
- `_PointSample.add` (lines 107–118): `add(self, h, t)`
- `_PointSample.result` (lines 120–122): `result(self)`
- `summarize_batches` (lines 125–238): `summarize_batches(batch_factory, *, thresholds, score_bins=100, transcript_bins=160, scatter_max_points=100000, seed=42, transcript_axis_max=None, progress=None)` — Two complete scalar scans; histograms use ALL eligible rows, scatter is capped.
- `_read_h5_obs_vector` (lines 241–260): `_read_h5_obs_vector(obs, key, start, end, *, strings=False)` — Narrow reader for standard AnnData obs arrays and nullable numeric arrays.
- `iter_metadata_batches` (lines 263–310): `iter_metadata_batches(bins_path, score_path, *, metric='total_counts', chunk_size=250000)` — Read ONLY obs/index, obs/metric and three Parquet columns. Never read X.
- `_stamp` (lines 313–316): `_stamp(path)`
- `_check_completed_measurement` (lines 319–338): `_check_completed_measurement(work, cfg)`
- `threshold_locations` (lines 341–360): `threshold_locations(project, sample_keys=None)` — Read-only table of where to edit defaults/overrides and their effective values.
- `_count_ticks` (lines 363–367): `_count_ticks(axis_max)`
- `_format_ticks` (lines 370–377): `_format_ticks(ax, axis, axis_max)`
- `render_review` (lines 380–471): `render_review(result, folder, *, sample, thresholds, dpi=300)` — Four separate figures, using Matplotlib's default palette.
- `_write_report` (lines 474–500): `_write_report(result, folder, *, sample, thresholds, provenance, dpi)`
- `generate_bin_qc_review` (lines 503–582): `generate_bin_qc_review(project, sample_keys=None, *, execute=False, candidate_thresholds=None, chunk_size=250000, score_bins=100, transcript_bins=160, scatter_max_points=100000, seed=42, transcript_axis_max=None)` — Notebook entry point. Serial samples; plot-only execution, preview by default.
- `validate_bin_qc_thresholds` (lines 585–607): `validate_bin_qc_thresholds(project, sample_keys=None)` — Print effective cutoff locations; raise once before launching any workers.

Observed internal imports: `vhd/control/manifest.py`, `vhd/control/paths_v3.py`


Observed importing files: `vhd/center/controller.py`

## `vhd/he/source.py`

Chooses configured or resolved H&E score inputs and reports paths/calibration without asserting biological registration.

Source: [vhd/he/source.py:1–88](source_snapshot/vhd/he/source.py#L1-L88)

- `resolve_he_source` (lines 15–39): `resolve_he_source(cfg, spec)` — Return path, pixel-index-to-fullres transform and auditable source choices.
- `diagnose_he_sources` (lines 42–88): `diagnose_he_sources(project, sample_keys=None)` — Read-only source check; no image pixels, count arrays, staging or outputs.

Observed internal imports: `vhd/compact_images.py`, `vhd/control/manifest.py`, `vhd/core.py`, `vhd/spaceranger_images.py`


Observed importing files: `vhd/he/workflow.py`

## `vhd/he/workflow.py`

Separate fixed H&E measurement and explicit bin classification stages with sidecars/receipts and image overlays. Threshold changes do not redefine the raw expression matrix.

Source: [vhd/he/workflow.py:1–81](source_snapshot/vhd/he/workflow.py#L1-L81)

- `measure` (lines 11–47): `measure(cfg, spec)`
- `classify` (lines 50–64): `classify(obs, measurement, settings)`
- `classify_stage` (lines 67–81): `classify_stage(cfg, spec)`

Observed internal imports: `vhd/annotations/raster.py`, `vhd/control/storage.py`, `vhd/core.py`, `vhd/he/fixed.py`, `vhd/he/source.py`, `vhd/images.py`, `vhd/io.py`, `vhd/plots.py`


Observed importing files: `vhd/control/runner.py`

## `vhd/images.py`

Image headers, regions, thumbnails, RGB sampling, optional display normalization and lazy/resized image access. Works in explicitly supplied image coordinates rather than redefining bin coordinates.

Source: [vhd/images.py:1–187](source_snapshot/vhd/images.py#L1-L187)

- `image_info` (lines 10–37): `image_info(path, mpp_override=None)` — OpenSlide first; ordinary RGB TIFF fallback requires tifffile + zarr.
- `_white_rgb` (lines 40–49): `_white_rgb(array)`
- `read_region` (lines 52–78): `read_region(path, left, top, width, height)` — Read only a rectangular level-0 RGB region. Reopens file; safe inside delayed tasks.
- `thumbnail` (lines 81–103): `thumbnail(info, max_side=3000)`
- `sample_rgb` (lines 106–114): `sample_rgb(info, xy, thumb)` — Approximate image intensity at bin centers using a thumbnail; never changes coordinates.
- `lab_stats` (lines 117–125): `lab_stats(rgb, od_threshold=0.08)`
- `reinhard` (lines 128–138): `reinhard(rgb, source_stats, target_stats)` — Optional LAB mean/std color matching; not stain deconvolution and not the missing legacy helper.
- `_image_tile` (lines 141–145): `_image_tile(path, x, y, w, h, normalization)`
- `lazy_rgb` (lines 148–159): `lazy_rgb(info, tile_size=1024, normalization=None)`
- `resized_crop` (lines 162–187): `resized_crop(info, bounds, target_mpp, output_path, normalization=None, tile_size=1024)` — Tile-by-tile resampling to a memory-mapped RGB crop; actual dimensions define the affine.

Observed internal imports: `vhd/core.py`


Observed importing files: `tools/preview_assets_on_he.py`, `vhd/adapters/assemble.py`, `vhd/adapters/bins.py`, `vhd/adapters/cells.py`, `vhd/annotations/discovery.py`, `vhd/annotations/preview_categories.py`, `vhd/annotations/workflow.py`, `vhd/cells.py`, `vhd/compact_images.py`, `vhd/he/workflow.py`, `vhd/io.py`, `vhd/plots.py`, `vhd/preflight.py`, `vhd/qc.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/segmentation.py`, `vhd/storage.py`

## `vhd/integration.py`

Joint-analysis orchestration: select eligible raw-count cells, select common HVGs, prepare scVI inputs, delegate training, build Leiden/UMAP companions, diagnostics and explicit writeback.

Source: [vhd/integration.py:1–339](source_snapshot/vhd/integration.py#L1-L339)

- `integration_dir` (lines 17–20): `integration_dir(cfg)`
- `eligible` (lines 23–28): `eligible(obs, cfg)`
- `consensus_hvg` (lines 31–44): `consensus_hvg(rankings, number)` — Batch-balanced consensus: number of top-HVG batches, then median within-batch rank.
- `prepare_scvi` (lines 47–169): `prepare_scvi(cfg)` — Two pass, one sample in RAM at a time; concat_on_disk assembles the shared-HVG input.
- `sparse_h5_ram_estimate` (lines 172–179): `sparse_h5_ram_estimate(path)`
- `train_scvi` (lines 182–187): `train_scvi(cfg)` — Compatibility single-device entry. DDP must use the explicit script launcher.
- `leiden_umaps` (lines 190–243): `leiden_umaps(cfg)`
- `diagnostics` (lines 246–272): `diagnostics(cfg)`
- `writeback_annotations` (lines 275–339): `writeback_annotations(cfg, spec)` — Append a SMALL zero-gene annotation table. Never rewrite huge bins or duplicate cell counts.

Observed internal imports: `vhd/analysis_qc.py`, `vhd/compute/clustering.py`, `vhd/compute/scvi_worker.py`, `vhd/core.py`, `vhd/io.py`, `vhd/palette.py`, `vhd/persistence/__init__.py`, `vhd/plots.py`, `vhd/reconstruction/storage.py`, `vhd/storage.py`


Observed importing files: `vhd/analysis_qc.py`, `vhd/compute/integration_worker.py`, `vhd/compute/scvi_worker.py`, `vhd/control/runner.py`

## `vhd/io.py`

Space Ranger resolution and count ingestion; original coordinate assembly; metadata-only access, selected table loading and selected-bin loading. Distinguishes table inspection from reading expression.

Source: [vhd/io.py:1–184](source_snapshot/vhd/io.py#L1-L184)

- `resolve_spaceranger` (lines 18–28): `resolve_spaceranger(spec)`
- `read_raw_counts` (lines 31–51): `read_raw_counts(path)`
- `ingest` (lines 54–110): `ingest(cfg, spec)`
- `h5_metadata` (lines 113–119): `h5_metadata(path)`
- `table_metadata` (lines 122–130): `table_metadata(store, table)` — Read ONLY obs/var; do not instantiate the huge X matrix or unrelated tables.
- `load_table` (lines 133–155): `load_table(store, table='cells', *, merge_scvi=False)` — Eagerly load one named AnnData, not all tables. This is NOT a row-backed reader.
- `load_spatial_with_table` (lines 158–163): `load_spatial_with_table(store, table='cells', *, merge_scvi=False, elements=('images', 'labels', 'shapes', 'points'))`
- `selected_bins` (lines 166–184): `selected_bins(cfg, spec)` — Materialize only QC-kept rows of the raw-bin staging H5AD.

Observed internal imports: `vhd/core.py`, `vhd/grid_diagnostics.py`, `vhd/images.py`, `vhd/master.py`, `vhd/projective_grid.py`


Observed importing files: `vhd/adapters/assemble.py`, `vhd/adapters/bins.py`, `vhd/adapters/cells.py`, `vhd/analysis_qc.py`, `vhd/annotations/workflow.py`, `vhd/bin_master.py`, `vhd/cells.py`, `vhd/center/single_sample.py`, `vhd/control/runner.py`, `vhd/grid_diagnostics.py`, `vhd/he/workflow.py`, `vhd/integration.py`, `vhd/master.py`, `vhd/persistence/spatial.py`, `vhd/plots.py`, `vhd/preflight.py`, `vhd/qc.py`, `vhd/reconstruction/storage.py`, `vhd/sample_metadata.py`, `vhd/segmentation.py`, `vhd/storage.py`

## `vhd/master.py`

Coordinates base/legacy master creation/reuse, current annotation checks, H/E-map storage and geometric cell-annotation refresh. Named dual-method append lives in reconstruction/storage.py.

Source: [vhd/master.py:1–146](source_snapshot/vhd/master.py#L1-L146)

- `effective_bin_obs` (lines 9–11): `effective_bin_obs(p)`
- `transfer_config` (lines 14–20): `transfer_config(cfg, p)`
- `current_annotations` (lines 23–40): `current_annotations(cfg, spec)`
- `store_he_maps` (lines 43–61): `store_he_maps(cfg, spec)`
- `assemble_master` (lines 64–114): `assemble_master(cfg, spec, bins_only=False)`
- `refresh_cell_annotations` (lines 117–146): `refresh_cell_annotations(cfg, spec)`

Observed internal imports: `vhd/adapters/assemble.py`, `vhd/annotations/geometry.py`, `vhd/annotations/raster.py`, `vhd/annotations/transfer.py`, `vhd/annotations/workflow.py`, `vhd/bin_master.py`, `vhd/cells.py`, `vhd/compact_images.py`, `vhd/core.py`, `vhd/io.py`, `vhd/persistence/__init__.py`, `vhd/sample_metadata.py`, `vhd/storage.py`


Observed importing files: `vhd/adapters/assemble.py`, `vhd/adapters/cells.py`, `vhd/annotations/workflow.py`, `vhd/bin_master.py`, `vhd/cells.py`, `vhd/control/prechecks.py`, `vhd/control/runner.py`, `vhd/io.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/reconstruction/storage.py`, `vhd/segmentation.py`, `vhd/storage.py`

## `vhd/palette.py`

Recorded categorical palette and optional labelled extensions; natural ordering for cluster labels.

Source: [vhd/palette.py:1–60](source_snapshot/vhd/palette.py#L1-L60)

- `natural_order` (lines 20–24): `natural_order(values)`
- `distinct_palette` (lines 27–60): `distinct_palette(n: int, allow_extension=True)`

Observed internal imports: None found statically.


Observed importing files: `vhd/center/single_sample.py`, `vhd/integration.py`, `vhd/plots.py`

## `vhd/persistence/__init__.py`

Explicit master updates with retained recovery data; no mount management.

Source: [vhd/persistence/__init__.py:1–3](source_snapshot/vhd/persistence/__init__.py#L1-L3)


Observed internal imports: `vhd/persistence/spatial.py`, `vhd/persistence/transaction.py`


Observed importing files: `vhd/annotations/workflow.py`, `vhd/bin_master.py`, `vhd/integration.py`, `vhd/master.py`, `vhd/reconstruction/storage.py`, `vhd/sample_metadata.py`

## `vhd/persistence/spatial.py`

Patched selective SpatialData element and table-metadata writes. Refreshes only affected table roots plus the container root; delegates recoverable replacement to transaction.py.

Source: [vhd/persistence/spatial.py:1–216](source_snapshot/vhd/persistence/spatial.py#L1-L216)

- `open_group` (lines 16–18): `open_group(path, mode='r')`
- `format_number` (lines 21–25): `format_number(path)`
- `refresh_metadata` (lines 28–64): `refresh_metadata(store, *, table_names=())` — Refresh only explicitly changed tables, then the container's root cache.
- `aligned` (lines 67–69): `aligned(frame, index)`
- `update_table_metadata` (lines 72–137): `update_table_metadata(store, table, *, obs=None, obsm=None, uns=None, drop_obs=(), policy, staging_dir, execute=False, single_writer_ack=False)` — Merge selected columns and indexed embedding DataFrames. Never write X/layers.
- `persist_changes` (lines 140–216): `persist_changes(sdata, *, new_elements=(), replace_elements=(), transformation_elements=(), policy, staging_dir, execute=False, single_writer_ack=False, selected_readback=False)` — Explicit intent. Non-table data replacements are NEVER silently transform-only.

Observed internal imports: `vhd/control/paths_v3.py`, `vhd/core.py`, `vhd/io.py`, `vhd/persistence/transaction.py`


Observed importing files: `vhd/annotations/workflow.py`, `vhd/persistence/__init__.py`, `vhd/sample_metadata.py`

## `vhd/persistence/transaction.py`

Verifies copies and journals component replacements with explicit recovery/retirement. Recoverable multi-key changes are not a globally atomic filesystem transaction.

Source: [vhd/persistence/transaction.py:1–127](source_snapshot/vhd/persistence/transaction.py#L1-L127)

- `inventory` (lines 15–24): `inventory(path)`
- `copy_verified` (lines 27–30): `copy_verified(src, dst)`
- `remove_component` (lines 33–36): `remove_component(p)`
- `target` (lines 39–44): `target(store, rel)`
- `validate_store` (lines 47–52): `validate_store(store, policy)`
- `writer` (lines 56–65): `writer(store, policy, ack=False, recovery=False)`
- `apply_replacements` (lines 68–105): `apply_replacements(store, replacements, policy, *, execute=False, single_writer_ack=False, refresh=None, verify=None, precondition=None, _fault=None)`
- `recover_transaction` (lines 108–127): `recover_transaction(journal, policy, *, execute=False, single_writer_ack=False, allow_partial=False, refresh=None)`

Observed internal imports: `vhd/control/paths_v3.py`, `vhd/control/storage.py`, `vhd/core.py`


Observed importing files: `vhd/annotations/workflow.py`, `vhd/persistence/__init__.py`, `vhd/persistence/spatial.py`

## `vhd/plots.py`

Shared count histograms, numeric/categorical spatial scatter, technical QC panels, boundary overlays and report-only replotting.

Source: [vhd/plots.py:1–161](source_snapshot/vhd/plots.py#L1-L161)

- `sample_indices` (lines 9–13): `sample_indices(n, maximum=300000, seed=42)`
- `finish` (lines 16–20): `finish(fig, path, dpi=300)`
- `histogram` (lines 23–37): `histogram(values, title, path, label=None, log1p=False, dpi=300, log_base=10)`
- `scatter_numeric` (lines 40–66): `scatter_numeric(xy, values, title, path, *, thumb=None, image_size=None, coordinate_labels=('x', 'y'), max_points=300000, dpi=300, log1p=False, count_axes=None, log_base=10)`
- `scatter_categorical` (lines 69–102): `scatter_categorical(xy, values, title, path, *, colors=None, thumb=None, image_size=None, max_points=300000, dpi=300, point_size=0.8, labels=('x', 'y'), allow_extension=True)`
- `standard_qc_plots` (lines 105–120): `standard_qc_plots(obs, output_dir, prefix, dpi=300, log_base=10)`
- `boundary_overlay` (lines 123–150): `boundary_overlay(polygons_image, info, thumb, path, bounds=None, dpi=300, max_polygons=75000)`
- `replot_sample` (lines 153–161): `replot_sample(cfg, spec)`

Observed internal imports: `vhd/core.py`, `vhd/count_display.py`, `vhd/images.py`, `vhd/io.py`, `vhd/palette.py`


Observed importing files: `tools/demo_annotation_signal_contract.py`, `vhd/adapters/bins.py`, `vhd/adapters/cells.py`, `vhd/analysis_qc.py`, `vhd/cells.py`, `vhd/center/single_sample.py`, `vhd/compute/scvi_worker.py`, `vhd/control/runner.py`, `vhd/he/workflow.py`, `vhd/integration.py`, `vhd/qc.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/segmentation.py`

## `vhd/preflight.py`

Legacy/source-level configuration and SpatialData API checks. Different from the per-worker import probe and the two real-science dual-method smoke tests.

Source: [vhd/preflight.py:1–57](source_snapshot/vhd/preflight.py#L1-L57)

- `preflight` (lines 11–43): `preflight(cfg)`
- `check_spatial_apis` (lines 46–57): `check_spatial_apis()`

Observed internal imports: `vhd/core.py`, `vhd/images.py`, `vhd/io.py`


Observed importing files: None found statically.

## `vhd/projective_grid.py`

Validates homographies, domain behavior and model-derived quadrilateral corners, keeping the original observed centers authoritative.

Source: [vhd/projective_grid.py:1–154](source_snapshot/vhd/projective_grid.py#L1-L154)

- `homography` (lines 16–25): `homography(value)`
- `project_xy` (lines 28–40): `project_xy(xy, matrix)` — Homogeneous divide, retaining arbitrary leading dimensions.
- `is_projective` (lines 43–46): `is_projective(geometry)` — Detect matrix semantics, not just a possibly missing descriptive field.
- `grid_corners` (lines 49–56): `grid_corners(rows, cols, matrix)`
- `_domain_audit` (lines 59–75): `_domain_audit(h, rows, cols)`
- `_projective_metrics` (lines 78–91): `_projective_metrics(rows, cols, xy, h, chunk_size)`
- `fit_grid_model_checked` (lines 94–146): `fit_grid_model_checked(rows, cols, fullres_xy, tolerance_px=0.1, seed=42, *, rounding_policy='verified_integer', geometry_policy='auto_projective', chunk_size=250000)` — Prefer existing affine behavior; otherwise validate a projective model.
- `geometry_contract` (lines 149–154): `geometry_contract(matrix)`

Observed internal imports: `vhd/grid_geometry.py`


Observed importing files: `vhd/adapters/assemble.py`, `vhd/adapters/bins.py`, `vhd/annotations/projective_sampling.py`, `vhd/annotations/workflow.py`, `vhd/grid_diagnostics.py`, `vhd/io.py`, `vhd/projective_storage.py`, `vhd/reconstruction/geometry.py`, `vhd/storage.py`

## `vhd/projective_storage.py`

Creates/checks full-resolution polygon representations for non-affine bins. Bounded construction does not make the final GeoDataFrame lazy.

Source: [vhd/projective_storage.py:1–95](source_snapshot/vhd/projective_storage.py#L1-L95)

- `bin_instance_ids` (lines 13–26): `bin_instance_ids(obs, geometry)`
- `make_projective_bin_shapes` (lines 29–56): `make_projective_bin_shapes(obs, geometry, chunk_size=100000)`
- `validate_projective_bin_shapes` (lines 59–95): `validate_projective_bin_shapes(element, obs, geometry, sample_indices)` — Full ID relation check and sampled vertex/model check; no expression read.

Observed internal imports: `vhd/core.py`, `vhd/projective_grid.py`


Observed importing files: `vhd/adapters/assemble.py`, `vhd/storage.py`

## `vhd/qc.py`

Retained bin-QC pathway used when the fixed H&E-score route is not enabled. Do not confuse it with he/workflow.classify_stage or the later analysis-QC stage.

Source: [vhd/qc.py:1–132](source_snapshot/vhd/qc.py#L1-L132)

- `build_bin_qc` (lines 16–132): `build_bin_qc(cfg, spec)`

Observed internal imports: `vhd/core.py`, `vhd/images.py`, `vhd/io.py`, `vhd/plots.py`


Observed importing files: `vhd/control/runner.py`

## `vhd/reconstruction/__init__.py`

Independent cell reconstruction branches sharing the reviewed H&E prior.

Source: [vhd/reconstruction/__init__.py:1–4](source_snapshot/vhd/reconstruction/__init__.py#L1-L4)


Observed internal imports: `vhd/reconstruction/config.py`


Observed importing files: None found statically.

## `vhd/reconstruction/bin2cell_adapter.py`

Calls actual Bin2cell expansion/aggregation on prepared bins/prior, validates raw-count/coordinate contracts, computes technical QC and optionally creates separate density-derived objects.

Source: [vhd/reconstruction/bin2cell_adapter.py:1–278](source_snapshot/vhd/reconstruction/bin2cell_adapter.py#L1-L278)

- `_sources` (lines 20–36): `_sources(cfg, spec)`
- `limited_affinity` (lines 40–48): `limited_affinity(n)` — Bin2cell uses cKDTree workers=-1. Bound that query to this worker's CPUs.
- `expand_with_upstream` (lines 51–70): `expand_with_upstream(a, settings, b2c, threads=1)` — Small/all-labelled edge cases are explicit; ordinary cases use upstream API.
- `_load_bins` (lines 73–105): `_load_bins(cfg, p, obs, keep)`
- `_cell_qc` (lines 108–149): `_cell_qc(a, g, cfg, spec, geom, report)`
- `run_bin2cell` (lines 152–234): `run_bin2cell(cfg, spec)`
- `_secondary_signature` (lines 237–242): `_secondary_signature(cfg, p)`
- `run_secondary` (lines 245–278): `run_secondary(cfg, spec)` — Optional fluorescence StarDist on a 2-um array-grid count-density image.

Observed internal imports: `vhd/annotations/transfer.py`, `vhd/cells.py`, `vhd/center/resources.py`, `vhd/core.py`, `vhd/images.py`, `vhd/master.py`, `vhd/plots.py`, `vhd/reconstruction/config.py`, `vhd/reconstruction/geometry.py`, `vhd/sample_metadata.py`, `vhd/segmentation.py`


Observed importing files: `vhd/control/runner.py`

## `vhd/reconstruction/config.py`

Validates Proseg/Bin2cell selections, analysis table, Bin2cell parameters/bin scope and method-specific paths; rewrites only generated-cell routes.

Source: [vhd/reconstruction/config.py:1–122](source_snapshot/vhd/reconstruction/config.py#L1-L122)

- `selected_methods` (lines 18–27): `selected_methods(cfg)` — None means untouched v5 cells route; an explicit list uses named tables.
- `generated_entry` (lines 30–31): `generated_entry(spec)`
- `analysis_table` (lines 34–46): `analysis_table(cfg, spec=None)`
- `bin2cell_settings` (lines 49–79): `bin2cell_settings(cfg)`
- `method_paths` (lines 82–95): `method_paths(p, method)` — Proseg keeps its existing on-disk cache. Bin2cell never overwrites it.
- `effective_bin_column` (lines 98–102): `effective_bin_column(cfg)`
- `apply_method_route` (lines 105–122): `apply_method_route(steps, cfg, row)` — Rewrite only generated-cell routes, preserving bin and imported-cell paths.

Observed internal imports: None found statically.


Observed importing files: `vhd/center/controller.py`, `vhd/center/importers.py`, `vhd/center/stages.py`, `vhd/center/ui.py`, `vhd/control/manifest.py`, `vhd/reconstruction/__init__.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/reconstruction/reports.py`, `vhd/reconstruction/storage.py`

## `vhd/reconstruction/geometry.py`

Samples the shared prior at bin positions, builds sparse aggregation assignment matrices, traces assigned-grid boundaries and transforms their vertices with holes/multipart support.

Source: [vhd/reconstruction/geometry.py:1–89](source_snapshot/vhd/reconstruction/geometry.py#L1-L89)

- `sample_prior` (lines 12–26): `sample_prior(mask, fullres_xy, geometry, prior_metadata, chunk_size=250000)`
- `assignment_matrix` (lines 29–37): `assignment_matrix(labels)` — Return sorted positive labels, cell-by-bin int64 matrix, and bin row mapping.
- `grid_layout` (lines 40–51): `grid_layout(rows, cols, max_pixels)`
- `label_polygons` (lines 54–89): `label_polygons(rows, cols, labels, matrix, max_pixels=50000000)`

Observed internal imports: `vhd/core.py`, `vhd/projective_grid.py`


Observed importing files: `vhd/reconstruction/bin2cell_adapter.py`

## `vhd/reconstruction/reports.py`

Creates the method comparison HTML/CSV/JSON from available method reports. These are descriptive alternative reconstructions, not ground-truth segmentation scores.

Source: [vhd/reconstruction/reports.py:1–28](source_snapshot/vhd/reconstruction/reports.py#L1-L28)

- `comparison_report` (lines 9–28): `comparison_report(cfg, spec)`

Observed internal imports: `vhd/center/reports.py`, `vhd/core.py`, `vhd/reconstruction/config.py`


Observed importing files: `vhd/reconstruction/storage.py`

## `vhd/reconstruction/storage.py`

Serially appends independent method tables and boundaries with cell-ID qualification, readback checks and receipts. Refreshes cell annotations using each method's appropriate assignments.

Source: [vhd/reconstruction/storage.py:1–183](source_snapshot/vhd/reconstruction/storage.py#L1-L183)

- `_read_shapes` (lines 16–23): `_read_shapes(store, region)`
- `verify_method` (lines 26–46): `verify_method(store, method)`
- `verify_written_counts` (lines 49–60): `verify_written_counts(store, method, expected, chunk_size=1000000)` — Compare the just-written CSR components in bounded reads while X is available.
- `canonicalize` (lines 63–75): `canonicalize(a, g, method, spec)` — Copy metadata/geometry identity only; retain the count matrix and coordinates.
- `_tracked_sources` (lines 78–85): `_tracked_sources(mp)`
- `append_method` (lines 88–122): `append_method(cfg, spec, method)`
- `assemble_methods` (lines 125–142): `assemble_methods(cfg, spec)`
- `refresh_method_annotations` (lines 145–183): `refresh_method_annotations(cfg, spec)`

Observed internal imports: `vhd/annotations/transfer.py`, `vhd/bin_master.py`, `vhd/cells.py`, `vhd/core.py`, `vhd/io.py`, `vhd/master.py`, `vhd/persistence/__init__.py`, `vhd/reconstruction/config.py`, `vhd/reconstruction/reports.py`, `vhd/sample_metadata.py`, `vhd/storage.py`


Observed importing files: `vhd/control/runner.py`, `vhd/integration.py`

## `vhd/sample_metadata.py`

Attaches resolved sample descriptors to AnnData observations and records ownership in uns; also offers an explicit selective synchronization path for existing tables. It does not perform spatial annotation transfer.

Source: [vhd/sample_metadata.py:1–180](source_snapshot/vhd/sample_metadata.py#L1-L180)

- `_record` (lines 17–31): `_record(uns)`
- `_matches` (lines 34–46): `_matches(series, value)`
- `_constant` (lines 49–57): `_constant(value, index)`
- `plan_sample_metadata` (lines 60–110): `plan_sample_metadata(obs, uns, spec, *, replace_owned=False, prune_owned=False)` — Return changed obs columns and the next provenance record; never mutate input.
- `attach_sample_metadata` (lines 113–124): `attach_sample_metadata(adata, spec)` — Attach to a newly created in-memory AnnData; inputs/counts stay unchanged.
- `sync_sample_metadata` (lines 127–180): `sync_sample_metadata(cfg, spec, *, execute=False, replace_owned=False, prune_owned=False)` — Preview or persist sample metadata on already assembled bins/cells only.

Observed internal imports: `vhd/control/sample_metadata.py`, `vhd/core.py`, `vhd/io.py`, `vhd/persistence/__init__.py`, `vhd/persistence/spatial.py`


Observed importing files: `vhd/adapters/assemble.py`, `vhd/adapters/cells.py`, `vhd/cells.py`, `vhd/master.py`, `vhd/reconstruction/bin2cell_adapter.py`, `vhd/reconstruction/storage.py`

## `vhd/segmentation.py`

Creates and gates the shared H&E StarDist nucleus prior; builds/checks external Proseg commands and validates durable outputs. Includes legacy multi-sample execution helpers.

Source: [vhd/segmentation.py:1–285](source_snapshot/vhd/segmentation.py#L1-L285)

- `gate_prior` (lines 22–53): `gate_prior(mask, bin_mask_xy, qc_keep, output, min_keep_bins=1, chunk_rows=256)` — Retain whole nuclei with >=N QC-kept bin CENTERS; this is not area-overlap integration.
- `prior_signature` (lines 56–62): `prior_signature(cfg, spec)`
- `stardist_prior` (lines 65–160): `stardist_prior(cfg, spec)`
- `proseg_paths` (lines 163–167): `proseg_paths(directory)`
- `check_proseg` (lines 170–183): `check_proseg(executable, directory)`
- `run_proseg` (lines 186–264): `run_proseg(cfg, spec)`
- `run_proseg_samples` (lines 267–285): `run_proseg_samples(cfg, specs)` — Parallel independent CPU processes. Memory estimates are USER-SUPPLIED, not guarantees.

Observed internal imports: `vhd/annotations/transfer.py`, `vhd/cells.py`, `vhd/core.py`, `vhd/images.py`, `vhd/io.py`, `vhd/master.py`, `vhd/plots.py`


Observed importing files: `vhd/annotations/transfer.py`, `vhd/cells.py`, `vhd/control/runner.py`, `vhd/reconstruction/bin2cell_adapter.py`

## `vhd/spaceranger_images.py`

Resolves hires/lowres PNGs and calibration from supported spatial folders within one configured Space Ranger outs, including split-file layout.

Source: [vhd/spaceranger_images.py:1–184](source_snapshot/vhd/spaceranger_images.py#L1-L184)

- `path_state` (lines 20–52): `path_state(path)` — Inspect one path and open readable files without reading payload bytes.
- `candidate_inventory` (lines 55–67): `candidate_inventory(outs)` — No recursive search, neighbor-sample search, hashing, copying or writes.
- `_read_scale` (lines 71–95): `_read_scale(path, resolution='hires')` — Read only the requested image scale; unrelated bin-specific keys may differ.
- `_check_usable` (lines 98–104): `_check_usable(item, field)`
- `_record` (lines 107–127): `_record(outs, resolution, image_item, scale_item, factor, rule)`
- `resolve_spaceranger_image` (lines 130–184): `resolve_spaceranger_image(outs, resolution='hires')` — Return image, matching scale and path provenance; do not read image pixels.

Observed internal imports: None found statically.


Observed importing files: `vhd/compact_images.py`, `vhd/he/source.py`

## `vhd/storage.py`

Low-level SpatialData construction/linkage helpers: affine bin-label rasters, table-region relationships, optional prior and readback validation. Delegates assembly to the adapter rather than owning the controller.

Source: [vhd/storage.py:1–171](source_snapshot/vhd/storage.py#L1-L171)

- `scale0` (lines 15–22): `scale0(element)`
- `index_to_intrinsic_transform` (lines 25–35): `index_to_intrinsic_transform(element, index_to_fullres)` — Fit against the PARSED raster's real coordinates, rather than assuming 0 vs 0.5 origins.
- `set_fullres_transform` (lines 38–42): `set_fullres_transform(element, index_to_fullres)`
- `make_bin_labels` (lines 45–61): `make_bin_labels(obs, geom)`
- `parse_table` (lines 64–71): `parse_table(a, region, instance_ids)`
- `optional_nuclei` (lines 74–96): `optional_nuclei(cfg, spec, p, geom)`
- `assemble_sample` (lines 99–102): `assemble_sample(cfg, spec)` — Compatibility entry; use the same explicit image policy and master writer.
- `validate_store` (lines 105–171): `validate_store(store, spatial_elements=None)` — Validate both table relations and sampled raster centers WITHOUT reading expression matrices.

Observed internal imports: `vhd/compact_images.py`, `vhd/core.py`, `vhd/images.py`, `vhd/io.py`, `vhd/master.py`, `vhd/projective_grid.py`, `vhd/projective_storage.py`


Observed importing files: `vhd/adapters/assemble.py`, `vhd/bin_master.py`, `vhd/compact_images.py`, `vhd/integration.py`, `vhd/master.py`, `vhd/reconstruction/storage.py`
