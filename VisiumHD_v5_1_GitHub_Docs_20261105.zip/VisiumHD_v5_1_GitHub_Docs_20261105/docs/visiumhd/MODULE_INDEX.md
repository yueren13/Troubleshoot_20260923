# Module index

[Documentation home](README.md) · [Complete module reference](MODULE_REFERENCE.md) · [Handbook](PIPELINE_HANDBOOK.md)

All 100 entries from the original module catalog. The groups below retain its category labels. Click a module to read its original description, definitions and observed dependencies.

## Advanced CLI

| Module | Responsibility |
|---|---|
| [scripts/run_pipeline.py](MODULE_REFERENCE.md#scriptsrun_pipelinepy) | Optional synchronous lower-level CLI. Its explicit --action list is narrower than the Project Center and does not expose all dual-method operations. |

## Core/scientific

| Module | Responsibility |
|---|---|
| [vhd/analysis_qc.py](MODULE_REFERENCE.md#vhdanalysis_qcpy) | Non-destructive raw-count cell/gene eligibility for analysis, including species-dependent mitochondrial limits and keyed source signatures. Does not replace cell reconstruction QC. |
| [vhd/bin_master.py](MODULE_REFERENCE.md#vhdbin_masterpy) | Sample/store identity checks and the explicit reusable bin-master checkpoint. Validates tracked sources/observations and refuses unrelated or incomplete destinations. |
| [vhd/cells.py](MODULE_REFERENCE.md#vhdcellspy) | Converts durable Proseg output to prepared cells: read polygons/counts, reconcile features, transform boundaries, compute QC/cell cycle and summarize bin-derived metadata. |
| [vhd/compact_images.py](MODULE_REFERENCE.md#vhdcompact_imagespy) | Selects and constructs compact master images with explicit mappings back to full resolution, and validates their storage contract. |
| [vhd/core.py](MODULE_REFERENCE.md#vhdcorepy) | Shared numerical, identity and cache contracts: JSON serialization, signatures, stage locks, raw integer-CSR checks, QC metrics, coordinate transforms, H5AD-safe values and environment reports. |
| [vhd/count_display.py](MODULE_REFERENCE.md#vhdcount_displaypy) | Count-axis presentation transforms and labels only; does not normalize or modify the scientific values. |
| [vhd/grid_diagnostics.py](MODULE_REFERENCE.md#vhdgrid_diagnosticspy) | Coordinate-only inspection using position tables and barcode order before count/image arrays; writes diagnostic reports only through explicit report operations. |
| [vhd/grid_geometry.py](MODULE_REFERENCE.md#vhdgrid_geometrypy) | Checks affine fits and verified integer-rounding cases without changing the source coordinates. Exposes projective diagnostic evidence for the model-selection layer. |
| [vhd/images.py](MODULE_REFERENCE.md#vhdimagespy) | Image headers, regions, thumbnails, RGB sampling, optional display normalization and lazy/resized image access. Works in explicitly supplied image coordinates rather than redefining bin coordinates. |
| [vhd/integration.py](MODULE_REFERENCE.md#vhdintegrationpy) | Joint-analysis orchestration: select eligible raw-count cells, select common HVGs, prepare scVI inputs, delegate training, build Leiden/UMAP companions, diagnostics and explicit writeback. |
| [vhd/io.py](MODULE_REFERENCE.md#vhdiopy) | Space Ranger resolution and count ingestion; original coordinate assembly; metadata-only access, selected table loading and selected-bin loading. Distinguishes table inspection from reading expression. |
| [vhd/master.py](MODULE_REFERENCE.md#vhdmasterpy) | Coordinates base/legacy master creation/reuse, current annotation checks, H/E-map storage and geometric cell-annotation refresh. Named dual-method append lives in reconstruction/storage.py. |
| [vhd/palette.py](MODULE_REFERENCE.md#vhdpalettepy) | Recorded categorical palette and optional labelled extensions; natural ordering for cluster labels. |
| [vhd/plots.py](MODULE_REFERENCE.md#vhdplotspy) | Shared count histograms, numeric/categorical spatial scatter, technical QC panels, boundary overlays and report-only replotting. |
| [vhd/preflight.py](MODULE_REFERENCE.md#vhdpreflightpy) | Legacy/source-level configuration and SpatialData API checks. Different from the per-worker import probe and the two real-science dual-method smoke tests. |
| [vhd/projective_grid.py](MODULE_REFERENCE.md#vhdprojective_gridpy) | Validates homographies, domain behavior and model-derived quadrilateral corners, keeping the original observed centers authoritative. |
| [vhd/projective_storage.py](MODULE_REFERENCE.md#vhdprojective_storagepy) | Creates/checks full-resolution polygon representations for non-affine bins. Bounded construction does not make the final GeoDataFrame lazy. |
| [vhd/qc.py](MODULE_REFERENCE.md#vhdqcpy) | Retained bin-QC pathway used when the fixed H&E-score route is not enabled. Do not confuse it with he/workflow.classify_stage or the later analysis-QC stage. |
| [vhd/sample_metadata.py](MODULE_REFERENCE.md#vhdsample_metadatapy) | Attaches resolved sample descriptors to AnnData observations and records ownership in uns; also offers an explicit selective synchronization path for existing tables. It does not perform spatial annotation transfer. |
| [vhd/segmentation.py](MODULE_REFERENCE.md#vhdsegmentationpy) | Creates and gates the shared H&E StarDist nucleus prior; builds/checks external Proseg commands and validates durable outputs. Includes legacy multi-sample execution helpers. |
| [vhd/spaceranger_images.py](MODULE_REFERENCE.md#vhdspaceranger_imagespy) | Resolves hires/lowres PNGs and calibration from supported spatial folders within one configured Space Ranger outs, including split-file layout. |
| [vhd/storage.py](MODULE_REFERENCE.md#vhdstoragepy) | Low-level SpatialData construction/linkage helpers: affine bin-label rasters, table-region relationships, optional prior and readback validation. Delegates assembly to the adapter rather than owning the controller. |

## Package initializer

| Module | Responsibility |
|---|---|
| [vhd/__init__.py](MODULE_REFERENCE.md#vhd__init__py) | Visium HD Project Center; existing scientific cache versions are preserved. |
| [vhd/adapters/__init__.py](MODULE_REFERENCE.md#vhdadapters__init__py) | Package namespace initializer; no stage implementation is defined here. |
| [vhd/annotations/__init__.py](MODULE_REFERENCE.md#vhdannotations__init__py) | Explicit annotation geometry, coverage, and metadata transfer. No RNA reaggregation. |
| [vhd/center/__init__.py](MODULE_REFERENCE.md#vhdcenter__init__py) | Persistent, review-first interface over the uploaded Visium HD scientific engine. |
| [vhd/compute/__init__.py](MODULE_REFERENCE.md#vhdcompute__init__py) | Package namespace initializer; no stage implementation is defined here. |
| [vhd/control/__init__.py](MODULE_REFERENCE.md#vhdcontrol__init__py) | Package namespace initializer; no stage implementation is defined here. |
| [vhd/he/__init__.py](MODULE_REFERENCE.md#vhdhe__init__py) | Quantitative fixed-reference H&E; display normalization is kept separate. |
| [vhd/persistence/__init__.py](MODULE_REFERENCE.md#vhdpersistence__init__py) | Explicit master updates with retained recovery data; no mount management. |
| [vhd/reconstruction/__init__.py](MODULE_REFERENCE.md#vhdreconstruction__init__py) | Independent cell reconstruction branches sharing the reviewed H&E prior. |

## Standalone utility

| Module | Responsibility |
|---|---|
| [tools/audit_share_bundle.py](MODULE_REFERENCE.md#toolsaudit_share_bundlepy) | Read-only package hygiene/path-pattern audit. Not a full security, privacy or license certification. |
| [tools/check_project_center_environment.py](MODULE_REFERENCE.md#toolscheck_project_center_environmentpy) | Read-only package/resource/interface inventory, used by notebook 99. Does not install dependencies or launch sample jobs. |
| [tools/demo_annotation_signal_contract.py](MODULE_REFERENCE.md#toolsdemo_annotation_signal_contractpy) | Generates a small synthetic annotation/signal contract demonstration in a new directory. Not a biological sample test. |
| [tools/demo_discovery_first.py](MODULE_REFERENCE.md#toolsdemo_discovery_firstpy) | Synthetic discovery and native-signal-summary example. Leaves generated choices unselected; does not approve real sources. |
| [tools/demo_project_center_reports.py](MODULE_REFERENCE.md#toolsdemo_project_center_reportspy) | Synthetic report-layout demonstration; the displayed demo plots are not products of real segmentation or clustering. |
| [tools/inspect_annotation_geometry.py](MODULE_REFERENCE.md#toolsinspect_annotation_geometrypy) | Standalone original region-inspection entry point; analogous functionality is also packaged in annotations/region_inspection.py for center use. |
| [tools/inspect_bin_grid.py](MODULE_REFERENCE.md#toolsinspect_bin_gridpy) | Command-line coordinate-only diagnostic entry point; delegates to the grid modules. |
| [tools/preview_assets_on_he.py](MODULE_REFERENCE.md#toolspreview_assets_on_hepy) | Visual-First H&E/annotation/raw-signal gallery, called from the controller through runpy. Display changes do not grant scientific approval. |
| [tools/reference_inspector.py](MODULE_REFERENCE.md#toolsreference_inspectorpy) | Retained standalone copy of the original region inspector. It is not another mandatory annotation processing stage. |
| [tools/review_annotation_candidates.py](MODULE_REFERENCE.md#toolsreview_annotation_candidatespy) | Standalone candidate-gallery helper retained for direct use and tests; the center uses its packaged counterpart in annotations/region_review.py. |
| [tools/strip_source_notebooks.py](MODULE_REFERENCE.md#toolsstrip_source_notebookspy) | Explicit source-only notebook/code bundle utility. Does not execute notebook code; never point packaging tools at active working products casually. |
| [tools/validate_repository.py](MODULE_REFERENCE.md#toolsvalidate_repositorypy) | Static Python/notebook/CSV validation. Repository mode rejects saved notebook execution state; working mode permits it without clearing or executing it. |

## Tests/tool regression

| Module | Responsibility |
|---|---|
| [tools/test_review_annotation_candidates.py](MODULE_REFERENCE.md#toolstest_review_annotation_candidatespy) | Regression tests for the standalone review helper, despite residing under tools/. Not an operator-facing processing script. |

## adapters

| Module | Responsibility |
|---|---|
| [vhd/adapters/anndata_input.py](MODULE_REFERENCE.md#vhdadaptersanndata_inputpy) | Selective AnnData metadata/count-matrix access for H5AD, AnnData-Zarr and named SpatialData tables. Avoids loading unrelated matrices/layers. |
| [vhd/adapters/assemble.py](MODULE_REFERENCE.md#vhdadaptersassemblepy) | Assembles actual bin-only, cell-only or bin-plus-cell SpatialData with truthful geometry and metadata linkage; validates the stored product. |
| [vhd/adapters/bins.py](MODULE_REFERENCE.md#vhdadaptersbinspy) | Imports an existing bin table from the declared count source, uses original coordinate columns, and resolves/reuses supplied QC rather than guessing a new registration. |
| [vhd/adapters/cells.py](MODULE_REFERENCE.md#vhdadapterscellspy) | Imports standalone cells from declared raw counts/coordinates, using actual supplied boundaries where available. Does not fabricate biological cell outlines. |

## annotations

| Module | Responsibility |
|---|---|
| [vhd/annotations/alignment.py](MODULE_REFERENCE.md#vhdannotationsalignmentpy) | Explicit source-to-H&E alignment from reference pixels, transforms, dimensions or landmarks; dimension matching requires same-extent confirmation. |
| [vhd/annotations/area_sampling.py](MODULE_REFERENCE.md#vhdannotationsarea_samplingpy) | Exact overlap-weighted sampling of a piecewise-constant source-pixel field over affine bin footprints. |
| [vhd/annotations/discovery.py](MODULE_REFERENCE.md#vhdannotationsdiscoverypy) | Discovers categories, merges current choices, compiles selected outputs and QC rules, and supports original source-preview approvals. Managed center saves coordinate the current normal route. |
| [vhd/annotations/geometry.py](MODULE_REFERENCE.md#vhdannotationsgeometrypy) | ImageScope XML reading, per-parent positive-minus-negative composition, transformed polygon geometry and independent bin-center membership with coverage semantics. |
| [vhd/annotations/preview_categories.py](MODULE_REFERENCE.md#vhdannotationspreview_categoriespy) | Per-category H&E views from one physical source without loading expression data. |
| [vhd/annotations/projective_sampling.py](MODULE_REFERENCE.md#vhdannotationsprojective_samplingpy) | Equivalent source-pixel-overlap summaries using each projective bin's quadrilateral rather than a shared affine basis. |
| [vhd/annotations/raster.py](MODULE_REFERENCE.md#vhdannotationsrasterpy) | Explicit-axis/channel lazy raster readers and selected-plane value checks, with small PNG fallback. Scientific binary validation is separate from display. |
| [vhd/annotations/region_inspection.py](MODULE_REFERENCE.md#vhdannotationsregion_inspectionpy) | Formal in-package read-only invalid-region inventory and mathematical repair-candidate statistics; does not accept candidates. |
| [vhd/annotations/region_review.py](MODULE_REFERENCE.md#vhdannotationsregion_reviewpy) | In-package visual comparisons and composition of unapproved repair candidates in XML coordinates, not an H&E registration check. |
| [vhd/annotations/review.py](MODULE_REFERENCE.md#vhdannotationsreviewpy) | Legacy file-level asset approval API. Retained for old role-based manifests; not an extra form required after the Project Center visual-first save. |
| [vhd/annotations/reviewed_geometry.py](MODULE_REFERENCE.md#vhdannotationsreviewed_geometrypy) | Source-bound explicit adoption and activation of derived polygon-only geometry, preserving holes, negative roles and all polygon components. |
| [vhd/annotations/transfer.py](MODULE_REFERENCE.md#vhdannotationstransferpy) | Coverage-aware cell summaries from bin assignments and annotation-based segmentation eligibility. Keeps independent category truth values and valid-bin coverage; geometric assignment is not molecule reassignment. |
| [vhd/annotations/visual_approval.py](MODULE_REFERENCE.md#vhdannotationsvisual_approvalpy) | Bridges reviewed Visual-First galleries to choice signatures and real transfer prerequisites. Separates visual acceptance from an actual stored-source receipt. |
| [vhd/annotations/workflow.py](MODULE_REFERENCE.md#vhdannotationsworkflowpy) | Asset CSV contract, source/transform signatures, native signal interpretation, polygon loaders, real spatial-source import and per-bin metadata transfer. |

## center

| Module | Responsibility |
|---|---|
| [vhd/center/asset_report_navigation.py](MODULE_REFERENCE.md#vhdcenterasset_report_navigationpy) | Read-only gallery/repair-report inventory, identity checks, image selectors and display. Viewing a report does not approve its geometry or scientific use. |
| [vhd/center/controller.py](MODULE_REFERENCE.md#vhdcentercontrollerpy) | Persistent coordination API: project creation/opening, managed hashes, route planning, review gates, explicit saves, processing, resource caps, reports, methods and analysis groups. |
| [vhd/center/importers.py](MODULE_REFERENCE.md#vhdcenterimporterspy) | Compact sample/asset-sheet parsing, optional descriptor-CSV join and small managed configuration copies. Extra sample-sheet columns become resolved sample metadata; this is not the strict manifest reader. |
| [vhd/center/reports.py](MODULE_REFERENCE.md#vhdcenterreportspy) | Registers known scientific reports and renders fixed project/sample/group HTML summaries with bounded image/table content. Does not generate missing biological results. |
| [vhd/center/resources.py](MODULE_REFERENCE.md#vhdcenterresourcespy) | Available-resource observation including visible cgroups, optional allocation caps and conservative runtime settings. Does not reserve GPUs or learn a validated memory model. |
| [vhd/center/single_sample.py](MODULE_REFERENCE.md#vhdcentersingle_samplepy) | Explicit independent CPU Scanpy PCA/neighbors/UMAP/Leiden workflow on one selected cell table; produces method-partitioned companion metadata/embedding results. |
| [vhd/center/stages.py](MODULE_REFERENCE.md#vhdcenterstagespy) | Human-readable stage labels, selected endpoint routes, expected output locations and bounded inventory. Presence is not proof of scientific correctness. |
| [vhd/center/state.py](MODULE_REFERENCE.md#vhdcenterstatepy) | Small JSON controller ledger with revision history, fingerprints and an advisory POSIX lock. Contains no RNA arrays and does not lock unrelated external readers. |
| [vhd/center/ui.py](MODULE_REFERENCE.md#vhdcenteruipy) | Connected Jupyter widget interface and setup form. Buttons call the controller; its HTML report display is distinct from a disconnected exported HTML file. |

## compute

| Module | Responsibility |
|---|---|
| [vhd/compute/clustering.py](MODULE_REFERENCE.md#vhdcomputeclusteringpy) | Configured CPU or RAPIDS graph/UMAP/Leiden backend, with optional Dask multi-GPU Leiden path. Different from the independent CPU analysis module. |
| [vhd/compute/integration_worker.py](MODULE_REFERENCE.md#vhdcomputeintegration_workerpy) | Separate worker for prepare/cluster/diagnostics/writeback integration phases using the selected interpreter. |
| [vhd/compute/launch.py](MODULE_REFERENCE.md#vhdcomputelaunchpy) | Chooses action-specific interpreters, creates worker environments, computes concurrency budgets, performs probes and submits/monitors sample or integration subprocesses. |
| [vhd/compute/probe.py](MODULE_REFERENCE.md#vhdcomputeprobepy) | Legacy/lightweight software/host/NVIDIA inventory without importing deep-learning frameworks into the notebook process. |
| [vhd/compute/runtime_checks.py](MODULE_REFERENCE.md#vhdcomputeruntime_checkspy) | Preserves worker executable invocation, identifies required imports for each action and probes those imports in the selected environment. |
| [vhd/compute/scvi_state.py](MODULE_REFERENCE.md#vhdcomputescvi_statepy) | Dependency-light classification of absent, partial, model-ready and complete scVI artifacts. Prevents unsafe model reuse or overwrite. |
| [vhd/compute/scvi_worker.py](MODULE_REFERENCE.md#vhdcomputescvi_workerpy) | Script/DDP training and separate single-writer latent inference, using declared raw counts and sample batch labels; records model/history/inference receipts. |
| [vhd/compute/startup_support.py](MODULE_REFERENCE.md#vhdcomputestartup_supportpy) | Persistent startup/cache controls, bounded isolated probes, timeout handling and Proseg executable inspection. Runtime controls are separated from scientific settings. |
| [vhd/compute/worker.py](MODULE_REFERENCE.md#vhdcomputeworkerpy) | Fresh sample-worker module invoked with python -m; reads a resolved project snapshot and dispatches one action. |

## control

| Module | Responsibility |
|---|---|
| [vhd/control/manifest.py](MODULE_REFERENCE.md#vhdcontrolmanifestpy) | Strict full-manifest reader, global/per-sample configuration merge, storage-policy checks, resolved sample paths, action plans and worker snapshots. The compact new-project sheet is parsed elsewhere. |
| [vhd/control/notebook_runtime.py](MODULE_REFERENCE.md#vhdcontrolnotebook_runtimepy) | Explicit preview/execute, sample-selection and action-description helpers retained for direct notebook/advanced workflows. |
| [vhd/control/paths_v3.py](MODULE_REFERENCE.md#vhdcontrolpaths_v3py) | Retained path helper despite its historical filename: path expansion, required roots/sentinels, overlap checks, layout and optional mounted-source staging. |
| [vhd/control/prechecks.py](MODULE_REFERENCE.md#vhdcontrolprecheckspy) | Checks action-specific inputs and small receipts before launching a batch; not a complete scientific execution test. |
| [vhd/control/runner.py](MODULE_REFERENCE.md#vhdcontrolrunnerpy) | Prepares localized sample contexts, dispatches scientific actions, records status, separates report categories and handles sample/group publication. |
| [vhd/control/sample_metadata.py](MODULE_REFERENCE.md#vhdcontrolsample_metadatapy) | Reads and joins descriptor CSVs using exact sample identities, validates scalar values/reserved names and optional types/renames, resolves legacy metadata JSON and builds provenance. |
| [vhd/control/storage.py](MODULE_REFERENCE.md#vhdcontrolstoragepy) | Explicit local/remote staging, free-space checks, inventories and immutable publication under declared policy. No input mutation or mount operations. |

## he

| Module | Responsibility |
|---|---|
| [vhd/he/display_legacy.py](MODULE_REFERENCE.md#vhdhedisplay_legacypy) | Retained display-oriented Macenko normalizer with repaired return contracts. Eager display preprocessing, not the fixed-reference quantitative tissue-score definition. |
| [vhd/he/fixed.py](MODULE_REFERENCE.md#vhdhefixedpy) | Quantitative fixed-reference H/E extraction, fixed scaling, combination and center sampling. Keep separate from slide-wise display normalization. |
| [vhd/he/qc_review.py](MODULE_REFERENCE.md#vhdheqc_reviewpy) | Streaming score/count histograms, sampled scatter and all-valid-bin density plots from existing measurement metadata, with threshold inspection helpers. |
| [vhd/he/source.py](MODULE_REFERENCE.md#vhdhesourcepy) | Chooses configured or resolved H&E score inputs and reports paths/calibration without asserting biological registration. |
| [vhd/he/workflow.py](MODULE_REFERENCE.md#vhdheworkflowpy) | Separate fixed H&E measurement and explicit bin classification stages with sidecars/receipts and image overlays. Threshold changes do not redefine the raw expression matrix. |

## persistence

| Module | Responsibility |
|---|---|
| [vhd/persistence/spatial.py](MODULE_REFERENCE.md#vhdpersistencespatialpy) | Patched selective SpatialData element and table-metadata writes. Refreshes only affected table roots plus the container root; delegates recoverable replacement to transaction.py. |
| [vhd/persistence/transaction.py](MODULE_REFERENCE.md#vhdpersistencetransactionpy) | Verifies copies and journals component replacements with explicit recovery/retirement. Recoverable multi-key changes are not a globally atomic filesystem transaction. |

## reconstruction

| Module | Responsibility |
|---|---|
| [vhd/reconstruction/bin2cell_adapter.py](MODULE_REFERENCE.md#vhdreconstructionbin2cell_adapterpy) | Calls actual Bin2cell expansion/aggregation on prepared bins/prior, validates raw-count/coordinate contracts, computes technical QC and optionally creates separate density-derived objects. |
| [vhd/reconstruction/config.py](MODULE_REFERENCE.md#vhdreconstructionconfigpy) | Validates Proseg/Bin2cell selections, analysis table, Bin2cell parameters/bin scope and method-specific paths; rewrites only generated-cell routes. |
| [vhd/reconstruction/geometry.py](MODULE_REFERENCE.md#vhdreconstructiongeometrypy) | Samples the shared prior at bin positions, builds sparse aggregation assignment matrices, traces assigned-grid boundaries and transforms their vertices with holes/multipart support. |
| [vhd/reconstruction/reports.py](MODULE_REFERENCE.md#vhdreconstructionreportspy) | Creates the method comparison HTML/CSV/JSON from available method reports. These are descriptive alternative reconstructions, not ground-truth segmentation scores. |
| [vhd/reconstruction/storage.py](MODULE_REFERENCE.md#vhdreconstructionstoragepy) | Serially appends independent method tables and boundaries with cell-ID qualification, readback checks and receipts. Refreshes cell annotations using each method's appropriate assignments. |

