# Repository-format conversion notes

[Documentation home](README.md)

## Baseline and scope

The original November 4 handbook documents **v5.1rc1 plus scoped-metadata-refresh-20261104-v1**. This November 5 edition changes its reading format and navigation, not scientific behavior. No study data, approval state, runtime settings, UV project, installed pipeline or remote repository was modified.

## What changed

- The main handbook and complete module reference use their existing Markdown source, retaining all 18 numbered chapters and all 100 module entries. Existing explanatory text, tables and code snippets were not rewritten.
- 270 HTML-source-browser links were changed to relative links to versioned native source files. Three empty package-initializer links point to the empty file without an invalid line anchor; their original reference labels remain visible.
- Added a documentation landing README, an 18-chapter contents list, a grouped module index, a source index, upload instructions and a root-README snippet. Module-path headings use code formatting to preserve underscores when rendered.
- The 104 source-browser files (100 Python files and four configuration/example references) are copied into `source_snapshot/`; their bytes match the original recorded hashes. This is reference material, not a runnable installation.
- Metadata-example CSV/JSON inputs are byte-for-byte unchanged. The original source audit, source inventory and historical validation record are retained.
- The PDF is a conversion of the existing 23-page Word handbook, with a small cover/navigation wording update for this repository edition. It is a reading copy, not an interactive viewer or a complete printout of the 100-file module catalog.
- The custom HTML search/filter controls and styling are not carried into Markdown. Use the module index, heading navigation or browser Find. All documentation remains usable without those controls.

## Validation performed for this conversion

See `conversion_checks.json` for the exact totals. Checks cover local relative-link targets, Markdown heading anchors, source line ranges, source hashes, unchanged example inputs, retained chapters/module entries and the PDF page count. The PDF was rendered for visual review. These are documentation checks, not new scientific pipeline tests.

No internal GitHub repository or enterprise server was accessed; actual rendering on your organization's instance remains to be confirmed. No online document-conversion service or external HTML preview service was used.
