# Visium HD v5.1 documentation

**Repository-readable edition · November 5, 2026**  
**Scientific baseline:** `0.5.1rc1` plus `scoped-metadata-refresh-20261104-v1`.

Start with the **[operator and maintainer handbook](PIPELINE_HANDBOOK.md)**.

| Read | Use it for |
|---|---|
| [Pipeline handbook](PIPELINE_HANDBOOK.md) | The complete 18-chapter explanation of operation, metadata, stages, storage and maintenance. |
| [Module index](MODULE_INDEX.md) | Find a Python module by its responsibility. |
| [Complete module reference](MODULE_REFERENCE.md) | Original descriptions, definitions, signatures and observed dependencies for all 100 Python files. |
| [Source index](SOURCE_INDEX.md) | Exact, frozen source files and their recorded hashes, replacing the HTML source browser. |
| [Metadata examples](metadata_examples/README.md) | Inline descriptors, a separate metadata CSV and the typed full-configuration example. |
| [Handbook PDF](VisiumHD_v5_1_Handbook.pdf) | The 23-page offline/print reading edition. |
| [Original source audit](SOURCE_AUDIT.md) | Evidence supporting the original handbook. |
| [Historical handbook validation](ORIGINAL_VALIDATION.md) | Original checks; not new scientific tests. |
| [Conversion notes](CONVERSION_NOTES.md) | What changed in this documentation format, and what was checked. |

## Read inside the repository

Open the `.md` links above in the repository's normal rendered/Preview view, not Raw or Code. There is no HTML application to host, no JavaScript search/filter control and no GitHub Pages requirement. Navigation uses ordinary headings, tables, code blocks and relative links.

GitHub documents Markdown rendering, heading outlines and relative links in its [README guide](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes). It also [supports PDF previews](https://docs.github.com/en/repositories/working-with-files/using-files/working-with-non-code-files#rendering-pdf-documents); your organization's server/version/policy can affect availability, and links inside its PDF viewer may not be active. Markdown is the primary reading format here.

## Scope

This edition preserves the original handbook's terminology, module descriptions, examples and scientific caveats. Source citations now open native code files with line-range links. The snapshot is documentation reference material, not a replacement code release.

No pipeline code, UV environment, study configuration, approval state, biological result or remote repository has been changed. No scientific run is needed to use these documents. Keep the original interactive HTML edition for approved local/offline use if useful; it is not required for these Markdown pages.
