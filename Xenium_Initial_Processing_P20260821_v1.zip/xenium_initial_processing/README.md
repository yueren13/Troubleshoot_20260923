# Xenium initial processing: 10x outputs → SpatialData → cell QC

This bundle adapts your original Xenium preview, shape-measurement, and quality-control notebooks to the `P-20260821-0003 / Batch1_20261010` directory structure. It adds the missing 10x import stage and uses **`xenium_vanilla_cell`** for the original 10x cell-segmented AnnData table throughout.

The expected batch contains **12 technical regions, 6 slides, and 3 runs**. Each technical region is processed independently. H&E image paths are matched at the slide level and recorded for later registration. No unaligned H&E image is placed into a Xenium coordinate system.

## Quick start

1. Extract this entire folder together. Keep `xenium_workflow/` beside the notebooks.
2. Open the notebooks in JupyterLab using **your existing uv project kernel**. The code targets the supplied lockfile; it does not install or upgrade packages.
3. Open `Step0A_Discover_and_Validate_Inputs.ipynb`. Edit **`BATCH_ROOT`** and **`OUTPUT_ROOT`** in its configuration cell. `BATCH_ROOT` should end in `Batch1_20261010`, and `OUTPUT_ROOT` should be a separate writable directory outside it.
4. Run Step0A and inspect the manifest, the six slide/H&E associations, and the input validation report. Add biological metadata if available.
5. Run the remaining notebooks in the order below. They all load the same `workflow_config.json` created by Step0A.

| Notebook | What it does | Main outputs |
|---|---|---|
| `Step0A_Discover_and_Validate_Inputs.ipynb` | Inspect kernel versions, discover regions, create/reuse the manifest, check required files | Shared configuration; `sample_manifest.csv`; preflight and runtime reports |
| `Step0B_Import_Xenium_to_SpatialData.ipynb` | Import each 10x bundle, name the original table, validate IDs/links, save and reopen | One completed SpatialData Zarr store per region |
| `Step1_DatasetPreview.ipynb` | Preview morphology, segmentation masks, cell centroids, and optional ROIs | Region overview and ROI PNGs |
| `Step2_DataProcess_measureshape.ipynb` | Measure polygon geometry and join it to the cell table by cell ID | `polygon_*` observation fields; morphology CSVs; saved table update |
| `Step3_DatasetProcess_qualitycontrol.ipynb` | Calculate gene/control/shape diagnostics, apply editable QC rules, save flags and reports | Updated original table; QC reports/figures; all-cell and passing-cell H5AD exports |

For an initial trial on one region, run discovery, set `config.selected_sample_ids` to one displayed ID in the optional Step0A selection cell, and save the configuration. After inspecting its results, clear that list and run the batch. Existing completed imports are checked and reused. The default selection is all included regions.

**Scope ends at cell QC.** Raw counts are not normalized, log-transformed, clustered, integrated, or annotated. Downstream analyses can start from the passing-cell H5ADs or from `xenium_vanilla_cell` with a QC selection.

## Input discovery and manifest

Discovery is restricted to `BATCH_ROOT/Xenium_run_*/output-*` directories matching:

```text
output-<instrument>__<slide>__Region_<number>__<YYYYMMDD>__<HHMMSS>
```

The project summary PDF is ignored. Neither `post_Xenium_HE_images/ome_tiff` nor its sibling `tiff` directory becomes a dataset. The H&E lookup uses the `ome_tiff` directory and an exact slide-ID match.

Examples:

| Run | Slide ID | Regions | Referenced H&E |
|---|---|---|---|
| `Xenium_run_01` | `0117167` | 1, 2 | `BMS_0117167.ome.tif` |
| `Xenium_run_01` | `0117194` | 1, 2 | `BMS_0117194.ome.tif` |
| `Xenium_run_02` | `0117690` | 1, 2 | `BMS_0117690.ome.tif` |
| `Xenium_run_02` | `0117734` | 1, 2 | `BMS_0117734.ome.tif` |
| `Xenium_run_03` | `0117170` | 1, 2 | `BMS_0117170.ome.tif` |
| `Xenium_run_03` | `0117181` | 1, 2 | `BMS_0117181.ome.tif` |

All identifiers are read as strings. The leading zero in `0117690` is preserved. Technical sample IDs include the run, instrument, slide, region, date, and time; for example:

```text
Xenium_run_02__XETG00318__0117690__Region_1__20260928__230929
```

That longer identifier makes filenames unambiguous. `sample_name` provides a shorter editable label. The directory names identify technical regions; they do not establish biological specimen identity, donor identity, or treatment.

Useful manifest fields:

| Field | Meaning / editing policy |
|---|---|
| `sample_id` | Stable technical region identifier; do not edit |
| `sample_name` | Editable display label |
| `include` | `true` or `false`; governs notebook selection |
| `project_id`, `batch_id`, `run_id` | Project and acquisition organization |
| `instrument_id`, `slide_id`, `region_id`, `region_name`, `run_date`, `run_time` | Parsed acquisition identity; keep unchanged |
| `source_dir`, `zarr_path` | Raw input and generated output locations |
| `biological_sample_id`, `donor_id`, `tissue`, `condition`, `notes` | Optional user-supplied biology; initially blank |
| `he_image_path` | Shared source H&E for the slide |
| `he_alignment_path` | Reserved for a future **region-specific** alignment |
| `he_alignment_status` | Records availability; setting a path does not import or apply a transform |

The example CSV in `examples/` reproduces your twelve supplied directory names using clear placeholder paths. **Do not use it instead of actual discovery.** Step0A generates the working manifest from your mounted data.

Re-running discovery preserves editable selections and annotations. A missing previously recorded region stops manifest replacement so a temporarily unavailable mount does not silently erase metadata. Step2/Step3 refresh editable labels from the manifest without reimporting raw counts.

## What gets imported

The official `spatialdata_io.xenium` reader is used with explicit flags. This avoids relying on defaults that differ across versions. The provided lockfile pins `spatialdata-io==0.6.0`; the implementation was checked against that version's source, not just the moving stable documentation.

By default, the output store contains:

| Element type | Typical key | Notes |
|---|---|---|
| Tables | `xenium_vanilla_cell` | Original 10x cell-by-gene counts; all original cells retained |
| Images | `morphology_focus` | Xenium morphology channels; legacy MIP also included when available |
| Labels | `cell_labels`, `nucleus_labels` | Native segmentation raster labels |
| Shapes | `cell_boundaries`, `nucleus_boundaries` | Native 10x boundary polygons |
| Points | `transcripts` | Transcript locations and their supplied attributes |

The actual inventory is displayed in Step0B. No additional transcript quality or cell-assignment filter is applied to the point cloud. The cell-feature matrix already follows 10x's matrix construction rules. `gex_only=True` selects gene-expression features for the working AnnData matrix; negative control/codeword summaries are retained in the cell metadata. For outputs with protein features, this is intentionally the **gene-expression** table, not a protein-analysis workflow.

The standard required bundle includes `experiment.xenium`, `cells.parquet`, `cell_feature_matrix.h5`, and `cells.zarr.zip`, plus the requested boundary, transcript, and morphology files. The pinned reader uses `cells.zarr.zip` metadata for newer outputs even if label images are disabled. The preflight reports missing files before a large import starts. It is not a general converter for CSV-only or partially archived bundles.

### Memory and disk

The workflow processes one region at a time and does not load all twelve region objects together. Images and points use the reader's lazy representations. This does **not** make the initial conversion memory-free: the pinned reader scans label IDs internally, may decode large TIFF planes, and writing the self-contained store materializes selected arrays. Keep adequate RAM and disk space for a full region and the generated store.

The settings in Step0A allow transcript points, labels, boundaries, and morphology to be disabled independently. To retain Step2 shape measurements, keep cell boundaries enabled. If both labels and boundaries are disabled, the importer retains cell circles so the table still has a valid spatial annotation target. Step1 explains missing image/label layers instead of inventing a preview.

Changing import options after a completed import requires a new output directory. This prevents a lightweight first import from being silently mistaken for a complete one.

## Table identity and coordinates

Within a region:

```python
import spatialdata as sd
sdata = sd.read_zarr("/your/output/zarr/<sample_id>.zarr")
adata = sdata.tables["xenium_vanilla_cell"]
```

The workflow notebooks use `read_sample()` instead of the generic reader because it also checks the import completion marker and detects pending table transactions.

The original Xenium `cell_id` becomes the table's observation name. It is also retained in `.obs['cell_id']`. Native integer mask instances remain in `.obs['cell_labels']` when labels are imported. SpatialData's `.obs['region']` continues to identify the annotated spatial element; region 1/2 is recorded separately in `region_id` and `region_name`.

| Location | Coordinate meaning |
|---|---|
| `.obsm['spatial']` | Native Xenium cell-centroid x/y, µm |
| `.obsm['spatial_um']` | Explicit alias of those centroids, µm |
| `.obsm['spatial_global']` | Centroids divided by the experiment's pixel size, morphology pixels |
| Native boundary geometries | µm; their reader transform maps to the `global` pixel coordinate system |
| Image/label `global` | Morphology pixels, local to one region |
| H&E reference | External file path; no assumed transformation |

The import records pixel size and these definitions in `.uns['xenium_import']`. ROI preview bounds are entered in µm, then converted explicitly to global pixels. Separate regions remain separate coordinate systems even if their numerical coordinates overlap.

Standalone H5AD export names are `sample_id::cell_id` so cell IDs do not collide across regions. The source ID remains in the `cell_id` column. Source SpatialData annotation metadata is retained as provenance rather than as an active link to absent spatial elements.

## Shape measurements: what changed from your draft

Your original Step2 computes polygon measurements and then rasterizes all polygons into a morphology-image-sized array to calculate elongation and eccentricity. That allocation can be large, and an identity raster transform is inappropriate if polygon coordinates and image pixels use different units.

The new Step2 uses the polygons in their native micrometre coordinates and joins by cell ID. It calculates geometry metrics without building a whole-region raster. Continuous polygon moments provide equivalent-ellipse axes, elongation, and eccentricity. Holes and multipolygon components are included. These are well-defined polygon metrics, but they are not numerically identical to pixelized `skimage.regionprops` measurements.

Main new fields include:

| Field | Meaning |
|---|---|
| `polygon_area_um2`, `polygon_perimeter_um` | Boundary-polygon area and perimeter |
| `polygon_convex_area_um2`, `polygon_convex_perimeter_um` | Convex-hull measurements |
| `polygon_solidity` | Area / convex-hull area |
| `polygon_convexity` | Convex-hull perimeter / polygon perimeter |
| `polygon_perimeter_convex_ratio` | Reciprocal of convexity; preserves the old draft's ratio convention |
| `polygon_circularity` | `4π × area / perimeter²` |
| `polygon_compactness` | Reciprocal of circularity |
| `polygon_bbox_occupancy` | Polygon area / axis-aligned bounding-box area |
| `polygon_elongation` | `1 − minor_axis / major_axis`, from continuous moments |
| `polygon_eccentricity` | `sqrt(1 − (minor_axis / major_axis)²)`, from continuous moments |
| `polygon_to_vendor_cell_area_ratio` | Polygon area / native 10x cell area |
| `polygon_present`, `polygon_valid_geometry`, `polygon_geometry_status`, `polygon_moments_valid` | Geometry availability and validity diagnostics |

The original `cell_area` and `nucleus_area` remain unchanged. 10x describes the boundary polygons as simplified representations intended for visualization and recommends the masks for downstream segmentation or morphology analysis. Accordingly, the `polygon_*` fields are diagnostic proxies and are not used as automatic cell-exclusion criteria. The prefix prevents them from being confused with native mask-derived area measurements.

Missing cell-to-polygon IDs stop the standard notebook for investigation. Invalid geometries retain their rows with diagnostic flags and missing values; they are not silently repaired. The helper supports an explicit non-strict missing-shape mode if a reviewed dataset requires it.

The computed metrics are saved directly back into SpatialData before Step3. This also fixes the old draft's gap between producing a morphology CSV and later plotting those fields without merging them into the cell table.

## QC: count semantics and presets

The old Step3 calculated control fractions using the native `total_counts`, then called Scanpy QC metrics, which can replace `total_counts` with the expression-matrix row sum. Those totals have different definitions for a gene-only matrix.

The new code keeps them separate:

| Field | Definition |
|---|---|
| `transcript_counts` | Original 10x gene-transcript count from cell metadata |
| `total_counts` | Original 10x total count, including the specified control/codeword categories |
| `xenium_total_counts` | Explicit preserved alias used as the control-fraction denominator |
| `total_counts_gene_expression` | Row sum of the raw gene-expression matrix |
| `n_genes_by_counts` | Number of expressed gene features |
| `log1p_total_counts_gene_expression`, `log1p_n_genes_by_counts` | Observation metrics for plotting; `X` is unchanged |
| `pct_counts_in_top_<N>_genes` | Top-N gene-count percentages, computed only when the panel has at least N genes |
| `gene_matrix_matches_transcript_counts` | Consistency diagnostic between matrix gene sum and vendor gene-transcript total |

Top-N metrics use bounded row blocks; the entire matrix is not densified. Zero-count cells and small panels are handled explicitly. No mitochondrial-percentage filter is imposed on a targeted panel.

### Default and historical criteria

The **`conservative` default enables only `transcript_counts >= 10`**. This is a transparent first-pass setting rather than a claim that one cutoff is optimal for all tissues. Your original fraction thresholds are available as **`historical`**:

| Setting | Conservative | Historical |
|---|---:|---:|
| Minimum transcripts | 10 | 10 |
| Minimum gene fraction of total | Off | 0.70 |
| Maximum negative-probe fraction | Off | 0.05 |
| Maximum negative-codeword fraction | Off | 0.02 |
| Maximum genomic-control fraction | Off | 0.005 |
| Maximum unassigned-codeword fraction | Off | 0.10 |
| Maximum deprecated-codeword counts | Off | 0 |

Choose the preset in Step3 and use global or per-region overrides. All threshold values and rule evaluation counts are saved. This bundle contains no measurements from your actual batch, so neither preset has been tuned to it.

Missing optional control measurements are **not assumed to be zero**. The corresponding enabled criterion is marked unevaluated and a warning is emitted. Inspect:

- `qc_pass`: all evaluated enabled rules passed.
- `qc_complete`: all enabled rules could be evaluated for that cell.
- `qc_reason`: failed-rule names.
- `qc_not_evaluated`: enabled rules with missing measurements.
- `qc_fail_<rule>` and `qc_evaluated_<rule>`: per-rule audit fields.
- `qc_status`: `high_quality` / `low_quality` labels retained for compatibility with your draft; they describe the configured criteria, not a universal biological quality judgment.

The passing-cell export uses `qc_pass`. If complete measurement coverage is required, review missing fields and either resolve them or deliberately export `qc_pass & qc_complete`. Missing optional controls do not silently become measured passing values.

`unassigned_codeword_counts` refers to the decoding codebook category. It does **not** mean valid transcripts that fell outside every cell. That separate assignment question can be examined later using the transcript table.

### Segmentation diagnostics

The workflow fits gene transcripts against native cell area within each region and stores robust residuals. Area outliers and unusually dense cells receive `is_big`, `is_dense`, and `seg_qc` annotations. Their purpose is to direct inspection. They do not enter the pass/fail gate. The code uses a consistent median-based robust scale rather than the old draft's mean absolute deviation combined with a median center.

Inspect cell-type/tissue context before treating large, elongated, multinucleated, or dense cells as segmentation failures. The saved spatial QC map makes it possible to see whether failures cluster in particular locations.

## Output organization

Everything below is written under your chosen `OUTPUT_ROOT`:

| Directory | Contents |
|---|---|
| `metadata/` | Working manifest; configuration snapshot; kernel versions; preflight; import/shape status; QC threshold plan |
| `zarr/` | One independent SpatialData store per technical region; sibling table backups and lock/transaction metadata when needed |
| `tables/<sample_id>/` | Polygon metrics, criterion audit, compressed cell metadata with QC |
| `tables/batch_qc_summary.csv` | Region/run/slide retention and metric summaries |
| `h5ad/` | `*_all_cells_qc.h5ad` and `*_qc_pass.h5ad`; optional same-panel combined export |
| `figures/<sample_id>/` | Morphology/mask overview, centroids, optional ROI, QC diagnostics, control fractions, spatial QC |
| `figures/batch_qc_retention.png` | Batch retention comparison |
| `logs/` | Timestamped notebook-stage progress and exceptions |

The original SpatialData table retains all input cells. H5ADs retain raw gene counts and use sample-prefixed cell IDs. The combined H5AD option is off by default, checks feature names and IDs, and explicitly preserves region-local coordinates rather than implying spatial registration. Combining panels with unmatched measured genes is not automatic.

## Reruns, persistence, and recovery

Full imports use a new sibling staging directory. The table and links are checked after writing, the source fingerprint is rechecked, and a completion marker is recorded before promoting the directory. Existing destinations are not overwritten. Inputs are never modified.

Shape/QC updates write only the cell table. They stage and validate a replacement, retain the previous table in a sibling backup directory, and refresh consolidated metadata after the swap. A checksum of the raw expression matrix and cell/feature identities rejects accidental normalization or subsetting of the original table. Advisory locks serialize cooperative reads/writes. Backup tables are retained for recovery; images and transcript/label data are not duplicated for each QC update.

These operations require **a local or mounted POSIX filesystem with reliable locks and same-filesystem directory renames**. They are not an object-store transaction implementation. Process locally first if the eventual destination is S3. Generic independent readers do not participate in the workflow locks; avoid other applications reading/writing the same store during its update.

If a process is killed during a table swap, `read_sample()` reports a pending transaction instead of silently opening an ambiguous store. After confirming no writer is active:

```python
from xenium_workflow.io import recover_table_update, read_sample
recover_table_update("/your/output/zarr/<sample_id>.zarr")
sdata = read_sample("/your/output/zarr/<sample_id>.zarr")
```

Recovery restores the previous table, so rerun the interrupted shape/QC stage. A normal completed backup is available separately; no automatic deletion policy is applied. Incomplete initial-import staging directories are kept for diagnosis and are not reused as completed outputs.

Step3 reruns deliberately replace derived H5AD/CSV/PNG outputs when `OVERWRITE_DERIVED_EXPORTS=True`. Table backups still preserve the previous annotation state. Batch summaries retain previously completed regions; inspect each row's recorded QC settings if only a subset was rerun with changed thresholds.

## Environment and verification

The supplied `pyproject.toml` and `uv.lock` are preserved byte-for-byte in `environment_reference/`. They are references, not a second environment you must create. No GPU package or new scientific package is required by this workflow beyond the user's pinned environment. The notebooks print the active kernel path to help catch an accidentally selected base kernel.

Core target versions include Python >=3.13, SpatialData 0.7.2, spatialdata-io 0.6.0, spatialdata-plot 0.3.3, AnnData 0.12.11, Scanpy 1.12.1, pandas 2.3.3, Shapely 2.1.2, Dask 2026.1.1, and Zarr 3.1.6.

See **`VALIDATION.md`** for the completed validation record. Verification uses small synthetic 10x-format inputs and actual pinned reader/storage libraries, not your experimental data. The run-report PDF, real region outputs, real masks/images, and H&E registration files were not supplied, so full-batch runtime, memory demand, data-specific QC retention, and actual image alignment cannot be established here.

To run the included smoke tests from this folder in your existing uv environment:

```bash
python -m pytest tests -q
```

If this folder is inside your uv project, `uv run python -m pytest tests -q` uses that project's environment. The tests create tiny temporary synthetic datasets and do not touch your raw batch or configured outputs.

## Included implementation modules

| Module | Responsibility |
|---|---|
| `config.py` | Shared configuration; actual kernel/package version report |
| `manifest.py` | Directory-name parsing; slide/H&E matching; CSV identity handling; preflight |
| `io.py` | Official-reader import; raw identity/count checks; recoverable local writes; H5AD export |
| `morphology.py` | Polygon metrics and explicit ID joins |
| `qc.py` | Sparse count metrics; safe control fractions; presets; rule audit; robust shape/count diagnostics |
| `plotting.py` | SpatialData previews; bounded cell scatterplots; QC and batch figures |
| `reporting.py` | Logs; inventories; small summaries; optional checked AnnData concatenation |

The package does not depend on your external `Custom_functions/python_functions` directory or on saved `.pyc` files. Your original notebooks and helpers were used to identify the intended workflow and historical QC thresholds; old hard-coded paths, sample exclusions, and treatment labels were not carried into this new batch.

## Future H&E extension

For slide `0117690`, both region manifests refer to the same `BMS_0117690.ome.tif`, but each row retains its own alignment-file field. A future notebook can load an aligned image using the official `xenium_aligned_image` reader after verifying image axes, transform direction, scale, and region correspondence. That is a separate operation from merely finding an H&E filename.

This avoids creating an apparently registered H&E layer from an unverified identity transform. The raw image can be shared by source path; the two region transforms should be validated independently.

## Primary references

- [spatialdata-io Xenium reader API](https://spatialdata.scverse.org/projects/io/en/stable/generated/spatialdata_io.xenium.html)
- [Exact spatialdata-io v0.6.0 Xenium reader source](https://github.com/scverse/spatialdata-io/blob/v0.6.0/src/spatialdata_io/readers/xenium.py)
- [Exact SpatialData v0.7.2 implementation](https://github.com/scverse/spatialdata/blob/v0.7.2/src/spatialdata/_core/spatialdata.py)
- [10x: Understanding Xenium outputs, v3.2](https://www.10xgenomics.com/support/software/xenium-onboard-analysis/3.2/analysis/xoa-output-understanding-outputs)
- [10x: Understanding Xenium outputs, current documentation](https://www.10xgenomics.com/support/software/xenium-onboard-analysis/latest/analysis/xoa-output-understanding-outputs)
- [SpatialData-plot rendering API](https://spatialdata.scverse.org/projects/plot/en/stable/plotting.html)

Stable documentation can advance beyond the supplied lockfile. The pinned source and synthetic runtime checks take priority for implementation compatibility in this bundle.
