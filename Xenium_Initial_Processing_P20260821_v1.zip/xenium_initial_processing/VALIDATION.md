# Validation record

Prepared for the Xenium initial-processing bundle, version 1.0.0.

## Completed checks

**26 automated tests passed** in the final test-suite run. All five notebooks' code cells also executed successfully, in order, against a generated batch arranged as the user's **12 regions / 6 slides / 3 runs**. Each synthetic region contains a small real-format 10x bundle with H5 counts, Parquet metadata/boundaries/transcripts, ZIP/Zarr masks, experiment JSON, and OME-TIFF morphology.

The notebook validation ran with Python **3.13.17** on ordinary local POSIX storage. It produced 12 SpatialData stores and **24 H5AD exports** (all cells and QC-passing cells for each region). No pending table transactions remained after the complete run.

| Notebook | Code-cell execution |
|---|---|
| Step0A · discover and validate | Passed |
| Step0B · import | Passed for all 12 synthetic regions |
| Step1 · preview | Passed for all 12 synthetic regions |
| Step2 · shape measurement | Passed for all 12 synthetic regions |
| Step3 · QC and exports | Passed for all 12 synthetic regions |

Code cells were executed by a Python test runner with a fresh namespace for each notebook and temporary test paths. This checks the notebook code sequence; it is not a claim that a real experimental batch was run in the user's JupyterLab installation. Optional off-by-default paths are covered where noted below rather than represented as part of the default notebook execution.

## Tested contracts

- The directory parser finds the twelve technical regions, preserves leading-zero slide IDs, excludes the project-report PDF/H&E directories, and maps two regions to the same slide-level H&E reference.
- Manifest refresh preserves editable metadata, custom CSV columns, selection flags, and H&E overrides. Changed acquisition IDs are rejected.
- The actual `spatialdata_io.xenium` reader imports the synthetic H5/Parquet/ZIP/TIFF inputs; tests do not replace it with a mock reader.
- Cell IDs, integer mask instances, the SpatialData table link, native micrometre coordinates, and global pixel coordinates are consistent.
- Label-disabled import variants retain valid polygon or circle annotation targets.
- The named DAPI channel renders correctly; a micrometre ROI maps to the expected global pixel bounds.
- Raw gene counts, cell identities, and native vendor totals survive import, morphology annotation, QC, table updates, and H5AD export.
- Non-table spatial elements remain byte-identical during table-only persistence.
- Minimal and historical QC policies, missing optional controls, zero denominators, small panels, and threshold reruns behave as documented.
- Polygon joins use cell identities despite reordered geometries. Known rectangles, rotations, translations, physical scaling, holes, and multipolygons satisfy independent analytic expectations.
- Area/density outlier flags remain advisory and do not automatically fail cells.
- Standalone export IDs use sample prefixes. Optional same-panel concatenation checks measured feature identities and rejects mismatches.
- Compressed metadata CSVs are actually gzip-compressed despite being written through a temporary staging name.
- Altered raw counts are rejected during a vanilla-table update.
- Injected installation failure rolls back the previous table. Simulated interruption before or after new-table installation blocks reads until explicit recovery.
- A cooperative reader cannot race an active table writer.
- All five delivered notebooks validate against the notebook schema, all Python code cells parse, and delivered notebooks have clean execution state and no synthetic output embedded.
- `environment_reference/pyproject.toml` and `environment_reference/uv.lock` match the supplied files byte-for-byte.

## Runtime versions

| Package | Tested version |
|---|---:|
| Python | 3.13.17 |
| spatialdata | 0.7.2 |
| spatialdata-io | 0.6.0 |
| spatialdata-plot | 0.3.3 |
| anndata | 0.12.11 |
| scanpy | 1.12.1 |
| numpy | 2.4.4 |
| pandas | 2.3.3 |
| shapely | 2.1.2 |
| scipy | 1.17.1 |
| dask | 2026.1.1 |
| zarr | 3.1.6 |
| pyarrow | 24.0.0 |

This was an isolated CPU test environment matching the core pinned packages, not a full recreation of every GPU dependency in the user's uv project. The final pytest run emitted 17 warnings, principally upstream compatibility/serialization warnings and a Matplotlib layout warning; the generated morphology, QC, and batch figures were also inspected visually.

## Filesystem finding and supported write assumptions

The identical notebook sequence initially encountered stale transaction sidecars in the automatically synchronized working directory, even after a completed table update. A fresh complete run on ordinary `/tmp` storage succeeded without stale sidecars or pending transactions. Recovery checks were retained throughout; they were not disabled to make the run pass.

Use a local or mounted POSIX directory filesystem with reliable advisory locks and same-filesystem renames, and a single writer per region. Background synchronization that restores earlier file states is outside this transaction model. Direct S3/object-store writes and the user's particular network mount were not tested. For those environments, perform mutable processing on suitable local storage before copying completed results to the final destination.

## Limits of this validation

The real 10x outputs, experiment metadata, morphology masks/images, and aligned H&E were not supplied. Therefore this validation does not establish actual cell counts, panel composition, QC retention, biological segmentation accuracy, H&E alignment, whole-slide memory use, or full-batch runtime. Synthetic runtimes are not useful estimates for the user's experimental dataset.

The true-reader fixture represents a newer Xenium layout with a named DAPI morphology channel. Legacy and future/version-specific bundles still rely on the official pinned reader's supported formats and the preflight checks; no claim is made that every 10x software release or multi-assay variation was exercised.

The default first run on real data should begin with one chosen region, review its import inventory and preview, and then expand the selection to the full batch. This is a practical data-specific check after the code validation above.

## Reproduce the included smoke tests

From this extracted folder, with the user's uv environment activated:

```bash
python -m pytest tests -q
```

The tests generate tiny temporary fixtures. They do not use `workflow_config.json`, do not touch the real batch, and do not download external datasets. `validation_summary.json` records the corresponding structured version/notebook results; `SOURCE_PROVENANCE.json` records the provided reference-file hashes and primary documentation links.
