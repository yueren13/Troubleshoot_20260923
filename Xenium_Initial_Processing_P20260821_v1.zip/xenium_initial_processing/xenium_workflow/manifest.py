"""Discover only Xenium region directories, preserving identifiers as strings."""
from __future__ import annotations

from collections import Counter
from datetime import datetime
from pathlib import Path
import json
import re
import warnings

import pandas as pd

from .config import WorkflowConfig


REGION_PATTERN = re.compile(
    r"^output-(?P<instrument_id>[^/]+?)__(?P<slide_id>[^/]+?)__"
    r"(?P<region_name>Region_(?P<region_id>\d+))__"
    r"(?P<run_date>\d{8})__(?P<run_time>\d{6})$"
)
IDENTITY_COLUMNS = ["sample_id", "run_id", "instrument_id", "slide_id",
                    "region_id", "region_name", "run_date", "run_time", "source_dir", "zarr_path"]
EDITABLE_COLUMNS = ["include", "sample_name", "biological_sample_id", "donor_id", "tissue",
                    "condition", "notes", "he_image_path", "he_alignment_path", "he_alignment_status"]


def parse_output_name(name: str) -> dict[str, str]:
    match = REGION_PATTERN.fullmatch(name)
    if match is None:
        raise ValueError(f"Unexpected region directory name: {name}")
    result = match.groupdict()
    datetime.strptime(result["run_date"] + result["run_time"], "%Y%m%d%H%M%S")
    return result


def _he_match(batch_root: Path, slide_id: str) -> tuple[str, str]:
    folder = batch_root / "post_Xenium_HE_images" / "ome_tiff"
    names = {f"bms_{slide_id}.ome.tif", f"bms_{slide_id}.ome.tiff"}
    matches = sorted(p for p in folder.iterdir() if p.is_file() and p.name.lower() in names) if folder.is_dir() else []
    if len(matches) > 1:
        raise ValueError(f"Ambiguous H&E image for slide {slide_id}: {matches}")
    expected = folder / f"BMS_{slide_id}.ome.tif"
    return str(matches[0] if matches else expected), "found" if matches else "not_found"


def discover_samples(config: WorkflowConfig) -> pd.DataFrame:
    root = Path(config.batch_root).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(root)
    rows = []
    for run_dir in sorted(root.glob("Xenium_run_*")):
        if not run_dir.is_dir():
            continue
        for source in sorted(run_dir.glob("output-*")):
            if not source.is_dir():
                continue
            parsed = parse_output_name(source.name)
            # Run + instrument + slide + region + timestamp is a stable, collision-resistant technical ID.
            sample_id = "__".join([run_dir.name, parsed["instrument_id"], parsed["slide_id"],
                                   parsed["region_name"], parsed["run_date"], parsed["run_time"]])
            he, he_status = _he_match(root, parsed["slide_id"])
            rows.append({"include": "true", "sample_id": sample_id,
                         "sample_name": f"{run_dir.name}_{parsed['slide_id']}_{parsed['region_name']}",
                         "project_id": config.project_id, "batch_id": config.batch_id,
                         "run_id": run_dir.name, **parsed, "source_dir": str(source),
                         "zarr_path": str(config.root / "zarr" / f"{sample_id}.zarr"),
                         "he_image_path": he, "he_file_status": he_status,
                         "he_alignment_path": "", "he_alignment_status": "pending",
                         "biological_sample_id": "", "donor_id": "", "tissue": "",
                         "condition": "", "notes": ""})
    if not rows:
        raise FileNotFoundError(f"No Xenium_run_*/output-* region directories in {root}")
    frame = pd.DataFrame(rows, dtype=str)
    validate_manifest(frame)
    if config.expected_regions is not None and len(frame) != config.expected_regions:
        warnings.warn(f"Expected {config.expected_regions} regions from your directory tree; found {len(frame)}. "
                      "Review the discovery table before importing.", stacklevel=2)
    return frame


def validate_manifest(frame: pd.DataFrame) -> None:
    missing = set(IDENTITY_COLUMNS + ["include"]) - set(frame.columns)
    if missing:
        raise ValueError(f"Manifest is missing columns: {sorted(missing)}")
    for column in ("sample_id", "source_dir", "zarr_path"):
        if frame[column].eq("").any() or frame[column].duplicated().any():
            raise ValueError(f"Manifest {column} must be nonempty and unique.")
    for value in frame["include"]:
        parse_include(value)
    for row in frame.to_dict("records"):
        if not re.fullmatch(r"[A-Za-z0-9_.-]+(?:__[A-Za-z0-9_.-]+)*", row["sample_id"]):
            raise ValueError(f"sample_id must be safe for filenames: {row['sample_id']!r}")
        parsed = parse_output_name(Path(row["source_dir"]).name)
        source_run = Path(row["source_dir"]).parent.name
        if row["run_id"] != source_run:
            raise ValueError(f"run_id {row['run_id']!r} disagrees with source parent {source_run!r}.")
        canonical_id = "__".join([source_run, parsed["instrument_id"], parsed["slide_id"],
                                  parsed["region_name"], parsed["run_date"], parsed["run_time"]])
        if row["sample_id"] != canonical_id:
            raise ValueError("sample_id disagrees with the canonical acquisition identity; edit sample_name for a display label.")
        for key, val in parsed.items():
            if str(row[key]) != val:
                raise ValueError(f"Manifest {key}={row[key]!r} disagrees with source name {val!r}; "
                                 "read CSV identifiers as strings to preserve leading zeros.")


def parse_include(value) -> bool:
    text = str(value).strip().lower()
    if text in {"true", "1", "yes"}:
        return True
    if text in {"false", "0", "no"}:
        return False
    raise ValueError(f"include must be true or false, got {value!r}")


def read_manifest(path: str | Path) -> pd.DataFrame:
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    validate_manifest(frame)
    return frame


def save_manifest(frame: pd.DataFrame, path: str | Path, *, preserve_edits: bool = True) -> pd.DataFrame:
    """Refresh discovery while preserving user annotations; never silently drop old rows."""
    path = Path(path)
    frame = frame.copy()
    if path.exists() and preserve_edits:
        old = read_manifest(path).set_index("sample_id")
        new = frame.set_index("sample_id")
        vanished = old.index.difference(new.index)
        if len(vanished):
            raise ValueError(f"Previously recorded region(s) are missing from discovery: {list(vanished)}. "
                             "Keep the existing manifest and inspect the input mount; no overwrite occurred.")
        common = old.index.intersection(new.index)
        custom_columns = [c for c in old.columns if c not in new.columns]
        for col in custom_columns:
            new[col] = ""
        for col in EDITABLE_COLUMNS + custom_columns:
            if col in old:
                new.loc[common, col] = old.loc[common, col]
        new["he_file_status"] = new["he_image_path"].map(lambda p: "found" if Path(p).is_file() else "not_found")
        frame = new.reset_index()
    validate_manifest(frame)
    atomic_csv(frame, path)
    return frame


def selected_samples(config: WorkflowConfig) -> pd.DataFrame:
    all_rows = read_manifest(config.manifest_path)
    rows = all_rows.loc[all_rows["include"].map(parse_include)].copy()
    if config.selected_sample_ids:
        unknown = set(config.selected_sample_ids) - set(rows["sample_id"])
        if unknown:
            raise ValueError(f"Selected sample IDs are unknown or excluded: {sorted(unknown)}")
        rows = rows[rows.sample_id.isin(config.selected_sample_ids)].copy()
    if rows.empty:
        raise ValueError("No regions selected. Check include and selected_sample_ids.")
    return rows.reset_index(drop=True)


def atomic_csv(frame: pd.DataFrame, path: str | Path, *, index: bool = False) -> None:
    from uuid import uuid4
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{uuid4().hex}.tmp")
    try:
        # The staging suffix is .tmp, so compression cannot be inferred from it.
        frame.to_csv(temp, index=index, compression="gzip" if path.suffix == ".gz" else None)
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()


def manifest_summary(frame: pd.DataFrame) -> pd.DataFrame:
    return (frame.groupby(["run_id", "slide_id"], sort=True)
            .agg(n_regions=("sample_id", "size"),
                 regions=("region_name", lambda x: ", ".join(x)),
                 he_image_path=("he_image_path", "first"),
                 he_file_status=("he_file_status", "first"))
            .reset_index())


def preflight_inputs(frame: pd.DataFrame, options: dict) -> pd.DataFrame:
    """Inspect metadata/file presence only; do not read images or transcripts."""
    rows = []
    for sample in frame.to_dict("records"):
        source = Path(sample["source_dir"])
        required = ["experiment.xenium", "cells.parquet", "cell_feature_matrix.h5", "cells.zarr.zip"]
        if options.get("include_transcripts", True):
            required.append("transcripts.parquet")
        if options.get("include_cell_boundaries", True):
            required.append("cell_boundaries.parquet")
        if options.get("include_nucleus_boundaries", True):
            required.append("nucleus_boundaries.parquet")
        missing = [name for name in required if not (source / name).is_file()]
        empty = [name for name in required if (source / name).is_file() and (source / name).stat().st_size == 0]
        error = ""
        xoa = ""
        original_xoa = ""
        pixel_size = ""
        try:
            specs = json.loads((source / "experiment.xenium").read_text())
            pixel_size = float(specs["pixel_size"])
            if not (0 < pixel_size < float("inf")):
                raise ValueError("pixel_size must be finite and positive")
            original_xoa = str(specs.get("analysis_sw_version", ""))
            xoa = str((specs.get("xenium_ranger") or {}).get("version") or original_xoa)
            parsed_version = re.search(r"^(?:x|X)enium-(\d+)\.\d+\.\d+", xoa)
            if parsed_version is None:
                raise ValueError(f"Unrecognized Xenium software version {xoa!r}; pinned reader cannot verify its layout.")
            major = int(parsed_version.group(1))
            if options.get("include_morphology", True):
                if major < 2:
                    morphology = [source / "morphology_focus.ome.tif"]
                    if not morphology[0].is_file():
                        missing.append("morphology_focus.ome.tif")
                else:
                    image_dir = source / "morphology_focus"
                    morphology = [p for p in image_dir.glob("*.ome.tif") if p.is_file() and not p.name.startswith("._")]
                    names = {p.name for p in morphology}
                    if "morphology_focus_0000.ome.tif" in names:
                        expected = {f"morphology_focus_{i:04}.ome.tif" for i in range(len(names))}
                        if len(names) not in {1, 4} or names != expected:
                            raise ValueError("Pinned reader expects 1 or 4 sequential morphology_focus_000N.ome.tif files.")
                    elif "ch0000_dapi.ome.tif" not in names:
                        missing.append("morphology_focus/morphology_focus_0000.ome.tif OR morphology_focus/ch0000_dapi.ome.tif")
                empty += [str(p.relative_to(source)) for p in morphology if p.is_file() and p.stat().st_size == 0]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            error = f"experiment.xenium: {exc}"
        rows.append({"sample_id": sample["sample_id"], "ready": not (missing or empty or error),
                     "missing_files": "; ".join(missing), "empty_files": "; ".join(empty),
                     "metadata_error": error, "xoa_version": xoa, "original_xoa_version": original_xoa, "pixel_size_um": pixel_size,
                     "he_found": Path(sample["he_image_path"]).is_file(),
                     "alignment_status": sample["he_alignment_status"]})
    return pd.DataFrame(rows)


def require_ready(report: pd.DataFrame) -> None:
    failed = report.loc[~report["ready"]]
    if not failed.empty:
        raise RuntimeError(f"{len(failed)} selected region(s) failed preflight. Inspect the displayed report "
                           "and metadata/input_preflight.csv. Raw files were not changed.")
