"""Small audit files and optional same-panel AnnData concatenation."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
import traceback

import numpy as np
import pandas as pd

from .config import atomic_json
from .manifest import atomic_csv


def log_event(root, step, sample_id, status, **details):
    path = Path(root) / "logs" / f"{step}.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    event = {"time_utc": datetime.now(timezone.utc).isoformat(), "step": step,
             "sample_id": sample_id, "status": status, **details}
    with path.open("a") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")


def log_exception(root, step, sample_id, exc):
    log_event(root, step, sample_id, "failed", error=str(exc), traceback=traceback.format_exc())


def table_inventory(sdata):
    rows = []
    for kind in ("images", "labels", "shapes", "points", "tables"):
        for name, element in getattr(sdata, kind).items():
            # Do not ask Dask points for their length (that could scan the data).
            if kind == "points":
                detail = f"lazy points; {element.npartitions} partitions; columns={list(element.columns)}"
            elif kind == "tables":
                detail = f"{element.n_obs:,} cells × {element.n_vars:,} features"
            elif kind == "shapes":
                detail = f"{len(element):,} geometries"
            elif hasattr(element, "children"):
                detail = "pyramid: " + ", ".join(element.children)
            else:
                detail = str(dict(element.sizes))
            rows.append({"kind": kind, "name": name, "detail": detail})
    return pd.DataFrame(rows)


def per_region_summary(adata, row):
    obs = adata.obs
    result = {"sample_id": str(row["sample_id"]), "sample_name": str(row["sample_name"]),
              "run_id": str(row["run_id"]), "slide_id": str(row["slide_id"]),
              "region_id": str(row["region_id"]), "n_cells": int(adata.n_obs),
              "n_genes": int(adata.n_vars)}
    if "qc_pass" in obs:
        result["n_pass"] = int(obs["qc_pass"].sum())
        result["n_fail"] = int(adata.n_obs - result["n_pass"])
        result["pct_pass"] = 100.0 * result["n_pass"] / adata.n_obs if adata.n_obs else float("nan")
    for column in ("transcript_counts", "total_counts_gene_expression", "n_genes_by_counts", "cell_area", "nucleus_area"):
        if column in obs:
            value = pd.to_numeric(obs[column], errors="coerce").to_numpy(dtype=float)
            value = value[np.isfinite(value)]
            result[f"median_{column}"] = float(np.median(value)) if len(value) else float("nan")
    for column in ("is_big", "is_dense"):
        if column in obs:
            result[f"n_{column}"] = int(obs[column].sum())
    if "qc_complete" in obs:
        result["n_qc_evaluation_incomplete"] = int((~obs["qc_complete"].astype(bool)).sum())
    if "xenium_qc" in adata.uns:
        result["qc_thresholds_json"] = str(adata.uns["xenium_qc"].get("thresholds_json", ""))
    return result


def merge_summary(existing_path, new_rows):
    """Update summary rows without discarding previously completed samples."""
    path = Path(existing_path)
    frame = pd.DataFrame(new_rows)
    if path.exists():
        old = pd.read_csv(path, dtype={"sample_id": str, "sample_name": str, "slide_id": str,
                                      "region_id": str, "run_id": str})
        frame = pd.concat([old.loc[~old.sample_id.isin(frame.sample_id)], frame], ignore_index=True)
    frame = frame.sort_values("sample_id").reset_index(drop=True)
    atomic_csv(frame, path)
    return frame


def concatenate_same_panel(tables: dict):
    """Optional standalone AnnData only; never merge unrelated coordinate systems.

    Fails on panel differences rather than converting unmeasured genes to zeros.
    Spatial coordinates remain local to each source region and are not a common
    slide coordinate system. Input tables and their IDs are not changed.
    """
    import anndata as ad
    if not tables:
        raise ValueError("No tables to concatenate.")
    first = next(iter(tables.values()))
    feature_set = set(first.var_names)
    feature_ids = (dict(zip(first.var_names, first.var["gene_ids"].astype(str)))
                   if "gene_ids" in first.var else None)
    copies = {}
    for name, table in tables.items():
        if not table.var_names.is_unique or set(table.var_names) != feature_set:
            raise ValueError(f"Panel mismatch in {name}; use separate datasets or explicitly design a shared-panel analysis.")
        if feature_ids is not None:
            if "gene_ids" not in table.var or dict(zip(table.var_names, table.var["gene_ids"].astype(str))) != feature_ids:
                raise ValueError(f"Feature-ID mismatch in {name}; matching symbols alone are insufficient.")
        # Labels are meaningful only in the source SpatialData store.
        copy = table.copy()
        copy.uns.pop("spatialdata_attrs", None)
        if "cell_id" not in copy.obs:
            raise KeyError(f"Original cell_id missing from {name}.")
        copy.obs_names = pd.Index(str(name) + "::" + copy.obs["cell_id"].astype(str))
        copy.obs_names.name = "sample_cell_id"
        copies[str(name)] = copy
    combined = ad.concat(copies, axis=0, join="inner", label="source_sample_id",
                         index_unique=None, merge="same", uns_merge="same")
    if not combined.obs_names.is_unique:
        raise ValueError("Combined cell IDs are not unique.")
    combined.uns.pop("spatialdata_attrs", None)
    combined.uns["coordinate_note"] = "spatial / spatial_um are local to source_sample_id; no cross-region registration."
    combined.uns["source_sample_ids"] = list(copies)
    return combined
