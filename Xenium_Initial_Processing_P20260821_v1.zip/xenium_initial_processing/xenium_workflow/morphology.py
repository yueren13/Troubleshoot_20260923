"""Planar morphology from Xenium boundary polygons, without image rasterization.

In spatialdata-io 0.6.0 the imported boundary coordinates themselves are in
micrometers. Their transformation into ``global`` coordinates produces pixels;
that transformation must NOT be applied before these native-coordinate metrics.
Use ``coordinate_scale_um=1.0`` for those boundaries. For other geometries, pass
the known micrometers per native coordinate unit explicitly.

10x ``cell_area`` and ``nucleus_area`` describe the vendor segmentation and remain
unchanged. Boundary polygons can be simplified, so the separate ``polygon_*``
measurements are descriptive diagnostics, not replacements for vendor areas.
"""
from __future__ import annotations

import warnings
from typing import Any

import numpy as np
import pandas as pd
import shapely


_NUMERIC_SUFFIXES = (
    "area_um2", "perimeter_um", "convex_area_um2", "convex_perimeter_um",
    "solidity", "convexity", "perimeter_convex_ratio", "compactness",
    "circularity", "bbox_area_um2", "bbox_occupancy", "centroid_x_um",
    "centroid_y_um", "major_axis_length_um", "minor_axis_length_um",
    "elongation", "eccentricity",
)


def _ids(values: Any, label: str) -> pd.Index:
    """Make comparison keys without interpreting IDs as labels or coordinates."""
    if isinstance(values, pd.MultiIndex):
        raise ValueError(f"{label} must be a one-dimensional cell identifier, not a MultiIndex.")
    converted = []
    for value in values:
        if value is None or pd.isna(value):
            raise ValueError(f"{label} contains a missing identifier.")
        text = value.decode("utf-8") if isinstance(value, (bytes, np.bytes_)) else str(value)
        if not text:
            raise ValueError(f"{label} contains an empty identifier.")
        converted.append(text)
    index = pd.Index(converted, name="cell_id")
    if not index.is_unique:
        examples = index[index.duplicated(keep=False)].unique().tolist()[:5]
        raise ValueError(f"{label} is not unique; example duplicate IDs: {examples!r}. Supply a one-to-one ID mapping explicitly.")
    return index


def _ring_integrals(ring: Any, origin: np.ndarray) -> np.ndarray:
    """Return orientation-independent area and moments for one closed ring."""
    xy = np.asarray(ring.coords, dtype=np.float64)[:, :2] - origin
    x0, y0 = xy[:-1, 0], xy[:-1, 1]
    x1, y1 = xy[1:, 0], xy[1:, 1]
    cross = x0 * y1 - x1 * y0
    area = np.sum(cross) / 2.0
    if area == 0:
        return np.zeros(6, dtype=np.float64)
    integrals = np.array([
        area,
        np.sum((x0 + x1) * cross) / 6.0,
        np.sum((y0 + y1) * cross) / 6.0,
        np.sum((x0 * x0 + x0 * x1 + x1 * x1) * cross) / 12.0,
        np.sum((2 * x0 * y0 + x0 * y1 + x1 * y0 + 2 * x1 * y1) * cross) / 24.0,
        np.sum((y0 * y0 + y0 * y1 + y1 * y1) * cross) / 12.0,
    ], dtype=np.float64)
    return integrals * (1.0 if area > 0 else -1.0)


def _equivalent_ellipse(geometry: Any) -> tuple[float, float, float, float]:
    """Continuous polygon area moments; no discretization or large canvas."""
    centroid = geometry.centroid
    origin = np.array([centroid.x, centroid.y])
    polygons = geometry.geoms if geometry.geom_type == "MultiPolygon" else (geometry,)
    moments = np.zeros(6, dtype=np.float64)
    for polygon in polygons:
        moments += _ring_integrals(polygon.exterior, origin)
        for interior in polygon.interiors:
            moments -= _ring_integrals(interior, origin)
    area, mx, my, mxx, mxy, myy = moments
    if not np.isfinite(moments).all() or area <= 0:
        raise ValueError("Nonfinite or nonpositive polygon moment area.")
    mean_x, mean_y = mx / area, my / area
    cov_xx = mxx / area - mean_x * mean_x
    cov_yy = myy / area - mean_y * mean_y
    cov_xy = mxy / area - mean_x * mean_y
    center = (cov_xx + cov_yy) / 2.0
    spread = float(np.hypot((cov_xx - cov_yy) / 2.0, cov_xy))
    maximum, minimum = center + spread, center - spread
    tolerance = 1e-10 * max(abs(maximum), 1.0)
    if not np.isfinite(maximum + minimum) or maximum <= 0 or minimum < -tolerance:
        raise ValueError("Polygon second-moment matrix is not positive semidefinite.")
    minimum = max(0.0, minimum)
    # A uniformly filled ellipse of semi-axis a has variance a^2/4, so its
    # full equivalent major/minor axis lengths are 4 * sqrt(eigenvalue).
    major, minor = 4.0 * np.sqrt(maximum), 4.0 * np.sqrt(minimum)
    ratio = min(1.0, minor / major)
    return float(major), float(minor), float(1.0 - ratio), float(np.sqrt(max(0.0, 1.0 - ratio * ratio)))


def measure_polygon_morphology(
    shapes: Any,
    *,
    coordinate_scale_um: float = 1.0,
    shape_id_column: str | None = None,
    include_moments: bool = True,
    prefix: str = "polygon_",
) -> pd.DataFrame:
    """Return one row per explicitly identified polygon or multipolygon.

    Parameters
    ----------
    shapes
        GeoDataFrame/GeoSeries (or a DataFrame with a ``geometry`` column).
        Its index must be the native cell ID unless ``shape_id_column`` is set.
    coordinate_scale_um
        Micrometers per native geometry coordinate unit. Set **1.0** for native
        Xenium boundaries from the pinned reader. If geometries have already
        been transformed into image pixels, supply the measured pixel size.
        SpatialData transforms are deliberately not guessed or applied here.
    shape_id_column
        Optional explicit ID column in ``shapes``. The function never substitutes
        table row order or integer label instance IDs for cell IDs.
    include_moments
        Compute equivalent ellipse axes, elongation and eccentricity from exact
        continuous polygon moments, including holes and all components. This is
        linear in polygon vertices and uses constant temporary memory per cell.
    prefix
        Prefix for new columns; default ``polygon_`` avoids vendor name clashes.

    Invalid, empty, missing and nonpolygonal geometries retain their row and
    receive NaN metrics plus explicit diagnostic flags. They are not repaired.
    ``convexity`` is hull perimeter / perimeter, while
    ``perimeter_convex_ratio`` preserves the reciprocal used in the old draft.
    ``bbox_occupancy`` describes geometry, not transcript density.
    """
    if isinstance(coordinate_scale_um, bool) or not np.isfinite(coordinate_scale_um) or coordinate_scale_um <= 0:
        raise ValueError("coordinate_scale_um must be a known finite positive micrometer scale.")
    if not isinstance(prefix, str) or not prefix:
        raise ValueError("prefix must be a nonempty string.")
    if shape_id_column is None:
        identifiers = _ids(shapes.index, "Shape index")
    else:
        if shape_id_column not in shapes:
            raise KeyError(f"Shape ID column {shape_id_column!r} is absent.")
        identifiers = _ids(shapes[shape_id_column], f"Shape column {shape_id_column!r}")
    if hasattr(shapes, "geometry"):
        geometry = shapes.geometry
    elif isinstance(shapes, pd.DataFrame) and "geometry" in shapes:
        geometry = shapes["geometry"]
    else:
        raise TypeError("shapes must expose a geometry series/column.")
    geometries = np.asarray(geometry, dtype=object)
    if geometries.ndim != 1 or len(geometries) != len(identifiers):
        raise ValueError("Geometry and shape identifier lengths differ.")
    n = len(identifiers)
    result = pd.DataFrame({prefix + key: np.full(n, np.nan, dtype=float) for key in _NUMERIC_SUFFIXES}, index=identifiers)
    present = np.ones(n, dtype=bool)
    valid = np.zeros(n, dtype=bool)
    moment_valid = np.zeros(n, dtype=bool)
    statuses = np.full(n, "ok", dtype=object)
    if n:
        try:
            missing = shapely.is_missing(geometries)
            empty = shapely.is_empty(geometries)
            polygonal = np.isin(shapely.get_type_id(geometries), [3, 6])
            geometry_valid = shapely.is_valid(geometries)
        except TypeError as error:
            raise TypeError("The geometry column must contain Shapely geometries or None.") from error
        statuses[missing] = "missing_geometry"
        statuses[~missing & empty] = "empty_geometry"
        statuses[~missing & ~empty & ~polygonal] = "non_polygon_geometry"
        statuses[~missing & ~empty & polygonal & ~geometry_valid] = "invalid_geometry"
        candidates = ~missing & ~empty & polygonal & geometry_valid
        candidate_indices = np.flatnonzero(candidates)
        candidate_areas = shapely.area(geometries[candidates])
        positive = np.isfinite(candidate_areas) & (candidate_areas > 0)
        valid[candidate_indices[positive]] = True
        statuses[candidate_indices[~positive]] = "nonpositive_area"
        idx = np.flatnonzero(valid)
        if len(idx):
            g = geometries[idx]
            scale, scale2 = float(coordinate_scale_um), float(coordinate_scale_um) ** 2
            area = shapely.area(g)
            perimeter = shapely.length(g)
            hulls = shapely.convex_hull(g)
            convex_area = shapely.area(hulls)
            convex_perimeter = shapely.length(hulls)
            bounds = shapely.bounds(g)
            bbox_area = (bounds[:, 2] - bounds[:, 0]) * (bounds[:, 3] - bounds[:, 1])
            centroids = shapely.centroid(g)
            values = {
                "area_um2": area * scale2,
                "perimeter_um": perimeter * scale,
                "convex_area_um2": convex_area * scale2,
                "convex_perimeter_um": convex_perimeter * scale,
                "solidity": area / convex_area,
                "convexity": convex_perimeter / perimeter,
                "perimeter_convex_ratio": perimeter / convex_perimeter,
                "compactness": perimeter ** 2 / (4 * np.pi * area),
                "circularity": 4 * np.pi * area / perimeter ** 2,
                "bbox_area_um2": bbox_area * scale2,
                "bbox_occupancy": area / bbox_area,
                "centroid_x_um": shapely.get_x(centroids) * scale,
                "centroid_y_um": shapely.get_y(centroids) * scale,
            }
            for key, value in values.items():
                result.iloc[idx, result.columns.get_loc(prefix + key)] = value
            if include_moments:
                moment_columns = [result.columns.get_loc(prefix + name) for name in ("major_axis_length_um", "minor_axis_length_um", "elongation", "eccentricity")]
                moment_values = np.full((n, 4), np.nan, dtype=float)
                for row in idx:
                    try:
                        major, minor, elongation, eccentricity = _equivalent_ellipse(geometries[row])
                    except (ValueError, FloatingPointError, OverflowError):
                        statuses[row] = "moments_failed"
                        continue
                    moment_values[row] = [major * scale, minor * scale, elongation, eccentricity]
                    moment_valid[row] = True
                result.iloc[:, moment_columns] = moment_values
    result[prefix + "present"] = present
    result[prefix + "valid_geometry"] = valid
    result[prefix + "moments_valid"] = moment_valid
    result[prefix + "geometry_status"] = pd.Categorical(statuses)
    result.attrs["morphology_metadata"] = {
        "coordinate_scale_um": float(coordinate_scale_um),
        "coordinate_basis": "native_shape_coordinates_no_spatialdata_transform_applied",
        "area_unit": "micrometer_squared", "length_unit": "micrometer",
        "shape_id_source": "index" if shape_id_column is None else shape_id_column,
        "prefix": prefix,
        "moment_method": "continuous_polygon_area_moments" if include_moments else "disabled",
        "elongation_definition": "1 - equivalent_minor_axis / equivalent_major_axis",
        "eccentricity_definition": "sqrt(1 - (equivalent_minor_axis / equivalent_major_axis)^2)",
        "convexity_definition": "convex_hull_perimeter / polygon_perimeter",
        "perimeter_convex_ratio_definition": "polygon_perimeter / convex_hull_perimeter (old draft convention)",
        "bbox_occupancy_definition": "polygon_area / axis_aligned_bounding_box_area",
        "vendor_area_policy": "10x cell_area and nucleus_area are unchanged and authoritative",
        "invalid_geometry_policy": "retain_row_and_mark_nan_no_geometry_repair",
        "n_shapes": int(n), "n_valid_geometry": int(valid.sum()),
        "n_moments_valid": int(moment_valid.sum()),
    }
    if n and (~valid).any():
        warnings.warn(f"{int((~valid).sum())} / {n} boundary geometries could not be measured; inspect {prefix}geometry_status. No cells were removed.", UserWarning, stacklevel=2)
    if include_moments and (valid & ~moment_valid).any():
        warnings.warn(f"Polygon moment calculation failed for {int((valid & ~moment_valid).sum())} valid geometries; axis/eccentricity metrics are NaN for those cells.", UserWarning, stacklevel=2)
    return result


def annotate_morphology(
    sdata: Any,
    *,
    table_name: str = "xenium_vanilla_cell",
    shape_key: str = "cell_boundaries",
    table_id_column: str | None = "cell_id",
    shape_id_column: str | None = None,
    coordinate_scale_um: float = 1.0,
    include_moments: bool = True,
    prefix: str = "polygon_",
    strict: bool = True,
) -> pd.DataFrame:
    """Join measured geometry to a SpatialData table by explicit cell identity.

    This annotates only the in-memory table. Rows, matrix, vendor metadata,
    images, labels, geometries, transforms, and disk stores are preserved.
    ``strict=True`` rejects missing shape IDs before adding any annotations;
    ``strict=False`` retains unmatched cells with NaN metrics and explicit flags.
    The returned metrics have exactly the table's index/order. Use
    ``table_id_column=None`` only when ``obs_names`` are the desired identifiers.

    The pinned Xenium reader uses cell-ID boundary indices, even when the table
    annotates integer ``cell_labels`` mask instances. Use ``cell_id`` for that
    default join. For a separately generated label-indexed geometry, supply its
    actual corresponding observation column; no ID mapping is inferred here.
    """
    if table_name not in sdata.tables:
        raise KeyError(f"Table {table_name!r} is absent.")
    if shape_key not in sdata.shapes:
        raise KeyError(f"Shape element {shape_key!r} is absent; enable boundaries during import.")
    adata = sdata.tables[table_name]
    if table_id_column is None:
        table_ids = _ids(adata.obs_names, "Table obs_names")
    else:
        if table_id_column not in adata.obs:
            raise KeyError(f"Table ID column {table_id_column!r} is absent.")
        table_ids = _ids(adata.obs[table_id_column], f"Table column {table_id_column!r}")
    measured = measure_polygon_morphology(sdata.shapes[shape_key], coordinate_scale_um=coordinate_scale_um, shape_id_column=shape_id_column, include_moments=include_moments, prefix=prefix)
    missing_ids = table_ids.difference(measured.index, sort=False)
    if len(missing_ids) and strict:
        raise ValueError(
            f"{len(missing_ids)} table cells have no matching ID in {shape_key!r}; examples: {missing_ids.tolist()[:5]!r}. "
            "Check table_id_column/shape_id_column explicitly; do not join by row order or assume that mask label IDs equal cell IDs."
        )
    aligned = measured.reindex(table_ids).copy()
    aligned.index = adata.obs_names.copy()
    for suffix in ("present", "valid_geometry", "moments_valid"):
        aligned[prefix + suffix] = aligned[prefix + suffix].eq(True)
    status = aligned[prefix + "geometry_status"].astype(object)
    aligned[prefix + "geometry_status"] = pd.Categorical(status.where(pd.notna(status), "missing_shape"))
    for column in aligned:
        adata.obs[column] = aligned[column]
    if shape_key == "cell_boundaries" and "cell_area" in adata.obs:
        vendor_area = pd.to_numeric(adata.obs["cell_area"], errors="coerce").to_numpy(dtype=float, na_value=np.nan)
        polygon_area = aligned[prefix + "area_um2"].to_numpy(dtype=float)
        ratio = np.full(len(adata), np.nan, dtype=float)
        np.divide(polygon_area, vendor_area, out=ratio, where=np.isfinite(vendor_area) & (vendor_area > 0))
        adata.obs[prefix + "to_vendor_cell_area_ratio"] = ratio
        aligned[prefix + "to_vendor_cell_area_ratio"] = ratio
    metadata = dict(measured.attrs["morphology_metadata"])
    metadata.update({
        "shape_key": shape_key, "table_name": table_name,
        "table_id_source": "obs_names" if table_id_column is None else table_id_column,
        "n_table_cells": int(len(table_ids)), "n_missing_shape_ids": int(len(missing_ids)),
        "n_extra_shape_ids": int(len(measured.index.difference(table_ids, sort=False))),
        "strict_identity_match": bool(strict),
    })
    adata.uns.setdefault("xenium_morphology", {})[prefix.rstrip("_")] = metadata
    aligned.attrs["morphology_metadata"] = metadata
    if len(missing_ids):
        warnings.warn(f"Retained {len(missing_ids)} cells without matching boundary IDs; their {prefix}present is False and geometry metrics are NaN.", UserWarning, stacklevel=2)
    return aligned
