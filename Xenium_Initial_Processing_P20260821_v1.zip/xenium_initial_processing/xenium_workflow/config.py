"""Small, explicit configuration shared by the five notebooks."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import json
import platform
import sys
import warnings


LOCKED_CORE = {
    "spatialdata": "0.7.2", "spatialdata-io": "0.6.0",
    "spatialdata-plot": "0.3.3", "anndata": "0.12.11",
    "scanpy": "1.12.1", "pandas": "2.3.3", "shapely": "2.1.2",
    "zarr": "3.1.6", "dask": "2026.1.1", "pyarrow": "24.0.0",
}


@dataclass
class WorkflowConfig:
    batch_root: str
    output_root: str
    project_id: str = "P-20260821-0003"
    batch_id: str = "Batch1_20261010"
    expected_regions: int | None = 12
    selected_sample_ids: list[str] = field(default_factory=list)
    import_options: dict = field(default_factory=lambda: {
        "include_transcripts": True,
        "include_cell_labels": True,
        "include_nucleus_labels": True,
        "include_cell_boundaries": True,
        "include_nucleus_boundaries": True,
        "include_morphology": True,
        "n_jobs": 1,
    })

    @property
    def root(self) -> Path:
        return Path(self.output_root).expanduser().resolve()

    @property
    def manifest_path(self) -> Path:
        return self.root / "metadata" / "sample_manifest.csv"

    def prepare(self) -> None:
        source = Path(self.batch_root).expanduser().resolve()
        if not source.is_dir():
            raise FileNotFoundError(f"Set BATCH_ROOT to the directory containing Xenium_run_*: {source}")
        # Keep all generated files outside the supplied raw-data tree.
        if self.root == source or self.root.is_relative_to(source):
            raise ValueError("OUTPUT_ROOT must be outside BATCH_ROOT, to keep raw outputs separate.")
        for name in ("metadata", "zarr", "figures", "tables", "h5ad", "logs"):
            (self.root / name).mkdir(parents=True, exist_ok=True)

    def save(self, path: str | Path) -> None:
        payload = asdict(self)
        payload["batch_root"] = str(Path(self.batch_root).expanduser().resolve())
        payload["output_root"] = str(self.root)
        atomic_json(path, payload)

    @classmethod
    def load(cls, path: str | Path) -> "WorkflowConfig":
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError("Run Step0A once to create workflow_config.json beside the notebooks.")
        return cls(**json.loads(path.read_text()))


def atomic_json(path: str | Path, payload: dict | list) -> None:
    """Replace a small JSON file only after writing it completely."""
    from uuid import uuid4
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{uuid4().hex}.tmp")
    try:
        temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()


def environment_report(*, strict: bool = True) -> dict:
    """Record the actual notebook kernel; never install or upgrade packages."""
    packages = {}
    missing = []
    mismatched = []
    for name, locked in LOCKED_CORE.items():
        try:
            actual = version(name)
        except PackageNotFoundError:
            actual = "MISSING"
            missing.append(name)
        packages[name] = {"installed": actual, "lock": locked}
        if actual != locked and actual != "MISSING":
            mismatched.append(f"{name}: {actual} (lock {locked})")
    result = {"python": platform.python_version(), "executable": sys.executable,
              "platform": platform.platform(), "packages": packages}
    if strict and missing:
        raise RuntimeError("Select your existing uv project kernel; missing: " + ", ".join(missing))
    if mismatched:
        warnings.warn("Kernel differs from supplied uv.lock: " + "; ".join(mismatched), stacklevel=2)
    if sys.version_info < (3, 13):
        warnings.warn("Your supplied project requires Python >=3.13; this kernel is older.", stacklevel=2)
    return result
