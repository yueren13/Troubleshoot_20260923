"""Bounded preview and QC plots; raw matrices are never densified for plotting."""
from __future__ import annotations

from pathlib import Path
import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PALETTE = {"high_quality": "#277A78", "low_quality": "#D16B45"}


def _finish(fig, destination, dpi=180):
    fig.tight_layout()
    if destination is not None:
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(destination, dpi=dpi, bbox_inches="tight", facecolor="white")
    return fig


def _sample_indices(n, maximum=100_000, seed=0):
    return np.sort(np.random.default_rng(seed).choice(n, maximum, replace=False)) if n > maximum else np.arange(n)


def preview_spatialdata(sdata, destination=None, *, roi_um=None, channel=0, dpi=150):
    """Morphology and cell-label previews, using SpatialData transformations.

    roi_um is (xmin, ymin, xmax, ymax) in native Xenium micrometres. It is
    converted to reader-global pixels using the recorded pixel size. The
    queried container excludes transcript points, so preview does not query
    or materialize the transcript cloud. Overview rendering uses automatic
    pyramid selection; do not request scale='full' on whole-slide images.
    """
    import spatialdata as sd
    import spatialdata_plot  # noqa: F401; registers .pl

    table = sdata.tables["xenium_vanilla_cell"]
    sample = str(table.obs["sample_id"].iloc[0]) if table.n_obs else "empty region"
    image_key = "morphology_focus" if "morphology_focus" in sdata.images else next(iter(sdata.images), None)
    labels_key = "cell_labels" if "cell_labels" in sdata.labels else next(iter(sdata.labels), None)
    # Plotting a lean container avoids unintended point-cloud work.
    view = sd.SpatialData(images={image_key: sdata.images[image_key]} if image_key else {},
                          labels={labels_key: sdata.labels[labels_key]} if labels_key else {})
    if roi_um is not None:
        bounds = np.asarray(roi_um, dtype=float)
        if bounds.shape != (4,) or not np.isfinite(bounds).all() or np.any(bounds[2:] <= bounds[:2]):
            raise ValueError("roi_um must be finite (xmin,ymin,xmax,ymax), with max > min.")
        pixel_size = float(table.uns["xenium_import"]["pixel_size_um"])
        view = sd.bounding_box_query(view, axes=("x", "y"),
                                     min_coordinate=bounds[:2] / pixel_size,
                                     max_coordinate=bounds[2:] / pixel_size,
                                     target_coordinate_system="global", filter_table=False)
    fig, axes = plt.subplots(1, 2, figsize=(13, 6), dpi=dpi)
    if image_key in view.images:
        element = view.images[image_key]
        array = next(iter(element["scale0"].data_vars.values())) if hasattr(element, "children") else element
        selected_channel = channel
        # spatialdata-plot 0.3.3 interprets channel as a coordinate value, not
        # necessarily a positional index. Xenium 2+ uses names such as DAPI.
        if isinstance(channel, (int, np.integer)):
            if "c" not in array.coords or not 0 <= int(channel) < array.sizes["c"]:
                raise ValueError(f"Morphology channel index {channel} is out of bounds.")
            selected_channel = array.coords["c"].values[int(channel)].item()
        view.pl.render_images(image_key, channel=selected_channel, cmap="gray").pl.show(
            ax=axes[0], coordinate_systems="global", title=f"Morphology · {selected_channel}")
    else:
        axes[0].text(.5, .5, "Morphology image not imported / outside ROI", ha="center", va="center")
        axes[0].set_axis_off()
    if labels_key in view.labels:
        labels_title = "10x cell labels" if labels_key == "cell_labels" else f"10x {labels_key.replace('_', ' ')}"
        view.pl.render_labels(labels_key).pl.show(ax=axes[1], coordinate_systems="global", title=labels_title)
    else:
        axes[1].text(.5, .5, "Cell labels not imported / outside ROI", ha="center", va="center")
        axes[1].set_axis_off()
    for ax in axes:
        if ax.axison:
            ax.set_xlabel("Global x (morphology pixels)")
            ax.set_ylabel("Global y (morphology pixels)")
    fig.suptitle(sample + (" · ROI specified in µm" if roi_um is not None else ""), fontsize=10)
    return _finish(fig, destination, dpi)


def centroid_map(adata, destination=None, *, color=None, max_cells=150_000, title=None):
    if "spatial_um" not in adata.obsm:
        raise KeyError("spatial_um is missing; import with Step0B before making coordinate plots.")
    positions = np.asarray(adata.obsm["spatial_um"])
    ids = _sample_indices(adata.n_obs, max_cells)
    fig, ax = plt.subplots(figsize=(8, 8))
    if color and color in adata.obs:
        data = adata.obs[color].iloc[ids]
        if pd.api.types.is_numeric_dtype(data) and not pd.api.types.is_bool_dtype(data):
            values = data.to_numpy(dtype=float)
            art = ax.scatter(positions[ids, 0], positions[ids, 1], c=values, s=1.0, cmap="viridis", rasterized=True)
            fig.colorbar(art, ax=ax, label=color, shrink=.6)
        else:
            labels = data.astype(str).to_numpy()
            for label in sorted(set(labels)):
                sub = ids[labels == label]
                ax.scatter(positions[sub, 0], positions[sub, 1], s=1.0, label=label,
                           color=PALETTE.get(label), rasterized=True)
            ax.legend(markerscale=5, loc="best")
    else:
        ax.scatter(positions[ids, 0], positions[ids, 1], s=.6, color="#277A78", rasterized=True)
    ax.set(xlabel="Xenium x (µm)", ylabel="Xenium y (µm)", title=title or "Cell centroids")
    ax.set_aspect("equal")
    ax.invert_yaxis()
    if len(ids) < adata.n_obs:
        ax.text(0, -.08, f"Deterministic display sample: {len(ids):,} of {adata.n_obs:,} cells; QC uses all cells.",
                transform=ax.transAxes, fontsize=8)
    return _finish(fig, destination)


def _missing(ax, fields):
    ax.text(.5, .5, "Not available\n" + ", ".join(fields), ha="center", va="center", transform=ax.transAxes)
    ax.set_axis_off()


def _hist(ax, obs, field, *, log1p=False):
    if field not in obs:
        return _missing(ax, [field])
    values = pd.to_numeric(obs[field], errors="coerce").to_numpy(dtype=float)
    valid = np.isfinite(values) & (values >= 0 if log1p else True)
    values = values[valid]
    if not len(values):
        return _missing(ax, [field])
    values = np.log1p(values) if log1p else values
    edges = np.histogram_bin_edges(values, bins=50)
    if "qc_status" in obs:
        statuses = obs["qc_status"].astype(str).to_numpy()[valid]
        for status, color in PALETTE.items():
            ax.hist(values[statuses == status], bins=edges, histtype="step", lw=1.5, color=color, label=status)
    else:
        ax.hist(values, bins=edges, color="#277A78", alpha=.85)
    ax.set_xlabel(f"log1p({field})" if log1p else field)
    ax.set_ylabel("Cells")


def _scatter(ax, obs, x, y, *, logx=False, logy=False, max_cells=60_000):
    missing = [name for name in (x, y) if name not in obs]
    if missing:
        return _missing(ax, missing)
    sub = obs.iloc[_sample_indices(len(obs), max_cells)]
    xx = pd.to_numeric(sub[x], errors="coerce").to_numpy(dtype=float)
    yy = pd.to_numeric(sub[y], errors="coerce").to_numpy(dtype=float)
    valid = np.isfinite(xx) & np.isfinite(yy)
    if logx:
        valid &= xx >= 0
        xx = np.log1p(np.maximum(xx, 0))
    if logy:
        valid &= yy >= 0
        yy = np.log1p(np.maximum(yy, 0))
    if "qc_status" in sub:
        statuses = sub["qc_status"].astype(str).to_numpy()
        for label, color in PALETTE.items():
            take = valid & (statuses == label)
            ax.scatter(xx[take], yy[take], s=1.0, alpha=.35, color=color, rasterized=True, label=label)
    else:
        ax.scatter(xx[valid], yy[valid], s=1.0, alpha=.35, color="#277A78", rasterized=True)
    ax.set_xlabel(f"log1p({x})" if logx else x)
    ax.set_ylabel(f"log1p({y})" if logy else y)


def qc_diagnostics(adata, destination=None, *, title="QC diagnostics"):
    """All-cell distributions plus bounded scatterplots, including shape proxies."""
    obs = adata.obs
    fig, axes = plt.subplots(3, 3, figsize=(15, 12))
    _hist(axes[0, 0], obs, "transcript_counts", log1p=True)
    _hist(axes[0, 1], obs, "n_genes_by_counts", log1p=True)
    _hist(axes[0, 2], obs, "frac_real")
    _scatter(axes[1, 0], obs, "cell_area", "transcript_counts", logx=True, logy=True)
    _scatter(axes[1, 1], obs, "cell_area", "nucleus_area", logx=True, logy=True)
    _scatter(axes[1, 2], obs, "polygon_solidity", "polygon_circularity")
    _scatter(axes[2, 0], obs, "cell_area", "polygon_area_um2", logx=True, logy=True)
    _scatter(axes[2, 1], obs, "polygon_solidity", "polygon_eccentricity")
    _hist(axes[2, 2], obs, "counts_area_resid")
    if "qc_status" in obs:
        from matplotlib.patches import Patch
        fig.legend(handles=[Patch(color=c, label=l) for l, c in PALETTE.items()],
                   loc="upper right", bbox_to_anchor=(.99, 1.02), frameon=False)
    fig.suptitle(title, fontsize=14)
    return _finish(fig, destination)


def control_diagnostics(adata, destination=None, *, title="Control fractions"):
    fields = ["frac_real", "frac_negP", "frac_negCw", "frac_genomic", "frac_unass", "deprecated_codeword_counts"]
    fig, axes = plt.subplots(2, 3, figsize=(13, 7))
    for ax, field in zip(axes.flat, fields):
        _hist(ax, adata.obs, field)
    fig.suptitle(title + " · fractions use original 10x total_counts", fontsize=12)
    return _finish(fig, destination)


def batch_qc_plot(summary: pd.DataFrame, destination=None):
    required = {"sample_name", "n_cells", "n_pass"}
    if not required <= set(summary):
        raise ValueError(f"Missing batch summary fields: {required - set(summary)}")
    summary = summary.copy()
    y = np.arange(len(summary))
    keep = summary["n_pass"].to_numpy(dtype=float)
    fail = summary["n_cells"].to_numpy(dtype=float) - keep
    denom = np.maximum(keep + fail, 1)
    fig, axes = plt.subplots(1, 2, figsize=(15, max(4, len(summary) * .4)))
    for ax, x1, x2 in [(axes[0], keep, fail), (axes[1], 100 * keep / denom, 100 * fail / denom)]:
        ax.barh(y, x1, color=PALETTE["high_quality"], label="pass")
        ax.barh(y, x2, left=x1, color=PALETTE["low_quality"], label="fail")
        ax.set_yticks(y, summary["sample_name"])
        ax.invert_yaxis()
    axes[0].set_xlabel("Cells")
    axes[1].set_xlabel("Percentage of cells")
    axes[1].set_xlim(0, 100)
    axes[1].legend(loc="lower right")
    fig.suptitle("QC retention by technical region", fontsize=13)
    return _finish(fig, destination)
