"""Non-destructive Xenium QC on a single region's AnnData table.

The count matrix, rows, cell IDs, and vendor metrics are never replaced. In
particular, ``total_counts`` retains its Xenium definition (including controls);
matrix-derived gene counts are stored under ``total_counts_gene_expression`` instead.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields, replace
import json
import warnings
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy import sparse


@dataclass(frozen=True)
class QCThresholds:
    """Editable thresholds; ``None`` disables a criterion.

    The default is deliberately modest: at least 10 gene transcripts per cell.
    Historical fractions are available with :meth:`from_preset`, but need review
    for this panel/tissue. Missing optional control measurements are explicitly
    unevaluated, never silently treated as zero.
    """
    min_transcript_counts: float = 10.0
    min_genes: float | None = None
    min_real_fraction: float | None = None
    max_control_probe_fraction: float | None = None
    max_control_codeword_fraction: float | None = None
    max_genomic_control_fraction: float | None = None
    max_unassigned_codeword_fraction: float | None = None
    max_deprecated_codeword_counts: float | None = None

    def __post_init__(self) -> None:
        for f in fields(self):
            value = getattr(self, f.name)
            if value is None:
                if f.name == "min_transcript_counts":
                    raise ValueError("min_transcript_counts must be a nonnegative number.")
                continue
            if isinstance(value, (bool, np.bool_)) or not np.isfinite(float(value)) or float(value) < 0:
                raise ValueError(f"{f.name} must be a finite nonnegative number or None.")
            if "fraction" in f.name and float(value) > 1:
                raise ValueError(f"{f.name} is a fraction in [0, 1], not a percentage.")
            object.__setattr__(self, f.name, float(value))

    @classmethod
    def from_preset(cls, preset: str = "minimal_transcripts", **overrides: Any) -> "QCThresholds":
        if preset in {"minimal_transcripts", "conservative", "recommended", "minimal"}:
            base = cls()
        elif preset in {"historical", "legacy", "original_step3"}:
            base = cls(
                min_transcript_counts=10,
                min_real_fraction=0.70,
                max_control_probe_fraction=0.05,
                max_control_codeword_fraction=0.02,
                max_genomic_control_fraction=0.005,
                max_unassigned_codeword_fraction=0.10,
                max_deprecated_codeword_counts=0,
            )
        else:
            raise ValueError(f"Unknown QC preset {preset!r}; choose 'minimal_transcripts' or 'legacy'.")
        return replace(base, **overrides)

    @classmethod
    def legacy(cls, **overrides: Any) -> "QCThresholds":
        """Original Step3 hard thresholds; opt in only after inspecting controls."""
        return cls.from_preset("legacy", **overrides)


def qc_thresholds(preset: str = "minimal_transcripts", overrides: Mapping[str, Any] | None = None) -> QCThresholds:
    """Create a preset with optional per-sample numeric overrides."""
    return QCThresholds.from_preset(preset, **dict(overrides or {}))


def _numeric(obs: pd.DataFrame, key: str) -> np.ndarray:
    if key not in obs:
        return np.full(len(obs), np.nan, dtype=float)
    return pd.to_numeric(obs[key], errors="coerce").to_numpy(dtype=float, na_value=np.nan)


def _safe_fraction(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
    out = np.full(len(denominator), np.nan, dtype=float)
    valid = np.isfinite(numerator) & (numerator >= 0) & np.isfinite(denominator) & (denominator > 0)
    np.divide(numerator, denominator, out=out, where=valid)
    return out


def annotate_gene_count_metrics(
    adata: Any,
    *,
    count_layer: str | None = None,
    percent_top: Sequence[int] = (10, 20, 50, 150),
    chunk_size: int = 1024,
) -> dict[str, Any]:
    """Calculate sparse-safe raw gene-count metrics without touching vendor totals.

    ``X`` (or the selected layer) must contain gene-expression counts. No
    normalization, log transform, or filtering is applied to the matrix. Top-N
    percentages use bounded row blocks; N larger than the panel is omitted.
    """
    if isinstance(chunk_size, bool) or int(chunk_size) != chunk_size or chunk_size < 1:
        raise ValueError("chunk_size must be positive.")
    if count_layer is not None and count_layer not in adata.layers:
        raise KeyError(f"Count layer {count_layer!r} is absent.")
    matrix = adata.X if count_layer is None else adata.layers[count_layer]
    if matrix is None:
        raise ValueError("The selected raw count matrix is empty.")
    is_sparse = sparse.issparse(matrix)
    if is_sparse:
        matrix = matrix.tocsr(copy=False)
        if not matrix.has_canonical_format:
            matrix = matrix.copy()
            matrix.sum_duplicates()
        values = matrix.data
    elif isinstance(matrix, np.ndarray):
        values = matrix
    else:
        raise TypeError("QC requires an in-memory NumPy or SciPy sparse count matrix. Read the table first.")
    if not np.issubdtype(values.dtype, np.number) or np.issubdtype(values.dtype, np.complexfloating):
        raise TypeError("The count matrix must contain real numeric counts.")
    if not np.isfinite(values).all() or np.any(values < 0):
        raise ValueError("Counts must be finite and nonnegative.")
    if not np.issubdtype(values.dtype, np.integer) and not np.allclose(values, np.rint(values), rtol=0, atol=1e-6):
        raise ValueError("The selected matrix is not raw integer-like counts; choose the raw count layer.")
    n_obs, n_vars = matrix.shape
    gene_counts = np.asarray(matrix.sum(axis=1, dtype=np.float64), dtype=float).ravel()
    detected = np.asarray((matrix > 0).sum(axis=1), dtype=np.int64).ravel()
    adata.obs["total_counts_gene_expression"] = gene_counts
    adata.obs["n_genes_by_counts"] = detected
    adata.obs["log1p_total_counts_gene_expression"] = np.log1p(gene_counts)
    adata.obs["log1p_n_genes_by_counts"] = np.log1p(detected)
    feature_totals = np.asarray(matrix.sum(axis=0, dtype=np.float64), dtype=float).ravel()
    feature_detected = np.asarray((matrix > 0).sum(axis=0), dtype=np.int64).ravel()
    adata.var["total_counts"] = feature_totals
    adata.var["n_cells_by_counts"] = feature_detected
    adata.var["mean_counts"] = feature_totals / n_obs if n_obs else np.full(n_vars, np.nan)
    adata.var["pct_dropout_by_counts"] = 100 * (1 - feature_detected / n_obs) if n_obs else np.full(n_vars, np.nan)
    requested: list[int] = []
    for value in percent_top:
        if isinstance(value, bool) or int(value) != value or int(value) < 1:
            raise ValueError("percent_top values must be positive integers.")
        requested.append(int(value))
    usable = sorted({v for v in requested if v <= n_vars})
    # Remove only previously generated Top-N columns, so changing panel/options
    # cannot leave stale metrics behind on a rerun.
    for key in list(adata.obs.columns):
        if key.startswith("pct_counts_in_top_") and key.endswith("_genes"):
            del adata.obs[key]
    top = {n: np.full(n_obs, np.nan, dtype=float) for n in usable}
    if usable and n_vars:
        for start in range(0, n_obs, chunk_size):
            stop = min(start + chunk_size, n_obs)
            block = matrix[start:stop].toarray() if is_sparse else np.asarray(matrix[start:stop])
            # Sort at most a row block, never the full cell-by-gene matrix.
            highest = np.sort(np.partition(block, n_vars - max(usable), axis=1)[:, -max(usable):], axis=1)[:, ::-1]
            cumulative = np.cumsum(highest, axis=1, dtype=np.float64)
            for n in usable:
                top[n][start:stop] = 100 * _safe_fraction(cumulative[:, n - 1], gene_counts[start:stop])
    for n, value in top.items():
        adata.obs[f"pct_counts_in_top_{n}_genes"] = value
    return {
        "matrix_source": "X" if count_layer is None else f"layers/{count_layer}",
        "n_obs": int(n_obs), "n_vars": int(n_vars),
        "percent_top_computed": usable,
        "percent_top_omitted_panel_too_small": sorted(set(requested) - set(usable)),
    }


def _huber_line(x: np.ndarray, y: np.ndarray, max_iter: int = 30) -> tuple[np.ndarray, str]:
    """Two-parameter Huber IRLS without an optional statsmodels dependency."""
    center = float(np.mean(x))
    xc = x - center
    if np.ptp(xc) < 1e-12:
        return np.array([float(np.median(y)), 0.0]), "constant_area_median"
    design = np.column_stack([np.ones(len(x)), xc])
    beta = np.linalg.lstsq(design, y, rcond=None)[0]
    for _ in range(max_iter):
        residual = y - design @ beta
        median = float(np.median(residual))
        scale = 1.4826 * float(np.median(np.abs(residual - median)))
        if scale <= 1e-12:
            break
        standardized = np.abs(residual) / (1.345 * scale)
        weights = np.ones_like(standardized)
        far = standardized > 1
        weights[far] = 1 / standardized[far]
        weight_sum = weights.sum()
        xm = np.sum(weights * xc) / weight_sum
        ym = np.sum(weights * y) / weight_sum
        denominator = np.sum(weights * (xc - xm) ** 2)
        if denominator <= 1e-15:
            break
        slope = np.sum(weights * (xc - xm) * (y - ym)) / denominator
        new_beta = np.array([ym - slope * xm, slope])
        if np.max(np.abs(beta - new_beta)) < 1e-8:
            beta = new_beta
            break
        beta = new_beta
    return np.array([beta[0] - beta[1] * center, beta[1]]), "huber_irls"


def fit_counts_area_residuals(
    adata: Any,
    *,
    count_column: str = "transcript_counts",
    area_column: str = "cell_area",
    groupby: str | None = None,
    max_fit_cells: int = 100_000,
    min_fit_cells: int = 10,
    big_n_mad: float = 3.0,
    dense_n_mad: float = 3.0,
) -> dict[str, Any]:
    """Annotate exploratory shape/density flags independently of pass/fail QC.

    Uses log10(gene transcripts + 1) versus log10(vendor cell area). Large-cell
    and dense-cell flags are observations, not evidence of doublets or errors.
    Fit separately per region; pass ``groupby`` only if using a combined table.
    """
    if max_fit_cells < min_fit_cells or min_fit_cells < 2:
        raise ValueError("Require max_fit_cells >= min_fit_cells >= 2.")
    if big_n_mad <= 0 or dense_n_mad <= 0:
        raise ValueError("MAD multipliers must be positive.")
    obs = adata.obs
    counts, areas = _numeric(obs, count_column), _numeric(obs, area_column)
    if groupby is None:
        groups = np.repeat("all_cells", len(obs))
    else:
        if groupby not in obs:
            raise KeyError(groupby)
        if obs[groupby].isna().any():
            raise ValueError(f"{groupby!r} has missing groups.")
        groups = obs[groupby].astype(str).to_numpy()
    residuals = np.full(len(obs), np.nan)
    zscores = np.full(len(obs), np.nan)
    is_big = np.zeros(len(obs), dtype=bool)
    is_dense = np.zeros(len(obs), dtype=bool)
    evaluated = np.zeros(len(obs), dtype=bool)
    fit_records: list[dict[str, Any]] = []
    for group in pd.unique(groups):
        where_group = groups == group
        valid = where_group & np.isfinite(areas) & (areas > 0) & np.isfinite(counts) & (counts >= 0)
        valid_rows = np.flatnonzero(valid)
        if len(valid_rows) < min_fit_cells:
            fit_records.append({"group": str(group), "status": "insufficient_valid_cells", "n_valid": int(len(valid_rows))})
            continue
        fit_rows = valid_rows
        if len(fit_rows) > max_fit_cells:
            fit_rows = fit_rows[np.linspace(0, len(fit_rows) - 1, max_fit_cells, dtype=np.int64)]
        beta, method = _huber_line(np.log10(areas[fit_rows]), np.log10(counts[fit_rows] + 1))
        r = np.log10(counts[valid_rows] + 1) - (beta[0] + beta[1] * np.log10(areas[valid_rows]))
        center = float(np.median(r))
        scale = 1.4826 * float(np.median(np.abs(r - center)))
        scale_method = "1.4826_median_absolute_deviation"
        if scale <= 1e-12:
            scale = float(np.std(r))
            scale_method = "std_fallback_for_zero_mad"
        residuals[valid_rows] = r
        if scale > 1e-12:
            zscores[valid_rows] = (r - center) / scale
            is_dense[valid_rows] = zscores[valid_rows] > dense_n_mad
        else:
            zscores[valid_rows] = 0.0
            scale_method = "zero_spread_no_dense_flags"
        area_center = float(np.median(areas[valid_rows]))
        area_scale = 1.4826 * float(np.median(np.abs(areas[valid_rows] - area_center)))
        # If every core cell has the same area, any larger cell is still flagged
        # for inspection; this is advisory and never removes a cell.
        area_cutoff = area_center + big_n_mad * area_scale
        is_big[valid_rows] = areas[valid_rows] > area_cutoff
        evaluated[valid_rows] = True
        fit_records.append({
            "group": str(group), "status": "fitted", "method": method,
            "n_valid": int(len(valid_rows)), "n_fit": int(len(fit_rows)),
            "intercept": float(beta[0]), "slope": float(beta[1]),
            "residual_center": center, "residual_scale": scale,
            "residual_scale_method": scale_method,
            "area_median_um2": area_center, "area_scaled_mad_um2": area_scale,
            "big_area_cutoff_um2": area_cutoff,
        })
    obs["counts_area_resid"] = residuals
    obs["counts_area_resid_robust_z"] = zscores
    obs["is_big"] = is_big
    obs["is_dense"] = is_dense
    obs["seg_qc_evaluated"] = evaluated
    obs["seg_qc"] = pd.Categorical(np.where(~evaluated, "not_evaluated", np.where(is_big | is_dense, "suspect", "ok")), categories=["ok", "suspect", "not_evaluated"])
    result = {"count_column": count_column, "area_column": area_column, "big_n_mad": big_n_mad, "dense_n_mad": dense_n_mad, "fits": fit_records}
    adata.uns["counts_area_fit_json"] = json.dumps(result, allow_nan=False)
    return result


def annotate_qc(
    adata: Any,
    thresholds: QCThresholds | Mapping[str, Any] | str | None = None,
    *,
    groupby: str | None = None,
    count_layer: str | None = None,
    percent_top: Sequence[int] = (10, 20, 50, 150),
    sample_name: str | None = None,
    calculate_segmentation_diagnostics: bool = True,
) -> dict[str, Any]:
    """Add gene metrics, fractions, rule audit, and QC labels, preserving all cells.

    ``qc_pass`` means all *evaluated* enabled criteria passed. Inspect
    ``qc_complete`` and ``qc_not_evaluated`` when optional measurements are absent.
    Missing/invalid required transcript counts fail; zero vendor totals fail any
    enabled fraction criteria. Optional missing controls are skipped with a
    warning and recorded in ``uns['xenium_qc']``.
    """
    if thresholds is None:
        thresholds = QCThresholds()
    elif isinstance(thresholds, str):
        thresholds = QCThresholds.from_preset(thresholds)
    elif isinstance(thresholds, Mapping):
        thresholds = QCThresholds(**dict(thresholds))
    if not isinstance(thresholds, QCThresholds):
        raise TypeError("thresholds must be QCThresholds, a mapping, a preset name, or None.")
    if "transcript_counts" not in adata.obs:
        raise KeyError("Xenium transcript_counts is required; import the cells metadata first.")
    metrics = annotate_gene_count_metrics(adata, count_layer=count_layer, percent_top=percent_top)
    obs = adata.obs
    if sample_name is not None:
        if "sample_name" in obs and len(obs) and not obs["sample_name"].astype(str).eq(str(sample_name)).all():
            raise ValueError("sample_name disagrees with an existing sample_name column.")
        obs["sample_name"] = str(sample_name)
    if "xenium_total_counts" not in obs:
        if "total_counts" in obs:
            warnings.warn("xenium_total_counts absent: preserving current total_counts as vendor totals. This must be the unmodified Xenium cells metadata, not Scanpy totals.", UserWarning, stacklevel=2)
            obs["xenium_total_counts"] = obs["total_counts"].copy()
        else:
            obs["xenium_total_counts"] = np.nan
    denominator = _numeric(obs, "xenium_total_counts")
    fractions = {
        "frac_real": "transcript_counts", "frac_negP": "control_probe_counts",
        "frac_negCw": "control_codeword_counts", "frac_genomic": "genomic_control_counts",
        "frac_unass": "unassigned_codeword_counts",
    }
    for destination, source in fractions.items():
        obs[destination] = _safe_fraction(_numeric(obs, source), denominator)
    obs["frac_control_probe"] = obs["frac_negP"]
    obs["frac_control_codeword"] = obs["frac_negCw"]
    obs["frac_genomic_control"] = obs["frac_genomic"]
    obs["frac_unassigned_codeword"] = obs["frac_unass"]
    obs["nucleus_cell_area_ratio"] = _safe_fraction(_numeric(obs, "nucleus_area"), _numeric(obs, "cell_area"))
    obs["transcripts_per_um2"] = _safe_fraction(_numeric(obs, "transcript_counts"), _numeric(obs, "cell_area"))
    obs["gene_matrix_matches_transcript_counts"] = np.isclose(obs["total_counts_gene_expression"].to_numpy(), _numeric(obs, "transcript_counts"), rtol=0, atol=1e-6)
    # Each tuple: rule, metric, source metadata, comparison, threshold.
    definitions = [
        ("min_transcript_counts", "transcript_counts", "transcript_counts", "min", thresholds.min_transcript_counts),
        ("min_genes", "n_genes_by_counts", "n_genes_by_counts", "min", thresholds.min_genes),
        ("min_real_fraction", "frac_real", "transcript_counts", "min", thresholds.min_real_fraction),
        ("max_control_probe_fraction", "frac_negP", "control_probe_counts", "max", thresholds.max_control_probe_fraction),
        ("max_control_codeword_fraction", "frac_negCw", "control_codeword_counts", "max", thresholds.max_control_codeword_fraction),
        ("max_genomic_control_fraction", "frac_genomic", "genomic_control_counts", "max", thresholds.max_genomic_control_fraction),
        ("max_unassigned_codeword_fraction", "frac_unass", "unassigned_codeword_counts", "max", thresholds.max_unassigned_codeword_fraction),
        ("max_deprecated_codeword_counts", "deprecated_codeword_counts", "deprecated_codeword_counts", "max", thresholds.max_deprecated_codeword_counts),
    ]
    for key in list(obs.columns):
        if key.startswith("qc_fail_") or key.startswith("qc_evaluated_"):
            del obs[key]
    pass_all = np.ones(len(obs), dtype=bool)
    complete = np.ones(len(obs), dtype=bool)
    reasons = np.full(len(obs), "", dtype=object)
    unknown = np.full(len(obs), "", dtype=object)
    audit: list[dict[str, Any]] = []
    for rule, metric, source, direction, threshold in definitions:
        if threshold is None:
            audit.append({"rule": rule, "metric": metric, "enabled": False, "n_evaluated": 0, "n_failed": 0, "n_not_evaluated": 0})
            continue
        values = _numeric(obs, metric)
        raw_values = _numeric(obs, source)
        raw_present = np.isfinite(raw_values)
        # Required criteria always evaluate invalid values as failure. Optional
        # missing values are unknown; invalid negatives fail if supplied.
        required = rule in {"min_transcript_counts", "min_genes", "min_real_fraction"}
        evaluated = np.ones(len(obs), dtype=bool) if required else raw_present
        passed = np.isfinite(values) & (raw_values >= 0)
        if "fraction" in rule:
            passed &= np.isfinite(denominator) & (denominator > 0) & (values >= 0) & (values <= 1)
        passed &= values >= float(threshold) if direction == "min" else values <= float(threshold)
        failed = evaluated & ~passed
        missing = ~evaluated
        obs[f"qc_evaluated_{rule}"] = evaluated
        obs[f"qc_fail_{rule}"] = failed
        pass_all &= ~failed
        complete &= evaluated
        reasons[failed] = np.where(reasons[failed] == "", rule, reasons[failed] + ";" + rule)
        unknown[missing] = np.where(unknown[missing] == "", rule, unknown[missing] + ";" + rule)
        if missing.any():
            warnings.warn(f"QC rule {rule!r} unevaluated for {int(missing.sum())} cells: metadata {source!r} is absent, nonnumeric, or nonfinite. It was not replaced by zero.", UserWarning, stacklevel=2)
        audit.append({"rule": rule, "metric": metric, "source": source, "enabled": True, "direction": direction, "threshold": float(threshold), "n_evaluated": int(evaluated.sum()), "n_failed": int(failed.sum()), "n_not_evaluated": int(missing.sum())})
    obs["qc_pass"] = pass_all
    obs["qc_complete"] = complete
    obs["qc_reason"] = reasons
    obs["qc_not_evaluated"] = unknown
    obs["qc_status"] = pd.Categorical(np.where(pass_all, "high_quality", "low_quality"), categories=["high_quality", "low_quality"])
    if calculate_segmentation_diagnostics:
        fit_counts_area_residuals(adata, groupby=groupby)
    adata.uns["xenium_qc"] = {
        "workflow_version": "1.0.0",
        "thresholds_json": json.dumps(asdict(thresholds), allow_nan=False),
        "rules_json": json.dumps(audit, allow_nan=False),
        "gene_metrics_json": json.dumps(metrics, allow_nan=False),
        "denominator": "xenium_total_counts",
        "matrix_counts_column": "total_counts_gene_expression",
        "missing_optional_metrics_policy": "skip_with_warning_and_qc_complete_false",
        "segmentation_flags_policy": "advisory_only_not_used_in_qc_pass",
        "matrix_policy": "unchanged_raw_counts_no_cells_removed",
        "control_note": "unassigned_codeword_counts are decoded unassigned codewords; they are not transcripts unassigned to cells",
    }
    return qc_summary(adata, sample_name=sample_name)


def qc_report(adata: Any) -> pd.DataFrame:
    """Return a criterion-level audit table, including explicitly skipped checks."""
    information = adata.uns.get("xenium_qc", {})
    if "rules_json" not in information:
        raise ValueError("Call annotate_qc first.")
    return pd.DataFrame(json.loads(information["rules_json"]))


def qc_summary(adata: Any, sample_name: str | None = None) -> dict[str, Any]:
    """One region's report, ready for a batch summary DataFrame/CSV."""
    obs = adata.obs
    if "qc_pass" not in obs:
        raise ValueError("Call annotate_qc first.")
    if sample_name is None:
        sample_name = str(obs["sample_name"].iloc[0]) if len(obs) and "sample_name" in obs else ""
    n = len(obs)
    passed = obs["qc_pass"].astype(bool).to_numpy()
    result: dict[str, Any] = {
        "sample_name": sample_name, "n_cells": int(n), "n_genes": int(adata.n_vars),
        "n_qc_pass": int(passed.sum()), "n_qc_fail": int((~passed).sum()),
        "pct_qc_pass": float(100 * passed.mean()) if n else np.nan,
        "n_qc_incomplete": int((~obs["qc_complete"].astype(bool)).sum()),
        "median_transcript_counts": float(np.nanmedian(_numeric(obs, "transcript_counts"))) if n else np.nan,
        "median_n_genes": float(np.nanmedian(_numeric(obs, "n_genes_by_counts"))) if n else np.nan,
        "n_matrix_transcript_count_mismatches": int((~obs["gene_matrix_matches_transcript_counts"].astype(bool)).sum()),
    }
    for key in ("is_big", "is_dense"):
        if key in obs:
            result[f"n_{key}"] = int(obs[key].astype(bool).sum())
    for column in obs.columns:
        if column.startswith("qc_fail_"):
            result[f"n_{column}"] = int(obs[column].astype(bool).sum())
    # Pooled fractions must use the same vendor denominator as per-cell fractions.
    denominator = _numeric(obs, "xenium_total_counts")
    for suffix, source in {"control_probe": "control_probe_counts", "control_codeword": "control_codeword_counts", "genomic_control": "genomic_control_counts", "unassigned_codeword": "unassigned_codeword_counts"}.items():
        numerator = _numeric(obs, source)
        valid = np.isfinite(numerator) & (numerator >= 0) & np.isfinite(denominator) & (denominator > 0)
        result[f"pooled_{suffix}_fraction"] = float(numerator[valid].sum() / denominator[valid].sum()) if valid.any() else np.nan
    return result
