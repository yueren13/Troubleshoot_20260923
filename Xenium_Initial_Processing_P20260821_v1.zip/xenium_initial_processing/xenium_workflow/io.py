"""Xenium import, identity checks, and recoverable local SpatialData writes.

The API targets spatialdata 0.7.2 / spatialdata-io 0.6.0. The original 10x
matrix remains in ``X``. H&E paths are provenance only; no unaligned image is
placed into the Xenium coordinate system.

Writes require a local/POSIX directory store, one writer, and same-filesystem
rename semantics. Mounted filesystems must support these semantics. This is
not an S3/object-store transaction implementation. Table backups are retained
outside the SpatialData store; image/point/label arrays are never rewritten
during shape or QC table updates.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
from importlib.metadata import PackageNotFoundError, version
import json
import os
from pathlib import Path
import re
from typing import Any, Mapping
from uuid import uuid4
import warnings

import numpy as np
import pandas as pd

TABLE_KEY = "xenium_vanilla_cell"
COMPLETION_MARKER = ".xenium_import_complete.json"
WORKFLOW_VERSION = "1.0.0"


@dataclass(frozen=True)
class ImportOptions:
    """Choose expensive spatial elements; cell expression is always imported.

    Transcript points are imported without an additional QV/assignment filter.
    The 10x gene-expression matrix itself already reflects the vendor's
    assigned-transcript/Q20 rules. Disabling labels keeps a valid table link
    to cell boundaries, or to cell circles if boundaries are also disabled.
    ``n_jobs`` controls polygon construction, not the Dask scheduler.
    """

    include_transcripts: bool = True
    include_cell_labels: bool = True
    include_nucleus_labels: bool = True
    include_cell_boundaries: bool = True
    include_nucleus_boundaries: bool = True
    include_morphology: bool = True
    n_jobs: int = 1

    def __post_init__(self) -> None:
        for key, value in asdict(self).items():
            if key != "n_jobs" and type(value) is not bool:
                raise TypeError(f"{key} must be a bool, not {value!r}.")
        if isinstance(self.n_jobs, bool) or not isinstance(self.n_jobs, int) or self.n_jobs < 1:
            raise ValueError("n_jobs must be a positive integer.")


def _local_path(value: str | Path) -> Path:
    if "://" in str(value):
        raise ValueError("This workflow writes local directory stores; use a local path, not a URL.")
    return Path(value).expanduser().resolve()


def _json_text(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _atomic_json(path: Path, data: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + uuid4().hex)
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, sort_keys=True, ensure_ascii=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _options(options: ImportOptions | Mapping[str, Any] | None) -> ImportOptions:
    if isinstance(options, ImportOptions):
        return options
    values = {key: value.item() if isinstance(value, np.generic) else value for key, value in dict(options or {}).items()}
    return ImportOptions(**values)


def source_fingerprint(source_dir: str | Path, options: ImportOptions | Mapping[str, Any] | None = None) -> dict:
    """Stat inputs actually consumed, and hash the small experiment manifest.

    This deliberately avoids hashing multi-gigabyte images. A change preserving
    both file size and mtime cannot be detected by this inexpensive check.
    """
    options = _options(options)
    source = _local_path(source_dir)
    spec_path = source / "experiment.xenium"
    specs = json.loads(spec_path.read_text(encoding="utf-8"))
    files = [spec_path, source / "cells.parquet", source / "cell_feature_matrix.h5"]
    # v2+ readers require the cell_summary metadata even when labels are off.
    raw_version = str((specs.get("xenium_ranger") or {}).get("version") or specs.get("analysis_sw_version", ""))
    match = re.search(r"[Xx]enium-(\d+)", raw_version)
    major = int(match.group(1)) if match else None
    if options.include_cell_labels or options.include_nucleus_labels or major is None or major >= 2:
        files.append(source / "cells.zarr.zip")
    if options.include_cell_boundaries:
        files.append(source / "cell_boundaries.parquet")
    if options.include_nucleus_boundaries:
        files.append(source / "nucleus_boundaries.parquet")
    if options.include_transcripts:
        files.append(source / "transcripts.parquet")
    if options.include_morphology:
        if major is not None and major >= 2:
            image_files = sorted((source / "morphology_focus").glob("*.ome.tif"))
            image_files = [p for p in image_files if not p.name.startswith("._")]
            if not image_files:
                raise FileNotFoundError(f"No morphology_focus/*.ome.tif files found in {source}.")
            files.extend(image_files)
        else:
            files.append(source / "morphology_focus.ome.tif")
        if (source / "morphology_mip.ome.tif").is_file():
            files.append(source / "morphology_mip.ome.tif")
    entries = []
    for path in sorted(set(files)):
        if not path.is_file():
            raise FileNotFoundError(f"Required Xenium input is missing: {path}")
        stat = path.stat()
        entries.append({"path": str(path.relative_to(source)), "size_bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns})
    result = {"files": entries, "experiment_sha256": sha256(spec_path.read_bytes()).hexdigest()}
    result["sha256"] = sha256(_json_text(result).encode()).hexdigest()
    return result


def _decode_ids(values: Any) -> pd.Index:
    result = pd.Index([v.decode("utf-8") if isinstance(v, bytes) else str(v) for v in values], dtype="object")
    if result.has_duplicates or result.isin(["", "nan", "None"]).any():
        raise ValueError("The original Xenium cell IDs must be nonempty and unique within a region.")
    return result


def _matrix_signature(adata: Any) -> dict:
    """Hash sparse buffers and row/feature identities, without densifying X."""
    from scipy import sparse

    digest = sha256()
    for index in (adata.obs_names, adata.var_names):
        digest.update("\0".join(index.astype(str)).encode())
        digest.update(b"\0\0")
    matrix = adata.X
    if sparse.issparse(matrix):
        matrix = matrix.tocsr(copy=False)
        for array in (matrix.data, matrix.indices, matrix.indptr):
            digest.update(str(array.dtype).encode())
            digest.update(memoryview(np.ascontiguousarray(array)).cast("B"))
        nnz = int(matrix.nnz)
    else:
        array = np.asarray(matrix)
        digest.update(str(array.dtype).encode())
        digest.update(memoryview(np.ascontiguousarray(array)).cast("B"))
        nnz = int(np.count_nonzero(array))
    return {"n_obs": int(adata.n_obs), "n_vars": int(adata.n_vars), "nnz": nnz, "sha256": digest.hexdigest()}


def assert_table_links(sdata: Any, table_key: str = TABLE_KEY) -> None:
    """Validate identities and annotation links without scanning full masks.

    The pinned reader already checks cell-label IDs against the raster. Here
    IDs are checked for missing/duplicate values and valid shape references.
    This never invents a mapping from row order or assumes nucleus IDs equal
    cell IDs.
    """
    from spatialdata.models import TableModel, get_table_keys

    if table_key not in sdata.tables:
        raise KeyError(f"Expected SpatialData table {table_key!r}; found {list(sdata.tables)}.")
    adata = sdata.tables[table_key]
    TableModel.validate(adata)
    if adata.n_obs == 0 or adata.n_vars == 0:
        raise ValueError("The Xenium table has no cells or no gene-expression features.")
    if "cell_id" not in adata.obs:
        raise KeyError("Original 10x cell_id is missing from table.obs.")
    ids = _decode_ids(adata.obs["cell_id"])
    if not adata.obs_names.is_unique:
        raise ValueError("AnnData observation names are not unique.")
    regions, region_key, instance_key = get_table_keys(adata)
    if regions is None or region_key is None or instance_key is None:
        raise ValueError("The cell table has no SpatialData region/instance annotation metadata.")
    targets = [regions] if isinstance(regions, str) else list(regions)
    if len(targets) != 1:
        raise ValueError(f"Each imported region must annotate one cell element, got {targets!r}.")
    target = targets[0]
    if target not in sdata:
        raise ValueError(f"The table annotates missing spatial element {target!r}.")
    if set(adata.obs[region_key].astype(str)) != {str(target)}:
        raise ValueError("Table region metadata does not agree with obs region values.")
    instances = adata.obs[instance_key]
    if instances.isna().any() or instances.duplicated().any():
        raise ValueError("Cell-to-spatial-element instance IDs are missing or duplicated.")
    if target in sdata.labels:
        if not pd.api.types.is_integer_dtype(instances) or (instances <= 0).any():
            raise ValueError("Cell-label instance IDs must be positive integers; no row-order fallback is allowed.")
    elif target in sdata.shapes:
        shape_ids = sdata.shapes[target].index
        if not shape_ids.is_unique or not instances.isin(shape_ids).all():
            raise ValueError("Some table instance IDs are absent or duplicated in the target shapes.")
    else:
        raise ValueError(f"Unexpected cell annotation target type for {target!r}.")
    if len(ids) != len(instances):
        raise ValueError("Cell and instance ID lengths differ.")


def import_sample(row: Mapping[str, Any], options: ImportOptions | Mapping[str, Any] | None = None) -> Any:
    """Import one manifest row with the official Xenium reader; no disk writes.

    Native Xenium IDs become observation names. Both ``spatial`` and
    ``spatial_um`` are x/y centroids in micrometers; ``spatial_global`` is in
    morphology pixels, matching the reader's ``global`` coordinate system.
    """
    from spatialdata_io import xenium

    options = _options(options)
    source = _local_path(row["source_dir"])
    sample_id = str(row["sample_id"])
    if not sample_id or sample_id.lower() in {"nan", "none"}:
        raise ValueError("A nonempty sample_id is required.")
    fingerprint = source_fingerprint(source, options)
    specs = json.loads((source / "experiment.xenium").read_text(encoding="utf-8"))
    pixel_size = float(specs["pixel_size"])
    if not np.isfinite(pixel_size) or pixel_size <= 0:
        raise ValueError(f"Invalid experiment.xenium pixel_size: {pixel_size!r}.")
    # A valid cheap target is needed while constructing the official reader's
    # SpatialData when labels are disabled. Retarget to polygons below if used.
    circles = not options.include_cell_labels
    with warnings.catch_warnings():
        warnings.filterwarnings("error", message=r".*cell_id.*does not match.*")
        warnings.filterwarnings("error", message=r".*Could not parse the version of the Xenium Analyzer.*")
        sdata = xenium(
            source,
            cells_boundaries=options.include_cell_boundaries,
            nucleus_boundaries=options.include_nucleus_boundaries,
            cells_as_circles=circles,
            cells_labels=options.include_cell_labels,
            nucleus_labels=options.include_nucleus_labels,
            transcripts=options.include_transcripts,
            morphology_mip=options.include_morphology and (source / "morphology_mip.ome.tif").is_file(),
            morphology_focus=options.include_morphology,
            aligned_images=False,
            cells_table=True,
            n_jobs=options.n_jobs,
            gex_only=True,
        )
    if "table" not in sdata.tables:
        raise RuntimeError("The Xenium reader returned no cell-expression table.")
    table = sdata.tables.pop("table")
    sdata.tables[TABLE_KEY] = table
    if circles and options.include_cell_boundaries:
        table.obs["region"] = pd.Categorical(["cell_boundaries"] * table.n_obs)
        sdata.set_table_annotates_spatialelement(TABLE_KEY, region="cell_boundaries", region_key="region", instance_key="cell_id")
        sdata.shapes.pop("cell_circles", None)
    cell_ids = _decode_ids(table.obs["cell_id"])
    table.obs["cell_id"] = cell_ids.to_numpy()
    table.obs_names = cell_ids
    table.obs_names.name = "cell_id_index"
    native_columns = [str(c) for c in table.obs.columns]
    if "total_counts" in table.obs:
        table.obs["xenium_total_counts"] = table.obs["total_counts"].copy()
    table.var["feature_name_original"] = table.var_names.astype(str)
    # Keep every feature/count; disambiguate duplicate symbols only as an index.
    table.var_names_make_unique()
    xy = np.asarray(table.obsm["spatial"], dtype=float)
    if xy.shape != (table.n_obs, 2) or not np.isfinite(xy).all():
        raise ValueError("Expected finite x/y cell centroids from cells.parquet.")
    table.obsm["spatial_um"] = xy.copy()
    table.obsm["spatial_global"] = xy / pixel_size
    manifest_fields = (
        "sample_id", "sample_name", "project_id", "batch_id", "run_id", "instrument_id", "slide_id",
        "region_id", "region_name", "run_date", "run_time", "source_dir", "zarr_path",
        "biological_sample_id", "donor_id", "tissue", "condition", "notes",
        "he_image_path", "he_alignment_path", "he_alignment_status",
    )
    provenance = {}
    for field in manifest_fields:
        value = row.get(field, "")
        value = "" if value is None or (isinstance(value, (float, np.floating)) and np.isnan(value)) else str(value)
        provenance[field] = value
        # SpatialData's obs['region'] is deliberately never overwritten.
        if field not in {"source_dir", "zarr_path", "he_image_path", "he_alignment_path"}:
            table.obs[field] = value
    provenance["source_dir"] = str(source)
    provenance["he_alignment_status"] = "pending"  # recording a path never imports/alters an alignment
    table.obs["he_alignment_status"] = "pending"
    packages = {}
    for name in ("spatialdata", "spatialdata-io", "anndata", "numpy", "pandas", "zarr", "tifffile"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = "unknown"
    table.uns["xenium_import"] = {
        "workflow_version": WORKFLOW_VERSION,
        "created_utc": _utc(),
        "sample_id": sample_id,
        "source_dir": str(source),
        "pixel_size_um": pixel_size,
        "analysis_sw_version": str(specs.get("analysis_sw_version", "")),
        "xenium_ranger_version": str((specs.get("xenium_ranger") or {}).get("version", "")),
        "import_options": asdict(options),
        "source_fingerprint_sha256": fingerprint["sha256"],
        "source_fingerprint_json": _json_text(fingerprint),
        "manifest": provenance,
        "package_versions": packages,
        "native_obs_columns": native_columns,
        "counts_location": "X: unnormalized 10x Gene Expression counts; all input cells retained",
        "he_image_imported": False,
        "coordinates": {
            "spatial": "x,y in micrometers (10x cell centroid)",
            "spatial_um": "x,y in micrometers (explicit alias)",
            "spatial_global": "x,y in morphology pixels; micrometers / pixel_size_um",
            "global": "morphology pixels; local to this region, not a cross-region registration",
            "boundary_native_units": "micrometers",
            "label_native_units": "pixels",
        },
    }
    sdata.attrs["xenium_workflow"] = {
        "workflow_version": WORKFLOW_VERSION, "sample_id": sample_id, "table_key": TABLE_KEY,
        "source_dir": str(source), "pixel_size_um": pixel_size,
    }
    assert_table_links(sdata)
    return sdata


def sync_manifest_metadata(sdata: Any, row: Mapping[str, Any]) -> Any:
    """Apply edited biological labels/H&E references without changing identity.

    Updates are in memory until ``save_table_update``. H&E remains unimported;
    an existing image + alignment path is marked ``available_not_imported``.
    The authoritative mutable manifest metadata lives with the cell table.
    """
    assert_table_links(sdata)
    table = sdata.tables[TABLE_KEY]
    metadata = table.uns["xenium_import"]
    recorded = metadata["manifest"]

    def clean(value: Any) -> str:
        if value is None or (isinstance(value, (float, np.floating)) and np.isnan(value)):
            return ""
        return str(value)

    identity_fields = (
        "sample_id", "project_id", "batch_id", "run_id", "instrument_id", "slide_id",
        "region_id", "region_name", "run_date", "run_time", "source_dir",
    )
    for field in identity_fields:
        if field not in row:
            continue
        previous = clean(recorded.get(field, metadata.get(field, "")))
        current = clean(row[field])
        matches = (_local_path(previous) == _local_path(current)) if field == "source_dir" and previous and current else previous == current
        if not matches:
            raise ValueError(f"Manifest identity {field!r} changed ({previous!r} -> {current!r}); re-import under a new sample/output instead.")
    if sdata.path is not None and clean(row.get("zarr_path", "")):
        if _local_path(row["zarr_path"]) != _local_path(sdata.path):
            raise ValueError("Manifest zarr_path does not match the currently opened sample.")
    editable = (
        "sample_name", "biological_sample_id", "donor_id", "tissue", "condition", "notes",
        "he_image_path", "he_alignment_path",
    )
    for field in editable:
        if field in row:
            recorded[field] = clean(row[field])
            if field not in {"he_image_path", "he_alignment_path"}:
                table.obs[field] = recorded[field]
    image_path = clean(recorded.get("he_image_path", ""))
    alignment_path = clean(recorded.get("he_alignment_path", ""))
    available = bool(image_path and alignment_path and Path(image_path).expanduser().is_file() and Path(alignment_path).expanduser().is_file())
    status = "available_not_imported" if available else "pending"
    recorded["he_alignment_status"] = status
    table.obs["he_alignment_status"] = status
    metadata["he_image_imported"] = False
    metadata["manifest_metadata_updated_utc"] = _utc()
    return sdata


def _journal_path(store: Path) -> Path:
    return store.with_name("." + store.name + ".table-update.json")


@contextmanager
def _store_lock(store: Path, *, exclusive: bool):
    """OS-released advisory lock for this workflow's directory I/O."""
    try:
        import fcntl
    except ImportError as exc:
        raise RuntimeError("Recoverable directory writes require POSIX (Linux/macOS) file locks.") from exc
    store.parent.mkdir(parents=True, exist_ok=True)
    lock_path = store.with_name("." + store.name + ".workflow.lock")
    with lock_path.open("a+", encoding="utf-8") as stream:
        try:
            fcntl.flock(stream.fileno(), (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError(f"Another workflow reader/writer currently holds {lock_path}; retry after it finishes.") from exc
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


@contextmanager
def _writer_lock(store: Path):
    with _store_lock(store, exclusive=True):
        yield


def _load_marker(store: Path) -> dict:
    marker = store / COMPLETION_MARKER
    if not marker.is_file():
        raise RuntimeError(f"No completed-import marker found in {store}. Do not treat a partial store as imported.")
    data = json.loads(marker.read_text(encoding="utf-8"))
    if data.get("table_key") != TABLE_KEY or data.get("status") != "complete":
        raise RuntimeError(f"Invalid completed-import marker: {marker}.")
    return data


def read_sample(path: str | Path) -> Any:
    """Read a completed region store; fail if an interrupted swap is pending."""
    import spatialdata as sd

    store = _local_path(path)
    if not store.is_dir():
        raise FileNotFoundError(f"SpatialData directory does not exist: {store}")
    with _store_lock(store, exclusive=False):
        if _journal_path(store).exists():
            raise RuntimeError(
                f"An interrupted table update exists for {store}. After confirming no writer is running, "
                "call recover_table_update(path), then reopen the sample."
            )
        marker = _load_marker(store)
        result = sd.read_zarr(store)
        assert_table_links(result)
        table = result.tables[TABLE_KEY]
        meta = table.uns.get("xenium_import", {})
        if meta.get("sample_id") != marker["sample_id"] or meta.get("source_fingerprint_sha256") != marker["source_fingerprint_sha256"]:
            raise RuntimeError("The stored table provenance does not match the completed-import marker.")
        if (table.n_obs, table.n_vars) != (marker["raw_table"]["n_obs"], marker["raw_table"]["n_vars"]):
            raise RuntimeError("The full cell/gene table shape changed; filtering belongs in exported analysis tables.")
    return result


def write_import(sdata: Any, destination: str | Path) -> Any:
    """Write/validate a fresh sibling store, then rename and reopen it.

    Never overwrites an existing destination. Failure leaves a clearly named
    incomplete ``*.importing-*.zarr`` for diagnosis. Writing realizes selected
    lazy arrays on disk; it can take time and storage even though the reader
    represents images/points lazily.
    """
    import spatialdata as sd

    destination = _local_path(destination)
    assert_table_links(sdata)
    meta = sdata.tables[TABLE_KEY].uns["xenium_import"]
    before = _matrix_signature(sdata.tables[TABLE_KEY])
    with _writer_lock(destination):
        if destination.exists():
            raise FileExistsError(f"Destination already exists; verify/reuse it or choose a new output path: {destination}")
        staging = destination.with_name(destination.name + ".importing-" + uuid4().hex + ".zarr")
        sdata.write(staging, overwrite=False, consolidate_metadata=True)
        reopened = sd.read_zarr(staging)
        assert_table_links(reopened)
        if _matrix_signature(reopened.tables[TABLE_KEY]) != before:
            raise RuntimeError(f"Raw matrix/identity validation failed for staged import {staging}.")
        current_source = source_fingerprint(meta["source_dir"], meta["import_options"])
        if current_source["sha256"] != meta["source_fingerprint_sha256"]:
            raise RuntimeError("An input file changed while importing; staged data were not promoted.")
        marker = {
            "status": "complete", "workflow_version": WORKFLOW_VERSION, "completed_utc": _utc(),
            "table_key": TABLE_KEY, "sample_id": meta["sample_id"], "source_dir": meta["source_dir"],
            "import_options": {k: v.item() if isinstance(v, np.generic) else v for k, v in meta["import_options"].items()},
            "source_fingerprint_sha256": meta["source_fingerprint_sha256"], "raw_table": before,
        }
        _atomic_json(staging / COMPLETION_MARKER, marker)
        del reopened
        os.rename(staging, destination)
    # Essential: Dask arrays from the old object still refer to source/staging.
    return read_sample(destination)


def verify_existing_import(row: Mapping[str, Any], options: ImportOptions | Mapping[str, Any] | None = None) -> dict:
    """Verify a completed sample before an import-loop skip (no mutations)."""
    options = _options(options)
    store = _local_path(row["zarr_path"])
    marker = _load_marker(store)
    if marker["sample_id"] != str(row["sample_id"]) or _local_path(marker["source_dir"]) != _local_path(row["source_dir"]):
        raise RuntimeError(f"Existing output belongs to a different sample/source: {store}")
    if marker["import_options"] != asdict(options):
        raise RuntimeError(f"Import options changed for {store}; use a new output directory to re-import.")
    if source_fingerprint(row["source_dir"], options)["sha256"] != marker["source_fingerprint_sha256"]:
        raise RuntimeError(f"Input size/mtime or experiment metadata changed for {store}; use a new output directory.")
    sdata = read_sample(store)
    del sdata
    return marker


def _read_table(path: Path) -> Any:
    import anndata as ad
    from spatialdata.models import TableModel

    table = ad.read_zarr(path)
    attrs = table.uns.get(TableModel.ATTRS_KEY, {})
    if isinstance(attrs.get("region"), np.ndarray):
        attrs["region"] = attrs["region"].tolist()
    TableModel.validate(table)
    return table


def _consolidate(store: Path) -> None:
    import spatialdata as sd

    handle = sd.SpatialData()
    handle.path = store
    # The public method explicitly opens the store with use_consolidated=False.
    handle.write_consolidated_metadata()


def _rollback_transaction(store: Path, transaction: dict) -> None:
    """Restore original bytes and park partial new bytes outside the store."""
    table_key = transaction["table_key"]
    token = transaction["token"]
    if not re.fullmatch(r"[a-zA-Z0-9_]+", table_key) or not re.fullmatch(r"[0-9a-f]{32}", token):
        raise RuntimeError("Invalid transaction identifiers; no recovery action was taken.")
    if _local_path(transaction["store"]) != store:
        raise RuntimeError("Transaction store mismatch; no recovery action was taken.")
    original = store / "tables" / table_key
    staged = store / "tables" / f"staged_{table_key}_{token}"
    backup_dir = store.with_name(store.name + ".table_backups") / token
    backup = backup_dir / (table_key + ".zarr")
    backup_dir.mkdir(parents=True, exist_ok=True)
    if backup.exists():
        if original.exists():
            os.rename(original, backup_dir / ("uncommitted_new_" + uuid4().hex + ".zarr"))
        os.rename(backup, original)
    elif not original.exists():
        raise RuntimeError(f"Both original table and its recorded backup are missing: {original}")
    if staged.exists():
        os.rename(staged, backup_dir / ("abandoned_stage_" + uuid4().hex + ".zarr"))
    _consolidate(store)
    _read_table(original)
    _journal_path(store).unlink(missing_ok=True)


def recover_table_update(path: str | Path) -> Path:
    """Roll back a pending update after an interrupted process, then reopen.

    A live workflow writer prevents recovery via the OS lock. If a process
    died after installation but before completion, rollback deliberately
    restores the prior table; rerun the shape/QC step to apply the new result.
    No image, label, shape, or transcript arrays are changed.
    """
    store = _local_path(path)
    with _writer_lock(store):
        journal = _journal_path(store)
        if not journal.exists():
            raise FileNotFoundError(f"There is no pending table-update journal for {store}.")
        transaction = json.loads(journal.read_text(encoding="utf-8"))
        _rollback_transaction(store, transaction)
    reopened = read_sample(store)
    del reopened
    return store


def save_table_update(sdata: Any, table_key: str = TABLE_KEY) -> Path:
    """Stage/validate a table update, retain the old table, and swap locally.

    Returns the backup table directory. All raw count values, cells and genes
    must remain unchanged from the original import. Only annotations are
    persisted. Call this after adding morphology/QC metrics and flags, then
    discard/reopen the object before another notebook stage.
    """
    if table_key != TABLE_KEY:
        raise ValueError(f"This workflow updates only the original table {TABLE_KEY!r}.")
    if sdata.path is None:
        raise ValueError("Write the initial SpatialData import before updating its table.")
    store = _local_path(sdata.path)
    assert_table_links(sdata, table_key)
    marker = _load_marker(store)
    signature = _matrix_signature(sdata.tables[table_key])
    if signature != marker["raw_table"]:
        raise ValueError("Raw counts, cell IDs, or feature IDs changed. Preserve the vanilla table; export a filtered copy instead.")
    token = uuid4().hex
    stage_key = f"staged_{table_key}_{token}"
    original = store / "tables" / table_key
    staged = store / "tables" / stage_key
    backup_dir = store.with_name(store.name + ".table_backups") / token
    backup = backup_dir / (table_key + ".zarr")
    journal = _journal_path(store)
    transaction = {"store": str(store), "table_key": table_key, "token": token, "started_utc": _utc(), "state": "preparing"}
    with _writer_lock(store):
        if journal.exists():
            raise RuntimeError(f"A previous table update is pending; call recover_table_update({str(store)!r}) first.")
        if not original.is_dir():
            raise FileNotFoundError(f"Original table group is missing: {original}")
        backup_dir.mkdir(parents=True, exist_ok=False)
        _atomic_json(journal, transaction)
        try:
            sdata.tables[stage_key] = sdata.tables[table_key]
            sdata.write_element(stage_key)
            staged_table = _read_table(staged)
            if _matrix_signature(staged_table) != signature:
                raise RuntimeError("Staged table failed raw matrix/identity round-trip validation.")
            del staged_table
            transaction["state"] = "staged"
            _atomic_json(journal, transaction)
            os.rename(original, backup)
            transaction["state"] = "backed_up"
            _atomic_json(journal, transaction)
            os.rename(staged, original)
            transaction["state"] = "installed"
            _atomic_json(journal, transaction)
            del sdata.tables[stage_key]
            _consolidate(store)
            check = _read_table(original)
            if _matrix_signature(check) != signature:
                raise RuntimeError("Installed table failed raw matrix/identity validation.")
            del check
            _atomic_json(backup_dir / "backup_info.json", {**transaction, "completed_utc": _utc(), "backup_table": str(backup)})
            journal.unlink()
        except BaseException as exc:
            sdata.tables.pop(stage_key, None)
            try:
                _rollback_transaction(store, transaction)
            except BaseException as recovery_error:
                raise RuntimeError(
                    f"Table update failed and rollback could not finish. Keep the journal/backups; "
                    f"recover_table_update({str(store)!r}) is required. Rollback error: {recovery_error}"
                ) from exc
            raise RuntimeError("Table update failed; the previous on-disk table was restored. Reopen the sample before retrying.") from exc
    reopened = read_sample(store)
    del reopened
    return backup


def export_h5ad(
    adata: Any,
    destination: str | Path,
    *,
    qc_pass_only: bool = False,
    prefix_obs_names: bool = True,
    overwrite: bool = False,
) -> Path:
    """Write a standalone raw-count analysis table through a staged H5AD.

    Filter cells only when explicitly requested. Native cell IDs remain in
    ``obs['cell_id']``. By default exported observation names are
    ``sample_id::cell_id`` so concatenating regions does not collide. The
    SpatialData table and spatial elements are untouched.
    """
    import anndata as ad

    destination = _local_path(destination)
    if destination.exists() and not overwrite:
        raise FileExistsError(f"H5AD export already exists: {destination}")
    if qc_pass_only:
        if "qc_pass" not in adata.obs:
            raise KeyError("QC must be evaluated before exporting cells with qc_pass_only=True.")
        flags = adata.obs["qc_pass"]
        if not pd.api.types.is_bool_dtype(flags) or flags.isna().any():
            raise ValueError("qc_pass must contain complete boolean flags.")
        export = adata[flags.to_numpy()].copy()
    else:
        export = adata.copy()
    if prefix_obs_names:
        if "sample_id" not in export.obs or "cell_id" not in export.obs:
            raise KeyError("sample_id and cell_id are required to build globally unique export IDs.")
        export.obs_names = pd.Index(export.obs["sample_id"].astype(str) + "::" + export.obs["cell_id"].astype(str))
        export.obs_names.name = "sample_cell_id"
        if not export.obs_names.is_unique:
            raise ValueError("Sample-prefixed cell IDs are not unique.")
    export.uns["xenium_export"] = {
        "created_utc": _utc(), "qc_pass_only": qc_pass_only,
        "counts": "X contains unnormalized Gene Expression counts",
        "obs_names_prefixed": prefix_obs_names,
        "source_table_key": TABLE_KEY,
    }
    if "spatialdata_attrs" in export.uns:
        # This standalone file carries provenance, not a live annotation link
        # to spatial elements that are absent from the H5AD.
        export.uns["source_spatialdata_attrs"] = export.uns.pop("spatialdata_attrs")
    before = _matrix_signature(export)
    destination.parent.mkdir(parents=True, exist_ok=True)
    staged = destination.with_name(destination.stem + ".writing-" + uuid4().hex + ".h5ad")
    export.write_h5ad(staged, compression="gzip")
    check = ad.read_h5ad(staged)
    if _matrix_signature(check) != before:
        raise RuntimeError(f"H5AD export failed matrix/identity verification: {staged}")
    del check, export
    if destination.exists() and not overwrite:
        raise FileExistsError(f"Destination appeared while exporting; staged export retained at {staged}.")
    os.replace(staged, destination)
    return destination
