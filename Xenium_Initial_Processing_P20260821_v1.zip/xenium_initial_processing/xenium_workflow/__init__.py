"""Initial processing of independent Xenium regions using SpatialData."""

__version__ = "1.0.0"

