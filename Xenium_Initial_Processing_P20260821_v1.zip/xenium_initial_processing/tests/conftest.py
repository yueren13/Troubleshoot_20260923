"""Tiny generated fixtures; no real biological data or external downloads."""
from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd
import pytest
from anndata import AnnData
from scipy.sparse import csr_matrix

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _synthetic_xenium import create_batch
from xenium_workflow.config import WorkflowConfig
from xenium_workflow.manifest import discover_samples, save_manifest


@pytest.fixture(scope='session')
def synthetic_batch(tmp_path_factory):
    base = tmp_path_factory.mktemp('synthetic_xenium')
    batch = create_batch(base)
    expectations = json.loads((base/'fixture_expected.json').read_text())
    return batch, expectations


@pytest.fixture
def workflow_config(synthetic_batch, tmp_path):
    batch, _ = synthetic_batch
    cfg = WorkflowConfig(batch_root=str(batch), output_root=str(tmp_path/'processed'))
    cfg.prepare()
    save_manifest(discover_samples(cfg), cfg.manifest_path)
    return cfg


@pytest.fixture
def raw_adata(synthetic_batch):
    _, expected = synthetic_batch
    info = expected[0]
    metadata = pd.read_parquet(Path(info['path'])/'cells.parquet')
    adata = AnnData(csr_matrix(np.asarray(info['counts_genes'], dtype=np.float32)),
                    obs=metadata.set_index('cell_id', drop=False),
                    var=pd.DataFrame(index=['GENE_A','GENE_B','GENE_C']))
    adata.obs['xenium_total_counts'] = adata.obs['total_counts'].copy()
    adata.obsm['spatial'] = np.asarray(info['centers_um'],dtype=float)
    return adata
