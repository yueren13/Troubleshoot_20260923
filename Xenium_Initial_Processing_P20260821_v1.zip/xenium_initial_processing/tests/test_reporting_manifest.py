"""Regression checks for metadata refresh, compressed exports, and concatenation."""
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from xenium_workflow.manifest import atomic_csv, discover_samples, read_manifest, save_manifest, validate_manifest
from xenium_workflow.reporting import concatenate_same_panel


def test_manifest_refresh_preserves_custom_metadata_and_he_override(workflow_config, tmp_path):
    frame = read_manifest(workflow_config.manifest_path)
    custom_he = tmp_path / "verified_source.ome.tif"
    custom_he.write_bytes(b"reference only")
    frame["custom_specimen_note"] = ""
    frame.loc[0, "custom_specimen_note"] = "keep this annotation"
    frame.loc[0, "he_image_path"] = str(custom_he)
    save_manifest(frame, workflow_config.manifest_path, preserve_edits=False)
    refreshed = save_manifest(discover_samples(workflow_config), workflow_config.manifest_path)
    assert refreshed.loc[0, "custom_specimen_note"] == "keep this annotation"
    assert refreshed.loc[0, "he_image_path"] == str(custom_he)
    assert refreshed.loc[0, "he_file_status"] == "found"


def test_manifest_rejects_changed_run_or_technical_sample_id(workflow_config):
    frame = read_manifest(workflow_config.manifest_path)
    broken = frame.copy()
    broken.loc[0, "run_id"] = "Xenium_run_wrong"
    with pytest.raises(ValueError, match="run_id"):
        validate_manifest(broken)
    broken = frame.copy()
    broken.loc[0, "sample_id"] = "renamed_biological_specimen"
    with pytest.raises(ValueError, match="sample_id"):
        validate_manifest(broken)


def test_atomic_csv_honors_gzip_target_suffix(tmp_path):
    path = tmp_path / "metadata.csv.gz"
    before = pd.DataFrame({"slide_id": ["0117690"], "value": [3]})
    atomic_csv(before, path)
    assert path.read_bytes()[:2] == b"\x1f\x8b"
    after = pd.read_csv(path, dtype={"slide_id": str})
    pd.testing.assert_frame_equal(before, after)


def test_same_panel_concat_prefixes_ids_and_rejects_feature_identity_mismatch(raw_adata):
    a = raw_adata.copy()
    b = raw_adata[:, ::-1].copy()
    a.obs["sample_id"] = "sample_a"
    b.obs["sample_id"] = "sample_b"
    gene_ids = {name: f"id_{name}" for name in a.var_names}
    a.var["gene_ids"] = [gene_ids[n] for n in a.var_names]
    b.var["gene_ids"] = [gene_ids[n] for n in b.var_names]
    a.uns["spatialdata_attrs"] = {"region": "cell_labels"}
    b.uns["spatialdata_attrs"] = {"region": "cell_labels"}
    before = a.X.copy()
    joined = concatenate_same_panel({"sample_a": a, "sample_b": b})
    assert joined.n_obs == a.n_obs + b.n_obs
    assert joined.obs_names.is_unique
    assert all(i.startswith("sample_a::") for i in joined.obs_names[:a.n_obs])
    assert all(i.startswith("sample_b::") for i in joined.obs_names[a.n_obs:])
    assert "spatialdata_attrs" not in joined.uns
    assert (a.X != before).nnz == 0
    assert "spatialdata_attrs" in a.uns
    b.var.loc[b.var.index[0], "gene_ids"] = "wrong_id"
    with pytest.raises(ValueError, match="Feature-ID mismatch"):
        concatenate_same_panel({"sample_a": a, "sample_b": b})
