"""Recovery contracts on local temporary storage, including injected failures."""
from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import pytest

from xenium_workflow import io
from xenium_workflow.manifest import read_manifest


@pytest.fixture
def backed_region(workflow_config):
    """Reuse the real-format 10x fixture, importing only its small cell objects."""
    row = read_manifest(workflow_config.manifest_path).iloc[0].to_dict()
    options = io.ImportOptions(
        include_transcripts=False,
        include_cell_labels=False,
        include_nucleus_labels=False,
        include_cell_boundaries=False,
        include_nucleus_boundaries=False,
        include_morphology=False,
    )
    data = io.import_sample(row, options)
    return io.write_import(data, row["zarr_path"])


def test_modified_raw_counts_cannot_replace_original(backed_region):
    store = Path(backed_region.path)
    original = backed_region.tables[io.TABLE_KEY].X.copy()
    backed_region.tables[io.TABLE_KEY].X.data[0] += 1
    with pytest.raises(ValueError, match="Raw counts"):
        io.save_table_update(backed_region)
    reopened = io.read_sample(store)
    assert (reopened.tables[io.TABLE_KEY].X != original).nnz == 0
    assert not io._journal_path(store).exists()


def test_install_failure_restores_previous_table(backed_region, monkeypatch):
    """Fail after the old table moved to backup, before the new one installs."""
    store = Path(backed_region.path)
    backed_region.tables[io.TABLE_KEY].obs["must_not_commit"] = "new value"
    rename = io.os.rename
    failed = False

    def fail_one_install(source, destination):
        nonlocal failed
        if Path(source).name.startswith("staged_") and Path(destination).name == io.TABLE_KEY and not failed:
            failed = True
            raise OSError("injected table install failure")
        return rename(source, destination)

    monkeypatch.setattr(io.os, "rename", fail_one_install)
    with pytest.raises(RuntimeError, match="previous on-disk table was restored"):
        io.save_table_update(backed_region)
    assert failed
    reopened = io.read_sample(store)
    assert "must_not_commit" not in reopened.tables[io.TABLE_KEY].obs
    assert not io._journal_path(store).exists()
    assert not any(name.startswith("staged_") for name in reopened.tables)


@pytest.mark.parametrize("new_table_installed", [False, True])
def test_pending_transaction_blocks_reads_and_explicitly_rolls_back(backed_region, new_table_installed):
    """Create the two on-disk interruption states without killing a process."""
    store = Path(backed_region.path)
    token = uuid4().hex
    stage_key = f"staged_{io.TABLE_KEY}_{token}"
    staged = backed_region.tables[io.TABLE_KEY].copy()
    staged.obs["must_not_commit"] = "new value"
    backed_region.tables[stage_key] = staged
    backed_region.write_element(stage_key)
    backup_dir = store.with_name(store.name + ".table_backups") / token
    backup_dir.mkdir(parents=True)
    original_path = store / "tables" / io.TABLE_KEY
    io.os.rename(original_path, backup_dir / (io.TABLE_KEY + ".zarr"))
    if new_table_installed:
        io.os.rename(store / "tables" / stage_key, original_path)
    transaction = {
        "store": str(store), "table_key": io.TABLE_KEY, "token": token,
        "state": "installed" if new_table_installed else "backed_up",
    }
    io._atomic_json(io._journal_path(store), transaction)
    with pytest.raises(RuntimeError, match="interrupted table update"):
        io.read_sample(store)
    io.recover_table_update(store)
    reopened = io.read_sample(store)
    assert "must_not_commit" not in reopened.tables[io.TABLE_KEY].obs
    assert not io._journal_path(store).exists()
    assert not any(name.startswith("staged_") for name in reopened.tables)


def test_reader_cannot_race_cooperative_table_writer(backed_region):
    store = Path(backed_region.path)
    with io._writer_lock(store):
        with pytest.raises(RuntimeError, match="currently holds"):
            io.read_sample(store)
    assert io.read_sample(store).tables[io.TABLE_KEY].shape == backed_region.tables[io.TABLE_KEY].shape
