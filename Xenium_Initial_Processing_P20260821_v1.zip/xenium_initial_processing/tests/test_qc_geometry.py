"""Independent analytic checks for polygon moments and advisory QC flags."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from anndata import AnnData
from scipy.sparse import csr_matrix
from shapely import affinity
from shapely.geometry import MultiPolygon, Polygon, box

from xenium_workflow.morphology import measure_polygon_morphology
from xenium_workflow.qc import annotate_qc


def _measure(geometry, *, scale=1.0):
    frame = pd.DataFrame({"geometry": [geometry]}, index=["cell-a"])
    return measure_polygon_morphology(frame, coordinate_scale_um=scale).iloc[0]


@pytest.mark.parametrize("reverse_ring", [False, True])
def test_rectangle_axes_are_invariant_to_orientation_rotation_and_translation(reverse_ring):
    """A uniform rectangle has coordinate variances width²/12 and height²/12."""
    width, height = 6.0, 2.0
    rectangle = box(-width / 2, -height / 2, width / 2, height / 2)
    if reverse_ring:
        rectangle = Polygon(list(rectangle.exterior.coords)[::-1])
    rectangle = affinity.rotate(rectangle, 37.0, origin=(0, 0))
    rectangle = affinity.translate(rectangle, xoff=1e8, yoff=-1e8)
    scale = 2.5
    measured = _measure(rectangle, scale=scale)

    assert measured.polygon_area_um2 == pytest.approx(width * height * scale**2, rel=1e-7)
    assert measured.polygon_perimeter_um == pytest.approx(2 * (width + height) * scale, rel=1e-7)
    assert measured.polygon_major_axis_length_um == pytest.approx(4 * np.sqrt(width**2 / 12) * scale, rel=1e-7)
    assert measured.polygon_minor_axis_length_um == pytest.approx(4 * np.sqrt(height**2 / 12) * scale, rel=1e-7)
    assert measured.polygon_elongation == pytest.approx(1 - height / width, rel=1e-7)
    assert measured.polygon_eccentricity == pytest.approx(np.sqrt(1 - height**2 / width**2), rel=1e-7)
    assert measured.polygon_moments_valid


def test_off_center_hole_subtracts_area_and_correctly_recenters_moments():
    """Check axes against rectangle-minus-rectangle area integrals, not a raster."""
    outer = box(-4, -2, 4, 2)  # area 32, centroid (0, 0)
    hole = box(0, -.5, 2, .5)  # area 2, centroid (1, 0)
    geometry = Polygon(outer.exterior.coords, holes=[hole.exterior.coords])
    measured = _measure(geometry)

    total_area = 32 - 2
    expected_x = (32 * 0 - 2 * 1) / total_area
    variance_x = (32 * (8**2 / 12) - 2 * (2**2 / 12 + 1**2)) / total_area - expected_x**2
    variance_y = (32 * (4**2 / 12) - 2 * (1**2 / 12)) / total_area
    assert measured.polygon_area_um2 == pytest.approx(total_area)
    assert measured.polygon_centroid_x_um == pytest.approx(expected_x)
    assert measured.polygon_centroid_y_um == pytest.approx(0, abs=1e-12)
    assert measured.polygon_major_axis_length_um == pytest.approx(4 * np.sqrt(variance_x))
    assert measured.polygon_minor_axis_length_um == pytest.approx(4 * np.sqrt(variance_y))
    assert measured.polygon_eccentricity == pytest.approx(np.sqrt(1 - variance_y / variance_x))
    assert measured.polygon_perimeter_um == pytest.approx(24 + 6)


def test_multipolygon_axes_include_the_distance_between_components():
    """Two unit squares have within-square variance 1/12 plus centroid variance."""
    geometry = MultiPolygon([box(-.5, -.5, .5, .5), box(3.5, -.5, 4.5, .5)])
    measured = _measure(geometry)

    variance_x, variance_y = 1 / 12 + 2**2, 1 / 12
    assert measured.polygon_area_um2 == pytest.approx(2)
    assert measured.polygon_centroid_x_um == pytest.approx(2)
    assert measured.polygon_major_axis_length_um == pytest.approx(4 * np.sqrt(variance_x))
    assert measured.polygon_minor_axis_length_um == pytest.approx(4 * np.sqrt(variance_y))
    assert measured.polygon_elongation == pytest.approx(6 / 7)
    assert measured.polygon_eccentricity == pytest.approx(np.sqrt(48 / 49))
    assert measured.polygon_valid_geometry and measured.polygon_moments_valid


def test_area_and_density_outliers_do_not_become_automatic_cell_failures():
    """Exercise the fitted diagnostics; the four-cell integration fixture cannot."""
    counts = np.full(100, 20, dtype=np.int64)
    counts[96] = 10_000
    areas = np.full(100, 20.0)
    areas[97:] = [200, 300, 1000]
    obs = pd.DataFrame({
        "transcript_counts": counts,
        "total_counts": counts,
        "xenium_total_counts": counts,
        "cell_area": areas,
    }, index=[f"cell-{i}" for i in range(len(counts))])
    adata = AnnData(csr_matrix(counts[:, None]), obs=obs)
    original = adata.X.copy()
    annotate_qc(adata)

    assert adata.obs.seg_qc_evaluated.all()
    assert adata.obs.is_big.iloc[97:].all()
    assert adata.obs.is_dense.iloc[96]
    assert adata.obs.seg_qc.eq("suspect").any()
    assert adata.obs.qc_pass.all()
    assert adata.obs.qc_complete.all()
    assert adata.n_obs == 100 and (adata.X != original).nnz == 0
