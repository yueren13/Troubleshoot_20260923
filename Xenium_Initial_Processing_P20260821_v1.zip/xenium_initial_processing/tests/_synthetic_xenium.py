"""Build tiny synthetic XOA 3.0 output, deliberately with nonlexical cell order."""
from __future__ import annotations
import json
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZIP_DEFLATED
from pathlib import Path
import h5py
import numpy as np
import pandas as pd
import scipy.sparse as sp
import tifffile
import zarr


def _cell_id(prefix: int) -> str:
    return ''.join(chr(ord('a')+int(ch,16)) for ch in f'{prefix:08x}')+'-1'


def create_region(path: Path, *, pixel_size: float = 0.5) -> dict:
    n_cells = 4
    path.mkdir(parents=True, exist_ok=True)
    prefixes=np.array([8,1,6,3],dtype=np.uint32)[:n_cells]
    ids=np.array([_cell_id(int(x)) for x in prefixes])
    centers=np.array([[7,7],[23,7],[7,23],[23,23]],dtype=float)[:n_cells]
    widths=np.array([4,6,8,10],dtype=float)[:n_cells]
    counts=np.array([[20,4,0,2],[0,0,0,1],[6,18,9,3],[9,10,11,0]],dtype=np.int32)[:n_cells]
    csr=sp.csr_matrix(counts)
    with h5py.File(path/'cell_feature_matrix.h5','w') as handle:
        matrix=handle.create_group('matrix')
        for name, arr in {'data':csr.data,'indices':csr.indices,'indptr':csr.indptr,
                          'shape':np.array([csr.shape[1],csr.shape[0]],dtype=np.int64),
                          'barcodes':ids.astype('S')}.items():
            matrix.create_dataset(name,data=arr)
        features=matrix.create_group('features')
        for name,arr in {'name':['GENE_A','GENE_B','GENE_C','NegControlProbe_A'],
                         'id':['idA','idB','idC','negA'],
                         'feature_type':['Gene Expression']*3+['Negative Control Probe'],
                         'genome':['GRCh38']*4}.items():
            features.create_dataset(name,data=np.array(arr,dtype='S'))
    metadata=pd.DataFrame({'cell_id':ids,'x_centroid':centers[:,0],'y_centroid':centers[:,1],
                           'transcript_counts':counts[:,:3].sum(axis=1),
                           'control_probe_counts':counts[:,3],
                           'control_codeword_counts':np.array([1,0,0,0])[:n_cells],
                           'unassigned_codeword_counts':np.array([0,0,2,0])[:n_cells],
                           'deprecated_codeword_counts':np.zeros(n_cells,dtype=int),
                           'total_counts':counts.sum(axis=1)+np.array([1,0,2,0])[:n_cells],
                           'cell_area':widths**2,'nucleus_area':(widths/2)**2})
    metadata.to_parquet(path/'cells.parquet',index=False)
    for kind,factor in [('cell',1),('nucleus',0.5)]:
        boundaries=[]
        # Input rows are reversed. Grouped polygons sort lexically, unlike matrix cells.
        for cell_id,center,width in reversed(list(zip(ids,centers,widths))):
            half=width*factor/2
            x,y=center
            for vx,vy in [(x-half,y-half),(x+half,y-half),(x+half,y+half),(x-half,y+half),(x-half,y-half)]:
                boundaries.append({'cell_id':cell_id,'vertex_x':vx,'vertex_y':vy})
        pd.DataFrame(boundaries).to_parquet(path/f'{kind}_boundaries.parquet',index=False)
    shape=(64,64)
    cell_mask=np.zeros(shape,dtype=np.uint32)
    nucleus_mask=np.zeros(shape,dtype=np.uint32)
    for i,(center,width) in enumerate(zip(centers,widths),start=1):
        cx,cy=(center/pixel_size).astype(int)
        half=int(width/pixel_size/2)
        cell_mask[cy-half:cy+half,cx-half:cx+half]=i
        nh=half//2
        nucleus_mask[cy-nh:cy+nh,cx-nh:cx+nh]=i
    with TemporaryDirectory() as zarr_temp:
        zarr_path=Path(zarr_temp)/'cells.zarr'
        group=zarr.open_group(zarr_path,mode='w',zarr_format=2)
        group.create_array('cell_id',data=np.column_stack([prefixes,np.ones(n_cells,dtype=np.uint32)]))
        group.create_array('cell_summary',data=np.column_stack([np.zeros(n_cells),np.ones(n_cells)]))
        group['cell_summary'].attrs['column_names']=['z_level','nucleus_count']
        masks=group.create_group('masks')
        masks.create_array('0',data=nucleus_mask,chunks=(32,32))
        masks.create_array('1',data=cell_mask,chunks=(32,32))
        group.create_group('polygon_sets').create_group('1').create_array('cell_index',data=np.arange(n_cells,dtype=np.uint32))
        with ZipFile(path/'cells.zarr.zip','w',compression=ZIP_DEFLATED) as archive:
            for source in sorted(zarr_path.rglob('*')):
                if source.is_file():
                    archive.write(source,source.relative_to(zarr_path))
    transcript_df=pd.DataFrame({'transcript_id':np.arange(6,dtype=np.uint64),
                              'cell_id':[ids[0],ids[0],ids[1],ids[2],ids[3],'UNASSIGNED'],
                              'feature_name':['GENE_A','NegControlProbe_A','GENE_A','GENE_B','GENE_C','GENE_A'],
                              'x_location':[7.0,7.5,23.0,7.0,23.0,30.0],
                              'y_location':[7.0,7.5,7.0,23.0,23.0,30.0],
                              'z_location':[0.0]*6,'qv':[30.0,30.0,10.0,35.0,25.0,40.0],
                              'overlaps_nucleus':[1,1,0,1,1,0]})
    transcript_df.to_parquet(path/'transcripts.parquet',index=False)
    (path/'experiment.xenium').write_text(json.dumps({'analysis_sw_version':'xenium-3.0.0','pixel_size':pixel_size,'experiment_name':'synthetic validation fixture'}))
    image=np.arange(64*64,dtype=np.uint16).reshape(shape)
    (path/'morphology_focus').mkdir(exist_ok=True)
    tifffile.imwrite(path/'morphology_focus'/'morphology_focus_0000.ome.tif',image,ome=True,metadata={'axes':'YX'})
    return {'path':str(path),'cell_ids':ids.tolist(),'counts_genes':counts[:,:3].tolist(),'counts_all':counts.tolist(),'pixel_size':pixel_size,'centers_um':centers.tolist(),'areas_um2':(widths**2).tolist(),'polygon_cell_order':sorted(ids.tolist()),'native_total_counts':metadata.total_counts.tolist()}


def create_batch(root: Path):
    batch=root/'P-20260821-0003'/'Batch1_20261010'
    runs=[('Xenium_run_01',['0117167','0117194'],'20260904__234830'),
          ('Xenium_run_02',['0117690','0117734'],'20260928__230929'),
          ('Xenium_run_03',['0117170','0117181'],'20261005__214900')]
    expected=[]
    for run,slides,timestamp in runs:
        for slide in slides:
            for region in [1,2]:
                p=batch/run/f'output-XETG00318__{slide}__Region_{region}__{timestamp}'
                expected.append(create_region(p))
    he_dir=batch/'post_Xenium_HE_images'/'ome_tiff'
    he_dir.mkdir(parents=True,exist_ok=True)
    for _,slides,_ in runs:
        for slide in slides:
            tifffile.imwrite(he_dir/f'BMS_{slide}.ome.tif',np.zeros((64,64,3),dtype=np.uint8),photometric='rgb',ome=True,metadata={'axes':'YXS'})
    (batch/'CA001-050_batch1_Xenium_Project_Report_10_09_2026.pdf').write_bytes(b'%PDF-1.4 synthetic placeholder, never imported\n')
    (batch/'post_Xenium_HE_images'/'tiff').mkdir(exist_ok=True)
    (root/'fixture_expected.json').write_text(json.dumps(expected,indent=2))
    return batch


