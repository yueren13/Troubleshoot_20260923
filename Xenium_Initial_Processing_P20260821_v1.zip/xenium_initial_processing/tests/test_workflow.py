"""End-to-end contracts tested on a small, real-format synthetic Xenium batch.

Run from this folder's parent with ``uv run pytest -q tests`` in the supplied
project environment. Fixtures are generated in pytest's temporary directory.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd
import pytest
from scipy import sparse

from xenium_workflow.config import WorkflowConfig
from xenium_workflow.manifest import (
    discover_samples, manifest_summary, parse_output_name, preflight_inputs,
    read_manifest, save_manifest, selected_samples, validate_manifest,
)
from xenium_workflow.qc import QCThresholds, annotate_qc, qc_report


def test_manifest_preserves_slide_ids_and_shared_he(workflow_config):
    frame = read_manifest(workflow_config.manifest_path)
    assert len(frame) == 12
    assert frame.sample_id.is_unique
    assert frame.slide_id.str.startswith('0').all()
    assert set(frame.run_id) == {'Xenium_run_01','Xenium_run_02','Xenium_run_03'}
    slide = frame[frame.slide_id.eq('0117690')]
    assert len(slide) == 2
    assert set(slide.region_name) == {'Region_1','Region_2'}
    assert slide.he_image_path.nunique() == 1
    assert Path(slide.he_image_path.iloc[0]).name == 'BMS_0117690.ome.tif'
    assert frame.he_alignment_status.eq('pending').all()
    assert set(manifest_summary(frame).n_regions) == {2}
    assert preflight_inputs(frame, workflow_config.import_options).ready.all()
    assert all(Path(p).is_dir() for p in frame.source_dir)
    assert not frame.source_dir.str.contains('post_Xenium|Project_Report').any()


def test_manifest_roundtrip_preserves_edits_and_detects_bad_ids(workflow_config):
    frame = read_manifest(workflow_config.manifest_path)
    frame.loc[0,'donor_id'] = 'D001'
    frame.loc[0,'include'] = 'false'
    save_manifest(frame, workflow_config.manifest_path, preserve_edits=False)
    refreshed = save_manifest(discover_samples(workflow_config), workflow_config.manifest_path)
    assert refreshed.loc[0,'donor_id'] == 'D001'
    assert refreshed.loc[0,'include'] == 'false'
    assert len(selected_samples(workflow_config)) == 11
    broken = refreshed.copy()
    broken.loc[0,'slide_id'] = str(int(broken.loc[0,'slide_id']))
    with pytest.raises(ValueError, match='leading zeros|disagrees'):
        validate_manifest(broken)
    with pytest.raises(ValueError):
        parse_output_name('CA001-050_batch1_Xenium_Project_Report_10_09_2026.pdf')


def test_qc_minimal_preserves_raw_counts_totals_and_rows(raw_adata):
    a = raw_adata
    before = a.X.copy()
    vendor_totals = a.obs.total_counts.copy()
    cell_ids = a.obs.cell_id.copy()
    summary = annotate_qc(a, percent_top=(1,2,10))
    assert summary['n_cells'] == 4
    assert summary['n_qc_pass'] == 3
    assert a.obs.qc_pass.tolist() == [True,False,True,True]
    assert (a.X != before).nnz == 0
    pd.testing.assert_series_equal(a.obs.total_counts,vendor_totals)
    pd.testing.assert_series_equal(a.obs.cell_id,cell_ids)
    np.testing.assert_array_equal(a.obs.total_counts_gene_expression,[24,0,33,30])
    np.testing.assert_array_equal(a.obs.n_genes_by_counts,[2,0,3,3])
    assert 'pct_counts_in_top_10_genes' not in a.obs
    assert np.isnan(a.obs.pct_counts_in_top_1_genes.iloc[1])
    assert a.obs.frac_negP.iloc[0] == pytest.approx(2/27)
    assert a.obs.qc_complete.all()


def test_historical_qc_missing_control_is_recorded(raw_adata):
    a = raw_adata
    with pytest.warns(UserWarning, match='max_genomic_control_fraction'):
        annotate_qc(a, thresholds=QCThresholds.from_preset('historical'))
    assert a.obs.qc_pass.tolist() == [False,False,False,True]
    assert not a.obs.qc_complete.any()
    assert a.obs.frac_genomic.isna().all()
    assert a.obs.qc_not_evaluated.str.contains('max_genomic_control_fraction').all()
    genomic = qc_report(a).set_index('rule').loc['max_genomic_control_fraction']
    assert genomic.n_evaluated == 0
    assert genomic.n_not_evaluated == 4
    assert genomic.n_failed == 0
    # Re-running with minimal policy clears obsolete control-rule failures.
    annotate_qc(a, thresholds='minimal')
    assert a.obs.qc_complete.all()
    assert 'qc_fail_max_control_probe_fraction' not in a.obs


def test_zero_total_invalid_fraction_and_unknown_optional(raw_adata):
    a = raw_adata
    a.obs.loc[a.obs.index[0],'xenium_total_counts'] = 0
    a.obs.loc[a.obs.index[2],'control_probe_counts'] = np.nan
    threshold=QCThresholds(min_real_fraction=.7,max_control_probe_fraction=.05)
    with pytest.warns(UserWarning,match='max_control_probe_fraction'):
        annotate_qc(a, thresholds=threshold)
    assert np.isnan(a.obs.frac_real.iloc[0])
    assert not a.obs.qc_pass.iloc[0]
    assert a.obs.qc_fail_min_real_fraction.iloc[0]
    assert not a.obs.qc_complete.iloc[2]
    assert not a.obs.qc_evaluated_max_control_probe_fraction.iloc[2]
    assert not a.obs.qc_fail_max_control_probe_fraction.iloc[2]


def test_qc_rejects_normalized_matrix(raw_adata):
    a = raw_adata
    a.X = a.X.astype(float)
    a.X.data[0] = .5
    with pytest.raises(ValueError,match='raw integer-like'):
        annotate_qc(a)


def _spatial_bytes(store: Path) -> dict[str,str]:
    return {str(path.relative_to(store)):hashlib.sha256(path.read_bytes()).hexdigest()
            for element in ('images','labels','shapes','points')
            for path in (store/element).rglob('*') if path.is_file()}


def test_true_10x_import_coordinates_ids_and_table_persistence(workflow_config, synthetic_batch):
    from spatialdata.models import get_table_keys
    from spatialdata.transformations import get_transformation
    from xenium_workflow.io import (
        TABLE_KEY, assert_table_links, import_sample, read_sample, save_table_update,
        verify_existing_import, write_import,
    )
    row = read_manifest(workflow_config.manifest_path).iloc[0].to_dict()
    expected = synthetic_batch[1][0]
    sdata = import_sample(row, workflow_config.import_options)
    assert set(sdata.tables) == {'xenium_vanilla_cell'}
    assert set(sdata.images) == {'morphology_focus'}
    assert set(sdata.labels) == {'cell_labels','nucleus_labels'}
    assert set(sdata.shapes) == {'cell_boundaries','nucleus_boundaries'}
    assert set(sdata.points) == {'transcripts'}
    table = sdata.tables[TABLE_KEY]
    np.testing.assert_array_equal(table.X.toarray(),expected['counts_genes'])
    assert table.obs_names.tolist() == expected['cell_ids']
    assert table.obs.cell_id.tolist() == expected['cell_ids']
    assert table.n_vars == 3  # negative-control matrix feature is not a gene
    np.testing.assert_array_equal(table.obs.total_counts, expected['native_total_counts'])
    np.testing.assert_array_equal(table.obs.xenium_total_counts, table.obs.total_counts)
    np.testing.assert_array_equal(table.obsm['spatial_um'], expected['centers_um'])
    np.testing.assert_array_equal(table.obsm['spatial_global'], np.asarray(expected['centers_um'])/.5)
    np.testing.assert_array_equal(table.obs.cell_labels,[1,2,3,4])
    region,region_key,instance_key = get_table_keys(table)
    assert (region,region_key,instance_key) == ('cell_labels','region','cell_labels')
    # Native polygon positions are micrometers; their global scale is 2 pixels/um.
    scale=get_transformation(sdata.shapes['cell_boundaries']).to_affine_matrix(('x','y'),('x','y'))
    np.testing.assert_array_equal(scale,np.diag([2.,2.,1.]))
    assert sdata.shapes['cell_boundaries'].index.tolist() == expected['polygon_cell_order']
    assert sdata.shapes['cell_boundaries'].index.tolist() != expected['cell_ids']
    points=sdata.points['transcripts'].compute()
    assert len(points) == 6
    assert points.qv.min() == 10  # transcript points are not silently filtered
    assert 'UNASSIGNED' in points.cell_id.values
    assert table.uns['xenium_import']['he_image_imported'] is False
    assert table.obs.slide_id.eq('0117167').all()
    assert_table_links(sdata)
    store=Path(row['zarr_path'])
    backed=write_import(sdata,store)
    spatial_before=_spatial_bytes(store)
    assert spatial_before
    before_x=backed.tables[TABLE_KEY].X.copy()
    annotate_qc(backed.tables[TABLE_KEY], thresholds='minimal')
    backup=save_table_update(backed)
    assert backup.is_dir()
    assert spatial_before == _spatial_bytes(store)
    reopened=read_sample(store)
    assert (reopened.tables[TABLE_KEY].X!=before_x).nnz == 0
    assert reopened.tables[TABLE_KEY].obs.qc_pass.tolist() == [True,False,True,True]
    assert reopened.points['transcripts'].shape[0].compute() == 6
    assert_table_links(reopened)
    marker=verify_existing_import(row,workflow_config.import_options)
    assert marker['status'] == 'complete'
    with pytest.raises(FileExistsError):
        write_import(reopened,store)


@pytest.mark.parametrize('boundaries,target',[(True,'cell_boundaries'),(False,'cell_circles')])
def test_lightweight_import_keeps_valid_table_target(workflow_config,boundaries,target):
    from spatialdata.models import get_table_keys
    from xenium_workflow.io import TABLE_KEY, ImportOptions, assert_table_links, import_sample
    row=read_manifest(workflow_config.manifest_path).iloc[0].to_dict()
    options=ImportOptions(include_transcripts=False,include_morphology=False,
                          include_cell_labels=False,include_nucleus_labels=False,
                          include_cell_boundaries=boundaries,include_nucleus_boundaries=False)
    sdata=import_sample(row,options)
    assert not sdata.images and not sdata.labels and not sdata.points
    assert set(sdata.shapes) == {target}
    region,_,instance_key=get_table_keys(sdata.tables[TABLE_KEY])
    assert (region,instance_key) == (target,'cell_id')
    assert_table_links(sdata)


def test_morphology_joins_native_cell_ids_and_uses_micrometers(workflow_config):
    from xenium_workflow.io import ImportOptions, import_sample
    from xenium_workflow.morphology import annotate_morphology

    row = read_manifest(workflow_config.manifest_path).iloc[0]
    data = import_sample(row, options=ImportOptions(
        include_transcripts=False, include_cell_labels=True,
        include_nucleus_labels=False, include_cell_boundaries=True,
        include_nucleus_boundaries=True, include_morphology=False,
    ))
    table = data.tables['xenium_vanilla_cell']
    native_order = table.obs.cell_id.tolist()
    assert native_order != data.shapes['cell_boundaries'].index.tolist()
    original_counts = table.X.copy()
    original_areas = table.obs.cell_area.copy()
    original_geometry = data.shapes['cell_boundaries'].geometry.to_wkb().copy()
    measured = annotate_morphology(data, coordinate_scale_um=1.0)
    assert measured.index.tolist() == native_order
    np.testing.assert_allclose(table.obs.polygon_area_um2, [16,36,64,100])
    np.testing.assert_allclose(table.obs.polygon_perimeter_um, [16,24,32,40])
    np.testing.assert_allclose(table.obs.polygon_centroid_x_um, [7,23,7,23])
    np.testing.assert_allclose(table.obs.polygon_major_axis_length_um, np.array([4,6,8,10])*4/np.sqrt(12))
    np.testing.assert_allclose(table.obs.polygon_eccentricity, 0, atol=1e-7)
    np.testing.assert_allclose(table.obs.polygon_to_vendor_cell_area_ratio, 1)
    annotate_morphology(data, shape_key='nucleus_boundaries', prefix='nucleus_polygon_')
    np.testing.assert_allclose(table.obs.nucleus_polygon_area_um2, [4,9,16,25])
    assert (table.X != original_counts).nnz == 0
    pd.testing.assert_series_equal(table.obs.cell_area, original_areas)
    pd.testing.assert_series_equal(data.shapes['cell_boundaries'].geometry.to_wkb(), original_geometry)


def test_morphology_handles_holes_invalid_geometry_and_unmatched_ids(raw_adata):
    import geopandas as gpd
    from shapely.geometry import Polygon, box
    from spatialdata import SpatialData
    from spatialdata.models import ShapesModel
    from xenium_workflow.morphology import annotate_morphology, measure_polygon_morphology

    hole = Polygon([(0,0),(4,0),(4,4),(0,4)], holes=[[(1,1),(3,1),(3,3),(1,3)]])
    invalid = Polygon([(0,0),(2,2),(0,2),(2,0),(0,0)])
    shapes = gpd.GeoDataFrame(geometry=[hole, invalid, box(0,0,1,1)],
                             index=raw_adata.obs_names[[2,0,1]])
    with pytest.warns(UserWarning, match='could not be measured'):
        metrics = measure_polygon_morphology(shapes, coordinate_scale_um=2.0)
    assert metrics.polygon_area_um2.iloc[0] == pytest.approx(48)
    assert metrics.polygon_perimeter_um.iloc[0] == pytest.approx(48)
    assert not metrics.polygon_valid_geometry.iloc[1]
    assert np.isnan(metrics.polygon_area_um2.iloc[1])
    data = SpatialData(shapes={'cell_boundaries': ShapesModel.parse(shapes)},
                       tables={'xenium_vanilla_cell': raw_adata})
    with pytest.warns(UserWarning, match='could not be measured'):
        with pytest.raises(ValueError, match='no matching ID'):
            annotate_morphology(data, strict=True)
    assert 'polygon_area_um2' not in raw_adata.obs
    with pytest.warns(UserWarning):
        annotate_morphology(data, strict=False)
    assert len(raw_adata) == 4
    assert raw_adata.obs.polygon_present.tolist() == [True,True,True,False]
    assert raw_adata.obs.polygon_geometry_status.iloc[3] == 'missing_shape'
    assert np.isnan(raw_adata.obs.polygon_area_um2.iloc[3])


def test_preview_uses_named_channel_and_transforms_micrometer_roi(workflow_config, tmp_path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from xenium_workflow.io import ImportOptions, import_sample
    from xenium_workflow.plotting import preview_spatialdata

    row = read_manifest(workflow_config.manifest_path).iloc[0]
    data = import_sample(row, options=ImportOptions(
        include_transcripts=False, include_morphology=True,
        include_cell_labels=True, include_nucleus_labels=False,
        include_cell_boundaries=False, include_nucleus_boundaries=False,
    ))
    destination = tmp_path / 'roi_preview.png'
    figure = preview_spatialdata(data, destination, channel=0, roi_um=(5,5,9,9), dpi=50)
    assert destination.stat().st_size > 1000
    assert 'DAPI' in figure.axes[0].get_title()
    # Native micrometres / 0.5 um-per-pixel = reader-global pixel coordinates.
    for axis in figure.axes[:2]:
        np.testing.assert_allclose(axis.get_xlim(), (10,18))
        np.testing.assert_allclose(axis.get_ylim(), (18,10))
    plt.close(figure)
