"""Read-only diagnosis of a bin-metadata/master observation-ID mismatch.

No repair, ID conversion, worker launch, controller save, or scientific write.
Requires the existing Project Center and its installed pandas/pyarrow/h5py/
AnnData/Zarr. Reads observation IDs, small receipts and source text, not X.
"""
from __future__ import annotations

import gc
import hashlib
import inspect
import json
from pathlib import Path
import traceback
from datetime import datetime, timezone


def _center(pc):
    if pc is not None:
        if not callable(getattr(pc, 'snapshot', None)):
            raise TypeError('Pass the existing ProjectCenter instance.')
        return pc
    found = {id(x): x for x in gc.get_objects()
             if type(x).__name__ == 'ProjectCenter'
             and type(x).__module__ == 'vhd.center.controller'}
    if len(found) != 1:
        raise RuntimeError(f'Found {len(found)} existing Centers; pass the intended pc. No Center opened.')
    return next(iter(found.values()))


def _stat(path):
    p = Path(path)
    if not p.exists():
        return {'exists': False}
    s = p.stat()
    return {'exists': True, 'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns,
            'is_dir': p.is_dir()}


def _json_file(path, limit=2*1024**2):
    p = Path(path)
    result = {'path': str(p), **_stat(p)}
    if not p.is_file():
        return result
    if p.stat().st_size > limit:
        result['not_read'] = 'Exceeds small-record size limit.'
        return result
    before = _stat(p)
    data = p.read_bytes()
    if _stat(p) != before:
        raise RuntimeError(f'Record changed during read: {p}')
    result['sha256'] = hashlib.sha256(data).hexdigest()
    try:
        result['content'] = json.loads(data)
    except (ValueError, UnicodeError) as exc:
        result['parse_error'] = str(exc)
    return result


def _summarize(index):
    import pandas as pd
    import numpy as np
    if isinstance(index, pd.MultiIndex):
        raise ValueError('Unexpected MultiIndex; no flattening or ID conversion attempted.')
    duplicate = index.duplicated(keep=False)
    positions = np.flatnonzero(duplicate)[:6]
    return {
        'n_rows': len(index), 'index_class': type(index).__name__,
        'dtype': str(index.dtype), 'name': repr(index.name),
        'is_unique': bool(index.is_unique),
        'null_count': int(index.isna().sum()),
        'rows_in_duplicate_groups': int(duplicate.sum()),
        'duplicate_examples_repr': [repr(index[int(i)]) for i in positions],
        'first_ids_repr': [repr(x) for x in index[:6]],
        'last_ids_repr': [repr(x) for x in index[-3:]],
        'first_id_python_types': [type(x).__name__ for x in index[:6]],
    }


def compare_indices(left, right, *, left_name, right_name, chunk_size=250_000):
    """Compare without forcing types/prefixes or changing either index.

    Full membership comparison uses pandas' index lookup in bounded query blocks.
    Exact uniqueness/population match is required; order differences are separate.
    """
    import numpy as np
    result = {'left': left_name, 'right': right_name,
              'same_length': len(left) == len(right),
              'same_order': bool(left.equals(right)),
              'left_unique': bool(left.is_unique), 'right_unique': bool(right.is_unique)}
    if not left.is_unique or not right.is_unique:
        result.update(same_unique_id_set=False,
                      finding='Duplicate IDs; population match not evaluated.')
        return result
    if left.hasnans or right.hasnans:
        result.update(same_unique_id_set=None,
                      finding='Null IDs; no repair or null-string conversion attempted.')
        return result
    def missing(query, reference):
        count, examples = 0, []
        for start in range(0, len(query), chunk_size):
            block = query[start:start+chunk_size]
            miss = reference.get_indexer(block) < 0
            count += int(miss.sum())
            for pos in np.flatnonzero(miss)[:max(0, 6-len(examples))]:
                examples.append(repr(block[int(pos)]))
        return count, examples
    left_only, le = missing(left, right)
    right_only, re = missing(right, left)
    result.update(left_only_count=left_only, right_only_count=right_only,
                  left_only_examples_repr=le, right_only_examples_repr=re,
                  shared_id_count=len(left)-left_only,
                  same_unique_id_set=(left_only == 0 and right_only == 0))
    result['finding'] = (
        'IDs and order agree.' if result['same_order'] else
        'Same IDs; order differs only. The native aligned() permits reordering.'
        if result['same_unique_id_set'] else
        'Different ID populations or representations; do not join by row position.')
    return result


def _parquet_index(path):
    import pyarrow.parquet as pq
    import pandas as pd
    p = Path(path); before = _stat(p)
    with p.open('rb') as handle:
        pf = pq.ParquetFile(handle)
        n = pf.metadata.num_rows
        metadata = pf.schema_arrow.metadata or {}
        pandas_info = json.loads(metadata.get(b'pandas', b'{}'))
        index_info = pandas_info.get('index_columns', [])
        # Metadata-backed RangeIndex can be recreated without any column read.
        if len(index_info) == 1 and isinstance(index_info[0], dict):
            r = index_info[0]
            if r.get('kind') != 'range':
                raise ValueError(f'Unsupported Parquet index metadata: {r}')
            idx = pd.RangeIndex(r['start'], r['stop'], r['step'], name=r.get('name'))
        elif not index_info:
            idx = pd.RangeIndex(n)
        else:
            if not all(isinstance(k, str) for k in index_info):
                raise ValueError('Unsupported mixed Parquet index metadata.')
            # Arrow adds only the persisted index fields to the empty projection.
            frame = pf.read(columns=[], use_threads=False,
                            use_pandas_metadata=True).to_pandas()
            if len(frame.columns):
                raise RuntimeError('Unexpected non-index columns returned; stop without loading all obs.')
            idx = frame.index
        if len(idx) != n:
            raise RuntimeError(f'Parquet index length {len(idx)} differs from footer rows {n}.')
        details = {'pandas_index_metadata': index_info,
                   'n_parquet_columns': len(pf.schema_arrow.names), 'rows_from_footer': n,
                   'no_persisted_index': not bool(index_info)}
    if _stat(p) != before:
        raise RuntimeError(f'Parquet file changed during inspection: {p}')
    return idx, details


def _encoded_index(obs):
    import pandas as pd
    from anndata.io import read_elem
    key = obs.attrs.get('_index')
    if isinstance(key, bytes):
        key = key.decode('utf-8')
    if not isinstance(key, str) or key not in obs:
        raise ValueError('Missing/invalid AnnData obs _index attribute; no column guessing.')
    idx = pd.Index(read_elem(obs[key]))
    return idx, {'stored_index_key': key}


def _h5_index(path):
    import h5py
    p = Path(path); before = _stat(p)
    with h5py.File(p, 'r') as handle:
        idx, info = _encoded_index(handle['obs'])
    if _stat(p) != before:
        raise RuntimeError(f'H5AD changed during inspection: {p}')
    return idx, info


def _zarr_index(store):
    import zarr
    # Match persistence.spatial.open_group: explicitly bypass consolidated metadata.
    obs = zarr.open_group(str(Path(store)/'tables'/'bins_2um'/'obs'),
                          mode='r', use_consolidated=False)
    return _encoded_index(obs)


def inspect_bin_ids(controller=None, *, sample='Navli-82', confirmed_no_writers=False):
    """Inspect current on-disk IDs. Caller must verify no writer is using this sample.

    Returns JSON-serializable evidence; caller can save it to a NEW diagnostic file.
    Reads all IDs, which may use several GB on a multi-million-bin sample, but no
    count/image arrays. Local guards do not establish inactivity on another host.
    """
    if confirmed_no_writers is not True:
        raise PermissionError('Wait for the failed run to return; verify no other writer, then explicitly confirm.')
    pc = _center(controller)
    from vhd.control.manifest import sample_layout
    state = pc.snapshot(); key = pc.key(sample); row = pc.row(key, state['project'])
    layout = sample_layout(state['project'], row)
    work, reports, store = (Path(layout[k]) for k in ('work', 'report', 'store'))
    jobs = state.get('jobs', {}).get(key, {})
    running = [a for a, j in jobs.items() if j.get('status') == 'running']
    if running:
        raise RuntimeError(f'Jobs recorded running: {running}. Inspect them; do not launch a duplicate.')
    locks = list(work.glob('.worker_*.lock'))
    writer_lock = Path(str(store)+'.vhd_writer.lock')
    if writer_lock.exists():
        locks.append(writer_lock)
    if locks:
        raise RuntimeError('Existing locks need inspection; none removed: '+str([str(p) for p in locks]))
    journal_root = Path(str(store)+'.vhd_transactions')
    journal_states = []
    for journal in sorted(journal_root.glob('*/journal.json')):
        item = _json_file(journal)
        value = item.get('content', {}).get('state')
        journal_states.append({'path':str(journal), 'state':value})
        if value not in ('committed', 'rolled_back'):
            raise RuntimeError(f'Unresolved/unreadable transaction {journal}. No recovery requested.')
    report = {'schema':'vhd-bin-id-diagnostic-1',
              'sample':key, 'checked_at_utc':datetime.now(timezone.utc).isoformat(),
              'workspace':str(pc.workspace), 'revision_at_start':state.get('revision'),
              'paths':{k:str(v) for k,v in layout.items()},
              'current_input_paths':{k:row.get(k) for k in
                  ('spaceranger_outs','bin_input','bin_table','master_store','work_dir','tmp_dir')},
              'jobs':jobs, 'review_assets':state.get('reviews',{}).get(key,{}).get('review_assets'),
              'transaction_states':journal_states, 'indices':{}, 'comparisons':[], 'errors':[],
              'scientific_arrays_read':False, 'scientific_files_written':False,
              'id_values_changed':False, 'patch_applied':False, 'worker_launched':False}
    try:
        from vhd.annotations.workflow import read_assets, active_assets
        assets = read_assets(row.get('assets_manifest'),row['dataset_id'],row['sample_id'])
        report['active_external_sources'] = [a['asset_id'] for a in active_assets(assets)]
        report['choice_rows'] = pc.choices(key)
    except Exception as exc:
        report['active_source_inspection_error'] = f'{type(exc).__name__}: {exc}'
    for name in ('master_sources.json','storage_manifest.json','assets_transfer.json','status_transfer_assets.json'):
        report.setdefault('receipts',{})[name] = _json_file(reports/name)
    for name in ('01_ingest_complete.json','02_qc_complete.json'):
        report.setdefault('receipts',{})[name] = _json_file(work/name)
    # Small source excerpts identify the implementation actually used by this kernel.
    try:
        import vhd.annotations.workflow as workflow
        import vhd.persistence.spatial as persistence
        import vhd.master as master
        for fun in (workflow.transfer_assets, persistence.aligned,
                    persistence.update_table_metadata, master.assemble_master):
            text=inspect.getsource(fun)
            report.setdefault('native_sources',{})[fun.__module__+'.'+fun.__name__] = {
                'file':inspect.getsourcefile(fun), 'sha256':hashlib.sha256(text.encode()).hexdigest(),
                'source':text}
    except Exception as exc:
        report['native_source_inspection_error'] = f'{type(exc).__name__}: {exc}'
    try:
        import zarr
        root=zarr.open_group(str(store),mode='r',use_consolidated=False)
        attrs=dict(root.attrs)
        report['master_identity_attributes']={k:attrs.get(k) for k in
            ('sample','dataset_id','vhd_version','source_signature','coordinate_system')}
    except Exception as exc:
        report['master_attribute_error']=f'{type(exc).__name__}: {exc}'
    reference = None
    def load(name, path, reader):
        item={'path':str(path), 'stat':_stat(path)}
        try:
            if not Path(path).exists():
                raise FileNotFoundError(path)
            print(f'Reading observation IDs only: {name} | {path}', flush=True)
            index, detail=reader(path)
            item.update(_summarize(index), **detail)
            report['indices'][name]=item
            return index
        except Exception as exc:
            item['error']=f'{type(exc).__name__}: {exc}'
            report['indices'][name]=item
            report['errors'].append({'stage':name, 'traceback':traceback.format_exc()})
            return None
    reference=load('qc_obs',work/'bins_qc_obs.parquet',_parquet_index)
    for name,path,reader in (
        ('master_bins_2um',store,_zarr_index),
        ('prepared_bins_h5ad',work/'bins_raw.h5ad',_h5_index),
        ('existing_transfer_sidecar',work/'bins_annotated_obs.parquet',_parquet_index),
    ):
        if name=='existing_transfer_sidecar' and not path.exists():
            report['indices'][name]={'path':str(path),'stat':{'exists':False},'optional':True}
            continue
        index=load(name,path,reader)
        if reference is not None and index is not None:
            comparison=compare_indices(reference,index,left_name='qc_obs',right_name=name)
            report['comparisons'].append(comparison)
            print(json.dumps(comparison,indent=2), flush=True)
        del index
        gc.collect()
    del reference
    gc.collect()
    final=pc.snapshot()
    report['controller_revision_unchanged'] = final.get('revision')==state.get('revision')
    report['limitations']=[
        'Current on-disk inspection, not a snapshot of the failed worker in memory.',
        'ID equality alone does not establish matching counts, geometry, or scientific provenance.',
        'No automatic prefix/type normalization, positional joining, or data repair.',
        'Requires exclusive absence of writers confirmed by the user, including other hosts.',
        'Reads all relevant IDs; memory use grows with bin count. No expression arrays are read.'
    ]
    print('\nID summaries:')
    print(json.dumps(report['indices'],indent=2,default=str))
    print('\nRead-only diagnosis finished. No patch, metadata update, or worker launch.')
    return report
