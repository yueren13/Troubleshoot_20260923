> **Legacy v4 file-level interface.** For a single file containing mixed-use
> categories and names discovered at runtime, use ASSETS_V41_DISCOVERY.md instead.
> v4.1 adds footprint summaries; the legacy center-sampling descriptions below
> apply only when those methods are explicitly chosen.

# Annotation and signal contract

## Purpose is explicit

| `role` | Stored/previewed | Bin metadata | May drive prior QC | May transfer to cells |
|---|---|---|---|---|
| `segmentation_qc` | Yes | After approval | Only explicitly named Boolean columns | Only requested `cell_methods` |
| `analysis` | Yes | After approval | **No** | Requested methods |
| `both` | Yes | After approval | Explicit configured Boolean columns | Requested methods |
| `reference_only` | Yes when parseable; otherwise source/error provenance | **No** | **No** | **No**; `cell_methods` must be blank |

`enabled=false` skips import altogether. To keep an unreliable layer inside the master, use **enabled=true + role=reference_only**, not enabled=false. Its tentative transform is for visual inspection, not proof of registration. A malformed/unavailable reference file is recorded as `reference_unparsed`; no polygon is fabricated. Persistence/transaction errors are never swallowed as harmless reference failures.

Legacy aliases: `exclusion` → `segmentation_qc`; `biological` and `signal` → `analysis`. They no longer imply automatic consumption. Changing a layer from active to reference-only changes the active-transfer signature; retransfer before downstream segmentation/metadata refresh. Previously source-owned bin columns are removed and the transfer specification is replaced. If a prior setting still names that layer, the code stops rather than silently continuing. Do not remove an asset manifest from a workspace that still contains derived annotations; retain an explicit manifest and retransfer after disabling/changing sources. Already-created segmentation cannot be retroactively corrected without an explicit new segmentation run.

## `.annotations` files

The parser accepts **ImageScope-style XML content** under `.annotations`, `.annotation` or `.xml`, including namespaces and `V`/`Vertex` vertex tags. It preserves negative-region holes and multipart polygons. Unsupported XML roots, degenerate vertices and invalid polygons fail clearly for active sources. File extension alone does not establish the schema. An actual file from the new pilot has not been inspected for this release.

Set `format=imagescope_xml`, `kind=polygons`, `category_column=name` for that schema. List exact categories separated by semicolons. `membership` retains independent Boolean memberships (Tissue and Necrosis may overlap); `categorical` produces an explicit mixed label for overlapping categories. Unknown coverage remains separate from an assessed negative.

`coverage_mode=exhaustive` asserts that absence of a supplied region means negative throughout the selected bin domain. Use it only for comprehensively reviewed annotations. `positive_only` leaves regions outside all annotations unassessed. `polygon` uses a separate declared coverage polygon, transformed from the same source frame. The example Tissue/Anthropotic/Necrosis labels preserve the earlier supplied spelling; replace them with the exact strings in the actual file.

## Registered binary TIFF at 1:9

The example row uses:

```text
kind                 signal
format               tiff
axes                 yx
signal_type          binary
positive_value       255
negative_value       0
nodata_value         [blank]
bin_method           center_nearest
cell_methods         mean;sum;median
role                 analysis
source_to_fullres    9;0;0;0;9;0
```

The transform means **x_fullres=9*x_signal; y_fullres=9*y_signal** for array-index pixel centers. It applies when one signal pixel corresponds to nine full-resolution pixels along each axis, with the stated origins. It is NOT evidence that the user's image has zero offsets, matching orientation or this exact scale direction. If the signal is nine times larger, the scale is 1/9 instead. Cropped, rotated or translated images require the complete affine. For a downsampling convention that maps each coarse pixel center to the center of a 9×9 source block, an offset of 4 source pixels may be appropriate; do not add it without knowing how registration was generated.

The six coefficients are `a;b;c;d;e;f`, with x'=a*x+b*y+c and y'=d*x+e*y+f. They are **not Shapely's ordering**. Intrinsic raster-coordinate offsets used by SpatialData are accounted for separately.

The raw TIFF values are preserved in the stored image. The measurement adapter converts only the declared positive/negative codes to 1/0 and validates all native pixels tile-wise. Use positive_value=1 for a 0/1 mask. A 0/255 mask is not blindly treated as a continuous intensity. Binary data use nearest-center sampling; linear interpolation is rejected. Explicit NoData must differ from positive and negative codes. Floating NaNs and out-of-bounds samples remain invalid, never measured zeros.

For cell summaries: the mean is the fraction of **valid sampled bin centers** that are positive; the sum is the number of positive sampled centers; the median summarizes those 0/1 values. These are not physical-area integrals or independent molecule counts. Sampling several bins within one coarse signal pixel does not add independent imaging resolution. `n_valid_bins` and coverage are retained. The complete source image remains at native resolution; it is not expanded into a nine-times-larger raster.

## Preview and persistence

02A imports layers and plots H&E, sources, the capture grid and optional named ROIs. Source/transform signatures must be approved before active transfer. Reference-only changes do not alter the scientific transfer signature. A registry is stored at master attrs `vhd_assets` and in `reports/assets_preview.json`; `approval_at_import` is a snapshot, not the current CSV's live approval status.

02B assigns only the actual table bins by validated IDs/order. It does not overwrite RNA X. Native source layers are kept; derived bin metadata may be restricted to the capture footprint. Real cell polygons are required for geometric bin-to-cell summaries; centroid display glyphs cannot stand in for boundaries. Agreement, majority ties, total contributing bins and annotation coverage remain distinct measures.
