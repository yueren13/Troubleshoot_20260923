# Visual report only. This does not run import_assets or write a master.
from pathlib import Path
import runpy

viewer = runpy.run_path(str(Path(ROOT) / "tools" / "preview_assets_on_he.py"))
review = viewer["preview_assets_on_he"](
    PROJECT,
    sample_keys=["BM0164135A_s1_A1"],
    max_side=2000,
    signal_alpha=0.85,                 # Higher = less transparent; 1.0 is opaque.
    signal_zero_transparent=True,       # Only exact zeros hidden, in DISPLAY only.
    show=True,
)
display(review)
