#!/usr/bin/env python3
"""Coordinate-only diagnostics; no expression or image pixel arrays are read."""
from pathlib import Path
import argparse
import json
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--settings', type=Path)
    parser.add_argument('--samples', nargs='+')
    parser.add_argument('--write-reports', action='store_true', help='Write small JSON diagnostics in configured report folders.')
    args=parser.parse_args()
    root=args.root.expanduser().resolve()
    sys.path.insert(0,str(root))
    from vhd.control.manifest import load_project
    from vhd.grid_diagnostics import diagnose_project, report_summary
    project=load_project(args.manifest or root/'config'/'samples.csv', args.settings or root/'config'/'settings.json')
    reports=diagnose_project(project,args.samples,write_reports=args.write_reports)
    print(report_summary(reports).to_string(index=False))
    print(json.dumps(reports,indent=2,allow_nan=False))
    return 0 if reports and all(r.get('status')=='passed' for r in reports.values()) else 2


if __name__=='__main__':
    raise SystemExit(main())
