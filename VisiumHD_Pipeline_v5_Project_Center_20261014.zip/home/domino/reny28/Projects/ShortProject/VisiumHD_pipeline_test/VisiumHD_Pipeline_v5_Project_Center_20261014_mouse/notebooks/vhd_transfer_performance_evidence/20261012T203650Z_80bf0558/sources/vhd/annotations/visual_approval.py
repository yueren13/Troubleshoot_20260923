"""Connect an explicitly selected Visual-First gallery to choice approval and import.

Preview is read-only. Execution updates small configuration/approval files after
explicit confirmation; it never creates a fictitious 'stored' import receipt.
The regular transfer then performs any missing REAL source import before .obs writes.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
import os
import re
import stat
import tempfile
import uuid
from pathlib import Path
from datetime import datetime, timezone

import numpy as np

PATCH = 'visual-first-approval-bridge-20261007-v1'
VIEWERS = {'visual-first-assets-on-he-20261002-v1',
           'visual-first-assets-on-he-20261005-opacity-v2'}


def _sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _sha_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024**2), b''):
            h.update(b)
    return h.hexdigest()


def _stamp(path):
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(p)
    s = p.stat()
    return {'path': str(p.resolve()), 'size_bytes': s.st_size, 'mtime_ns': s.st_mtime_ns}


def _same_stamp(recorded, path, label):
    now = _stamp(path)
    if (not recorded or Path(recorded.get('path', '')).resolve() != Path(now['path'])
            or recorded.get('size_bytes') != now['size_bytes']
            or recorded.get('mtime_ns') != now['mtime_ns']):
        raise RuntimeError(f'{label} differs from the Visual-First gallery. Regenerate that gallery; do not copy old signatures.')
    return now


def _read_csv(path):
    path = Path(path)
    if path.is_symlink():
        raise ValueError(f'Refuse to edit symlinked configuration: {path}')
    data = path.read_bytes()
    reader = csv.DictReader(io.StringIO(data.decode('utf-8-sig'), newline=''))
    fields = reader.fieldnames
    if not fields or len(set(fields)) != len(fields):
        raise ValueError(f'Invalid CSV headers: {path}')
    rows = list(reader)
    if any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError(f'Malformed CSV row: {path}')
    return data, fields, rows


def _csv_bytes(fields, rows):
    text = io.StringIO(newline='')
    w = csv.DictWriter(text, fieldnames=fields)
    w.writeheader(); w.writerows(rows)
    return text.getvalue().encode('utf-8')


def _file_update(updates, path):
    path = Path(path).resolve()
    if path not in updates:
        old, fields, rows = _read_csv(path)
        updates[path] = {'old': old, 'fields': fields, 'rows': rows}
    return updates[path]


def _atomic_bytes(path, content):
    path = Path(path)
    if path.is_symlink():
        raise ValueError(f'Symlinked output: {path}')
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = stat.S_IMODE(path.stat().st_mode) if path.exists() else 0o644
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, 'wb') as f:
            f.write(content); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def _canonical_map(project, mapping):
    from ..control.manifest import resolve_sample_keys
    out = {}
    for alias, value in (mapping or {}).items():
        key = resolve_sample_keys(project, [alias])[0]
        if key in out:
            raise ValueError(f'Same sample specified twice: {key}')
        out[key] = value
    return out


def list_visual_reviews(project, sample_keys=None):
    """List saved galleries only; never choose or approve the newest automatically."""
    from ..control.manifest import resolve_sample_keys, sample_layout
    import pandas as pd
    keys = set(resolve_sample_keys(project, sample_keys))
    records = []
    for row in project['rows']:
        if row['sample_key'] not in keys:
            continue
        for f in sorted(Path(sample_layout(project, row)['report']).glob('assets_on_he_*/summary.json'), reverse=True):
            try:
                s = json.loads(f.read_text())
                records.append({'sample_key': row['sample_key'], 'summary': str(f),
                                'gallery': str(f.parent/'index.html'), 'status': s.get('status'),
                                'viewer': s.get('version'),
                                'sources': ';'.join(x.get('asset_id', '') for x in s.get('sources', []))})
            except (OSError, ValueError) as exc:
                records.append({'sample_key': row['sample_key'], 'summary': str(f),
                                'status': 'unreadable: ' + str(exc)})
    return pd.DataFrame(records)


def _evidence(summary_path, sample_key):
    f = Path(summary_path).expanduser().resolve()
    summary = json.loads(f.read_text())
    if summary.get('version') not in VIEWERS or summary.get('sample_key') != sample_key:
        raise ValueError('Choose this sample\'s Visual-First summary.json, not the XML repair review_summary.json.')
    if summary.get('status') not in ('report_complete_unapproved', 'report_with_source_errors'):
        raise ValueError('Visual-First report failed; a failed report is not approval evidence.')
    if summary.get('purpose') != 'visual review only, not an import/transfer receipt':
        raise ValueError('Unsupported visual-review schema.')
    images = summary.get('images', [])
    if not images:
        raise ValueError('Visual report contains no completed images.')
    gallery = f.parent/'index.html'
    if not gallery.is_file():
        raise FileNotFoundError(f'Missing reviewed gallery: {gallery}')
    evidence = [{'path': str(f), 'sha256': _sha_file(f)},
                {'path': str(gallery), 'sha256': _sha_file(gallery)}]
    for image in images:
        rel = Path(image['file'])
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('Unsafe preview filename in summary.')
        image_path = f.parent/rel
        if image_path.is_symlink() or not image_path.resolve().is_relative_to(f.parent):
            raise ValueError('Preview file escapes its gallery directory.')
        evidence.append({'path': str(image_path), 'sha256': _sha_file(image_path)})
    return summary, evidence


def _verify_view(summary, asset, geometry, selected_categories):
    from ..core import affine
    matches = [r for r in summary['sources'] if r['asset_id'] == asset['asset_id']]
    if len(matches) != 1:
        raise ValueError(f"Source {asset['asset_id']} was not shown exactly once in this gallery.")
    shown = matches[0]
    if shown.get('kind') != asset['kind'] or Path(shown['path']).resolve() != Path(asset['path']).resolve():
        raise ValueError('The gallery depicts another source path or kind; regenerate it.')
    if shown.get('status') not in ('shown', 'shown_with_encoding_warning'):
        raise ValueError(f"{asset['asset_id']} was not shown as usable geometry/signal: {shown.get('status')}. Raw unrepaired outlines cannot be approved as filled polygons.")
    _same_stamp(shown.get('source_stamp'), asset['path'], 'Annotation/signal source')
    _same_stamp(summary.get('reference_stamp'), geometry['image']['path'], 'H&E reference')
    ref = summary.get('reference_image', {})
    if any(ref.get(k) != geometry['image'].get(k) for k in ('width', 'height')):
        raise ValueError('H&E reference dimensions changed.')
    current = affine(geometry.get('tenx_to_image', np.eye(3))) @ affine(asset['source_to_fullres'])
    previous = np.asarray(shown.get('source_to_display_reference'), float)
    if previous.shape != (3, 3) or not np.allclose(current, previous, rtol=1e-12, atol=1e-7):
        raise ValueError('The current source-to-H&E transform differs from the displayed transform. Regenerate the gallery.')
    # Older Visual-First galleries do not show/hash coverage polygons separately.
    if asset.get('coverage_path'):
        raise ValueError('This gallery version has no reviewed coverage-polygon evidence. Use the original stored-preview route for coverage_path sources.')
    if asset['kind'] == 'polygons':
        info = shown.get('geometry_info', {})
        if info.get('geometry_status') != 'parsed':
            raise ValueError('Only fully parsed, reviewed polygon derivatives can be approved.')
        observed = {x['name'] for x in info.get('categories', [])}
        if not set(selected_categories) <= observed:
            raise ValueError('A selected category was not shown in this gallery.')
    else:
        ps = shown.get('pixel_summary', {})
        if (ps.get('declared_axes') != asset['axes'] or ps.get('channel') != asset['channel']
                or ps.get('scan') != 'all pixels in selected native plane'):
            raise ValueError('Signal channel/axes/full-plane scan evidence does not match.')
        if int(ps.get('n_measured_valid', 0)) < 1:
            raise ValueError('No valid measured signal pixels were reported.')
    return shown


def _signal_summary_check(shown, asset):
    """Preview from recorded all-pixel inventory. Execute also validates native pixels."""
    if asset['kind'] != 'signal':
        return
    ps = shown['pixel_summary']
    if asset.get('signal_type') == 'continuous':
        return
    pos, neg = asset['positive_value'], asset['negative_value']
    if ps.get('unique_values_complete'):
        bad = [x['value'] for x in ps['unique_values_and_counts'] if x['value'] not in (pos, neg)]
        if bad:
            raise ValueError(f"Binary declaration does not fit displayed native values, examples {bad[:8]}. For a numerical stain choose signal_interpretations={{sample: {{'{asset['asset_id']}': 'native'}}}} to preserve native values, or explicitly choose binary_01/binary_0255 only for a genuine two-code mask. No thresholding is applied.")
    elif not (ps.get('binary_encoding_status') == 'matches_declared_codes'
              and ps.get('declared_positive') == pos and ps.get('declared_negative') == neg):
        raise ValueError('Recorded signal scan does not establish this binary encoding. Choose an explicit interpretation; no automatic binarization.')


def _prospective_signal(asset, mode):
    new = copy.deepcopy(asset)
    if mode in (None, 'as_configured'):
        return new, {}
    if asset['kind'] != 'signal':
        raise ValueError('Signal interpretation was supplied for a polygon source.')
    if mode == 'native':
        # A declaration change, NOT a change to any TIFF pixel or measurement scale.
        new.update(signal_type='continuous', positive_value='', negative_value='')
    elif mode in ('binary_01', 'binary_0255'):
        new.update(signal_type='binary', positive_value=1. if mode == 'binary_01' else 255., negative_value=0.)
    else:
        raise ValueError('Signal interpretation: as_configured, native, binary_01 or binary_0255.')
    change = {k: {'old': asset.get(k), 'new': new[k]}
              for k in ('signal_type', 'positive_value', 'negative_value') if asset.get(k) != new[k]}
    return new, change


def _receipt_path(report_dir, asset_id):
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', asset_id):
        raise ValueError('Unsafe asset ID.')
    return Path(report_dir)/f'asset_{asset_id}_visual_approval.json'


def approve_visual_choices(project, selections, *, review_reports,
                           signal_interpretations=None, execute=False,
                           reviewer='', confirm_plan=None):
    """Preview/record approval from selected H&E galleries; no old import receipt needed.

    selections: {sample: [asset_ids]}; review_reports: {sample: summary_json}.
    signal_interpretations: {sample: {asset_id: 'native' | 'as_configured' |
    'binary_01' | 'binary_0255'}}. Default leaves all scientific settings unchanged.
    Preview reads small reports, source geometry/headers and source fingerprints.
    Execute also reads selected signal pixels, writes approval files and explicitly
    proposed CSV changes with backups. It does NOT open/write a SpatialData master.
    """
    from ..core import digest
    from ..control.manifest import as_bool, row_config, sample_layout, check_policy
    from ..control.paths_v3 import assert_target
    from .alignment import resolve_alignment
    from .workflow import read_assets, alignment_signature, validate_prior_sources
    from .discovery import (read_choices, choice_signature, expand_choices,
                            source_geometry, review_prior_settings)
    if type(execute) is not bool:
        raise TypeError('execute must be Boolean.')
    check_policy(project)
    selected = _canonical_map(project, selections)
    reports = _canonical_map(project, review_reports)
    modes = _canonical_map(project, signal_interpretations or {})
    if not selected:
        raise ValueError('Select explicit sample and source IDs; empty selection approves nothing.')
    updates, proposed, entries, errors, compiled_by_sample = {}, [], [], [], {}
    cfg_by_sample = {}
    # Validate every requested source before any configuration/approval write.
    for key, ids in selected.items():
        if not isinstance(ids, (list, tuple)) or not ids or len(set(ids)) != len(ids):
            raise ValueError('Provide a nonempty list of unique source IDs for each sample.')
        try:
            if key not in reports:
                raise ValueError(f'Missing explicit Visual-First summary.json for {key}. Use list_visual_reviews().')
            row = next(r for r in project['rows'] if r['sample_key'] == key)
            cfg, spec = row_config(project, row); cfg_by_sample[key] = cfg
            paths = sample_layout(project, row)
            geometry = source_geometry(project, row)
            summary, evidence = _evidence(reports[key], key)
            sources = {a['asset_id']: a for a in read_assets(row.get('assets_manifest'), row['dataset_id'], row['sample_id'])}
            if set(modes.get(key, {})) - set(ids):
                raise ValueError('Signal interpretation refers to a source not selected for approval.')
        except Exception as exc:
            errors.append(f'{key}: {type(exc).__name__}: {exc}'); continue
        for asset_id in ids:
            try:
                if asset_id not in sources:
                    raise ValueError(f'No enabled source {asset_id!r} for this sample.')
                original = resolve_alignment(sources[asset_id], geometry)
                if original['role'] != 'discover':
                    raise ValueError('Use this bridge only for per-category discovery sources.')
                choices_path = Path(original['review_table'])
                if choices_path.is_symlink():
                    raise ValueError('Refuse symlinked choices file.')
                choice_update = _file_update(updates, choices_path)
                all_choices = read_choices(choices_path)
                selected_rows = [c for c in all_choices if c['sample_key'] == key and c['asset_id'] == asset_id and as_bool(c['include_in_obs'])]
                if not selected_rows:
                    raise ValueError('No selected rows for this source. Nothing to approve.')
                shown = _verify_view(summary, original, geometry, [c['category'] for c in selected_rows])
                original_sig = alignment_signature(original, geometry)
                prospective, settings_change = _prospective_signal(original, modes.get(key, {}).get(asset_id))
                _signal_summary_check(shown, prospective)
                # Keep the source-signature match strict against the pre-edit config.
                compiled = expand_choices(prospective, geometry, require_approval=False, source_signature=original_sig)
                new_sig = alignment_signature(prospective, geometry)
                compiled_by_sample.setdefault(key, []).extend(compiled)
                if settings_change:
                    source_csv = Path(original['_manifest_path'])
                    if source_csv.is_symlink():raise ValueError('Refuse symlinked assets CSV.')
                    source_update = _file_update(updates, source_csv)
                    matches = [r for r in source_update['rows'] if r['sample_id'].strip() == row['sample_id']
                               and r['asset_id'].strip() == asset_id
                               and (not r.get('dataset_id', '').strip() or r['dataset_id'].strip() == row['dataset_id'])
                               and as_bool(r.get('enabled', ''), True)]
                    if len(matches) != 1:raise ValueError('Ambiguous source CSV row.')
                    for field in settings_change:
                        if field not in source_update['fields']:source_update['fields'].append(field)
                        for r in source_update['rows']:r.setdefault(field, '')
                        matches[0][field] = str(prospective[field])
                    proposed.append({'sample': key, 'asset': asset_id, 'file': str(source_csv), 'changes': settings_change})
                choice_sigs = {}
                for c in choice_update['rows']:
                    if c['sample_key'] != key or c['asset_id'] != asset_id:continue
                    if new_sig != original_sig:
                        c['source_signature'] = new_sig; c['reviewed_signature'] = ''
                    if as_bool(c['include_in_obs']):
                        c['reviewed_signature'] = choice_signature(c, new_sig)
                        choice_sigs[c['item_key']] = c['reviewed_signature']
                receipt_path = _receipt_path(paths['report'], asset_id)
                assert_target(receipt_path, cfg['storage_policy'].get('approved_work_roots', []),
                              [original['path'], geometry['image']['path'], paths['store']])
                entry = {'sample': key, 'asset': asset_id, 'alignment_signature': new_sig,
                         'choice_signatures': choice_sigs, 'receipt': str(receipt_path),
                         'review_summary': str(Path(reports[key]).resolve()), 'evidence': evidence,
                         'source_stamp': _stamp(original['path']),
                         'reference_stamp': _stamp(geometry['image']['path']),
                         'signal_interpretation': modes.get(key, {}).get(asset_id, 'as_configured'),
                         'native_value_review': {k: shown.get('pixel_summary', {}).get(k) for k in
                             ('dtype','min','max','n_measured_valid','binary_encoding_status') } if original['kind']=='signal' else {},
                         'value_settings_change': settings_change,
                         'outputs': [{'category': c['category'], 'obs_name': c['obs_name'], 'qc_use': c['qc_use'],
                                      'signal_methods': c['signal_methods']} for c in selected_rows],
                         'existing_master_directory': Path(paths['store']).is_dir(),
                         'existing_bin_table_directory': (Path(paths['store'])/'tables/bins_2um').is_dir(),
                         'master': str(paths['store'])}
                entries.append((entry, prospective, geometry))
            except Exception as exc:
                errors.append(f'{key} / {asset_id}: {type(exc).__name__}: {exc}')
    for key, items in compiled_by_sample.items():
        try:
            prior = review_prior_settings(items, cfg_by_sample[key].get('prior_filter', {}))
            validate_prior_sources(items, prior)
            names = []
            for item in items:
                base = item['_output_column']
                names += [base, base+'__assessed'] if item['kind']=='polygons' else [base+'__'+m for m in item['_signal_methods']]
            if len(names) != len(set(names)):raise ValueError('Selected output columns collide across sources.')
        except Exception as exc:
            errors.append(f'{key}: {type(exc).__name__}: {exc}')
    public_entries = [e for e, _, _ in entries]
    plan_core = {'patch': PATCH, 'entries': public_entries, 'proposed_source_setting_changes': proposed,
                 'config_inputs': {str(p): _sha_bytes(u['old']) for p, u in updates.items()}}
    plan_id = digest(plan_core)
    result = {'status': 'blocked' if errors else 'ready_for_explicit_approval', 'execute': execute,
              'plan_id': plan_id, 'errors': errors, **plan_core,
              'master_opened_or_written': False, 'stored_receipts_fabricated': False,
              'historical_source_check': 'Existing gallery size/mtime/path plus transform/category checks; current content is bound by pipeline full-source fingerprint. A prior content hash was not present in the old viewer.'}
    if not execute:return result
    if errors:raise RuntimeError('No approvals/configuration were written:\n'+'\n'.join(errors))
    if not isinstance(reviewer, str) or not reviewer.strip():raise ValueError('Enter a reviewer name/identifier after inspecting the selected gallery and plan.')
    if confirm_plan != plan_id:raise RuntimeError('Approval plan was not explicitly confirmed or changed. Run preview again and pass its plan_id.')
    # Verify REAL measured pixels for selected signals before granting approval.
    from .raster import validate_signal_encoding
    for e, asset, geom in entries:
        if asset['kind'] == 'signal':validate_signal_encoding(asset)
        if alignment_signature(asset, geom) != e['alignment_signature']:
            raise RuntimeError('Source changed during validation; no approval written.')
        _same_stamp(e['reference_stamp'], geom['image']['path'], 'H&E reference')
        for ev in e['evidence']:
            if _sha_file(ev['path']) != ev['sha256']:raise RuntimeError('Reviewed gallery changed during approval.')
    writes = {}
    now = datetime.now(timezone.utc).isoformat()
    for e, _, _ in entries:
        path = Path(e['receipt'])
        if path.is_symlink():raise ValueError('Symlinked approval receipt.')
        old = path.read_bytes() if path.exists() else None
        record = {'schema': PATCH, 'status': 'approved_visual_review_not_import_receipt',
                  'reviewer': reviewer.strip(), 'approved_at_utc': now, 'plan_id': plan_id,
                  'master_written': False, **e}
        # Reapproval without a config/data change can reuse the existing review.
        prior = json.loads(old) if old else {}
        unchanged = prior.get('schema') == PATCH and all(prior.get(k) == e[k] for k in
                    ('sample','asset','alignment_signature','choice_signatures','evidence','reference_stamp','source_stamp'))
        if not unchanged:writes[path] = (old, json.dumps(record, indent=2, allow_nan=False).encode())
    for path, u in updates.items():
        # Preserve byte-for-byte input if no field values changed.
        _, original_fields, original_rows = _read_csv(path)
        if original_fields == u['fields'] and original_rows == u['rows']:continue
        writes[path] = (u['old'], _csv_bytes(u['fields'], u['rows']))
    for path, u in updates.items():
        if path.read_bytes() != u['old']:raise RuntimeError('Configuration changed during approval; preview again.')
    if not writes:
        result.update(status='already_approved', reviewer=reviewer.strip(), backups=[]); return result
    # Small per-file replacements with retained backups; not a multi-file atomic transaction.
    # Receipt writes precede config. Interrupted mismatched signatures fail closed.
    backups, completed = [], []
    try:
        for path, (old, new) in writes.items():
            if path.is_symlink() or (path.read_bytes() if path.exists() else None) != old:
                raise RuntimeError(f'File changed while preparing approval: {path}')
            if old is not None:
                backup = path.with_name(path.name+'.before_visual_approval_'+uuid.uuid4().hex+'.txt')
                backup.write_bytes(old); backups.append(str(backup))
            _atomic_bytes(path, new); completed.append((path, old, new))
    except BaseException:
        for path, old, new in reversed(completed):
            if path.read_bytes() == new:
                if old is None:path.unlink()
                else:_atomic_bytes(path, old)
        raise
    result.update(status='approved', reviewer=reviewer.strip(), backups=backups,
                  instruction='Reload PROJECT before 02B. The transfer will perform any missing actual source import first; no stored receipt was forged.')
    return result


def _valid_stored(paths, source_id, signature):
    f = Path(paths['report'])/f'asset_{source_id}.json'
    if not f.is_file():return False
    r = json.loads(f.read_text())
    group = 'shapes' if r.get('kind') == 'polygons' else 'images'
    return (r.get('status') == 'stored' and r.get('alignment_signature') == signature
            and r.get('preview_status') == 'generated' and bool(r.get('element'))
            and (Path(paths['store'])/group/r['element']).is_dir())


def validate_visual_receipt(paths, source_id, signature, items):
    path = _receipt_path(paths['report'], source_id)
    if not path.is_file():raise RuntimeError(f'No current stored preview OR Visual-First approval for {source_id}. Run approve_visual_choices with its reviewed summary.json.')
    r = json.loads(path.read_text())
    sample = items[0]['dataset_id']+'__'+items[0]['sample_id']
    if (r.get('schema') != PATCH or r.get('status') != 'approved_visual_review_not_import_receipt'
            or r.get('asset') != source_id or r.get('sample') != sample
            or r.get('alignment_signature') != signature):
        raise RuntimeError(f'Stale Visual-First approval for {source_id}; review current choices/source.')
    for a in items:
        key = a['asset_id'].rsplit('_item_', 1)[-1]
        if (not a.get('_choice_signature') or r.get('choice_signatures', {}).get(key) != a['_choice_signature']
                or a.get('reviewed_signature') != signature):
            raise RuntimeError(f'Visual approval does not cover current choice {source_id}/{key}.')
    _same_stamp(r['reference_stamp'], r['reference_stamp']['path'], 'H&E reference')
    _same_stamp(r['source_stamp'], items[0]['path'], 'Annotation/signal source')
    for ev in r['evidence']:
        if _sha_file(ev['path']) != ev['sha256']:raise RuntimeError('Approved visual evidence is missing or changed.')
    return r


def ensure_transfer_sources(cfg, spec, assets, alignments, *, paths=None):
    """Validate visual approval and perform missing REAL imports, never fabricate receipts.

    This is called only by executing transfer_assets, not by plan preview.
    The unchanged import_assets assembler reuses tracked masters and preserves its
    coordinate/write/partial-output gates. Old completed sources remain reusable.
    """
    from ..core import sample_paths
    from .workflow import import_assets, read_assets, active_assets
    from .raster import validate_signal_encoding
    p = paths if paths is not None else sample_paths(cfg, spec)
    grouped = {}
    for a, sig in zip(assets, alignments):
        sid = a.get('_source_asset_id', a['asset_id'])
        bucket = grouped.setdefault(sid, {'sig': sig, 'items': []})
        if bucket['sig'] != sig:raise ValueError('Inconsistent source signatures within transfer.')
        if a['reviewed_signature'] != sig:raise RuntimeError(f'Unapproved transfer source {sid}.')
        bucket['items'].append(a)
    def stored(sid, signature):
        # Preserve the pre-existing transfer contract for legacy approvals. The
        # stronger element/status checks apply to the new Visual-First route.
        if not _receipt_path(p['report'], sid).exists():
            f = Path(p['report'])/f'asset_{sid}.json'
            return f.is_file() and json.loads(f.read_text()).get('alignment_signature') == signature
        return _valid_stored(p, sid, signature)
    needs_import = []
    for sid, value in grouped.items():
        if stored(sid, value['sig']):continue
        validate_visual_receipt(p, sid, value['sig'], value['items'])
        needs_import.append(sid)
    if needs_import:
        # Check selected signal encodings before expensive master access, not after it.
        for a in assets:
            if a['kind'] == 'signal':validate_signal_encoding(a)
        # Original import includes all configured enabled sources. Prevalidate any
        # other non-reference signals too, so an unselected mismatch cannot hide.
        sources = read_assets(spec['_row'].get('assets_manifest'), spec['dataset_id'], spec['sample_id'])
        selected_ids = set(grouped)
        for a in sources:
            if a['kind'] == 'signal' and a['asset_id'] not in selected_ids and a['role'] != 'reference_only':
                validate_signal_encoding(a)
        print('Visual-First approval verified. Importing/reusing actual spatial sources before bin transfer:', needs_import, flush=True)
        import_assets(cfg, spec)
    for sid, value in grouped.items():
        if not stored(sid, value['sig']):
            raise RuntimeError(f'Actual source import did not create a matching stored preview for {sid}; no bin transfer will proceed.')


def print_approval_plan(plan):
    """Compact notebook view. The complete audit remains in the returned dictionary."""
    print('VISUAL-FIRST APPROVAL:', plan['status'])
    print('Master opened/written by this approval call:', plan.get('master_opened_or_written', False))
    for entry in plan.get('entries', []):
        print('\n', entry['sample'], '/', entry['asset'])
        print(' Reviewed gallery:', str(Path(entry['review_summary']).parent/'index.html'))
        print(' Source interpretation:', entry['signal_interpretation'])
        if entry.get('native_value_review'):
            print(' Recorded native signal:', entry['native_value_review'])
        for output in entry['outputs']:
            method = (' [' + output['signal_methods'] + ']') if output['signal_methods'] else ''
            print(' ', output['category'], '->', output['obs_name'] + method, '| QC:', output['qc_use'])
        for field, change in entry.get('value_settings_change', {}).items():
            print(' Proposed assets.csv change:', field, repr(change['old']), '->', repr(change['new']))
        print(' Approval record:', entry['receipt'])
    for err in plan.get('errors', []):
        print('\nBLOCKER:', err)
    if plan.get('backups'):
        print('\nBackups:')
        for path in plan['backups']:print(' ', path)
    if plan['status'] == 'ready_for_explicit_approval':
        print('\nReady for YOUR explicit confirmation. No approval has been saved.')
    elif plan['status'] in ('approved', 'already_approved'):
        print('\nReload PROJECT and return to notebook 02B. Execute mode will import missing spatial sources before transfer.')
