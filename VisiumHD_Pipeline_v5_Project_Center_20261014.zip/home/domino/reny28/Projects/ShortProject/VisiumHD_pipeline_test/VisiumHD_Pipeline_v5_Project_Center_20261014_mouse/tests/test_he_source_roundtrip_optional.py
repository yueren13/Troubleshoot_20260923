"""Tiny real H5/PNG/NPY/Parquet measurement test; not a whole-slide validation."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import pytest
ad=pytest.importorskip('anndata')
pytest.importorskip('pyarrow')
from scipy import sparse
from PIL import Image
from vhd.he.workflow import measure


def test_real_hires_lookup_measurement_and_count_file_unchanged(tmp_path):
    folder=tmp_path/'outs/spatial';folder.mkdir(parents=True)
    Image.fromarray(np.full((8,10,3),200,np.uint8)).save(folder/'tissue_hires_image.png')
    (folder/'scalefactors_json.json').write_text('{"tissue_hires_scalef":0.25}')
    work=tmp_path/'work';work.mkdir()
    obs=pd.DataFrame({'pxl_col_in_fullres':[0.,8.,16.],'pxl_row_in_fullres':[0.,8.,16.]},index=['b1','b2','b3'])
    a=ad.AnnData(sparse.csr_matrix([[1,0],[0,2],[3,1]]),obs=obs,var=pd.DataFrame(index=['g1','g2']))
    counts=work/'bins_raw.h5ad';a.write_h5ad(counts)
    stamp=(hashlib.sha256(counts.read_bytes()).hexdigest(),counts.stat().st_mtime_ns)
    cfg={'he_score':{'h_limit':1.9705,'e_limit':1.0308,'h_weight':1.,'e_weight':1.,'method':'soft_union','tile_size':3},
         'storage_policy':{'min_free_tmp_gib':0},'plots':{'dpi':50}}
    spec={'sample':'P__A','outs':str(tmp_path/'outs'),'_paths':{'work':str(work),'report':str(tmp_path/'reports'),
            'proseg':str(tmp_path/'proseg'),'store':str(tmp_path/'master.zarr')}}
    report=measure(cfg,spec)
    out=pd.read_parquet(work/'bins_he.parquet')
    assert out.index.equals(obs.index) and out.he_tissue_score_valid.all()
    assert report['source_resolution']['layout']=='outs_spatial'
    assert stamp==(hashlib.sha256(counts.read_bytes()).hexdigest(),counts.stat().st_mtime_ns)
    files=[p for p in work.rglob('*') if p.is_file()]
    after={str(p):(p.read_bytes(),p.stat().st_mtime_ns) for p in files}
    assert measure(cfg,spec)==report
    assert after=={str(p):(p.read_bytes(),p.stat().st_mtime_ns) for p in files}
