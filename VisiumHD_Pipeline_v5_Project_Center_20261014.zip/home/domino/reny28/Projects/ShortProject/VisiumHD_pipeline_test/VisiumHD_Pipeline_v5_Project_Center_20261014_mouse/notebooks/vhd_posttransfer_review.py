"""Read-only review of persisted VHD bin metadata and StarDist execution records.

No pipeline launch, approval, repair, configuration update, or scientific write.
Reports are written only to the caller's new review directory. Do not review a
master while any process is writing it. Uses existing pixel-coordinate contracts.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence
import hashlib
import html
import json
import math
import re
import sys
import uuid
import zipfile

import numpy as np
import pandas as pd

VERSION = 'posttransfer-observed-review-1'
DEFAULT_SAMPLE = 'Project__BM0164135A_s1_A1'
DEFAULT_ROOT = Path('/stash/results/dev/reny28/2026/VisiumHD_pipeline_test/work/vhd/Project/BM0164135A_s1_A1/run01')
DEFAULT_MASTER = Path('/stash/results/dev/reny28/2026/VisiumHD_pipeline_test/zarr_files/BM0164135A_s1_A1.zarr')
DEFAULT_PACKAGE = Path('/home/domino/reny28/Projects/ShortProject/VisiumHD_pipeline_test/VisiumHD_Pipeline_v5_Project_Center_20261009_human')


def _jsonable(value):
    if isinstance(value, dict): return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [_jsonable(v) for v in value]
    if isinstance(value, Path): return str(value)
    if isinstance(value, np.ndarray): return _jsonable(value.tolist())
    if isinstance(value, np.generic): return _jsonable(value.item())
    if value is pd.NA: return None
    if isinstance(value, float) and not math.isfinite(value): return None
    return value


def _write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(_jsonable(value), indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)


def _stamp(path):
    p = Path(path)
    if not p.exists(): return {'path': str(p), 'exists': False}
    s = p.stat()
    return {'path': str(p.resolve()), 'exists': True, 'size': s.st_size,
            'mtime_ns': s.st_mtime_ns, 'is_file': p.is_file()}


def _read_small_json(path, max_bytes=8*1024**2):
    path = Path(path)
    if not path.is_file(): return {'_absent': str(path)}
    if path.stat().st_size > max_bytes: return {'_not_read': 'Exceeds diagnostic size limit', 'path': str(path)}
    try: return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc: return {'_read_error': str(exc), 'path': str(path)}


def _tail(path, limit=65536):
    p = Path(path)
    if not p.is_file(): return '(No file at this path.)'
    with p.open('rb') as h:
        h.seek(0, 2); size = h.tell(); h.seek(max(0, size-limit))
        text = h.read(limit).decode('utf-8', errors='replace')
    return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text)


def _new_output(output_root, prefix):
    parent = Path(output_root).expanduser().resolve()
    parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    target = parent / f'{prefix}_{stamp}_{uuid.uuid4().hex[:8]}'
    target.mkdir()
    return target


def _paths(pc, sample, sample_root, master):
    if pc is None:
        return Path(sample_root).resolve(), Path(master).resolve(), None, DEFAULT_PACKAGE
    snap = pc.snapshot()
    rows = [r for r in snap['project']['rows'] if r.get('sample_key') == sample]
    if len(rows) != 1: raise KeyError(f'Expected one project row for {sample}; found {len(rows)}')
    from vhd.control.manifest import sample_layout
    p = sample_layout(snap['project'], rows[0])
    # No sample_paths() call: that engine helper creates directories.
    work = Path(p['work']); root = work.parent
    if Path(p['report']) != root/'reports':
        raise ValueError('Nonstandard work/report layout; use explicit paths with controller=None.')
    module = sys.modules.get(type(pc).__module__)
    source = getattr(module, '__file__', None)
    package = Path(source).resolve().parents[2] if source else DEFAULT_PACKAGE
    return root, Path(p['store']), snap, package


def diagnose_stardist(controller=None, *, sample=DEFAULT_SAMPLE,
                       sample_root=DEFAULT_ROOT, master=DEFAULT_MASTER,
                       output_root='vhd_stardist_status_review'):
    """Read job/status/log/source evidence, return a small diagnostic ZIP. Never launch."""
    root, store, snap, package = _paths(controller, sample, sample_root, master)
    out = _new_output(output_root, 'stardist_diagnostic')
    job = (snap or {}).get('jobs', {}).get(sample, {}).get('stardist', {})
    transfer = (snap or {}).get('jobs', {}).get(sample, {}).get('transfer_assets', {})
    worker = _read_small_json(root/'reports/status_stardist.json')
    resource = _read_small_json(root/'reports/worker_stardist.resources.json')
    print('StarDist controller job (a ready route does NOT imply no prior failure):')
    print(json.dumps(_jsonable(job), indent=2))
    print('\nStarDist worker status:')
    print(json.dumps(_jsonable(worker), indent=2))
    print('\nLatest StarDist worker log (bounded tail, timestamps should be checked):')
    log = _tail(root/'reports/worker_stardist.log')
    print(log)
    verdict = ('controller_reports_failed' if job.get('status') == 'failed' else
               'controller_reports_running_do_not_launch_again' if job.get('status') == 'running' else
               'controller_reports_complete_check_contract_and_products' if job.get('status') == 'complete' else
               'no_controller_stardist_job_available')
    evidence = dict(version=VERSION, sample=sample, verdict=verdict, controller_job=job,
                    transfer_controller_job=transfer, worker_status=worker, resources=resource,
                    record_timestamps_may_refer_to_previous_attempts=True,
                    project_write_or_worker_launch=False, sample_root=str(root), store=str(store))
    if controller is not None:
        try: evidence['live_route'] = controller.plan([sample])
        except Exception as exc: evidence['live_route_error'] = repr(exc)
        settings = snap['project']['settings']
        evidence['configured_execution'] = settings.get('execution', {})
        evidence['configured_stardist'] = settings.get('stardist', {})
        evidence['resource_caps'] = snap.get('resource_limits', {})
    members = [
        'vhd/segmentation.py', 'vhd/compute/runtime_checks.py',
        'vhd/center/stages.py', 'vhd/center/reports.py', 'vhd/center/controller.py',
        'vhd/center/resources.py', 'vhd/compute/launch.py',
    ]
    sources = []
    for rel in members:
        src = package/rel
        record = {'relative': rel, **_stamp(src)}
        if src.is_file() and src.stat().st_size <= 2*1024**2:
            data = src.read_bytes(); dest = out/'sources'/rel
            dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
        sources.append(record)
    evidence['source_inventory'] = sources
    for name in ['status_stardist.json','worker_stardist.resources.json','assets_transfer.json']:
        _write_json(out/'reports'/name, _read_small_json(root/'reports'/name))
    (out/'worker_stardist_log_tail.txt').write_text(log, encoding='utf-8')
    evidence['work_file_inventory'] = [_stamp(root/'work'/name) for name in (
        'prior_raw.npy','prior_qc.npy','prior_metadata.json','he_crop.npy',
        '03_stardist_complete.json','bins_annotated_obs.parquet')]
    evidence['inventory_note'] = 'Listed prior names are diagnostic candidates, not certification of the installed output contract.'
    _write_json(out/'stardist_diagnostic.json', evidence)
    archive = out/'VHD_StarDist_diagnostic.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for f in sorted(out.rglob('*')):
            if f.is_file() and f != archive: z.write(f, f.relative_to(out))
    print('\nDiagnostic verdict:', verdict)
    print('Evidence ZIP:', archive)
    print('No jobs, reviews, settings, locks, or scientific files were changed.')
    return archive


def _quiescent(root, store, controller, sample):
    if controller is not None:
        jobs = controller.snapshot().get('jobs', {}).get(sample, {})
        running = [k for k, v in jobs.items() if v.get('status') == 'running']
        if running: raise RuntimeError(f'Finish/inspect active jobs before reading this master: {running}')
    locks = list((root/'work').glob('.worker_*.lock'))
    writer = store.with_name(store.name+'.vhd_writer.lock')
    if writer.exists(): locks.append(writer)
    if locks: raise RuntimeError('Existing execution/writer locks; no review was started: '+str(locks))
    txroot = store.with_name(store.name+'.vhd_transactions')
    for p in txroot.glob('*/journal.json'):
        j = _read_small_json(p)
        if j.get('state') not in ('committed', 'rolled_back'):
            raise RuntimeError(f'Unresolved or unreadable transaction: {p}')


def _matrix(geometry):
    m = np.asarray(geometry.get('tenx_to_image'), dtype=float)
    if m.shape != (3, 3) or not np.isfinite(m).all() or abs(np.linalg.det(m)) < 1e-15:
        raise ValueError('Missing/invalid saved tenx_to_image transform; no identity guessed.')
    return m


def transform_centers(frame, matrix):
    xy = frame[['pxl_col_in_fullres', 'pxl_row_in_fullres']].to_numpy(dtype=np.float64)
    m = np.asarray(matrix, dtype=np.float64)
    z = xy@m[2,:2] + m[2,2]
    with np.errstate(divide='ignore', invalid='ignore'):
        return (xy@m[:2,:2].T + m[:2,2])/z[:,None]


def load_master_columns(store, columns):
    """Read just obs index/selected obs columns; never X, layers or full SpatialData."""
    import zarr
    from anndata.io import read_elem
    group = zarr.open_group(str(Path(store)/'tables'/'bins_2um'), mode='r', use_consolidated=False)
    og = group['obs']
    index_key = og.attrs.get('_index')
    if not isinstance(index_key, str): raise ValueError('Unrecognized AnnData obs index metadata.')
    names = pd.Index(read_elem(og[index_key]))
    if names.hasnans or not names.is_unique: raise ValueError('Missing/duplicate bin IDs in persisted obs.')
    if not all(isinstance(x, str) for x in names[:100]):
        raise ValueError('Expected original string bin IDs; no ID conversion/relabeling applied.')
    missing = [c for c in columns if c not in og]
    if missing: raise KeyError('Requested columns absent from actual master obs: '+str(missing))
    frame = pd.DataFrame(index=names)
    for c in columns:
        value = read_elem(og[c])
        if len(value) != len(names): raise ValueError(f'Incorrect length in obs/{c}')
        frame[c] = value.array if isinstance(value, pd.Series) else value  # Stored order; no Series alignment.
    frame.index.name = 'bin_id'
    return frame


def _equal_values(left, right):
    left = pd.Series(left).reset_index(drop=True); right = pd.Series(right).reset_index(drop=True)
    if len(left) != len(right): raise ValueError('Unequal comparison lengths.')
    missing = left.isna().to_numpy() & right.isna().to_numpy()
    both = left.notna().to_numpy() & right.notna().to_numpy()
    same = missing.copy()
    if pd.api.types.is_numeric_dtype(left.dtype) and pd.api.types.is_numeric_dtype(right.dtype):
        a = left[both].to_numpy(dtype=float, na_value=np.nan)
        b = right[both].to_numpy(dtype=float, na_value=np.nan)
        same[both] = a == b  # Same exported values: no rounding allowance needed.
    else:
        same[both] = left[both].astype(str).to_numpy() == right[both].astype(str).to_numpy()
    return same


def compare_sidecar(frame, path, *, columns=None, batch_size=100000):
    """Full ID-aligned check against the transfer sidecar, streamed by row batch."""
    import pyarrow.parquet as pq
    path = Path(path); before = _stamp(path)
    columns = list(columns or frame.columns)
    seen = np.zeros(len(frame), dtype=bool)
    mismatch = {c: 0 for c in columns}
    total = 0
    with pq.ParquetFile(path) as pf:
        for batch in pf.iter_batches(batch_size=batch_size, columns=columns, use_pandas_metadata=True):
            data = batch.to_pandas()
            if isinstance(data.index, pd.MultiIndex) or not data.index.is_unique:
                raise ValueError('Unexpected duplicate/MultiIndex in sidecar batch.')
            positions = frame.index.get_indexer(data.index)
            if (positions < 0).any(): raise ValueError('Sidecar has IDs absent from persisted master; no positional fallback.')
            if seen[positions].any(): raise ValueError('Repeated bin IDs across sidecar batches.')
            seen[positions] = True; total += len(data)
            for c in columns:
                mismatch[c] += int((~_equal_values(frame[c].iloc[positions].array, data[c].array)).sum())
    if before != _stamp(path): raise RuntimeError('Sidecar changed during comparison; stop concurrent writers.')
    table = pd.DataFrame({'column': columns, 'mismatch_count': [mismatch[c] for c in columns],
                          'n_compared': total, 'master_bins_not_seen': int((~seen).sum())})
    return table


@dataclass
class Review:
    sample: str
    root: Path
    store: Path
    output: Path
    frame: pd.DataFrame
    xy_image: np.ndarray
    geometry: dict
    receipt: dict
    controller: Any = None


def _field_stats(frame, fields):
    records=[]
    for name in fields:
        s=frame[name]; valid=s.dropna(); row={'column':name,'dtype':str(s.dtype),
            'n_bins':len(s),'n_missing':int(s.isna().sum()),'n_present':len(valid)}
        if pd.api.types.is_bool_dtype(s.dtype):
            row.update(n_true=int(valid.astype(bool).sum()), n_false=int((~valid.astype(bool)).sum()))
        elif pd.api.types.is_numeric_dtype(s.dtype):
            values=valid.to_numpy(dtype=float); finite=values[np.isfinite(values)]
            row['n_nonfinite_nonmissing']=int((~np.isfinite(values)).sum())
            if len(finite):
                row.update(min=float(finite.min()),max=float(finite.max()),mean=float(finite.mean()),
                           median=float(np.median(finite)),q01=float(np.quantile(finite,.01)),q99=float(np.quantile(finite,.99)))
        else:
            row['category_counts_json']=json.dumps({str(k):int(v) for k,v in s.value_counts(dropna=False).items()})
        records.append(row)
    return pd.DataFrame(records)


def open_review(controller=None, *, sample=DEFAULT_SAMPLE, sample_root=DEFAULT_ROOT,
                master=DEFAULT_MASTER, output_root='vhd_posttransfer_reviews', columns=None,
                confirmed_no_other_readers_or_writers=False):
    """Load metadata read-only; writes only a newly named report directory.

    No independent owner check across hosts is possible here; explicit quiescence
    acknowledgement supplements local lock/controller checks.
    """
    if not confirmed_no_other_readers_or_writers:
        raise PermissionError('Confirm exclusive/quiescent access before opening the master for review.')
    root,store,snap,package = _paths(controller,sample,sample_root,master)
    _quiescent(root,store,controller,sample)
    receipt_path=root/'reports/assets_transfer.json'; receipt=_read_small_json(receipt_path)
    status=_read_small_json(root/'reports/status_transfer_assets.json')
    if status.get('status')!='complete' or 'owned_columns' not in receipt:
        raise RuntimeError('No completed transfer worker status/receipt; review stopped.')
    sidecar=root/'work/bins_annotated_obs.parquet'
    declared=receipt.get('derived_stamp',{}); current=_stamp(sidecar)
    if any(current.get(k)!=declared.get(k) for k in ('size','mtime_ns')) or not current.get('exists'):
        raise RuntimeError('Sidecar size/mtime does not match transfer receipt; do not review stale results.')
    geometry=_read_small_json(root/'work/geometry.json'); m=_matrix(geometry)
    selected=list(dict.fromkeys(['pxl_col_in_fullres','pxl_row_in_fullres','qc_class','qc_keep']+
                                list(receipt['owned_columns'] if columns is None else columns)))
    before=_stamp(receipt_path)
    frame=load_master_columns(store,selected)
    xy=transform_centers(frame,m)
    if before!=_stamp(receipt_path): raise RuntimeError('Transfer receipt changed during read.')
    _quiescent(root,store,controller,sample)
    parent=Path(output_root).expanduser().resolve()
    if parent==store or store in parent.parents:
        raise ValueError('Review outputs must be outside the live master store.')
    out=_new_output(parent,sample+'_observed_obs')
    stats=_field_stats(frame,[c for c in selected if not c.startswith('pxl_')])
    stats.to_csv(out/'persisted_obs_column_summary.csv',index=False)
    summary={'version':VERSION,'sample':sample,'source':'actual persisted tables/bins_2um/obs',
             'store':str(store),'n_bins':len(frame),'read_columns':selected,
             'coordinate_transform':m.tolist(),'n_nonfinite_image_centers':int((~np.isfinite(xy).all(1)).sum()),
             'transfer_receipt':receipt,'scientific_arrays_written':False,
             'segmentation_or_transfer_reexecuted':False,'review_is_not_an_approval':True}
    _write_json(out/'review_manifest.json',summary)
    if not any(receipt.get('transfer_spec',{}).get(k) for k in ('categorical','boolean','continuous')):
        print('NOTE: saved transfer_spec requests no cell-level asset summaries. Bin fields exist, but these choices do not request automatic transfer of those fields to cells.')
    print('Loaded persisted bin obs:',frame.shape)
    print('New review folder:',out)
    return Review(sample,root,store,out,frame,xy,geometry,receipt,controller)


def verify_master_against_sidecar(review: Review):
    _quiescent(review.root,review.store,review.controller,review.sample)
    table=compare_sidecar(review.frame,review.root/'work/bins_annotated_obs.parquet')
    table.to_csv(review.output/'master_vs_transfer_sidecar.csv',index=False)
    okay=bool((table['mismatch_count']==0).all() and (table['master_bins_not_seen']==0).all())
    _write_json(review.output/'master_vs_sidecar_check.json',{'passed':okay,
                'scope':'All loaded columns and all source bin IDs; no X/layers read or written'})
    _quiescent(review.root,review.store,review.controller,review.sample)
    if not okay: raise ValueError('Persisted obs and transfer sidecar differ. See saved mismatch table; no repair attempted.')
    print('All compared metadata values and bin IDs agree.')
    return table


def _he_image(review, bounds, max_side):
    from vhd.images import image_info, thumbnail, read_region
    info=review.geometry['image']; actual=image_info(info['path'],info['mpp'])
    if (actual['width'],actual['height'])!=(info['width'],info['height']):
        raise ValueError('Original H&E dimensions changed since ingest.')
    if bounds is None:
        image=thumbnail(actual,max_side=max_side)
        extent=(-.5,actual['width']-.5,actual['height']-.5,-.5)
        return image,extent
    left,top,right,bottom=map(int,bounds)
    if not (0<=left<right<=actual['width'] and 0<=top<bottom<=actual['height']):
        raise ValueError('ROI bounds must be left,top,right,bottom inside original H&E pixels.')
    if (right-left)*(bottom-top)>25_000_000:
        raise ValueError('ROI exceeds 25 million original pixels. Select a smaller ROI or extend the reader explicitly.')
    image=read_region(info['path'],left,top,right-left,bottom-top)
    return image,(left-.5,right-.5,bottom-.5,top-.5)


def _safe_name(value): return re.sub(r'[^A-Za-z0-9_.-]+','_',str(value))


def _draw_field(review, field, indices, image, extent, target, *, dpi, point_size, alpha):
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize
    s=review.frame[field].iloc[indices]; xy=review.xy_image[indices]
    fig,ax=plt.subplots(figsize=(10,8))
    ax.imshow(image,extent=extent,origin='upper')
    if pd.api.types.is_numeric_dtype(s.dtype) and not pd.api.types.is_bool_dtype(s.dtype):
        values=s.to_numpy(dtype=float,na_value=np.nan); good=np.isfinite(values)
        source=review.frame[field].to_numpy(dtype=float,na_value=np.nan)
        finite=source[np.isfinite(source)]
        lo=float(finite.min()) if len(finite) else 0.; hi=float(finite.max()) if len(finite) else 1.
        if hi==lo: hi=lo+max(1e-12,abs(lo)*1e-6)
        if (~good).any(): ax.scatter(*xy[~good].T,s=point_size,marker='x',label='missing/nonfinite',alpha=.5)
        artist=ax.scatter(*xy[good].T,s=point_size,c=values[good],norm=Normalize(lo,hi),alpha=alpha,linewidths=0)
        fig.colorbar(artist,ax=ax,label=field+' (stored values; global range)')
        if (~good).any(): ax.legend(loc='upper left',bbox_to_anchor=(1.02,1),fontsize=8)
    else:
        full=review.frame[field].astype('string').fillna('<unassessed>')
        vals=s.astype('string').fillna('<unassessed>').to_numpy()
        cats=sorted(full.unique().tolist())
        if len(cats)>30: plt.close(fig); raise ValueError(f'Too many categories to draw for {field}: {len(cats)}')
        for label in cats:
            keep=vals==label
            ax.scatter(*xy[keep].T,s=point_size,alpha=alpha,linewidths=0,label=label)
        ax.legend(title='Stored value',loc='upper left',bbox_to_anchor=(1.02,1),fontsize=8,markerscale=2)
    ax.set_xlim(extent[0],extent[1]);ax.set_ylim(extent[2],extent[3]);ax.set_aspect('equal')
    ax.set_xlabel('Original H&E x / column (pixels)');ax.set_ylabel('Original H&E y / row (pixels)')
    ax.set_title(f'{review.sample} | {field}')
    fig.text(.1,.005,f'Persisted bin centers: {len(indices):,} displayed; no expression or signal recomputation',fontsize=8)
    fig.savefig(target,dpi=dpi,bbox_inches='tight');plt.close(fig)


def render_review(review: Review, *, fields=None, rois=None, max_overview_points=300000,
                  max_roi_points=500000, thumbnail_side=2400, point_size=.6, alpha=.8, dpi=300,seed=42):
    """Render saved values over H&E; point subsampling is display-only and audited."""
    _quiescent(review.root,review.store,review.controller,review.sample)
    if fields is None:
        fields=[c for c in review.receipt['owned_columns'] if not c.endswith(('__assessed','__n_valid_pixels','__in_bounds_fraction','__valid'))]
    fields=list(fields); rois=list(rois or [])
    if not fields or any(c not in review.frame for c in fields): raise KeyError('Select existing persisted obs fields.')
    if min(max_overview_points,max_roi_points,thumbnail_side,dpi)<=0 or point_size<=0 or not 0<alpha<=1:
        raise ValueError('Invalid rendering settings.')
    settings=dict(fields=fields,rois=rois,max_overview_points=max_overview_points,max_roi_points=max_roi_points,
                  thumbnail_side=thumbnail_side,point_size=point_size,alpha=alpha,dpi=dpi,seed=seed)
    digest=hashlib.sha256(json.dumps(_jsonable(settings),sort_keys=True).encode()).hexdigest()[:12]
    out=review.output/'plots'/digest;out.mkdir(parents=True,exist_ok=True)
    _write_json(out/'plot_settings.json',settings)
    xy=review.xy_image; info=review.geometry['image']
    in_image=np.isfinite(xy).all(1)&(xy[:,0]>=-.5)&(xy[:,0]<info['width']-.5)&(xy[:,1]>=-.5)&(xy[:,1]<info['height']-.5)
    candidates=np.flatnonzero(in_image);rng=np.random.default_rng(seed)
    overview=rng.choice(candidates,size=min(len(candidates),int(max_overview_points)),replace=False)
    image,extent=_he_image(review,None,thumbnail_side)
    images=[];selection=[]
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    fig,ax=plt.subplots(figsize=(10,8));ax.imshow(image,extent=extent,origin='upper')
    if len(candidates):
        low=xy[candidates].min(0); high=xy[candidates].max(0)
        ax.add_patch(Rectangle(low,*(high-low),fill=False,label='Bin-center bounding box'))
    for i,roi in enumerate(rois):
        box=roi['bounds_px']; l,t,r,b=box
        ax.add_patch(Rectangle((l,t),r-l,b-t,fill=False,linestyle='--'))
        ax.text(l,t,str(roi.get('name',f'ROI{i+1}')),fontsize=9)
    ax.set(xlim=extent[:2],ylim=extent[2:],xlabel='Original H&E x (px)',ylabel='Original H&E y (px)',title='H&E / ROI coordinate guide',aspect='equal')
    target=out/'HE_coordinate_guide.png';fig.savefig(target,dpi=dpi,bbox_inches='tight');plt.close(fig);images.append(target)
    for field in fields:
        target=out/f'whole_{_safe_name(field)}.png'
        _draw_field(review,field,overview,image,extent,target,dpi=dpi,point_size=point_size,alpha=alpha);images.append(target)
    selection.append(dict(region='whole',n_candidate_bins=len(candidates),n_displayed=len(overview),n_outside_image=int((~in_image).sum())))
    for i,roi in enumerate(rois):
        name=_safe_name(roi.get('name',f'ROI{i+1}')); bounds=roi['bounds_px'];l,t,r,b=bounds
        chosen=np.flatnonzero(in_image&(xy[:,0]>=l-.5)&(xy[:,0]<r-.5)&(xy[:,1]>=t-.5)&(xy[:,1]<b-.5))
        use=rng.choice(chosen,size=min(len(chosen),int(max_roi_points)),replace=False)
        img,ext=_he_image(review,bounds,thumbnail_side)
        fig,ax=plt.subplots(figsize=(9,8));ax.imshow(img,extent=ext,origin='upper');ax.set_title(name+' | H&E only');ax.set_aspect('equal')
        target=out/f'{name}_HE_only.png';fig.savefig(target,dpi=dpi,bbox_inches='tight');plt.close(fig);images.append(target)
        for field in fields:
            target=out/f'{name}_{_safe_name(field)}.png'
            _draw_field(review,field,use,img,ext,target,dpi=dpi,point_size=max(point_size,3),alpha=alpha);images.append(target)
        selection.append(dict(region=name,n_candidate_bins=len(chosen),n_displayed=len(use),bounds_px=bounds))
    _write_json(out/'display_sampling.json',selection)
    pages=['<!doctype html><meta charset="utf-8"><title>Transferred obs review</title>',
           '<style>body{font-family:Arial;margin:28px}img{max-width:100%;height:auto}figure{margin:20px 0}</style>',
           '<h1>Actual persisted bin metadata on H&E</h1>',
           '<p>No source remeasurement, QC change, or automatic review approval. Whole-slide points may be subsampled; column-summary statistics use all loaded bins. Native stored values and missingness are preserved.</p>']
    for p in images:
        pages.append(f'<figure><a href="{html.escape(p.name)}"><img loading="lazy" src="{html.escape(p.name)}"></a><figcaption>{html.escape(p.stem)}</figcaption></figure>')
    (out/'index.html').write_text('\n'.join(pages),encoding='utf-8')
    _quiescent(review.root,review.store,review.controller,review.sample)
    print('New transfer review gallery:',out/'index.html')
    return out
