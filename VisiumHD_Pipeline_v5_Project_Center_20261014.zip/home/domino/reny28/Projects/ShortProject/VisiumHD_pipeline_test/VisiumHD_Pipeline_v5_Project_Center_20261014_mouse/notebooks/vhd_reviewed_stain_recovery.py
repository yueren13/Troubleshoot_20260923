"""Narrow recovery for the reviewed 205f... new images/asset_stain transaction.

Preview is read-only. Execution calls the INSTALLED native recover_transaction;
it never manufactures a journal terminal state. No worker launch, killing,
configuration changes, package patching, or generalized transaction cleanup.

This is not a general Zarr repair utility. Keep reviewed_journal.json beside it.
"""
from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import os
from pathlib import Path, PurePosixPath
import re
import socket
import stat
import sys
from datetime import datetime, timezone
from typing import Any
import uuid

SAMPLE = 'Project__BM0164135A_s1_A1'
STORE = Path('/stash/results/dev/reny28/2026/VisiumHD_pipeline_test/zarr_files/BM0164135A_s1_A1.zarr')
TRANSACTION_ID = '205fba82de114df797fe0dae6f1ae222'
RELATIVE = 'images/asset_stain'
EXPECTED_JOURNAL_SHA256 = 'b65e0e5b7ff613af9a0e574cda7f5188ef75c7daf104ee1d931c79c75b4988eb'
EXPECTED_SOURCES = {
    'vhd/persistence/transaction.py': '39f21522d5b31acb5199d8c304c74e8cbceaa9ccae4291f6de12c4574b0c0b03',
    'vhd/persistence/spatial.py': '9b8006e90ba68d5d4a0585ec6597b0906faac59909093d5c6d273691674aa407',
}
VERSION = 'reviewed-new-image-rollback-1'


def _hash_file(path: Path, *, limit: int | None = None) -> str:
    h = hashlib.sha256()
    remaining = limit
    with Path(path).open('rb') as f:
        while remaining is None or remaining > 0:
            block = f.read(4 * 1024**2 if remaining is None else min(4 * 1024**2, remaining))
            if not block:
                if remaining not in (None, 0):
                    raise IOError(f'Unexpected early EOF: {path}')
                break
            h.update(block)
            if remaining is not None:
                remaining -= len(block)
    return h.hexdigest()


def _json_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def _save(value: Any, path: Path) -> None:
    # Only recovery audit files use this helper. The native code owns journal updates.
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False, default=str) + '\n')
    os.replace(temp, path)


def _regular(path: Path) -> None:
    m = path.lstat().st_mode
    if not stat.S_ISREG(m):
        raise ValueError(f'Expected regular, non-symlink file: {path}')


def _no_symlink_components(root: Path, path: Path) -> None:
    root = Path(root)
    relative = Path(path).relative_to(root)
    current = root
    if current.is_symlink():
        raise ValueError(f'Symlinked recovery root: {current}')
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f'Symlinked path component: {current}')


def _safe_tree(path: Path, parent: Path) -> None:
    """Reject symlinks/special files without following them through an inventory."""
    if path.is_symlink() or not path.resolve().is_relative_to(parent.resolve()):
        raise ValueError(f'Unsafe path: {path}')
    if not path.exists():
        return
    if not path.is_dir():
        raise ValueError(f'Expected a directory component: {path}')
    for directory, directories, files in os.walk(path, followlinks=False):
        for name in directories:
            d = Path(directory) / name
            if not stat.S_ISDIR(d.lstat().st_mode):
                raise ValueError(f'Symlink/special directory is not supported: {d}')
        for name in files:
            _regular(Path(directory) / name)


def _expected_record() -> dict:
    p = Path(__file__).with_name('reviewed_journal.json')
    _regular(p)
    if _hash_file(p) != EXPECTED_JOURNAL_SHA256:
        raise ValueError('The bundled reviewed_journal.json is absent or changed; do not replace its contents.')
    return json.loads(p.read_text())


def _check_record(record: dict, expected: dict) -> None:
    # Permit exactly the native terminal state for idempotent inspection only.
    if record == expected:
        return
    terminal = dict(expected, state='rolled_back')
    if record == terminal:
        return
    raise ValueError('Live journal differs from the reviewed transaction. No recovery was attempted. '
                     'Do not edit the journal to match this helper.')


def _runtime(controller) -> dict:
    if controller is None or not callable(getattr(controller, 'snapshot', None)):
        raise ValueError('Pass the EXISTING ProjectCenter object as controller=pc. Do not construct another one.')
    source = Path(inspect.getfile(type(controller))).resolve()
    package_root = source.parents[2]
    for rel, expected_hash in EXPECTED_SOURCES.items():
        f = package_root / rel
        _regular(f)
        if _hash_file(f) != expected_hash:
            raise ValueError(f'Installed source changed since the evidence review: {f}. No code was patched.')
    tx = importlib.import_module('vhd.persistence.transaction')
    spatial = importlib.import_module('vhd.persistence.spatial')
    manifest = importlib.import_module('vhd.control.manifest')
    core = importlib.import_module('vhd.core')
    for module, rel in ((tx, 'vhd/persistence/transaction.py'), (spatial, 'vhd/persistence/spatial.py')):
        if Path(module.__file__).resolve() != (package_root / rel).resolve():
            raise RuntimeError('Controller and persistence module come from different package roots.')
    # A loaded older function must not be substituted for the reviewed disk source.
    for function, rel in ((tx.recover_transaction, 'vhd/persistence/transaction.py'),
                          (spatial.refresh_metadata, 'vhd/persistence/spatial.py')):
        if Path(inspect.getfile(function)).resolve() != (package_root / rel).resolve():
            raise RuntimeError('Recovery function source path does not match reviewed package.')
    snapshot = controller.snapshot()
    project = snapshot['project']
    rows = [r for r in project['rows'] if r['sample_key'] == SAMPLE]
    if len(rows) != 1:
        raise ValueError('Selected sample is missing/ambiguous in this controller.')
    row = rows[0]
    cfg, _ = manifest.row_config(project, row)
    layout = manifest.sample_layout(project, row)
    store = Path(layout['store']).resolve()
    if store != STORE.resolve():
        raise ValueError('This controller maps the sample to a different master; no path override is allowed.')
    policy = cfg['storage_policy']
    tx.validate_store(store, policy)  # preserve installed approved-root policy
    txdir = store.parent / (store.name + '.vhd_transactions') / TRANSACTION_ID
    for path in (txdir.parent, txdir):
        if path.is_symlink():
            raise ValueError(f'Symlinked transaction directory: {path}')
    return dict(tx=tx, spatial=spatial, core=core, policy=policy,
                store=store, txdir=txdir, journal=txdir/'journal.json',
                work=Path(layout['work']), project_root=package_root,
                config_digest=_json_hash(cfg['storage_policy']))


def _lock_info(path: Path) -> dict:
    if not path.exists() and not path.is_symlink():
        return dict(path=str(path), exists=False)
    _regular(path)
    if path.stat().st_size > 64 * 1024:
        raise ValueError(f'Unexpectedly large lock file: {path}')
    data = path.read_bytes()
    text = data.decode('utf-8', errors='replace')
    try:
        owner = json.loads(text)
    except (ValueError, TypeError):
        owner = None
    pid = owner.get('pid') if isinstance(owner, dict) else owner if isinstance(owner, int) else None
    if isinstance(pid, bool) or not isinstance(pid, int) or pid <= 0:
        pid = None
    alive = None
    process_detail = None
    if pid is not None:
        import psutil
        alive = psutil.pid_exists(pid)
        if alive:
            try:
                p = psutil.Process(pid)
                process_detail = dict(name=p.name(), create_time=p.create_time(), command=p.cmdline())
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                process_detail = 'Exists or could not be inspected; do not assume stale.'
    st = path.stat()
    return dict(path=str(path), exists=True, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                mtime_ns=st.st_mtime_ns, contents=text, owner_pid=pid,
                owner_pid_exists_in_this_namespace=alive, local_process=process_detail,
                caveat='Lock contains no reliable host/namespace identity. Local PID absence is not proof of global inactivity.')


def _worker_scan() -> dict:
    import psutil
    matches, denied = [], 0
    for p in psutil.process_iter(['pid', 'cmdline']):
        try:
            cmd = p.info.get('cmdline') or []
            if p.pid == os.getpid():
                continue
            text = ' '.join(cmd)
            if 'vhd.compute.worker' in text:
                # Any such worker is a conservative reason to wait; no processes are killed.
                matches.append(dict(pid=p.pid, command=cmd))
        except psutil.AccessDenied:
            denied += 1
        except (psutil.NoSuchProcess, psutil.ZombieProcess):
            pass
    return dict(visible_vhd_workers=matches, inaccessible_processes=denied,
                host=socket.gethostname(), kernel_pid=os.getpid(),
                limitation='Does not detect remote readers/writers or arbitrary direct scripts; manual quiescence confirmation is required.')


def _journal_inventory(rt: dict) -> list:
    rows = []
    for p in sorted(rt['txdir'].parent.glob('*/journal.json')):
        _regular(p)
        d = json.loads(p.read_text())
        rows.append(dict(path=str(p), state=d.get('state'), sha256=_hash_file(p)))
    return rows


def _assess_live(live: Path, incoming: Path, expected: list, tx) -> dict:
    _safe_tree(incoming, incoming.parent)
    _safe_tree(live, live.parent)
    print('Verifying the retained incoming image against its recorded file hashes...', flush=True)
    inc = tx.inventory(incoming)
    if inc != expected:
        raise ValueError('Retained incoming image does not match the journal hashes. No rollback allowed by this helper.')
    if not live.exists():
        return dict(kind='absent', allow_partial=False, live_inventory=None,
                    incoming_inventory=inc, live_files=0, live_bytes=0, missing_files=len(inc), prefix_files=[])
    print('Checking the live image: exact copy, missing chunks, or verified shorter prefixes only...', flush=True)
    current = tx.inventory(live)
    if current == expected:
        return dict(kind='complete_copy_not_committed', allow_partial=False, live_inventory=current,
                    incoming_inventory=inc, live_files=len(current), live_bytes=sum(e['bytes'] for e in current),
                    missing_files=0, prefix_files=[])
    expected_by_path = {e['path']: e for e in expected}
    if len(expected_by_path) != len(expected):
        raise ValueError('Duplicate manifest path.')
    prefixes = []
    for entry in current:
        relative = entry['path']
        if relative not in expected_by_path:
            raise ValueError(f'Unexpected live file {relative!r}; this may be a newer edit. No rollback.')
        want = expected_by_path[relative]
        if entry == want:
            continue
        if entry['bytes'] >= want['bytes']:
            raise ValueError(f'Unexpected live content in {relative!r}; it is not a verified interrupted copy.')
        staged_file = incoming / relative
        if _hash_file(staged_file, limit=entry['bytes']) != entry['sha256']:
            raise ValueError(f'Live {relative!r} differs from the retained incoming prefix. No rollback.')
        prefixes.append(dict(path=relative, live_bytes=entry['bytes'], expected_bytes=want['bytes']))
    return dict(kind='verified_partial_incoming_copy', allow_partial=True, live_inventory=current,
                incoming_inventory=inc, live_files=len(current), live_bytes=sum(e['bytes'] for e in current),
                missing_files=len(expected)-len(current), prefix_files=prefixes)


def _build_plan(rt: dict, controller) -> dict:
    expected = _expected_record()
    j = rt['journal']; _regular(j)
    raw = j.read_bytes(); record = json.loads(raw)
    _check_record(record, expected)
    if Path(record['master']).resolve() != rt['store']:
        raise ValueError('Journal master and configured master disagree.')
    ops = record['operations']
    if len(ops) != 1 or ops[0]['relative'] != RELATIVE or ops[0]['existed'] is not False:
        raise ValueError('Only the reviewed, single new-image transaction is supported.')
    incoming = rt['txdir']/'incoming'/RELATIVE
    live = rt['tx'].target(rt['store'], RELATIVE)
    _no_symlink_components(rt['txdir'], incoming)
    _no_symlink_components(rt['store'], live)
    inventory = _journal_inventory(rt)
    others = [r for r in inventory if Path(r['path']) != j and r['state'] not in ('committed','rolled_back')]
    if others:
        raise RuntimeError(f'Other unresolved transactions require separate review: {others}')
    snap = controller.snapshot()
    jobs = snap.get('jobs',{}).get(SAMPLE,{})
    running = [a for a, rec in jobs.items() if rec.get('status') == 'running']
    lock = _lock_info(rt['store'].parent/(rt['store'].name+'.vhd_writer.lock'))
    worker_locks = [_lock_info(p) for p in sorted(rt['work'].glob('.worker_*.lock'))]
    process_scan = _worker_scan()
    if record['state'] == 'rolled_back':
        # Never remove a newly reimported image when this historical journal is terminal.
        return dict(schema=VERSION, status='already_rolled_back_no_action', journal=str(j),
                    journal_sha256=hashlib.sha256(raw).hexdigest(), store=str(rt['store']),
                    live_component_exists_now=live.exists(), writer_lock=lock,
                    explanation='This old transaction needs no further rollback. Use normal transfer validation.')
    print(f'Journal: {j}\nScope: one NEW element, {RELATIVE}', flush=True)
    assessment = _assess_live(live, incoming, ops[0]['incoming'], rt['tx'])
    if j.read_bytes() != raw:
        raise RuntimeError('Journal changed during inspection; no plan produced.')
    native_preview = rt['tx'].recover_transaction(j, rt['policy'], execute=False,
                          single_writer_ack=False, allow_partial=assessment['allow_partial'])
    plan = dict(schema=VERSION, status='preview_only', sample=SAMPLE, journal=str(j),
                journal_sha256=hashlib.sha256(raw).hexdigest(), journal_state=record['state'],
                store=str(rt['store']), operation=RELATIVE, existed_before=False,
                assessment=assessment, native_preview=native_preview, writer_lock=lock,
                worker_locks=worker_locks, process_scan=process_scan, controller_running_actions=running,
                policy_digest=rt['config_digest'], journal_inventory=inventory)
    plan['plan_id'] = _json_hash(plan)
    return plan


def preview(controller) -> dict:
    """Read-only checks. Hashes about 420 MiB of staged image plus the existing live copy."""
    rt = _runtime(controller)
    plan = _build_plan(rt, controller)
    if plan['status'] == 'already_rolled_back_no_action':
        print(json.dumps(plan, indent=2), flush=True)
        return plan
    brief = {k: v for k,v in plan.items() if k not in ('assessment','journal_inventory')}
    brief['image_summary'] = {k:v for k,v in plan['assessment'].items() if not k.endswith('_inventory')}
    brief['image_summary']['incoming_bytes'] = sum(e['bytes'] for e in plan['assessment']['incoming_inventory'])
    print(json.dumps(brief, indent=2), flush=True)
    print('PREVIEW ONLY. No journal, lock, image, or scientific output was changed.', flush=True)
    return plan


def _check_quiescence(plan: dict) -> None:
    if plan.get('controller_running_actions'):
        raise RuntimeError('Controller has a running action; inspect it before recovery.')
    if plan.get('worker_locks'):
        raise RuntimeError('A worker-stage lock exists. This helper does not clear worker-stage locks.')
    if plan.get('process_scan',{}).get('visible_vhd_workers'):
        raise RuntimeError('A local vhd worker is visible. Stop/wait/review it separately; this helper never kills processes.')
    lock=plan['writer_lock']
    if lock.get('owner_pid_exists_in_this_namespace'):
        raise RuntimeError('Recorded writer-lock PID exists locally. It may be active or reused; resolve identity before recovery.')


def rollback_reviewed_image(plan: dict, controller, *,
        confirmed_no_readers_or_writers: bool = False,
        confirmed_rollback_new_image: bool = False,
        archive_confirmed_stale_writer_lock: bool = False,
        reviewer: str = '', verification_note: str = '') -> dict:
    """Preserve live image, then call native rollback+metadata refresh.

    The two confirmations concern ALL readers/writers sharing this master, not
    just visible processes. Archiving a native writer lock is separately opt-in.
    Controller locks are not bypassed; native writer locking remains in use.
    """
    if not (confirmed_no_readers_or_writers and confirmed_rollback_new_image):
        raise PermissionError('Confirm no concurrent readers/writers and deliberate rollback of the new image. No change made.')
    if not reviewer.strip() or not verification_note.strip():
        raise ValueError('Supply reviewer and actual verification evidence. No change made.')
    if plan.get('schema') != VERSION:
        raise ValueError('Use a preview from this helper.')
    if plan.get('status') == 'already_rolled_back_no_action':
        raise ValueError('Journal is already rolled back; do not run recovery again.')
    _check_quiescence(plan)
    rt = _runtime(controller)
    # Cooperating ProjectCenter launchers use this same exclusive controller lock.
    # Native recover_transaction subsequently acquires the separate store writer lock.
    with controller.store.exclusive():
        fresh = _build_plan(rt, controller)
        if fresh.get('status') == 'already_rolled_back_no_action':
            return dict(status='already_rolled_back_no_action', jobs_launched=False)
        stable_fields = ('journal_sha256','store','operation','policy_digest','journal_inventory')
        if any(fresh[k] != plan[k] for k in stable_fields):
            raise RuntimeError('Journal/policy/transactions changed after preview. Inspect again.')
        if fresh['assessment'] != plan['assessment'] or fresh['writer_lock'] != plan['writer_lock']:
            raise RuntimeError('Live/staged image or writer lock changed after preview. Inspect again.')
        _check_quiescence(fresh)
        if fresh['writer_lock']['exists'] and not archive_confirmed_stale_writer_lock:
            raise PermissionError('The native .vhd_writer.lock still exists. Only after verifying its owner '
                                  'has stopped, explicitly set archive_confirmed_stale_writer_lock=True. '
                                  'No source changed.')
        when=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        audit=rt['txdir']/'recovery_audits'/(when+'_'+uuid.uuid4().hex[:10])
        audit.mkdir(parents=True, exist_ok=False)
        _save(fresh,audit/'verified_plan.json')
        (audit/'journal_before.json').write_bytes(rt['journal'].read_bytes())
        receipt=dict(schema=VERSION,phase='preserving_evidence',audit_dir=str(audit),
                     reviewer=reviewer,verification_note=verification_note,
                     store=str(rt['store']),journal=str(rt['journal']),operation=RELATIVE,
                     input_state=fresh['journal_state'],
                     allow_partial=fresh['assessment']['allow_partial'],jobs_launched=False,
                     controller_state_manually_changed=False,package_source_changed=False,
                     writer_lock_archived=False)
        _save(receipt,audit/'recovery_receipt.json')
        live=rt['tx'].target(rt['store'],RELATIVE)
        try:
            if live.exists():
                print('Preserving the live image component before native rollback...',flush=True)
                rt['tx'].copy_verified(live,audit/'live_before'/RELATIVE)
                if rt['tx'].inventory(audit/'live_before'/RELATIVE)!=fresh['assessment']['live_inventory']:
                    raise RuntimeError('Live-image preservation no longer matches preview; no rollback.')
            # Recheck both sides after the preservation copy. No unreviewed live bytes may be removed.
            if (rt['tx'].inventory(live) if live.exists() else None)!=fresh['assessment']['live_inventory']:
                raise RuntimeError('Live image changed while preserving it; no rollback.')
            if rt['tx'].inventory(rt['txdir']/'incoming'/RELATIVE)!=fresh['assessment']['incoming_inventory']:
                raise RuntimeError('Incoming image changed while preserving evidence; no rollback.')
            if _hash_file(rt['journal'])!=fresh['journal_sha256']:
                raise RuntimeError('Journal changed; no rollback.')
            current_lock=_lock_info(Path(fresh['writer_lock']['path']))
            if current_lock!=fresh['writer_lock']:
                raise RuntimeError('Writer lock changed; no rollback.')
            check=dict(fresh,process_scan=_worker_scan(),worker_locks=[_lock_info(p) for p in rt['work'].glob('.worker_*.lock')])
            _check_quiescence(check)
            if current_lock['exists']:
                lock=Path(current_lock['path'])
                receipt['phase']='archiving_reviewed_stale_writer_lock'
                _save(receipt,audit/'recovery_receipt.json')
                archived=audit/'writer_lock_before.json'
                # No removal/copy fallback on a mounted filesystem: a rename failure stops here.
                lock.rename(archived)
                if lock.exists() or _hash_file(archived)!=current_lock['sha256']:
                    raise RuntimeError('Writer-lock archival check failed; no native rollback invoked.')
                receipt['writer_lock_archived']=True
            receipt['phase']='native_rollback_started'
            _save(receipt,audit/'recovery_receipt.json')
            print('Calling installed recover_transaction(rollback), then native metadata consolidation. Do not interrupt.',flush=True)
            returned=rt['tx'].recover_transaction(
                rt['journal'],rt['policy'],execute=True,single_writer_ack=True,
                allow_partial=fresh['assessment']['allow_partial'],refresh=rt['spatial'].refresh_metadata)
            after=json.loads(rt['journal'].read_text())
            expected_after=dict(_expected_record(),state='rolled_back')
            if after!=expected_after or returned.get('state')!='rolled_back' or live.exists():
                raise RuntimeError('Native rollback did not meet the expected postconditions. Do not retry transfer.')
            if rt['tx'].inventory(rt['txdir']/'incoming'/RELATIVE)!=fresh['assessment']['incoming_inventory']:
                raise RuntimeError('Retained incoming image changed unexpectedly after rollback.')
            remaining=[r for r in _journal_inventory(rt) if r['state'] not in ('committed','rolled_back')]
            if remaining:
                raise RuntimeError(f'Unresolved transactions remain: {remaining}')
            (audit/'journal_after.json').write_bytes(rt['journal'].read_bytes())
            receipt.update(phase='rollback_complete',journal_state='rolled_back',
                           live_new_image_absent=True,retained_incoming_verified=True,
                           refresh_returned_successfully=True,
                           validation_scope='Native metadata consolidation and exact component/journal checks; not a full count-array/biological revalidation.')
            _save(receipt,audit/'recovery_receipt.json')
            print(json.dumps(receipt,indent=2),flush=True)
            return receipt
        except BaseException as exc:
            receipt.update(phase='recovery_failed_requires_review',error=repr(exc))
            try:_save(receipt,audit/'recovery_receipt.json')
            except Exception:pass
            print(f'Recovery stopped. Preserve everything. Audit: {audit}',flush=True)
            raise
