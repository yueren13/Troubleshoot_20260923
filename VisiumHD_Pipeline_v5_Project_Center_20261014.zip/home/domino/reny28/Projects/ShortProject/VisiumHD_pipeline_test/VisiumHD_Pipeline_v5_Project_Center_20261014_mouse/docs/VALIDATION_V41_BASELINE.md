# v4.1 validation — September 30, 2026

## Actually executed on this source build

| Check | Result |
|---|---|
| Full available pytest collection | **214 passed, 7 skipped** |
| Python static parsing | **74 files passed** |
| Notebook format | **22 source-only notebooks passed** |
| Notebook code compilation | **90 cells passed** |
| CSV structure | **17 active/config CSV files passed** |
| New starter configuration pairs | Default, raw-three and mixed-entry schemas/routes/policies passed with temporary approved roots |
| Synthetic discovery/signal demo | 4 categories discovered from one XML file, 1 binary TIFF, 324 illustrative bin footprints; conserved fractional binary sum = 7 native positive pixels |

Full pytest output, static report, configuration report, demo evidence and package
versions are included beside this file. These totals belong to this build only;
do not add prior v4/v3/patch test totals.

## What the tests cover

Inherited control/numerical tests plus new cases for exact category discovery,
commas and reserved words in category names, one-source mixed-use choices, unknown
names, nullable independent memberships, union/exclusion and coverage rules,
source/selection approval invalidation, category removal, unchanged source files,
optional dataset identity, sample aliases, actual X/Y dimension ratios, hint mismatch,
pixel-convention offsets, landmark fits, affine/rotated footprints, weighted medians,
NaN/coverage/limits, conservation of fractional source-pixel sums, and min/max cell
summaries. Source hashing is performed once per active physical source per transfer
specification rather than once for every derived category.

The metadata-transfer orchestration tests use actual XML/TIFF calculations but
**explicitly stub parquet/master read/write calls**. They demonstrate which obs
columns and settings are sent to the writer, not a real SpatialData roundtrip.
The synthetic demo does not create a master, read RNA or approve real data.

## The seven skips are not seven remaining scientific assertions

Five entire optional modules were skipped because anndata was unavailable:
`test_resume_optional.py`, `test_spatial_optional.py`,
`test_v3_spatial_optional.py`, `test_v4_spatial_optional.py`, and
`test_v41_spatial_optional.py`. A module-level skip can contain multiple tests.
Two opt-in scVI tests were also skipped. SpatialData and the target GPU packages
were not available for end-to-end execution here.

The new optional scientific test builds a tiny actual SpatialData store, transfers
all five signal summaries into bin obs, reopens it, and compares X component bytes.
It must run in the target environment; its presence is not a passing result.

## Not executed or established

Actual new sample .annotations/TIFF compatibility; real image registration accuracy;
new-source import into the user's master stores; full-slide runtime and memory;
registered bin/cell readback; approved-mount transaction recovery; Proseg/StarDist;
scVI fit/save/load/DDP; RAPIDS/Dask; or full-cohort scientific validity.
No institutional mount was accessed, no packages in the user's environment were
changed, no GitHub write occurred and no original supplied artifact was modified.

## Target checks before scientific interpretation

Run 99 and inspect which scientific tests actually execute. Then discover the real
source names and scale, import/inspect source and category overlays, approve explicit
choices, verify chosen obs and coverage distributions, and only then use QC regions
for segmentation. Inspect a known boundary/NoData patch and a signal grid edge.
Keep raw counts, sample IDs and output destinations unchanged unless a deliberate
new-run/migration change is selected. Do not turn review flags true to bypass errors.
