# v4.1 source and API provenance

The implementation is based on the actually delivered v4 archive, the user's
pasted/attached legacy helpers and the current requested workflow. No real new
annotation or signal file was supplied for this change. No private project inputs
or corporate template assets are included in the source bundle.

Primary references consulted for related data-model/resampling conventions:
- https://spatialdata.scverse.org/en/stable/tutorials/notebooks/notebooks/examples/transformations.html
- https://anndata.readthedocs.io/en/stable/generated/anndata.AnnData.layers.html
- https://anndata.readthedocs.io/en/stable/generated/anndata.AnnData.html
- https://scikit-image.org/docs/stable/api/skimage.transform.html

The new footprint statistics use custom overlap arithmetic / Shapely intersections;
they are not a claim to call skimage.resize or to estimate image-content registration.
Source-code and optional runtime compatibility checks remain separate from docs.

## Prior API references

> Retained v3 technical reference. For the consolidated v4 setup and changed behavior, read START_HERE.md, ASSETS_V4.md and IMAGE_AND_ANALYSIS_V4.md first.

# Source provenance / APIs consulted

User-provided source: cfs_202412.py, cfs_spatialdata_202412.py, cfs_normhe_202605.py,
and the fixed-reference H&E functions pasted into the conversation. The test fixture
preserves that latter code for numerical comparison. No original biological data,
patient/sample deployment manifests, or executed notebook image outputs are included.

The v2 baseline helpers and compute launchers are retained except for documented changes.

Primary documentation consulted (2026-09-28):
- https://spatialdata.scverse.org/en/stable/api/SpatialData.html
- https://spatialdata.scverse.org/en/stable/tutorials/notebooks/notebooks/examples/spatialdata_format.html
- https://anndata.readthedocs.io/en/stable/generated/anndata.io.write_elem.html
- https://anndata.readthedocs.io/en/stable/tutorials/zarr-v3.html
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.ndimage.map_coordinates.html
- https://docs.scvi-tools.org/en/stable/user_guide/use_case/multi_gpu_training.html
- https://david-barnett.github.io/microViz/reference/distinct_palette.html

Palette attribution and limits remain those of the v2 implementation: microViz
brewerPlus colors plus explicitly identified optional extensions beyond 41 classes.
No new software license or institutional compliance claim is introduced.
