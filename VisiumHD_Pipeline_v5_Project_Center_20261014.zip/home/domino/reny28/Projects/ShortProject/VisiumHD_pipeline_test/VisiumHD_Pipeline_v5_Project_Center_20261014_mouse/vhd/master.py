"""Stable canonical master, selective annotation refresh, and optional analysis tables."""
from __future__ import annotations
import copy,json
from pathlib import Path
import numpy as np
import pandas as pd


def effective_bin_obs(p):
    candidate=p['work']/'bins_annotated_obs.parquet'
    return candidate if candidate.exists() else p['bin_obs']


def transfer_config(cfg,p):
    cfg=copy.deepcopy(cfg);report=p['report']/'assets_transfer.json'
    if report.exists():
        extra=json.loads(report.read_text())['transfer_spec'];base=cfg['metadata_transfer']
        if isinstance(base['categorical'],list):base['categorical']={k:{} for k in base['categorical']}
        base['categorical'].update(extra['categorical']);base['boolean']=list(dict.fromkeys(base['boolean']+extra['boolean']));base['continuous'].update(extra['continuous']);base.setdefault('boolean_options',{}).update(extra.get('boolean_options',{}))
    return cfg


def current_annotations(cfg,spec):
    if not spec.get('_row',{}).get('assets_manifest'):
        from .core import sample_paths
        pp=sample_paths(cfg,spec)
        if (pp['report']/'assets_transfer.json').exists():raise RuntimeError('Previously transferred assets exist but the manifest was removed. Keep the manifest and mark sources reference_only/disabled, then explicitly retransfer to clear owned columns.')
        return
    from .core import sample_paths,file_stamp
    from .annotations.workflow import asset_specification,read_assets,active_assets
    p=sample_paths(cfg,spec);f=p['report']/'assets_transfer.json'
    if not f.exists() and not active_assets(read_assets(spec['_row']['assets_manifest'],spec['dataset_id'],spec['sample_id'])):
        if cfg.get('prior_filter',{}).get('mode')=='from_review':cfg['prior_filter']['enabled']=False
        return
    if not f.exists():raise RuntimeError('Transfer reviewed annotations before downstream processing.')
    receipt=json.loads(f.read_text());derived=p['work']/'bins_annotated_obs.parquet'
    if receipt.get('signature')!=asset_specification(cfg,spec)[1]:raise RuntimeError('Asset sources, measurement/transfer settings, or base QC changed. Review/retransfer annotations before downstream processing.')
    if not derived.is_file() or receipt.get('derived_stamp')!=file_stamp(derived):raise RuntimeError('Transferred bin annotations changed or are incomplete. Recompute the transfer before downstream processing.')
    if cfg.get('prior_filter',{}).get('mode')=='from_review':
        cfg['prior_filter']=copy.deepcopy(receipt['prior_filter'])


def store_he_maps(cfg,spec):
    from .bin_master import assert_destination_identity
    assert_destination_identity(cfg,spec)
    import spatialdata as sd
    from .annotations.raster import spatial_image
    from .core import sample_paths,dump_json
    from .persistence import persist_changes,update_table_metadata
    p=sample_paths(cfg,spec);f=p['work']/'he_fixed/measurement.json';receipt=p['report']/'he_master.json'
    if not f.exists():return
    record=json.loads(f.read_text())
    if receipt.exists() and json.loads(receipt.read_text()).get('signature')==record['signature']:return
    s=sd.read_zarr(p['store'],selection=('images','labels','shapes','points'));new=[];replace=[]
    for name,path in record['maps'].items():
        name=name if name.startswith('he_') else 'he_'+name
        s.images[name]=spatial_image(path,'yx',None,record['source_to_fullres'],name)
        (replace if (p['store']/'images'/name).exists() else new).append(name)
    persist_changes(s,new_elements=new,replace_elements=replace,policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=cfg['storage'].get('single_writer_ack',False))
    update_table_metadata(p['store'],'bins_2um',uns={'vhd_he_measurement_json':json.dumps(record,sort_keys=True)},policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=cfg['storage'].get('single_writer_ack',False))
    dump_json({'signature':record['signature'],'elements':new+replace},receipt)


def assemble_master(cfg,spec,bins_only=False):
    from .bin_master import assert_destination_identity
    assert_destination_identity(cfg,spec)
    from .core import sample_paths,file_stamp,dump_json
    from .adapters.assemble import assemble,validate_product
    from .io import table_metadata
    from .persistence import update_table_metadata,persist_changes
    from .sample_metadata import attach_sample_metadata,sync_sample_metadata
    cfg=copy.deepcopy(cfg)
    if bins_only:cfg['cells']['mode']='none'
    p=sample_paths(cfg,spec);receipt=p['report']/'master_sources.json';marker=p['report']/'storage_manifest.json'
    if not cfg['storage'].get('single_writer_ack',False):raise PermissionError('Review master destination and set storage.single_writer_ack=true; no concurrent readers/writers.')
    binsource=file_stamp(p['bins']) if p['bins'].exists() else None
    cellsource=file_stamp(p['cells']) if cfg['cells']['mode']!='none' and p['cells'].exists() else None
    if not p['store'].exists():
        result=assemble(cfg,spec);dump_json({'cell_source':cellsource,'bin_source':binsource},receipt);store_he_maps(cfg,spec);return result
    if not marker.exists() or not receipt.exists():raise RuntimeError('Existing master is not tracked by this v3 workspace. Use explicit notebook 13 for legacy metadata updates, or import to a new canonical master. No automatic overwrite/adoption.')
    old=json.loads(receipt.read_text())
    if binsource and old.get('bin_source') is not None and binsource!=old['bin_source']:
        raise RuntimeError('Prepared bin counts changed. Use a NEW master; annotation-only sync must not replace or ignore changed expression.')
    import zarr
    from .compact_images import validate_images
    live_policy=zarr.open_group(str(p['store']),mode='r').attrs.get('image_storage',{}).get('policy','original')
    if live_policy!=cfg['storage'].get('image_policy','original'):
        raise RuntimeError('Image storage policy differs from this existing master. Use a NEW master; no implicit compaction.')
    if (p['store']/'tables/bins_2um').exists():
        obs=pd.read_parquet(effective_bin_obs(p));live,_=table_metadata(p['store'],'bins_2um')
        if not live.index.equals(obs.index):raise ValueError('Bin identities changed; annotation-only update cannot replace the population.')
        changed=[c for c in obs if c not in ('region','instance_id') and (c not in live or not obs[c].equals(live[c]))]
        if changed:update_table_metadata(p['store'],'bins_2um',obs=obs[changed],policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=True)
    if cellsource and cellsource!=old.get('cell_source'):
        if (p['store']/'tables/cells').exists():raise RuntimeError('Cell input changed. Use annotation-only refresh for metadata or a NEW master for changed expression/populations. No implicit counts replacement.')
        import anndata as ad,spatialdata as sd,geopandas as gpd
        from spatialdata.models import ShapesModel
        from spatialdata.transformations import Identity
        from .storage import parse_table
        a=ad.read_h5ad(p['cells']);attach_sample_metadata(a,spec);geom=p['work']/'cell_geometry.json'
        info=json.loads(geom.read_text()) if geom.exists() else {'region':'cell_boundaries','coordinate_system':'fullres'}
        region=info['region']
        if region=='cell_boundaries':g=gpd.read_parquet(p['polygons'])
        else:g=gpd.GeoDataFrame({'radius':np.ones(a.n_obs)},geometry=gpd.points_from_xy(a.obsm['spatial'][:,0],a.obsm['spatial'][:,1]),index=a.obs_names)
        if not g.index.astype(str).equals(a.obs_names):raise ValueError('Cell geometry identity/order mismatch.')
        s=sd.read_zarr(p['store'],selection=('images','labels','shapes','points'))
        s.shapes[region]=ShapesModel.parse(g,transformations={info['coordinate_system']:Identity()});s.tables['cells']=parse_table(a,region,a.obs_names.astype(str))
        persist_changes(s,new_elements=[region,'cells'],policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=True)
        old['cell_source']=cellsource;dump_json(old,receipt)
    sync_sample_metadata(cfg,spec,execute=True)
    store_he_maps(cfg,spec)
    from .bin_master import sync_optional_prior
    sync_optional_prior(cfg,spec)
    result=validate_product(p['store']);m=json.loads(marker.read_text());m['validation']=result;dump_json(m,marker);return result


def refresh_cell_annotations(cfg,spec):
    from .bin_master import assert_destination_identity
    assert_destination_identity(cfg,spec)
    import spatialdata as sd
    from spatialdata.transformations import get_transformation
    from .annotations.geometry import transform_polygons
    from .annotations.transfer import aggregate_annotations
    from .cells import geometric_assign
    from .core import sample_paths,dump_json
    from .io import table_metadata
    from .persistence import update_table_metadata
    current_annotations(cfg,spec);p=sample_paths(cfg,spec)
    if not cfg['metadata_transfer']['enabled']:return {'status':'metadata_transfer_disabled'}
    bins=pd.read_parquet(effective_bin_obs(p));obs,_=table_metadata(p['store'],'cells')
    regions=obs.region.astype(str).unique()
    if len(regions)!=1 or regions[0]!='cell_boundaries':raise ValueError('Annotation transfer requires real cell polygons, not centroid glyphs.')
    s=sd.read_zarr(p['store'],selection=('shapes',));g=s.shapes[regions[0]];ids=pd.Index(obs.instance_id.astype(str))
    if not ids.is_unique or not ids.isin(g.index.astype(str)).all():raise ValueError('Invalid cell-to-boundary links.')
    transform=get_transformation(g,to_coordinate_system='fullres').to_affine_matrix(input_axes=('x','y'),output_axes=('x','y'))
    g=transform_polygons(g.loc[ids],transform);settings=transfer_config(cfg,p)['metadata_transfer']
    assignment=geometric_assign(bins[['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy(),g,settings['chunk_size'])
    if settings['bin_scope']=='qc_keep_only':assignment[~bins.qc_keep.to_numpy(bool)]=-1
    elif settings['bin_scope']!='all_bins':raise ValueError('bin_scope: all_bins or qc_keep_only.')
    columns=aggregate_annotations(bins,assignment,len(obs),settings);columns.index=obs.index
    receipt=p['report']/'cell_annotation_refresh.json';old=json.loads(receipt.read_text()) if receipt.exists() else {}
    drop=[c for c in old.get('owned_columns',[]) if c not in columns and c in obs]
    update_table_metadata(p['store'],'cells',obs=columns,drop_obs=drop,policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=cfg['storage'].get('single_writer_ack',False))
    columns.to_parquet(p['report']/'cell_annotation_refresh.parquet')
    result={'n_cells':len(obs),'n_assigned_bin_centers':int((assignment>=0).sum()),'n_ambiguous_bins':int((assignment==-2).sum()),'owned_columns':list(columns),'counts_rewritten':False}
    dump_json(result,receipt);return result
