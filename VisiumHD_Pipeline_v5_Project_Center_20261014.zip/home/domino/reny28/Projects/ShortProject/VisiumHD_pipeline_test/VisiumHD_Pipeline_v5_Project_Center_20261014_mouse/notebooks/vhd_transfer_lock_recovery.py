"""Inspect, then explicitly archive ONE reviewed orphaned transfer_assets lock.

Not a vhd API patch. No automatic worker termination, lock deletion, status edits,
output cleanup, configuration changes, or launches. Inspection never writes files.
Archive only after verifying no owner/child remains on any relevant host/container.
A local process list cannot prove remote/shared-mount quiescence.
"""
from __future__ import annotations

import hashlib
import json
import os
import shlex
import socket
import stat
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SAMPLE = 'Project__BM0164135A_s1_A1'
ACTION = 'transfer_assets'
LOCK_PATH = Path('/stash/results/dev/reny28/2026/VisiumHD_pipeline_test/work/vhd/'
                 'Project/BM0164135A_s1_A1/run01/work/.worker_transfer_assets.lock')
MAX_FILES = 64
MAX_BYTES = 256 * 1024


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _attributes(st: os.stat_result) -> dict:
    return dict(mode=int(st.st_mode), dev=int(st.st_dev), ino=int(st.st_ino),
                size=int(st.st_size), mtime_ns=int(st.st_mtime_ns))


def _snapshot(path: Path) -> dict:
    """Bounded inspection of a regular file or small lock directory; rejects links."""
    path = Path(path).expanduser().absolute()  # Do not resolve away a final symlink.
    if path.name != '.worker_transfer_assets.lock' and not path.name.endswith('.archived'):
        raise ValueError('This helper is limited to the transfer_assets lock or its archived copy.')
    entries = []
    total_bytes = 0

    def visit(p: Path, relative: str, depth: int = 0):
        nonlocal total_bytes
        if depth > 4 or len(entries) >= MAX_FILES:
            raise ValueError('Unexpectedly complex lock directory; manual review required.')
        before = p.lstat()
        attrs = _attributes(before)
        if stat.S_ISLNK(before.st_mode):
            raise ValueError(f'Refusing symlink in lock: {p}')
        if stat.S_ISREG(before.st_mode):
            if before.st_size > MAX_BYTES or total_bytes + before.st_size > MAX_BYTES:
                raise ValueError('Lock contents exceed the small-metadata limit; no archive attempted.')
            fd = os.open(str(p), os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
            with os.fdopen(fd, 'rb') as handle:
                if _attributes(os.fstat(handle.fileno())) != attrs:
                    raise RuntimeError('Lock changed while opening; inspect again after workers stop.')
                data = handle.read(MAX_BYTES + 1)
                after_read = _attributes(os.fstat(handle.fileno()))
            if len(data) > MAX_BYTES or after_read != attrs or _attributes(p.lstat()) != attrs:
                raise RuntimeError('Lock changed during inspection; do not recover it now.')
            total_bytes += len(data)
            entries.append(dict(relative=relative, kind='file', attributes=attrs,
                                sha256=hashlib.sha256(data).hexdigest(),
                                text_preview=data[:8192].decode('utf-8', errors='replace'),
                                preview_truncated=len(data) > 8192))
        elif stat.S_ISDIR(before.st_mode):
            entries.append(dict(relative=relative, kind='directory', attributes=attrs))
            for child in sorted(p.iterdir(), key=lambda x: x.name):
                rel = child.name if relative == '.' else relative + '/' + child.name
                visit(child, rel, depth + 1)
            if _attributes(p.lstat()) != attrs:
                raise RuntimeError('Lock directory changed during inspection; inspect again.')
        else:
            raise ValueError('Lock is not a regular file/small directory; no action taken.')

    visit(path, '.')
    content = [{k: e[k] for k in ('relative', 'kind', 'sha256') if k in e} for e in entries]
    return dict(path=str(path), entries=entries, total_bytes=total_bytes,
                identity=_digest(entries), content_digest=_digest(content))


def _owner_hints(snapshot: dict) -> list[dict]:
    """Report only explicit PID/host fields; do not assume their semantics or PID namespace."""
    hints = []
    for entry in snapshot['entries']:
        text = entry.get('text_preview', '').strip()
        if not text or entry.get('preview_truncated'):
            continue
        try:
            value = json.loads(text)
        except (ValueError, TypeError):
            value = None
        if isinstance(value, dict):
            useful = {k: v for k, v in value.items()
                      if k.lower() in ('pid', 'worker_pid', 'controller_pid', 'host', 'hostname',
                                       'process_id', 'started_at', 'created_at', 'sample', 'action')}
            if useful:
                hints.append(dict(file=entry['relative'], fields=useful))
        # Plain PID and key=value text are still displayed verbatim in snapshot previews.
    return hints


def scan_local_workers(sample: str) -> dict:
    """Read-only process check. Never equates absence of local matches with a stale lock."""
    import psutil
    workers = []
    inaccessible = []
    unknown_worker_commands = []
    for process in psutil.process_iter():
        if process.pid == os.getpid():
            continue
        try:
            argv = process.cmdline()
            if not argv:
                continue
            # A vhd module token is narrower than matching arbitrary notebook text.
            is_worker = 'vhd.compute.worker' in argv or any(
                a.endswith('/vhd/compute/worker.py') for a in argv)
            if not is_worker:
                continue
            def option(name):
                for i, arg in enumerate(argv):
                    if arg == name and i + 1 < len(argv):
                        return argv[i + 1]
                    if arg.startswith(name + '='):
                        return arg.split('=', 1)[1]
                return None
            worker_sample = option('--sample')
            record = dict(pid=process.pid, ppid=process.ppid(), status=process.status(),
                          started_epoch=process.create_time(), sample=worker_sample,
                          action=option('--action'), command=shlex.join(argv))
            if worker_sample is None:
                unknown_worker_commands.append(record)
            elif worker_sample == sample or worker_sample == sample.split('__')[-1]:
                workers.append(record)
        except (psutil.NoSuchProcess, psutil.ZombieProcess):
            continue
        except psutil.AccessDenied:
            inaccessible.append(process.pid)
    return dict(host=socket.gethostname(), kernel_pid=os.getpid(),
                matching_sample_workers=workers, unknown_sample_vhd_workers=unknown_worker_commands,
                inaccessible_pids=inaccessible,
                limitation='Current host/PID namespace only; not a check of other hosts or all possible launchers.')


def _jobs(controller: Any) -> dict:
    if not callable(getattr(controller, 'snapshot', None)):
        raise TypeError('Pass the existing ProjectCenter object pc, not a new controller.')
    state = controller.snapshot()
    if not isinstance(state.get('jobs'), dict):
        raise TypeError('Unexpected controller jobs structure; stop and inspect installed code.')
    return state['jobs']


def inspect_transfer_lock(controller: Any, *, lock_path: str | Path = LOCK_PATH,
                          sample: str = SAMPLE) -> dict:
    """Read state, lock metadata, contents, and local worker command lines. No writes."""
    path = Path(lock_path).expanduser().absolute()
    if path.name != '.worker_transfer_assets.lock':
        raise ValueError('Only .worker_transfer_assets.lock is accepted.')
    jobs = _jobs(controller)
    if sample not in jobs:
        raise KeyError(f'{sample} is absent from the controller jobs; verify the project.')
    job = jobs[sample].get(ACTION, {})
    try:
        snap = _snapshot(path)
    except FileNotFoundError:
        snap = None
    report = dict(schema='vhd-transfer-lock-inspection-1', inspected_at=_now(),
                  inspected_epoch=time.time(), sample=sample, action=ACTION, lock_path=str(path),
                  controller_job=dict(job), lock_snapshot=snap,
                  owner_hints=_owner_hints(snap) if snap else [],
                  local_process_scan=scan_local_workers(sample),
                  recovery_performed=False)
    print(json.dumps(report, indent=2, default=str))
    print('\nINSPECTION ONLY. No lock/state/output was changed. A local empty process list is not proof of no owner.')
    return report


def _write_json_new(path: Path, value: dict) -> None:
    with path.open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2, default=str)
        handle.write('\n')


def archive_reviewed_transfer_lock(report: dict, controller: Any, *,
                                   confirmed_worker_stopped: bool = False,
                                   confirmed_no_other_launchers: bool = False,
                                   reviewer: str = '', verification_note: str = '') -> dict:
    """Archive precisely the unchanged lock inspected above, under explicit review.

    Requires quiescence of owner, children, other controllers, and other hosts with
    shared access. Takes the existing controller's exclusive guard, but cannot
    prevent an independent external launcher that does not honor that guard.
    No kill/unlink/rmtree and no manual controller-status update is performed.
    """
    if confirmed_worker_stopped is not True or confirmed_no_other_launchers is not True:
        raise ValueError('Verify the lock owner/children have stopped and all other launchers are idle, '
                         'then explicitly set BOTH confirmations True. Nothing changed.')
    if not str(reviewer).strip() or not str(verification_note).strip():
        raise ValueError('A reviewer and factual worker/host verification note are required.')
    if report.get('schema') != 'vhd-transfer-lock-inspection-1' or report.get('action') != ACTION:
        raise ValueError('Use the unmodified report returned by inspect_transfer_lock.')
    if time.time() - report['inspected_epoch'] > 30 * 60:
        raise ValueError('Inspection is older than 30 minutes; inspect again before recovery.')
    path = Path(report['lock_path'])
    if path.name != '.worker_transfer_assets.lock':
        raise ValueError('Unexpected lock path.')
    if report.get('lock_snapshot') is None:
        raise ValueError('No lock was present in the inspection; do not archive anything.')
    sample = report['sample']
    # Ensure this failed job actually named this lock, not another project's path.
    old_job = report.get('controller_job', {})
    if old_job.get('status') != 'failed' or str(path) not in old_job.get('error', ''):
        raise ValueError('Expected a failed transfer_assets record naming this exact lock. '
                         'This helper is scoped to the failure shown in this conversation.')
    store = getattr(controller, 'store', None)
    if not callable(getattr(store, 'exclusive', None)):
        raise TypeError('This controller lacks the expected exclusive guard; nothing changed.')

    with store.exclusive():
        current_jobs = _jobs(controller)
        running = [(s, a) for s, actions in current_jobs.items() for a, j in actions.items()
                   if j.get('status') == 'running']
        if running:
            raise RuntimeError(f'Controller job(s) running: {running}; nothing archived.')
        current_job = current_jobs.get(sample, {}).get(ACTION, {})
        if current_job != old_job:
            raise RuntimeError('Controller job record changed since inspection; inspect again.')
        local = scan_local_workers(sample)
        if local['matching_sample_workers'] or local['unknown_sample_vhd_workers']:
            raise RuntimeError('A same-sample or unidentified vhd worker is still visible locally. '
                               'Inspect it first; nothing archived.\n' + json.dumps(local, indent=2))
        current = _snapshot(path)
        if current['identity'] != report['lock_snapshot']['identity']:
            raise RuntimeError('Lock metadata/contents changed since inspection; nothing archived.')

        # Sibling of work/, not inside the scientific work-product directory.
        history = path.parent.parent / 'worker_lock_recovery_history'
        history.mkdir(exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
        session = history / (stamp + '_' + uuid.uuid4().hex[:12])
        session.mkdir(exist_ok=False)
        archived = session / 'worker_transfer_assets.lock.archived'
        plan = dict(schema='vhd-single-lock-recovery-1', phase='prepared_not_yet_archived',
                    reviewer=str(reviewer).strip(), verification_note=str(verification_note).strip(),
                    prepared_at=_now(), original_lock=str(path), archived_lock=str(archived),
                    inspection=report, final_local_process_scan=local,
                    scope='Only this lock path; no controller-state/config/scientific-output edits; no process kill.')
        _write_json_new(session / 'recovery_plan.json', plan)
        # No copy/delete fallback: a failed filesystem rename remains a failure.
        try:
            if _snapshot(path)['identity'] != current['identity']:
                raise RuntimeError('Lock changed immediately before archive; aborting.')
            os.rename(path, archived)
            moved = _snapshot(archived)
            if moved['content_digest'] != current['content_digest']:
                raise RuntimeError('Archived content check failed. Inspect audit; do not retry automatically.')
            if os.path.lexists(path):
                raise RuntimeError('A lock exists again at the original path. Another launcher or filesystem '
                                   'behavior needs review; do not archive it repeatedly.')
            receipt = dict(phase='archived_verified', completed_at=_now(), sample=sample,
                           action=ACTION, archive=str(archived), audit_directory=str(session),
                           original_lock_absent=True, content_digest=moved['content_digest'],
                           controller_status_unchanged=current_job['status'], jobs_launched=False)
            _write_json_new(session / 'recovery_complete.json', receipt)
        except Exception as exc:
            _write_json_new(session / 'recovery_failure.json',
                            dict(at=_now(), error=f'{type(exc).__name__}: {exc}',
                                 original_lock_exists=os.path.lexists(path),
                                 archived_lock_exists=os.path.lexists(archived)))
            raise RuntimeError(f'Archive operation did not complete cleanly. Inspect {session}; '
                               'no automatic rollback, deletion or retry was performed.') from exc
    print(json.dumps(receipt, indent=2))
    print('One reviewed lock archived. No worker was started. Retry transfer through ProjectCenter normally.')
    return receipt
