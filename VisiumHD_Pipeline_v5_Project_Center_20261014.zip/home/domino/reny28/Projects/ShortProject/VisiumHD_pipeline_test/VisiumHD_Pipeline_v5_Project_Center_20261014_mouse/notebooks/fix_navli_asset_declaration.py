"""Correct a misdeclared, unprocessed ImageScope XML asset, without adopting geometry.

Two-phase: preview() is read-only; apply() changes only format/category_column in
one managed assets.csv row using the existing Center lock and commit. Original
annotations, choices, reviews, jobs, code, images and expression are not changed.
Read README before use. This is not a general source migration/repair API.
"""
from __future__ import annotations

import ast
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import gc
import hashlib
import importlib
import inspect
import io
import csv
import json
from pathlib import Path
import textwrap
import uuid

VERSION = 'vhd-xml-declaration-correction-20261014-r1'
OLD_CATEGORY = 'All categories are discovered; leave unwanted categories unselected after review.'
NEW_VALUES = {'format': 'imagescope_xml', 'category_column': 'name'}
PROTECTED_STATE = ('project', 'jobs', 'group_jobs', 'reviews', 'drafts', 'resume', 'endpoints')
PRE_ASSET_ACTIONS = {'ingest_raw', 'import_bins', 'measure_he', 'bin_qc', 'reuse_bin_qc',
                     'assemble_bins', 'replot'}
ASSET_HASH_ACTIONS = {'transfer_assets', 'refresh_cell_annotations', 'review_assets', 'stardist', 'proseg'}


def _hash(data):
    return hashlib.sha256(data).hexdigest()


def _json_hash(value):
    return _hash(json.dumps(value, sort_keys=True, default=str, separators=(',', ':')).encode())


def _find_center(pc):
    if pc is not None:
        if type(pc).__name__ != 'ProjectCenter' or type(pc).__module__ != 'vhd.center.controller':
            raise TypeError('Pass the existing vhd.center.controller.ProjectCenter object.')
        return pc
    found = {id(x): x for x in gc.get_objects()
             if type(x).__name__ == 'ProjectCenter' and type(x).__module__ == 'vhd.center.controller'}
    if len(found) != 1:
        raise RuntimeError(f'Found {len(found)} existing Centers. Pass the intended pc explicitly. No new Center was created.')
    return next(iter(found.values()))


def _native(pc):
    """Fail closed if the relevant native methods have changed since source review."""
    guard_path = Path(__file__).with_name('reviewed_source_guards.json')
    expected = json.loads(guard_path.read_text())
    functions = {}
    for name in expected:
        if name.startswith('ProjectCenter.'):
            functions[name] = getattr(type(pc), name.split('.', 1)[1])
        else:
            module, name_attr = name.rsplit('.', 1)
            functions[name] = getattr(importlib.import_module(module), name_attr)
    observed = {}
    for name, function in functions.items():
        parsed = ast.parse(textwrap.dedent(inspect.getsource(function)))
        observed[name] = _hash(ast.dump(parsed, include_attributes=False).encode())
    bad = [name for name in expected if observed[name] != expected[name]]
    if bad:
        raise RuntimeError('Reviewed native implementation differs: '+', '.join(bad)+
                           '. No correction performed; review the current source rather than bypassing this guard.')
    return (importlib.import_module('vhd.annotations.workflow'),
            importlib.import_module('vhd.annotations.discovery'),
            importlib.import_module('vhd.center.state'), observed)


def _stable_bytes(path, max_bytes):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'Expected a regular nonsymlink file: {path}')
    first = path.stat()
    if first.st_size > max_bytes:
        raise ValueError(f'{path} exceeds diagnostic size limit ({max_bytes} bytes).')
    data = path.read_bytes()
    last = path.stat()
    if (first.st_size, first.st_mtime_ns) != (last.st_size, last.st_mtime_ns):
        raise RuntimeError(f'File changed during inspection: {path}')
    return data


def _read_csv(data):
    r = csv.DictReader(io.StringIO(data.decode('utf-8-sig'), newline=''))
    fields, rows = r.fieldnames, list(r)
    if not fields or len(fields) != len(set(fields)) or any(None in x or any(v is None for v in x.values()) for x in rows):
        raise ValueError('Malformed asset manifest; no correction performed.')
    return fields, rows


def _csv_text(fields, rows):
    s = io.StringIO(newline='')
    w = csv.DictWriter(s, fieldnames=fields)
    w.writeheader(); w.writerows(rows)
    return s.getvalue()


def _active_jobs(state):
    return [(bucket, sample, action) for bucket in ('jobs', 'group_jobs')
            for sample, jobs in state.get(bucket, {}).items() for action, job in jobs.items()
            if isinstance(job, dict) and job.get('status') == 'running']


def _context(pc, sample, asset_id):
    wf, discovery, native_state, sources = _native(pc)
    state = pc.snapshot()
    if _active_jobs(state):
        raise RuntimeError('A Center job is still marked running. Finish/inspect it before a configuration change.')
    row = pc.row(sample, state['project']); key = row['sample_key']
    manifest = Path(row['assets_manifest']).expanduser().absolute()
    expected = Path(pc.workspace).absolute() / 'engine' / 'assets.csv'
    if manifest != expected:
        raise ValueError('This correction is limited to the Center-managed engine/assets.csv.')
    if any(p.is_symlink() for p in (Path(pc.workspace), manifest.parent, manifest)):
        raise ValueError('A workspace/engine/manifest symlink requires a separate review.')
    raw = _stable_bytes(manifest, 16 * 1024**2)
    fields, rows = _read_csv(raw)
    hits = [i for i, a in enumerate(rows) if a.get('sample_id', '').strip() == row['sample_id']
            and a.get('dataset_id', '').strip() in ('', row['dataset_id'])
            and a.get('asset_id', '').strip() == asset_id]
    if len(hits) != 1:
        raise ValueError('Expected exactly one matching raw assets.csv row.')
    i = hits[0]; original = rows[i]
    if not {'format', 'category_column'} <= set(fields):
        raise ValueError('Required fields are not present; no columns will be inferred/added.')
    if original['format'].strip() != 'reviewed_polygons_json' or original['category_column'].strip() != OLD_CATEGORY:
        raise ValueError('This row does not match the reported format/category misconfiguration. '
                         'It may already be corrected; no write was made.')
    assets = wf.read_assets(str(manifest), row['dataset_id'], row['sample_id'])
    matches = [a for a in assets if a['asset_id'] == asset_id]
    if len(matches) != 1 or matches[0]['kind'] != 'polygons' or matches[0]['role'] != 'discover':
        raise ValueError('Expected one enabled polygon source with role=discover.')
    asset = matches[0]
    choice_path = Path(asset['review_table'])
    if choice_path.absolute() != (manifest.parent / 'asset_choices.csv').absolute():
        raise ValueError('Configured review_table is not the table used by this Center UI.')
    choices = discovery.read_choices(choice_path)
    if any(x['sample_key'] == key and x['asset_id'] == asset_id for x in choices):
        raise ValueError('Target already has category choices. Use a reviewed source-revision workflow, not this zero-choice correction.')
    if state.get('reviews', {}).get(key, {}).get('review_assets'):
        raise ValueError('Target already has a saved asset review; source revision must explicitly address that review.')
    later = [(a, j.get('status')) for a, j in state.get('jobs', {}).get(key, {}).items()
             if a not in PRE_ASSET_ACTIONS and j.get('status') not in (None, 'not_recorded')]
    if later:
        raise ValueError(f'Target has downstream job history {later}; partial/completed products need separate review.')
    other_completed = []
    for other in state['project']['rows']:
        if other['sample_key'] == key: continue
        for action, job in state.get('jobs', {}).get(other['sample_key'], {}).items():
            if action in ASSET_HASH_ACTIONS and job.get('status') == 'complete':
                other_completed.append({'sample': other['sample_key'], 'action': action})
    return dict(pc=pc, wf=wf, state=state, native_state=native_state, sources=sources, row=row, key=key,
                manifest=manifest, raw=raw, fields=fields, rows=rows, index=i, asset=asset,
                choice_sha=_hash(choice_path.read_bytes()) if choice_path.exists() else None,
                other_completed=other_completed)


def _inspect_xml(context):
    from defusedxml import ElementTree as ET
    a = context['asset']; path = Path(a['path'])
    data = _stable_bytes(path, 128 * 1024**2)
    if not data:
        raise ValueError('The annotation source is empty. Nothing was changed.')
    try:
        root = ET.fromstring(data, forbid_dtd=True, forbid_entities=True, forbid_external=True)
    except Exception as exc:
        raise ValueError('Source was not accepted as safe ImageScope XML. Its suffix is not used as proof. '
                         f'No correction made. Parser: {type(exc).__name__}: {exc}') from exc
    local = lambda tag: tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''
    anns = [el for el in root.iter() if local(el.tag) == 'Annotation']
    if local(root.tag) not in ('Annotations', 'Annotation') or not anns:
        raise ValueError('Expected ImageScope Annotations/Annotation structure; no fallback reader is used.')
    categories = dict(sorted(Counter(el.get('Name', 'unnamed') for el in anns).items()))
    if any(not c.strip() for c in categories):
        raise ValueError('Empty annotation category names require review.')
    proposed_asset = deepcopy(a); proposed_asset.update(NEW_VALUES)
    try:
        g = context['wf'].polygons(proposed_asset)
        if 'name' not in g.columns:
            raise RuntimeError('The native XML reader did not produce its expected name column.')
        if len(g) == 0:
            raise ValueError('Native reader produced no polygon features.')
        geom = {'status': 'passed', 'n_polygon_features': int(len(g)),
                'available_category_column': 'name', 'categories': sorted(set(g['name'].astype(str)))}
    except ValueError as exc:
        # Correcting a factual source-type declaration does not repair/adopt invalid geometry.
        # Keep the native failure visible and preserve its normal subsequent review requirement.
        geom = {'status': 'needs_separate_geometry_review', 'error': str(exc)}
    if _hash(_stable_bytes(path, 128 * 1024**2)) != _hash(data):
        raise RuntimeError('Annotation source changed during parsing; do not apply the proposal.')
    return {'source_path': str(path), 'source_sha256': _hash(data), 'source_bytes': len(data),
            'source_format_verified': 'imagescope_xml', 'xml_root': local(root.tag),
            'xml_annotation_elements': len(anns), 'xml_category_annotation_counts': categories,
            'native_strict_geometry': geom, 'geometry_repaired': False}


def preview(controller=None, *, sample='Navli-82', asset_id='pathology'):
    """Read-only: verifies real XML content, tests the strict native reader, proposes 2 fields."""
    pc = _find_center(controller); c = _context(pc, sample, asset_id)
    xml = _inspect_xml(c)
    result = dict(version=VERSION, sample_key=c['key'], asset_id=asset_id,
                  workspace=str(Path(pc.workspace).absolute()), revision=c['state']['revision'],
                  manifest=str(c['manifest']), manifest_sha256=_hash(c['raw']),
                  choices_sha256=c['choice_sha'], native_methods=c['sources'],
                  protected_state_sha256=_json_hash({k:c['state'].get(k) for k in PROTECTED_STATE}),
                  before={k:c['asset'][k] for k in NEW_VALUES}, after=dict(NEW_VALUES),
                  other_completed_jobs_affected_by_global_asset_hash=c['other_completed'],
                  configuration_changed=False, reviews_approved=False, **xml)
    result['proposal_sha256'] = _json_hash(result)
    print(json.dumps(result, indent=2))
    print('\nPreview only. No source, config, choices, reviews, code or biological products changed.')
    if c['other_completed']:
        print('STOP: the shared asset-manifest hash also affects completed jobs; apply() will refuse this case.')
    return result


def _assert_no_local_workers():
    import psutil
    found = []
    denied = 0
    for p in psutil.process_iter(['pid','cmdline']):
        try:
            cmd = p.info['cmdline'] or []
            if any(x == 'vhd.compute.worker' for x in cmd):
                found.append({'pid':p.pid, 'command':cmd})
        except psutil.NoSuchProcess:
            pass
        except psutil.AccessDenied:
            denied += 1
    if found:
        raise RuntimeError('Visible VHD workers are active; no configuration change: '+str(found))
    return {'matching_workers': [], 'access_denied_count': denied,
            'remote_hosts_or_pid_namespaces_verified': False}


def _write_json(path, data):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(data, f, indent=2, default=str); f.write('\n')


def apply(controller, proposal, *, confirmed_raw_xml=False,
          confirmed_all_pipeline_sessions_idle=False, reviewer=''):
    """Save only the two verified declaration fields; does NOT discover/approve/transfer."""
    if confirmed_raw_xml is not True or confirmed_all_pipeline_sessions_idle is not True or not str(reviewer).strip():
        raise PermissionError('Explicit raw-XML intent, idle-session confirmation, and reviewer are required.')
    if not isinstance(proposal, dict) or proposal.get('version') != VERSION:
        raise ValueError('Pass the unchanged preview() result.')
    unsealed = {k:v for k,v in proposal.items() if k != 'proposal_sha256'}
    if proposal.get('proposal_sha256') != _json_hash(unsealed):
        raise ValueError('The proposal was edited; rerun preview instead.')
    pc = _find_center(controller)
    if proposal.get('other_completed_jobs_affected_by_global_asset_hash'):
        raise RuntimeError('This shared manifest participates in other completed-job contracts. '
                           'No change made; use a separately reviewed configuration migration.')
    local = _assert_no_local_workers()
    with pc.store.exclusive():
        c = _context(pc, proposal['sample_key'], proposal['asset_id'])
        # Re-read/revalidate the small XML and code/config snapshots before any write.
        xml = _inspect_xml(c)
        checks = {
            'workspace': str(Path(pc.workspace).absolute()), 'revision': c['state']['revision'],
            'manifest': str(c['manifest']), 'manifest_sha256': _hash(c['raw']),
            'choices_sha256': c['choice_sha'], 'native_methods': c['sources'],
            'protected_state_sha256': _json_hash({k:c['state'].get(k) for k in PROTECTED_STATE}),
            'source_sha256': xml['source_sha256'], 'source_path': xml['source_path'],
            'native_strict_geometry': xml['native_strict_geometry'],
            'other_completed_jobs_affected_by_global_asset_hash': c['other_completed'],
        }
        changed = [k for k,v in checks.items() if proposal.get(k) != v]
        if changed: raise RuntimeError('Context changed since preview: '+', '.join(changed)+'. Rerun preview.')
        rows = deepcopy(c['rows']); rows[c['index']].update(NEW_VALUES)
        text = _csv_text(c['fields'], rows)
        audit = Path(pc.workspace) / 'source_declaration_corrections'
        if audit.is_symlink(): raise ValueError('Refuse symlinked audit directory.')
        audit = audit / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'_'+uuid.uuid4().hex[:8])
        audit.mkdir(parents=True, exist_ok=False)
        (audit/'assets_before.csv.txt').write_bytes(c['raw'])
        (audit/'assets_proposed.csv.txt').write_text(text, encoding='utf-8')
        _write_json(audit/'state_before.json', c['state'])
        _write_json(audit/'proposal.json', proposal)
        receipt = dict(version=VERSION, phase='prepared', sample_key=c['key'], reviewer=reviewer,
                       audit_dir=str(audit), before=proposal['before'], after=dict(NEW_VALUES),
                       native_geometry=xml['native_strict_geometry'], local_process_check=local,
                       geometry_repaired=False, choices_created=False, reviews_approved=False,
                       scientific_jobs_launched=False, pipeline_source_modified=False)
        _write_json(audit/'prepared.json', receipt)
        original_state = deepcopy(c['state'])
        try:
            # Same native atomic writer and managed-hash commit as the Center's own saves.
            c['native_state'].atomic_write(c['manifest'], text)
            fields_after, rows_after = _read_csv(c['manifest'].read_bytes())
            if fields_after != c['fields'] or rows_after != rows:
                raise RuntimeError('Written manifest failed exact row verification.')
            pc._commit(c['state'], f"{VERSION}: {reviewer.strip()} confirmed original XML for {c['key']}/{proposal['asset_id']}; corrected format/category field; no geometry/use approval.")
            after = pc.snapshot()
            if any(after.get(k) != original_state.get(k) for k in PROTECTED_STATE):
                raise RuntimeError('Unexpected protected controller-state change; inspect audit before further operations.')
            if _hash(_stable_bytes(Path(xml['source_path']),128*1024**2)) != xml['source_sha256']:
                raise RuntimeError('Source changed during the save; do not proceed to discovery until reviewed.')
            receipt.update(phase='configuration_saved', revision=after['revision'],
                           manifest_sha256=_hash(c['manifest'].read_bytes()),
                           source_sha256=xml['source_sha256'])
        except BaseException as exc:
            receipt.update(phase='error_requires_review', error=f'{type(exc).__name__}: {exc}')
            # Roll back only when state definitely did not advance. Never restore old state JSON.
            try:
                disk_state = pc.store.read()
                if (disk_state == original_state and
                    c['manifest'].read_bytes() == text.encode('utf-8')):
                    c['native_state'].atomic_write(c['manifest'], c['raw'].decode('utf-8'))
                    if c['manifest'].read_bytes() != c['raw']:
                        raise RuntimeError('Could not verify restoration of original manifest bytes.')
                    pc.snapshot()
                    receipt['phase'] = 'not_committed_original_manifest_restored'
                else:
                    receipt['state_may_have_committed'] = True
            except BaseException as second:
                receipt['recovery_check_error'] = f'{type(second).__name__}: {second}'
            _write_json(audit/'receipt.json', receipt)
            raise RuntimeError(f'Correction did not return cleanly. Inspect {audit}/receipt.json; '
                               'do not manually restore controller state or retry blindly.') from exc
        _write_json(audit/'receipt.json', receipt)
    print(json.dumps(receipt, indent=2))
    print('Now refresh the Center. Use Discover category names; generate/review a new H&E gallery; save usage explicitly.')
    return receipt
