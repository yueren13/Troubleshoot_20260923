# Validation — Project Center v5 / 0.5.0rc1

Run date: October 9, 2026. These are local software checks, **not validation of the user's biological data, institutional filesystem, or GPUs**.

## Results

| Check | Result / scope |
|---|---|
| Full available pytest collection | **591 passed, 17 skipped**; captured output in `validation/pytest.txt`. |
| New mandatory Project Center tests included above | **34 passed** in `tests/test_project_center.py`. Not an additional 34 on top of 591. |
| Preexisting engine preservation | **68 existing `vhd/*.py` files (recursive) byte-identical** to the uploaded patched source. Exact hashes in `SOURCE_PROVENANCE.json`. |
| Recursive static syntax/notebook checks | **129 Python files, 26 source-only notebooks, 115 code cells** parsed/validated/compiled. This includes the historical advanced notebooks. |
| Existing repository validator | Passed. Its notebook scan covers only the **2 top-level launcher/smoke notebooks and 3 code cells**; the recursive check above covers advanced notebooks too. |
| Static HTML browser checks | Four pages loaded through Chromium `set_content`; 13 embedded report images decoded and zero page-script errors. Exported relative-link targets checked. This is **not** a live widget/comm test. |

## New interaction actually exercised

A test generated real tiny PNG/TIFF/XML inputs and ran the actual opacity-updated Visual-First viewer with a 4x reference/signal dimension ratio and an incorrect 9x hint. The new center imported managed config copies, saved corrected hint + explicit extent confirmation + native signal interpretation + category choices in **one save operation**, and reopened the state. It verified saved approval signatures and preservation of original XML/TIFF/CSV bytes. No master was opened or written in that test.

Other checks cover exact metadata joining and leading-zero preservation; wrong species not silently coerced to human for new projects; stale-form rejection; protected original inputs; optimistic revisions; competing controller locks; blocked-save rollback with retained draft; no-asset/midway routes; no missing-report approval; changed output stamps; stopped-job acknowledgements; report export; cgroup/GPU parsing; caps without changing the source config; executable validation; and UI field validation.

One controller dispatch test deliberately supplies fake worker output bytes to test state transitions. Those bytes are not real H5AD or Parquet data, and that test is **not** counted as a scientific roundtrip. Existing inherited tests similarly state their mocked/stubbed scope individually.

The demonstration report figures are synthetic layout examples. **The ten demo panels are not results of a UMAP/Leiden run, and the outline illustration is not segmentation output.** Their titles and summaries say so. The actual optional analysis implementation is in `vhd/center/single_sample.py`; it has a separate real-science test below.

## What did NOT run here

The 17 skips consist of **14 dependency-gated whole modules** (including the new widget and independent-analysis modules), **one optional original-workflow cross-version test**, and **two opt-in scVI tests**. A skipped module may contain multiple tests, so 17 skipped entries is not the number of remaining scientific assertions.

`ipywidgets`, AnnData, SpatialData, Scanpy, Zarr, PyArrow and igraph were not installed in the available delivery environment. Installing missing packages was unavailable there. In particular:

- Live Jupyter widget construction and browser-to-kernel callbacks were not executed here. `tests/test_project_center_widgets_optional.py` tests real widget construction/Python callbacks when ipywidgets is available, but even it does not replace the actual browser **Test browser connection** on Domino/Jupyter.
- `tests/test_project_center_analysis_optional.py` is a real tiny stored-AnnData independent analysis/count-preservation test, included but skipped here.
- Inherited optional real SpatialData/AnnData write/readback tests remain included and skipped as reported.
- No actual user TIFF/SVS/annotation derivative, expression matrix, mounted S3/EBS path, full-slide memory/runtime, StarDist GPU, Proseg, scVI/DDP, or RAPIDS job was executed here.
- Filesystem `flock`/atomic-replace behavior was tested only on the local test filesystem, not the institutional mount.

## First target-environment pilot

Open the launcher in the intended kernel, import the **current** config to a new workspace, and click Test browser connection. Reopen the workspace and verify persistence. Inspect actual metadata/paths/evidence. Resolve the current stain decision on the asset panel; save; reopen and verify that selections and confirmation persist. Preview the transfer; execute it only after reviewing the plan and writer access. Inspect actual selected `.obs` columns and count/coordinate preservation using the scientific test/readback tools.

A failed large job must remain a failed/partial output requiring inspection; a passing UI test must not turn it green. Preserve the old pipeline and results during this pilot.

## Fixture correction

One inherited missing-threshold test read the operator's active settings and assumed thresholds were null. The uploaded settings contained chosen values. The test now explicitly sets null values in its disposable fixture before asserting rejection. No classifier, input configuration, or biological cutoff was changed to make the test pass.
