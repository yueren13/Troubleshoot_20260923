"""H&E source selection and read-only diagnostics for paired OR split layouts."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from ..core import affine
from ..spaceranger_images import (
    SPATIAL_SOURCE_PATCH, path_state, candidate_inventory,
    _read_scale, resolve_spaceranger_image,
)

HE_SOURCE_PATCH = SPATIAL_SOURCE_PATCH


def resolve_he_source(cfg, spec):
    """Return path, pixel-index-to-fullres transform and auditable source choices.

    Explicit image/transform settings win. Automatic images and JSON can live
    separately under the SAME configured sample outs; no data files are moved.
    """
    settings = cfg["he_score"]
    if settings.get("image_path"):
        path = Path(settings["image_path"])
        if settings.get("source_to_fullres") is None:
            raise ValueError("Explicit H&E image requires its pixel-center source_to_fullres transform.")
        matrix = affine(settings["source_to_fullres"])
        state = path_state(path)
        if state["state"] not in ("readable_file", "directory"):
            raise FileNotFoundError(f"Explicit H&E source unavailable; no automatic substitution: {state}")
        return path, matrix, {
            "implementation": HE_SOURCE_PATCH, "layout": "explicit",
            "image_path": str(path), "transform_origin": "he_score.source_to_fullres",
            "image_state": state, "registration_verified": False,
        }
    outs = spec.get("outs")
    if not outs:
        raise ValueError("Provide he_score.image_path and transform or Space Ranger outs.")
    record = resolve_spaceranger_image(outs, "hires")
    return Path(record["image_path"]), np.asarray(record["index_to_fullres"], dtype=float), record


def diagnose_he_sources(project, sample_keys=None):
    """Read-only source check; no image pixels, count arrays, staging or outputs.

    Uses the configured source paths, not a worker's possible staged copy. A
    'resolved' result establishes file access/calibration parsing only, not RGB
    decoding, registration, staining quality, or successful measurement.
    """
    from ..control.manifest import resolve_sample_keys, row_config, sample_layout
    from ..compact_images import compact_sources

    keys = resolve_sample_keys(project, sample_keys)
    by_key = {row["sample_key"]: row for row in project["rows"]}
    reports = {}
    for key in keys:
        row = by_key[key]
        cfg, spec = row_config(project, row)
        report = {"sample": key, "patch": HE_SOURCE_PATCH,
                  "image_pixels_read": False, "expression_read": False,
                  "data_or_config_written": False,
                  "inspection_scope": "configured sources; no staging"}
        if spec.get("outs"):
            report["candidate_pairs"] = candidate_inventory(spec["outs"])
            report["candidate_note"] = "Directory inventory only; images and JSON may be resolved across these two folders within this sample outs."
        try:
            path, matrix, origin = resolve_he_source(cfg, spec)
            report.update(status="resolved", image_path=str(path),
                          source_to_fullres=matrix.tolist(), resolution=origin)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            report.update(status="unresolved", error_type=type(exc).__name__, error=str(exc))
        # Compact assembly needs lowres as well; report it separately rather
        # than incorrectly requiring lowres just to measure hires H&E.
        if cfg.get("storage", {}).get("image_policy", "original") == "compact":
            try:
                images = compact_sources(cfg, spec)
                report["compact_master_source_check"] = {
                    "status": "paths_resolved", "sources": images,
                    "note": "Path/calibration check only; image decoding and registration not tested."
                }
            except (OSError, ValueError, TypeError, KeyError) as exc:
                report["compact_master_source_check"] = {
                    "status": "not_ready", "error_type": type(exc).__name__, "error": str(exc)
                }
        paths = sample_layout(project, row)
        report["expected_he_directory"] = str(Path(paths["work"]) / "he_fixed")
        report["completion_record_present"] = (Path(paths["work"]) / "he_fixed/complete.json").is_file()
        reports[key] = report
    return reports
