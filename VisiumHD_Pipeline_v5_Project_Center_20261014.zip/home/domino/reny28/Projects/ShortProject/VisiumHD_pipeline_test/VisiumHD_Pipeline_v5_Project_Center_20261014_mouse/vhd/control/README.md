# control

CSV stages, mounted-path roles, explicit policies and phase dispatch.

See ../../docs/START_HERE.md and ../../docs/IMPLEMENTATION_STATUS.md. Source review and CPU tests are not target-environment validation.
