"""Static validation for a clean repository or an actively used notebook folder.

Default mode retains the original release policy: no saved cell outputs/counts.
Use --mode working from notebook 99. It permits saved execution state without
executing or clearing cells. Both modes still validate formats, Python syntax,
JSON, and CSV structure. Neither mode establishes scientific/GPU readiness.
"""
from __future__ import annotations

import argparse
import ast
import csv
import json
from pathlib import Path


def validate(root: Path, mode: str = "repository") -> dict:
    if mode not in ("repository", "working"):
        raise ValueError("mode must be repository or working")
    try:
        import nbformat
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "nbformat is required in the Python environment running this validator. "
            "This is a validation dependency, not evidence of a GPU problem."
        ) from exc

    root = Path(root).expanduser().resolve()
    for name in ("vhd", "notebooks", "tools", "tests", "config"):
        if not (root / name).is_dir():
            raise FileNotFoundError(f"Expected pipeline directory is missing: {root / name}")

    python_files = sorted(set(
        list((root / "vhd").rglob("*.py"))
        + list((root / "scripts").glob("*.py"))
        + list((root / "tools").glob("*.py"))
        + list((root / "tests").rglob("*.py"))
    ))
    for path in python_files:
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))

    notebooks = sorted((root / "notebooks").glob("*.ipynb"))
    code_cells = 0
    executed = []
    for path in notebooks:
        nb = nbformat.read(str(path), as_version=4)
        nbformat.validate(nb)
        has_execution_state = False
        for number, cell in enumerate(nb.cells, start=1):
            if cell.cell_type != "code":
                continue
            has_execution_state |= bool(cell.outputs) or cell.execution_count is not None
            # Preserve the original requirement that these cells be Python code.
            # Compilation validates syntax; it does not execute the source.
            compile(cell.source, f"{path}:cell_{number}", "exec")
            code_cells += 1
        if has_execution_state:
            executed.append(path.relative_to(root).as_posix())

    for path in sorted((root / "config").glob("*.json")):
        json.loads(path.read_text(encoding="utf-8-sig"))
    csv_files = sorted((root / "config").glob("*.csv"))
    for path in csv_files:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.reader(handle)
            header = next(reader, None)
            if not header or any(not name.strip() for name in header):
                raise ValueError(f"Empty/missing CSV header: {path}")
            width = len(header)
            if len(set(header)) != width:
                raise ValueError(f"Duplicate CSV headers: {path}")
            for line, row in enumerate(reader, start=2):
                if len(row) != width:
                    raise ValueError(
                        f"Malformed CSV {path}, line {line}: expected {width} fields; got {len(row)}"
                    )

    if mode == "repository" and executed:
        raise ValueError(
            "Executed notebook outputs are not allowed in repository mode:\n  "
            + "\n  ".join(executed)
            + "\nFor local working notebooks, use --mode working. "
            "Do not delete analysis outputs to satisfy a runtime check. "
            "Repository mode remains required before publishing source notebooks."
        )

    return {
        "static_validation": "passed",
        "mode": mode,
        "python_files": len(python_files),
        "notebooks": len(notebooks),
        "code_cells": code_cells,
        "csv_files": len(csv_files),
        "notebooks_with_saved_execution_state": executed,
        "notes": [
            "Working mode permits saved outputs/counts, but does not clear or execute them."
            if mode == "working" else "Repository mode requires unexecuted source notebooks.",
            "No biological data were read; scientific/GPU functionality was not tested.",
            "This tool did not modify source, configuration, or data files.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("repository", "working"), default="repository")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    result = validate(args.root, args.mode)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
