"""Computational bodies transcribed from the user's pasted functions.
Only formatting/comments were shortened; these are NOT corrected replacements.
No original files or repository content are imported or modified.
"""
import gc
import numpy as np
from scipy.ndimage import map_coordinates
from tqdm.auto import tqdm


def combine_he_tissue_signal(H_u8, E_u8, *, method="soft_union", h_weight=0.6,
                             e_weight=1.0, h_threshold=None, e_threshold=None):
    H = np.clip(np.asarray(H_u8, dtype=np.float32) / 255.0, 0, 1)
    E = np.clip(np.asarray(E_u8, dtype=np.float32) / 255.0, 0, 1)
    Hw = np.clip(h_weight * H, 0, 1)
    Ew = np.clip(e_weight * E, 0, 1)
    if method == "soft_union":
        score = 1.0 - (1.0 - Hw) * (1.0 - Ew)
    elif method == "max":
        score = np.maximum(Hw, Ew)
    elif method == "weighted_mean":
        denom = h_weight + e_weight
        if denom <= 0:
            raise ValueError("At least one stain weight must be positive.")
        score = (h_weight * H + e_weight * E) / denom
    else:
        raise ValueError("method must be 'soft_union', 'max', or 'weighted_mean'.")
    tissue_mask = None
    if h_threshold is not None and e_threshold is not None:
        tissue_mask = (H >= h_threshold) | (E >= e_threshold)
    return score.astype(np.float32), tissue_mask


def map_hires_image_to_visiumhd_bins(adata, image_2d, *, tissue_hires_scalef,
                                   out_key, spatial_key="spatial", interpolation="linear",
                                   chunk_size=1_000_000, show_progress=True):
    field = np.asarray(image_2d, dtype=np.float32)
    if field.ndim != 2:
        raise ValueError(f"image_2d must be 2D; received shape {field.shape}.")
    H, W = field.shape
    xy = np.asarray(adata.obsm[spatial_key])
    if xy.ndim != 2 or xy.shape[1] < 2:
        raise ValueError(f"adata.obsm[{spatial_key!r}] must be an N×2 coordinate matrix.")
    n = adata.n_obs
    values = np.full(n, np.nan, dtype=np.float32)
    in_bounds = np.zeros(n, dtype=bool)
    order = {"nearest": 0, "linear": 1}.get(interpolation)
    if order is None:
        raise ValueError("interpolation must be 'nearest' or 'linear'.")
    starts = range(0, n, chunk_size)
    if show_progress:
        starts = tqdm(starts, total=(n+chunk_size-1)//chunk_size,
                      desc=f"Mapping {out_key}", unit="chunk")
    for start in starts:
        end = min(start+chunk_size, n)
        x = xy[start:end, 0].astype(np.float64) * tissue_hires_scalef
        y = xy[start:end, 1].astype(np.float64) * tissue_hires_scalef
        valid = (np.isfinite(x) & np.isfinite(y) & (x >= 0) & (x <= W-1)
                 & (y >= 0) & (y <= H-1))
        in_bounds[start:end] = valid
        if valid.any():
            vals = map_coordinates(field, coordinates=np.vstack([y[valid], x[valid]]),
                                   order=order, mode="constant", cval=np.nan, prefilter=False)
            local_idx = np.flatnonzero(valid) + start
            values[local_idx] = vals.astype(np.float32, copy=False)
    adata.obs[out_key] = values
    adata.obs[f"{out_key}_in_bounds"] = in_bounds
    adata.uns[f"{out_key}_mapping"] = {
        "source": "hires image", "tissue_hires_scalef": float(tissue_hires_scalef),
        "interpolation": interpolation, "n_in_bounds": int(in_bounds.sum()),
        "n_out_of_bounds": int((~in_bounds).sum()),
    }
    return values


def _as_hwc(img_cyx: np.ndarray) -> np.ndarray:
    if img_cyx.ndim != 3 or img_cyx.shape[0] not in (3, 4):
        raise ValueError(f"Expected image with shape (c, y, x) and 3 or 4 channels. Got {img_cyx.shape}.")
    return np.moveaxis(img_cyx[:3], 0, -1)


def _batch_lstsq(HE: np.ndarray, Y: np.ndarray, batch: int = 200_000) -> np.ndarray:
    Cs = []
    for i in range(0, Y.shape[1], batch):
        C_i, _, _, _ = np.linalg.lstsq(HE, Y[:, i:i+batch], rcond=None)
        Cs.append(C_i)
    return np.concatenate(Cs, axis=1)


def estimate_background_Io_rgb(img_hwc, *, sat_max=0.08, value_quantile=90,
                               io_quantile=99.5, fallback=255.0):
    from matplotlib.colors import rgb_to_hsv
    I = np.asarray(img_hwc, dtype=np.float32)
    I01 = np.clip(I / 255.0, 0, 1)
    hsv = rgb_to_hsv(I01)
    sat = hsv[..., 1]
    val = hsv[..., 2]
    v_thr = np.percentile(val, value_quantile)
    bg = (val >= v_thr) & (sat <= sat_max)
    if bg.sum() < 1000:
        return np.array([fallback, fallback, fallback], dtype=np.float32)
    Io_rgb = np.percentile(I[bg, :3], io_quantile, axis=0)
    Io_rgb = np.where(np.isfinite(Io_rgb) & (Io_rgb > 10), Io_rgb, fallback)
    return Io_rgb.astype(np.float32)


def extract_he_concentrations_reference(img, *, Io=255.0, white_balance=False,
                                        clip_concentrations=True, lstsq_batch=200_000):
    HERef = np.array([[0.5626, 0.2159], [0.7201, 0.8012], [0.4062, 0.5581]], dtype=np.float64)
    try:
        import xarray as xr
        if isinstance(img, xr.DataArray):
            arr = img.values
        else:
            arr = img
    except Exception:
        arr = img
    if arr.shape[0] in (3, 4):
        I = _as_hwc(arr)
    elif arr.shape[-1] in (3, 4):
        I = arr[..., :3]
    else:
        raise ValueError("Provide RGB image as (c,y,x) or (y,x,c).")
    h, w, _ = I.shape
    I = I.astype(np.float32, copy=False)
    if white_balance:
        Io_used = estimate_background_Io_rgb(I)
    else:
        Io_used = float(Io)
    Io_arr = np.asarray(Io_used, dtype=np.float32)
    if Io_arr.ndim == 0:
        Io_arr = np.array([float(Io_arr)] * 3, dtype=np.float32)
    I_clip = np.minimum(I, Io_arr.reshape(1, 1, 3) - 1.0)
    I_clip = np.maximum(I_clip, 0)
    OD = -np.log((I_clip+1.0) / Io_arr.reshape(1, 1, 3))
    OD = OD.astype(np.float32, copy=False)
    Y = OD.reshape(-1, 3).T
    gc.collect()
    C = _batch_lstsq(HERef, Y, batch=lstsq_batch).astype(np.float32, copy=False)
    gc.collect()
    if clip_concentrations:
        C[C < 0] = 0
    H_conc = C[0, :].reshape(h, w).astype(np.float32, copy=False)
    E_conc = C[1, :].reshape(h, w).astype(np.float32, copy=False)
    return H_conc, E_conc, Io_used


def fixed_scale_he_tissue_score(H_conc, E_conc, *, h_limit=1.9705, e_limit=1.0308,
                                 h_weight=1.0, e_weight=1.0, method="soft_union"):
    H = np.asarray(H_conc, dtype=np.float32)
    E = np.asarray(E_conc, dtype=np.float32)
    Hn = np.clip(H / float(h_limit), 0, 1)
    En = np.clip(E / float(e_limit), 0, 1)
    Hw = np.clip(h_weight * Hn, 0, 1)
    Ew = np.clip(e_weight * En, 0, 1)
    if method == "soft_union":
        score = 1.0 - (1.0-Hw) * (1.0-Ew)
    elif method == "max":
        score = np.maximum(Hw, Ew)
    elif method == "weighted_mean":
        score = (h_weight*Hn + e_weight*En) / (h_weight+e_weight)
    else:
        raise ValueError("method must be 'soft_union', 'max', or 'weighted_mean'.")
    return score.astype(np.float32), Hn.astype(np.float32), En.astype(np.float32)


def combine_he_fixed_tissue_signal(H_fixed, E_fixed, *, method="soft_union", h_weight=1.0,
                                    e_weight=1.0, score_threshold=None, h_threshold=None,
                                    e_threshold=None):
    H = np.clip(np.asarray(H_fixed, dtype=np.float32), 0, 1)
    E = np.clip(np.asarray(E_fixed, dtype=np.float32), 0, 1)
    Hw = np.clip(h_weight * H, 0, 1)
    Ew = np.clip(e_weight * E, 0, 1)
    if method == "soft_union":
        score = 1.0 - (1.0-Hw) * (1.0-Ew)
    elif method == "max":
        score = np.maximum(Hw, Ew)
    elif method == "weighted_mean":
        denom = h_weight + e_weight
        if denom <= 0:
            raise ValueError("h_weight + e_weight must be > 0.")
        score = (h_weight*H + e_weight*E) / denom
    else:
        raise ValueError("method must be 'soft_union', 'max', or 'weighted_mean'.")
    score = np.clip(score, 0, 1).astype(np.float32)
    tissue_mask = None
    if score_threshold is not None:
        tissue_mask = score >= float(score_threshold)
    if h_threshold is not None and e_threshold is not None:
        tissue_mask = (H >= float(h_threshold)) | (E >= float(e_threshold))
    return score, tissue_mask
