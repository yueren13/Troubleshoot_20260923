"""Resolve native Space Ranger display images and calibration within ONE outs tree.

A source relationship is the configured sample/run, not necessarily one folder.
Keep the previous complete-pair preference; when pairs are split, find each file
in the two named directories. No recursive, neighbor-sample or image substitution.
This checks access and numerical calibration, not tissue registration or origin.
"""
from __future__ import annotations
import json
import math
import os
from pathlib import Path
import stat

SPATIAL_SOURCE_PATCH = "spatial-split-layout-20261001-v2"
_IMAGE = "tissue_hires_image.png"
_SCALES = "scalefactors_json.json"
_ABSENT = {"missing", "broken_symlink"}

def path_state(path):
    """Inspect one path and open readable files without reading payload bytes."""
    path = Path(path)
    record = {"path": str(path), "state": "missing", "is_symlink": False}
    try:
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            record["is_symlink"] = True
            record["link_target"] = os.readlink(path)
        try:
            info = path.stat()
        except FileNotFoundError:
            record["state"] = "broken_symlink" if record["is_symlink"] else "missing"
            return record
        if stat.S_ISDIR(info.st_mode):
            record["state"] = "directory"
            return record
        if not stat.S_ISREG(info.st_mode):
            record["state"] = "not_regular_file"
            return record
        record["size_bytes"] = int(info.st_size)
        record["mtime_ns"] = int(info.st_mtime_ns)
        if info.st_size == 0:
            record["state"] = "empty_file"
            return record
        with path.open("rb"):
            pass
        record["state"] = "readable_file"
    except FileNotFoundError:
        pass
    except OSError as exc:
        record.update(state="access_error", error_type=type(exc).__name__, error=str(exc))
    return record


def candidate_inventory(outs):
    """No recursive search, neighbor-sample search, hashing, copying or writes."""
    outs = Path(outs)
    return [
        {"layout": layout, "folder": str(folder),
         "hires": path_state(folder / _IMAGE),
         "scales": path_state(folder / _SCALES),
         "lowres": path_state(folder / "tissue_lowres_image.png")}
        for layout, folder in (
            ("binned_002um", outs / "binned_outputs" / "square_002um" / "spatial"),
            ("outs_spatial", outs / "spatial"),
        )
    ]



def _read_scale(path, resolution="hires"):
    """Read only the requested image scale; unrelated bin-specific keys may differ."""
    if resolution not in ("hires", "lowres"):
        raise ValueError("resolution must be hires or lowres")
    key = f"tissue_{resolution}_scalef"
    def unique_object(pairs):
        result = {}
        for name, value in pairs:
            if name in result:
                raise ValueError(f"Duplicate JSON key {name!r}")
            result[name] = value
        return result
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique_object)
        raw = data[key]
        if isinstance(raw, bool):
            raise ValueError("Boolean scale is not a numeric calibration")
        factor = float(raw)
        if not math.isfinite(factor) or factor <= 0:
            raise ValueError("Scale must be positive and finite")
        if not math.isfinite(1.0 / factor):
            raise ValueError("Inverse scale is not finite")
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        raise ValueError(f"Invalid {key} in {path}: {exc}") from exc
    return factor


def _check_usable(item, field):
    state = item[field]
    if state["state"] != "readable_file":
        raise ValueError(
            "Space Ranger source contains a present but unusable file; no silent replacement: "
            + json.dumps(state, ensure_ascii=False)
        )


def _record(outs, resolution, image_item, scale_item, factor, rule):
    matched = image_item["folder"] == scale_item["folder"]
    return {
        "implementation": SPATIAL_SOURCE_PATCH,
        "layout": image_item["layout"] if matched else "split_spatial_layout",
        "selection_rule": rule,
        "sample_outs": str(Path(outs)),
        "resolution": resolution,
        "image_layout": image_item["layout"],
        "scalefactors_layout": scale_item["layout"],
        "same_folder": matched,
        "image_path": image_item[resolution]["path"],
        "scalefactors_path": scale_item["scales"]["path"],
        f"tissue_{resolution}_scalef": factor,
        "index_to_fullres": [[1.0/factor, 0.0, 0.0], [0.0, 1.0/factor, 0.0], [0.0, 0.0, 1.0]],
        "transform_origin": f"Space Ranger tissue_{resolution}_scalef; fullres = {resolution} / scale",
        "image_state": image_item[resolution],
        "scales_state": scale_item["scales"],
        "registration_verified": False,
        "origin_note": "Association is by the configured sample outs tree. File history and H&E alignment are not verified by path lookup; readable symlinks are followed without rewriting them.",
    }


def resolve_spaceranger_image(outs, resolution="hires"):
    """Return image, matching scale and path provenance; do not read image pixels.

    First preserve a complete same-folder pair (2-um, then root spatial). If no
    such pair exists, select the image and JSON independently from those exact
    directories, never from another sample. Missing/broken links allow fallback;
    present invalid sources stop. A JSON with a missing/invalid scale is not
    bypassed. Different valid paired exports retain their prior deterministic
    preference; only an unpaired cross-folder candidate requires independent
    selection. The source provenance explicitly records split selection.
    """
    if not outs:
        raise ValueError("Space Ranger outs is required for automatic display-image lookup.")
    if resolution not in ("hires", "lowres"):
        raise ValueError("resolution must be hires or lowres")
    candidates = candidate_inventory(outs)
    for item in candidates:
        if item[resolution]["state"] in _ABSENT or item["scales"]["state"] in _ABSENT:
            continue
        _check_usable(item, resolution)
        _check_usable(item, "scales")
        factor = _read_scale(item["scales"]["path"], resolution)
        return _record(outs, resolution, item, item, factor, "existing_same_folder_pair")

    image_item = None
    for item in candidates:
        if item[resolution]["state"] in _ABSENT:
            continue
        _check_usable(item, resolution)
        image_item = item
        break
    # Do not substitute lowres for hires or make a scale from image dimensions.
    if image_item is not None:
        scale_candidates = []
        for item in candidates:
            if item["scales"]["state"] in _ABSENT:
                continue
            _check_usable(item, "scales")
            scale_candidates.append((item, _read_scale(item["scales"]["path"], resolution)))
        if scale_candidates:
            scale_item, factor = scale_candidates[0]
            if any(not math.isclose(factor, other, rel_tol=1e-12, abs_tol=0.0)
                   for _, other in scale_candidates[1:]):
                raise ValueError("Conflicting unpaired Space Ranger image scales; select an explicit reviewed image and transform.")
            return _record(outs, resolution, image_item, scale_item, factor, "split_files_within_same_outs")
    details = "\n".join(
        f"  {item[key]['path']} [{item[key]['state']}]"
        for item in candidates for key in (resolution, "scales")
    )
    raise FileNotFoundError(
        f"No readable {resolution} image plus its scale-factor JSON within this sample's two spatial folders. "
        "Same-folder placement is NOT required. Checked:\n" + details
        + "\nProvide the original files for this same sample/run, or an explicit reviewed image/transform. "
          "No lowres/original-image substitution, resizing, source copying or coordinate change was performed."
    )
