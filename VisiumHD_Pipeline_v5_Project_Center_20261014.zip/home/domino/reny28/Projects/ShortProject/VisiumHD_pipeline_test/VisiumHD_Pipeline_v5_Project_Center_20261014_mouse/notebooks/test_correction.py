from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

import correct_navli_master as c
REAL_GUARD = c._guard


def sample_layout(project, row):
    root=Path(row['root'])
    return {'root':root,'work':root/'work','report':root/'reports','store':Path(row['master_store'])}


def check_policy(project):
    approved=Path(project['approved'])
    for r in project['rows']:
        if approved not in Path(r['master_store']).parents:
            raise PermissionError('Outside allowed root')


class State:
    def __init__(self, d): self.d=deepcopy(d)
    @contextmanager
    def exclusive(self): yield


class ProjectCenter:
    __module__='vhd.center.controller'
    def __init__(self,w,d): self.workspace=w; self.store=State(d)
    def snapshot(self): return deepcopy(self.store.d)
    def row(self,key,project=None):
        return next(r for r in (project or self.snapshot()['project'])['rows'] if r['sample_key']==key)
    def _done(self,d,row,action): return d['jobs'][row['sample_key']][action]['status']=='complete'
    def _contract(self,d,row,action): return 'unchanged-'+action
    def _commit(self,d,event,export=False):
        if export:
            # Minimal state/export fixture; not an implementation of the entire engine.
            Path(d['project']['manifest_path']).write_text(json.dumps(d['project']['rows']))
            Path(d['project']['settings_path']).write_text(json.dumps(d['project']['settings']))
        d['revision']+=1; d.setdefault('history',[]).append(event);self.store.d=deepcopy(d)
        return deepcopy(d)


class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name); self.work=self.root/'sample'/'work';self.work.mkdir(parents=True)
        self.rep=self.root/'sample'/'reports';self.rep.mkdir()
        self.ws=self.root/'center';self.ws.mkdir()
        self.stores=self.root/'masters';self.stores.mkdir()
        self.old=self.stores/'BM0164135A_s1_A1.zarr';self.old.mkdir()
        (self.old/'.zattrs').write_text(json.dumps({'sample':c.OLD_SAMPLE}))
        (self.old/'expression.fake').write_bytes(b'ORIGINAL BM COUNTS')
        for f in ('bins_raw.h5ad','bins_qc_obs.parquet','geometry.json'): (self.work/f).write_bytes(b'ORIGINAL NAVLI '+f.encode())
        manifest=self.ws/'samples.csv';manifest.write_text('original')
        settings=self.ws/'settings.json';settings.write_text('{}')
        row={'sample_id':'Navli-82','sample_key':c.SAMPLE,'stage':'raw','root':str(self.root/'sample'),
             'master_store':str(self.old),'_plan':['assemble_bins','transfer_assets']}
        d={'revision':36,'project':{'rows':[row],'approved':str(self.stores),'manifest_path':str(manifest),
            'settings_path':str(settings),'settings':{'storage':{'single_writer_ack':True}}},
           'jobs':{c.SAMPLE:{**{a:{'status':'complete'} for a in c.PRE},'transfer_assets':{'status':'failed'}}},
           'reviews':{c.SAMPLE:{'review_assets':{'decision':'no_selected_outputs','reviewer':'reny28'}}},
           'drafts':{},'resume':{},'endpoints':{c.SAMPLE:'cells'},'history':[]}
        self.pc=ProjectCenter(self.ws,d)
        self.mods={'vhd.control.manifest':types.SimpleNamespace(sample_layout=sample_layout,check_policy=check_policy,
                   row_config=lambda p,r:(deepcopy(p['settings']),{})),
                   'vhd.annotations.discovery':types.SimpleNamespace(preview_selected_plan=lambda *a,**k:[{'active_outputs':0,'prior_filter':{'enabled':False}}]),
                   'vhd.center.resources':types.SimpleNamespace(runtime_project=lambda p,limits:(deepcopy(p),{})),
                   'vhd.compute.launch':types.SimpleNamespace(launch_samples=self.fake_launch)}
        self.calls=[]
        self.addCleanup(patch.stopall)
        patch.object(c,'_guard',lambda pc:None).start()
        patch.object(c,'_modules',lambda:self.mods).start()
        patch('psutil.process_iter',return_value=[]).start()
    def fake_launch(self,project,action,execute,sample_keys):
        self.calls.append((action,execute,sample_keys))
        row=next(r for r in project['rows'] if r['sample_key']==c.SAMPLE)
        dest=Path(row['master_store']);dest.mkdir()
        (dest/'.zattrs').write_text(json.dumps({'sample':c.SAMPLE}))
        (self.rep/'status_assemble_bins.json').write_text(json.dumps({'status':'complete'}))
        (self.rep/'master_sources.json').write_text(json.dumps({'bin_source':{'path':str(self.work/'bins_raw.h5ad')}}))
        (self.rep/'storage_manifest.json').write_text('{}')
        return [{'status':'complete'}]
    def preview(self):return c.preview(self.pc)
    def save(self,plan=None):return c.save_destination(self.pc,plan or self.preview(),confirmed_all_sessions_idle=True,confirmed_new_destination=True,reviewer='Yue')
    def test_preview_no_writes(self):
        before=sorted(str(p) for p in self.root.rglob('*'));d=self.pc.snapshot()
        p=self.preview();self.assertEqual(p['new_master'],str(self.stores/'Navli-82.zarr'))
        self.assertEqual(before,sorted(str(p) for p in self.root.rglob('*')));self.assertEqual(d,self.pc.snapshot())
    def test_save_only_destination_and_history(self):
        d=self.pc.snapshot();r=self.save();after=self.pc.snapshot()
        self.assertEqual(r['phase'],'destination_saved');self.assertEqual(d['jobs'],after['jobs']);self.assertEqual(d['reviews'],after['reviews'])
        self.assertEqual((self.old/'expression.fake').read_bytes(),b'ORIGINAL BM COUNTS')
        self.assertEqual((self.work/'bins_raw.h5ad').read_bytes(),b'ORIGINAL NAVLI bins_raw.h5ad')
        self.assertFalse(Path(r['new_master']).exists()); self.assertEqual(self.calls,[])
        d['project']['rows'][0]['master_store']=r['new_master'];self.assertEqual(d['project'],after['project'])
    def test_confirmation_required(self):
        with self.assertRaises(PermissionError):c.save_destination(self.pc,self.preview())
    def test_existing_target(self):
        (self.stores/'Navli-82.zarr').mkdir()
        with self.assertRaises(FileExistsError):self.preview()
    def test_existing_partial(self):
        (self.stores/'Navli-82.zarr.partial').mkdir()
        with self.assertRaises(FileExistsError):self.preview()
    def test_wrong_old_identity(self):
        (self.old/'.zattrs').write_text(json.dumps({'sample':'other'}))
        with self.assertRaises(ValueError):self.preview()
    def test_state_change(self):
        p=self.preview();self.pc.store.d['revision']+=1
        with self.assertRaises(RuntimeError):self.save(p)
    def test_source_change(self):
        p=self.preview();(self.work/'bins_raw.h5ad').write_bytes(b'CHANGED')
        with self.assertRaises(RuntimeError):self.save(p)
    def test_external_assets_active(self):
        self.mods['vhd.annotations.discovery'].preview_selected_plan=lambda *a,**k:[{'active_outputs':1,'prior_filter':{'enabled':False}}]
        with self.assertRaises(RuntimeError):self.preview()
    def test_running_job(self):
        self.pc.store.d['jobs'][c.SAMPLE]['transfer_assets']['status']='running'
        with self.assertRaises(RuntimeError):self.preview()
    def test_downstream_file(self):
        (self.work/'prior_raw.npy').write_bytes(b'prior')
        with self.assertRaises(RuntimeError):self.preview()
    def test_work_lock(self):
        (self.work/'.worker_transfer_assets.lock').write_text('')
        with self.assertRaises(RuntimeError):self.preview()
    def test_changed_completion_contract(self):
        self.pc._contract=lambda d,r,a:r['master_store']
        with self.assertRaises(RuntimeError):self.preview()
    def test_successful_native_launch(self):
        r=self.save();d=self.pc.snapshot();out=c.initialize_bin_master(self.pc,r,confirmed_no_other_readers_or_writers=True)
        self.assertEqual(out['phase'],'native_bin_master_complete');self.assertEqual(self.calls,[('assemble_bins',True,[c.SAMPLE])])
        self.assertEqual(d['jobs'],self.pc.snapshot()['jobs']);self.assertEqual(d['reviews'],self.pc.snapshot()['reviews'])
        self.assertEqual((self.old/'expression.fake').read_bytes(),b'ORIGINAL BM COUNTS')
    def test_initialization_confirmation(self):
        r=self.save()
        with self.assertRaises(PermissionError):c.initialize_bin_master(self.pc,r)
        self.assertEqual(self.calls,[])
    def test_failure_preserves_partial(self):
        r=self.save()
        def fail(*a,**kw):
            (self.stores/'Navli-82.zarr.partial').mkdir();raise RuntimeError('simulated worker failure')
        self.mods['vhd.compute.launch'].launch_samples=fail
        with self.assertRaises(RuntimeError):c.initialize_bin_master(self.pc,r,confirmed_no_other_readers_or_writers=True)
        self.assertTrue((self.stores/'Navli-82.zarr.partial').is_dir());self.assertTrue((Path(r['audit_dir'])/'initialization_error.json').is_file())
        self.assertEqual((self.old/'expression.fake').read_bytes(),b'ORIGINAL BM COUNTS')
    def test_altered_receipt(self):
        r=self.save();r['new_master']=str(self.old)
        with self.assertRaises(ValueError):c.initialize_bin_master(self.pc,r,confirmed_no_other_readers_or_writers=True)
    def test_different_center(self):
        r=self.save();self.pc.workspace=self.root/'other_center'
        with self.assertRaises(RuntimeError):c.initialize_bin_master(self.pc,r,confirmed_no_other_readers_or_writers=True)
    def test_existing_master_receipts(self):
        (self.rep/'master_sources.json').write_text('{}')
        with self.assertRaises(RuntimeError):self.preview()
    def test_missing_native_assembly_route(self):
        self.pc.store.d['project']['rows'][0]['_plan']=['transfer_assets']
        r=self.save()
        with self.assertRaises(RuntimeError):c.initialize_bin_master(self.pc,r,confirmed_no_other_readers_or_writers=True)
        self.assertEqual(self.calls,[])
    def test_code_guard_accepts_exact_source(self):
        import ast, inspect, textwrap
        src=ast.dump(ast.parse(textwrap.dedent(inspect.getsource(c._digest))),include_attributes=False)
        folder=self.root/'guard';folder.mkdir()
        (folder/'source_guards.json').write_text(json.dumps({'correct_navli_master._digest':hashlib.sha256(src.encode()).hexdigest()}))
        with patch.object(c,'__file__',str(folder/'module.py')):
            REAL_GUARD(self.pc)
    def test_code_guard_rejects_changed_source(self):
        folder=self.root/'guard';folder.mkdir()
        (folder/'source_guards.json').write_text(json.dumps({'correct_navli_master._digest':'0'*64}))
        with patch.object(c,'__file__',str(folder/'module.py')):
            with self.assertRaises(RuntimeError):REAL_GUARD(self.pc)
    def test_policy_violation(self):
        other=self.root/'outside';other.mkdir()
        with self.assertRaises(PermissionError):c.preview(self.pc,new_master=other/'Navli-82.zarr')

if __name__=='__main__': unittest.main()
