# Discover first, choose category use second — v4.1

## The change

One source file can contain Tissue, Necrosis, tumor subregions, or other unknown
categories. Those names may overlap and can differ between samples. Import the
original file once, retain all parseable polygons as one source element, inspect
its categories and overlays, and then choose each category's computational use.
The source `.annotations` file is never edited by these selections.

`kind` is the **data type** (`polygons` or `signal`), not the biological purpose.
The new default `role=discover` is implicit; do not supply file-level purpose or
categories in the new starter CSV. Old file-level v4 role declarations remain a
compatibility interface and are described in ASSETS_V4.md, not the new default.

## What to fill before inspecting a file

Use **config/assets.csv** (plural, extension `.csv`) and point each relevant row
of `config/samples.csv` to it through `assets_manifest`. For annotations drawn
in the named original H&E image's pixel coordinates:

```csv
sample_id,asset_id,kind,path,format,registration_mode
Sample01,pathology,polygons,/approved/study_A/Sample01.annotations,imagescope_xml,reference_pixels
Sample02,pathology,polygons,/approved/study_B/Sample02.annotations,imagescope_xml,reference_pixels
```

No dataset or folder-name guessing occurs. `asset_id` is a short per-sample label
you choose, not an annotation category. `reference_pixels` explicitly declares
the annotation coordinates to be original H&E pixels; it is not a registration
algorithm. Other units/orientations require the declared affine or landmarks.

The parser recognizes ImageScope-style XML with `Annotations`/`Annotation`,
`Regions`, `Vertices`, and `V`/`Vertex` tags, preserving NegativeROA holes and
multipart regions. The `.annotations` suffix alone does not prove this schema.
Malformed or unsupported active source geometry stops; no category or polygon
is invented. A whole source may still use legacy `role=reference_only` when it
must be recorded but not consumed. This release does not silently repair malformed
individual regions in an otherwise active file.

## Discovery does not require knowing the names

Use optional **00A** to inspect inputs before expression import, or the first
section of **02A** after bins are prepared. Discovery reads source geometry and
image metadata, not the expression matrix. Execute mode writes:

- `config/asset_choices.csv`, beside the source CSV, with exact discovered names;
- per-source `asset_<id>_discovery.json` in the sample's reports directory,
  containing native extents, category inventory, and image scale proposal.

The first discovery creates **all include flags false**. A source being readable
or stored does not enable its use. The choices table is a normal CSV, viewable in
the notebook or an editor; no notebook widget is required.

Discovery can run again. It preserves choices for unchanged identities, adds
new categories unselected, and removes deleted categories from the active review
table while backing up its previous version. A changed source/reference transform
clears affected approval and same-extent confirmation. Early 00A discovery may
precede full bin geometry; rerun discovery in 02A once the canonical geometry is
available. Choices persist, but the more complete geometry requires fresh review.

## Edit the generated choices — not category overrides

| Editable column | Meaning |
|---|---|
| `include_in_obs` | `true` writes a selected category/signal to bin `.obs`; `false` retains it spatially but does not use it. |
| `qc_use` | `include` means accepted-tissue region; `exclude` means excluded region; `none` means annotation only. |
| `obs_name` | Suggested readable, collision-resistant name is generated; edit to a unique safe column name if desired. |
| `cell_methods` | Polygons: `fraction;majority`, one or neither. Signal: selected summaries of bin values, optional. |
| `coverage_mode` | `positive_only`, `exhaustive`, or `polygon`; meaning below. |
| `signal_methods` | For signal rows only: `mean;median;sum;min;max` or explicit center sampling. |
| `same_extent_confirmed` | Required for auto-extent signal alignment, after checking the matched field of view/orientation. |
| `notes` | Your notes; they do not alter numerical results. |

Keep `sample_key`, `asset_id`, `item_key`, `category` and signature columns as
generated. Do not invent or retype a category to select it. The sample key is an
internal stable namespace plus sample ID; it is not an input path.

Example choices **after those names were actually discovered**:

| category | include_in_obs | qc_use | obs_name | cell_methods | coverage_mode |
|---|---|---|---|---|---|
| Tissue | true | include | is_tissue | | positive_only |
| Necrosis | true | exclude | is_necrosis | | exhaustive |
| Tumor region | true | none | in_tumor | fraction;majority | exhaustive |
| Unreliable annotation | false | none | (keep generated name) | | positive_only |

These are illustrations, not guessed names for your new samples. False categories
remain in the original imported shapes element but create **no** bin or cell
annotation columns. Marking all categories false retains the whole layer without
scientific use. Do not set the source `enabled=false` for that purpose; it skips
source import altogether.

## Overlapping categories stay independent

Selected polygon categories become separate nullable Boolean memberships. Tissue
and Necrosis can both be true at a bin. They are not collapsed into an exclusive
categorical label, and a category drawn later does not overwrite another category.

With `prior_filter.mode="from_review"` (the new starter setting), the pipeline
constructs the prior policy automatically from reviewed choices:

```text
base bin QC AND union(selected include categories)
            AND NOT union(selected exclude categories)
```

With no include categories, only the exclusions and base QC apply. Exclusions win
in overlaps. With neither kind selected, no pathology filter is added. The choices
table replaces manual category names in per-sample override JSONs. You may still
use overrides for genuine sample-specific numerical settings.

### Absence and missing coverage must not be confused

- `positive_only`: a covered positive is true; outside that selected category is
  unassessed. Unselected categories do not establish coverage or negative labels.
- `exhaustive`: after reviewing the complete relevant domain, absence is a known
  false value throughout the bin domain. This is an explicit assertion.
- `polygon`: use a separately supplied `coverage_path` in the source row to define
  the assessed domain; that polygon must use the same source coordinate frame.

A QC exclusion cannot use `positive_only` in this release, because that would
leave every non-excluded bin's exclusion status unknown. Choose exhaustive only
when justified, or provide an assessed-domain polygon. Multiple include categories
use three-valued OR: one known true establishes inclusion even if another category
is unassessed there. Unknown remaining decisions follow `unknown_policy`, default
exclude; review its impact before segmentation.

## Import, inspect, approve, transfer

1. **02A discovery:** refresh inventory and choices; no bin annotations are written.
2. **02A import:** store original sources in `.shapes`/`.images`; generate whole,
   configured-ROI, and individual-category H&E overlays. Full paths are printed.
3. Edit `asset_choices.csv` after seeing names and previews.
4. In 02A, approve only selected source IDs:

```python
APPROVE_CHOICES = {"Sample01": ["pathology"], "Sample02": ["pathology", "stain"]}
```

Unique plain sample IDs work; ambiguous IDs require the printed canonical key.
Approval binds each selected category's output/settings to its source and current
registered preview. It never approves unselected categories. Empty `{}` does nothing.
Scale estimation or a readable file alone never sets approval.

5. **02B:** reload files, inspect the compiled output/QC plan, then transfer to
   `tables['bins_2um'].obs`. Signature checks reject stale inputs or changed choices.
6. Continue segmentation only after reviewing the resulting bin-level decisions.
7. **05B** can refresh selected cell summaries after a cell table with real cell
   polygons exists. Enable `metadata_transfer.enabled` to use that route.

The new metadata is keyed by existing bin identities. The writer updates `.obs`
and provenance, not RNA X. Deselected source-owned columns are removed by an
explicit retransfer; unrelated metadata is not removed. Changing a category/QC
selection can invalidate a downstream segmentation run. Existing segmentation is
not silently regenerated or retroactively declared consistent.

`fraction;majority` for an independent Boolean category gives positive-bin fraction,
valid-bin count, coverage, and positive/negative/mixed majority. It does not force
different categories into a single mutually exclusive cell type.

## Version and limits

Use the complete v4.1 folder in a new code directory. Earlier v4 source/transfer
signatures are not automatically adopted. No original source objects are changed.
No real annotations from the new selected samples or scientific mounted-store
roundtrips were available for this delivery. Check VALIDATION_SUMMARY.md.
