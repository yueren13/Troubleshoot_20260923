"""Synthetic filesystem/numerical tests; no institutional data or SpatialData."""
import copy
import json
import os
from pathlib import Path
import sys
import types

import numpy as np
import pandas as pd
import pytest
from PIL import Image

from vhd.he.source import resolve_he_source, candidate_inventory, path_state, diagnose_he_sources
from vhd.core import digest, file_stamp


def pair(outs, layout="binned", factor=0.25, lowres=True):
    folder=outs/('binned_outputs/square_002um/spatial' if layout=='binned' else 'spatial')
    folder.mkdir(parents=True,exist_ok=True)
    im=np.full((8,10,3),220,np.uint8);im[2:5,2:6]=[150,90,170]
    Image.fromarray(im).save(folder/'tissue_hires_image.png')
    if lowres:Image.fromarray(im[::2,::2]).save(folder/'tissue_lowres_image.png')
    (folder/'scalefactors_json.json').write_text(json.dumps({'tissue_hires_scalef':factor,'tissue_lowres_scalef':float(factor)/2 if isinstance(factor,(float,int)) else .1}))
    return folder


def cfg_spec(tmp_path):
    cfg={'he_score':{'image_path':None,'source_to_fullres':None,'white_balance':False,
                    'axes':'yxc','Io':255.,'intensity_range':[0,255],
                    'h_limit':1.9705,'e_limit':1.0308,'h_weight':1.,'e_weight':1.,
                    'method':'soft_union','tile_size':3,'bin_chunk_size':2,
                    'interpolation':'linear','alpha':'white'},
         'storage_policy':{'min_free_tmp_gib':0},'plots':{'dpi':50},
         'storage':{'image_policy':'compact'}}
    spec={'sample':'P__A','outs':str(tmp_path/'outs'),'image':str(tmp_path/'original.svs'),
          '_paths':{'work':str(tmp_path/'work'),'report':str(tmp_path/'reports'),
                    'proseg':str(tmp_path/'proseg'),'store':str(tmp_path/'master.zarr')}}
    return cfg,spec


def test_binned_pair_keeps_original_path_matrix_and_signature(tmp_path):
    cfg,spec=cfg_spec(tmp_path);folder=pair(Path(spec['outs']))
    path,matrix,rec=resolve_he_source(cfg,spec)
    expected=np.diag([4.,4.,1.])
    assert path==folder/'tissue_hires_image.png'
    np.testing.assert_array_equal(matrix,expected)
    old=digest({'source':file_stamp(path,full_hash=True),'matrix':expected,'settings':cfg['he_score'],'algorithm':'fixed-he-v3'})
    new=digest({'source':file_stamp(path,full_hash=True),'matrix':matrix,'settings':cfg['he_score'],'algorithm':'fixed-he-v3'})
    assert old==new and rec['layout']=='binned_002um'


def test_root_pair_fallback_uses_its_own_calibration(tmp_path):
    cfg,spec=cfg_spec(tmp_path);outs=Path(spec['outs']);root=pair(outs,'root',.125)
    nested=outs/'binned_outputs/square_002um/spatial';nested.mkdir(parents=True)
    (nested/'scalefactors_json.json').write_text(json.dumps({'tissue_hires_scalef':.5}))
    path,matrix,rec=resolve_he_source(cfg,spec)
    assert path==root/'tissue_hires_image.png';np.testing.assert_array_equal(matrix,np.diag([8.,8.,1.]))
    assert rec['scalefactors_path']==str(root/'scalefactors_json.json')


def test_prefers_existing_binned_pair_not_root(tmp_path):
    cfg,spec=cfg_spec(tmp_path);b=pair(Path(spec['outs']),'binned',.25);pair(Path(spec['outs']),'root',.1)
    path,matrix,_=resolve_he_source(cfg,spec)
    assert path.parent==b;assert matrix[0,0]==4


def test_hires_measurement_does_not_require_lowres(tmp_path):
    cfg,spec=cfg_spec(tmp_path);pair(Path(spec['outs']),'root',lowres=False)
    assert resolve_he_source(cfg,spec)[2]['layout']=='outs_spatial'


def test_same_sample_cross_directory_image_scale_pair_is_supported(tmp_path):
    cfg,spec=cfg_spec(tmp_path);outs=Path(spec['outs']);f=pair(outs,'root')
    (f/'scalefactors_json.json').unlink()
    nested=outs/'binned_outputs/square_002um/spatial';nested.mkdir(parents=True)
    (nested/'scalefactors_json.json').write_text('{"tissue_hires_scalef":0.25}')
    path, matrix, rec = resolve_he_source(cfg,spec)
    assert path == f/'tissue_hires_image.png'
    assert rec['layout'] == 'split_spatial_layout'
    assert rec['scalefactors_path'] == str(nested/'scalefactors_json.json')
    np.testing.assert_array_equal(matrix, np.diag([4.,4.,1.]))


def test_missing_hires_does_not_substitute_original_or_lowres(tmp_path):
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']))
    (f/'tissue_hires_image.png').unlink();Path(spec['image']).write_bytes(b'original')
    with pytest.raises(FileNotFoundError,match='No lowres/original-image substitution'):resolve_he_source(cfg,spec)


@pytest.mark.parametrize('factor',[0,-1,float('nan'),float('inf'),True,None,'bad',[],{}])
def test_invalid_scale_not_bypassed(tmp_path,factor):
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']));pair(Path(spec['outs']),'root')
    (f/'scalefactors_json.json').write_text(json.dumps({'tissue_hires_scalef':factor}))
    with pytest.raises(ValueError,match='Invalid tissue_hires_scalef'):resolve_he_source(cfg,spec)


@pytest.mark.parametrize('text',['{}','not-json','[]','{"tissue_hires_scalef":0.1,"tissue_hires_scalef":0.2}'])
def test_invalid_scale_file_clear_error(tmp_path,text):
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']));(f/'scalefactors_json.json').write_text(text)
    with pytest.raises(ValueError,match='Invalid tissue_hires_scalef'):resolve_he_source(cfg,spec)


def test_empty_image_not_silently_replaced(tmp_path):
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']));pair(Path(spec['outs']),'root')
    (f/'tissue_hires_image.png').write_bytes(b'')
    with pytest.raises(ValueError,match='empty_file'):resolve_he_source(cfg,spec)


def test_direct_broken_symlink_diagnosis_and_fallback(tmp_path):
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']));target=f/'tissue_hires_image.png'
    target.unlink();target.symlink_to('absent_image.png');pair(Path(spec['outs']),'root')
    inv=candidate_inventory(spec['outs'])
    assert inv[0]['hires']['state']=='broken_symlink'
    assert inv[0]['hires']['link_target']=='absent_image.png'
    assert resolve_he_source(cfg,spec)[2]['layout']=='outs_spatial'
    assert target.is_symlink() and not target.exists()


def test_valid_symlink_not_replaced(tmp_path):
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']));target=f/'tissue_hires_image.png'
    actual=f/'actual.png';target.rename(actual);target.symlink_to('actual.png')
    path,matrix,_=resolve_he_source(cfg,spec)
    assert path==target and path.is_symlink() and matrix[0,0]==4


def test_explicit_source_and_affine_win(tmp_path):
    cfg,spec=cfg_spec(tmp_path);pair(Path(spec['outs']))
    explicit=tmp_path/'chosen.npy';np.save(explicit,np.zeros((3,4,3),np.uint8))
    cfg['he_score'].update(image_path=str(explicit),source_to_fullres=[2,0,4,0,3,7])
    path,matrix,rec=resolve_he_source(cfg,spec)
    assert path==explicit;np.testing.assert_equal(matrix,[[2,0,4],[0,3,7],[0,0,1]])
    assert rec['layout']=='explicit'


def test_explicit_directory_source_kept(tmp_path):
    cfg,spec=cfg_spec(tmp_path);p=tmp_path/'image.zarr';p.mkdir()
    cfg['he_score'].update(image_path=str(p),source_to_fullres=np.eye(3).tolist())
    assert resolve_he_source(cfg,spec)[0]==p


def test_explicit_missing_transform_rejected(tmp_path):
    cfg,spec=cfg_spec(tmp_path);cfg['he_score']['image_path']=str(tmp_path/'custom.png')
    with pytest.raises(ValueError,match='Explicit H&E'):resolve_he_source(cfg,spec)


def test_explicit_missing_file_not_ignored(tmp_path):
    cfg,spec=cfg_spec(tmp_path);pair(Path(spec['outs']))
    cfg['he_score'].update(image_path=str(tmp_path/'missing.png'),source_to_fullres=np.eye(3).tolist())
    with pytest.raises(FileNotFoundError,match='no automatic substitution'):resolve_he_source(cfg,spec)


def test_no_outs_explicit_required(tmp_path):
    cfg,spec=cfg_spec(tmp_path);spec['outs']=''
    with pytest.raises(ValueError,match='Space Ranger outs'):resolve_he_source(cfg,spec)


def stub_metadata(monkeypatch):
    # Exact measurement code runs on real PNG/NPY. H5/Parquet I/O is isolated.
    stub=types.ModuleType('vhd.io')
    obs=pd.DataFrame({'pxl_col_in_fullres':[0.,4.,12.,200.],
                      'pxl_row_in_fullres':[0.,4.,12.,200.]},index=['b1','b2','b3','b4'])
    stub.h5_metadata=lambda path:(obs.copy(),pd.DataFrame())
    monkeypatch.setitem(sys.modules,'vhd.io',stub)
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,path:self.to_pickle(path))
    return obs


def test_measure_root_fallback_actual_numeric_maps(tmp_path,monkeypatch):
    stub_metadata(monkeypatch)
    from vhd.he.workflow import measure
    from vhd.he.fixed import extract_he_concentrations_reference,fixed_scale_he_tissue_score
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']),'root')
    before=copy.deepcopy(cfg);rec=measure(cfg,spec)
    assert cfg==before;assert rec['source_resolution']['layout']=='outs_spatial'
    pixels=np.array(Image.open(f/'tissue_hires_image.png'))
    H,E,_=extract_he_concentrations_reference(pixels,channel_axis=-1,Io=255.,intensity_range=[0,255],alpha='white')
    score,hn,en=fixed_scale_he_tissue_score(H,E)
    for name,value in [('H_raw',H),('E_raw',E),('H_fixed',hn),('E_fixed',en),('he_tissue_score',score)]:
        np.testing.assert_allclose(np.load(Path(spec['_paths']['work'])/'he_fixed'/f'{name}.npy'),value,atol=3e-7)
    bins=pd.read_pickle(Path(spec['_paths']['work'])/'bins_he.parquet')
    assert list(bins.index)==['b1','b2','b3','b4']
    assert not bins.loc['b4','he_tissue_score_valid']
    assert np.isnan(bins.loc['b4','he_tissue_score'])


def test_original_completed_measurement_reused_without_rewriting(tmp_path,monkeypatch):
    stub_metadata(monkeypatch)
    from vhd.he import workflow as patched
    # Test original signature compatibility against the exact shipped v4.1.1
    # workflow retained in the hotfix package's independent evidence folder.
    source_path=os.environ.get('VHD_HE_ORIGINAL_WORKFLOW')
    if not source_path:pytest.skip('Set VHD_HE_ORIGINAL_WORKFLOW to original workflow text for cross-version test.')
    original=types.ModuleType('vhd.he._original_test');original.__package__='vhd.he'
    exec(compile(Path(source_path).read_text(),source_path,'exec'),original.__dict__)
    cfg,spec=cfg_spec(tmp_path);pair(Path(spec['outs']))
    expected=original.measure(cfg,spec)
    paths=list(Path(spec['_paths']['work']).rglob('*'))+list(Path(spec['_paths']['report']).rglob('*'))
    before={str(p):(p.read_bytes(),p.stat().st_mtime_ns) for p in paths if p.is_file()}
    monkeypatch.setattr(patched,'extract_he_concentrations_reference',lambda *a,**k:pytest.fail('Must reuse, not recompute'))
    assert patched.measure(cfg,spec)==expected
    after={str(p):(p.read_bytes(),p.stat().st_mtime_ns) for p in paths if p.is_file()}
    assert before==after


def test_unresolved_source_stops_before_sample_directories(tmp_path,monkeypatch):
    stub_metadata(monkeypatch)
    from vhd.he.workflow import measure
    cfg,spec=cfg_spec(tmp_path)
    with pytest.raises(FileNotFoundError):measure(cfg,spec)
    assert not Path(spec['_paths']['work']).exists()


def test_empty_directory_from_previous_failure_is_not_partial_output(tmp_path,monkeypatch):
    stub_metadata(monkeypatch)
    from vhd.he.workflow import measure
    cfg,spec=cfg_spec(tmp_path);pair(Path(spec['outs']),'root')
    (Path(spec['_paths']['work'])/'he_fixed').mkdir(parents=True)
    assert measure(cfg,spec)['source_resolution']['layout']=='outs_spatial'


def test_untracked_map_still_rejected_and_preserved(tmp_path,monkeypatch):
    stub_metadata(monkeypatch)
    from vhd.he.workflow import measure
    cfg,spec=cfg_spec(tmp_path);pair(Path(spec['outs']))
    f=Path(spec['_paths']['work'])/'he_fixed/H_raw.npy';f.parent.mkdir(parents=True);f.write_bytes(b'leave me')
    with pytest.raises(RuntimeError,match='Partial/untracked'):measure(cfg,spec)
    assert f.read_bytes()==b'leave me'


def test_changed_source_still_invalidates_completion(tmp_path,monkeypatch):
    stub_metadata(monkeypatch)
    from vhd.he.workflow import measure
    cfg,spec=cfg_spec(tmp_path);f=pair(Path(spec['outs']))
    measure(cfg,spec)
    Image.fromarray(np.full((8,10,3),230,np.uint8)).save(f/'tissue_hires_image.png')
    with pytest.raises(RuntimeError,match='Stale/incomplete'):measure(cfg,spec)


def test_diagnostic_uses_plain_id_and_writes_nothing(tmp_path,monkeypatch):
    import vhd.control.manifest as m
    cfg,spec=cfg_spec(tmp_path);pair(Path(spec['outs']),'root')
    row={'sample_id':'A','sample_key':'P__A'};project={'rows':[row]}
    monkeypatch.setattr(m,'row_config',lambda project,row:(cfg,spec))
    monkeypatch.setattr(m,'sample_layout',lambda project,row:{'work':tmp_path/'not_created'})
    before={str(p):p.read_bytes() for p in tmp_path.rglob('*') if p.is_file()}
    r=diagnose_he_sources(project,['A'])['P__A']
    assert r['status']=='resolved' and r['resolution']['layout']=='outs_spatial'
    assert r['compact_master_source_check']['status']=='paths_resolved'
    assert not (tmp_path/'not_created').exists()
    assert before=={str(p):p.read_bytes() for p in tmp_path.rglob('*') if p.is_file()}
    json.dumps(r,allow_nan=False)


def test_diagnostic_returns_actionable_unresolved_report(tmp_path,monkeypatch):
    import vhd.control.manifest as m
    cfg,spec=cfg_spec(tmp_path);row={'sample_id':'A','sample_key':'P__A'}
    monkeypatch.setattr(m,'row_config',lambda project,row:(cfg,spec))
    monkeypatch.setattr(m,'sample_layout',lambda project,row:{'work':tmp_path/'not_created'})
    r=diagnose_he_sources({'rows':[row]},['A'])['P__A']
    assert r['status']=='unresolved' and r['error_type']=='FileNotFoundError'
    assert r['compact_master_source_check']['status']=='not_ready'
    assert r['candidate_pairs'][0]['hires']['state']=='missing'
    assert not list(tmp_path.iterdir())
