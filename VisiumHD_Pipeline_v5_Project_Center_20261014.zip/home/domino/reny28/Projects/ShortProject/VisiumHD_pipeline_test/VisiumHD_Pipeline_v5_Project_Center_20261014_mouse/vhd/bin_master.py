"""Explicit bin-master checkpoint and sample-identity guards.

No population intersection, relabelling, implicit source adoption, or approval.
Only ensure_bin_master() writes, through the existing native assembler/writer.
"""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path

PATCH_ID = 'vhd-bin-master-lifecycle-20261015-r1'
CHECKPOINT = 'bin_master_checkpoint.json'


def _read_json(path, limit=16 * 1024**2):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'Expected a regular metadata file: {path}')
    with path.open('rb') as handle:
        data = handle.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f'Metadata exceeds safety limit: {path}')
    obj = json.loads(data)
    if not isinstance(obj, dict):
        raise ValueError(f'Expected a JSON object: {path}')
    return obj


def _paths(cfg, spec):
    # Do not call core.sample_paths(): it mkdir()s even for read-only checks.
    q = {k: Path(v) for k, v in spec.get('_paths', {}).items()}
    if q:
        w, r = q['work'], q['report']
    else:
        w = Path(cfg['work_root']) / spec['sample']
        r = Path(cfg['output_root']) / 'reports' / spec['sample']
        q = {'store': Path(cfg['output_root'])/'samples'/f"{spec['sample']}.zarr"}
    return dict(q, work=w, report=r, bins=w/'bins_raw.h5ad', bin_obs=w/'bins_qc_obs.parquet',
                geometry=w/'geometry.json', prior=w/'prior_qc.npy', cells=w/'cells_qc.h5ad')


def root_identity(store):
    """Read authoritative root metadata, without opening scientific arrays."""
    store = Path(store)
    if store.is_symlink() or not store.is_dir():
        raise ValueError(f'Expected a nonsymlink master directory: {store}')
    v3, v2 = store/'zarr.json', store/'.zgroup'
    if v3.exists() and v2.exists():
        raise ValueError(f'Ambiguous root metadata (v2 and v3): {store}')
    if v3.exists():
        doc = _read_json(v3)
        if doc.get('zarr_format') != 3 or doc.get('node_type') != 'group':
            raise ValueError(f'Invalid v3 group metadata: {v3}')
        attrs = doc.get('attributes', {})
    elif v2.exists():
        if _read_json(v2).get('zarr_format') != 2:
            raise ValueError(f'Invalid v2 group metadata: {v2}')
        attrs = _read_json(store/'.zattrs')
    else:
        raise ValueError(f'No recognized Zarr root metadata: {store}; do not adopt this directory.')
    if not isinstance(attrs, dict):
        raise ValueError('Root attributes must be a mapping.')
    return attrs


def assert_destination_identity(cfg, spec):
    """A missing destination is allowed. A foreign/unknown existing master is not."""
    p = _paths(cfg, spec); store = p['store']
    expected = {'sample': str(spec['sample']), 'dataset_id': str(spec['dataset_id'])}
    if store.is_symlink():
        raise ValueError(f'Master destination is a symlink: {store}')
    if store.exists():
        attrs = root_identity(store)
        observed = {k: attrs.get(k) for k in expected}
        if observed != expected:
            raise ValueError(
                f'MASTER SAMPLE IDENTITY MISMATCH: requested {expected}, found {observed} at {store}. '
                'Correct this sample\'s master_store to an approved NEW destination. '
                'Do not rename another sample\'s store or align by overlapping bin IDs.')
        return {'exists': True, **expected, 'store': str(store)}
    return {'exists': False, **expected, 'store': str(store)}


def check_project_destinations(project, row):
    """Catch duplicate/overlapping outputs and foreign stores before a worker writes."""
    from .control.manifest import row_config, sample_layout
    if row.get('goal') == 'export_only':
        return
    target = Path(sample_layout(project, row)['store']).resolve()
    for other in project['rows']:
        if other['sample_key'] == row['sample_key'] or other.get('goal') == 'export_only':
            continue
        candidate = Path(sample_layout(project, other)['store']).resolve()
        if target == candidate or target in candidate.parents or candidate in target.parents:
            raise ValueError(f'Master destinations overlap for {row["sample_key"]} and '
                             f'{other["sample_key"]}: {target} / {candidate}')
    cfg, spec = row_config(project, row)
    assert_destination_identity(cfg, spec)


def _stamp(path):
    path = Path(path)
    if path.is_symlink():
        raise ValueError(f'Symlinked checkpoint prerequisite: {path}')
    if not path.exists():
        return {'path': str(path), 'exists': False}
    st = path.stat()
    return {'path': str(path), 'exists': True, 'is_file': path.is_file(),
            'size': st.st_size, 'mtime_ns': st.st_mtime_ns}


def signature(cfg, spec):
    p = _paths(cfg, spec)
    inputs = {name: _stamp(p['work']/name) for name in (
        'bins_raw.h5ad', 'bins_qc_obs.parquet', 'geometry.json', 'he_normalization.json',
        'he_fixed/measurement.json', 'he_fixed/complete.json')}
    payload = {'schema': PATCH_ID, 'sample': spec['sample'], 'dataset_id': spec['dataset_id'],
               'destination': str(p['store'].resolve()), 'inputs': inputs,
               'storage': cfg['storage'], 'metadata': spec.get('metadata', {})}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()


def _assert_transactions_idle(store):
    store = Path(store)
    for name in (str(store)+'.partial', str(store)+'.vhd_writer.lock'):
        if Path(name).exists() or Path(name).is_symlink():
            raise RuntimeError(f'Existing partial product/writer lock: {name}; inspect, do not delete.')
    transactions = Path(str(store)+'.vhd_transactions')
    if transactions.is_symlink():
        raise RuntimeError('Symlinked transaction history is not accepted.')
    for journal in sorted(transactions.glob('*/journal.json')):
        state = _read_json(journal).get('state')
        if state not in ('committed', 'rolled_back'):
            raise RuntimeError(f'Unresolved transaction: {journal}; no automatic recovery.')


def _assert_tracked(cfg, spec):
    from .core import file_stamp
    p = _paths(cfg, spec)
    marker, receipt = p['report']/'storage_manifest.json', p['report']/'master_sources.json'
    if not marker.is_file() or not receipt.is_file():
        raise RuntimeError('Existing master has no matching workspace assembly receipts. '
                           'Use a new destination or separately reviewed adoption; no automatic overwrite.')
    sources = _read_json(receipt); storage = _read_json(marker)
    if sources.get('bin_source') != file_stamp(p['bins']):
        raise RuntimeError('Master receipt does not identify the current prepared bins; do not reuse it.')
    if not storage.get('path') or Path(storage['path']).resolve() != p['store'].resolve():
        raise RuntimeError('Storage receipt points to a different master destination.')
    if not (p['store']/'tables/bins_2um').is_dir():
        raise RuntimeError('Tracked master lacks tables/bins_2um.')
    return sources, storage



def _verify_he_maps(cfg, spec):
    p = _paths(cfg, spec); measurement = p['work']/'he_fixed/measurement.json'
    if not measurement.is_file():
        return {'he_measurement_present': False, 'he_maps_checked': []}
    record = _read_json(measurement); receipt = p['report']/'he_master.json'
    if not receipt.is_file() or _read_json(receipt).get('signature') != record.get('signature'):
        raise RuntimeError('H&E measurements have not been synchronized to this master; '
                           'inspect assembly/storage receipts before certifying the checkpoint.')
    names = [n if n.startswith('he_') else 'he_'+n for n in record.get('maps',{})]
    missing = [n for n in names if not (p['store']/'images'/n).is_dir()]
    if missing:
        raise RuntimeError('H&E map elements missing from master: '+str(missing))
    return {'he_measurement_present': True, 'he_maps_checked': names}


def checkpoint_reusable(cfg, spec):
    """Cheap inventory after a prior full check; not a fresh matrix-integrity test."""
    p = _paths(cfg, spec); certificate = p['report']/CHECKPOINT
    if not certificate.is_file():
        return False
    try:
        report = _read_json(certificate)
        if report.get('status') != 'complete' or report.get('signature') != signature(cfg, spec):
            return False
        if not assert_destination_identity(cfg, spec)['exists']:
            return False
        _assert_tracked(cfg, spec)
        _verify_he_maps(cfg, spec)
        _assert_transactions_idle(p['store'])
        return True
    except (OSError, ValueError, RuntimeError, KeyError):
        return False


def center_contract(project, row):
    from .control.manifest import row_config
    return signature(*row_config(project, row))


def center_done(project, row):
    from .control.manifest import row_config
    return checkpoint_reusable(*row_config(project, row))


def _verify_base_obs(cfg, spec):
    """Check base QC columns and observation population; never load X/layers here."""
    import pandas as pd
    from .io import table_metadata
    p = _paths(cfg, spec)
    source = pd.read_parquet(p['bin_obs'])
    live, _ = table_metadata(p['store'], 'bins_2um')
    if not source.index.is_unique or not live.index.is_unique or not source.index.equals(live.index):
        raise ValueError('Bin-master checkpoint: base QC and master IDs/order differ. No intersection or relabelling.')
    required = ['qc_keep', 'qc_class']
    missing = [c for c in required if c not in source or c not in live]
    if missing:
        raise ValueError('Base bin QC columns missing: '+str(missing))
    checked = []
    for col in source:
        if col in ('region', 'instance_id'):
            continue
        if col not in live:
            raise ValueError(f'Base metadata column absent from master: {col}')
        pd.testing.assert_series_equal(source[col], live[col], check_dtype=False,
                                       check_categorical=False, check_names=False)
        checked.append(str(col))
    return {'n_bins': len(source), 'base_columns_checked': checked,
            'observation_population_changed': False, 'expression_loaded_by_verifier': False}


def ensure_bin_master(cfg, spec):
    """Assemble or validate a real base-bin master regardless of external assets."""
    from .core import require_review, stage_lock, dump_json
    from .master import assemble_master
    from .adapters.assemble import validate_product
    if '_project' in cfg and '_row' in spec:
        check_project_destinations(cfg['_project'], spec['_row'])
        from .control.manifest import check_policy
        check_policy(cfg['_project'])
    identity = assert_destination_identity(cfg, spec)
    require_review(cfg, spec)
    if not cfg['storage'].get('single_writer_ack', False):
        raise PermissionError('Confirm intended master and exclusive writers before building bin master.')
    p = _paths(cfg, spec)
    for name in ('bins', 'bin_obs', 'geometry'):
        if not p[name].is_file():
            raise FileNotFoundError(f'Bin-master prerequisite missing: {p[name]}')
    _assert_transactions_idle(p['store'])
    if identity['exists']:
        _assert_tracked(cfg, spec)
    if checkpoint_reusable(cfg, spec):
        print('BIN_MASTER_CHECKPOINT reused:', p['store'], flush=True)
        return _read_json(p['report']/CHECKPOINT)
    start_signature = signature(cfg, spec)
    with stage_lock(p['work'], 'bin_master_checkpoint'):
        # Never assemble on top of a foreign or untracked product.
        exists = assert_destination_identity(cfg, spec)['exists']
        if exists:
            _assert_tracked(cfg, spec)
        print('BIN_MASTER_CHECKPOINT '+('validate existing (no master rewrite)' if exists else 'create')+
              ': '+str(p['store']), flush=True)
        if not exists:
            # A pre-existing annotation sidecar must not be adopted merely by filename.
            if (p['work']/'bins_annotated_obs.parquet').exists():
                from .master import current_annotations
                current_annotations(copy.deepcopy(cfg), spec)
            assemble_master(cfg, spec, bins_only=True)
        assert_destination_identity(cfg, spec)
        _assert_tracked(cfg, spec)
        validation = validate_product(p['store'])
        obs_report = _verify_base_obs(cfg, spec)
        he_report = _verify_he_maps(cfg, spec)
        if signature(cfg, spec) != start_signature:
            raise RuntimeError('Bin prerequisites/settings changed during checkpoint; no completion certificate written.')
        report = {'schema': PATCH_ID, 'status': 'complete', 'sample': spec['sample'],
                  'dataset_id': spec['dataset_id'], 'store': str(p['store']),
                  'signature': start_signature, 'validation': validation, **obs_report, **he_report,
                  'external_assets_selected_or_imported': False,
                  'scope': 'Base bin master. Annotation, nuclear, cell and biological reviews are separate.',
                  'reuse_policy': 'Source stamps + sample identity + tracking receipts + element presence; '
                                  'not a full integrity recheck on every UI refresh.'}
        dump_json(report, p['report']/CHECKPOINT)
    return report


def sync_optional_prior(cfg, spec):
    """Retain the native optional nuclei label when early assembly precedes StarDist.

    Only add a previously absent label. Existing labels are never replaced here.
    Native optional_nuclei() supplies the same transform and label construction.
    """
    if not cfg['storage'].get('include_nuclei_prior', False):
        return
    p = _paths(cfg, spec)
    if not p['prior'].exists() or (p['store']/'labels/nuclei_prior').exists():
        return
    assert_destination_identity(cfg, spec)
    import spatialdata as sd
    from .storage import optional_nuclei
    from .persistence import persist_changes
    from .core import sample_paths
    native_paths = sample_paths(cfg, spec)
    geom = _read_json(p['geometry'])
    prior = optional_nuclei(cfg, spec, native_paths, geom)
    if prior is None:
        return
    s = sd.read_zarr(p['store'], selection=('images','labels','shapes','points'))
    s.labels['nuclei_prior'] = prior
    persist_changes(s, new_elements=['nuclei_prior'], policy=cfg['storage_policy'],
                    staging_dir=p['work'], execute=True,
                    single_writer_ack=cfg['storage'].get('single_writer_ack', False))
