# What changed in this candidate

The new files in `vhd/center/` provide controller state, normalized configuration copies, report registration/rendering, route/review boundaries, resource probing, a Jupyter Widgets UI, and an optional independent analysis worker. The normal launcher is new; the old notebooks are retained under `notebooks/advanced/` with saved outputs cleared in the delivery copy only.

**Every preexisting `vhd/` source file from the supplied snapshot is byte-preserved.** Existing scientific VERSION/fingerprints are not bumped just because the controller release is 0.5.0rc1. `SOURCE_PROVENANCE.json` records the checked counts/hashes. Source data and on-instance files were not changed.

One inherited test fixture was corrected: `test_bin_qc_review.py` previously assumed the owner's active settings contained null cutoffs. The supplied settings already had chosen cutoffs, so the missing-threshold test now explicitly constructs missing threshold values before asserting rejection. The classifier and user's configuration were not changed.

## Formal reports

All stages share a fixed HTML report style, bounded embedded thumbnails, readable summary tables, and expandable technical metadata. Reports distinguish existing evidence, saved decisions and executed actions. Report generation is attached to center action/save boundaries and explicit Refresh, not a background monitoring service.

## Scope of the one-save annotation action

Within a controller lock, the action operates on managed copies, refreshes changed category discovery, reapplies the current UI selections and extent confirmation, runs the real existing gallery-evidence/choice validator, validates native signal pixels when requested, and records the approval. Rejected saves restore managed values and retain a draft. It does not fabricate stored-source receipts or bypass actual import/transfer.

Per-file backups/replacements are not an atomic transaction across a mounted biological store and all controller files. The state revision/fingerprint checks stop on an interrupted/inconsistent save. There is no claim of general transaction support on arbitrary object-store mounts.

## Future work deliberately not hidden in this release

Full branching of already completed scientific revisions; safe bulk sheet reimport/merge into an existing project; richer per-sample scientific parameter editing; per-stage measured-memory learning; detached background scheduling; stronger cross-process storage transactions; and production UI/scientific acceptance testing on the user's environment.
