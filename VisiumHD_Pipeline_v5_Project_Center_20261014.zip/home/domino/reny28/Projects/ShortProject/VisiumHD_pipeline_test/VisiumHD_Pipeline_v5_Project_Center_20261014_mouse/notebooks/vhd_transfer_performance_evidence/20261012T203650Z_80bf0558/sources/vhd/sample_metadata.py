"""Attach scalar sample metadata to observations without altering expression.

Import/build call `attach_sample_metadata` on the in-memory table. Existing masters
use `sync_sample_metadata`, which delegates only obs/uns component writes to the
existing recoverable writer. Neither function invents biological values.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from .control.sample_metadata import validate_values, validate_field_name, value_digest, SCHEMA_VERSION

RECORD_KEY = 'vhd_sample_metadata_json'


def _record(uns):
    raw = uns.get(RECORD_KEY)
    if raw is None:
        return {}
    if not isinstance(raw, str):
        raise ValueError(f'{RECORD_KEY} must be a JSON string.')
    result = json.loads(raw)
    if not isinstance(result, dict) or result.get('schema') != SCHEMA_VERSION:
        raise ValueError('Unknown sample metadata ownership record; do not overwrite it.')
    owned = result.get('owned_columns', [])
    if not isinstance(owned, list) or any(not isinstance(k, str) for k in owned) or len(set(owned)) != len(owned):
        raise ValueError('Invalid sample metadata ownership record.')
    for key in owned:
        validate_field_name(key)
    return result


def _matches(series, value):
    if value is None:
        return bool(series.isna().all())
    if series.isna().any():
        return False
    # Avoid accepting a Boolean flag as a numeric measurement with the same value.
    if isinstance(value, bool) != pd.api.types.is_bool_dtype(series):
        if isinstance(value, bool) or pd.api.types.is_bool_dtype(series):
            return False
    try:
        return bool(series.eq(value).fillna(False).all())
    except (ValueError, TypeError):
        return False


def _constant(value, index):
    if value is None:
        return pd.Series(np.nan, index=index, dtype='float64')
    if isinstance(value, str):
        # One category per sample is substantially cheaper than millions of copies.
        return pd.Series(pd.Categorical.from_codes(np.zeros(len(index), dtype=np.int8),
                         categories=pd.Index([value], dtype=object)), index=index)
    dtype = 'bool' if isinstance(value, bool) else 'int64' if isinstance(value, int) else 'float64'
    return pd.Series(value, index=index, dtype=dtype)


def plan_sample_metadata(obs, uns, spec, *, replace_owned=False, prune_owned=False):
    """Return changed obs columns and the next provenance record; never mutate input.

    Existing conflicting non-owned columns always fail. Explicit replacement and
    pruning can affect only columns recorded as owned by this metadata mechanism.
    Identical existing fields are retained without claiming ownership of them.
    """
    values = validate_values(dict(spec.get('metadata', {})))
    if not obs.index.is_unique or not obs.columns.is_unique:
        raise ValueError('Sample metadata attachment requires unique observation IDs and columns.')
    for key in ('sample', 'sample_id', 'dataset_id'):
        expected = spec.get(key)
        if expected is not None and key in obs and not _matches(obs[key], expected):
            raise ValueError(f'Table {key} does not match selected sample; refusing cross-sample metadata.')
    prior = _record(uns)
    if prior and prior.get('sample_key') != spec.get('sample'):
        raise ValueError('Stored sample metadata belongs to another sample.')
    owned = set(prior.get('owned_columns', []))
    removed = sorted(owned - set(values))
    if removed and not prune_owned:
        raise ValueError(f'Metadata no longer supplies owned columns {removed}. '
                         'Review and use prune_owned=True to remove only these metadata fields.')
    changed = pd.DataFrame(index=obs.index)
    next_owned = owned & set(values)
    retained_equal = []
    for key, value in values.items():
        if key in obs:
            if _matches(obs[key], value):
                retained_equal.append(key)
                continue
            if key not in owned or not replace_owned:
                raise ValueError(f'Metadata column {key!r} conflicts with existing observations. '
                                 'Rename it, or explicitly replace it only if owned by this mechanism.')
        else:
            next_owned.add(key)
        changed[key] = _constant(value, obs.index)
    record = {'schema': SCHEMA_VERSION, 'sample_key': spec.get('sample'),
              'metadata_signature': value_digest(values), 'values': values,
              'owned_columns': sorted(next_owned),
              'source': spec.get('metadata_provenance', {})}
    # Do not rewrite the per-table provenance when only another sample's CSV row
    # changed. The complete source snapshot remains recorded at project level.
    equivalent = (prior.get('metadata_signature') == record['metadata_signature'] and
                  prior.get('owned_columns') == record['owned_columns'] and
                  prior.get('sample_key') == record['sample_key'])
    record_text = json.dumps(prior if equivalent else record, sort_keys=True, allow_nan=False)
    plan = {'sample': spec.get('sample'), 'n_observations': len(obs),
            'add_or_replace': list(changed), 'drop_owned': removed,
            'retained_equal': retained_equal, 'writes_expression': False,
            'record_changed': uns.get(RECORD_KEY) != record_text}
    return changed, removed, record_text, plan


def attach_sample_metadata(adata, spec):
    """Attach to a newly created in-memory AnnData; inputs/counts stay unchanged."""
    if not spec.get('metadata') and RECORD_KEY not in adata.uns:
        return {'add_or_replace': [], 'writes_expression': False}
    changed, drop, record, plan = plan_sample_metadata(adata.obs, adata.uns, spec)
    if drop:
        raise AssertionError('Default attachment does not prune metadata.')
    for key in changed:
        adata.obs[key] = changed[key]
    if plan['record_changed']:
        adata.uns[RECORD_KEY] = record
    return plan


def sync_sample_metadata(cfg, spec, *, execute=False, replace_owned=False, prune_owned=False):
    """Preview or persist sample metadata on already assembled bins/cells only.

    Does not run import, segmentation or normalization. Preview reads obs/var and
    the one provenance key, never X/layers or full image arrays. Actual writes
    rewrite obs/selected uns components via the existing recoverable writer.
    """
    from .core import sample_paths
    from .io import table_metadata
    from .persistence import update_table_metadata
    from .persistence.spatial import open_group
    from anndata.io import read_elem
    row = spec.get('_row', {})
    if row.get('goal') == 'export_only':
        return {'status': 'export_only_unchanged', 'tables': [], 'writes_expression': False}
    p = sample_paths(cfg, spec)
    plans = []
    for table in ('bins_2um', 'cells'):
        base = Path(p['store']) / 'tables' / table
        if not base.is_dir():
            continue
        obs, _ = table_metadata(p['store'], table)
        group = open_group(base)
        uns = {}
        if 'uns' in group and RECORD_KEY in group['uns']:
            uns[RECORD_KEY] = read_elem(group['uns'][RECORD_KEY])
        if not spec.get('metadata') and not uns:
            plans.append({'table': table, 'status': 'no_metadata', 'writes_expression': False})
            continue
        changed, drop, record, plan = plan_sample_metadata(
            obs, uns, spec, replace_owned=replace_owned, prune_owned=prune_owned)
        plan['table'] = table
        plans.append((plan, changed, drop, record))
    if not plans:
        raise FileNotFoundError(f"No bins_2um/cells table at {p['store']}; assemble before metadata sync.")
    # All available tables are checked for collisions before the first write.
    results = []
    for item in plans:
        if isinstance(item, dict):
            results.append(item)
            continue
        plan, changed, drop, record = item
        updates = {RECORD_KEY: record} if plan['record_changed'] else None
        if changed.shape[1] or drop or updates:
            write_plan = update_table_metadata(
                p['store'], plan['table'], obs=changed if changed.shape[1] else None,
                drop_obs=drop, uns=updates, policy=cfg['storage_policy'], staging_dir=p['work'],
                execute=execute, single_writer_ack=cfg['storage'].get('single_writer_ack', False))
            plan['status'] = 'written' if execute else 'preview'
            plan['writer'] = write_plan
        else:
            plan['status'] = 'unchanged'
        results.append(plan)
    return {'execute': execute, 'tables': results, 'writes_expression': False}
