> Inherited technical reference. For the v4.1 source/category interface, start with START_HERE.md, ASSETS_V41_DISCOVERY.md and SIGNAL_MEASUREMENTS_V41.md. Older file-level role examples remain compatibility-only.

# Repository handoff for v4

This downloadable bundle was prepared without changing the live GitHub repository. It is not a claim that the unmerged foundation, scVI fix, or documentation PR now contains v4.

Use a separate code branch and compare this bundle to the installed version before a future reviewed source import. The obsolete v3-only patch and its repository preparation utility are intentionally not presented as v4 import tools. Do not apply the old execution/validator hotfix installers on top of this consolidated source.

Keep `project_1/` as historical input. Never upload real manifests, source images, matrices, private deployment paths, executed notebook outputs or corporate assets into a public repository. Perform a current repository read before a future PR, preserve its existing work, and let the owner decide merges. Historical documentation under `docs/history_v3/` is provenance, not the current installation guide.
