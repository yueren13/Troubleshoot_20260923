"""Journaled component replacement. Recoverable, NOT atomic across Zarr keys.

No background cleanup. Old and incoming payloads remain until explicit retirement.
Single-writer acknowledgement requires the caller to stop concurrent readers too.
"""
from __future__ import annotations
import os,json,uuid,shutil
from pathlib import Path
from contextlib import contextmanager
from ..core import dump_json
from ..control.storage import sha256,free_space_gate
from ..control.paths_v3 import assert_target,require_roots,storage_profile


def inventory(path):
    p=Path(path)
    if p.is_symlink():raise ValueError('Symlinked component is not supported.')
    if p.is_file():return [{'path':'.','bytes':p.stat().st_size,'sha256':sha256(p)}]
    if not p.is_dir():raise FileNotFoundError(p)
    out=[]
    for f in sorted(p.rglob('*')):
        if f.is_symlink():raise ValueError('Symlinked component child is not supported.')
        if f.is_file():out.append({'path':f.relative_to(p).as_posix(),'bytes':f.stat().st_size,'sha256':sha256(f)})
    return out


def copy_verified(src,dst):
    expected=inventory(src);dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(src,dst) if Path(src).is_dir() else shutil.copy2(src,dst)
    if inventory(dst)!=expected:raise IOError('Staged/backup copy mismatch.')


def remove_component(p):
    if p.is_symlink():raise ValueError('Refusing to remove symlink.')
    if p.is_dir():shutil.rmtree(p)
    elif p.exists():p.unlink()


def target(store,rel):
    r=Path(rel)
    if r.is_absolute() or '..' in r.parts or len(r.parts)<2 or r.parts[0] not in ('images','labels','shapes','points','tables'):raise ValueError('Not an explicit spatial component path.')
    p=Path(store)/r
    if not p.resolve().is_relative_to(Path(store).resolve()):raise ValueError('Component escapes master.')
    return p


def validate_store(store,policy):
    require_roots(policy);p=Path(store).resolve()
    if not p.is_dir():raise FileNotFoundError('Incremental updates need an existing master.')
    roots=policy.get('approved_master_roots',policy.get('approved_object_roots',[]))
    for x in (p,p.parent/(p.name+'.vhd_transactions'),p.parent/(p.name+'.vhd_writer.lock')):assert_target(x,roots)
    return p


@contextmanager
def writer(store,policy,ack=False,recovery=False):
    p=validate_store(store,policy)
    if not ack:raise PermissionError('Explicit single_writer_ack=True and no concurrent readers/writers required.')
    if not recovery:
        for j in (p.parent/(p.name+'.vhd_transactions')).glob('*/journal.json'):
            if json.loads(j.read_text()).get('state') not in ('committed','rolled_back'):raise RuntimeError(f'Unresolved transaction: {j}')
    lock=p.parent/(p.name+'.vhd_writer.lock');fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    os.write(fd,json.dumps({'pid':os.getpid(),'store':str(p)}).encode());os.close(fd)
    try:yield p
    finally:lock.unlink(missing_ok=True)


def apply_replacements(store,replacements,policy,*,execute=False,single_writer_ack=False,refresh=None,verify=None,precondition=None,_fault=None):
    store=validate_store(store,policy);pairs=[]
    for relative,source in replacements.items():
        dest=target(store,relative);source=Path(source).resolve()
        if source.is_relative_to(store):raise ValueError('Stage payload outside live master before replacement.')
        pairs.append((relative,source,dest))
    rels=[Path(x[0]) for x in pairs]
    if any(a!=b and (a in b.parents or b in a.parents) for a in rels for b in rels):raise ValueError('Overlapping component updates.')
    plan={'master':str(store),'components':[x[0] for x in pairs],'execute':execute}
    if not execute or not pairs:return plan
    with writer(store,policy,single_writer_ack):
        if precondition:precondition(store)
        need=sum(sum(e['bytes'] for e in inventory(src))*2+(sum(e['bytes'] for e in inventory(dst)) if dst.exists() else 0) for _,src,dst in pairs)
        profile=storage_profile(store,policy)
        if profile.get('capacity_check',policy.get('check_master_free_space',True)):
            free_space_gate(store.parent,need,policy.get('min_free_master_gib',0))
        root=store.parent/(store.name+'.vhd_transactions')/uuid.uuid4().hex;root.mkdir(parents=True)
        journal=root/'journal.json';ops=[{'relative':r,'existed':d.exists(),'status':'planned'} for r,_,d in pairs]
        record={'schema':1,'master':str(store),'state':'preparing','operations':ops};dump_json(record,journal)
        try:
            for op,(_,src,dst) in zip(ops,pairs):
                copy_verified(src,root/'incoming'/op['relative']);op['incoming']=inventory(root/'incoming'/op['relative'])
                if dst.exists():copy_verified(dst,root/'backup'/op['relative']);op['old']=inventory(dst)
                op['status']='backed_up';dump_json(record,journal)
            record['state']='prepared';dump_json(record,journal)
            if _fault:_fault('prepared')
            for op,(_,_,dst) in zip(ops,pairs):
                op['status']='promoting';record['state']='promoting';dump_json(record,journal)
                remove_component(dst);copy_verified(root/'incoming'/op['relative'],dst)
                op['status']='promoted';dump_json(record,journal)
                if _fault:_fault('promoted:'+op['relative'])
            if refresh:refresh(store)
            if verify:verify(store)
            record['state']='committed';dump_json(record,journal)
        except BaseException as exc:
            record['state']='needs_recovery';record['error']=repr(exc);dump_json(record,journal)
            raise RuntimeError(f'Update incomplete. Recover using {journal}; do not delete backups or retry blindly.') from exc
    return {**plan,'state':'committed','journal':str(journal),'backups_retained':True}


def recover_transaction(journal,policy,*,execute=False,single_writer_ack=False,allow_partial=False,refresh=None):
    j=Path(journal).resolve();record=json.loads(j.read_text());p=validate_store(record['master'],policy);root=j.parent
    if not root.is_relative_to(p.parent/(p.name+'.vhd_transactions')):raise ValueError('Journal does not belong to master.')
    if record['state']=='committed':raise ValueError('Do not automatically roll back a committed transaction.')
    if record['state']=='rolled_back':return record
    for op in record['operations']:
        if op['status']=='planned':continue
        live=target(p,op['relative'])
        if op['existed'] and inventory(root/'backup'/op['relative'])!=op['old']:raise IOError('Backup invalid; manual recovery required.')
        if live.exists() and inventory(live) not in (op.get('old'),op.get('incoming')):
            if not (allow_partial and op['status']=='promoting'):raise RuntimeError('Live data differs; inspect potential newer edits. Partial interrupted copy requires explicit allow_partial.')
    if not execute:return {'journal':str(j),'action':'rollback','execute':False}
    with writer(p,policy,single_writer_ack,recovery=True):
        for op in record['operations']:
            if op['status']=='planned':continue
            live=target(p,op['relative']);remove_component(live)
            if op['existed']:copy_verified(root/'backup'/op['relative'],live)
        if refresh:refresh(p)
        record['state']='rolled_back';dump_json(record,j)
    return record
