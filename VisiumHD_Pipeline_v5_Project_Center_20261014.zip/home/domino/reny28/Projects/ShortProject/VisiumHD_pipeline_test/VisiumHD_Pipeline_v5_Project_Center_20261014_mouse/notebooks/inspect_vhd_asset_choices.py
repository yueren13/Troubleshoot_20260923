"""Inspect category-choice loading and the native review planner; no repairs or saves.

Uses the existing in-kernel ProjectCenter. Does not open a new Center, execute
workers, approve choices, or write a report. Native preview validation can read
and hash configured sources. It does not perform metadata transfer or segmentation.
"""
from __future__ import annotations

import gc
import importlib
import json
import os
from pathlib import Path
import sys
import traceback


def _find_center(controller=None):
    if controller is not None:
        if not all(callable(getattr(controller, n, None)) for n in ('snapshot', 'choices', 'row')):
            raise TypeError('Pass your existing ProjectCenter object.')
        return controller
    candidates = {}
    for obj in gc.get_objects():
        cls = type(obj)
        if cls.__name__ == 'ProjectCenter' and cls.__module__ == 'vhd.center.controller':
            candidates[id(obj)] = obj
    if len(candidates) != 1:
        raise RuntimeError(
            f'Found {len(candidates)} existing ProjectCenter objects. '
            'Run in the kernel displaying the intended Center, or pass that '
            'specific existing controller. No controller was created.'
        )
    return next(iter(candidates.values()))


def _failure(exc):
    result = {'exception': type(exc).__name__, 'message': str(exc),
              'traceback': ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))}
    # Report explicit local path variables, not arbitrary locals or source contents.
    locations = []
    for frame, lineno in traceback.walk_tb(exc.__traceback__):
        if not str(frame.f_globals.get('__name__', '')).startswith('vhd.'):
            continue
        for name in ('path', 'p', 'f', 'report_path', 'summary_path', 'overrides'):
            value = frame.f_locals.get(name)
            if isinstance(value, Path) or (isinstance(value, str) and os.path.isabs(value)):
                item = {'function': frame.f_code.co_name, 'line': lineno,
                        'variable': name, 'path': str(value)}
                if item not in locations:
                    locations.append(item)
    result['path_variables_from_traceback'] = locations
    if isinstance(exc, json.JSONDecodeError):
        result['json_position'] = {'line': exc.lineno, 'column': exc.colno,
                                  'position': exc.pos, 'document_characters': len(exc.doc)}
    return result


def inspect_asset_choices(controller=None, *, sample='Navli-82'):
    """Return a small report and print every failure in full. No files are written."""
    controller = _find_center(controller)
    manifest = importlib.import_module('vhd.control.manifest')
    workflow = importlib.import_module('vhd.annotations.workflow')
    discovery = importlib.import_module('vhd.annotations.discovery')
    state = controller.snapshot()
    project = state['project']
    key = manifest.resolve_sample_keys(project, [sample])[0]
    row = controller.row(key, project)
    workspace = Path(controller.workspace)
    managed_choices = workspace / 'engine' / 'asset_choices.csv'
    report = {
        'sample_key': key, 'workspace': str(workspace),
        'managed_choices_used_by_ui': str(managed_choices),
        'source_modules': {m.__name__: getattr(m, '__file__', None)
                           for m in (manifest, workflow, discovery)},
        'steps': {}, 'inspection_only': True,
        'no_workers_or_approvals_or_configuration_changes': True,
    }
    print('Sample:', key)
    print('Existing Center:', workspace)
    print('UI choice table:', managed_choices)

    def step(name, callback):
        print('\n=== ' + name + ' ===')
        try:
            value = callback()
            report['steps'][name] = {'status': 'read', 'value': value}
            print(json.dumps(value, indent=2, default=str))
            return value
        except Exception as exc:
            info = _failure(exc)
            report['steps'][name] = {'status': 'error', **info}
            print(info['traceback'], end='')
            if info.get('path_variables_from_traceback'):
                print('Paths exposed by the failing VHD call:')
                print(json.dumps(info['path_variables_from_traceback'], indent=2))
            if info.get('json_position'):
                print('JSON decode details:', info['json_position'])
            return None

    raw_assets = []
    def assets_summary():
        nonlocal raw_assets
        raw_assets = workflow.read_assets(row.get('assets_manifest'), row['dataset_id'], row['sample_id'])
        fields = ('asset_id', 'kind', 'role', 'format', 'path', 'category_column',
                  'registration_mode', 'coverage_mode', 'coverage_path', 'review_table')
        return [{f: asset.get(f, '') for f in fields} for asset in raw_assets]
    step('Configured asset sources', assets_summary)

    def ui_choices():
        choices = controller.choices(key)
        fields = ('asset_id', 'item_key', 'category', 'include_in_obs', 'qc_use',
                  'obs_name', 'coverage_mode', 'cell_methods')
        return {'count': len(choices),
                'by_asset': {a['asset_id']: sum(c['asset_id'] == a['asset_id'] for c in choices)
                             for a in raw_assets},
                'rows': [{f: c.get(f, '') for f in fields} for c in choices]}
    step('Choices visible to the UI', ui_choices)

    for asset in raw_assets:
        value = asset.get('review_table')
        if asset.get('role') != 'discover' or not value:
            continue
        path = Path(value).expanduser()
        def table_summary(path=path, aid=asset['asset_id']):
            choices = discovery.read_choices(path)
            selected = [c for c in choices if c['sample_key'] == key and c['asset_id'] == aid]
            return {'path': str(path), 'exists': path.is_file(),
                    'same_path_as_ui_table': path.resolve() == managed_choices.resolve(),
                    'matching_rows': len(selected),
                    'categories': [c['category'] for c in selected]}
        step('Configured choice table: ' + asset['asset_id'], table_summary)

    def gallery_summary():
        frame = controller.galleries(key)
        return frame.to_dict('records')
    step('Saved gallery index', gallery_summary)
    step('Native review planner (full error if any)',
         lambda: discovery.preview_selected_plan(project, [key], require_approval=False))
    print('\nInspection finished. No discovery, repair, approval, transfer, or run was requested.')
    return report
