# Historical v4 delivery evidence

These files describe the previous **0.4.0-review** bundle, not this v4.1 build.
Test totals must not be added to the current test total. Archived configurations
retain their original relative references; they are **reference-only copies, not
runnable files at this relocated path**. Use the current root config templates.
