"""Opt-in actual worker fit/infer; a CPU test does not establish GPU or DDP behavior."""
import os,json
from pathlib import Path
import pytest
pytestmark=pytest.mark.skipif(os.environ.get('VHD_TEST_SCVI_WORKER')!='1',reason='Explicit VHD_TEST_SCVI_WORKER=1 and scVI environment required.')


def test_real_worker_handoff(tmp_path):
    import anndata as ad
    import numpy as np
    import pandas as pd
    from scipy import sparse
    from vhd.compute.scvi_worker import execute
    cfg=json.loads((Path(__file__).parents[1]/'config/settings.g5_24xlarge.example.json').read_text())
    cfg['_integration_work']=str(tmp_path);cfg['execution']['scvi']={'mode':'single','devices':1}
    cfg['execution']['reserve_ram_gib']=0;cfg['execution']['host_ram_budget_gib']=16
    cfg['scvi'].update(require_gpu=False,n_latent=3,n_hidden=16,n_layers=1,max_epochs=1,batch_size=32,max_training_ram_gib=16)
    cfg['plots']['dpi']=40
    a=ad.AnnData(X=sparse.csr_matrix(np.random.default_rng(42).poisson(2,(80,30)).astype(np.int32)),obs=pd.DataFrame({'sample':pd.Categorical(['a']*40+['b']*40)},index=[f'c{i}' for i in range(80)]))
    a.write_h5ad(tmp_path/'scvi_counts_hvg.h5ad')
    assert execute(cfg,'train')['status']=='trained'
    assert execute(cfg,'train')['status']=='model_reused_waiting_for_inference'
    assert execute(cfg,'infer')['status']=='inference_complete'
    assert execute(cfg,'infer')['status']=='reused'
    assert np.load(tmp_path/'latent.npy').shape==(80,3)
