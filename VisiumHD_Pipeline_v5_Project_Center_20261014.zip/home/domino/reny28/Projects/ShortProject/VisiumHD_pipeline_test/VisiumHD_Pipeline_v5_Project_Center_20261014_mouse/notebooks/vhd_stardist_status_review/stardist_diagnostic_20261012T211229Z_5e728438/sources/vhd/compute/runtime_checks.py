"""Launch-time import checks in the selected interpreter, not the notebook kernel.

Checks run once per action before submitting sample jobs. No pip/uv installation,
no model fitting, no data access, and no interpreter symlink resolution.
Imports can initialize libraries and use the worker's configured scratch caches.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess


def executable_path(value, base):
    """Make an executable path absolute WITHOUT dereferencing symlinks.

    Data paths and write-allowlist checks must continue to use their existing
    canonicalization. A venv/bin/python is an invocation path, not just a file.
    Parent components are retained because symlink/.. has filesystem semantics.
    """
    value = str(value).strip()
    for a, b in re.findall(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)', value):
        if (a or b) not in os.environ:
            raise ValueError(f'Unset executable path variable: {a or b}')
    value = os.path.expanduser(os.path.expandvars(value))
    if not value or '://' in value or any(c in value for c in ('\x00', '\n', '\r', '*', '?')):
        raise ValueError('Executable must be an explicit nonempty filesystem path, not a URL, glob or command string.')
    p = Path(value)
    if not p.is_absolute():
        p = Path(base).absolute() / p
    return str(p)  # NEVER p.resolve() or realpath(p)


def action_imports(action, *, backend=None):
    modules = ['numpy', 'pandas', 'scipy', 'psutil', 'vhd.control.runner']
    if action != 'export_existing':
        modules += ['anndata', 'zarr']
    if action in {'assemble', 'assemble_bins', 'import_cells', 'import_bins', 'ingest_raw',
                  'postprocess_cells', 'refresh_cell_annotations', 'import_assets',
                  'transfer_assets', 'writeback', 'prepare','analysis_qc','replot'}:
        modules += ['spatialdata', 'geopandas', 'shapely', 'dask', 'h5py', 'pyarrow']
    if action in {'prepare','analysis_qc'}:modules += ['scanpy','pyarrow']
    if action=='prepare':modules += ['skmisc']
    if action in {'import_assets','transfer_assets'}:modules += ['defusedxml','tifffile','PIL']
    if action == 'stardist':
        modules += ['tensorflow', 'stardist', 'csbdeep']
    if action in {'train', 'infer'}:
        modules += ['torch', 'scvi', 'h5py', 'pyarrow']
    if action == 'cluster':
        modules += ['scanpy']
        if backend in {'rapids', 'rapids_dask'}:
            modules += ['cupy', 'rapids_singlecell']
        if backend == 'rapids_dask':
            modules += ['dask_cuda']
    return list(dict.fromkeys(modules))


_PROBE = r'''
import importlib, json, sys
print('VHD_RUNTIME ' + json.dumps({'executable': sys.executable,
    'prefix': sys.prefix, 'base_prefix': sys.base_prefix}), flush=True)
for name in json.loads(sys.argv[1]):
    print('IMPORT ' + name, flush=True)
    importlib.import_module(name)
print('VHD_IMPORTS_OK', flush=True)
'''


def preflight_python(executable, modules, *, env=None, cwd=None, timeout=180):
    """Stop once with the actual interpreter/import error before starting jobs."""
    exe = str(executable)
    if not Path(exe).is_file() or not os.access(exe, os.X_OK):
        raise FileNotFoundError(f'Configured Python is not an executable file: {exe}')
    cmd = [exe, '-B', '-u', '-c', _PROBE, json.dumps(list(modules))]
    try:
        result = subprocess.run(cmd, env=env, cwd=cwd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, errors='replace',
                                timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        text = exc.stdout or ''
        if isinstance(text, bytes):
            text = text.decode(errors='replace')
        raise RuntimeError(f'Worker import preflight timed out for {exe}. No sample jobs were submitted.\n{text[-8000:]}') from exc
    output = result.stdout or ''
    if result.returncode:
        raise RuntimeError(
            f'Worker import preflight failed (exit={result.returncode}).\n'
            f'Configured executable: {exe}\nNo sample jobs for this action were submitted.\n'
            f'{output[-12000:]}\nCheck the interpreter path before installing packages. '
            'Do not replace a venv/bin/python with its resolved base binary.'
        )
    records = [line[len('VHD_RUNTIME '):] for line in output.splitlines() if line.startswith('VHD_RUNTIME ')]
    if len(records) != 1 or 'VHD_IMPORTS_OK' not in output.splitlines():
        raise RuntimeError(f'Unexpected Python preflight output for {exe}:\n{output[-8000:]}')
    record = json.loads(records[0])
    venv_root = Path(exe).parent.parent
    if (venv_root / 'pyvenv.cfg').is_file():
        if not Path(record['prefix']).exists() or not os.path.samefile(record['prefix'], venv_root):
            raise RuntimeError(f'Python did not enter the requested virtual environment: {record}. '
                               'Check PYTHONHOME and executable configuration. No sample jobs were submitted.')
    print(json.dumps({'worker_import_preflight': 'passed', **record,
                      'modules': list(modules), 'scientific_execution_tested': False}, indent=2), flush=True)
    return record
