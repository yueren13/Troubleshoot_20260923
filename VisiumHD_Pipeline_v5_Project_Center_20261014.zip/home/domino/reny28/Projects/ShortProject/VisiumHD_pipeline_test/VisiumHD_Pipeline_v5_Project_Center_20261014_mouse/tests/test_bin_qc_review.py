"""Numerical/real-HDF5 tests; Parquet is stubbed only in explicitly named tests."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace, ModuleType

import h5py
import numpy as np
import pandas as pd
import pytest

from vhd.he import qc_review as q
from vhd.he.workflow import classify
from vhd.core import file_stamp
from vhd.control.manifest import COLUMNS, load_project, row_config, sample_layout

BASE = Path(__file__).parents[1]


def thresholds(**kwargs):
    return q._thresholds({"transcript_metric":"total_counts", "transcript_transform":"identity", **kwargs})


def batch_factory(h, valid, tx, chunks=7):
    h, valid, tx = map(np.asarray, (h, valid, tx))
    return lambda: ((h[i:i+chunks],valid[i:i+chunks],tx[i:i+chunks]) for i in range(0,len(h),chunks))


def test_exact_histograms_all_bins_zeros_and_no_input_mutation():
    h=np.array([0,.1,.2,.5,1,np.nan],np.float32)
    valid=np.array([1,1,1,1,1,0],bool)
    tx=np.array([0,1,3,100,10000,5],np.int64)
    before=[x.copy() for x in (h,valid,tx)]
    out=q.summarize_batches(batch_factory(h,valid,tx,2),thresholds=thresholds())
    s=out['summary']
    assert s['n_bins']==6 and s['n_he_valid']==5 and s['n_transcript_valid']==6 and s['n_joint_valid']==5
    assert s['n_zero_transcripts']==1 and s['n_he_exact_one']==1
    assert out['he_hist'].sum()==5 and out['transcript_hist'].sum()==6 and out['density'].sum()==5
    assert s['candidate_class_counts'] is None
    for original,old in zip((h,valid,tx),before):np.testing.assert_array_equal(original,old)


@pytest.mark.parametrize('transform',['identity','log1p'])
@pytest.mark.parametrize('h_dtype',[np.float32,np.float64])
def test_candidate_quadrants_match_existing_classifier(transform,h_dtype):
    h=np.array([0,.2,.3,.3,.8,1,np.nan],h_dtype)
    v=np.array([1,1,1,1,1,1,0],bool);tx=np.array([0,1,2,3,4,np.nan,9.])
    setting={'tissue_score_threshold':.3,'transcript_threshold':(np.log1p(3) if transform=='log1p' else 3.),'transcript_transform':transform}
    out=q.summarize_batches(batch_factory(h,v,tx,2),thresholds=q._thresholds(setting))
    obs=pd.DataFrame({'total_counts':tx})
    measurement=pd.DataFrame({'he_tissue_score':h,'he_tissue_score_valid':v})
    expected=classify(obs,measurement,setting)
    assert out['summary']['candidate_class_counts']=={k:int((expected.qc_class==k).sum()) for k in q.CLASSES}
    assert out['summary']['candidate_qc_keep_count']==int(expected.qc_keep.sum())


def test_scatter_uniform_priority_subset_is_chunk_invariant_and_capped():
    n=10003;rng=np.random.default_rng(13)
    h=rng.random(n);tx=rng.integers(0,500,n);v=rng.random(n)>.15
    outputs=[q.summarize_batches(batch_factory(h,v,tx,c),thresholds=thresholds(),scatter_max_points=31) for c in (41,300,10003)]
    for out in outputs:
        assert out['summary']['scatter_n']==31
        np.testing.assert_array_equal(out['he_hist'],outputs[0]['he_hist'])
        np.testing.assert_array_equal(out['density'],outputs[0]['density'])
        np.testing.assert_array_equal(out['scatter_he'],outputs[0]['scatter_he'])
        np.testing.assert_array_equal(out['scatter_tx'],outputs[0]['scatter_tx'])


def test_transcript_threshold_only_changes_labels_not_keep_estimate():
    h=np.linspace(0,1,21).astype(np.float32);v=np.ones(21,bool);tx=np.arange(21)
    outputs=[q.summarize_batches(batch_factory(h,v,tx),thresholds=thresholds(tissue_score_threshold=.5,transcript_threshold=t)) for t in (1,16)]
    assert outputs[0]['summary']['candidate_qc_keep_count']==outputs[1]['summary']['candidate_qc_keep_count']
    assert outputs[0]['summary']['candidate_class_counts']!=outputs[1]['summary']['candidate_class_counts']


def test_tail_is_not_hidden_and_ticks_are_original_units():
    result=q.summarize_batches(batch_factory([.4],[True],[12001]),thresholds=thresholds())
    assert result['summary']['transcript_axis_max']==100000
    assert result['transcript_hist'].sum()==1
    assert q._count_ticks(10000).tolist()==[0,1,10,100,1000,10000]


def test_candidate_does_not_change_settings():
    s={'tissue_score_threshold':None,'transcript_threshold':None,'transcript_transform':'log1p'};before=copy.deepcopy(s)
    qv=q._thresholds(s,{'tissue_score_threshold':.2,'transcript_threshold':np.log(4.)})
    assert s==before and qv['transcript_threshold_raw_equivalent']==pytest.approx(3.)
    assert qv['origin']=='plot_only_candidate'


@pytest.mark.parametrize('kw',[{'tissue_score_threshold':-1},{'tissue_score_threshold':1.1},
    {'transcript_threshold':-1},{'transcript_threshold':True},{'transcript_threshold':'3'},
    {'tissue_score_threshold':np.nan},{'transcript_threshold':np.inf},
    {'transcript_transform':'log10'},{'transcript_metric':'X/data'}])
def test_bad_thresholds_rejected(kw):
    with pytest.raises((ValueError,TypeError)):q._thresholds(kw)


def test_unknown_candidate_key_rejected():
    with pytest.raises(ValueError):q._thresholds({}, {'min_counts':3})


@pytest.mark.parametrize('h,v,tx',[
    ([.5],[1],[2]), ([np.nan],[True],[2]), ([1.01],[True],[2]),
    ([-.1],[True],[2]), ([.5],[True],[-1]), ([.5,.6],[True],[1]),
    (['.5'],[True],[2]),
])
def test_corrupt_arrays_fail_not_silently_coerce(h,v,tx):
    with pytest.raises(ValueError):q.summarize_batches(batch_factory(h,v,tx),thresholds=thresholds())


def test_empty_and_no_joint_valid_are_distinguished():
    with pytest.raises(ValueError,match='no 2-micron'):
        q.summarize_batches(lambda:iter([]),thresholds=thresholds())
    result=q.summarize_batches(batch_factory([np.nan,np.nan],[False,False],[0,2]),thresholds=thresholds())
    assert result['summary']['n_joint_valid']==0 and result['transcript_hist'].sum()==2


def test_nonreplayable_factory_rejected():
    iterator=iter([(np.array([.2]),np.array([True]),np.array([1]))])
    with pytest.raises(RuntimeError):q.summarize_batches(lambda:iterator,thresholds=thresholds())


def make_h5(path, ids, tx):
    with h5py.File(path,'w') as f:
        obs=f.create_group('obs');obs.attrs['_index']='barcode';obs.attrs['encoding-type']='dataframe';obs.attrs['encoding-version']='0.2.0'
        obs.attrs['column-order']=np.array(['total_counts'],dtype=h5py.string_dtype())
        obs.create_dataset('barcode',data=np.asarray(ids,dtype=object),dtype=h5py.string_dtype())
        obs.create_dataset('total_counts',data=np.asarray(tx))
        f.create_dataset('X',data=np.arange(len(ids)*2).reshape(len(ids),2))
    return path


def test_hdf5_column_reader_never_needs_X(tmp_path,monkeypatch):
    path=make_h5(tmp_path/'a.h5ad',['x','y','z'],[0,3,16])
    get=h5py.Dataset.__getitem__
    def guard(self,key):
        if self.name.startswith('/X'):raise AssertionError('Expression read!')
        return get(self,key)
    monkeypatch.setattr(h5py.Dataset,'__getitem__',guard)
    with h5py.File(path,'r') as f:
        assert q._read_h5_obs_vector(f['obs'],'barcode',0,2,strings=True).tolist()==['x','y']
        assert q._read_h5_obs_vector(f['obs'],'total_counts',1,3).tolist()==[3,16]


def test_hdf5_nullable_numeric_and_bad_encoding(tmp_path):
    p=make_h5(tmp_path/'a.h5ad',['x','y'],[1,2])
    with h5py.File(p,'a') as f:
        g=f['obs'].create_group('nullable');g.attrs['encoding-type']='nullable-integer'
        g.create_dataset('values',data=[1,2]);g.create_dataset('mask',data=[False,True])
        bad=f['obs'].create_group('bad');bad.attrs['encoding-type']='categorical'
    with h5py.File(p,'r') as f:
        r=q._read_h5_obs_vector(f['obs'],'nullable',0,2);assert r[0]==1 and np.isnan(r[1])
        with pytest.raises(ValueError,match='Unsupported'):q._read_h5_obs_vector(f['obs'],'bad',0,2)


def project_fixture(tmp_path):
    tmp_path.mkdir(parents=True,exist_ok=True)
    s=json.loads((BASE/'config/settings.json').read_text());s.pop('path_variables_file',None);s.pop('sample_metadata',None)
    s['plots']['dpi']=50;s['run_id']='review_test'
    s['proseg']['executable']=sys.executable
    policy=s['storage_policy']
    for k in list(policy):
        if k.startswith('approved_') and k.endswith('_roots'):policy[k]=[str(tmp_path)]
    policy['required_existing_roots']=[str(tmp_path)];policy['required_sentinels']=[];policy['locations']=[]
    for k in ('control_dir','tmp_dir','output_object_dir','output_plot_dir','output_data_dir','work_dir'):
        s['integration'][k]=str(tmp_path/'integration'/k)
    r=dict.fromkeys(COLUMNS,'');r.update(enabled='true',dataset_id='Study',sample_id='S1',stage='raw',goal='bin_QCed',
        spaceranger_outs=str(tmp_path/'input/outs'),segmentation_image=str(tmp_path/'input/he.svs'),
        output_object_dir=str(tmp_path/'output'),output_plot_dir=str(tmp_path/'plots'),output_data_dir=str(tmp_path/'tables'),
        tmp_dir=str(tmp_path/'scratch'),work_dir=str(tmp_path/'work'),master_store=str(tmp_path/'master.zarr'))
    for f,rows in [('samples.csv',[r])]:
        with (tmp_path/f).open('w',newline='') as h:
            w=csv.DictWriter(h,fieldnames=list(r));w.writeheader();w.writerows(rows)
    (tmp_path/'settings.json').write_text(json.dumps(s))
    return load_project(tmp_path/'samples.csv',tmp_path/'settings.json')


def receipt_fixture(project):
    row=project['rows'][0];cfg,_=row_config(project,row);p=sample_layout(project,row);work=p['work'];work.mkdir(parents=True)
    (work/'he_fixed').mkdir()
    bins=make_h5(work/'bins_raw.h5ad',['a','b','c','d'],[0,2,4,100])
    score=work/'bins_he.parquet';score.write_bytes(b'PARQUET IS STUBBED IN THESE TESTS')
    meta=work/'he_fixed/measurement.json';meta.write_text(json.dumps({'signature':'fixture','parameters':cfg['he_score']}))
    marker=work/'he_fixed/complete.json';marker.write_text(json.dumps({'signature':'fixture','outputs':[file_stamp(meta),file_stamp(score)]}))
    return p,[bins,score,meta,marker]


def test_preview_no_dirs_or_data_reads_and_threshold_display(tmp_path,monkeypatch):
    pr=project_fixture(tmp_path);before={str(p) for p in tmp_path.rglob('*')}
    monkeypatch.setattr(q,'_check_completed_measurement',lambda *a,**k:(_ for _ in ()).throw(AssertionError('read!')))
    result=q.generate_bin_qc_review(pr,['S1'],execute=False)
    assert result['mode'].tolist()==['PREVIEW_ONLY']
    assert before=={str(p) for p in tmp_path.rglob('*')}
    loc=q.threshold_locations(pr,['S1']);assert loc.iloc[0].settings_file==pr['settings_path']
    # Explicit missing-value fixture, independent of the operator's config/settings.json.
    pr['settings']['bin_qc'].update(tissue_score_threshold=None,transcript_threshold=None)
    with pytest.raises(ValueError,match='No workers'):q.validate_bin_qc_thresholds(pr,['S1'])


def test_check_threshold_overrides_from_actual_configuration(tmp_path):
    pr=project_fixture(tmp_path)
    override=tmp_path/'override.json';override.write_text(json.dumps({'bin_qc':{'tissue_score_threshold':.2,'transcript_threshold':2}}))
    pr['rows'][0]['overrides_json']=str(override)
    result=q.validate_bin_qc_thresholds(pr,['S1']);assert result.iloc[0].transcript_threshold==2
    assert result.iloc[0].overrides_json==str(override)


def test_plot_workflow_with_explicitly_stubbed_parquet_keeps_input_bytes(tmp_path,monkeypatch):
    pr=project_fixture(tmp_path);p,inputs=receipt_fixture(pr)
    before={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in inputs+[Path(pr['settings_path']),Path(pr['manifest_path'])]}
    data=(np.array([0,.25,.5,1],np.float32),np.ones(4,bool),np.array([0,2,4,100]))
    monkeypatch.setattr(q,'iter_metadata_batches',lambda *a,**k:iter([data]))
    result=q.generate_bin_qc_review(pr,['S1'],execute=True,candidate_thresholds={'tissue_score_threshold':.4,'transcript_threshold':3})
    folder=Path(result.iloc[0].report_dir)
    assert len(list(folder.glob('*.png')))==4
    summary=json.loads((folder/'review_summary.json').read_text())
    assert summary['n_bins']==4 and summary['candidate_qc_keep_count']==2
    assert summary['expression_values_read'] is False
    for filename,sha in before.items():assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==sha
    # Same request makes another new report folder rather than overwriting old reports.
    result2=q.generate_bin_qc_review(pr,['S1'],execute=True)
    assert result2.iloc[0].report_dir!=str(folder) and folder.is_dir()


def test_source_change_and_missing_completion_stop(tmp_path,monkeypatch):
    pr=project_fixture(tmp_path);p,paths=receipt_fixture(pr)
    cfg,_=row_config(pr,pr['rows'][0])
    paths[1].write_bytes(b'changed')
    with pytest.raises(ValueError,match='changed'):q._check_completed_measurement(p['work'],cfg)
    paths[-1].unlink()
    with pytest.raises(FileNotFoundError,match='Complete measure_he'):q._check_completed_measurement(p['work'],cfg)


def test_he_parameter_mismatch_stops(tmp_path):
    pr=project_fixture(tmp_path);p,_=receipt_fixture(pr);cfg,_=row_config(pr,pr['rows'][0]);cfg['he_score']['h_weight']=.2
    with pytest.raises(ValueError,match='settings differ'):q._check_completed_measurement(p['work'],cfg)


def test_density_and_histogram_figures_render_without_valid_he(tmp_path):
    result=q.summarize_batches(batch_factory([np.nan,np.nan],[False,False],[0,2]),thresholds=thresholds())
    folder=tmp_path/'plots';folder.mkdir()
    images=q.render_review(result,folder,sample='Synthetic invalid-score example',thresholds=thresholds(),dpi=40)
    assert len(images)==4 and all(Path(p).stat().st_size>1000 for p in images.values())


def install_fake_parquet(monkeypatch, ids, h, valid, *, index_name='barcode', expected_rows=None):
    """Explicit Arrow API test double: does NOT test Parquet serialization."""
    data={'he_tissue_score':np.asarray(h),'he_tissue_score_valid':np.asarray(valid),'barcode':np.asarray(ids,dtype=object)}
    if index_name!='barcode':data[index_name]=data.pop('barcode')
    seen=[]
    class Array:
        def __init__(self,a):self.a=a;self.null_count=sum(v is None for v in a)
        def to_numpy(self,zero_copy_only=False):return self.a
    class Batch:
        def __init__(self,cols,start,end):
            self.data=[Array(data[c][start:end]) for c in cols];self.num_rows=end-start
            self.schema=SimpleNamespace(get_field_index=cols.index)
        def column(self,i):return self.data[i]
    class PF:
        def __init__(self,path):
            self.metadata=SimpleNamespace(num_rows=len(ids) if expected_rows is None else expected_rows)
            self.schema_arrow=SimpleNamespace(names=list(data),metadata={b'pandas':json.dumps({'index_columns':[index_name]}).encode()})
        def iter_batches(self,*,batch_size,columns,use_threads):
            seen.append(columns)
            for i in range(0,len(ids),batch_size):yield Batch(columns,i,min(i+batch_size,len(ids)))
        def close(self):pass
    pa=ModuleType('pyarrow');pa.__path__=[];pa.__version__='0.0.0'
    pq=ModuleType('pyarrow.parquet');pq.ParquetFile=PF;pa.parquet=pq
    monkeypatch.setitem(sys.modules,'pyarrow',pa);monkeypatch.setitem(sys.modules,'pyarrow.parquet',pq)
    return seen


def test_streaming_reader_real_h5_with_explicit_arrow_stub(tmp_path,monkeypatch):
    path=make_h5(tmp_path/'bins.h5ad',['a','b','c'],[0,1,3])
    seen=install_fake_parquet(monkeypatch,['a','b','c'],[0,.1,.8],[True,True,True])
    actual=list(q.iter_metadata_batches(path,'stubbed.parquet',chunk_size=2))
    assert [len(b[0]) for b in actual]==[2,1]
    assert set(seen[0])=={'he_tissue_score','he_tissue_score_valid','barcode'}
    assert actual[1][2][0]==3


def test_streaming_reader_order_guard_with_explicit_arrow_stub(tmp_path,monkeypatch):
    path=make_h5(tmp_path/'bins.h5ad',['a','b'],[0,1])
    install_fake_parquet(monkeypatch,['b','a'],[0,.1],[True,True])
    with pytest.raises(ValueError,match='identities/order'):
        list(q.iter_metadata_batches(path,'stubbed.parquet',chunk_size=1))


def test_streaming_reader_length_guard_with_explicit_arrow_stub(tmp_path,monkeypatch):
    path=make_h5(tmp_path/'bins.h5ad',['a','b'],[0,1])
    install_fake_parquet(monkeypatch,['a','b'],[0,.1],[True,True],expected_rows=3)
    with pytest.raises(ValueError,match='different row counts'):
        list(q.iter_metadata_batches(path,'stubbed.parquet'))
