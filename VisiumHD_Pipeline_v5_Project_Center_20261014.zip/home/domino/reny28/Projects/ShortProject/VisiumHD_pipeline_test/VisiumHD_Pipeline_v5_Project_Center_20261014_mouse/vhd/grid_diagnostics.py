"""Read positions/barcode identifiers before loading the expression matrix.

No count values or image pixels are read by this module's preparation functions.
Reports are written only by fit_and_report when a destination is explicitly given.
"""
from __future__ import annotations

import gzip
import json
from pathlib import Path
import numpy as np
import pandas as pd

from .core import dump_json, file_stamp
from .grid_geometry import GridGeometryError
from .projective_grid import PROJECTIVE_GRID_PATCH as GRID_FIT_PATCH, fit_grid_model_checked

REQUIRED = ('array_row', 'array_col', 'pxl_col_in_fullres', 'pxl_row_in_fullres')


def read_matrix_barcodes(matrix):
    matrix = Path(matrix)
    if matrix.is_dir():
        candidates = [matrix / 'barcodes.tsv.gz', matrix / 'barcodes.tsv']
        found = [p for p in candidates if p.is_file()]
        if len(found) != 1:
            raise ValueError('Expected exactly one barcodes.tsv or barcodes.tsv.gz in raw matrix directory.')
        opener = gzip.open if found[0].suffix == '.gz' else open
        with opener(found[0], 'rt', encoding='utf-8') as stream:
            values = [line.rstrip('\r\n') for line in stream]
        if any('\t' in v for v in values):
            raise ValueError('Expected a single-column raw-barcode file.')
    else:
        import h5py
        with h5py.File(matrix, 'r') as handle:
            if 'matrix/barcodes' not in handle:
                raise ValueError('Space Ranger raw H5 lacks matrix/barcodes.')
            values = handle['matrix/barcodes'].asstr()[()]
    index = pd.Index(values, dtype=object)
    if len(index) == 0 or index.hasnans or not all(isinstance(v, str) and v for v in index):
        raise ValueError('Raw barcodes must be nonempty strings.')
    if not index.is_unique:
        raise ValueError('Raw barcode identifiers are duplicated.')
    return index


def positions_for_matrix(sr):
    """Reproduce the original exact barcode join, but before expression loading."""
    names = read_matrix_barcodes(sr['matrix'])
    pos = pd.read_parquet(sr['positions'])
    if 'barcode' not in pos or pos['barcode'].isna().any():
        raise ValueError('tissue_positions.parquet needs nonmissing unique barcode column.')
    pos['barcode'] = pos['barcode'].astype(str)
    if pos['barcode'].duplicated().any():
        raise ValueError('tissue_positions.parquet needs unique barcode column.')
    missing = [k for k in REQUIRED if k not in pos.columns]
    if missing:
        raise ValueError(f'Missing required position columns: {missing}')
    pos = pos.set_index('barcode').reindex(names)
    if pos[list(REQUIRED)].isna().any().any():
        raise ValueError('At least one raw barcode lacks original full-resolution coordinates.')
    for key in ('array_row', 'array_col'):
        val = pos[key].to_numpy(dtype=float)
        if not np.isfinite(val).all() or np.any(val < 0) or not np.equal(val, np.rint(val)).all():
            raise ValueError(f'Invalid integer grid positions in {key}.')
        pos[key] = val.astype(np.int64)
    if pos[['array_row', 'array_col']].duplicated().any():
        raise ValueError('Duplicate 2-um array grid positions.')
    return pos


def fit_and_report(rows, cols, xy, coordinate_settings, *, report_path=None,
                   source=None, source_mpp=None, context=None, source_column_dtypes=None):
    """Use the same check in diagnostics, raw import, and existing-bin import."""
    tolerance = coordinate_settings.get('grid_max_residual_px', .1)
    policy = coordinate_settings.get('grid_rounding_policy', 'verified_integer')
    extra = {'source': str(source) if source is not None else None,
             'context': context or 'bin_coordinates', 'counts_loaded_for_this_check': False,
             'patch': GRID_FIT_PATCH,
             'source_column_dtypes': source_column_dtypes or {}}
    if source is not None and Path(source).is_file():
        extra['source_stamp'] = file_stamp(source)
    try:
        matrix, report = fit_grid_model_checked(rows, cols, xy, tolerance_px=tolerance,
                rounding_policy=policy, geometry_policy=coordinate_settings.get(
                    "grid_geometry_policy", "auto_projective"))
    except GridGeometryError as exc:
        exc.report.update(extra)
        _physical_units(exc.report, source_mpp)
        if report_path is not None:
            dump_json(exc.report, report_path)
            raise GridGeometryError(f'{exc} Diagnostic: {report_path}', exc.report) from exc
        raise
    report.update(extra)
    report['grid_index_to_fullres'] = matrix.tolist()
    _physical_units(report, source_mpp)
    if report_path is not None:
        dump_json(report, report_path)
    return matrix, report


def _physical_units(report, source_mpp):
    if source_mpp is not None:
        value = float(source_mpp)
        if not np.isfinite(value) or value <= 0:
            raise ValueError('Source microns_per_pixel must be positive and finite.')
        report['source_microns_per_pixel'] = value
        report['max_residual_um_using_scalar_source_mpp'] = report['max_residual_px'] * value
        report['physical_error_note'] = 'Uses declared scalar source calibration, not image registration accuracy.'


def prepare_raw_grid(sr, cfg, spec, *, report_path=None):
    pos = positions_for_matrix(sr)
    scales = json.loads(Path(sr['scales']).read_text())
    source_mpp = spec.get('source_mpp_override') or scales.get('microns_per_pixel')
    xy = pos[['pxl_col_in_fullres', 'pxl_row_in_fullres']].to_numpy(np.float64)
    matrix, report = fit_and_report(pos.array_row, pos.array_col, xy, cfg['coordinates'],
                                    report_path=report_path, source=sr['positions'],
                                    source_mpp=source_mpp, context='raw_matrix_barcode_order',
                                    source_column_dtypes={k:str(pos[k].dtype) for k in REQUIRED})
    return pos, xy, matrix, report


def diagnose_project(project, sample_keys=None, *, write_reports=False):
    """Inspect selected raw inputs only. No workers, expression, images or data writes.

    write_reports=False returns reports without filesystem writes. True writes
    small diagnostic JSON files to the configured per-sample reports directory
    after the normal storage-policy check; no expression products are modified.
    """
    from .control.manifest import check_policy, resolve_sample_keys, row_config, sample_layout
    from .io import resolve_spaceranger
    check_policy(project)
    selected = set(resolve_sample_keys(project, sample_keys))
    reports = {}
    for row in project['rows']:
        if row['sample_key'] not in selected:
            continue
        key = row['sample_key']
        cfg, spec = row_config(project, row)
        report_path = Path(sample_layout(project, row)['report']) / 'grid_coordinate_diagnostic.json'
        if row['stage'] != 'raw':
            reports[key] = {'status': 'not_checked', 'reason': 'Diagnostic entry accepts raw-stage rows only.'}
            continue
        try:
            sr = resolve_spaceranger(spec)
            pos, xy, matrix, report = prepare_raw_grid(sr, cfg, spec,
                                      report_path=report_path if write_reports else None)
            reports[key] = report
            del pos, xy, matrix
        except GridGeometryError as exc:
            reports[key] = exc.report
        except Exception as exc:
            reports[key] = {'status': 'error', 'error_type': type(exc).__name__, 'error': str(exc),
                            'patch': GRID_FIT_PATCH, 'expression_matrix_loaded': False}
            if write_reports:
                dump_json(reports[key], report_path)
        reports[key]['expected_report_path'] = str(report_path)
    return reports


def report_summary(reports):
    records = []
    for sample, r in reports.items():
        projective = r.get('projective_diagnostic', {})
        records.append({'sample': sample, 'status': r.get('status'),
                        'acceptance': r.get('acceptance'),
                        'initial_max_error_px': r.get('initial_least_squares', {}).get('max_residual_px'),
                        'accepted_or_initial_max_error_px': r.get('max_residual_px'),
                        'max_axis_error_px': max(r.get('max_abs_axis_residual_px', [np.nan])),
                        'all_coordinates_integer': r.get('all_source_coordinates_integer'),
                        'projective_diagnostic_max_error_px': projective.get('max_residual_px'),
                        'reason': r.get('reason', r.get('error', ''))})
    return pd.DataFrame(records)
