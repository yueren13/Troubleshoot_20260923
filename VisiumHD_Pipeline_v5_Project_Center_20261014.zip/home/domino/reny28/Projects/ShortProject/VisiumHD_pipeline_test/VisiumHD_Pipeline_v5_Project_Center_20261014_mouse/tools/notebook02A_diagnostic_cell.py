# After notebook 02A's existing initialization cell has loaded PROJECT and ROOT:
from pathlib import Path
import runpy

helper = runpy.run_path(
    str(Path(ROOT) / "tools" / "inspect_annotation_geometry.py")
)

audit = helper["inspect_project_annotations"](
    PROJECT,
    SAMPLE_KEYS,
    # Summarize mathematical repair proposals in memory; do NOT apply them.
    check_repair_candidates=True,
)

helper["print_diagnostic_summary"](audit, max_issues=30)

# Full region-level results remain in these DataFrames:
# display(audit["files"])
# display(audit["issues"])
# display(audit["regions"])
# To print every issue, use print_diagnostic_summary(audit, max_issues=None).
