# Implemented scope and remaining validation — v4

## Implemented in this source bundle

The features and configuration paths in README, START_HERE, ASSETS_V4 and IMAGE_AND_ANALYSIS_V4 are wired into the workers/notebooks, not just proposed JSON keys. The execution/validator fixes are included. Reference-only sources are excluded from active scientific transfer and cannot be named as prior-filter sources. Binary raw pixel codes are preserved in the master while a declared 0/1 measurement adapter is used for summaries. Compact image assembly coordinates both writer and validators. Analysis QC is an explicit prerequisite to integration when enabled.

The supplied tests exercise numerical behavior, configuration/routing, pure file/state contracts and selected orchestration with explicitly stubbed scientific I/O. The optional scientific modules require the real libraries and must not be counted as passed when skipped. See VALIDATION_SUMMARY.

## Not established by this release

- Actual new `.annotations` files use the supported ImageScope XML schema. Unsupported active formats stop; no generic extension-based guess is made.
- The user's 1:9 TIFF has zero offset, the same orientation or a particular binary encoding. Example positive=255 and scale=9 are explicit examples requiring source-specific review.
- End-to-end real-slide, mounted-storage, image registration, GPU segmentation, scVI training/inference/DDP or RAPIDS/Dask validation. There are no new biological or timing results here.
- Full out-of-core matrix import or training, unlimited GPU spill, one-slide multi-GPU StarDist, GPU Proseg or distributed multi-GPU UMAP. Inherited limitations remain.
- In-place compaction of an already-written full-resolution master. Use a new target for compact assembly; do not delete under an active writer.
- Cross-species ortholog mapping, arbitrary nonrigid registration, physical-area-weighted pixel pooling, independent molecule measurements from image masks, or hard geometric Proseg exclusion boundaries.
- Exact original Step03 QC decision equivalence. Fresh thresholds remain review inputs rather than inferred values.
- Automatic master-obs writeback of new analysis-QC sidecars or universal shared plot limits across all sample reports. The sidecars are consumed by integration and can be joined explicitly.
- Binary signal role alone creates a Boolean prior filter: prior rules still name explicit Boolean bin columns; continuous-threshold gating is not invented.
- A missing/unparseable reference layer is embedded as valid geometry: it is retained as source/error provenance. A previously stored version may remain with `previous_element_retained`; it is not declared current or computationally active.
- Every unknown future error is fixed, an interrupted multi-file replacement is atomic, or every partial output can be resumed without inspection.

## Next target-environment checkpoints

Run 99 and ensure scientific modules execute; inspect each sample's image registration; test one trusted and one reference-only annotation together; verify TIFF labels/scale against landmarks; review before/after QC counts and gene detection; confirm selected tables and count sums after saving. Validate real training/save/inference before a large integration. A fully completed legacy analysis does not prove equivalence of this new pipeline.
