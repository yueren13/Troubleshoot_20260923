# Findings from the uploaded VHD evidence

Basis: the user-supplied `VHD_transfer_performance_evidence.zip` and the earlier `VHD_transaction_evidence.zip`. This is source/report review, not a live server profile or a replacement for the pipeline code.

## Successful transfer

- Worker action status: `complete`.
- Worker scientific elapsed: 4174.877 seconds (69.58 minutes).
- Launcher elapsed: 4189.594 seconds (69.83 minutes).
- Launcher return code: 0.
- Sampled summed process-tree peak RSS: 31.628 GiB. This is not a hard memory limit or exact unique-memory peak.

## Current measurement

- Number of bins in saved geometry: 10,975,965.
- Registered bin geometry: `projective` / `projective_quadrilaterals`.
- Stain file: `/stash/results/dev/reny28/2026/VisiumHD_pipeline_test/cor_reg/NSCLC-ADC_BM0164135A_s1_A1_coreg_FucGM1_DAB_v1_4x_dwn.tif`.
- Source image shape y,x: `[9663, 13090]`.
- Declared signal type: `continuous`; no silent threshold conversion.
- Stain `bin_method`: `area_mean`; selected signal-method field is `mean`.
- Stored output: `FucGM1_DBA_mean__mean` (exact current spelling).

## Transferred columns and eventual cell summaries

```json
{
  "signature": "1f4916ba9d35aba4e8cb5c490a6b0349fba8b83d185a316dff994d9534f210da",
  "derived_stamp": {
    "path": "/stash/results/dev/reny28/2026/VisiumHD_pipeline_test/work/vhd/Project/BM0164135A_s1_A1/run01/work/bins_annotated_obs.parquet",
    "size": 1165523197,
    "mtime_ns": 1791835763000000000
  },
  "owned_columns": [
    "Anthropotic_HE__assessed",
    "Anthropotic_HE",
    "Necrosis_HE__assessed",
    "Necrosis_HE",
    "Tissue_HE__assessed",
    "Tissue_HE",
    "FucGM1_DBA_mean__mean",
    "FucGM1_DBA_mean__in_bounds_fraction",
    "FucGM1_DBA_mean__valid_fraction",
    "FucGM1_DBA_mean__n_valid_pixels",
    "FucGM1_DBA_mean__valid",
    "base_bin_qc_keep",
    "pathology_assessed",
    "pathology_excluded",
    "segmentation_keep",
    "segmentation_exclusion_reason"
  ],
  "transfer_spec": {
    "categorical": {},
    "boolean": [],
    "continuous": {}
  },
  "prior_filter": {
    "enabled": true,
    "tissue_column": null,
    "exclude_columns": [
      "Anthropotic_HE",
      "Necrosis_HE"
    ],
    "unknown_policy": "exclude",
    "minimum_support_bins": 1,
    "max_excluded_bin_fraction": 0.0,
    "filter_proseg_bins": false,
    "mode": "from_review",
    "tissue_columns": [
      "Tissue_HE"
    ]
  },
  "membership": "bin_centers",
  "continuous_measurement": "Per-field source provenance identifies center samples or exact pixel-overlap footprint summaries. Cell summaries aggregate those BIN measurements, not original image pixels."
}
```

The per-bin `Tissue_HE`, `Anthropotic_HE`, and `Necrosis_HE` memberships influence the saved segmentation decisions. The selected asset table has blank cell_methods, reflected by empty transfer_spec. That is different from failing to save bin-level fields. No cell-summary settings are changed by the review notebook.

## StarDist status: what these attachments do not show

The newest archive includes the transfer worker log/status/resource report but no status_stardist.json or worker_stardist.log. It does not establish the cause of the most recent StarDist launch refusal/failure. The earlier controller code catches non-interrupt exceptions, stores error in jobs[sample][action], and returns status-only events. Its plan marks the next incomplete computation ready; failed execution is not displayed as a failed route row. Hence a ready row and quiet UI do not certify successful StarDist.

## The visual-review gap

The supplied UI includes source-overlay approval before transfer and nuclear/cell reviews afterward. The transfer function saves the master metadata, sidecar and receipt; it does not generate a spatial gallery of the transferred obs values. The companion adds a separate observed-result review, without changing the controller route or auto-approving anything.

## Performance: verified implementation versus inference

- No Squidpy calculate_image_features call appears in the supplied annotation-transfer path. Polygon membership uses chunked Shapely point queries.
- The selected continuous stain uses exact source-pixel-overlap means for projective quadrilaterals, not nearest-center lookup and not the affine rectangular arithmetic branch.
- Sampling uses bounded tiles, but _read_pairs has no tile cache retained across calls. Source tiles can be reread across bin batches.
- validate_signal_encoding explicitly visits every native image pixel tile; the visual-approval/import path can call it before and during import. spatial_image constructs the full source-image tiling. Thus capture-area restriction is not end-to-end.
- Several requested area statistics share one set of overlaps per call. Here only mean was selected. This optimization does not remove repeated validation/copy/hash work or repeated tile reads across calls.
- Most relevant custom loops do not create a thread pool. The launcher OpenMP/BLAS settings do not by themselves parallelize them.
- The 69.83-minute total has no phase-level breakdown in these reports. The dominant bottleneck and a speedup estimate cannot be measured from these files alone.

## Supporting source excerpts (read-only)

### `vhd/center/controller.py` — lines 198–247

SHA256: `51df8184fd9e34674e087b77ad39928157a0ab680e7ea1968fad9db1427296a8`

```python
198: 
199:     def _review_ready(self,d,row,gate):
200:         from ..control.manifest import as_bool,row_config,sample_layout
201:         key=row['sample_key'];p=sample_layout(d['project'],row);review=d['reviews'].get(key,{}).get(gate,{})
202:         if gate=='review_assets':
203:             try:
204:                 from ..annotations.discovery import preview_selected_plan
205:                 plans=preview_selected_plan(d['project'],[key])
206:                 if not plans:return True,'No configured active asset choices.'
207:                 plan=plans[0]
208:                 if plan['active_outputs']==0 and not review:
209:                     return False,'Sources are present. Review their gallery and explicitly save no selected outputs, or select measurements.'
210:                 if plan['choice_approvals_complete']:
211:                     return True,'Current choices are approved or no measurements are selected; actual source checks remain at transfer.'
212:                 return False,'Review overlays and save usage in the Annotations panel.'
213:             except Exception as exc:return False,str(exc)
214:         if gate=='review_bins':
215:             cfg,_=row_config(d['project'],row)
216:             # Imported flags remain recognizable but only with extant classification evidence.
217:             needed=p['report']/'bins_qc_class.png'
218:             if not needed.exists():needed=p['report']/'bins_qc_class_on_HE.png'
219:             if as_bool(row['coordinates_reviewed']) and (row['stage'] not in ('raw','bin_imported') or as_bool(row['fresh_qc_reviewed'])) and needed.is_file():
220:                 if review and any(stamp(x['path'])!=x for x in review.get('evidence',[])):return False,'QC evidence changed since center approval.'
221:                 return True,'Coordinate/QC acknowledgement is set; evidence exists (not an automatic biological assessment).'
222:             return False,'Inspect bin/H&E overlay and save coordinate and QC review.'
223:         if not review:return False,'Inspect the corresponding reports and save this review.'
224:         if any(stamp(x['path'])!=x for x in review.get('evidence',[])):return False,'Review evidence changed.'
225:         return True,'Review saved.'
226: 
227:     def plan(self,samples=None):
228:         from ..control.manifest import resolve_sample_keys,row_config
229:         d=self.snapshot();project=d['project'];keys=resolve_sample_keys(project,samples);out=[]
230:         for key in keys:
231:             row=self.row(key,project);steps=route(row,d['endpoints'][key]);start=d['resume'].get(key,{}).get('action')
232:             blocked=False
233:             for i,action in enumerate(steps):
234:                 if start and i<steps.index(start):status='resume_skipped_not_certified';reason='Before explicitly selected resume point.'
235:                 elif action in REVIEW_STAGES:
236:                     ready,reason=self._review_ready(d,row,action);status='review_saved' if ready else 'needs_review'
237:                     if not ready:blocked=True
238:                 elif self._done(d,row,action):status='complete';reason='Center contract and output stamps unchanged.'
239:                 else:
240:                     status='waiting' if blocked else 'ready';reason='Scientific engine rechecks reuse/input signatures on execution.'
241:                     if action=='bin_qc':
242:                         q=row_config(project,row)[0]['bin_qc']
243:                         if q.get('tissue_score_threshold') is None or q.get('transcript_threshold') is None:
244:                             status='needs_settings';reason='Select tissue-score and transcript cutoffs in the Bin QC panel.'
245:                     # Only the first unresolved computational step can run next.
246:                     blocked=True
247:                 out.append({'sample':key,'action':action,'label':LABELS[action],'status':status,'reason':reason})
```

### `vhd/center/controller.py` — lines 413–474

SHA256: `51df8184fd9e34674e087b77ad39928157a0ab680e7ea1968fad9db1427296a8`

```python
413:     def run_until_review(self,samples=None,*,confirmed=False,max_actions=30):
414:         """Blocking notebook operation; releases resources at review barriers.
415: 
416:         Can be interrupted through Jupyter. No background service is installed. A
417:         stopped kernel leaves running state for explicit inspection, not auto-complete.
418:         """
419:         if not confirmed:raise ValueError('Explicit Run confirmation is required.')
420:         from ..control.manifest import resolve_sample_keys,sample_layout,row_config
421:         from ..compute.launch import launch_samples
422:         from .resources import runtime_project
423:         selected=resolve_sample_keys(self.project,samples);self._stop_requested=False;events=[]
424:         if any(job.get('status')=='running' for k in selected for job in self.snapshot()['jobs'].get(k,{}).values()):
425:             raise RuntimeError('A previous controller job is still marked running. Inspect its worker/status before retrying; use the recovery acknowledgement, not deletion.')
426:         # One controller operation at a time. Scientific workers retain their own locks.
427:         with self.store.exclusive():
428:             for _ in range(max_actions):
429:                 if self._stop_requested:break
430:                 d=self.snapshot();project=d['project'];plans=self.plan(selected)
431:                 ready=[p for p in plans if p['status']=='ready']
432:                 if not ready:break
433:                 action=ready[0]['action'];keys=[x['sample'] for x in ready if x['action']==action]
434:                 running,inventory=runtime_project(project,d.get('resource_limits'))
435:                 d['resources']=inventory
436:                 for key in keys:
437:                     row=self.row(key,project)
438:                     d['jobs'].setdefault(key,{})[action]={'status':'running','started_at':now(),'contract':self._contract(d,row,action)}
439:                     # Controller route can request an endpoint beyond legacy row goal, explicitly.
440:                     rr=self.row(key,running)
441:                     if action not in rr['_plan']:rr['_plan'].append(action)
442:                     if d['endpoints'][key]=='bins':rr['goal']='bin_QCed'
443:                 d=self._commit(d,f'Started {action} for '+', '.join(keys))
444:                 try:
445:                     if action=='cluster_individual':
446:                         from .single_sample import launch_individual
447:                         for key in keys:launch_individual(running,key,d['analysis_settings'],execute=True)
448:                     elif action=='publish':
449:                         from ..control.runner import publish_sample
450:                         for key in keys:publish_sample(running,self.row(key,running),execute=True)
451:                     else:launch_samples(running,action,execute=True,sample_keys=keys)
452:                     failed=[]
453:                 except BaseException as exc:
454:                     failed=[type(exc).__name__+': '+str(exc)]
455:                     if isinstance(exc,(KeyboardInterrupt,SystemExit)):
456:                         d=self.snapshot()
457:                         for key in keys:d['jobs'][key][action].update(status='interrupted',error=failed[0],finished_at=now())
458:                         self._commit(d,'Operation interrupted; partial results retained for inspection.')
459:                         raise
460:                 d=self.snapshot()
461:                 for key in keys:
462:                     row=self.row(key,d['project']);obs=observed(d['project'],row,action)
463:                     j=d['jobs'][key][action]
464:                     worker_ok=obs['worker_record'].get('status')=='complete'
465:                     # No certification of a failed new invocation from an old worker status.
466:                     okay=not failed and obs['all_expected_present']
467:                     j.update(status='complete' if okay else 'failed',finished_at=now(),
468:                         output_stamps=[stamp(x) for x in obs['present']],error=failed[0] if failed else ('' if okay else 'Expected output missing after worker returned.'),
469:                         contract=self._contract(d,row,action))
470:                     events.append({'sample':key,'action':action,'status':j['status']})
471:                 self._commit(d,f'Finished {action}; reports refreshed.')
472:                 if failed:break
473:         return events
474: 
```

### `vhd/center/ui.py` — lines 198–213

SHA256: `0c6068d7eb63cc1d5bb7d74bb71531121e39e43c39c29831084fb676c1d742eb`

```python
198:                 box=W.VBox([ga,button('Generate repair review',lambda:center.generate_geometry_review(key,ga.value)),review_path,confirm_geo,remove_lines,
199:                     button('Accept / activate derivative',lambda:center.accept_geometry(key,ga.value,review_path.value,reviewer=reviewer.value,confirm_all=confirm_geo.value,remove_lines=remove_lines.value))])
200:                 acc=W.Accordion(children=[box]);acc.set_title(0,'Optional invalid-geometry review (not required for an accepted derivative)');acc.selected_index=None;children.append(acc)
201:         asset_tab=W.VBox(children)
202:         # Later review reports
203:         later=[]
204:         for stage,gate,desc in [('segmentation','review_prior','I inspected the StarDist prior and its QC support.'),('cells','review_cells','I inspected cell QC / boundaries and accept these cells for further analysis.')]:
205:             check=W.Checkbox(description=desc,indent=False)
206:             later.extend([W.HTML('<h3>'+stage.title()+'</h3>'),open_stage(stage),check,
207:                           button('Save '+stage+' review',lambda g=gate,c=check:center.accept_review(key,g,reviewer=reviewer.value,confirmed=c.value))])
208:         cells_tab=W.VBox(later)
209:         # Analysis: independent default; opt-in group path separate.
210:         an=d['analysis_settings'];aid=W.Text(value=an['analysis_id'],description='Analysis revision',style=style,layout=wide)
211:         nh=W.IntText(value=int(an['n_hvg']),description='HVG count',style=style);np_=W.IntText(value=int(an['n_pcs']),description='PCA components',style=style)
212:         target=W.FloatText(value=float(an['target_sum']),description='Normalize target',style=style)
213:         analysis=[W.HTML('<h3>Independent clustering</h3><p>Endpoint "Independent clustered cells" uses one sample at a time: configured analysis QC → normalize/log1p → PCA → Leiden 0.1–1.0 → one UMAP colored for each resolution. No batch correction; the master counts are untouched. This is separate from scVI integration.</p>'),
```

### `vhd/center/ui.py` — lines 169–178

SHA256: `0c6068d7eb63cc1d5bb7d74bb71531121e39e43c39c29831084fb676c1d742eb`

```python
169:                     ident=aid+'/'+c['item_key']
170:                     use=W.Checkbox(value=as_bool(c['include_in_obs']),description='Save in bin .obs',indent=False)
171:                     qc=W.Dropdown(options=[('Analysis only','none'),('Segmentation inclusion','include'),('Segmentation exclusion','exclude')],value=c['qc_use'] or 'none',layout=W.Layout(width='240px'))
172:                     name=W.Text(value=c['obs_name'],description='Column',layout=W.Layout(width='330px'))
173:                     cov=W.Dropdown(options=coverage_options,value=c['coverage_mode'],layout=W.Layout(width='480px'))
174:                     methods=W.Text(value=c['signal_methods'],description='Bin summaries',placeholder='mean;median;sum;min;max',layout=wide)
175:                     cell=W.Text(value=c['cell_methods'],description='Cell summaries',placeholder='optional: fraction;majority for polygons',layout=wide)
176:                     forms[ident]=(use,qc,name,cov,methods,cell)
177:                     children.append(W.VBox([W.HTML('<b>'+html.escape(c['category'])+'</b>'),W.HBox([use,qc,name]),cov,
178:                                 *( [methods] if a['kind']=='signal' else []),cell],layout=W.Layout(border='1px solid #dce3eb',padding='10px',margin='6px 0')))
```

### `vhd/annotations/workflow.py` — lines 263–357

SHA256: `812926212d88a7c6a08f369faf76eddc293c5ec1b8eb337afdc4f9c3d5901337`

```python
263: def transfer_assets(cfg,spec):
264:     import shapely
265:     from ..he.fixed import sample_field
266:     from ..io import table_metadata
267:     from ..persistence import update_table_metadata
268:     from .discovery import review_prior_settings
269:     from .area_sampling import summarize_footprints
270:     p=sample_paths(cfg,spec);assets,sig,alignments=asset_specification(cfg,spec);receipt=p['report']/'assets_transfer.json';derived=p['work']/'bins_annotated_obs.parquet'
271:     old=json.loads(receipt.read_text()) if receipt.exists() else {}
272:     prior=review_prior_settings(assets,cfg.get('prior_filter',{}));validate_prior_sources(assets,prior)
273:     # A real visual-review approval may precede source storage. Complete/check the
274:     # actual import now; never manufacture 'stored' receipts merely to approve.
275:     from .visual_approval import ensure_transfer_sources
276:     ensure_transfer_sources(cfg,spec,assets,alignments,paths=p)
277:     if old.get('signature')==sig and derived.exists() and old.get('derived_stamp')==file_stamp(derived):return old
278:     geometry=json.loads(p['geometry'].read_text())
279:     out=pd.read_parquet(p['bin_obs']);xy=out[['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy();owned=[]
280:     specification={'categorical':{},'boolean':[],'continuous':{}}
281:     def add(key,values):
282:         if key in owned or key in out:raise ValueError(f'Annotation output collides with another output or source obs column: {key}')
283:         out[key]=values;owned.append(key)
284:     for a in assets:
285:         prefix=a['asset_id']+'__';coverage=None
286:         if a['coverage_path']:coverage=shapely.union_all(transform_polygons(polygons(a,True),a['source_to_fullres']).geometry.to_numpy())
287:         if a['kind']=='polygons':
288:             full=transform_polygons(polygons(a),a['source_to_fullres']);col=a['category_column'] or 'name'
289:             categories=a['categories'] or sorted(full[col].astype(str).unique())
290:             if set(categories)-set(full[col].astype(str)):raise ValueError('Selected category is absent from the source; rerun discovery.')
291:             g=full.loc[full[col].astype(str).isin(categories)].copy()
292:             if coverage is None and a['coverage_mode']=='positive_only':
293:                 # Unselected categories must not silently define assessed negatives.
294:                 coverage=shapely.union_all(g.geometry.to_numpy())
295:             classify_categories=categories
296:             if '_output_column' in a:
297:                 # A discovered name such as 'assessed' must not overwrite an
298:                 # internal coverage field. Source names remain unchanged on disk.
299:                 g=g.copy();g[col]='__selected_category__';classify_categories=['__selected_category__']
300:             frame=classify_polygons(xy,g,category_column=col,categories=classify_categories,
301:                     coverage=coverage,exhaustive=a['coverage_mode']=='exhaustive',mode=a['bin_method'])
302:             for c in frame:
303:                 safe=re.sub('[^A-Za-z0-9_]','_',str(c));key=prefix+safe
304:                 if '_output_column' in a:key=a['_output_column']+('__assessed' if c=='assessed' else '')
305:                 add(key,frame[c].array)
306:                 if c!='assessed' and a['cell_methods']:
307:                     if a['bin_method']=='membership':
308:                         specification['boolean'].append(key);specification.setdefault('boolean_options',{})[key]={'methods':a['cell_methods']}
309:                     else:specification['categorical'][key]={'missing_values':['unassessed','unassigned']}
310:         else:
311:             modes=a.get('_signal_methods') or ([a['bin_method'][5:]] if a['bin_method'].startswith('area_') else [a['bin_method']])
312:             base=a.get('_output_column',a['asset_id'])
313:             new_style='_output_column' in a or a['bin_method'].startswith('area_')
314:             with open_raster(a['path'],a['axes'],a['channel']) as field:
315:                 measured=MeasurementRaster(field,a)
316:                 area_modes=[x for x in modes if x in ('mean','median','sum','min','max')]
317:                 if area_modes:
318:                     if 'grid_index_to_fullres' not in geometry:raise ValueError('Area summaries require validated bin grid geometry; no guessed square footprint.')
319:                     coverage_source=None
320:                     if coverage is not None:
321:                         from shapely.affinity import affine_transform
322:                         m=np.linalg.inv(affine(a['source_to_fullres']));coverage_source=affine_transform(coverage,[m[0,0],m[0,1],m[1,0],m[1,1],m[0,2],m[1,2]])
323:                     from ..projective_grid import is_projective
324:                     options=dict(methods=area_modes,min_valid_fraction=float(a.get('min_valid_fraction') or 0),
325:                         coverage_source=coverage_source,**cfg.get('annotations',{}).get('area_sampling_options',{}))
326:                     if is_projective(geometry):
327:                         from .projective_sampling import summarize_projective_bins
328:                         summary=summarize_projective_bins(measured,out['array_row'].to_numpy(),out['array_col'].to_numpy(),
329:                             grid_index_to_fullres=geometry['grid_index_to_fullres'],
330:                             source_to_fullres=a['source_to_fullres'],**options)
331:                     else:
332:                         summary=summarize_footprints(measured,xy,source_to_fullres=a['source_to_fullres'],
333:                             bin_basis_fullres=affine(geometry['grid_index_to_fullres'])[:2,:2],**options)
334:                     for method in area_modes:
335:                         key=base+'__'+method;add(key,summary[method])
336:                         if a['cell_methods']:specification['continuous'][key]=a['cell_methods']
337:                     for key in ('in_bounds_fraction','valid_fraction','n_valid_pixels','valid'):add(base+'__'+key,summary[key])
338:                 for mode in (x for x in modes if x.startswith('center_')):
339:                     value,inside,valid=sample_field(measured,xy,source_to_fullres=a['source_to_fullres'],interpolation=mode.split('_')[1])
340:                     if coverage is not None:valid &= membership(xy,coverage)
341:                     value[~valid]=np.nan
342:                     key=base+'__'+(mode if new_style else 'value');add(key,value)
343:                     for suffix,v in [('in_bounds',inside),('valid',valid)]:add(key+'__'+suffix if new_style else prefix+suffix,v)
344:                     if a['cell_methods']:specification['continuous'][key]=a['cell_methods']
345:     decisions=segmentation_decisions(out,prior)
346:     for key in decisions:
347:         if key in owned:raise ValueError('Category output collides with a segmentation decision column.')
348:         out[key]=decisions[key];owned.append(key)
349:     live,_=table_metadata(p['store'],'bins_2um');drop=[c for c in old.get('owned_columns',[]) if c not in owned and c in live]
350:     provenance={a['asset_id']:{k:v for k,v in a.items() if k!='reviewed_signature'} for a in assets}
351:     update_table_metadata(p['store'],'bins_2um',obs=out[owned],drop_obs=drop,uns={'vhd_annotation_sources_json':json.dumps(provenance,sort_keys=True)},
352:           policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=cfg['storage'].get('single_writer_ack',False))
353:     out.to_parquet(derived)
354:     record={'signature':sig,'derived_stamp':file_stamp(derived),'owned_columns':owned,'transfer_spec':specification,
355:         'prior_filter':prior,'membership':'bin_centers',
356:         'continuous_measurement':'Per-field source provenance identifies center samples or exact pixel-overlap footprint summaries. Cell summaries aggregate those BIN measurements, not original image pixels.'}
357:     dump_json(record,receipt);return record
```

### `vhd/annotations/raster.py` — lines 48–83

SHA256: `b2dae41da1bc0534e75b0aa2a84b0f51f00c1713b99bf3688497e13c6d914204`

```python
48: 
49: def spatial_image(path,axes,channel,index_to_fullres,channel_name,tile_size=512):
50:     import dask.array as da
51:     from dask import delayed
52:     from spatialdata.models import Image2DModel
53:     from spatialdata.transformations import Identity,Affine,set_transformation
54:     from ..core import affine
55:     with open_raster(path,axes,channel) as image:h,w=image.shape;dtype=image.dtype
56:     rows=[]
57:     for y in range(0,h,tile_size):
58:         chunks=[]
59:         for x in range(0,w,tile_size):
60:             hh,ww=min(h-y,tile_size),min(w-x,tile_size)
61:             chunks.append(da.from_delayed(delayed(_tile)(str(path),axes,channel,y,x,hh,ww),shape=(1,hh,ww),dtype=dtype))
62:         rows.append(da.concatenate(chunks,axis=2))
63:     element=Image2DModel.parse(da.concatenate(rows,axis=1),dims=('c','y','x'),c_coords=[channel_name],transformations={'fullres':Identity()})
64:     # Account explicitly for the parser's center-coordinate convention (e.g. 0 vs 0.5).
65:     first_x=float(element.coords['x'][0]);first_y=float(element.coords['y'][0])
66:     sx=float(element.coords['x'][1]-element.coords['x'][0]) if w>1 else 1.
67:     sy=float(element.coords['y'][1]-element.coords['y'][0]) if h>1 else 1.
68:     coord_to_index=np.array([[1/sx,0,-first_x/sx],[0,1/sy,-first_y/sy],[0,0,1.]])
69:     set_transformation(element,Affine(affine(index_to_fullres)@coord_to_index,input_axes=('x','y'),output_axes=('x','y')),to_coordinate_system='fullres')
70:     return element
71: 
72: 
73: def validate_signal_encoding(asset,tile_size=512):
74:     """Inspect ALL native pixels tile-wise; preserve raw values in stored image."""
75:     from .workflow import signal_values
76:     with open_raster(asset['path'],asset['axes'],asset['channel']) as field:
77:         h,w=field.shape
78:         for y in range(0,h,tile_size):
79:             for x in range(0,w,tile_size):
80:                 block=field[y:y+tile_size,x:x+tile_size]
81:                 if block.ndim!=2:raise ValueError('A scalar signal needs a single explicit channel.')
82:                 signal_values(block,asset)
83:     return {'shape_yx':[h,w],'signal_type':asset.get('signal_type','continuous')}
```

### `vhd/annotations/projective_sampling.py` — lines 10–82

SHA256: `ab0ee543b3e6323290cc6cf88f26f61b769f6464e23dd2e4926ac4ae674b6455`

```python
10: from .area_sampling import METHODS, _read_pairs
11: 
12: 
13: def summarize_projective_bins(field, rows, cols, *, grid_index_to_fullres,
14:         source_to_fullres, methods=('mean',), min_valid_fraction=0., chunk_size=20000,
15:         max_pairs=1000000, max_pixels_per_bin=4096, tile_size=512, coverage_source=None):
16:     import shapely
17:     methods = list(methods)
18:     if not methods or set(methods)-set(METHODS) or len(set(methods)) != len(methods):
19:         raise ValueError('Choose unique mean/median/sum/max/min methods.')
20:     if not np.isfinite(min_valid_fraction) or not 0 <= min_valid_fraction <= 1:
21:         raise ValueError('min_valid_fraction must be in [0,1].')
22:     for v in (chunk_size, max_pairs, max_pixels_per_bin, tile_size):
23:         if not isinstance(v, (int, np.integer)) or isinstance(v, bool) or v < 1:
24:             raise ValueError('Chunk/pixel limits must be positive integers.')
25:     if len(field.shape) != 2:raise ValueError('A single 2D signal channel is required.')
26:     rows, cols = np.asarray(rows), np.asarray(cols)
27:     if rows.ndim != 1 or rows.shape != cols.shape:raise ValueError('Paired grid indices required.')
28:     inv = np.linalg.inv(affine(source_to_fullres)); n = len(rows)
29:     result = {m:np.full(n, np.nan, float) for m in methods}
30:     result.update(in_bounds_fraction=np.zeros(n), valid_fraction=np.zeros(n),
31:                   n_valid_pixels=np.zeros(n,np.int32),valid=np.zeros(n,bool))
32:     height,width = field.shape
33:     for start in range(0,n,chunk_size):
34:         end=min(n,start+chunk_size)
35:         vertices=grid_corners(rows[start:end],cols[start:end],grid_index_to_fullres)
36:         uv=vertices@inv[:2,:2].T+inv[:2,2]
37:         if np.max(np.abs(uv),initial=0)>2**50:raise ValueError('Signal coordinates exceed safe pixel-index range; review registration.')
38:         footprints=shapely.polygons(uv);areas=shapely.area(footprints)
39:         if not shapely.is_valid(footprints).all() or np.any(areas<=1e-15):raise ValueError('Degenerate signal-space bin footprint.')
40:         lo=uv.min(axis=1);hi=uv.max(axis=1)
41:         nx=int(np.ceil((hi[:,0]-lo[:,0]).max()))+2
42:         ny=int(np.ceil((hi[:,1]-lo[:,1]).max()))+2;k=nx*ny
43:         if k>max_pixels_per_bin or k>max_pairs:
44:             raise ValueError(f'{k} candidate pixels/bin exceeds max_pixels_per_bin or max_pairs; inspect registration before increasing limits.')
45:         dy,dx=np.mgrid[:ny,:nx];dx=dx.ravel();dy=dy.ravel()
46:         batch=max(1,max_pairs//k)
47:         for l in range(0,end-start,batch):
48:             u=min(end-start,l+batch);area=areas[l:u]
49:             xx=np.floor(lo[l:u,0]+.5).astype(np.int64)[:,None]+dx
50:             yy=np.floor(lo[l:u,1]+.5).astype(np.int64)[:,None]+dy
51:             bounds=(xx>=0)&(xx<width)&(yy>=0)&(yy<height)
52:             intersections=shapely.intersection(footprints[l:u,None],shapely.box(xx-.5,yy-.5,xx+.5,yy+.5))
53:             weights=shapely.area(intersections)
54:             inbounds=np.where(bounds & (weights>area[:,None]*1e-12),weights,0.)
55:             if coverage_source is not None:
56:                 weights=shapely.area(shapely.intersection(intersections,coverage_source))
57:             weights=np.where(bounds & (weights>area[:,None]*1e-12),weights,0.)
58:             active=weights>0;values=np.full(weights.shape,np.nan)
59:             if active.any():values[active]=_read_pairs(field,yy[active],xx[active],tile_size)
60:             if np.isinf(values).any():raise ValueError('Infinite measured signal values are not valid.')
61:             vw=np.where(np.isfinite(values),weights,0.);den=vw.sum(axis=1)
62:             ids=slice(start+l,start+u)
63:             result['in_bounds_fraction'][ids]=np.clip(inbounds.sum(axis=1)/area,0,1)
64:             result['valid_fraction'][ids]=np.clip(den/area,0,1)
65:             result['n_valid_pixels'][ids]=(vw>0).sum(axis=1)
66:             keep=(den>area*1e-12)&(den/area+1e-12>=min_valid_fraction);result['valid'][ids]=keep
67:             totals=(np.where(vw>0,values,0)*vw).sum(axis=1)
68:             for method in methods:
69:                 if method=='sum':v=totals
70:                 elif method=='mean':v=np.divide(totals,den,out=np.full(len(den),np.nan),where=den>0)
71:                 elif method=='max':v=np.where(vw>0,values,-np.inf).max(axis=1)
72:                 elif method=='min':v=np.where(vw>0,values,np.inf).min(axis=1)
73:                 else:
74:                     order=np.argsort(np.where(vw>0,values,np.inf),axis=1,kind='stable')
75:                     val=np.take_along_axis(values,order,axis=1);ww=np.take_along_axis(vw,order,axis=1);cum=np.cumsum(ww,axis=1)
76:                     mid=den/2;index=(cum>=mid[:,None]).argmax(axis=1);rr=np.arange(len(den));v=val[rr,index]
77:                     tied=(den>0)&np.isclose(cum[rr,index],mid,atol=area*1e-12,rtol=1e-10)
78:                     nxt=np.minimum(index+1,val.shape[1]-1);tied&=(nxt>index)&(ww[rr,nxt]>0)
79:                     v=np.where(tied,(v+val[rr,nxt])/2,v)
80:                 result[method][ids]=np.where(keep,v,np.nan)
81:     result['in_bounds']=result['in_bounds_fraction']>0
82:     return result
```

### `vhd/annotations/area_sampling.py` — lines 16–29

SHA256: `b12a64a296da9b2c701d50bee40592dea2839f048b4178b672b6055cfc4764d6`

```python
16:     """Read pairs through the slice-only Raster interface, not a full image."""
17:     out=np.empty(len(xs),float)
18:     width=field.shape[1];keys=(ys//tile_size)*((width+tile_size-1)//tile_size)+xs//tile_size
19:     order=np.argsort(keys,kind='stable');edges=np.r_[0,np.flatnonzero(np.diff(keys[order]))+1,len(order)]
20:     for l,r in zip(edges[:-1],edges[1:]):
21:         i=order[l:r];x0=int(xs[i[0]]//tile_size)*tile_size;y0=int(ys[i[0]]//tile_size)*tile_size
22:         patch=np.asarray(field[y0:min(y0+tile_size,field.shape[0]),x0:min(x0+tile_size,width)],float)
23:         if patch.ndim!=2:raise ValueError('A single signal channel must be selected.')
24:         out[i]=patch[ys[i]-y0,xs[i]-x0]
25:     return out
26: 
27: 
28: def summarize_footprints(field, xy_fullres, *, source_to_fullres, bin_basis_fullres,
29:                          methods=('mean',), min_valid_fraction=0., chunk_size=20000,
```

### `vhd/annotations/geometry.py` — lines 67–92

SHA256: `b8f95d5b795f0eafe3892413854f9f5819b0b919df3deeaa1d72755130fdd298`

```python
67:         part[valid]=shapely.intersects_xy(polygon,uv[valid,0],uv[valid,1]);out[start:start+len(part)]=part
68:     return out
69: 
70: 
71: def classify_polygons(xy,g,*,category_column='name',categories=None,coverage=None,exhaustive=False,mode='membership'):
72:     """Always return fresh values. Positive-only coverage leaves outside unknown.
73: 
74:     Independent membership flags allow Tissue AND Necrosis. Categorical overlap
75:     between distinct labels is mixed, not dependent on polygon input ordering.
76:     Boundary points are included; fractions elsewhere are bin-center fractions.
77:     """
78:     xy=np.asarray(xy,float);names=g[category_column].astype(str)
79:     cats=list(categories) if categories is not None else sorted(names.unique())
80:     if len(cats)!=len(set(cats)) or set(names)-set(cats):raise ValueError('Duplicate or undeclared annotation categories.')
81:     hit=np.column_stack([membership(xy,shapely.union_all(g.geometry[names==c].to_numpy())) for c in cats]) if cats else np.zeros((len(xy),0),bool)
82:     assessed=(np.isfinite(xy).all(axis=1) if exhaustive else hit.any(axis=1)) if coverage is None else membership(xy,coverage)
83:     assessed &= np.isfinite(xy).all(axis=1);result=pd.DataFrame({'assessed':assessed})
84:     if mode=='membership':
85:         for i,c in enumerate(cats):
86:             values=pd.array(hit[:,i],dtype='boolean');values[~assessed]=pd.NA;result[c]=values
87:     elif mode=='categorical':
88:         values=np.full(len(xy),'unassigned',object);values[~assessed]='unassessed'
89:         for i,c in enumerate(cats):values[assessed&hit[:,i]]=c
90:         values[assessed&(hit.sum(axis=1)>1)]='mixed';result['class']=pd.Categorical(values)
91:     else:raise ValueError('mode must be membership or categorical.')
92:     return result
```

### `vhd/annotations/visual_approval.py` — lines 493–506

SHA256: `0b9cd4f50a70ff06b7032a6eeefa16ecfbdc8f55b6b7137039fcc581e485857c`

```python
493:         needs_import.append(sid)
494:     if needs_import:
495:         # Check selected signal encodings before expensive master access, not after it.
496:         for a in assets:
497:             if a['kind'] == 'signal':validate_signal_encoding(a)
498:         # Original import includes all configured enabled sources. Prevalidate any
499:         # other non-reference signals too, so an unselected mismatch cannot hide.
500:         sources = read_assets(spec['_row'].get('assets_manifest'), spec['dataset_id'], spec['sample_id'])
501:         selected_ids = set(grouped)
502:         for a in sources:
503:             if a['kind'] == 'signal' and a['asset_id'] not in selected_ids and a['role'] != 'reference_only':
504:                 validate_signal_encoding(a)
505:         print('Visual-First approval verified. Importing/reusing actual spatial sources before bin transfer:', needs_import, flush=True)
506:         import_assets(cfg, spec)
```
