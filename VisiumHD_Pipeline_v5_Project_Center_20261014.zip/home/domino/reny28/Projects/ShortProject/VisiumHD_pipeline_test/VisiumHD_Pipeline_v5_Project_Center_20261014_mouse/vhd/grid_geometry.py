"""Checked affine raster geometry; authoritative per-bin coordinates are never changed.

The rounding branch is allowed only when EVERY source coordinate is exactly an
integer and an affine witness fits EVERY rounding interval +/- 0.5 pixel on EACH
axis. This is consistency with nearest-pixel rounding, not proof of its source.
Fractional coordinates never receive an automatic relaxed tolerance. A projective
fit is diagnostic only in this low-level checker. The projective_grid module
validates it separately for polygon geometry; it is never an Affine transform.
"""
from __future__ import annotations

import math
import numpy as np

GRID_FIT_PATCH = 'projective-grid-polygons-20261001-v2'
_POLICIES = {'strict', 'verified_integer'}
_EPS = 1e-7  # numerical feasibility allowance in full-resolution pixels


class GridGeometryError(ValueError):
    """A failed grid check with a JSON-serializable diagnostic report."""
    def __init__(self, message, report):
        super().__init__(message)
        self.report = report


def _inputs(rows, cols, fullres_xy, tolerance_px, chunk_size):
    r, c = np.asarray(rows), np.asarray(cols)
    raw = np.asarray(fullres_xy)
    if r.ndim != 1 or c.ndim != 1 or raw.shape != (len(r), 2) or len(c) != len(r):
        raise ValueError('Grid rows/cols must be length N and fullres_xy must be N by 2.')
    if len(r) < 3:
        raise ValueError('Need at least three non-collinear bin centers.')
    if not math.isfinite(float(tolerance_px)) or tolerance_px < 0:
        raise ValueError('grid_max_residual_px must be finite and nonnegative.')
    if isinstance(chunk_size, bool) or not isinstance(chunk_size, (int, np.integer)) or chunk_size < 1:
        raise ValueError('chunk_size must be a positive integer.')
    xy = np.asarray(raw, dtype=np.float64)
    for a in (r, c):
        if not np.issubdtype(a.dtype, np.number) or not np.isfinite(a).all():
            raise ValueError('Grid indices must be finite numeric values.')
        if np.any(a < 0) or not np.equal(a, np.rint(a)).all():
            raise ValueError('Grid indices must be nonnegative integers.')
    if not np.isfinite(xy).all():
        raise ValueError('Full-resolution coordinates contain NaN or infinity.')
    # Float64 exact-integer limit. Normal Visium indices/coordinates are much smaller.
    if np.max(np.abs(xy)) >= 2**52 or max(float(r.max()), float(c.max())) >= 2**52:
        raise ValueError('Coordinates/grid indices exceed safe float64 fitting range.')
    return r, c, xy, str(raw.dtype)


def _design(rows, cols, indices, center, scale):
    return np.column_stack(((cols[indices]-center[0])/scale[0],
                            (rows[indices]-center[1])/scale[1],
                            np.ones(len(cols[indices]))))


def _matrix(coef, center, scale):
    a = np.eye(3)
    a[:2, :2] = (coef[:2] / scale[:, None]).T
    a[:2, 2] = coef[2] - a[:2, :2] @ center
    if not np.isfinite(a).all() or abs(np.linalg.det(a[:2, :2])) < 1e-12:
        raise ValueError('Fitted grid transform is singular or non-finite.')
    return a


def _metrics(rows, cols, xy, a, chunk_size):
    max_norm = 0.; sums = 0.; axismax = np.zeros(2)
    worst = 0; noninteger = np.zeros(2, dtype=np.int64)
    for start in range(0, len(rows), chunk_size):
        end = min(start + chunk_size, len(rows))
        points = xy[start:end]
        pred = (np.column_stack([cols[start:end], rows[start:end]]) @ a[:2, :2].T
                + a[:2, 2])
        delta = pred - points
        errors = np.linalg.norm(delta, axis=1)
        k = int(np.argmax(errors))
        if float(errors[k]) >= max_norm:
            max_norm = float(errors[k]); worst = start + k
        sums += float(np.sum(errors**2, dtype=np.float64))
        axismax = np.maximum(axismax, np.max(np.abs(delta), axis=0))
        noninteger += np.sum(points != np.rint(points), axis=0)
    pitch = np.linalg.norm(a[:2, :2], axis=0)
    # Use smallest singular value: conservative for rotations and sheared grids.
    least_scale = float(np.linalg.svd(a[:2, :2], compute_uv=False)[-1])
    return {
        'max_residual_px': max_norm,
        'rms_residual_px': math.sqrt(sums / len(rows)),
        'max_abs_axis_residual_px': axismax.tolist(),
        'noninteger_coordinate_count_xy': noninteger.tolist(),
        'all_source_coordinates_integer': bool(np.all(noninteger == 0)),
        'validated_n_bins': int(len(rows)),
        'grid_pitch_px_column_row': pitch.tolist(),
        'smallest_grid_singular_value_px': least_scale,
        'conservative_max_residual_in_bins': max_norm / least_scale,
        'worst_bin': {'position_in_input': worst, 'array_row': int(rows[worst]),
                      'array_col': int(cols[worst]), 'source_fullres_xy': xy[worst].tolist()},
    }


def _axis_witness(rows, cols, xy, axis, initial, center, scale, chunk_size, seed):
    """Small cutting-plane LP; every proposed witness is checked over ALL bins.

    Fit only a small deterministic set, add worst constraints from every scan
    chunk, and stop if no fully verified witness is found. No use of sampled
    residuals as evidence for unsampled bins.
    """
    from scipy.optimize import linprog
    n = len(rows)
    take = np.random.default_rng(seed).choice(n, min(4096, n), replace=False)
    take = np.unique(np.r_[take, 0, n - 1])
    delta = np.zeros(3)
    for iteration in range(8):
        d = _design(rows, cols, take, center, scale)
        residual = d @ initial - xy[take, axis]
        # min t such that abs(residual + design @ delta) <= t
        lhs = np.vstack([np.column_stack([d, -np.ones(len(take))]),
                         np.column_stack([-d, -np.ones(len(take))])])
        rhs = np.r_[-residual, residual]
        sol = linprog([0., 0., 0., 1.], A_ub=lhs, b_ub=rhs,
                      bounds=[(None, None)]*3 + [(0., None)], method='highs',
                      options={'time_limit': 20., 'primal_feasibility_tolerance': 1e-9,
                               'dual_feasibility_tolerance': 1e-9})
        if not sol.success:
            return None, {'status': 'solver_failed', 'message': str(sol.message), 'iterations': iteration+1}
        if float(sol.x[3]) > .5 + _EPS:
            return None, {'status': 'rounding_intervals_inconsistent',
                          'minimax_lower_bound_px': float(sol.x[3]), 'iterations': iteration+1}
        delta = sol.x[:3]
        candidate = initial + delta
        maximum = 0.; additions = []
        for start in range(0, n, chunk_size):
            end = min(start + chunk_size, n)
            d = _design(rows, cols, slice(start, end), center, scale)
            err = np.abs(d @ candidate - xy[start:end, axis])
            maximum = max(maximum, float(err.max()))
            bad = np.flatnonzero(err > .5 + _EPS)
            if len(bad):
                limit = min(32, len(bad))
                use = bad[np.argpartition(err[bad], -limit)[-limit:]]
                additions.extend((use + start).tolist())
        if maximum <= .5 + _EPS:
            return candidate, {'status': 'verified_all_bins', 'iterations': iteration+1,
                               'max_abs_residual_px': maximum, 'n_constraints': int(len(take))}
        take = np.unique(np.r_[take, additions])
    return None, {'status': 'no_verified_witness_within_iteration_budget',
                  'iterations': 8, 'max_abs_residual_px': maximum}


def _projective_diagnostic(rows, cols, xy, selected, center, scale, chunk_size):
    """Report a candidate projective fit; NEVER authorize it as raster geometry."""
    d = _design(rows, cols, selected, center, scale)
    target = xy[selected]
    mid = np.mean(target, axis=0)
    span = np.max(np.abs(target-mid), axis=0)
    if np.any(span <= 0):
        return {'status': 'unavailable', 'reason': 'degenerate target span'}
    t = (target-mid) / span
    design = np.zeros((2*len(d), 8)); rhs = t.reshape(-1)
    design[0::2, :3] = d; design[1::2, 3:6] = d
    design[0::2, 6:] = -t[:, [0]] * d[:, :2]
    design[1::2, 6:] = -t[:, [1]] * d[:, :2]
    coeff, _, rank, _ = np.linalg.lstsq(design, rhs, rcond=None)
    if rank < 8:
        return {'status': 'unavailable', 'reason': 'rank_deficient'}
    h = np.r_[coeff, 1.].reshape(3, 3)
    tx = np.array([[1/scale[0], 0, -center[0]/scale[0]],
                   [0, 1/scale[1], -center[1]/scale[1]], [0, 0, 1.]])
    ty = np.array([[span[0], 0, mid[0]], [0, span[1], mid[1]], [0, 0, 1.]])
    h = ty @ h @ tx
    if abs(h[2, 2]) > 1e-12:
        h /= h[2, 2]
    maxerr = 0.; sumsq = 0.; dmin = float('inf'); dmax = -float('inf')
    for start in range(0, len(rows), chunk_size):
        end = min(start + chunk_size, len(rows))
        grid = np.column_stack([cols[start:end], rows[start:end]])
        denom = grid @ h[2, :2] + h[2, 2]
        dmin = min(dmin, float(denom.min())); dmax = max(dmax, float(denom.max()))
        if np.any(np.abs(denom) < 1e-8):
            return {'status': 'unavailable', 'reason': 'near_singular_denominator'}
        pred = (grid @ h[:2, :2].T + h[:2, 2]) / denom[:, None]
        err = np.linalg.norm(pred-xy[start:end], axis=1)
        maxerr = max(maxerr, float(err.max())); sumsq += float(np.sum(err**2))
    if dmin <= 0 <= dmax:
        return {'status': 'unavailable', 'reason': 'denominator_changes_sign'}
    return {'status': 'diagnostic_only_not_applied', 'matrix': h.tolist(),
            'max_residual_px': maxerr, 'rms_residual_px': math.sqrt(sumsq/len(rows)),
            'validated_n_bins': int(len(rows)),
            'interpretation': 'A smaller residual suggests projective geometry may fit better; it does not prove origin or H&E registration.'}


def fit_grid_affine_checked(rows, cols, fullres_xy, tolerance_px=.1, seed=42,
                            *, rounding_policy='verified_integer', chunk_size=250_000,
                            diagnose_projective=True):
    """Return affine plus audit, or fail with GridGeometryError.report.

    tolerance_px remains the strict Euclidean tolerance. verified_integer adds a
    *separate* rounding-interval check; no fractional or warped grid is accepted
    solely because its max Euclidean residual is less than one pixel.
    """
    if rounding_policy not in _POLICIES:
        raise ValueError(f'grid_rounding_policy must be one of {sorted(_POLICIES)}.')
    rows, cols, xy, dtype = _inputs(rows, cols, fullres_xy, tolerance_px, chunk_size)
    center = np.array([(float(cols.max())+float(cols.min()))/2,
                       (float(rows.max())+float(rows.min()))/2])
    scale = np.array([(float(cols.max())-float(cols.min()))/2,
                      (float(rows.max())-float(rows.min()))/2])
    if np.any(scale <= 0):
        raise ValueError('Grid positions are collinear; cannot fit an affine.')
    selected = np.random.default_rng(seed).choice(len(rows), min(100_000, len(rows)), replace=False)
    design = _design(rows, cols, selected, center, scale)
    coef, _, rank, _ = np.linalg.lstsq(design, xy[selected], rcond=None)
    if rank < 3:
        raise ValueError('Grid positions are collinear; cannot fit an affine.')
    a = _matrix(coef, center, scale)
    initial = _metrics(rows, cols, xy, a, chunk_size)
    report = dict(initial, implementation=GRID_FIT_PATCH, rounding_policy=rounding_policy,
                  strict_tolerance_px=float(tolerance_px), source_xy_dtype=dtype,
                  original_coordinates_preserved=True, numerical_feasibility_epsilon_px=_EPS,
                  fit_n_bins=int(len(selected)), seed=int(seed),
                  initial_least_squares=dict(initial),
                  raster_geometry='single_affine_approximation',
                  image_registration_verified=False)
    if initial['max_residual_px'] <= tolerance_px:
        report.update(status='passed', acceptance='strict_affine')
        return a, report
    reason = 'Strict affine tolerance exceeded.'
    if rounding_policy == 'verified_integer' and initial['all_source_coordinates_integer']:
        solved = []
        for axis in range(2):
            if initial['max_abs_axis_residual_px'][axis] <= .5 + _EPS:
                solved.append({'status': 'initial_fit_verified_all_bins'})
                continue
            candidate, status = _axis_witness(rows, cols, xy, axis, coef[:, axis],
                                             center, scale, chunk_size, seed + axis)
            solved.append(status)
            if candidate is None:
                break
            coef[:, axis] = candidate
        report['rounding_witness_axes'] = solved
        if len(solved) == 2 and all(x['status'] in {'initial_fit_verified_all_bins', 'verified_all_bins'} for x in solved):
            witness = _matrix(coef, center, scale)
            verified = _metrics(rows, cols, xy, witness, chunk_size)
            if max(verified['max_abs_axis_residual_px']) <= .5 + _EPS:
                report.update(verified)
                report.update(status='passed', acceptance='verified_integer_pixel_rounding',
                              rounding_interval_halfwidth_px=.5,
                              interpretation='Every source coordinate is integer-valued and an affine fits every +/-0.5-pixel interval. Consistent with nearest-pixel rounding; not proof of the original registration algorithm.',
                              footprint_note='Bin raster/footprint basis is a modeled affine approximation; source centers remain unchanged. Do not interpret fitted subpixel positions as measured precision.')
                return witness, report
        reason = 'No affine witness verified for every integer-pixel rounding interval.'
    elif not initial['all_source_coordinates_integer']:
        reason = 'Fractional source coordinates: automatic integer-pixel rounding allowance is inapplicable.'
    report.update(status='blocked', acceptance='none', reason=reason)
    if diagnose_projective:
        report['projective_diagnostic'] = _projective_diagnostic(rows, cols, xy, selected, center, scale, chunk_size)
    raise GridGeometryError(
        f"Grid is not sufficiently affine: maximum residual {initial['max_residual_px']:.6g} px "
        f"> {tolerance_px}. {reason} Original coordinates were not changed. "
        "Inspect grid_coordinate_diagnostic.json; do not globally raise the tolerance or snap centers. "
        "A projective/non-affine grid requires a separately validated geometry representation.", report)
