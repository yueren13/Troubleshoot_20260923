"""Discover source categories first; select and approve individual outputs afterward.

Configuration edits are explicit parent-process actions, with backups. Workers
never concurrently edit a shared category-choice CSV.
"""
from __future__ import annotations
import copy,csv,json,re,shutil,uuid
from pathlib import Path
import numpy as np
import pandas as pd
import shapely
from ..core import digest,dump_json
from ..control.manifest import as_bool,sample_layout,row_config,check_policy
from .alignment import resolve_alignment

CHOICE_COLUMNS=['sample_key','asset_id','item_key','category','include_in_obs','qc_use',
    'obs_name','signal_methods','cell_methods','coverage_mode','same_extent_confirmed',
    'source_signature','reviewed_signature','notes']


def read_choices(path):
    path=Path(path)
    if not path.exists():return []
    with path.open(newline='',encoding='utf-8-sig') as f:
        r=csv.DictReader(f)
        if r.fieldnames!=CHOICE_COLUMNS:raise ValueError(f'{path}: use the generated asset_choices.csv unchanged headers.')
        rows=list(r)
    for row in rows:
        if None in row or any(v is None for v in row.values()):raise ValueError('Malformed choice CSV; quote commas in text.')
    keys=[(r['sample_key'],r['asset_id'],r['item_key']) for r in rows]
    if len(set(keys))!=len(keys):raise ValueError('Duplicate asset-choice identity.')
    return rows


def atomic_choices(path,rows):
    """Replace only this small, explicit config file; retain prior version."""
    path=Path(path)
    if path.is_symlink():raise ValueError('Refuse symlinked review file.')
    if not path.parent.is_dir():raise FileNotFoundError(path.parent)
    text=json.dumps(rows,sort_keys=True)
    if path.exists() and json.dumps(read_choices(path),sort_keys=True)==text:return None
    backup=None
    if path.exists():
        backup=path.with_name(path.name+'.before_review_'+uuid.uuid4().hex[:8]+'.txt');shutil.copy2(path,backup)
    temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    with temp.open('x',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=CHOICE_COLUMNS);w.writeheader();w.writerows(rows)
    temp.replace(path)
    return str(backup) if backup else None


def selected_choices(asset):
    if asset.get('role')!='discover':return []
    sample=asset['dataset_id']+'__'+asset['sample_id']
    return [r for r in read_choices(asset['review_table']) if r['sample_key']==sample and r['asset_id']==asset['asset_id']]


def has_active_choices(asset):
    return any(as_bool(r['include_in_obs']) or r['qc_use'] not in ('','none') or bool(r['cell_methods']) for r in selected_choices(asset))


def source_geometry(project,row):
    paths=sample_layout(project,row)
    for name in ('geometry.json','cell_geometry.json'):
        p=paths['work']/name
        if p.is_file():
            data=json.loads(p.read_text());return data['geometry'] if name.startswith('cell') else data
    cfg,spec=row_config(project,row)
    if not spec.get('image'):raise ValueError('Supply a named H&E reference or first prepare geometry before asset discovery.')
    from ..images import image_info
    return {'image':image_info(spec['image'],spec.get('image_mpp_override')),'tenx_to_image':spec['tenx_to_image_affine']}


def choice_key(category):
    return digest({'category':str(category)})[:12]


def output_name(asset_id,category):
    stem=re.sub('[^A-Za-z0-9_]','_',str(category)).strip('_')[:48] or 'unnamed'
    return asset_id+'__'+stem+'_'+choice_key(category)[:8]


def discover_one(asset,geometry,sample_key):
    from .workflow import polygons,alignment_signature
    from .raster import open_raster
    resolved=resolve_alignment(asset,geometry);signature=alignment_signature(resolved,geometry)
    inventory=[]
    if asset['kind']=='polygons':
        g=polygons(asset);column=asset['category_column'] or 'name'
        if column not in g:raise ValueError(f'Category column {column!r} not found. Available: {list(g.columns)}')
        names=g[column].astype(str)
        for category in sorted(names.unique()):
            sub=g.loc[names==category]
            inventory.append({'category':category,'n_source_features':len(sub),'area_union_native_units2':float(shapely.union_all(sub.geometry).area),
                'bounds_native':list(map(float,sub.total_bounds)),
                'annotation_ids':';'.join(sub['annotation_id'].astype(str)) if 'annotation_id' in sub else ''})
    else:
        with open_raster(asset['path'],asset['axes'],asset['channel']) as field:
            h,w=field.shape;patch=field[0:min(64,h),0:min(64,w)]
            if patch.ndim!=2:raise ValueError('This release requires one selected 2D channel; declare axes/channel for multichannel input.')
            vals=np.unique(patch[np.isfinite(patch)])
            inventory=[{'category':'__signal__','shape_yx':[h,w],'dtype':str(field.dtype),
                        'sampled_values':vals[:16].tolist(),'sampled_values_not_full_validation':True}]
    choices=[]
    for item in inventory:
        category=item['category']
        choices.append(dict(zip(CHOICE_COLUMNS,[sample_key,asset['asset_id'],choice_key(category),category,
            'false','none',asset['asset_id'] if asset['kind']=='signal' else output_name(asset['asset_id'],category),
            'mean' if asset['kind']=='signal' else '', '',asset['coverage_mode'],'false',signature,'',''])))
    report={'sample_key':sample_key,'asset_id':asset['asset_id'],'path':asset['path'],'kind':asset['kind'],
        'alignment':resolved.get('_alignment',{}),'source_to_fullres':resolved['source_to_fullres'],
        'source_signature':signature,'inventory':inventory,'choices_file':asset.get('review_table','')}
    return choices,report


def merge_choices(existing,discovered,scopes):
    """Keep choices, never approvals, across changed source signatures.

    Removed categories in rediscovered sources are removed from the active table;
    the previous CSV backup preserves the audit. Unvisited samples are untouched.
    """
    previous={(r['sample_key'],r['asset_id'],r['item_key']):r for r in existing};out=[]
    for new in discovered:
        key=(new['sample_key'],new['asset_id'],new['item_key']);old=previous.get(key)
        if old:
            for col in ('include_in_obs','qc_use','obs_name','signal_methods','cell_methods','coverage_mode','same_extent_confirmed','notes'):new[col]=old[col]
            if old['source_signature']==new['source_signature']:new['reviewed_signature']=old['reviewed_signature']
            else:new['same_extent_confirmed']='false';new['reviewed_signature']=''
        out.append(new)
    out.extend(r for r in existing if (r['sample_key'],r['asset_id']) not in scopes)
    return sorted(out,key=lambda r:(r['sample_key'],r['asset_id'],r['category']))


def discover_assets(project,sample_keys=None,execute=False):
    from .workflow import read_assets
    check_policy(project);tables={};reports=[]
    for row in project['rows']:
        if sample_keys is not None and row['sample_key'] not in sample_keys:continue
        sources=read_assets(row.get('assets_manifest'),row['dataset_id'],row['sample_id'])
        if not sources:continue
        geometry=source_geometry(project,row);paths=sample_layout(project,row)
        for asset in sources:
            if asset['role']!='discover':continue
            choices,report=discover_one(asset,geometry,row['sample_key']);reports.append(report)
            path=Path(asset['review_table'])
            if path.parent!=Path(asset['_manifest_path']).parent:raise ValueError('Keep the generated review_table beside its source asset CSV.')
            slot=tables.setdefault(path,{'rows':[],'scopes':set()});slot['rows']+=choices;slot['scopes'].add((row['sample_key'],asset['asset_id']))
            if execute:
                paths['report'].mkdir(parents=True,exist_ok=True)
                dump_json(report,paths['report']/f"asset_{asset['asset_id']}_discovery.json")
    frames=[]
    for path,slot in tables.items():
        result=merge_choices(read_choices(path),slot['rows'],slot['scopes']);frames+=result
        if execute:
            backup=atomic_choices(path,result)
            print('Category/signal choices:',path,'| backup:',backup)
        else:print('PREVIEW ONLY. Would create/update choices:',path)
    return pd.DataFrame(frames,columns=CHOICE_COLUMNS),reports


def choice_signature(choice,source_signature):
    return digest({'algorithm':'choice-v4.1','source':source_signature,
        'selection':{k:choice[k] for k in CHOICE_COLUMNS if k not in ('source_signature','reviewed_signature','notes')}})


def expand_choices(asset,geometry,require_approval=True,*,source_signature=None):
    from .workflow import alignment_signature,polygons
    if '_alignment' not in asset:asset=resolve_alignment(asset,geometry)
    signature=source_signature or alignment_signature(asset,geometry);out=[]
    if asset['kind']=='polygons':
        g=polygons(asset);available=set(g[asset['category_column']].astype(str))
    else:available={'__signal__'}
    for choice in selected_choices(asset):
        selected=as_bool(choice['include_in_obs']);qc=choice['qc_use'] or 'none'
        if qc not in ('none','include','exclude'):raise ValueError('qc_use must be none, include or exclude.')
        if not selected:
            if qc!='none' or choice['cell_methods']:raise ValueError('QC/cell transfer requires include_in_obs=true for the selected category.')
            continue
        if choice['category'] not in available or choice['item_key']!=choice_key(choice['category']):raise ValueError('Category changed or unknown; rerun discovery rather than typing an unobserved category.')
        if choice['source_signature']!=signature:raise RuntimeError('Source/registration changed. Rerun discovery and 02A previews before approval.')
        name=choice['obs_name']
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',name):raise ValueError(f"obs_name must be a safe nonempty column identifier: {asset['asset_id']} / {choice['category']} has {name!r} in {asset['review_table']}.")
        if name in ('region','instance_id','qc_keep','qc_class','total_counts'):raise ValueError('Do not overwrite a core QC/linkage column.')
        sig=choice_signature(choice,signature)
        if require_approval and choice['reviewed_signature']!=sig:raise RuntimeError(f"Unapproved choice {asset['asset_id']} / {choice['category']}. Review 02A and run approve_choices.")
        report=asset.get('_alignment',{})
        if report.get('requires_same_extent_confirmation'):
            if not report.get('scale_checks_passed',True):raise ValueError('Scale checks failed: '+'; '.join(report['warnings']))
            if not as_bool(choice['same_extent_confirmed']):raise ValueError('Confirm same field of view/orientation in same_extent_confirmed after inspecting the scale proposal. Crops require landmarks/explicit affine.')
        coverage=choice['coverage_mode']
        if coverage not in ('exhaustive','positive_only','polygon'):raise ValueError('Invalid choice coverage_mode.')
        if coverage=='polygon' and not asset['coverage_path']:raise ValueError('Selected polygon coverage needs coverage_path in the source row.')
        if qc=='exclude' and coverage=='positive_only':raise ValueError('A QC exclusion needs assessed negative coverage. Choose exhaustive after review, or a declared coverage polygon; positive_only marks only positives and cannot establish clean tissue.')
        item=copy.deepcopy(asset);item['_source_asset_id']=asset['asset_id'];item['asset_id']=asset['asset_id']+'_item_'+choice['item_key']
        item['role']='both' if qc!='none' else 'analysis';item['_output_column']=name;item['_qc_use']=qc
        item['reviewed_signature']=signature;item['_choice_signature']=sig;item['coverage_mode']=coverage
        item['cell_methods']=[x.strip() for x in choice['cell_methods'].split(';') if x.strip()]
        if asset['kind']=='polygons':
            if set(item['cell_methods'])-{'fraction','majority'}:raise ValueError('Polygon cell_methods: fraction;majority.')
            item['categories']=[choice['category']];item['bin_method']='membership'
        else:
            if qc!='none':raise ValueError('Signal thresholds do not automatically define QC categories in this release.')
            if coverage=='positive_only':raise ValueError('Signal validity must not be defined by positive intensity.')
            modes=[x.strip() for x in choice['signal_methods'].split(';') if x.strip()]
            if not modes or set(modes)-{'mean','median','sum','min','max','center_nearest','center_linear'} or len(set(modes))!=len(modes):raise ValueError('signal_methods: mean;median;sum;min;max, or center sampling.')
            if item['signal_type']=='binary' and 'center_linear' in modes:raise ValueError('Do not linearly interpolate binary codes.')
            if set(item['cell_methods'])-{'mean','median','sum','min','max'}:raise ValueError('Invalid continuous cell_methods.')
            item['_signal_methods']=modes
        out.append(item)
    names=[a['_output_column'] for a in out]
    if len(names)!=len(set(names)):raise ValueError('Duplicate chosen obs_name values.')
    return out


def review_prior_settings(assets,settings):
    out=copy.deepcopy(settings)
    discovered=[a for a in assets if '_qc_use' in a]
    selected=[a for a in discovered if a['_qc_use']!='none']
    if settings.get('mode')=='from_review':
        include=[a['_output_column'] for a in selected if a['_qc_use']=='include']
        exclude=[a['_output_column'] for a in selected if a['_qc_use']=='exclude']
        out.update(enabled=bool(include or exclude),tissue_column=None,tissue_columns=include,exclude_columns=exclude)
    elif selected:
        raise ValueError('Set prior_filter.mode=from_review to use the discovered QC selections instead of hand-written category overrides.')
    return out


def approve_choices(project,selections,execute=False):
    """Explicit {sample_key:[source_asset_ids]} selection; approve selected rows only.

    Requires matching stored preview receipts produced by 02A. Discovery alone
    never establishes that an overlay has been inspected.
    """
    from .workflow import read_assets,alignment_signature
    changes={};plans=[]
    from ..control.manifest import resolve_sample_keys
    resolved_selections={}
    for alias,ids in selections.items():
        key=resolve_sample_keys(project,[alias])[0]
        if key in resolved_selections:raise ValueError('Same sample was selected twice for approval.')
        resolved_selections[key]=ids
    for key,ids in resolved_selections.items():
        if isinstance(ids,str):raise ValueError('List explicit asset IDs.')
        rows=[r for r in project['rows'] if r['sample_key']==key]
        if len(rows)!=1:raise KeyError(key)
        row=rows[0];geometry=source_geometry(project,row);paths=sample_layout(project,row)
        sources={a['asset_id']:a for a in read_assets(row['assets_manifest'],row['dataset_id'],row['sample_id'])}
        for asset_id in ids:
            a=resolve_alignment(sources[asset_id],geometry)
            if a['role']!='discover':raise ValueError('Use legacy approve_assets for legacy file-level roles.')
            report_path=paths['report']/f'asset_{asset_id}.json'
            if not report_path.is_file():raise RuntimeError(f'Run 02A import/preview before approving choices in the legacy route. Missing original-import receipt: {report_path}. For a completed Visual-First gallery use vhd.annotations.visual_approval.approve_visual_choices; do not create a fake stored receipt.')
            report=json.loads(report_path.read_text());signature=alignment_signature(a,geometry)
            if report.get('status')!='stored' or report.get('alignment_signature')!=signature or report.get('preview_status')!='generated':raise RuntimeError('No current successful stored preview. Reimport/regenerate 02A.')
            compiled=expand_choices(a,geometry,require_approval=False,source_signature=signature)
            selected_ids={x['asset_id'].rsplit('_item_',1)[-1] for x in compiled}
            path=Path(a['review_table']);current=changes.setdefault(path,read_choices(path))
            for choice in current:
                if choice['sample_key']==key and choice['asset_id']==asset_id and choice['item_key'] in selected_ids:
                    choice['reviewed_signature']=choice_signature(choice,signature)
                    plans.append({'sample':key,'asset':asset_id,'category':choice['category'],'obs_name':choice['obs_name'],'qc_use':choice['qc_use']})
    if execute:
        for path,rows in changes.items():print('Approval file:',path,'| backup:',atomic_choices(path,rows))
    return {'execute':execute,'approved_choices':plans}


def preview_selected_plan(project,sample_keys=None,*,require_approval=False):
    """Read-only plan: report pending approvals by default, never approve or import.

    Configuration/geometry checks remain active. Set require_approval=True for an
    explicitly strict approval check; transfer always requires valid approval.
    """
    from .workflow import read_assets,validate_prior_sources
    from ..control.manifest import resolve_sample_keys
    selected_keys=set(resolve_sample_keys(project,sample_keys))
    report=[]
    for row in project['rows']:
        if row['sample_key'] not in selected_keys:continue
        cfg,spec=row_config(project,row);items=[];pending=[]
        sources=read_assets(row.get('assets_manifest'),row['dataset_id'],row['sample_id'])
        geometry=source_geometry(project,row) if any(a['role']!='reference_only' for a in sources) else {}
        for a in sources:
            if a['role']=='reference_only':continue
            a=resolve_alignment(a,geometry)
            if a['role']=='discover':
                from .workflow import alignment_signature
                signature=alignment_signature(a,geometry)
                items+=expand_choices(a,geometry,require_approval=require_approval,source_signature=signature)
                for c in selected_choices(a):
                    if as_bool(c['include_in_obs']) and c['reviewed_signature']!=choice_signature(c,signature):
                        pending.append({'source':a['asset_id'],'category':c['category'],'obs_name':c['obs_name']})
            elif a['role']!='reference_only':items.append(a)
        prior=review_prior_settings(items,cfg.get('prior_filter',{}));validate_prior_sources(items,prior)
        report.append({'sample':row['sample_key'],'active_outputs':len(items),'prior_filter':prior,
          'choice_approvals_complete':not pending,'pending_choices':pending,
          'preview_only':True,'stored_sources_or_execution_validated':False,
          'outputs':[{'source':a.get('_source_asset_id',a['asset_id']),'category':a['categories'],
            'obs_column':a.get('_output_column',a['asset_id']+'__...'),'signal_methods':a.get('_signal_methods',[]),
            'qc_use':a.get('_qc_use','legacy_explicit'),'cell_methods':a['cell_methods']} for a in items]})
    return report
