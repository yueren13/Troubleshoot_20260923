"""Build a synthetic HTML-report demonstration. NOT a biological pipeline validation.
The figures illustrate the report layout; no segmentation or clustering algorithm is run.
Only a new explicitly named output directory is allowed.
"""
from pathlib import Path
import sys,json,argparse
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))


def build_demo(destination):
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from vhd.center import ProjectCenter
    from vhd.control.manifest import sample_layout
    target=Path(destination)
    if target.exists():raise FileExistsError('Choose a new directory; no overwrite: '+str(target))
    target.mkdir(parents=True)
    outputs=target/'synthetic_outputs';outputs.mkdir()
    sheet=target/'synthetic_samples.csv'
    sheet.write_text('sample_id,stage,spaceranger_outs,segmentation_image,species,study\nDemo01,raw,'+str(target/'not_supplied/outs')+','+str(target/'not_supplied/he.svs')+',human,Synthetic layout demonstration\n')
    c=ProjectCenter.from_sheets(sheet,None,outputs,target/'controller',title='SYNTHETIC demonstration | Visium HD Project Center')
    report=sample_layout(c.project,c.row('Demo01'))['report'];report.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(9);n=12000;h=rng.beta(2,3,n);tx=rng.poisson(1+35*h**2);valid=np.ones(n,bool)
    def save(fig,name):
        fig.savefig(report/name,dpi=105,bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5));ax.hist(h,bins=70);ax.set(xlabel='Fixed H&E tissue score',ylabel='Synthetic bins',title='SYNTHETIC • H&E score distribution');save(fig,'he_tissue_score_fixed.png')
    fig,ax=plt.subplots(figsize=(9,5));ax.scatter(h,np.log10(1+tx),s=2,alpha=.25);ax.set(xlabel='Fixed H&E tissue score',ylabel='Counts • log10(1 + count) spacing',title='SYNTHETIC • Bin score versus count');ax.set_yticks(np.log10(np.array([0,1,10,100])+1),['0','1','10','100']);save(fig,'bins_score_vs_counts.png')
    pd.DataFrame({'qc_class':['tissue-high_transcript-high','tissue-high_transcript-low','tissue-low'],
                  'n_synthetic_bins':[int(((h>=.2)&(tx>=3)).sum()),int(((h>=.2)&(tx<3)).sum()),int((h<.2).sum())]}).to_csv(report/'bin_counts_summary.csv',index=False)
    (report/'bin_qc_report.json').write_text(json.dumps({'purpose':'SYNTHETIC layout data — no actual tissue or source images','n_bins':n,'tissue_score_threshold':.2,'transcript_threshold':3,'classification_review':'Not biologically reviewed'},indent=2))
    centers=rng.uniform(0,100,(100,2));fig,ax=plt.subplots(figsize=(8,7))
    for x,y in centers:ax.add_patch(plt.Circle((x,y),rng.uniform(.5,1.5),fill=False))
    ax.set(xlim=(0,100),ylim=(100,0),aspect='equal',title='SYNTHETIC outlines • not StarDist/Proseg output',xlabel='Example image x',ylabel='Example image y');save(fig,'stardist_prior_ROI.png')
    fig,ax=plt.subplots(figsize=(9,5));counts=rng.lognormal(5,1.1,1000);ax.hist(np.log10(1+counts),bins=55);ax.set(xlabel='Counts • log10(1 + count) spacing',ylabel='Synthetic cells',title='SYNTHETIC • Cell count distribution');ax.set_xticks(np.log10(np.array([1,10,100,1000,10000])+1),['1','10','100','1,000','10,000']);save(fig,'cells_total_counts.png')
    pd.DataFrame({'metric':['n_synthetic_cells','n_example_pass','note'],'value':[1000,870,'No biological QC run']}).to_csv(report/'cell_qc_summary.csv',index=False)
    cluster=report/'individual_analysis/demo_layout';cluster.mkdir(parents=True)
    groups=np.repeat(np.arange(4),125);xy=rng.normal(size=(500,2))*.6+np.array([[0,0],[3,1],[0,3],[3,4]])[groups]
    records=[]
    for i in range(1,11):
        fig,ax=plt.subplots(figsize=(8,6));classes=(groups+(np.arange(500)%(1+i//4))*4)
        ax.scatter(xy[:,0],xy[:,1],c=classes,s=6);ax.set(title=f'SYNTHETIC display • resolution {i/10:.1f}\nNot a calculated UMAP or Leiden solution',xlabel='Illustrative coordinate 1',ylabel='Illustrative coordinate 2')
        fig.savefig(cluster/f'UMAP_leiden_{i/10:.1f}.png',dpi=90,bbox_inches='tight');plt.close(fig)
        for cls in np.unique(classes):records.append({'resolution':i/10,'example_label':int(cls),'n_synthetic_points':int((classes==cls).sum())})
    pd.DataFrame(records).to_csv(cluster/'cluster_sizes.csv',index=False)
    (cluster/'summary.json').write_text(json.dumps({'purpose':'Synthetic report layout only; no clustering algorithm executed','resolutions':'0.1 through 1.0','n_synthetic_points':500,'science_validated':False},indent=2))
    c.refresh();return c.workspace/'html/project_review.html'


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
    print(build_demo(args.output))
