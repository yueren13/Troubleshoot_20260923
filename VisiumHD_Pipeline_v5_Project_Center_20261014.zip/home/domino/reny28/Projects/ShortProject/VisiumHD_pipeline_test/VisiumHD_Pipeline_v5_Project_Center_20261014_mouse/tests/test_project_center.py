"""Project Center contracts on real CSV/JSON/XML/TIFF/PNG; no scientific engine stubs counted as biological runs."""
from pathlib import Path
import copy,json,csv,os
import numpy as np
import pytest
from PIL import Image
from vhd.center import ProjectCenter
from vhd.center.state import StateStore,stamp,atomic_write
from vhd.center.resources import parse_gpu_csv,cgroup_limits,runtime_project
from vhd.center.stages import route,observed
from vhd.center.ui import validate_choice_form

@pytest.fixture
def source(tmp_path):
    from test_visual_approval_bridge import setup
    return setup.__wrapped__(tmp_path)

@pytest.fixture
def center(source):
    return ProjectCenter.import_config(source['manifest'],source['settings'],source['root']/'project_center')


def test_migration_preserves_original_inputs_and_unknown_state(source,center):
    assert center.project['settings']['run_id']=='bridge_test'
    assert center.project['rows'][0]['sample_key']=='Project__A'
    assert center.project['rows'][0]['master_store']==source['project']['rows'][0]['master_store']
    assert not (source['paths']['store']).exists()
    assert center.snapshot()['jobs']=={}
    assert Path(center.project['rows'][0]['assets_manifest']).parent==center.workspace/'engine'
    assert (center.workspace/'html/project_review.html').is_file()


def test_reopen_restores_same_choices_and_reviews(center):
    choices=center.choices('A');x=center.snapshot()['revision'];center.frontend_check()
    second=ProjectCenter.open(center.workspace)
    assert second.choices('A')==choices
    assert second.snapshot()['frontend_check']['status']=='python_callback_received'
    assert second.snapshot()['revision']>x


def test_existing_nonempty_workspace_is_not_overwritten(source,center):
    with pytest.raises(FileExistsError):ProjectCenter.import_config(source['manifest'],source['settings'],center.workspace)


def test_managed_drift_stops_without_restoring_or_overwriting(center):
    path=center.workspace/'engine/assets.csv';path.write_text(path.read_text()+'\n')
    with pytest.raises(RuntimeError,match='outside'):center.snapshot()


def test_state_optimistic_revision_and_lock(tmp_path):
    s=StateStore(tmp_path/'state');s.initialize({'project':{},'history':[]})
    before=s.read()
    with s.exclusive():s.save_locked(before,0,'test')
    with s.exclusive():
        with pytest.raises(RuntimeError,match='changed'):s.save_locked(before,0,'stale')
    assert (s.directory/'revisions/state_000000.json').exists()


def test_second_controller_lock_fails_while_first_active(tmp_path):
    one=StateStore(tmp_path/'state');two=StateStore(tmp_path/'state')
    with one.exclusive():
        with pytest.raises(RuntimeError,match='active'):
            with two.exclusive():pass


def test_preview_does_not_make_approvals_or_master(center,source):
    before=(center.workspace/'engine/asset_choices.csv').read_bytes()
    plan=center.plan(['A'])
    assert any(p['action']=='review_assets' and p['status']=='needs_review' for p in plan)
    assert (center.workspace/'engine/asset_choices.csv').read_bytes()==before
    assert not source['paths']['store'].exists()


def choice_edits(center):
    return {c['asset_id']+'/'+c['item_key']:{k:c[k] for k in ('qc_use','obs_name','coverage_mode','signal_methods','cell_methods')}|
            {'include_in_obs':c['include_in_obs'].lower()=='true'} for c in center.choices('A')}


def test_one_save_keeps_selections_reconfirms_extent_and_approves_native(source,center):
    before={p:p.read_bytes() for p in (source['xml'],source['tif'],source['assets'],source['choices'])}
    edits=choice_edits(center)
    result=center.save_asset_review('A',gallery_summary=source['summary'],edits=edits,
        extent_confirmations={'stain':True},signal_interpretations={'stain':'native'},scale_hints={'stain':9},
        reviewer='Synthetic reviewer',confirmed=True)
    assert result['status']=='approved'
    assert all(p.read_bytes()==b for p,b in before.items())
    assert not source['paths']['store'].exists()
    reopened=ProjectCenter.open(center.workspace)
    assert all(c['reviewed_signature'] for c in reopened.choices('A') if c['include_in_obs'].lower()=='true')
    assert all(c['same_extent_confirmed']=='true' for c in reopened.choices('A') if c['asset_id']=='stain')
    assert any(x['action']=='review_assets' and x['status']=='review_saved' for x in reopened.plan(['A']))


def test_blocked_save_restores_config_and_retains_draft(center,source):
    before={p:p.read_bytes() for p in (center.workspace/'engine').glob('*.csv')}
    with pytest.raises(ValueError,match='Confirm same'):
        center.save_asset_review('A',gallery_summary=source['summary'],edits=choice_edits(center),
                extent_confirmations={'stain':False},signal_interpretations={'stain':'native'},reviewer='Tester',confirmed=True)
    assert all(p.read_bytes()==v for p,v in before.items())
    assert center.snapshot()['drafts']['Project__A']['last_error']
    assert not (source['paths']['report']/'asset_stain_visual_approval.json').exists()


def test_string_false_cannot_grant_confirmation(center,source):
    with pytest.raises(TypeError):
        center.save_asset_review('A',gallery_summary=source['summary'],edits={},extent_confirmations={'stain':'false'},reviewer='test',confirmed=True)


def test_stale_form_stops(center,source):
    rev=center.snapshot()['revision'];center.refresh()
    with pytest.raises(RuntimeError,match='Stale'):
        center.save_asset_review('A',gallery_summary=source['summary'],edits={},extent_confirmations={},reviewer='test',confirmed=True,expected_revision=rev)


def test_no_report_no_coordinate_approval(center):
    with pytest.raises(FileNotFoundError):center.accept_review('A','review_bins',reviewer='Tester',confirmed=True)


def test_coordinate_review_saved_without_rewrite(source,center):
    p=source['paths']['report']/'bins_qc_class.png';Image.fromarray(np.zeros((10,10,3),np.uint8)).save(p)
    original=source['manifest'].read_bytes();center.accept_review('A','review_bins',reviewer='Tester',confirmed=True)
    assert center.project['rows'][0]['coordinates_reviewed']=='true'
    assert source['manifest'].read_bytes()==original
    assert not source['paths']['store'].exists()


def test_bin_settings_do_not_touch_source_and_need_no_master(center,source):
    old=source['settings'].read_bytes();center.save_bin_settings('A',tissue_score=.25,transcripts=1)
    from vhd.control.manifest import row_config
    assert row_config(center.project,center.row('A'))[0]['bin_qc']['tissue_score_threshold']==.25
    assert source['settings'].read_bytes()==old


@pytest.mark.parametrize('value',[-1,2,float('nan'),True])
def test_bad_thresholds_rejected(center,value):
    with pytest.raises(ValueError):center.save_bin_settings('A',tissue_score=value,transcripts=1)


def test_no_silent_completed_qc_overwrite(center,source):
    p=source['paths']['work']/'02_qc_complete.json';p.write_text('{}')
    with pytest.raises(RuntimeError,match='completed QC'):center.save_bin_settings('A',tissue_score=.234,transcripts=1)
    assert p.read_text()=='{}'


def test_endpoint_not_integration_and_resume_not_fabricated(center):
    center.set_endpoint('A','clustered')
    assert center.project['rows'][0]['integration_group']==''
    assert 'cluster_individual' in [p['action'] for p in center.plan(['A'])]
    with pytest.raises(FileNotFoundError):center.select_resume('A','review_assets',acknowledge_existing=True)


def test_export_is_portable_html_only(center,tmp_path):
    import zipfile
    path=center.export_report(tmp_path/'report.zip')
    with zipfile.ZipFile(path) as z:
        assert 'project_review.html' in z.namelist()
        assert all(n.endswith('.html') for n in z.namelist())
    with pytest.raises(FileExistsError):center.export_report(path)


def test_gpu_visibility_and_uuid_mapping():
    csv='0, GPU-aa, Device0, 24000, 12000\n1, GPU-bb, Device1, 24000, 16000\n'
    assert [x['uuid'] for x in parse_gpu_csv(csv,'1')]==['GPU-bb']
    assert parse_gpu_csv(csv,'')==[]
    assert parse_gpu_csv(csv,'GPU-aa')[0]['index']==0
    assert parse_gpu_csv(csv,'-1')==[]


def test_cgroup_ancestor_memory_and_cpu_limits(tmp_path):
    root=tmp_path/'cgroup';child=root/'a';child.mkdir(parents=True)
    (tmp_path/'self').write_text('0::/a\n')
    (root/'cpu.max').write_text('200000 100000');(child/'cpu.max').write_text('400000 100000')
    (root/'memory.max').write_text('1000');(root/'memory.current').write_text('800')
    (child/'memory.max').write_text('800');(child/'memory.current').write_text('200')
    r=cgroup_limits(tmp_path/'self',root)
    assert r['cpu_quota_cores']==2 and r['memory_headroom_bytes']==200


def test_runtime_config_is_copy_and_caps_cpu(center):
    p=center.project;old=copy.deepcopy(p)
    inv={'cpu_affinity_threads':96,'eligible_cpu_cores':2,'ram_available_gib':8,'gpus':[]}
    runtime,observed=runtime_project(p,{'threads_per_job':1,'max_workers':8},inv)
    assert p==old
    assert runtime['settings']['execution']['cpu']['workers']<=2
    assert runtime['settings']['execution']['gpu_ids']==[]


def test_route_for_no_asset_sample_and_midway_cells():
    row={'stage':'cell_annotated','goal':'cell_annotated','bin_input':'','assets_manifest':''}
    steps=route(row,'clustered')
    assert steps==['import_cells','assemble','review_cells','cluster_individual','review_clustering']
    with pytest.raises(ValueError):route(row,'bins')


def test_new_two_sheet_metadata_preserves_leading_zero(tmp_path):
    from vhd.center.importers import project_from_sheets
    output=tmp_path/'output';output.mkdir()
    p=tmp_path/'samples.csv'
    p.write_text('sample_id,stage,spaceranger_outs,segmentation_image,species,donor_id\nA,raw,/example/A/outs,/example/A.svs,human,001\n')
    project=project_from_sheets(p,None,output)
    assert project['rows'][0]['_sample_metadata']=={'donor_id':'001','species':'human'}
    assert project['rows'][0]['assets_manifest']==''
    center=ProjectCenter.from_sheets(p,None,output,tmp_path/'center')
    assert center.project['rows'][0]['_sample_metadata']['donor_id']=='001'


def test_ui_form_validates_all_active_names_not_unselected():
    form={'p/1':{'include_in_obs':True,'obs_name':'Tissue_HE','qc_use':'include','coverage_mode':'exhaustive'},
          'p/2':{'include_in_obs':False,'obs_name':'bad&unused','qc_use':'none','coverage_mode':'positive_only'}}
    assert validate_choice_form(form)==form
    form['p/1']['obs_name']='Tissue_H&E'
    with pytest.raises(ValueError):validate_choice_form(form)


def test_real_controller_dispatched_fake_worker_not_real_science(center,source,monkeypatch):
    """Dispatch/state test only: worker output is explicit placeholder bytes, not H5/Parquet."""
    from vhd.compute import launch
    def fake(project,action,execute,sample_keys):
        from vhd.center.stages import output_paths
        for key in sample_keys:
            row=next(r for r in project['rows'] if r['sample_key']==key)
            for p in output_paths(project,row,action):
                p.parent.mkdir(parents=True,exist_ok=True)
                if p.suffix=='.json':p.write_text('{}')
                else:p.write_bytes(b'controller-only fixture')
        return []
    monkeypatch.setattr(launch,'launch_samples',fake)
    inv={'cpu_affinity_threads':8,'eligible_cpu_cores':8,'ram_available_gib':16,'gpus':[]}
    monkeypatch.setattr('vhd.center.resources.detect_resources',lambda:inv)
    center.run_until_review(['A'],confirmed=True,max_actions=1)
    assert center.snapshot()['jobs']['Project__A']['ingest_raw']['status']=='complete'
    assert center.plan(['A'])[0]['status']=='complete'
    # Reopen sees it; a changed output invalidates the center's cache.
    reopened=ProjectCenter.open(center.workspace);(source['paths']['work']/'bins_raw.h5ad').write_bytes(b'changed fixture')
    assert reopened.plan(['A'])[0]['status']=='ready'


def test_real_viewer_fourfold_hint_recovery_is_one_save(tmp_path):
    """Actual TIFF/PNG/XML and actual viewer; no SpatialData master opened."""
    from test_visual_approval_bridge import setup
    from vhd.annotations.discovery import discover_assets
    import runpy
    s=setup.__wrapped__(tmp_path)
    # Deliberately make reference 4x signal while its old hint remains 9.
    Image.fromarray(np.full((40,40,3),245,np.uint8)).save(s['ref'])
    s['geom']['image'].update(width=40,height=40)
    (s['paths']['work']/'geometry.json').write_text(json.dumps(s['geom']))
    discover_assets(s['project'],['Project__A'],execute=True)
    viewer=runpy.run_path(str(Path(__file__).parents[1]/'tools/preview_assets_on_he.py'))
    gallery=viewer['preview_assets_on_he'](s['project'],['A'],max_side=64,dpi=80,show=False)
    summary=gallery.iloc[0]['summary']
    before={p:p.read_bytes() for p in (s['xml'],s['tif'],s['assets'],s['choices'])}
    c=ProjectCenter.import_config(s['manifest'],s['settings'],tmp_path/'center')
    result=c.save_asset_review('A',gallery_summary=summary,edits=choice_edits(c),
        extent_confirmations={'stain':True},signal_interpretations={'stain':'native'},
        scale_hints={'stain':4},reviewer='Synthetic reviewer',confirmed=True)
    assert result['status']=='approved'
    reopened=ProjectCenter.open(c.workspace)
    selected=[r for r in reopened.choices('A') if r['include_in_obs']=='true']
    assert all(r['reviewed_signature'] for r in selected)
    assert next(r for r in selected if r['asset_id']=='stain')['same_extent_confirmed']=='true'
    assert all(p.read_bytes()==v for p,v in before.items())
    assert not s['paths']['store'].exists()


def test_optional_metadata_sheet_exact_join_and_conflict(tmp_path):
    out=tmp_path/'out';out.mkdir()
    sample=tmp_path/'s.csv';sample.write_text('sample_id,spaceranger_outs,segmentation_image,species\nA,/input/A/outs,/input/A.svs,human\n')
    meta=tmp_path/'m.csv';meta.write_text('Sample,Donor\nA,001\n')
    c=ProjectCenter.from_sheets(sample,None,out,tmp_path/'c',metadata_table=meta,metadata_id_column='Sample')
    assert c.row('A')['_sample_metadata']=={'species':'human','Donor':'001'}
    meta.write_text('Sample,species\nA,mouse\n')
    with pytest.raises(ValueError,match='conflicting'):
        ProjectCenter.from_sheets(sample,None,out,tmp_path/'other',metadata_table=meta,metadata_id_column='Sample')


def test_endpoint_change_clears_old_resume_selection(center):
    with center.store.exclusive():
        d=center.snapshot();d['resume']['Project__A']={'action':'cluster_individual'};center._commit(d,'synthetic route fixture')
    center.set_endpoint('A','bins')
    assert 'Project__A' not in center.snapshot()['resume']
    center.plan(['A'])


def test_interrupted_job_not_resubmitted_automatically(center):
    with center.store.exclusive():
        d=center.snapshot();d['jobs']['Project__A']={'ingest_raw':{'status':'running'}};center._commit(d,'Synthetic interrupted-session state')
    with pytest.raises(RuntimeError,match='still marked running'):center.run_until_review(['A'],confirmed=True)
    center.acknowledge_stopped_job('A','ingest_raw',confirmed=True,reviewer='Tester')
    assert center.snapshot()['jobs']['Project__A']['ingest_raw']['status']=='interrupted'


def test_new_sample_species_is_not_forced_human(tmp_path):
    from vhd.center.importers import project_from_sheets
    from vhd.control.manifest import row_config
    from vhd.analysis_qc import profile
    out=tmp_path/'o';out.mkdir();sheet=tmp_path/'s.csv'
    sheet.write_text('sample_id,spaceranger_outs,segmentation_image,species\nM,/input/M/outs,/input/M.svs,mouse\n')
    p=project_from_sheets(sheet,None,out);cfg,spec=row_config(p,p['rows'][0]);assert profile(cfg,spec)['max_pct_mt']==10


def test_runtime_edits_validate_files_and_do_not_run(center,tmp_path):
    import sys
    center.save_runtime_settings({'python_spatial':'current'})
    assert center.project['settings']['execution']['python_spatial']==sys.executable
    with pytest.raises(ValueError,match='not accessible'):center.save_runtime_settings({'proseg_executable':str(tmp_path/'missing')})
    assert center.snapshot()['jobs']=={}
