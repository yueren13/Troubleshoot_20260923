from pathlib import Path
import hashlib
import importlib.util
import json
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import pandas as pd
import pytest
import shapely
from shapely.geometry import Polygon, GeometryCollection, LineString

import review_annotation_candidates as m


BOX=[(0,0),(20,0),(20,20),(0,20)]
BOW=[(5,5),(9,9),(5,9),(9,5),(5,5)]
SPIKE=[(0,2),(0,1),(2,0),(0,0),(0,2)]


def write_source(path, annos):
    root=ET.Element('Annotations')
    for ai,(name,regs) in enumerate(annos):
        a=ET.SubElement(root,'Annotation',Id=str(ai),Name=name)
        rr=ET.SubElement(a,'Regions')
        for ri,(xy,negative) in enumerate(regs):
            r=ET.SubElement(rr,'Region',Id=str(ri),Type='Polygon',NegativeROA='1' if negative else '0')
            vs=ET.SubElement(r,'Vertices')
            for x,y in xy: ET.SubElement(vs,'V',X=str(x),Y=str(y))
    path.write_bytes(ET.tostring(root))
    return path


def audit_for(path):
    return {'files':pd.DataFrame([{'sample_key':'Project__Example','asset_id':'pathology',
         'source_kind':'annotation','path':str(path),
         'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}])}


def test_selfcrossing_not_cross_category_overlap(tmp_path):
    p=write_source(tmp_path/'a.annotations', [('Tissue',[(BOX,False)]),('Tumor',[(BOX,False)])])
    _,records=m._read_snapshot(p)
    assert [r['status'] for r in records]==['valid','valid']
    assert records[0]['_geometry'].intersects(records[1]['_geometry'])


def test_source_hash_blocks_stale_audit(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOX,False),(BOW,True)])])
    audit=audit_for(p);p.write_bytes(p.read_bytes()+b'\n')
    with pytest.raises(RuntimeError,match='changed'):
        m.write_candidate_review(audit,tmp_path)
    assert len(list(tmp_path.iterdir()))==1


def test_negative_split_keeps_all_components(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOX,False),(BOW,True)])])
    _,rs=m._read_snapshot(p)
    for r in rs:m._propose(r,False)
    assert rs[1]['candidates']['linework']['component_types']=={'Polygon':2}
    g,neg,_,stats=m._compose_annotation(rs)
    assert g.area==392
    assert neg.area==8
    assert len(g.interiors)==2
    assert g.is_valid
    assert not stats['accepted']


def test_collection_lower_components_retained_as_unapproved(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Training - Anthro',[(SPIKE,False)])])
    _,rs=m._read_snapshot(p)
    m._propose(rs[0],False)
    c=rs[0]['candidates']['linework']
    assert c['component_types']=={'LineString':1,'Polygon':1}
    assert c['lower_dimensional_length_source_units']==1
    g,_,lines,stats=m._compose_annotation(rs)
    assert len(lines)==1 and g.area==1
    assert stats['n_unapproved_lower_dimensional_parts']==1
    assert rs[0]['_geometry'].is_valid is False


def test_method_comparison_valid_candidates_only(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOW,False)])])
    _,rs=m._read_snapshot(p);m._propose(rs[0],True)
    assert set(rs[0]['candidates'])=={'linework','structure'}
    assert rs[0]['candidate_method_disagreement_area_source_units_squared']>=0


def test_no_auto_largest_component(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Area',[(BOW,False)])])
    _,rs=m._read_snapshot(p);m._propose(rs[0],False)
    g,_,_,_=m._compose_annotation(rs)
    assert len(list(g.geoms))==2 and g.area==8


def test_pure_lower_dimension_rejected_in_composition(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Area',[([(0,0),(1,1),(2,2)],False)])])
    _,rs=m._read_snapshot(p);m._propose(rs[0],False)
    with pytest.raises(ValueError,match='no filled polygon'):
        m._compose_annotation(rs)


def test_categories_never_unioned_together(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOX,False)]),('Tumor',[(BOX,False)])])
    _,rs=m._read_snapshot(p)
    with pytest.raises(ValueError,match='one XML Annotation'):
        m._compose_annotation(rs)


def test_negative_without_parent_rejected(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOW,True)])])
    _,rs=m._read_snapshot(p);m._propose(rs[0],False)
    with pytest.raises(ValueError,match='No positive parent'):
        m._compose_annotation(rs)


def test_exact_coordinate_duplicate_check(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOX,False),(BOW,True)]),('Tiling_Attempt',[(BOX,False),(BOW,True)])])
    _,rs=m._read_snapshot(p)
    assert rs[1]['coordinate_sequence_sha256']==rs[3]['coordinate_sequence_sha256']
    assert rs[1]['annotation_index']!=rs[3]['annotation_index']


def test_original_area_is_explicitly_unreliable(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Area',[(BOW,False)])])
    _,rs=m._read_snapshot(p);m._propose(rs[0],False)
    public=m._public_record(rs[0])
    assert public['original_area_unreliable_when_invalid']==0
    assert 'relative_area_change' not in public


@pytest.mark.parametrize('coords',[[(0,0),(1,1)],[(0,0),(float('nan'),1),(1,1)]])
def test_bad_vertices_no_reports(tmp_path,coords):
    p=write_source(tmp_path/'a.annotations',[('Bad',[(coords,False)])])
    with pytest.raises(ValueError,match='Malformed'):
        m.write_candidate_review(audit_for(p),tmp_path)
    assert len(list(tmp_path.iterdir()))==1


def test_zoom_point():
    assert m._intersection_point('Ring Self-intersection[33326 3683]')==[33326,3683]
    assert m._intersection_point('Valid Geometry') is None


def test_strict_snapshot_and_standalone_no_vhd_dependency(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Area',[(BOW,False)])])
    d,rs=m._read_snapshot(p)
    assert d==hashlib.sha256(p.read_bytes()).hexdigest()
    assert rs[0]['region_id']=='0' and rs[0]['annotation_id']=='0'


def test_visual_report_preserves_inputs_and_all_components(tmp_path):
    p=write_source(tmp_path/'a.annotations',[
        ('Tissue',[(BOX,False),(BOW,True)]),
        ('Tiling_Attempt',[(BOX,False),(BOW,True)]),
        ('Training - Anthro',[(SPIKE,False)])])
    config=tmp_path/'settings.json';config.write_text('{"unchanged":true}')
    before={f.name:(f.read_bytes(),f.stat().st_mtime_ns) for f in (p,config)}
    result=m.write_candidate_review(audit_for(p),tmp_path,compare_structure=True,dpi=72,zoom_radius=3)
    folder=Path(result['report_dir'])
    assert result['status']=='report_complete_not_approved'
    assert not result['accepted_geometry_written'] and not result['image_pixels_read']
    saved=json.loads((folder/'review_summary.json').read_text())
    assert saved['sources'][0]['n_invalid']==3
    assert len(saved['sources'][0]['identical_invalid_coordinate_sequence_groups'])==1
    assert len(list(folder.rglob('*.png')))==15 # 3 invalid * 2 methods * 2 views + 3 category views
    assert (folder/'index.html').is_file()
    assert not list(folder.rglob('*.geojson')) and not list(folder.rglob('*.annotations'))
    assert before=={f.name:(f.read_bytes(),f.stat().st_mtime_ns) for f in (p,config)}


def test_repeated_report_does_not_overwrite(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOX,False)])])
    a=m.write_candidate_review(audit_for(p),tmp_path,dpi=72)
    before=Path(a['report_dir'])/'index.html';content=before.read_bytes()
    b=m.write_candidate_review(audit_for(p),tmp_path,dpi=72)
    assert a['report_dir']!=b['report_dir'] and before.read_bytes()==content


@pytest.mark.parametrize('kwargs',[{'sample_key':'unknown'},{'asset_id':'unknown'}])
def test_no_match_fails_without_writes(tmp_path,kwargs):
    p=write_source(tmp_path/'a.annotations',[('Area',[(BOW,False)])])
    with pytest.raises(ValueError,match='No matching'):
        m.write_candidate_review(audit_for(p),tmp_path,**kwargs)
    assert len(list(tmp_path.iterdir()))==1


def test_report_limit_no_silent_truncation(tmp_path):
    p=write_source(tmp_path/'a.annotations',[('Area',[(BOW,False),(BOW,False)])])
    with pytest.raises(ValueError,match='exceeds'):
        m.write_candidate_review(audit_for(p),tmp_path,max_invalid_regions=1)
    assert len(list(tmp_path.iterdir()))==1


def test_partial_report_is_explicit(tmp_path,monkeypatch):
    p=write_source(tmp_path/'a.annotations',[('Area',[(BOW,False)])])
    def fail(*args):raise OSError('injected write failure')
    monkeypatch.setattr(m,'_draw_region',fail)
    with pytest.raises(OSError,match='injected'):
        m.write_candidate_review(audit_for(p),tmp_path)
    folder=next(tmp_path.glob('annotation_geometry_review_*'))
    assert (folder/'REPORT_INCOMPLETE.txt').is_file()
    assert not (folder/'index.html').exists()


def test_real_previous_diagnostic_schema(tmp_path):
    # Exercise the already-delivered inspector, not an invented replacement audit.
    location=Path(__file__).parent / 'reference_inspector.py'
    if not location.is_file():pytest.skip('Original inspector is not next to this optional integration test.')
    spec=importlib.util.spec_from_file_location('previous_inspector',location)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    p=write_source(tmp_path/'a.annotations',[('Tissue',[(BOX,False)])])
    report=mod.inspect_xml_regions(p,sample_key='P__S',asset_id='pathology',check_repair_candidates=True)
    assert 'summary' in report
    audit={'files':pd.DataFrame([report['summary']])}
    result=m.write_candidate_review(audit,tmp_path,dpi=72)
    assert result['sources'][0]['sample_key']=='P__S'
