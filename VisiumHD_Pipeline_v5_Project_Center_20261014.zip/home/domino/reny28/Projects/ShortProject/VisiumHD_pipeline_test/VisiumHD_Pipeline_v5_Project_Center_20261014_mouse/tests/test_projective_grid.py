"""Pure numeric + actual Shapely geometry tests (no scientific-storage claims)."""
import copy,json,sys,types
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import shapely
from vhd.projective_grid import (fit_grid_model_checked,grid_corners,project_xy,
    homography,geometry_contract,is_projective,_domain_audit,PROJECTIVE_GRID_PATCH)
from vhd.grid_geometry import GridGeometryError,fit_grid_affine_checked
from vhd.grid_diagnostics import fit_and_report,report_summary
from vhd.annotations.projective_sampling import summarize_projective_bins
from vhd.annotations.area_sampling import summarize_footprints
from vhd.core import affine,transform_xy
from vhd.projective_storage import make_projective_bin_shapes,validate_projective_bin_shapes,REGION

MATRICES=json.loads((Path(__file__).parent/'data/projective_diagnostic_matrices.json').read_text())['matrices']
H=np.array([[2,.2,1.5],[.1,2,1.5],[.007,-.005,1.]])


def indices(ny=18,nx=23):
    r,c=np.mgrid[:ny,:nx];return r.ravel(),c.ravel()


def obs_geometry(h=H,ny=18,nx=23):
    r,c=indices(ny,nx);xy=project_xy(np.c_[c,r],h)
    _,audit=fit_grid_model_checked(r,c,xy)
    g={'grid_shape':[ny,nx],'grid_index_to_fullres':h.tolist(),'grid_fit':audit,**geometry_contract(h)}
    obs=pd.DataFrame({'array_row':r,'array_col':c,'pxl_col_in_fullres':xy[:,0],
        'pxl_row_in_fullres':xy[:,1]},index=[f'B{x}' for x in range(len(r))])
    return obs,g,xy


@pytest.mark.parametrize('matrix',MATRICES)
@pytest.mark.parametrize('chunk',[71,250000])
def test_supplied_matrices_synthetic_grid(matrix,chunk):
    r,c=np.meshgrid(np.linspace(0,3349,63,dtype=int),np.linspace(0,3349,67,dtype=int),indexing='ij');r=r.ravel();c=c.ravel()
    xy=project_xy(np.c_[c,r],matrix);before=xy.copy()
    with pytest.raises(GridGeometryError):fit_grid_affine_checked(r,c,xy)
    h,rep=fit_grid_model_checked(r,c,xy,chunk_size=chunk)
    assert rep['acceptance']=='validated_projective_polygons'
    assert rep['validated_n_bins']==len(r) and rep['max_residual_px']<1e-7
    assert rep['initial_least_squares']['max_residual_px']>.1
    assert rep['projective_domain']['denominator_nonzero_over_entire_domain']
    np.testing.assert_array_equal(xy,before)
    np.testing.assert_allclose(project_xy(np.c_[c,r],h),xy,atol=1e-7,rtol=0)
    assert not rep['image_registration_verified']


def test_strict_affine_unchanged():
    r,c=indices();a=affine([2,.1,4,.2,3,5]);xy=transform_xy(np.c_[c,r],a)
    h,rep=fit_grid_model_checked(r,c,xy)
    assert rep['acceptance']=='strict_affine' and rep['bin_representation']=='affine_raster'
    np.testing.assert_array_equal(h[2],[0,0,1])


def test_integer_rounding_path_retained():
    r,c=indices();xy=np.rint(transform_xy(np.c_[c,r],affine([2.137,.117,1.18,.233,3.14,4.271])))
    h,rep=fit_grid_model_checked(r,c,xy)
    assert rep['acceptance']=='verified_integer_pixel_rounding' and not np.any(h[2,:2])


def test_affine_only_still_rejects():
    r,c=indices();xy=project_xy(np.c_[c,r],H)
    with pytest.raises(GridGeometryError):fit_grid_model_checked(r,c,xy,geometry_policy='affine_only')


def test_fractional_does_not_receive_integer_rounding_allowance():
    r,c=indices();xy=project_xy(np.c_[c,r],H);xy[20,0]+=.9
    with pytest.raises(GridGeometryError) as e:fit_grid_model_checked(r,c,xy)
    assert not e.value.report['all_source_coordinates_integer']
    assert e.value.report['projective_rejection']


def test_warped_outlier_rejected():
    r,c=indices();xy=project_xy(np.c_[c,r],H);xy[25,1]+=5
    with pytest.raises(GridGeometryError):fit_grid_model_checked(r,c,xy)


def test_horizon_at_half_bin_boundary_rejected():
    r,c=indices();h=np.array([[2,.2,0],[.1,2,1],[2,0,1.]])
    xy=project_xy(np.c_[c,r],h)
    with pytest.raises(GridGeometryError,match='denominator'):fit_grid_model_checked(r,c,xy)


@pytest.mark.parametrize('policy',['ignore','projective',''])
def test_invalid_policy(policy):
    r,c=indices()
    with pytest.raises(ValueError):fit_grid_model_checked(r,c,np.c_[c,r],geometry_policy=policy)


@pytest.mark.parametrize('h',[np.eye(2),np.zeros((3,3)),[[1,0,0],[0,1,0],[0,0,0]],[[1,0,0],[0,1,0],[np.nan,0,1]]])
def test_bad_homography(h):
    with pytest.raises(ValueError):homography(h)


def test_homogeneous_divide_not_plain_affine_multiplication():
    xy=np.array([[15,12],[21,16]],float)
    exact=project_xy(xy,H);wrong=xy@H[:2,:2].T+H[:2,2]
    assert np.max(np.abs(exact-wrong))>.1


def test_projective_corners_shared_between_neighbors():
    q=grid_corners([5,5],[4,5],H)
    np.testing.assert_array_equal(q[0,[1,2]],q[1,[0,3]])
    # Polygon centroid is NOT the projective image of the array-bin center.
    center=project_xy([[4,5]],H)[0];p=shapely.Polygon(q[0])
    assert np.linalg.norm(np.array([p.centroid.x,p.centroid.y])-center)>1e-4


def test_diagnostic_outputs_projective_model(tmp_path):
    r,c=indices();xy=project_xy(np.c_[c,r],H);f=tmp_path/'diag.json'
    h,rep=fit_and_report(r,c,xy,{},source_mpp=.25,report_path=f)
    assert json.loads(f.read_text())['acceptance']=='validated_projective_polygons'
    assert rep['counts_loaded_for_this_check'] is False
    assert rep['patch']==PROJECTIVE_GRID_PATCH
    assert report_summary({'sample':rep}).status.tolist()==['passed']


def _fake_spatial(monkeypatch):
    # Only the scientific-model parser/transform getter is stubbed. Actual
    # GeoDataFrame, Shapely polygons, indices and validation arithmetic are real.
    models=types.ModuleType('spatialdata.models');trans=types.ModuleType('spatialdata.transformations')
    class Identity:
        def to_affine_matrix(self,**kwargs):return np.eye(3)
    class ShapesModel:
        @staticmethod
        def parse(g,transformations):g.attrs['test_transforms']=transformations;return g
    trans.Identity=Identity;trans.get_transformation=lambda g,**k:g.attrs['test_transforms']['fullres']
    models.ShapesModel=ShapesModel
    monkeypatch.setitem(sys.modules,'spatialdata.models',models)
    monkeypatch.setitem(sys.modules,'spatialdata.transformations',trans)


def test_actual_polygons_and_id_link_with_parser_stub(monkeypatch):
    _fake_spatial(monkeypatch);obs,g,xy=obs_geometry()
    el,ids=make_projective_bin_shapes(obs,g,chunk_size=73)
    assert len(el)==len(obs) and shapely.is_valid(el.geometry.to_numpy()).all()
    assert el.index.is_unique and np.array_equal(ids,obs.index.to_numpy())
    obs['instance_id']=ids;obs['region']=REGION
    result=validate_projective_bin_shapes(el,obs,g,np.arange(len(obs)))
    assert result['sampled_bin_vertex_max_error_px']==0
    assert result['sampled_bin_center_max_error_px']<1e-7
    assert np.array_equal(obs[['pxl_col_in_fullres','pxl_row_in_fullres']],xy)


def test_mutated_vertices_rejected(monkeypatch):
    _fake_spatial(monkeypatch);obs,g,xy=obs_geometry();el,ids=make_projective_bin_shapes(obs,g)
    obs['instance_id']=ids
    el.loc[el.index[0], 'geometry']=shapely.affinity.translate(el.geometry.iloc[0],xoff=.02)
    with pytest.raises(ValueError,match='vertices changed'):validate_projective_bin_shapes(el,obs,g,[0])


def test_label_raster_rejects_projective_before_allocating():
    from vhd.storage import make_bin_labels
    obs,g,_=obs_geometry()
    with pytest.raises(ValueError,match='false Affine'):make_bin_labels(obs,g)


def test_duplicate_bin_ids_rejected(monkeypatch):
    _fake_spatial(monkeypatch);obs,g,_=obs_geometry();obs.iloc[1]=obs.iloc[0]
    with pytest.raises(ValueError,match='Duplicate'):make_projective_bin_shapes(obs,g)


def reference_stats(field,corners):
    p=shapely.Polygon(corners);weights=[];vals=[];inbounds=0
    for y in range(field.shape[0]):
        for x in range(field.shape[1]):
            w=p.intersection(shapely.box(x-.5,y-.5,x+.5,y+.5)).area
            if w>p.area*1e-12:
                inbounds+=w
                if np.isfinite(field[y,x]):weights.append(w);vals.append(field[y,x])
    if not vals:return {'valid_fraction':0,'in_bounds_fraction':inbounds/p.area,'valid':False}
    w=np.asarray(weights);v=np.asarray(vals);order=np.argsort(v,kind='stable');vv=v[order];ww=w[order];cum=np.cumsum(ww);mid=w.sum()/2
    i=int(np.argmax(cum>=mid));median=vv[i]
    if np.isclose(cum[i],mid,atol=p.area*1e-12,rtol=1e-10) and i+1<len(vv):median=(vv[i]+vv[i+1])/2
    return {'mean':(v*w).sum()/w.sum(),'sum':(v*w).sum(),'median':median,'min':v.min(),'max':v.max(),
            'valid_fraction':w.sum()/p.area,'in_bounds_fraction':inbounds/p.area,'n_valid_pixels':len(v),'valid':True}


@pytest.mark.parametrize('source',[np.eye(3),affine([2,.1,1,.15,2,1]),affine([0,-1,15,1,0,0])])
@pytest.mark.parametrize('chunk',[1,7,20000])
def test_signal_stats_against_independent_intersections(source,chunk):
    field=np.arange(26*27,dtype=float).reshape(26,27);field[3,3]=np.nan
    r=np.array([0,2,3,5,8]);c=np.array([0,2,3,7,10])
    result=summarize_projective_bins(field,r,c,grid_index_to_fullres=H,source_to_fullres=source,
        methods=['mean','median','sum','min','max'],chunk_size=chunk,max_pairs=150)
    inv=np.linalg.inv(source);q=grid_corners(r,c,H)@inv[:2,:2].T+inv[:2,2]
    for i,quad in enumerate(q):
        ref=reference_stats(field,quad)
        for key,value in ref.items():assert result[key][i]==pytest.approx(value,rel=1e-9,abs=1e-9)


def test_binary_area_mean_sum_and_valid_coverage():
    field=np.array([[1,0],[np.nan,1.]])
    h=np.array([[2,0,.5],[0,2,.5],[0,0,1.]])
    r=summarize_projective_bins(field,[0],[0],grid_index_to_fullres=h,source_to_fullres=np.eye(3),methods=['mean','median','sum','min','max'])
    assert r['mean'][0]==pytest.approx(2/3) and r['sum'][0]==2 and r['median'][0]==1
    assert r['valid_fraction'][0]==.75 and r['in_bounds_fraction'][0]==1 and r['n_valid_pixels'][0]==3


def test_signal_explicit_coverage_distinct_from_bounds():
    h=np.array([[2,0,.5],[0,2,.5],[0,0,1.]])
    r=summarize_projective_bins(np.ones((2,2)),[0],[0],grid_index_to_fullres=h,source_to_fullres=np.eye(3),
        coverage_source=shapely.box(-.5,-.5,.5,1.5),methods=['mean','sum'])
    assert r['valid_fraction'][0]==.5 and r['in_bounds_fraction'][0]==1 and r['sum'][0]==2


def test_signal_all_outside_is_unknown():
    r=summarize_projective_bins(np.ones((2,2)),[200],[100],grid_index_to_fullres=np.diag([2.,2.,1]),source_to_fullres=np.eye(3))
    assert not r['valid'][0] and np.isnan(r['mean'][0])


def test_signal_memory_cap():
    with pytest.raises(ValueError,match='candidate pixels'):
        summarize_projective_bins(np.ones((2,2)),[1],[1],grid_index_to_fullres=np.diag([100.,100.,1]),source_to_fullres=np.eye(3))


def test_signal_half_weight_median_tie():
    r=summarize_projective_bins(np.array([[1.,3],[5,7]]),[0],[0],grid_index_to_fullres=[[2,0,.5],[0,2,.5],[0,0,1]],source_to_fullres=np.eye(3),methods=['median'])
    assert r['median'][0]==4


@pytest.mark.parametrize('bad',['NaN','out_of_range','conflicting_ids'])
def test_polygon_input_safety(monkeypatch,bad):
    _fake_spatial(monkeypatch);obs,g,xy=obs_geometry()
    if bad=='NaN':obs['array_row']=obs.array_row.astype(float);obs.loc[obs.index[0],'array_row']=np.nan
    elif bad=='out_of_range':obs.loc[obs.index[0],'array_col']=24
    else:obs.iloc[1]=obs.iloc[0]
    with pytest.raises(ValueError):make_projective_bin_shapes(obs,g)
