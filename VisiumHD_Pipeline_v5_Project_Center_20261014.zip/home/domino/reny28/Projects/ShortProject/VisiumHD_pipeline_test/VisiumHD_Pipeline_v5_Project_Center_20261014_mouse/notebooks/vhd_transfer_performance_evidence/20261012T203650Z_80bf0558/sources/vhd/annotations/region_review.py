"""Visual review of ImageScope XML repair candidates; NOT a pipeline parser/repair.

Reads the original XML byte snapshot, verifies its hash against an existing
inspect_annotation_geometry.py audit, and writes ONLY a new report directory.
No XML, manifest, approval, .obs, master, or accepted geometry is modified.
All coordinates are the XML's source coordinates. No H&E registration is assumed.
Requires Shapely >=2.1, pandas, numpy, matplotlib and defusedxml.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import html
import json
import math
from pathlib import Path
import re
import uuid
from typing import Any

import numpy as np
import pandas as pd
import shapely
from defusedxml import ElementTree as ET
from shapely.geometry import Polygon

REVIEW_VERSION = "annotation-candidate-visual-review-20261002-v1"


def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _leaves(geometry):
    """Retain every component, including empty/lower-dimensional results."""
    if hasattr(geometry, "geoms") and not geometry.is_empty:
        for part in geometry.geoms:
            yield from _leaves(part)
    else:
        yield geometry


def _polygon_parts(geometry):
    return [g for g in _leaves(geometry)
            if g.geom_type == "Polygon" and not g.is_empty and g.area > 0]


def _candidate_info(geometry):
    leaves = list(_leaves(geometry))
    polygons = _polygon_parts(geometry)
    return {
        "type": geometry.geom_type,
        "valid": bool(geometry.is_valid), "empty": bool(geometry.is_empty),
        "component_types": dict(sorted(Counter(g.geom_type for g in leaves).items())),
        "polygon_component_areas_source_units_squared": [float(g.area) for g in polygons],
        "polygon_area_source_units_squared": float(sum(g.area for g in polygons)),
        "polygon_holes": int(sum(len(g.interiors) for g in polygons)),
        "lower_dimensional_types": dict(sorted(Counter(
            g.geom_type for g in leaves if g.geom_type != "Polygon").items())),
        "lower_dimensional_length_source_units": float(sum(
            g.length for g in leaves if g.geom_type != "Polygon")),
        "accepted": False,
    }


def _read_snapshot(path: Path, expected_sha256: str | None = None):
    payload = path.read_bytes()
    digest = _hash(payload)
    if expected_sha256 and digest != expected_sha256:
        raise RuntimeError(f"Source changed since the diagnostic: {path}. Rerun the read-only audit first.")
    root = ET.fromstring(payload)
    for node in root.iter():
        node.tag = node.tag.rsplit("}", 1)[-1]
    if root.tag not in ("Annotations", "Annotation"):
        raise ValueError("Expected ImageScope XML root Annotations/Annotation.")
    annotations = list(root.iter("Annotation"))
    if not annotations:
        raise ValueError("No Annotation elements.")
    records = []
    for ai, annotation in enumerate(annotations):
        category = annotation.get("Name", "unnamed")
        for ri, region in enumerate(annotation.findall("./Regions/Region")):
            rec = {
                "annotation_index": ai, "annotation_id": str(annotation.get("Id", ai)),
                "category": category,
                "region_index": ri, "region_id": str(region.get("Id", ri)),
                "negative_region": region.get("NegativeROA", "0").lower() in ("1", "true", "t", "yes"),
                "region_type": region.get("Type", ""),
                "n_vertices": 0, "status": "malformed", "reason": "",
                "candidates": {}, "_candidate_geometries": {},
            }
            try:
                vertices = region.find("Vertices")
                if vertices is None:
                    raise ValueError("Missing Vertices.")
                short = list(vertices.findall("V"))
                long = list(vertices.findall("Vertex"))
                if short and long:
                    raise ValueError("Mixed V/Vertex tags require manual format review.")
                vs = short or long
                xy = np.asarray([[float(v.get("X")), float(v.get("Y"))] for v in vs], dtype=np.float64)
                if xy.ndim != 2 or xy.shape[1] != 2 or len(xy) < 3 or not np.isfinite(xy).all():
                    raise ValueError("Need at least three finite X/Y vertices.")
                rec["n_vertices"] = len(xy)
                rec["coordinate_sequence_sha256"] = _hash(xy.astype("<f8").tobytes())
                polygon = Polygon(xy)
                rec.update(
                    _xy=xy, _geometry=polygon,
                    status="valid" if polygon.is_valid and not polygon.is_empty and polygon.area > 0 else "invalid",
                    reason=str(shapely.is_valid_reason(polygon)),
                    original_area_unreliable_when_invalid=float(polygon.area),
                )
                if rec["status"] == "invalid" and polygon.is_valid:
                    rec["reason"] = "Empty/zero-area filled region."
            except Exception as exc:
                rec["reason"] = f"{type(exc).__name__}: {exc}"
            records.append(rec)
    if not records:
        raise ValueError("No Regions/Region elements.")
    return digest, records


def _propose(rec, compare_structure):
    """Linework matches the original inspector's default; no best-method choice."""
    if rec["status"] != "invalid":
        return
    for method in (["linework", "structure"] if compare_structure else ["linework"]):
        try:
            candidate = shapely.make_valid(rec["_geometry"], method=method, keep_collapsed=True)
            rec["_candidate_geometries"][method] = candidate
            rec["candidates"][method] = _candidate_info(candidate)
        except Exception as exc:
            rec["candidates"][method] = {"error": f"{type(exc).__name__}: {exc}", "accepted": False}
    # Comparing two VALID candidates is meaningful. Invalid original area is not a gold standard.
    if {"linework", "structure"}.issubset(rec["_candidate_geometries"]):
        a, b = (rec["_candidate_geometries"][key] for key in ("linework", "structure"))
        try:
            pa = shapely.union_all(_polygon_parts(a))
            pb = shapely.union_all(_polygon_parts(b))
            rec["candidate_method_disagreement_area_source_units_squared"] = float(pa.symmetric_difference(pb).area)
        except Exception as exc:
            rec["candidate_comparison_error"] = f"{type(exc).__name__}: {exc}"


def _compose_annotation(records, method="linework"):
    """Candidate-only union of positive areas minus negative areas in ONE Annotation.

    Lower-dimensional candidates are not made into filled area. Their disposition
    is recorded as UNAPPROVED. No components are dropped from source/accepted data.
    """
    if len({r["annotation_index"] for r in records}) != 1:
        raise ValueError("Composition must be within one XML Annotation, never across categories.")
    positive, negative, residuals = [], [], []
    for rec in records:
        if rec["status"] == "malformed":
            raise ValueError(f"Malformed region {rec['region_id']}; no composed candidate.")
        g = rec["_geometry"] if rec["status"] == "valid" else rec["_candidate_geometries"].get(method)
        if g is None or not g.is_valid:
            raise ValueError(f"No valid {method} candidate for region {rec['region_id']}.")
        pieces = _polygon_parts(g)
        if not pieces:
            raise ValueError(f"Region {rec['region_id']} has no filled polygon component; do not silently omit it.")
        (negative if rec["negative_region"] else positive).extend(pieces)
        if rec["status"] != "valid":
            residuals.extend(g for g in _leaves(g) if g.geom_type != "Polygon" and not g.is_empty)
    if not positive:
        raise ValueError("No positive parent area in this Annotation.")
    positive_union = shapely.union_all(positive)
    negative_union = shapely.union_all(negative)
    result = positive_union.difference(negative_union) if negative else positive_union
    if not result.is_valid:
        raise ValueError("Composed category candidate is invalid; needs further review.")
    stats = {
        "method": method, "accepted": False,
        "positive_union_area_source_units_squared": float(positive_union.area),
        "negative_union_area_source_units_squared": float(negative_union.area),
        "negative_area_outside_positive_parent": float(negative_union.difference(positive_union).area),
        "net_candidate_area_source_units_squared": float(result.area),
        "net_type": result.geom_type, "net_empty": bool(result.is_empty),
        "net_valid": bool(result.is_valid),
        "n_unapproved_lower_dimensional_parts": len(residuals),
        "meaning": "CANDIDATE ONLY: union(positive polygon parts) minus union(negative polygon parts), per XML Annotation.",
    }
    return result, negative_union, residuals, stats


def _intersection_point(reason):
    match = re.search(r"\[\s*([-+0-9.eE]+)\s+([-+0-9.eE]+)\s*\]", reason)
    if not match:
        return None
    point = [float(match.group(1)), float(match.group(2))]
    return point if all(math.isfinite(x) for x in point) else None


def _plot_candidate_geometry(ax, geometry, label, *, fill=True):
    """Matplotlib defaults; each Polygon preserves interior holes in its patch."""
    from shapely.plotting import plot_polygon
    first_poly = first_lower = True
    for part in _leaves(geometry):
        if part.is_empty:
            continue
        if part.geom_type == "Polygon":
            plot_polygon(part, ax=ax, add_points=False, alpha=0.27 if fill else 1,
                         facecolor=None if fill else "none", linewidth=1.1,
                         label=label if first_poly else None)
            first_poly = False
        elif part.geom_type in ("LineString", "LinearRing"):
            xy = np.asarray(part.coords)
            ax.plot(xy[:, 0], xy[:, 1], linestyle=":", linewidth=2.3,
                    label="Lower-dimensional candidate (NOT filled/approved)" if first_lower else None)
            first_lower = False
        elif part.geom_type == "Point":
            ax.plot([part.x], [part.y], marker="x", linestyle="none",
                    label="Point candidate (NOT approved)" if first_lower else None)
            first_lower = False


def _draw_region(rec, folder, dpi, zoom_radius):
    import matplotlib.pyplot as plt
    outputs = []
    if rec["status"] != "invalid":
        return outputs
    key = f"a{rec['annotation_index']:04d}_r{rec['region_index']:05d}"
    raw = rec["_xy"]
    ring = raw if np.array_equal(raw[0], raw[-1]) else np.vstack((raw, raw[0]))
    point = _intersection_point(rec["reason"])
    for method, candidate in rec["_candidate_geometries"].items():
        for view in (["whole", "zoom"] if point is not None else ["whole"]):
            fig, ax = plt.subplots(figsize=(9, 8))
            try:
                # Invalid input is shown as an outline, never interpreted as a filled area.
                ax.plot(ring[:, 0], ring[:, 1], linestyle="--", linewidth=1.2,
                        label="Original XML ring (invalid; outline only)")
                _plot_candidate_geometry(ax, candidate, f"{method} polygon candidate")
                if point is not None:
                    ax.plot([point[0]], [point[1]], marker="o", fillstyle="none",
                            markersize=10, linestyle="none", label="Reported invalidity location")
                if view == "zoom":
                    ax.set_xlim(point[0]-zoom_radius, point[0]+zoom_radius)
                    ax.set_ylim(point[1]-zoom_radius, point[1]+zoom_radius)
                else:
                    ax.margins(0.06)
                ax.invert_yaxis()
                ax.set_aspect("equal", adjustable="box")
                ax.set_xlabel("X — annotation source coordinates")
                ax.set_ylabel("Y — annotation source coordinates")
                title = (f"{rec['category']} | annotation {rec['annotation_id']} / region {rec['region_id']}\n"
                         f"{'NEGATIVE / subtraction region' if rec['negative_region'] else 'Positive region'} | {method} | {view}")
                ax.set_title(title, fontsize=12, wrap=True)
                ax.legend(loc="best", fontsize=8)
                fig.text(0.5, 0.02, "CANDIDATE ONLY • Not accepted • No H&E registration shown", ha="center", fontsize=10)
                fig.tight_layout(rect=(0, 0.045, 1, 1))
                name = f"{key}_{method}_{view}.png"
                fig.savefig(folder / name, dpi=dpi)
                outputs.append(name)
            finally:
                plt.close(fig)
    return outputs


def _draw_category(records, folder, dpi):
    import matplotlib.pyplot as plt
    try:
        geometry, negative, residuals, stats = _compose_annotation(records)
    except Exception as exc:
        return {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}
    rec = records[0]
    name = f"a{rec['annotation_index']:04d}_category_linework_candidate.png"
    fig, ax = plt.subplots(figsize=(10, 8))
    try:
        _plot_candidate_geometry(ax, geometry, "Net polygon candidate AFTER exclusions")
        # Display all negative outlines without adding their areas back to the candidate.
        for i, part in enumerate(_polygon_parts(negative)):
            xy = np.asarray(part.exterior.coords)
            ax.plot(xy[:, 0], xy[:, 1], linestyle="--", linewidth=1,
                    label="Negative-region outline (subtract, not add)" if i == 0 else None)
        for r in records:
            if r["status"] == "invalid":
                xy = r["_xy"]
                xy = xy if np.array_equal(xy[0], xy[-1]) else np.vstack((xy, xy[0]))
                ax.plot(xy[:, 0], xy[:, 1], linestyle=":", linewidth=1)
        ax.autoscale_view(); ax.margins(.03); ax.invert_yaxis(); ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("X — annotation source coordinates"); ax.set_ylabel("Y — annotation source coordinates")
        ax.set_title(f"{rec['category']} | XML Annotation {rec['annotation_id']}\nCandidate-only category composition", wrap=True)
        handles, labels = ax.get_legend_handles_labels()
        if handles: ax.legend(fontsize=8)
        fig.text(.5, .02, "NOT accepted • Lower-dimensional pieces retained in the report, not treated as area • No H&E", ha="center", fontsize=9)
        fig.tight_layout(rect=(0, .045, 1, 1)); fig.savefig(folder / name, dpi=dpi)
    finally:
        plt.close(fig)
    stats["preview"] = name
    return stats


def _public_record(rec):
    return {key: value for key, value in rec.items() if not key.startswith("_")}


def write_candidate_review(audit, output_parent, *, sample_key=None, asset_id=None,
                           compare_structure=False, zoom_radius=100.0, dpi=180,
                           max_invalid_regions=50):
    """Write a NEW candidate-only visual report from the existing audit.

    Source files are re-read and must match the audit's SHA256. The only writes
    are inside the newly created report subdirectory. Output parent must exist.
    This function neither installs a hotfix nor prepares an importable geometry.
    Category previews include every source region in that XML Annotation; method
    comparisons (when requested) do not automatically select or approve a method.
    """
    if not hasattr(shapely, "make_valid") or tuple(int(x) for x in shapely.__version__.split(".")[:2]) < (2, 1):
        raise RuntimeError("This report helper requires Shapely >=2.1 (your diagnostic reported 2.1.2).")
    if type(compare_structure) is not bool:
        raise TypeError("compare_structure must be bool.")
    if not math.isfinite(zoom_radius) or zoom_radius <= 0:
        raise ValueError("zoom_radius must be positive in annotation source units.")
    if type(dpi) is not int or not 72 <= dpi <= 600:
        raise ValueError("dpi must be an integer between 72 and 600.")
    if type(max_invalid_regions) is not int or max_invalid_regions < 1:
        raise ValueError("max_invalid_regions must be positive.")
    if not isinstance(audit, dict) or not isinstance(audit.get("files"), pd.DataFrame):
        raise TypeError("Supply the audit returned by inspect_project_annotations().")
    parent = Path(output_parent).expanduser()
    if not parent.is_absolute() or not parent.is_dir():
        raise ValueError("output_parent must be an existing absolute report directory.")
    rows = audit["files"]
    for name in ("path", "source_sha256", "sample_key", "asset_id", "source_kind"):
        if name not in rows:
            raise ValueError(f"Audit is missing {name}.")
    if sample_key is not None: rows = rows[rows["sample_key"] == sample_key]
    if asset_id is not None: rows = rows[rows["asset_id"] == asset_id]
    rows = rows[rows["source_kind"] == "annotation"]
    if rows.empty:
        raise ValueError("No matching annotation source in this audit; no files written.")
    if rows[["sample_key", "asset_id", "path"]].duplicated().any():
        raise ValueError("Duplicate source records in audit.")
    snapshots = []
    for row in rows.to_dict("records"):
        expected = row["source_sha256"]
        if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise ValueError("Audit lacks a SHA256 source snapshot; rerun inspection.")
        path = Path(row["path"]).expanduser()
        digest, records = _read_snapshot(path, expected)
        malformed = [r for r in records if r["status"] == "malformed"]
        if malformed:
            raise ValueError("Malformed/mixed-tag source region; use source diagnostics before this repair-candidate report.")
        invalid_count = sum(r["status"] == "invalid" for r in records)
        if invalid_count > max_invalid_regions:
            raise ValueError(f"{invalid_count} invalid regions exceeds the explicit review limit {max_invalid_regions}; no report written.")
        for rec in records: _propose(rec, compare_structure)
        snapshots.append((row, digest, records))
    report_dir = parent / ("annotation_geometry_review_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_") + uuid.uuid4().hex[:8])
    report_dir.mkdir(exist_ok=False)
    result = {
        "review_version": REVIEW_VERSION,
        "shapely_version": shapely.__version__, "geos_version": shapely.geos_version_string,
        "purpose": "candidate inspection only; not an importable or accepted annotation",
        "methods": ["linework", "structure"] if compare_structure else ["linework"],
        "source_changed": False, "config_changed": False, "accepted_geometry_written": False,
        "image_pixels_read": False, "expression_read": False, "coordinate_frame": "XML source coordinates only",
        "report_dir": str(report_dir), "sources": [],
    }
    try:
        for fi, (source, digest, records) in enumerate(snapshots):
            folder = report_dir / f"source_{fi:03d}"; folder.mkdir()
            invalid = [r for r in records if r["status"] == "invalid"]
            for rec in invalid:
                rec["previews"] = [f"source_{fi:03d}/"+n for n in _draw_region(rec, folder, dpi, zoom_radius)]
            categories = []
            for ai in sorted({r["annotation_index"] for r in records}):
                selected = [r for r in records if r["annotation_index"] == ai]
                first = selected[0]
                item = {"category": first["category"], "annotation_index": ai, "annotation_id": first["annotation_id"],
                        "n_regions": len(selected), "n_invalid": sum(r["status"] == "invalid" for r in selected),
                        "n_negative": sum(r["negative_region"] for r in selected), "include_in_obs": False,
                        "approved": False}
                if item["n_invalid"]:
                    composition = _draw_category(selected, folder, dpi)
                    if "preview" in composition: composition["preview"] = f"source_{fi:03d}/"+composition["preview"]
                    item["candidate_composition"] = composition
                categories.append(item)
            # Verify suspected duplicates using every coordinate, not merely vertex count/error point.
            hashes = {}
            for rec in invalid:
                hashes.setdefault(rec["coordinate_sequence_sha256"], []).append(
                    {k: rec[k] for k in ("category", "annotation_id", "region_id", "annotation_index", "region_index", "negative_region")})
            result["sources"].append({
                "sample_key": source["sample_key"], "asset_id": source["asset_id"], "path": source["path"],
                "source_sha256": digest, "n_regions": len(records), "n_invalid": len(invalid),
                "category_inventory": categories, "region_candidates": [_public_record(r) for r in invalid],
                "identical_invalid_coordinate_sequence_groups": [v for v in hashes.values() if len(v) > 1],
                "duplicate_action": "report only; never deduplicated across annotations",
            })
        result["status"] = "report_complete_not_approved"
        (report_dir / "review_summary.json").write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False)+"\n", encoding="utf-8")
        _write_html(result, report_dir / "index.html")
    except Exception as exc:
        (report_dir / "REPORT_INCOMPLETE.txt").write_text(f"{type(exc).__name__}: {exc}\nDo not interpret partial plots as a completed review.\n", encoding="utf-8")
        raise
    print("CANDIDATE REPORT ONLY — no source/config/accepted geometry changed.")
    print("Open:", report_dir / "index.html")
    print("Summary:", report_dir / "review_summary.json")
    return result


def _write_html(result, path):
    esc = lambda value: html.escape(str(value), quote=True)
    text = ['<!doctype html><html><head><meta charset="utf-8"><title>Annotation candidate review</title>',
            '<style>body{font:17px sans-serif;max-width:1100px;margin:2em auto;padding:0 1em}img{max-width:100%}table{border-collapse:collapse}td,th{border:1px solid;padding:.4em}pre{white-space:pre-wrap}</style></head><body>',
            '<h1>Annotation repair candidates — not approved</h1>',
            '<p>XML-source coordinates only. No H&amp;E or registration is shown. Original source and pipeline outputs are unchanged. Candidate validity is not evidence of intended anatomy.</p>',
            '<p>Linework is the explicit version of the method used by the first diagnostic. Optional structure plots are alternatives, not automatic selections. Lower-dimensional components have no filled area here but are not approved for removal.</p>',
            '<p><a href="review_summary.json">Full numerical/provenance report</a></p>']
    for source in result["sources"]:
        text += [f'<h2>{esc(source["sample_key"])} / {esc(source["asset_id"])}</h2>',
                 f'<p>Source: {esc(source["path"])}<br>SHA256: {esc(source["source_sha256"])}</p>',
                 '<h3>Inventory (not a pipeline choices file)</h3><table><tr><th>Category</th><th>Annotation ID</th><th>Regions</th><th>Invalid</th><th>Negative</th><th>Candidate-only composition</th></tr>']
        for category in source["category_inventory"]:
            comp = category.get("candidate_composition", {})
            link = f'<a href="{esc(comp["preview"])}">Inspect after exclusions</a>' if "preview" in comp else esc(comp.get("error", "Not generated: no invalid regions"))
            text.append('<tr>'+''.join(f'<td>{esc(category[k])}</td>' for k in ("category", "annotation_id", "n_regions", "n_invalid", "n_negative"))+f'<td>{link}</td></tr>')
        text.append('</table>')
        for rec in source["region_candidates"]:
            text += [f'<h3>{esc(rec["category"])} / annotation {esc(rec["annotation_id"])} / region {esc(rec["region_id"])}</h3>',
                     f'<p>NegativeROA: {esc(rec["negative_region"])}; {esc(rec["reason"])}</p>',
                     '<pre>'+esc(json.dumps(rec["candidates"], indent=2))+'</pre>']
            for image in rec["previews"]:
                text.append(f'<p><a href="{esc(image)}">{esc(image)}</a></p><img loading="lazy" src="{esc(image)}" alt="Unapproved region candidate">')
    text += ['<h2>Before using a candidate</h2><p>Review all polygon pieces and exclusions; decide explicitly about any lower-dimensional components. Do not add negative polygons as positive tissue, keep only the largest piece, or deduplicate across categories. Check alignment against H&amp;E separately. This report provides no repair application or import command.</p>', '</body></html>']
    path.write_text('\n'.join(text), encoding='utf-8')
