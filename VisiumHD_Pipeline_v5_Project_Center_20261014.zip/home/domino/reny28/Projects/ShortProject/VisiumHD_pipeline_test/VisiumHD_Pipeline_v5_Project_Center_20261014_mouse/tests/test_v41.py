"""v4.1 numerical/config tests. Master I/O is stubbed only where explicitly stated."""
import copy,csv,json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import shapely
from scipy import sparse
from vhd.annotations.alignment import extent_affine,resolve_alignment,fit_landmarks
from vhd.annotations.area_sampling import summarize_footprints
from vhd.annotations.discovery import (CHOICE_COLUMNS,discover_one,merge_choices,read_choices,atomic_choices,
    expand_choices,choice_signature,review_prior_settings,has_active_choices)
from vhd.annotations.workflow import read_assets,alignment_signature,transfer_assets,active_assets,validate_prior_sources
from vhd.annotations.transfer import aggregate_annotations,segmentation_decisions
from vhd.annotations.raster import open_raster


def write_csv(path,rows,fields=None):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
    return path


def xml(tmp):
    def region(points,negative=0):
        return f'<Region NegativeROA="{negative}"><Vertices>'+''.join(f'<V X="{x}" Y="{y}"/>' for x,y in points)+'</Vertices></Region>'
    outer=region([(0,0),(10,0),(10,10),(0,10)])
    hole=region([(4,4),(6,4),(6,6),(4,6)],1)
    nec=region([(4,4),(7,4),(7,7),(4,7)])
    p=tmp/'sample.annotations'
    p.write_text('<Annotations><Annotation Name="Tissue"><Regions>'+outer+hole+'</Regions></Annotation><Annotation Name="Necrosis"><Regions>'+nec+'</Regions></Annotation><Annotation Name="Tumor, region 2"><Regions>'+outer+'</Regions></Annotation><Annotation Name="Do not use"><Regions>'+nec+'</Regions></Annotation></Annotations>')
    return p


def source(tmp,kind='polygons',**kwargs):
    raw={'sample_id':'A','asset_id':'pathology' if kind=='polygons' else 'signal','kind':kind,'path':str(xml(tmp)) if kind=='polygons' else '',
        'registration_mode':'explicit','source_to_fullres':'1;0;0;0;1;0', 'role':'discover','coverage_mode':'exhaustive'}
    raw.update(kwargs);path=write_csv(tmp/'assets.csv',[raw]);return read_assets(path,'Project','A')[0]


def prepare_choices(a,g):
    choices,report=discover_one(a,g,'Project__A');atomic_choices(a['review_table'],choices)
    return choices,report


def select(a,g,changes):
    rows=read_choices(a['review_table']);sig=alignment_signature(a,g)
    for r in rows:
        if r['category'] in changes:
            r.update(changes[r['category']]);r['reviewed_signature']=choice_signature(r,sig)
    atomic_choices(a['review_table'],rows)
    return rows


def test_minimal_source_no_dataset_or_category(tmp_path):
    a=source(tmp_path)
    assert a['dataset_id']=='Project' and a['categories']==[] and a['role']=='discover'
    choices,report=prepare_choices(a,{})
    assert len(choices)==4 and set(r['category'] for r in choices)=={'Tissue','Necrosis','Tumor, region 2','Do not use'}
    assert all(r['include_in_obs']=='false' for r in choices)
    assert not has_active_choices(a) and active_assets([a])==[]
    assert report['inventory'][2]['category'] # actual XML read, not names typed from memory


def test_same_file_mixed_roles_and_unknown_categories(tmp_path):
    a=source(tmp_path);g={};prepare_choices(a,g)
    select(a,g,{'Tissue':{'include_in_obs':'true','qc_use':'include'},'Necrosis':{'include_in_obs':'true','qc_use':'exclude'},
                'Tumor, region 2':{'include_in_obs':'true','cell_methods':'fraction;majority'}})
    items=expand_choices(a,g);assert len(items)==3
    assert len({i['_source_asset_id'] for i in items})==1
    assert not any('Do not use' in i['categories'] for i in items)
    prior=review_prior_settings(items,{'mode':'from_review','unknown_policy':'exclude'})
    assert prior['enabled'] and len(prior['tissue_columns'])==1 and len(prior['exclude_columns'])==1
    validate_prior_sources(items,prior)
    with pytest.raises(ValueError,match='not owned'):
        validate_prior_sources(items,{'enabled':True,'exclude_columns':[next(i['_output_column'] for i in items if i['role']=='analysis')]})


def test_changing_choice_requires_new_approval(tmp_path):
    a=source(tmp_path);prepare_choices(a,{})
    select(a,{}, {'Tissue':{'include_in_obs':'true'}})
    assert len(expand_choices(a,{}))==1
    rows=read_choices(a['review_table']);next(r for r in rows if r['category']=='Tissue')['qc_use']='include';atomic_choices(a['review_table'],rows)
    with pytest.raises(RuntimeError,match='Unapproved'):expand_choices(a,{})


def test_source_update_preserves_choices_but_clears_approval(tmp_path):
    a=source(tmp_path);prepare_choices(a,{})
    old=select(a,{}, {'Tissue':{'include_in_obs':'true','same_extent_confirmed':'true'}})
    p=Path(a['path']);p.write_text(p.read_text().replace('X="10"','X="11"'))
    new,_=discover_one(a,{},'Project__A')
    merged=merge_choices(old,new,{('Project__A','pathology')})
    tissue=next(x for x in merged if x['category']=='Tissue')
    assert tissue['include_in_obs']=='true' and tissue['reviewed_signature']=='' and tissue['same_extent_confirmed']=='false'


def test_merge_preserves_other_samples_and_drops_deleted_items():
    def r(sample,item):return dict(zip(CHOICE_COLUMNS,[sample,'a',item,item,'false','none','abc','','','exhaustive','false','s','','']))
    old=[r('one','keep'),r('one','removed'),r('two','other')]
    merged=merge_choices(old,[r('one','keep')],{('one','a')})
    assert [(x['sample_key'],x['item_key']) for x in merged]==[('one','keep'),('two','other')]


def test_selection_does_not_change_polygons(tmp_path):
    from vhd.annotations.workflow import polygons
    a=source(tmp_path);before=Path(a['path']).read_bytes();prepare_choices(a,{})
    select(a,{}, {'Necrosis':{'include_in_obs':'true'}})
    assert len(expand_choices(a,{}))==1 and len(polygons(a))==4 and Path(a['path']).read_bytes()==before
    assert polygons(a).loc[lambda f:f.name=='Tissue'].geometry.iloc[0].area==96


@pytest.mark.parametrize('mutate',[{'include_in_obs':'false','qc_use':'exclude'},{'include_in_obs':'true','obs_name':'region'},
                                     {'include_in_obs':'true','cell_methods':'sum'}])
def test_invalid_category_choices_rejected(tmp_path,mutate):
    a=source(tmp_path);prepare_choices(a,{});select(a,{}, {'Tissue':mutate})
    with pytest.raises(ValueError):expand_choices(a,{})


def test_extent_9_and_rounding_and_reference_frame():
    m=extent_affine((100,200),(900,1800));np.testing.assert_allclose(m,[[9,0,4],[0,9,4],[0,0,1]])
    m=extent_affine((100,200),(899,1801));assert m[0,0]==9.005 and m[1,1]==8.99
    np.testing.assert_allclose(extent_affine((100,200),(900,1800),pixel_convention='origin_centers'),np.diag([9,9,1]))


def test_auto_scale_is_proposal_not_registration(tmp_path):
    import tifffile
    p=tmp_path/'a.tif';tifffile.imwrite(p,np.zeros((100,200),np.uint8))
    a=source(tmp_path,'signal',path=str(p),registration_mode='auto_extent',source_to_fullres='',scale_hint='9')
    g={'image':{'width':1800,'height':900,'path':'reference.svs'},'tenx_to_image':[[1,0,10],[0,1,20],[0,0,1]]}
    resolved=resolve_alignment(a,g);assert resolved['_alignment']['scale_checks_passed']
    np.testing.assert_allclose(resolved['source_to_fullres'],[[9,0,-6],[0,9,-16],[0,0,1]])
    prepare_choices(a,g)
    select(resolved,g,{'__signal__':{'include_in_obs':'true'}})
    with pytest.raises(ValueError,match='same field'):expand_choices(resolved,g)
    select(resolved,g,{'__signal__':{'include_in_obs':'true','same_extent_confirmed':'true'}})
    assert len(expand_choices(resolved,g))==1


def test_scale_hint_mismatch_not_silently_used(tmp_path):
    import tifffile
    p=tmp_path/'a.tif';tifffile.imwrite(p,np.zeros((10,20),np.uint8))
    a=source(tmp_path,'signal',path=str(p),registration_mode='auto_extent',source_to_fullres='',scale_hint=str(1/9))
    g={'image':{'width':180,'height':90,'path':'ref'}};r=resolve_alignment(a,g)
    assert not r['_alignment']['scale_checks_passed'] and r['_alignment']['scale_x']==9
    prepare_choices(a,g);select(r,g,{'__signal__':{'include_in_obs':'true','same_extent_confirmed':'true'}})
    with pytest.raises(ValueError,match='Scale checks'):expand_choices(r,g)


def test_landmarks_fit_and_collinearity(tmp_path):
    x=np.array([[0,0],[5,0],[0,5],[5,5]])
    y=x@np.array([[9,1],[-1,8]]).T+[3,4]
    p=write_csv(tmp_path/'lm.csv',[dict(zip(['source_x','source_y','reference_x','reference_y'],[*a,*b])) for a,b in zip(x,y)])
    m,report=fit_landmarks(p);np.testing.assert_allclose(m,[[9,1,3],[-1,8,4],[0,0,1]],atol=1e-12)
    assert report['max_fit_residual_px']<1e-12
    write_csv(p,[{'source_x':i,'source_y':i,'reference_x':i,'reference_y':i} for i in range(3)])
    with pytest.raises(ValueError,match='collinear'):fit_landmarks(p)


def test_area_equal_weight_statistics():
    image=np.array([[1,3],[5,7]],float)
    r=summarize_footprints(image,[[.5,.5]],source_to_fullres=np.eye(3),bin_basis_fullres=np.diag([2,2]),methods=['mean','median','sum','min','max'])
    for k,v in {'mean':4,'median':4,'sum':16,'min':1,'max':7,'valid_fraction':1,'n_valid_pixels':4}.items():assert r[k][0]==pytest.approx(v)


def test_coarse_pixel_fractional_sum_conserved():
    img=np.array([[8.]])
    xy=[[-.25,-.25],[.25,-.25],[-.25,.25],[.25,.25]]
    r=summarize_footprints(img,xy,source_to_fullres=np.eye(3),bin_basis_fullres=np.diag([.5,.5]),methods=['mean','sum','median'])
    np.testing.assert_allclose(r['mean'],8);np.testing.assert_allclose(r['sum'],2);assert r['sum'].sum()==8
    np.testing.assert_allclose(r['median'],8)


def test_partial_nan_outside_are_not_zero():
    image=np.array([[2,np.nan],[4,6]],float)
    r=summarize_footprints(image,[[.5,.5],[999,999]],source_to_fullres=np.eye(3),bin_basis_fullres=np.diag([2,2]),methods=['mean','sum','median','min','max'])
    assert r['mean'][0]==4 and r['median'][0]==4 and r['sum'][0]==12 and r['valid_fraction'][0]==.75
    assert np.isnan(r['sum'][1]) and not r['valid'][1]
    s=summarize_footprints(image,[[.5,.5]],source_to_fullres=np.eye(3),bin_basis_fullres=np.diag([2,2]),methods=['mean'],min_valid_fraction=1)
    assert not s['valid'][0] and np.isnan(s['mean'][0])


def test_weighted_median_unequal_weights():
    im=np.array([[2.,10.]])
    # footprint [-.5,.75] includes 100% of pixel0 and 25% of pixel1
    r=summarize_footprints(im,[[.125,0]],source_to_fullres=np.eye(3),bin_basis_fullres=np.diag([1.25,1]),methods=['median','mean','sum'])
    assert r['median'][0]==2 and r['mean'][0]==3.6 and r['sum'][0]==4.5


@pytest.mark.parametrize('theta',[0,.1,.7,1.57])
def test_rotated_footprints_against_independent_bruteforce(theta):
    from shapely.geometry import Polygon,box
    im=np.arange(36).reshape(6,6).astype(float)
    b=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])*1.4
    xy=np.array([[.3,.8],[2.1,3.3],[5.4,5.2]])
    r=summarize_footprints(im,xy,source_to_fullres=np.eye(3),bin_basis_fullres=b,methods=['mean','sum'],chunk_size=1,tile_size=2)
    off=np.array([[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]])@b.T
    for i,q in enumerate(xy):
        p=Polygon(q+off);weights=np.array([[p.intersection(box(x-.5,y-.5,x+.5,y+.5)).area for x in range(6)] for y in range(6)])
        assert r['sum'][i]==pytest.approx((im*weights).sum(),abs=1e-10)
        assert r['mean'][i]==pytest.approx((im*weights).sum()/weights.sum(),abs=1e-10)


def test_explicit_coverage_polygon():
    from shapely.geometry import box
    im=np.ones((2,2))*4
    r=summarize_footprints(im,[[.5,.5]],source_to_fullres=np.eye(3),bin_basis_fullres=np.diag([2,2]),methods=['mean','sum'],coverage_source=box(-.5,-.5,.5,1.5))
    assert r['mean'][0]==4 and r['sum'][0]==8 and r['valid_fraction'][0]==.5


def test_area_memory_guard():
    with pytest.raises(ValueError,match='candidate pixels'):
        summarize_footprints(np.ones((10,10)),[[1,1]],source_to_fullres=np.eye(3),bin_basis_fullres=np.diag([100,100]))


def test_cell_max_min_and_boolean_majority():
    obs=pd.DataFrame({'v':[0.,1.,2.,np.nan],'flag':pd.array([True,True,False,pd.NA],dtype='boolean')})
    r=aggregate_annotations(obs,np.array([0,0,1,1]),2,{'continuous':{'v':['max','min']},'boolean':['flag'],'boolean_options':{'flag':{'methods':['majority']}}})
    assert r['geometric__v__max'].tolist()==[1,2] and r['geometric__v__min'].tolist()==[0,2]
    assert r['geometric__flag__dominant'].tolist()==['positive','negative']
    assert r['geometric__v__annotation_coverage'].tolist()==[1,.5]


def test_include_union_and_exclusion_overlap():
    f=pd.DataFrame({'qc_keep':[True]*4,'t1':[True,False,True,False],'t2':[False,True,True,False],'bad':[False,False,True,False]})
    r=segmentation_decisions(f,{'enabled':True,'tissue_columns':['t1','t2'],'exclude_columns':['bad']})
    assert r.segmentation_keep.tolist()==[True,True,False,False]


def test_exact_overlap_transfer_to_obs_with_io_stubs(tmp_path,monkeypatch):
    """Run real XML/category orchestration; only parquet/master persistence is stubbed."""
    import vhd.annotations.workflow as w
    import vhd.io as io
    import vhd.persistence as persistence
    a=source(tmp_path);g={'grid_index_to_fullres':np.eye(3).tolist()};prepare_choices(a,g)
    choices=select(a,g,{'Tissue':{'include_in_obs':'true','qc_use':'include'},'Necrosis':{'include_in_obs':'true','qc_use':'exclude'},
                        'Tumor, region 2':{'include_in_obs':'true','cell_methods':'majority'}})
    work=tmp_path/'work';rep=tmp_path/'rep';work.mkdir();rep.mkdir()
    geom=work/'geometry.json';geom.write_text(json.dumps(g));bo=work/'bins';bo.write_text('unchanged counts')
    paths={'work':work,'report':rep,'geometry':geom,'bin_obs':bo,'store':tmp_path/'s.zarr'}
    (rep/'asset_pathology.json').write_text(json.dumps({'alignment_signature':alignment_signature(a,g)}))
    base=pd.DataFrame({'pxl_col_in_fullres':[1.,5.,6.5,20.],'pxl_row_in_fullres':[1.,5.,6.5,20.],'qc_keep':True},index=list('abcd'))
    monkeypatch.setattr(w,'sample_paths',lambda *args:paths)
    monkeypatch.setattr(pd,'read_parquet',lambda path:base.copy())
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,path:Path(path).write_text(self.to_json()))
    monkeypatch.setattr(io,'table_metadata',lambda *args:(base.copy(),pd.DataFrame()))
    captured={};monkeypatch.setattr(persistence,'update_table_metadata',lambda *args,**kw:captured.update(kw))
    spec={'dataset_id':'Project','sample_id':'A','_row':{'assets_manifest':str(tmp_path/'assets.csv')}}
    r=transfer_assets({'prior_filter':{'mode':'from_review','unknown_policy':'exclude'},'storage_policy':{},'storage':{'single_writer_ack':True}},spec)
    obs=captured['obs'];assert obs.segmentation_keep.tolist()==[True,False,False,False]
    names={x['category']:x['obs_name'] for x in choices}
    assert obs[names['Tissue']].tolist()==[True,False,True,False]
    assert obs[names['Necrosis']].tolist()==[False,True,True,False]
    assert names['Do not use'] not in obs
    assert 'X' not in captured and bo.read_text()=='unchanged counts'
    assert r['transfer_spec']['boolean_options'][names['Tumor, region 2']]['methods']==['majority']


def test_sample_manifest_without_dataset_column(tmp_path):
    from vhd.control.manifest import read_manifest
    source=Path(__file__).resolve().parents[1]/'config/samples.cells_only.example.csv'
    with source.open() as f:r=csv.DictReader(f);heads=[x for x in r.fieldnames if x!='dataset_id'];rows=[{k:v for k,v in x.items() if k!='dataset_id'} for x in r]
    p=write_csv(tmp_path/'samples.csv',rows,heads);parsed=read_manifest(p)
    assert all(r['dataset_id']=='Project' for r in parsed)
    assert parsed[0]['cell_input']==rows[0]['cell_input']


def test_qc_exclusion_requires_assessed_negatives(tmp_path):
    a=source(tmp_path,coverage_mode='positive_only');prepare_choices(a,{})
    select(a,{}, {'Necrosis':{'include_in_obs':'true','qc_use':'exclude'}})
    with pytest.raises(ValueError,match='assessed negative'):expand_choices(a,{})


def test_sample_alias_without_dataset_typing():
    from vhd.control.manifest import resolve_sample_keys
    p={'rows':[{'sample_id':'A','sample_key':'Project__A'},{'sample_id':'B','sample_key':'Project__B'}]}
    assert resolve_sample_keys(p,['A'])==['Project__A']
    p['rows'].append({'sample_id':'A','sample_key':'Other__A'})
    with pytest.raises(ValueError,match='ambiguous'):resolve_sample_keys(p,['A'])


def test_positive_only_ignored_regions_do_not_set_negatives(tmp_path,monkeypatch):
    """Selecting Tissue must not make other source categories an assessed domain."""
    a=source(tmp_path,coverage_mode='positive_only');prepare_choices(a,{})
    select(a,{}, {'Tissue':{'include_in_obs':'true'}})
    items=expand_choices(a,{})
    from vhd.annotations.workflow import polygons
    from vhd.annotations.geometry import classify_polygons
    full=polygons(a);g=full[full.name.isin(items[0]['categories'])]
    r=classify_polygons([[5,5]],g,categories=items[0]['categories'],coverage=shapely.union_all(g.geometry))
    assert pd.isna(r.Tissue.iloc[0]) # hole is not "negative" because an ignored class fills it


def test_three_valued_union_of_positive_only_tissue_categories():
    obs=pd.DataFrame({'qc_keep':[True]*4,
        'tissue_a':pd.array([True,None,None,False],dtype='boolean'),
        'tissue_b':pd.array([None,True,None,False],dtype='boolean'),
        'necrosis':pd.array([False,False,False,False],dtype='boolean')})
    r=segmentation_decisions(obs,{'enabled':True,'tissue_columns':['tissue_a','tissue_b'],'exclude_columns':['necrosis'],'unknown_policy':'exclude'})
    assert r.segmentation_keep.tolist()==[True,True,False,False]
    assert r.pathology_assessed.tolist()==[True,True,False,True]


def test_binary_interpretation_change_invalidates_source_review(tmp_path):
    f=tmp_path/'signal.npy';np.save(f,np.zeros((2,2),np.uint8))
    a=source(tmp_path,'signal',path=str(f),signal_type='binary',positive_value='255',negative_value='0')
    sig=alignment_signature(a,{})
    a['positive_value']=1.
    assert alignment_signature(a,{})!=sig


def test_approval_requires_current_preview_and_accepts_sample_alias(tmp_path,monkeypatch):
    import vhd.annotations.discovery as d
    a=source(tmp_path);g={};prepare_choices(a,g)
    choices=read_choices(a['review_table']);choices[0]['include_in_obs']='true';atomic_choices(a['review_table'],choices)
    report=tmp_path/'reports';report.mkdir()
    row={'dataset_id':'Project','sample_id':'A','sample_key':'Project__A','assets_manifest':str(tmp_path/'assets.csv')}
    project={'rows':[row]}
    monkeypatch.setattr(d,'source_geometry',lambda *args:g)
    monkeypatch.setattr(d,'sample_layout',lambda *args:{'report':report})
    with pytest.raises(RuntimeError,match='before approving'):d.approve_choices(project,{'A':['pathology']},execute=True)
    sig=alignment_signature(a,g)
    (report/'asset_pathology.json').write_text(json.dumps({'status':'stored','alignment_signature':sig,'preview_status':'generated'}))
    result=d.approve_choices(project,{'A':['pathology']},execute=True)
    assert len(result['approved_choices'])==1
    assert len(expand_choices(a,g))==1
    assert all(not x['reviewed_signature'] for x in read_choices(a['review_table']) if x['include_in_obs']=='false')


def test_signal_five_statistics_transfer_to_obs_orchestration(tmp_path,monkeypatch):
    """Real TIFF/affine/footprint computations; only table persistence is stubbed."""
    import tifffile
    import vhd.annotations.workflow as w
    import vhd.io as io
    import vhd.persistence as persistence
    f=tmp_path/'signal.tif';tifffile.imwrite(f,np.array([[1,3],[5,7]],np.float32))
    a=source(tmp_path,'signal',path=str(f));g={'grid_index_to_fullres':[[2,0,.5],[0,2,.5],[0,0,1]]}
    prepare_choices(a,g);select(a,g,{'__signal__':{'include_in_obs':'true','signal_methods':'mean;median;sum;min;max','obs_name':'stain'}})
    work=tmp_path/'work';rep=tmp_path/'rep';work.mkdir();rep.mkdir()
    geom=work/'geometry.json';geom.write_text(json.dumps(g));bo=work/'bins';bo.write_text('unchanged expression source')
    paths={'work':work,'report':rep,'geometry':geom,'bin_obs':bo,'store':tmp_path/'s.zarr'}
    (rep/'asset_signal.json').write_text(json.dumps({'alignment_signature':alignment_signature(a,g)}))
    base=pd.DataFrame({'pxl_col_in_fullres':[.5],'pxl_row_in_fullres':[.5],'qc_keep':True},index=['bin'])
    monkeypatch.setattr(w,'sample_paths',lambda *args:paths)
    monkeypatch.setattr(pd,'read_parquet',lambda path:base.copy())
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,path:Path(path).write_text(self.to_json()))
    monkeypatch.setattr(io,'table_metadata',lambda *args:(base.copy(),pd.DataFrame()))
    captured={};monkeypatch.setattr(persistence,'update_table_metadata',lambda *args,**kw:captured.update(kw))
    spec={'dataset_id':'Project','sample_id':'A','_row':{'assets_manifest':str(tmp_path/'assets.csv')}}
    record=w.transfer_assets({'prior_filter':{'mode':'from_review'},'annotations':{},'storage_policy':{},'storage':{'single_writer_ack':True}},spec)
    for k,v in {'mean':4,'median':4,'sum':16,'min':1,'max':7}.items():assert captured['obs']['stain__'+k].iloc[0]==v
    assert captured['obs']['stain__valid_fraction'].iloc[0]==1
    assert 'X' not in captured and bo.read_text()=='unchanged expression source'


def test_reserved_category_name_transfers_without_losing_coverage(tmp_path,monkeypatch):
    import vhd.annotations.workflow as w
    import vhd.io as io
    import vhd.persistence as persistence
    a=source(tmp_path)
    path=Path(a['path']);path.write_text(path.read_text().replace('Name="Tissue"','Name="assessed"'))
    g={'grid_index_to_fullres':np.eye(3).tolist()};prepare_choices(a,g)
    select(a,g,{'assessed':{'include_in_obs':'true','obs_name':'chosen_assessed'}})
    work=tmp_path/'work';rep=tmp_path/'rep';work.mkdir();rep.mkdir()
    geom=work/'geometry.json';geom.write_text(json.dumps(g));bo=work/'bins';bo.write_text('source')
    paths={'work':work,'report':rep,'geometry':geom,'bin_obs':bo,'store':tmp_path/'s.zarr'}
    (rep/'asset_pathology.json').write_text(json.dumps({'alignment_signature':alignment_signature(a,g)}))
    base=pd.DataFrame({'pxl_col_in_fullres':[1.,20.],'pxl_row_in_fullres':[1.,20.],'qc_keep':True},index=['b1','b2'])
    monkeypatch.setattr(w,'sample_paths',lambda *args:paths)
    monkeypatch.setattr(pd,'read_parquet',lambda path:base.copy())
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,path:Path(path).write_text(self.to_json()))
    monkeypatch.setattr(io,'table_metadata',lambda *args:(base.copy(),pd.DataFrame()))
    captured={};monkeypatch.setattr(persistence,'update_table_metadata',lambda *args,**kw:captured.update(kw))
    spec={'dataset_id':'Project','sample_id':'A','_row':{'assets_manifest':str(tmp_path/'assets.csv')}}
    w.transfer_assets({'prior_filter':{'mode':'from_review'},'storage_policy':{},'storage':{'single_writer_ack':True}},spec)
    assert captured['obs'].chosen_assessed.tolist()==[True,False]
    assert captured['obs'].chosen_assessed__assessed.tolist()==[True,True]
