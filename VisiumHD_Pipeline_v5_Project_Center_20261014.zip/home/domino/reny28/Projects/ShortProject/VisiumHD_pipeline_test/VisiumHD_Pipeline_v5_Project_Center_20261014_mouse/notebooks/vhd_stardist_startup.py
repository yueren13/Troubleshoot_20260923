"""Bounded StarDist startup check + scoped launcher adaptation, not a scientific patch.

Designed for the v5 source supplied in VHD_StarDist_diagnostic.zip.
- Does not import TensorFlow/StarDist into the notebook process.
- Does not install packages or edit vhd source/configuration/state.
- Cache warm-up writes only private runtime caches and diagnostic logs.
- run_stardist() uses the existing controller for exactly one action.
- Native preflight validation remains enabled; its deadline is extended only
  for the StarDist module list. The shared Matplotlib cache applies only to
  this sample's preflight_stardist and stardist environments during this call.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import functools
import hashlib
import importlib
import inspect
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid

_VERSION = 'vhd-stardist-startup-1'
_EXPECTED = {
    'vhd/compute/runtime_checks.py': '41c84fb79ea837051c475e7aa046fe8302e49bf4e3729fe3c94434ce260dc7d5',
    'vhd/compute/launch.py': '2d900627733496d2dcb00d92339eefce6d35f3cf4f51d1b766af0962ad20b973',
}
_SAFE_ENV_KEYS = ('MPLCONFIGDIR', 'MPLBACKEND', 'CUDA_VISIBLE_DEVICES', 'XDG_CACHE_HOME',
                  'KERAS_HOME', 'TMPDIR', 'OMP_NUM_THREADS', 'TF_NUM_INTRAOP_THREADS')
_ACTIVE = False

# Executed ONLY in the configured worker Python. No image, matrix, model-weight
# loading, or pipeline action. Stack dumps diagnose slow imports; they do not exit.
_PROBE = r'''
import faulthandler, importlib, json, os, sys, time
faulthandler.enable()
faulthandler.dump_traceback_later(60, repeat=True, exit=False)
started=time.monotonic()
report={'runtime': {'executable':sys.executable, 'prefix':sys.prefix,
                   'base_prefix':sys.base_prefix}, 'timings':[], 'versions':{}}
def timed_import(name):
    t=time.monotonic(); print('BEGIN_IMPORT '+name, flush=True)
    obj=importlib.import_module(name)
    elapsed=time.monotonic()-t
    report['timings'].append({'module':name,'seconds':elapsed})
    version=getattr(obj,'__version__',None)
    if isinstance(version,(str,int,float)): report['versions'][name]=str(version)
    print('END_IMPORT '+name+' '+format(elapsed,'.2f')+' seconds', flush=True)
    return obj
try:
    print('STARTUP_RUNTIME '+json.dumps(report['runtime']),flush=True)
    print('MPLCONFIGDIR '+os.environ.get('MPLCONFIGDIR','<unset>'),flush=True)
    # Deliberately separate font initialization from TensorFlow/Keras imports.
    mpl=timed_import('matplotlib')
    timed_import('matplotlib.font_manager')
    report['matplotlib_cache_used']=mpl.get_cachedir()
    for name in json.loads(sys.argv[1]): timed_import(name)
    # Match imports used by the actual inference function without loading weights.
    timed_import('stardist.models')
    timed_import('csbdeep.utils')
    tf=sys.modules['tensorflow']
    print('BEGIN_GPU_ENUMERATION',flush=True)
    t=time.monotonic(); devices=tf.config.list_physical_devices('GPU')
    report['visible_tensorflow_gpus']=[str(d) for d in devices]
    report['gpu_enumeration_seconds']=time.monotonic()-t
    print('END_GPU_ENUMERATION '+json.dumps(report['visible_tensorflow_gpus']),flush=True)
    if json.loads(sys.argv[2]) and not devices:
        raise RuntimeError('Imports passed, but TensorFlow reports no GPU in the configured worker environment.')
    report.update(status='passed', elapsed_seconds=time.monotonic()-started,
                  model_downloaded=False, inference_tested=False, scientific_data_read=False)
    print('STARTUP_RESULT '+json.dumps(report),flush=True)
finally:
    faulthandler.cancel_dump_traceback_later()
'''


def _json_digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,default=str).encode()).hexdigest()


def _write_json(path, value):
    path=Path(path); tmp=path.with_name(path.name+'.tmp-'+uuid.uuid4().hex)
    tmp.write_text(json.dumps(value,indent=2,default=str)+'\n')
    os.replace(tmp,path)


def _native():
    launch=importlib.import_module('vhd.compute.launch')
    checks=importlib.import_module('vhd.compute.runtime_checks')
    root=Path(launch.PACKAGE_ROOT).resolve()
    actual={}
    for relative, expected in _EXPECTED.items():
        path=root/relative
        actual[relative]=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual[relative]!=expected:
            raise RuntimeError(f'Installed source differs from the reviewed version: {path}. '
                               'Do not force the adapter; inspect this version first.')
    if not inspect.isfunction(launch.worker_env) or launch.worker_env.__module__!='vhd.compute.launch':
        raise RuntimeError('worker_env is already adapted. Restore that adaptation first.')
    if not inspect.isfunction(checks.preflight_python) or checks.preflight_python.__module__!='vhd.compute.runtime_checks':
        raise RuntimeError('preflight_python is already adapted. Restore that adaptation first.')
    if hasattr(launch.worker_env,'__wrapped__') or hasattr(checks.preflight_python,'__wrapped__'):
        raise RuntimeError('A launcher wrapper is already active; do not stack adaptations.')
    if 'timeout' not in inspect.signature(checks.preflight_python).parameters:
        raise RuntimeError('Native preflight does not expose the reviewed timeout argument.')
    if Path(inspect.getfile(checks.preflight_python)).resolve()!=root/'vhd/compute/runtime_checks.py':
        raise RuntimeError('Loaded runtime-check function is not from the reviewed package root.')
    if Path(inspect.getfile(launch.worker_env)).resolve()!=root/'vhd/compute/launch.py':
        raise RuntimeError('Loaded environment function is not from the reviewed package root.')
    return launch,checks,root,actual


def _state(controller, sample):
    if not callable(getattr(controller,'snapshot',None)):
        raise TypeError('Pass the existing ProjectCenter object, normally pc; do not create a second controller.')
    state=controller.snapshot()
    active=[]
    for kind in ('jobs','group_jobs'):
        for key,jobs in state.get(kind,{}).items():
            for action,job in jobs.items():
                if job.get('status')=='running': active.append(f'{kind}/{key}/{action}')
    if active: raise RuntimeError('Another controller operation is recorded as running: '+', '.join(active))
    rows=[r for r in state['project']['rows'] if r['sample_key']==sample]
    if len(rows)!=1: raise KeyError(f'Expected one exact sample_key: {sample!r}')
    return state,rows[0]


def _context_fingerprint(state,sample):
    return _json_digest({'project':state['project'],'resource_limits':state.get('resource_limits',{}),
                         'managed_hashes':state.get('managed_hashes',{}),'sample':sample})


def _private_dir(path):
    path=Path(path).expanduser().absolute()
    if path.is_symlink(): raise ValueError(f'Use a direct private cache directory, not a symlink: {path}')
    path.mkdir(mode=0o700,parents=True,exist_ok=True)
    if not path.is_dir() or path.stat().st_uid!=os.getuid():
        raise PermissionError(f'Runtime cache must be a directory owned by the current user: {path}')
    # Do not chmod pre-existing paths. File creation, rather than os.access alone,
    # confirms write permission on mounted filesystems.
    probe=path/('.write-test-'+uuid.uuid4().hex)
    fd=os.open(probe,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    os.close(fd);probe.unlink()
    return path


def _check_cache_location(path,package,controller,state):
    candidate=Path(path).expanduser().absolute().resolve(strict=False)
    forbidden=[package.resolve()]
    if getattr(controller,'workspace',None) is not None:
        forbidden.append((Path(controller.workspace)/'engine').resolve())
    layout=importlib.import_module('vhd.control.manifest').sample_layout
    for row in state['project']['rows']:
        forbidden.append(Path(layout(state['project'],row)['store']).resolve())
    for root in forbidden:
        if candidate==root or root in candidate.parents:
            raise ValueError(f'Cache must be outside package source, managed engine, and masters: {candidate}')


def _cache_env(env, cache):
    new=dict(env); new['MPLCONFIGDIR']=str(cache)
    # Other settings, including GPU IDs, threads, model caches and PYTHONPATH,
    # are retained from the original worker_env, not reconstructed here.
    return new


def _stop_own_probe(proc):
    """Only called for a process started by this helper, never an existing worker."""
    if proc.poll() is not None: return
    try: os.killpg(proc.pid,signal.SIGTERM)
    except ProcessLookupError: pass
    try: proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try: os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError: pass
        proc.wait(timeout=10)


def _run_bounded(command,env,cwd,log,timeout_seconds):
    """Stream an import-only subprocess, retaining the full diagnostic output."""
    if os.name!='posix': raise RuntimeError('This helper targets the reviewed Linux environment.')
    log=Path(log); start=time.monotonic(); proc=None
    with log.open('xb',buffering=0) as output:
        try:
            proc=subprocess.Popen(command,env=env,cwd=cwd,stdout=output,
                                  stderr=subprocess.STDOUT,start_new_session=True)
            print(f'Import-test subprocess PID: {proc.pid}; log: {log}',flush=True)
            with log.open('r',encoding='utf-8',errors='replace') as tail:
                while True:
                    chunk=tail.read()
                    if chunk: print(chunk,end='',flush=True)
                    if proc.poll() is not None:
                        chunk=tail.read()
                        if chunk: print(chunk,end='',flush=True)
                        break
                    if time.monotonic()-start>=timeout_seconds:
                        raise TimeoutError(f'Import test exceeded {timeout_seconds:g} seconds. '
                                           f'Inspect BEGIN/END_IMPORT and stack dumps in {log}; no sample jobs were launched.')
                    time.sleep(0.25)
        except BaseException:
            if proc is not None: _stop_own_probe(proc)
            raise
    if proc.returncode:
        raise RuntimeError(f'Import/GPU-enumeration test exited {proc.returncode}. '
                           f'Full log: {log}. No sample jobs were launched.')
    return time.monotonic()-start


def prepare(controller, *, sample, cache_root, timeout_seconds=900,
            confirmed_no_other_launchers=False):
    """Warm the shared plot cache and test the selected Python in a child process.

    This writes runtime caches/logs, and imports TensorFlow plus enumerates GPUs
    ONLY in the child. It does not fit, load pretrained weights, read scientific
    arrays, or alter controller records. No package installation is performed.
    The explicit cache_root is user-approved runtime storage; filesystem locality
    is not inferred from its name. Use a writable, genuinely fast project path.
    """
    if not confirmed_no_other_launchers:
        raise PermissionError('Confirm no competing launcher is using this kernel/GPU before running the import test.')
    if isinstance(timeout_seconds,bool) or not math.isfinite(float(timeout_seconds)) or not 180<=float(timeout_seconds)<=3600:
        raise ValueError('Use an explicit bounded startup timeout between 180 and 3600 seconds.')
    launch,checks,package,hashes=_native()
    state,row=_state(controller,sample)
    resources=importlib.import_module('vhd.center.resources')
    runtime,hardware=resources.runtime_project(deepcopy(state['project']),state.get('resource_limits',{}))
    execution=runtime['settings']['execution']; gpu_ids=execution['gpu_ids'][:1]
    if not gpu_ids: raise RuntimeError('No eligible GPU is available to the configured StarDist launch. Check Resources / Reports.')
    runtime_row=next(r for r in runtime['rows'] if r['sample_key']==sample)
    paths=launch.sample_layout(runtime,runtime_row)
    threads=int(execution['stardist']['threads_per_worker'])
    exe=str(execution['python_stardist'])  # NEVER resolve a venv interpreter symlink.
    if not Path(exe).is_file() or not os.access(exe,os.X_OK): raise FileNotFoundError(exe)
    _check_cache_location(cache_root,package,controller,state)
    root=_private_dir(cache_root)
    cache=_private_dir(root/('mpl_'+hashlib.sha256(exe.encode()).hexdigest()[:12]))
    evidence=_private_dir(root/'checks'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]))
    probe_tmp=paths['scratch']/'runtime'/'preflight_stardist'
    worker_tmp=paths['scratch']/'runtime'/'stardist'
    env=launch.worker_env(probe_tmp,gpu_ids,threads)
    for original_cache in (Path(env['MPLCONFIGDIR']),worker_tmp/'mplconfigdir'):
        if original_cache.resolve()!=cache.resolve() and (original_cache/'matplotlibrc').exists():
            raise RuntimeError(f'A custom matplotlibrc exists at {original_cache}. '
                               'Review its preservation before redirecting the cache.')
    env=_cache_env(env,cache)
    modules=checks.action_imports('stardist')
    cfg,_=importlib.import_module('vhd.control.manifest').row_config(runtime,runtime_row)
    require_gpu=bool(cfg['stardist'].get('require_gpu',True))
    receipt={'schema':_VERSION,'status':'checking','sample':sample,
             'package_root':str(package),'source_sha256':hashes,'python':exe,
             'context_fingerprint':_context_fingerprint(state,sample),
             'timeout_seconds':float(timeout_seconds),'cache_dir':str(cache),
             'probe_tmp':str(probe_tmp),'worker_tmp':str(worker_tmp),
             'evidence_dir':str(evidence),'modules':modules,
             'environment':{k:env.get(k) for k in _SAFE_ENV_KEYS},
             'selected_gpu_not_reserved':gpu_ids,
             'scientific_data_read':False,'model_inference_tested':False,
             'project_configuration_modified':False,'source_files_modified':False}
    _write_json(evidence/'startup_receipt.json',receipt)
    print('Selected worker Python:',exe,flush=True)
    print('Selected GPU (not reserved):',gpu_ids,flush=True)
    print('Shared Matplotlib cache:',cache,flush=True)
    print('No model weights or scientific data will be loaded.',flush=True)
    log=evidence/'imports_and_gpu.log'
    command=[exe,'-B','-u','-c',_PROBE,json.dumps(modules),json.dumps(require_gpu)]
    try:
        _run_bounded(command,env,str(package),log,float(timeout_seconds))
        outputs=[line[len('STARTUP_RESULT '):] for line in log.read_text(errors='replace').splitlines()
                 if line.startswith('STARTUP_RESULT ')]
        if len(outputs)!=1: raise RuntimeError(f'No unique completion record in {log}')
        details=json.loads(outputs[0]);prefix=details['runtime']['prefix']
        venv=Path(exe).parent.parent
        if (venv/'pyvenv.cfg').is_file() and not os.path.samefile(prefix,venv):
            raise RuntimeError('The subprocess did not enter the selected virtual environment. Check PYTHONHOME/path.')
        if not os.path.samefile(details['matplotlib_cache_used'],cache):
            raise RuntimeError('Matplotlib did not use the requested shared cache.')
        receipt.update(status='passed',probe_result=details)
    except BaseException as exc:
        receipt.update(status='failed',error=f'{type(exc).__name__}: {exc}',log=str(log))
        _write_json(evidence/'startup_receipt.json',receipt)
        raise
    receipt['log']=str(log)
    _write_json(evidence/'startup_receipt.json',receipt)
    print('\nStartup imports and GPU enumeration passed. Model inference is still untested.',flush=True)
    return receipt


@contextmanager
def _launch_adaptation(launch,checks,receipt):
    """Temporary Python bindings, restored on success, failure, or interruption."""
    global _ACTIVE
    if _ACTIVE: raise RuntimeError('A startup adaptation is already active in this kernel.')
    old_env,old_preflight=launch.worker_env,checks.preflight_python
    allowed={str(Path(receipt['probe_tmp']).absolute()),str(Path(receipt['worker_tmp']).absolute())}
    preflight_path=str(Path(receipt['probe_tmp']).absolute())
    cache=Path(receipt['cache_dir'])
    counts={'worker_env_calls':0,'preflight_calls':0}
    @functools.wraps(old_env)
    def patched_env(tmp,gpus,threads):
        result=old_env(tmp,gpus,threads)
        if str(Path(tmp).absolute()) in allowed:
            counts['worker_env_calls']+=1
            result=_cache_env(result,cache)
        return result
    @functools.wraps(old_preflight)
    def patched_preflight(executable,modules,*,env=None,cwd=None,timeout=180):
        names=list(modules)
        matching=(str(executable)==receipt['python'] and 'tensorflow' in names and 'stardist' in names
                  and env is not None and str(env.get('TMPDIR'))==preflight_path)
        if matching:
            counts['preflight_calls']+=1
            timeout=receipt['timeout_seconds']
            env=_cache_env(env,cache)
            print(f'StarDist native import deadline: {timeout:g} seconds; checks remain enabled.',flush=True)
        return old_preflight(executable,names,env=env,cwd=cwd,timeout=timeout)
    _ACTIVE=True
    launch.worker_env=patched_env;checks.preflight_python=patched_preflight
    try: yield counts
    finally:
        launch.worker_env=old_env;checks.preflight_python=old_preflight;_ACTIVE=False


def run_stardist(controller, receipt, *, confirmed=False):
    """Execute only the ready StarDist step through the unchanged controller.

    Scientific execution WILL occur if preflight and input checks pass.
    Do not simultaneously click UI Run or use another controller/launcher.
    This does not install a permanent UI override; later plain UI launches use
    the original source and cache behavior. Reuse this helper after restarting.
    """
    if not confirmed: raise PermissionError('Set confirmed=True to authorize this one StarDist action.')
    if receipt.get('schema')!=_VERSION or receipt.get('status')!='passed':
        raise ValueError('A successful prepare() receipt is required; do not bypass a failed import/GPU check.')
    launch,checks,package,hashes=_native()
    state,_=_state(controller,receipt['sample'])
    if _context_fingerprint(state,receipt['sample'])!=receipt['context_fingerprint']:
        raise RuntimeError('Project, input signatures, executable settings or resource caps changed. Run prepare() again.')
    if str(package)!=receipt['package_root'] or hashes!=receipt['source_sha256']:
        raise RuntimeError('Package changed since startup preparation.')
    ready=[r for r in controller.plan([receipt['sample']]) if r.get('status')=='ready']
    if not ready or ready[0].get('action')!='stardist':
        raise RuntimeError('The next ready action is not StarDist. Inspect the route; this helper will not run another step.')
    if not Path(receipt['cache_dir']).is_dir(): raise FileNotFoundError(receipt['cache_dir'])
    run_dir=Path(receipt['evidence_dir'])/('launch_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8])
    run_dir.mkdir()
    audit={'schema':_VERSION,'sample':receipt['sample'],'started_utc':datetime.now(timezone.utc).isoformat(),
           'cache_dir':receipt['cache_dir'],'preflight_timeout_seconds':receipt['timeout_seconds'],
           'changes':'Temporary StarDist-only launcher env/deadline wrappers; source/config unchanged.'}
    _write_json(run_dir/'launch.json',audit)
    try:
        with _launch_adaptation(launch,checks,receipt) as counts:
            result=controller.run_until_review([receipt['sample']],confirmed=True,max_actions=1)
        job=controller.snapshot().get('jobs',{}).get(receipt['sample'],{}).get('stardist',{})
        audit.update(status='controller_returned',events=result,job=job,adapter_calls=counts)
        print('Controller result:\n'+json.dumps(result,indent=2,default=str),flush=True)
        print('StarDist job:\n'+json.dumps(job,indent=2,default=str),flush=True)
        if job.get('status')=='failed':
            raise RuntimeError('StarDist controller recorded a failure. Its full error is printed above. '
                               'Do not reset or mark complete; inspect that new error.')
        return result
    except BaseException as exc:
        audit.update(status='error',error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        audit['finished_utc']=datetime.now(timezone.utc).isoformat()
        audit['launcher_bindings_restored']=True
        _write_json(run_dir/'launch.json',audit)
        print('Original in-memory launcher functions restored. Audit:',run_dir/'launch.json',flush=True)
