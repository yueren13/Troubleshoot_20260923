"""Coverage-aware bin-center metadata summaries; these are not molecule assignments."""
import numpy as np
import pandas as pd


def aggregate_annotations(obs,assignment,n_cells,spec):
    a=np.asarray(assignment)
    if a.ndim!=1 or len(a)!=len(obs) or not np.issubdtype(a.dtype,np.integer) or (a>=n_cells).any() or (a< -2).any():raise ValueError('Invalid bin-to-cell assignments.')
    valid=a>=0;counts=np.bincount(a[valid],minlength=n_cells);out=pd.DataFrame({'geometric_n_bins':counts})
    cs=spec.get('categorical',{})
    if isinstance(cs,list):cs={c:{} for c in cs}
    for col,opt in cs.items():
        s=obs[col].astype('string');s=s.mask(s.isin(opt.get('missing_values',['unassessed','missing'])))
        cats=list(opt.get('categories') or sorted(s.dropna().unique()))
        if len(cats)>spec.get('max_categories',30) or len(cats)!=len(set(cats)) or set(s.dropna().unique())-set(cats):raise ValueError(f'Invalid category universe: {col}')
        matrix=np.zeros((n_cells,len(cats)),np.int64)
        for i,c in enumerate(cats):
            mask=valid&s.eq(c).fillna(False).to_numpy(bool);matrix[:,i]=np.bincount(a[mask],minlength=n_cells)
        den=matrix.sum(axis=1);has=den>0;prefix=f'geometric__{col}__'
        out[prefix+'n_valid_bins']=den;out[prefix+'annotation_coverage']=np.divide(den,counts,out=np.full(n_cells,np.nan),where=counts>0)
        for i,c in enumerate(cats):
            key=prefix+'fraction__'+''.join(x if x.isalnum() or x in '_-' else '_' for x in str(c))
            if key in out:raise ValueError('Category names collide after column normalization.')
            out[key]=np.divide(matrix[:,i],den,out=np.full(n_cells,np.nan),where=has)
        major=np.full(n_cells,'missing',object);fraction=np.full(n_cells,np.nan);ties=np.zeros(n_cells,bool)
        if cats:
            maximum=matrix.max(axis=1);major[has]=np.asarray(cats)[matrix.argmax(axis=1)[has]]
            ties=has&((matrix==maximum[:,None]).sum(axis=1)>1);major[ties]=opt.get('tie_label','mixed')
            fraction=np.divide(maximum,den,out=np.full(n_cells,np.nan),where=has)
        out[prefix+'dominant']=pd.Categorical(major);out[prefix+'dominant_fraction']=fraction;out[prefix+'is_tie']=ties
    for col in spec.get('boolean',[]):
        s=obs[col]
        if not pd.api.types.is_bool_dtype(s):raise ValueError(f'{col} must be a real boolean dtype.')
        ok=valid&s.notna().to_numpy();den=np.bincount(a[ok],minlength=n_cells)
        num=np.bincount(a[ok],weights=s[ok].astype(float),minlength=n_cells);prefix=f'geometric__{col}__'
        out[prefix+'fraction_true']=np.divide(num,den,out=np.full(n_cells,np.nan),where=den>0)
        out[prefix+'n_valid_bins']=den;out[prefix+'annotation_coverage']=np.divide(den,counts,out=np.full(n_cells,np.nan),where=counts>0)
        if 'majority' in spec.get('boolean_options',{}).get(col,{}).get('methods',[]):
            fraction=out[prefix+'fraction_true'].to_numpy();labels=np.full(n_cells,'missing',object)
            labels[(den>0)&(fraction>.5)]='positive';labels[(den>0)&(fraction<.5)]='negative';labels[(den>0)&(fraction==.5)]='mixed'
            out[prefix+'dominant']=pd.Categorical(labels);out[prefix+'dominant_fraction']=np.where(den>0,np.maximum(fraction,1-fraction),np.nan)
    for col,modes in spec.get('continuous',{}).items():
        modes=[modes] if isinstance(modes,str) else list(modes)
        if set(modes)-{'sum','mean','median','max','min'}:raise ValueError('Continuous modes: sum, mean, median, max, min.')
        x=pd.to_numeric(obs[col],errors='raise').to_numpy(dtype=float,na_value=np.nan)
        if np.isinf(x).any():raise ValueError('Infinite signal value; fix the source.')
        group=pd.DataFrame({'cell':a[valid],'value':x[valid]}).groupby('cell')['value'];den=group.count().reindex(range(n_cells),fill_value=0).to_numpy();prefix=f'geometric__{col}__'
        out[prefix+'n_valid_bins']=den;out[prefix+'annotation_coverage']=np.divide(den,counts,out=np.full(n_cells,np.nan),where=counts>0)
        for m in modes:
            values=group.sum(min_count=1) if m=='sum' else getattr(group,m)()
            out[prefix+m]=values.reindex(range(n_cells)).to_numpy()
    return out


def segmentation_decisions(obs,settings):
    base=obs.qc_keep.to_numpy(bool);out=pd.DataFrame(index=obs.index);out['base_bin_qc_keep']=base
    if not settings.get('enabled',False):
        out['pathology_assessed']=True;out['pathology_excluded']=False;out['segmentation_keep']=base
        out['segmentation_exclusion_reason']=np.where(base,'retained','base_qc');return out
    tissues=settings.get('tissue_columns') or ([settings['tissue_column']] if settings.get('tissue_column') else []);exclude=settings.get('exclude_columns',[])
    tissue=bool(tissues)
    if not tissue and not exclude:raise ValueError('Specify tissue and/or exclusion flags.')
    def union_state(columns, empty_value):
        # Three-valued OR: a known positive proves membership even when another
        # independently drawn category is unassessed at the same location.
        positive=np.zeros(len(obs),bool);all_known=np.ones(len(obs),bool)
        for col in columns:
            series=obs[col]
            if not pd.api.types.is_bool_dtype(series):raise ValueError('Pathology decisions require Boolean memberships, not strings.')
            positive |= series.fillna(False).to_numpy(bool)
            all_known &= series.notna().to_numpy()
        if not columns:return np.full(len(obs),empty_value,bool),np.ones(len(obs),bool)
        return positive,positive|all_known
    inside,tissue_known=union_state(tissues,True)
    bad,exclusion_known=union_state(exclude,False)
    known=tissue_known & exclusion_known
    policy=settings.get('unknown_policy','exclude')
    if policy not in ('exclude','keep_base'):raise ValueError('unknown_policy: exclude or keep_base.')
    keep=base&inside&~bad
    if policy=='exclude':keep &= known
    else:keep[~known]=base[~known]&~bad[~known]
    out['pathology_assessed']=known;out['pathology_excluded']=bad;out['segmentation_keep']=keep
    out['segmentation_exclusion_reason']=np.where(~base,'base_qc',np.where(bad,'pathology_exclusion',np.where(~known,'unknown_pathology',np.where(~inside,'outside_tissue','retained'))))
    return out


def gate_pathology(mask,xy,obs,output,settings):
    from ..segmentation import gate_prior
    keep=obs.segmentation_keep.to_numpy(bool)
    audit=gate_prior(mask,xy,keep,output,settings.get('minimum_support_bins',1))
    uv=np.asarray(xy);finite=np.isfinite(uv).all(axis=1);rc=np.zeros_like(uv,dtype=np.int64);rc[finite]=np.rint(uv[finite,::-1]).astype(np.int64)
    valid=finite&(rc[:,0]>=0)&(rc[:,0]<mask.shape[0])&(rc[:,1]>=0)&(rc[:,1]<mask.shape[1])
    labels=np.zeros(len(rc),np.int64);labels[valid]=mask[rc[valid,0],rc[valid,1]];n=int(mask.max())
    den=np.bincount(labels[valid],minlength=n+1);num=np.bincount(labels[valid&~keep],minlength=n+1)
    fraction=np.divide(num,den,out=np.full(n+1,np.nan),where=den>0)
    audit['excluded_bin_center_fraction']=fraction[1:];limit=settings.get('max_excluded_bin_fraction')
    if limit is not None:
        if not np.isfinite(limit) or not 0<=limit<=1:raise ValueError('max_excluded_bin_fraction must be in [0,1].')
        retain=audit.retain_for_proseg.to_numpy()&(fraction[1:]<=limit);lut=np.zeros(n+1,np.uint32)
        lut[np.flatnonzero(retain)+1]=np.arange(1,retain.sum()+1,dtype=np.uint32)
        out=np.load(output,mmap_mode='r+')
        for y in range(0,mask.shape[0],256):out[y:y+256]=lut[mask[y:y+256]]
        out.flush();audit['clean_label_id']=lut[1:];audit['retain_for_proseg']=retain
    audit['decision_measure']='sampled_bin_centers_not_polygon_area'
    return audit
