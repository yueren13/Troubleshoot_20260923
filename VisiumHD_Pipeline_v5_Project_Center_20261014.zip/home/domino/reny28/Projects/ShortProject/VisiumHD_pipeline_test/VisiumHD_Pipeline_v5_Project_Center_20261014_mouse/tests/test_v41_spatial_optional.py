"""Actual new signal-to-obs metadata roundtrip; module skip is not a passing test."""
import json,csv
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ad=pytest.importorskip('anndata');sd=pytest.importorskip('spatialdata');pytest.importorskip('zarr');pytest.importorskip('pyarrow')
from scipy import sparse
import geopandas as gpd
from shapely.geometry import box
from spatialdata.models import ShapesModel
from spatialdata.transformations import Identity
from vhd.storage import parse_table
from vhd.annotations.workflow import read_assets,alignment_signature,transfer_assets
from vhd.annotations.alignment import resolve_alignment
from vhd.annotations.discovery import discover_one,atomic_choices,choice_signature
from vhd.persistence.transaction import inventory


def test_real_signal_obs_roundtrip_no_count_rewrite(tmp_path):
    work=tmp_path/'work';report=tmp_path/'reports';work.mkdir();report.mkdir();store=tmp_path/'master.zarr'
    obs=pd.DataFrame({'pxl_col_in_fullres':[.5],'pxl_row_in_fullres':[.5],'qc_keep':[True]},index=['b1'])
    a=ad.AnnData(sparse.csr_matrix([[3,7]],dtype=np.int32),obs=obs.copy());a.obsm['spatial']=np.array([[.5,.5]])
    polygons=gpd.GeoDataFrame(geometry=[box(-.5,-.5,1.5,1.5)],index=['b1'])
    s=sd.SpatialData(shapes={'bins':ShapesModel.parse(polygons,transformations={'fullres':Identity()})},tables={'bins_2um':parse_table(a,'bins',a.obs_names)})
    s.write(store);before=inventory(store/'tables/bins_2um/X')
    sigfile=tmp_path/'signal.npy';np.save(sigfile,np.array([[1.,3.],[5.,7.]],np.float32))
    raw={'sample_id':'A','asset_id':'signal','kind':'signal','path':str(sigfile),'source_to_fullres':'1;0;0;0;1;0','axes':'yx'}
    manifest=tmp_path/'assets.csv'
    with manifest.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(raw));w.writeheader();w.writerow(raw)
    geometry={'grid_index_to_fullres':np.diag([2,2,1]).tolist()}
    (work/'geometry.json').write_text(json.dumps(geometry));obs.to_parquet(work/'bins_qc_obs.parquet')
    asset=resolve_alignment(read_assets(manifest,'Project','A')[0],geometry)
    choices,_=discover_one(asset,geometry,'Project__A');r=choices[0]
    r.update(include_in_obs='true',signal_methods='mean;median;sum;min;max',cell_methods='mean')
    r['reviewed_signature']=choice_signature(r,r['source_signature']);atomic_choices(asset['review_table'],choices)
    (report/'asset_signal.json').write_text(json.dumps({'status':'stored','alignment_signature':alignment_signature(asset,geometry)}))
    spec={'dataset_id':'Project','sample_id':'A','_row':{'assets_manifest':str(manifest)},'_paths':{'work':str(work),'report':str(report),'proseg':str(work/'proseg'),'store':str(store)}}
    cfg={'prior_filter':{'mode':'from_review'},'storage':{'single_writer_ack':True},
         'storage_policy':{'approved_master_roots':[str(tmp_path)],'approved_work_roots':[str(tmp_path)],'min_free_master_gib':0}}
    transfer_assets(cfg,spec)
    live=sd.read_zarr(store).tables['bins_2um']
    for field,value in {'signal__mean':4,'signal__median':4,'signal__sum':16,'signal__min':1,'signal__max':7}.items():assert live.obs.loc['b1',field]==pytest.approx(value)
    assert inventory(store/'tables/bins_2um/X')==before
