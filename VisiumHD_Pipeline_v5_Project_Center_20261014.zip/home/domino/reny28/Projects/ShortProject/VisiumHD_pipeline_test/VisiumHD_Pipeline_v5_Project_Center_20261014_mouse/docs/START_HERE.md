# Start here — Visium HD Project Center v5

**Release: 0.5.0rc1, October 9, 2026. Target-environment pilot candidate, not a validated production release.**

This full bundle starts from the supplied patched `VisiumHD_Pipeline_v4_1_1_human.zip`. The existing scientific engine is retained. The normal interface is now one launcher notebook and one persistent Project Center. The original sample/asset sheets become managed copies; they are not edited behind your back.

## The first session for the current human pilot

1. Extract the new folder beside the existing v4.1.1 folder. **Do not overlay it onto the running installation.** Finish/stop old workers before writing to the same stores from the new controller.
2. Open `notebooks/00_Project_Center.ipynb` in the intended scientific kernel. Run its single setup code cell.
3. Choose **Import existing pipeline configuration (current pilot)**. The form normally finds the old sibling folder. Verify the paths to its current `config/samples.csv` and `config/settings.json`. Choose a **new controller workspace**, for example a sibling `VisiumHD_Project_Center` on the local/EBS work drive. Confirm creation of managed copies and click **Open / create Project Center**.
4. Click **Test browser connection** and verify that a timestamp is saved. Then inspect the sample, paths, metadata, route and report tabs. No scientific job starts merely by opening the interface.

For later sessions choose **Open an existing Project Center**, using the same workspace. Do not reimport the original sheets on every session; that would create another independent state.

The original study configuration is also included under `examples/current_human3/config/` as an exact import example. Prefer your **current on-instance files** if they have changed since the upload. These examples contain private deployment paths/sample identifiers; review them before publishing any source to a public repository.

## Live-interface dependency

The selected kernel needs `ipywidgets` 8.x. Existing scientific dependencies remain required for their selected worker roles. No package installation is performed automatically.

Use your approved environment manager to add `ipywidgets>=8,<9` to the kernel. If JupyterLab and the kernel run in different environments, the JupyterLab server also needs `jupyterlab_widgets`. The official Jupyter guide explains the distinction: https://ipywidgets.readthedocs.io/en/stable/user_install.html . Seeing only `VBox(...)` text rather than controls indicates an unavailable widget frontend; it is not a data/QC failure.

Optional `99_Project_Center_Environment_Check.ipynb` inventories packages/resources and runs small tests. The **live browser/comm interaction was not tested in the delivery environment**, where ipywidgets was unavailable. Do not interpret static HTML screenshots as a browser-to-kernel test. The first-session Test browser connection button tests that interaction on your actual instance.

## The page and normal operation

The six tabs are **Overview / Run**, **Bin QC**, **Annotations / Signals**, **Segmentation / Cells**, **Clustering**, and **Resources / Reports**.

- **View** shows existing evidence without approving it.
- **Save** records explicit decisions in managed configuration and state.
- **Run until next review** runs only ready work up to review barriers. It does not approve later stages.
- **Refresh progress / reports** finds known report locations without loading expression matrices or scanning every file in native data stores.

Long operations are synchronous in the notebook kernel. The HTML/state is updated before and after controller actions, not as a background service or live tail of every worker instruction. Jupyter Interrupt stops the submitted operation through its existing worker handling; do not delete output/lock files. A killed kernel can leave a job marked running; the recovery control records your confirmation that it has actually stopped without killing a process or fabricating completion.

The controller's advisory lock serializes participating operations. It does not detect all external notebooks/viewers. Continue to avoid simultaneous access to the same mutable master. The state filesystem must support `flock`, `fsync`, and same-directory atomic replacement. No mount, cgroup, device-reset or unrelated-process operation is performed.

## Resume your existing results

Importing configuration does not copy H5AD, Zarr, TIFF or SVS files. It preserves their configured paths, sample identities and run ID. Existing output/status files are inventoried as historical evidence, **not automatically certified complete**.

The default route invokes earlier engine actions so their own signature/output checks decide whether to reuse completed results. It should not recompute unchanged, compatible cached products. A user-selected **Resume point** can skip earlier positions after explicit acknowledgement and existence checks; this does not grant an approval or certify skipped steps. Downstream engine guards still apply.

For this three-sample pilot, the input remains `raw`; that describes starting material, not how far the run has progressed. Keep integration groups blank unless joint analysis is deliberately requested.

Scientific cache versions are intentionally unchanged. A cache containing external configuration-file paths can still reject a managed-copy path for an existing-bin/cell import; no override or fake completion is supplied. Such a rejection needs targeted provenance review rather than force-overwriting. The current uploaded human samples have no per-sample override files.

## Your current annotation/stain review — now one Save

Open **Annotations / Signals**, choose the existing opacity-updated gallery, and view it on that tab. Current selections are imported: Tissue inclusion, Anthropotic/Necrosis exclusions, unneeded categories unchecked, stain mean.

On the same panel:

- Keep/edit safe output names and category use.
- Check the explicit coverage interpretation. Separate coverage polygons still have the original bridge's limitations and are not auto-approved.
- For the stain, confirm the expected scale is 4 **only when that same-field-of-view interpretation is correct**.
- Select **Use stored numeric values (no threshold)** when you intend the native continuous staining signal.
- Confirm the shared field of view/orientation after reviewing that overlay.
- Enter your reviewer name, check that you reviewed this gallery, and press **Save reviewed asset usage**.

That operation refreshes discovery as necessary, then applies the form's selections/extent decisions and records approval through the existing evidence validator. It does not make you rerun discovery and re-edit a CSV afterward. Rejected submissions retain a draft and show the cause; an unsuccessful save is not shown as approved.

No `reviewed_signature` or receipt filename is edited manually. Save does not write the master or `.obs`; actual import/transfer occurs when the route runs the transfer step. Geometry repair remains explicit, preserves negative roles and holes, and has an advanced panel on the same page. A previously accepted derivative does not require new repair merely because this controller was added.

## HTML reports

Fixed entry: `<workspace>/html/project_review.html`.

Per sample: `<workspace>/html/samples/<sample_key>/{bin_qc,assets,segmentation,cells,clustering}.html`.

Joint groups: `<workspace>/html/groups/<group>/clustering.html` after a group phase.

The index is small; per-stage pages embed bounded report thumbnails and readable small summary tables. They use existing generated reports; a missing figure is not invented. Historical report paths and explicit observed statuses remain visible in technical details.

Bin distributions can be generated from the Bin QC tab using the retained streaming plotting helper. H&E and classification plots are collected automatically once they exist. Segmentation/cell pages collect prior/Proseg/boundary/QC results as their stages complete. Clustering pages collect every generated resolution plot and its cluster-size tables.

The HTML export is read-only. Live buttons work only in the connected Project Center. To share all current pages, use `setup['center'].export_report('/approved/NEW_report_bundle.zip')` or copy the `html/` folder. A single per-stage HTML embeds its thumbnails. No public server or external data upload is used.

## New studies / sample metadata

Choose **Create a new project from sample and asset sheets**. The sample sheet accepts arbitrary additional metadata columns, preserving text IDs and leading zeros. An optional supplied metadata CSV is joined by an explicitly named sample-ID column, never by row order; conflicting values fail instead of silently winning.

The minimal examples are under `examples/new_project/`. They use illustrative paths, not your data. The selected output root must already exist. In this compact new-study mode, work, scratch, masters and published outputs are organized below it. For separate storage roots/environment/scientific settings, import a reviewed existing full configuration/profile rather than assuming automatic storage-policy inference.

Midway cell inputs still need declared raw-count source, coordinate meaning, and actual boundary information where required. The interface cannot infer those scientifically from a filename.

## Resources and analysis

Eligible CPUs use affinity and visible cgroup quotas; RAM uses available host memory and visible cgroup headroom. GPUs are detected with NVIDIA queries and visibility restrictions. This is an availability snapshot, not an enforced reservation. Unknown per-job RAM still means one pilot. Imported 60-GiB estimates remain user-configured estimates, not new measurements. The resource tab exposes caps and worker-executable locations; detection does not install environments or turn on distributed scVI automatically.

The default endpoint is the imported QC-bin/cell endpoint. **Independent clustered cells** is a new optional CPU Scanpy PCA route: raw-count analysis QC → gene detection filter → total normalization/log1p → HVG/PCA → neighbors → one UMAP → Leiden 0.1–1.0. It is not batch correction or a singleton scVI workaround. It writes a zero-gene companion embedding/metadata object and reports, not master RNA. Its real scientific test is included but was dependency-skipped here.

Joint scVI/RAPIDS remains explicit under the Clustering tab's optional group panel. Existing phase and compatibility checks remain. Run the phases in order; a selected endpoint does not imply every optional analysis completed.

## Boundaries of this first Project Center candidate

- Live Jupyter widgets and real AnnData/SpatialData/Scanpy writes were not available for execution here. Inspect `VALIDATION.md` for exact tests, skips and synthetic dispatch scope.
- Changing a cutoff **after a completed classification revision** is deliberately not force-overwritten. This candidate asks for a separate run/workspace rather than silently rebuilding dependent data. A complete branching/revision UI is not implemented.
- Automatic spreadsheet reimport/merge for adding samples to an existing managed project is not implemented yet. Create a reviewed new controller project or use the preserved advanced route; do not edit the `engine/` exports manually.
- The center does not yet provide general arbitrary edits to biological source paths/transforms or every scientific parameter after import. Those can change the source/analysis contract and need a new reviewed setup/profile. Runtime locations, stage cutoffs, category/signal decisions, analysis dimensions and explicit group membership have controls.
- The optional geometry-repair panel retains a repair-report path field; accepting repairs is not merged with alignment approval.
- It does not automatically learn per-stage memory models, run as a detached service, or recover an arbitrary half-written scientific store. Existing refusal/recovery safeguards remain.
- The new HTML reports do not add missing biological figures, certify registration from a dimension ratio, or turn clusters into validated cell types.

These limits are explicit so the candidate can be tested without another hidden approval loop. Preserve the old installation and original inputs until the on-instance pilot is accepted.
