from __future__ import annotations
import gc
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .core import (VERSION, affine, digest, dump_json, file_stamp, require_review,
                   safe_frame, safe_uns, sample_paths, stage_lock, transform_xy, translate)
from .images import lazy_rgb
from .io import table_metadata


def scale0(element):
    if hasattr(element,'data') and hasattr(element,'dims') and 'x' in element.dims and 'y' in element.dims:
        return element
    node = element['scale0']
    dataset = node.to_dataset() if hasattr(node,'to_dataset') else node.ds
    if len(dataset.data_vars)!=1:
        raise ValueError('Image scale0 does not have exactly one data variable.')
    return next(iter(dataset.data_vars.values()))


def index_to_intrinsic_transform(element, index_to_fullres):
    """Fit against the PARSED raster's real coordinates, rather than assuming 0 vs 0.5 origins."""
    e = scale0(element)
    x = np.asarray(e.coords['x'],dtype=float)
    y = np.asarray(e.coords['y'],dtype=float)
    sx = float(x[1]-x[0]) if len(x)>1 else 1.
    sy = float(y[1]-y[0]) if len(y)>1 else 1.
    if (len(x)>1 and not np.allclose(np.diff(x),sx)) or (len(y)>1 and not np.allclose(np.diff(y),sy)):
        raise ValueError('Parsed raster has nonuniform intrinsic coordinates.')
    native_to_index = affine([1/sx,0,-x[0]/sx,0,1/sy,-y[0]/sy])
    return affine(index_to_fullres) @ native_to_index


def set_fullres_transform(element, index_to_fullres):
    from spatialdata.transformations import Affine, set_transformation
    a = index_to_intrinsic_transform(element,index_to_fullres)
    set_transformation(element, {'fullres':Affine(a,input_axes=('x','y'),output_axes=('x','y'))}, set_all=True)
    return element


def make_bin_labels(obs, geom):
    from .projective_grid import is_projective
    if is_projective(geom):
        raise ValueError('A projective grid needs bins_2um_polygons, not a false Affine label transform.')
    import dask.array as da
    from spatialdata.models import Labels2DModel
    height,width = geom['grid_shape']
    if height*width >= np.iinfo(np.uint32).max:
        raise ValueError('Capture grid cannot be represented with unique uint32 bin labels.')
    row = obs.array_row.to_numpy(np.int64); col=obs.array_col.to_numpy(np.int64)
    ids = (row*width+col+1).astype(np.uint32)
    if len(np.unique(ids))!=len(ids):
        raise ValueError('Nonunique bin instance IDs.')
    arr = np.zeros((height,width),dtype=np.uint32); arr[row,col] = ids
    labels = Labels2DModel.parse(da.from_array(arr,chunks=(1024,1024)),dims=('y','x'))
    labels = set_fullres_transform(labels,geom['grid_index_to_fullres'])
    return labels, ids


def parse_table(a, region, instance_ids):
    from spatialdata.models import TableModel
    a.uns = safe_uns(dict(a.uns)); a.uns.pop('spatialdata_attrs',None)
    a.obs, a.var = safe_frame(a.obs),safe_frame(a.var)
    a.obs['region'] = pd.Categorical([region]*a.n_obs)
    # Preserve string object dtype for shapes, integer dtype for raster instance labels.
    a.obs['instance_id'] = np.asarray(instance_ids)
    return TableModel.parse(a,region=region,region_key='region',instance_key='instance_id')


def optional_nuclei(cfg,spec,p,geom):
    import dask.array as da
    from spatialdata.models import Labels2DModel
    from .core import proseg_to_fullres
    if not cfg['storage']['include_nuclei_prior']:
        return None
    if cfg['cells']['mode']=='proseg' and p['prior'].exists():
        meta=json.loads(p['prior_meta'].read_text())
        path=p['prior']
        matrix=np.linalg.inv(affine(geom['tenx_to_image']))@affine(meta['mask_index_to_image_px'])
    elif spec.get('legacy_prior_mask') and spec.get('legacy_prior_metadata'):
        path=Path(spec['legacy_prior_mask'])
        meta=json.loads(Path(spec['legacy_prior_metadata']).read_text())
        matrix=np.eye(3)
        matrix[0]=meta['x_transform']; matrix[1]=meta['y_transform']
        matrix=proseg_to_fullres('legacy_sr_row_col_um',geom)@matrix
    else:
        raise FileNotFoundError('include_nuclei_prior requested, but no prior mask/transform metadata was supplied.')
    array=np.load(path,mmap_mode='r')
    if array.dtype!=np.uint32 or array.ndim!=2:
        raise ValueError('Prior mask must be uint32 2D, 0=background.')
    labels=Labels2DModel.parse(da.from_array(array,chunks=(1024,1024)),dims=('y','x'))
    return set_fullres_transform(labels,matrix)


def assemble_sample(cfg,spec):
    """Compatibility entry; use the same explicit image policy and master writer."""
    from .master import assemble_master
    return assemble_master(cfg,spec)


def validate_store(store, spatial_elements=None):
    """Validate both table relations and sampled raster centers WITHOUT reading expression matrices."""
    import spatialdata as sd
    import zarr
    from anndata.io import read_elem
    from spatialdata.transformations import get_transformation
    from spatialdata.models import TableModel
    store=Path(store)
    s=spatial_elements if spatial_elements is not None else sd.read_zarr(store,selection=('images','labels','shapes'))
    from .projective_grid import is_projective
    geom=s.attrs['geometry']
    obs,var=table_metadata(store,'bins_2um')
    if not obs.index.is_unique or not var.index.is_unique or not len(obs):
        raise ValueError('Empty/nonunique bin barcodes or nonunique features.')
    idx=np.random.default_rng(42).choice(len(obs),min(4096,len(obs)),replace=False)
    target=obs.iloc[idx][['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy(float)
    geometry_result={}
    if is_projective(geom):
        from .projective_storage import REGION, validate_projective_bin_shapes
        if REGION not in s.shapes or not obs.region.astype(str).eq(REGION).all():
            raise ValueError('Projective bin table must reference its fullres quadrilaterals.')
        if 'bins_2um_labels' in s.labels:
            raise ValueError('Projective master unexpectedly contains an affine bin-label raster.')
        geometry_result=validate_projective_bin_shapes(s.shapes[REGION],obs,geom,idx)
        error=geometry_result['sampled_bin_center_max_error_px']
    else:
        if 'bins_2um_labels' not in s.labels:
            raise ValueError('Missing canonical affine bin labels.')
        if not obs.region.astype(str).eq('bins_2um_labels').all():
            raise ValueError('Bins table region references the wrong element.')
        grid=scale0(s.labels['bins_2um_labels'])
        r=obs.array_row.to_numpy(np.int64)[idx]; c=obs.array_col.to_numpy(np.int64)[idx]
        arr=grid.data
        labels=arr.vindex[r,c].compute() if hasattr(arr,'vindex') else np.asarray(arr)[r,c]
        if not np.array_equal(labels,obs.instance_id.to_numpy()[idx]):
            raise ValueError('Bin table instance IDs do not identify the correct grid labels.')
        native=np.column_stack([np.asarray(grid.coords['x'])[c],np.asarray(grid.coords['y'])[r]])
        trans=get_transformation(s.labels['bins_2um_labels'],to_coordinate_system='fullres')
        matrix=trans.to_affine_matrix(input_axes=('x','y'),output_axes=('x','y'))
        fullres=transform_xy(native,matrix)
        error=float(np.linalg.norm(fullres-target,axis=1).max(initial=0))
        if error>max(1e-7,geom['grid_fit']['max_residual_px']+1e-5):
            raise ValueError('Stored raster transformation changed bin positions.')
        geometry_result={'bin_representation':'affine_raster','bin_region':'bins_2um_labels'}
    root=zarr.open_group(str(store/'tables'/'bins_2um'),mode='r')
    xy=read_elem(root['obsm']['spatial'])
    if not np.array_equal(np.asarray(xy)[idx],target):
        raise ValueError('Bin obsm[spatial] differs from original full-resolution Space Ranger coordinates.')
    from .compact_images import validate_images
    validate_images(s)
    result={'n_bins':len(obs),'n_bin_genes':len(var),'sampled_bin_center_max_error_px':error,
             'tables':['bins_2um'],'coordinate_system':'fullres',
             'expression_X_not_loaded_by_validation':True,**geometry_result}
    del obs,var,xy; gc.collect()
    if (store/'tables'/'cells').exists():
        obs,var=table_metadata(store,'cells')
        region = str(obs.region.astype(str).iloc[0])
        g=s.shapes[region]
        if not obs.index.is_unique or set(obs.instance_id.astype(str))!=set(g.index.astype(str)):
            raise ValueError('Cell table instances do not match cell polygons.')
        if not obs.region.astype(str).eq(region).all():
            raise ValueError('Incorrect cell table region.')
        if len(obs)!=len(g):
            raise ValueError('Cell-table/polygon row count mismatch.')
        result.update(n_cells=len(obs),n_cell_genes=len(var),n_cell_qc_pass=int(obs.qc_pass.sum()))
        result['tables'].append('cells')
    return result
