"""Synthetic geometry + real XML/JSON/CSV/GDF tests. No master writes are mocked as real."""
import copy,csv,json
from pathlib import Path
import numpy as np
import pytest
import shapely
from shapely.geometry import Polygon,MultiPolygon,GeometryCollection,LineString,Point,box
from vhd.annotations import reviewed_geometry as rg
from vhd.annotations import region_review as vr
from vhd.annotations.workflow import polygons,read_assets,alignment_signature
from vhd.annotations.discovery import discover_one,expand_choices,atomic_choices,merge_choices,choice_signature
from vhd.annotations.geometry import classify_polygons
from vhd.control.manifest import COLUMNS,OPTIONAL_COLUMNS,load_project,sample_layout

BASE=Path(__file__).resolve().parents[1]


def write_csv(p,rows,headers=None):
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers or list(rows[0]));w.writeheader();w.writerows(rows)
    return p


def xml_fixture(p):
    def r(i,xy,negative=False):
        return f'<Region Id="{i}" Type="Polygon" NegativeROA="{int(negative)}"><Vertices>'+''.join(f'<V X="{x}" Y="{y}"/>' for x,y in xy)+'</Vertices></Region>'
    def a(i,name,regions):return f'<Annotation Id="{i}" Name="{name}" LineColor="123" Visible="True"><Regions>'+regions+'</Regions></Annotation>'
    outer=r('0',[(0,0),(20,0),(20,20),(0,20)])
    negative=r('10',[(2,2),(6,6),(2,6),(6,2)],True)
    spike=r('6',[(1,1),(5,1),(5,5),(3,5),(3,7),(3,5),(1,5),(1,1)])
    xml='<Annotations>'+a('0','Tissue',outer+negative)+a('3','Training - Anthro',spike)+a('7','Tiling_Attempt',outer+negative)+a('9','Tumor',outer)+'</Annotations>'
    p.write_text(xml);return p


def make_report(xml,path):
    sha,recs=vr._read_snapshot(xml)
    for r in recs:vr._propose(r,False)
    inv=[]
    for ai in sorted({r['annotation_index'] for r in recs}):
        rows=[r for r in recs if r['annotation_index']==ai];first=rows[0]
        item={'category':first['category'],'annotation_index':ai,'annotation_id':first['annotation_id'],
              'n_regions':len(rows),'n_invalid':sum(r['status']=='invalid' for r in rows),'n_negative':sum(r['negative_region'] for r in rows)}
        if item['n_invalid']:
            _,_,_,stats=vr._compose_annotation(rows);item['candidate_composition']=stats
        inv.append(item)
    public=[vr._public_record(r) for r in recs if r['status']=='invalid']
    d={'review_version':vr.REVIEW_VERSION,'shapely_version':shapely.__version__,'geos_version':shapely.geos_version_string,
       'status':'report_complete_not_approved','coordinate_frame':'XML source coordinates only',
       'sources':[{'sample_key':'Project__A','asset_id':'pathology','path':str(xml),'source_sha256':sha,
                   'n_regions':len(recs),'n_invalid':len(public),'category_inventory':inv,'region_candidates':public}]}
    path.write_text(json.dumps(d));return path


@pytest.fixture
def setup(tmp_path):
    xml=xml_fixture(tmp_path/'original.annotations');review=make_report(xml,tmp_path/'review_summary.json')
    manifest=write_csv(tmp_path/'assets.csv',[
        {'sample_id':'A','asset_id':'pathology','kind':'polygons','path':str(xml),'format':'imagescope_xml','registration_mode':'explicit','source_to_fullres':'1;0;0;0;1;0','coverage_mode':'exhaustive'},
        {'sample_id':'Other','asset_id':'pathology','kind':'polygons','path':'/unchanged/other.annotations','format':'imagescope_xml','registration_mode':'reference_pixels','source_to_fullres':'','coverage_mode':'positive_only'},
    ])
    row=dict.fromkeys(COLUMNS+list(OPTIONAL_COLUMNS),'')
    row.update(enabled='true',sample_id='A',stage='raw',goal='bin_QCed',spaceranger_outs=str(tmp_path/'outs'),segmentation_image=str(tmp_path/'he.svs'),
               output_object_dir=str(tmp_path/'objects'),output_plot_dir=str(tmp_path/'plots'),output_data_dir=str(tmp_path/'tables'),
               work_dir=str(tmp_path/'work'),tmp_dir=str(tmp_path/'tmp'),master_store=str(tmp_path/'masters/A.zarr'),assets_manifest=str(manifest))
    samples=write_csv(tmp_path/'samples.csv',[row])
    cfg=json.loads((BASE/'config/settings.json').read_text())
    cfg.pop('path_variables_file',None);cfg.pop('sample_metadata',None)
    cfg['run_id']='test_review'
    for k in ('python_spatial','python_stardist','python_scvi','python_rapids'):cfg['execution'][k]='current'
    cfg['proseg']['executable']='/unused/proseg'
    cfg['storage_policy']['required_existing_roots']=[];cfg['storage_policy']['required_sentinels']=[]
    cfg['storage_policy']['locations']=[]
    for k in ('approved_tmp_roots','approved_work_roots','approved_object_roots','approved_plot_roots','approved_data_roots','approved_master_roots','approved_cache_roots'):
        cfg['storage_policy'][k]=[str(tmp_path)]
    for k in ('control_dir','work_dir','tmp_dir','output_object_dir','output_plot_dir','output_data_dir'):
        cfg['integration'][k]=str(tmp_path/'integration'/k)
    settings=tmp_path/'settings.json';settings.write_text(json.dumps(cfg))
    project=load_project(samples,settings)
    return {'xml':xml,'review':review,'project':project,'assets':manifest,'settings':settings,'samples':samples}


def compile(s):return rg.compile_reviewed_source(s['review'],sample_key='Project__A',asset_id='pathology')
def plan(s):return rg.reviewed_geometry_plan(s['project'],'A','pathology',s['review'])
def accept(s,**kw):
    p=plan(s)
    return rg.accept_reviewed_geometry(s['project'],'A','pathology',s['review'],expected_plan_digest=p['plan_digest'],reviewer='Synthetic test reviewer',approve=True,allow_remove_lines=True,execute=True,**kw)


def test_compile_preserves_xml_and_all_annotation_categories(setup):
    before=setup['xml'].read_bytes();payload,frame=compile(setup)
    assert setup['xml'].read_bytes()==before
    assert len(payload['features'])==4 and len(frame)==3
    assert frame['line_parts_to_remove'].sum()==1
    assert all(frame.closed_valid_polygonal)
    tissue=shapely.from_wkb(bytes.fromhex(payload['features'][0]['geometry_wkb_hex']))
    assert tissue.area==392  # outer 400 minus BOTH bowtie lobes of area 4 each
    tiling=shapely.from_wkb(bytes.fromhex(payload['features'][2]['geometry_wkb_hex']))
    assert tissue.equals(tiling)
    assert payload['features'][0]['properties']['name']=='Tissue'
    assert payload['features'][2]['properties']['name']=='Tiling_Attempt'
    assert not payload['policy']['registration_approved']


def test_drop_standalone_lines_does_not_open_rings_or_remove_holes():
    p=Polygon([(0,0),(10,0),(10,10),(0,10)],holes=[[(2,2),(4,2),(4,4),(2,4)]])
    candidate=GeometryCollection([p,LineString([(10,10),(11,11)])])
    kept,other=rg.polygonal_candidate(candidate)
    assert kept.wkb==p.wkb and kept.area==96 and len(kept.interiors)==1 and len(other)==1
    assert kept.exterior.is_ring and kept.interiors[0].is_ring
    assert kept.covers(Point(10,10)) and not kept.covers(Point(10.5,10.5))


def test_all_polygon_parts_kept_even_small():
    candidate=MultiPolygon([box(0,0,.01,.01),box(10,10,100,100)])
    kept,other=rg.polygonal_candidate(candidate)
    assert len(kept.geoms)==2 and kept.geoms[0].area==pytest.approx(.0001) and not other


@pytest.mark.parametrize('g',[GeometryCollection([box(0,0,2,2),Point(9,9)]), LineString([(0,0),(1,1)]), Polygon(),
                              Polygon([(0,0),(1,1),(1,0),(0,1)])])
def test_bad_or_unsupported_components_stop(g):
    with pytest.raises(ValueError):rg.polygonal_candidate(g)


@pytest.mark.parametrize('g',[LineString([(0,0),(1,1)]),Point(0,0),Polygon(),Polygon([(0,0),(1,1),(1,0),(0,1)])])
def test_strict_closed_validation(g):
    with pytest.raises(ValueError):rg.assert_closed_polygonal(g)


def test_changed_source_rejected(setup):
    setup['xml'].write_text(setup['xml'].read_text()+' ')
    with pytest.raises(RuntimeError,match='Source changed'):compile(setup)


@pytest.mark.parametrize('field,value',[('shapely_version','0.0.0'),('geos_version','0.0.0'),('status','report_incomplete'),('coordinate_frame','somewhere else')])
def test_wrong_review_environment_or_status(setup,field,value):
    d=json.loads(setup['review'].read_text());d[field]=value;setup['review'].write_text(json.dumps(d))
    with pytest.raises(ValueError):compile(setup)


@pytest.mark.parametrize('what',['metric','coordinate_hash','missing_region','negative_flag','category_composition','category_name'])
def test_altered_report_fails(setup,what):
    d=json.loads(setup['review'].read_text());s=d['sources'][0];r=s['region_candidates'][0]
    if what=='metric':r['candidates']['linework']['polygon_area_source_units_squared']+=2
    if what=='coordinate_hash':r['coordinate_sequence_sha256']='0'*64
    if what=='missing_region':s['region_candidates'].pop()
    if what=='negative_flag':r['negative_region']=False
    if what=='category_composition':s['category_inventory'][0]['candidate_composition']['net_valid']=False
    if what=='category_name':s['category_inventory'][0]['category']='renamed'
    setup['review'].write_text(json.dumps(d))
    with pytest.raises(ValueError):compile(setup)


def test_plan_readonly_and_preview_has_no_writes(setup):
    root=setup['xml'].parent;before={str(p):p.read_bytes() for p in root.rglob('*') if p.is_file()}
    p=plan(setup)
    r=rg.accept_reviewed_geometry(setup['project'],'A','pathology',setup['review'],expected_plan_digest=p['plan_digest'])
    assert r['status']=='preview'
    assert before=={str(p):p.read_bytes() for p in root.rglob('*') if p.is_file()}


@pytest.mark.parametrize('approve,remove,reviewer',[(False,True,'x'),(True,False,'x'),(True,True,'')])
def test_approval_required(setup,approve,remove,reviewer):
    p=plan(setup)
    with pytest.raises(PermissionError):
        rg.accept_reviewed_geometry(setup['project'],'A','pathology',setup['review'],expected_plan_digest=p['plan_digest'],
            execute=True,approve=approve,allow_remove_lines=remove,reviewer=reviewer)
    assert not Path(p['output_parent']).exists()


def test_stale_plan_rejected(setup):
    with pytest.raises(ValueError,match='Plan changed'):
        rg.accept_reviewed_geometry(setup['project'],'A','pathology',setup['review'],expected_plan_digest='wrong',execute=True)


def test_derived_readback_and_reuse(setup):
    before=setup['xml'].read_bytes();s=setup['settings'].read_bytes();a=setup['assets'].read_bytes()
    r=accept(setup);p=Path(r['path']);raw=p.read_bytes();mtime=p.stat().st_mtime_ns
    g=rg.read_reviewed_polygons(p)
    assert g.crs is None and len(g)==4
    assert rg.accept_reviewed_geometry(setup['project'],'A','pathology',setup['review'],expected_plan_digest=plan(setup)['plan_digest'],execute=True,approve=True,allow_remove_lines=True,reviewer='test')['status']=='reused'
    assert p.read_bytes()==raw and p.stat().st_mtime_ns==mtime
    assert setup['xml'].read_bytes()==before and setup['settings'].read_bytes()==s and setup['assets'].read_bytes()==a
    d=json.loads(raw);assert len(d['payload']['region_audit'])==6
    assert sum(len(r['removed_lines']) for r in d['payload']['region_audit'])==1


def test_loader_hook_and_overlapping_memberships(setup):
    r=accept(setup);g=polygons({'path':r['path'],'format':rg.FORMAT,'coverage_path':''})
    assert list(g.name)==['Tissue','Training - Anthro','Tiling_Attempt','Tumor']
    f=classify_polygons(np.array([[10,10],[3,3],[100,100]]),g,categories=list(g.name),exhaustive=True)
    assert f.loc[0,'Tissue'] and f.loc[0,'Tumor'] and f.loc[0,'Tiling_Attempt']
    assert not f.loc[2,'Tumor']


def test_activate_preserves_other_rows_source_and_flags(setup):
    r=accept(setup);before=setup['assets'].read_bytes()
    dry=rg.activate_reviewed_geometry(setup['project'],'A','pathology',r['path'])
    assert dry['status']=='preview' and setup['assets'].read_bytes()==before
    out=rg.activate_reviewed_geometry(setup['project'],'A','pathology',r['path'],execute=True)
    assert Path(out['backup']).read_bytes()==before
    old=list(csv.DictReader(before.decode().splitlines()));new=list(csv.DictReader(setup['assets'].read_text().splitlines()))
    assert all(new[1][k]==v for k,v in old[1].items())
    assert all(new[0][k]==v for k,v in old[0].items() if k not in ('path','format','category_column'))
    assert new[0]['format']==rg.FORMAT
    a=read_assets(setup['assets'],'Project','A')[0];choices,_=discover_one(a,{},'Project__A')
    assert len(choices)==4 and all(c['include_in_obs']=='false' for c in choices)
    assert rg.activate_reviewed_geometry(setup['project'],'A','pathology',r['path'],execute=True)['status']=='already_active'


def test_previous_choices_stale_on_new_derivative(setup):
    a=read_assets(setup['assets'],'Project','A')[0]
    # Inventory keys identical to later choice identities, but old approval not reusable.
    r=accept(setup);rg.activate_reviewed_geometry(setup['project'],'A','pathology',r['path'],execute=True)
    new=read_assets(setup['assets'],'Project','A')[0];choices,_=discover_one(new,{},'Project__A')
    old=copy.deepcopy(choices)
    for c in old:
        c.update(include_in_obs='true',reviewed_signature='old_approval',source_signature='old_source')
    merged=merge_choices(old,choices,{('Project__A','pathology')})
    assert all(c['include_in_obs']=='true' and c['reviewed_signature']=='' for c in merged)


def test_tampered_payload_rejected(setup):
    r=accept(setup);p=Path(r['path']);d=json.loads(p.read_text());d['payload']['features'][0]['properties']['name']='Changed'
    p.write_text(json.dumps(d))
    with pytest.raises(ValueError,match='checksum'):rg.read_reviewed_polygons(p)


def test_partial_existing_derivative_rejected(setup):
    p=plan(setup);out=Path(p['output_parent'])/p['plan_digest']/'annotation.vhdpolygons.json';out.parent.mkdir(parents=True);out.write_text('{partial')
    with pytest.raises(ValueError):accept(setup)
    assert out.read_text()=='{partial'


def test_geometry_approval_is_not_alignment_or_category_selection(setup):
    r=accept(setup);d=json.loads(Path(r['path']).read_text())
    assert not d['payload']['policy']['registration_approved'] and not d['payload']['policy']['obs_categories_selected']


def test_actual_report_generation_and_adoption(setup):
    # Real XML diagnostic + actual plotting with tiny inputs, not a SpatialData write.
    r=rg.prepare_geometry_review(setup['project'],'A','pathology',execute=True)
    rp=Path(r['report_dir'])/'review_summary.json';assert rp.is_file()
    p=rg.reviewed_geometry_plan(setup['project'],'A','pathology',rp)
    assert len(p['regions'])==3 and any(Path(r['report_dir']).rglob('*.png'))


def test_refuse_symlinked_report_output(setup,tmp_path):
    paths=sample_layout(setup['project'],setup['project']['rows'][0]);parent=Path(paths['report']);parent.mkdir(parents=True)
    external=tmp_path/'outside';external.mkdir();(parent/'reviewed_annotations').symlink_to(external,target_is_directory=True)
    with pytest.raises(ValueError):plan(setup)
    assert not list(external.iterdir())


def test_refuse_symlinked_digest_folder(setup,tmp_path):
    p=plan(setup);parent=Path(p['output_parent']);parent.mkdir(parents=True);external=tmp_path/'elsewhere';external.mkdir()
    (parent/p['plan_digest']).symlink_to(external,target_is_directory=True)
    with pytest.raises(ValueError,match='symlinked'):accept(setup)
    assert not list(external.iterdir())
