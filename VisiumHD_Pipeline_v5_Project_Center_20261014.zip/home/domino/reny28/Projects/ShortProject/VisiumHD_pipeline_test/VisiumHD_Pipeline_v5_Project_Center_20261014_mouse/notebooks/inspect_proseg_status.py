"""Read the current Project Center Proseg status without launching or repairing work.

Use in the existing Project Center kernel:
    from inspect_proseg_status import inspect_proseg_status
    PROSEG_DIAGNOSTIC = inspect_proseg_status(pc)

Reads selected small status/command files and bounded log tails only. It does not
load scientific matrices, initialize a GPU, run Proseg, or write project state.
Log modification timestamps must be compared with the current job timestamps;
files may belong to an earlier attempt or may be changing during inspection.
"""
from __future__ import annotations

from datetime import datetime, timezone
import inspect
import json
from pathlib import Path
import re

_ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def inspect_proseg_status(controller, sample="Project__BM0164135A_s1_A1"):
    """Return and print observational evidence. Does not certify process liveness."""
    from vhd.control.manifest import sample_layout
    from vhd.compute import runtime_checks

    state = controller.snapshot()
    project = state["project"]
    rows = [row for row in project["rows"] if row["sample_key"] == sample]
    if len(rows) != 1:
        raise ValueError(f"Expected exactly one configured row for {sample!r}; found {len(rows)}.")
    paths = sample_layout(project, rows[0])
    jobs = state.get("jobs", {}).get(sample, {})
    report = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "sample": sample,
        "controller_jobs": {action: jobs.get(action, {"status": "not_recorded"})
                            for action in ("proseg", "postprocess_cells")},
        "proseg_import_modules": runtime_checks.action_imports("proseg"),
        "native_preflight_signature": str(inspect.signature(runtime_checks.preflight_python)),
        "files": {},
        "inspection_only": True,
        "note": "File timestamps/statuses may describe an older attempt; no process-liveness assertion.",
    }

    print("PROSEG CONTROLLER JOB:")
    print(json.dumps(report["controller_jobs"]["proseg"], indent=2, default=str))
    error = report["controller_jobs"]["proseg"].get("error")
    if error:
        print("\nFULL CONTROLLER ERROR (ANSI formatting removed):")
        print(_ANSI.sub("", str(error)))
    print("\nPOSTPROCESS_CELLS CONTROLLER JOB:")
    print(json.dumps(report["controller_jobs"]["postprocess_cells"], indent=2, default=str))
    print("\nNative Proseg import list:", report["proseg_import_modules"])
    print("Native preflight signature:", report["native_preflight_signature"])

    targets = [(Path(paths["report"]) / name) for name in (
        "status_proseg.json", "worker_proseg.log", "proseg_run.log",
        "proseg_exit.json", "proseg_command.txt", "status_postprocess_cells.json",
    )] + [Path(paths["work"]) / "04_proseg_complete.json"]
    for path in targets:
        record = {"path": str(path)}
        try:
            with path.open("rb") as handle:
                before = path.stat()
                start = max(0, before.st_size - 65536)
                handle.seek(start)
                raw = handle.read(65536)
                after = path.stat()
            text = raw.decode("utf-8", errors="replace")
            lines = _ANSI.sub("", text).splitlines()
            record.update(
                exists=True,
                mtime_utc=datetime.fromtimestamp(before.st_mtime, timezone.utc).isoformat(),
                size_bytes=before.st_size,
                tail_only=bool(start or len(lines) > 80),
                changed_during_read=(before.st_size, before.st_mtime_ns) !=
                                    (after.st_size, after.st_mtime_ns),
                text="\n".join(lines[-80:]),
            )
        except FileNotFoundError:
            record.update(exists=False, text="No file currently at this path.")
        except OSError as exc:
            record.update(read_error=f"{type(exc).__name__}: {exc}", text="Read unsuccessful.")
        report["files"][path.name] = record
        print(f"\n--- {path.name} ---")
        print("Path:", path)
        print("Modified UTC:", record.get("mtime_utc", "not available"))
        if record.get("read_error"):
            print(record["read_error"])
        if record.get("changed_during_read"):
            print("WARNING: file changed during read; this is not a stable snapshot.")
        print(record["text"])
    print("\nInspection finished. No jobs, settings, reviews, locks or data were changed.")
    return report
