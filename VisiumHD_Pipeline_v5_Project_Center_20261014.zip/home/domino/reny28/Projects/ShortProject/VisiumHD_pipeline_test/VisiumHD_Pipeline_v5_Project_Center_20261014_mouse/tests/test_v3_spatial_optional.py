"""Real encoders/SpatialData roundtrips, skipped as a MODULE when dependencies are absent."""
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
ad=pytest.importorskip('anndata')
sd=pytest.importorskip('spatialdata')
zarr=pytest.importorskip('zarr')
pytest.importorskip('dask')
pytest.importorskip('pyarrow')
import geopandas as gpd
from shapely.geometry import box,Polygon
from spatialdata.models import ShapesModel
from spatialdata.transformations import Identity,get_transformation
from vhd.storage import parse_table
from vhd.persistence import update_table_metadata,persist_changes
from vhd.persistence.transaction import inventory
from vhd.io import load_table


def fixture(tmp_path,fmt):
    a=ad.AnnData(X=sparse.csr_matrix([[1,0],[2,3]],dtype=np.int32),obs=pd.DataFrame(index=['a','b']))
    a.obsm['spatial']=np.array([[1,1],[3,1]],float)
    g=gpd.GeoDataFrame(geometry=[box(0,0,2,2),box(2,0,4,2)],index=a.obs_names)
    s=sd.SpatialData(shapes={'cell_boundaries':ShapesModel.parse(g,transformations={'fullres':Identity()})},tables={'cells':parse_table(a,'cell_boundaries',a.obs_names)})
    kw={}
    if fmt==2:
        from spatialdata._io.format import SpatialDataContainerFormatV01
        kw['sdata_formats']=SpatialDataContainerFormatV01()
    p=tmp_path/'master.zarr';s.write(p,**kw)
    return p,{'approved_master_roots':[str(tmp_path)],'approved_work_roots':[str(tmp_path)],'min_free_master_gib':0}


@pytest.mark.parametrize('fmt',[2,3])
def test_metadata_roundtrip_counts_unchanged(tmp_path,fmt):
    p,policy=fixture(tmp_path,fmt);before=inventory(p/'tables/cells/X')
    f=pd.DataFrame({'class':pd.Categorical(['B','A']),'flag':pd.array([pd.NA,True],dtype='boolean')},index=['b','a'])
    embedding=pd.DataFrame([[3.,4.],[1.,2.]],index=['b','a'])
    update_table_metadata(p,'cells',obs=f,obsm={'X_umap':embedding},uns={'test':'v3'},policy=policy,staging_dir=tmp_path/'stage',execute=True,single_writer_ack=True)
    assert before==inventory(p/'tables/cells/X')
    result=sd.read_zarr(p).tables['cells'];assert result.obs['class'].tolist()==['A','B'];assert pd.isna(result.obs.loc['b','flag'])
    np.testing.assert_equal(result.obsm['X_umap'],[[1,2],[3,4]])
    assert result.uns['test']=='v3'


@pytest.mark.parametrize('fmt',[2,3])
def test_geometry_replacement_preserves_hole_and_counts(tmp_path,fmt):
    p,policy=fixture(tmp_path,fmt);s=sd.read_zarr(p,selection=('shapes',));before=inventory(p/'tables/cells/X')
    outer=box(0,0,10,10).difference(box(4,4,6,6))
    s.shapes['cell_boundaries']=ShapesModel.parse(gpd.GeoDataFrame(geometry=[outer,box(20,0,22,2)],index=['a','b']),transformations={'fullres':Identity()})
    persist_changes(s,replace_elements=['cell_boundaries'],policy=policy,staging_dir=tmp_path/'stage',execute=True,single_writer_ack=True)
    r=sd.read_zarr(p);assert r.shapes['cell_boundaries'].geometry.iloc[0].area==96
    assert len(r.shapes['cell_boundaries'].geometry.iloc[0].interiors)==1
    assert before==inventory(p/'tables/cells/X')


def test_raster_index_origin_contract(tmp_path):
    from vhd.annotations.raster import spatial_image
    p=tmp_path/'x.npy';np.save(p,np.arange(20,dtype=np.float32).reshape(4,5))
    matrix=np.array([[2,0,10],[0,3,20],[0,0,1.]])
    e=spatial_image(p,'yx',None,matrix,'signal',tile_size=3)
    a=get_transformation(e,to_coordinate_system='fullres').to_affine_matrix(input_axes=('x','y'),output_axes=('x','y'))
    xy=np.array([float(e.coords['x'][0]),float(e.coords['y'][0]),1])
    np.testing.assert_allclose(a@xy,[10,20,1])
    np.testing.assert_equal(e.data.compute()[0],np.load(p))
