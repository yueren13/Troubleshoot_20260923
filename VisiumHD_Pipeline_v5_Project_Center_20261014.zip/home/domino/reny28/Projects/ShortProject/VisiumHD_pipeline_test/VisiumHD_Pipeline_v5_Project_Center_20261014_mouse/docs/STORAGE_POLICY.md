> Inherited technical reference. For the v4.1 source/category interface, start with START_HERE.md, ASSETS_V41_DISCOVERY.md and SIGNAL_MEASUREMENTS_V41.md. Older file-level role examples remain compatibility-only.

> Retained v3 technical reference. For the consolidated v4 setup and changed behavior, read START_HERE.md, ASSETS_V4.md and IMAGE_AND_ANALYSIS_V4.md first.

# Storage and selective persistence

Transport (mounted filesystem vs direct object URL), storage role (source/work/scratch/
cache/master/snapshot), and backing medium are separate configuration facts. Mounted
S3 uses ordinary paths; no S3 URL conversion or new authentication is required.
`locations` may label a configured root mounted_s3 or ebs. No prefixes are hard-coded.

Mounted object storage may report misleading free-space values. Its explicit
`capacity_check=false` can disable only that filesystem-capacity gate; source and
copy integrity checks remain active. Scratch space checks on actual local work
volumes still apply. Profile labels do not certify filesystem semantics or compliance.

## Retention
Active work and cache are retained. Scratch is logically disposable but no automatic
cleanup is implemented. No raw source is deleted. A completed publication is an
immutable optional snapshot, distinct from the stable mutable master. Existing
published prefixes are never silently overwritten.

## Explicit operations
`persist_changes(...,new_elements=[...])`: add only those elements.
`replace_elements=[...]`: stage and replace actual DATA, never inferred transform-only.
`transformation_elements=[...]`: write only transformation metadata; use a separate call.
`update_table_metadata(...,obs=...,obsm=...,uns=...)`: update selected metadata without
rewriting X/layers. Rewrites the obs component, not necessarily only one encoded column.
Embedding updates require indexed DataFrames. IDs/order are aligned explicitly.
Region/instance links and spatial coordinates are not mutable through this operation.

Dry run is default. Execution needs approved roots, staging directory, and explicit
single_writer_ack. The caller must stop concurrent readers as well as writers. The
lock is a guard for cooperating processes, not proof that a mount provides POSIX locks.

## Recovery model
All incoming and OLD on-disk components are copied and checksummed before promotion.
The old backup is not just an alias of the newly modified in-memory object. Promotion
uses remove/copy under a journal and is NOT a multi-key atomic transaction. It can
perform extra I/O for full-element replacement; metadata-only updates avoid count I/O.

Backups and journal live beside the master under <store>.vhd_transactions/<id>.
The approved master root must allow those sibling paths. Backups remain after success.
A failed/unresolved journal blocks new writes. `recover_transaction` defaults to preview;
rollback execution is deliberate, with metadata consolidation afterward. A partially
copied component requires explicit allow_partial after inspection; unexpected newer
live data is rejected. Stale writer locks require operator review, not automatic deletion.

Both Zarr formats 2 and 3 have optional real serialization tests. The v2-container path
uses the documented SpatialDataContainerFormatV01 writer in a current SpatialData
installation. Unsupported API/format combinations fail rather than silently mixing
storage formats. Actual mount writes, crash durability and reader-cache behavior must
be tested in the user's environment before updating an important master.

## Source registration
An existing master created by this v3 workspace can be selectively extended. Legacy
masters use the explicit notebook-13 update API or a fresh canonical import; they are
not silently adopted as if their coordinates/count lineage had been verified. Moving
workspaces/run_ids does not automatically migrate completion receipts.
