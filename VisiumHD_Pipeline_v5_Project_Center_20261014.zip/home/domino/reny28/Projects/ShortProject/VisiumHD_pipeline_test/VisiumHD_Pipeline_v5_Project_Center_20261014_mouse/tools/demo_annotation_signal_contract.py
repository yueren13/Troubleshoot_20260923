"""Tiny synthetic XML/TIFF/metadata demo. No biological data, models or masters.

Run from the pipeline root:
  python tools/demo_annotation_signal_contract.py --output /path/to/NEW/demo_folder
The destination must not exist. This creates only the named small demo directory.
"""
from pathlib import Path
import argparse,json,sys,csv
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import tifffile
from vhd.annotations.geometry import read_imagescope_annotation_xml,membership
from vhd.annotations.workflow import COLUMNS,OPTIONAL_ASSET_COLUMNS,read_assets,active_assets,MeasurementRaster
from vhd.annotations.raster import open_raster
from vhd.annotations.transfer import aggregate_annotations
from vhd.he.fixed import sample_field
from vhd.plots import histogram


def xml_square(outer=90,negative=True):
    def region(vertices,neg):
        return '<Region NegativeROA="'+str(int(neg))+'"><Vertices>'+''.join(f'<V X="{x}" Y="{y}"/>' for x,y in vertices)+'</Vertices></Region>'
    body=region([(0,0),(outer,0),(outer,outer),(0,outer)],False)
    if negative:body+=region([(18,18),(36,18),(36,36),(18,36)],True)
    return '<Annotations><Annotation Name="Tissue"><Regions>'+body+'</Regions></Annotation></Annotations>'


def run(output):
    output=Path(output)
    if output.exists():raise FileExistsError('Use a NEW demo directory. Existing files are not overwritten: '+str(output))
    output.mkdir(parents=True)
    q=output/'trusted.annotations';q.write_text(xml_square())
    r=output/'reference_only.annotations';r.write_text(xml_square(900,False))
    binary=np.zeros((10,10),np.uint8);binary[:,5:]=255;tifffile.imwrite(output/'binary_1_to_9.tif',binary)
    headers=COLUMNS+OPTIONAL_ASSET_COLUMNS;rows=[]
    for name,kind,role,path in [('trusted','polygons','segmentation_qc',q.name),('unreliable','polygons','reference_only',r.name),('binary','signal','analysis','binary_1_to_9.tif')]:
        row={k:'' for k in headers};row.update(enabled='true',dataset_id='Demo',sample_id='A',asset_id=name,kind=kind,role=role,path=path,coverage_mode='exhaustive',source_to_fullres='1;0;0;0;1;0',bin_method='membership',format='imagescope_xml',category_column='name')
        if kind=='signal':row.update(format='tiff',axes='yx',source_to_fullres='9;0;0;0;9;0',bin_method='center_nearest',cell_methods='mean;sum;median',signal_type='binary',positive_value='255',negative_value='0',category_column='')
        rows.append(row)
    with (output/'assets.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(rows)
    assets=read_assets(output/'assets.csv','Demo','A')
    assert [x['asset_id'] for x in active_assets(assets)]==['trusted','binary']
    polygon=read_imagescope_annotation_xml(q).geometry.iloc[0]
    assert polygon.area==90*90-18*18
    assert not membership(np.array([[27,27]]),polygon)[0]
    a=next(x for x in assets if x['asset_id']=='binary')
    xy=np.array([[9,9],[27,27],[63,9],[100,9]],float)
    with open_raster(output/'binary_1_to_9.tif','yx') as raster:
        values,inside,valid=sample_field(MeasurementRaster(raster,a),xy,source_to_fullres=a['source_to_fullres'],interpolation='nearest')
    np.testing.assert_allclose(values[:3],[0,0,1]);assert np.isnan(values[3]) and not valid[3]
    obs=pd.DataFrame({'signal':values});cell=aggregate_annotations(obs,np.array([0,0,1,1]),2,{'continuous':{'signal':['sum','mean','median']}})
    assert cell['geometric__signal__mean'].tolist()==[0.,1.]
    assert cell['geometric__signal__annotation_coverage'].tolist()==[1.,.5]
    cell.to_csv(output/'cell_signal_summary.csv',index=False)
    counts=np.array([0,1,2,3,10,16,30,100,300,1000,3000,10000])
    histogram(counts,'Synthetic count-axis check',output/'readable_counts.png',label='UMIs per cell',log1p=True,dpi=100)
    report={'status':'passed','synthetic_only':True,'source_files':['trusted.annotations','reference_only.annotations','binary_1_to_9.tif'],
      'active_ids':[x['asset_id'] for x in active_assets(assets)],'tissue_area_after_hole':polygon.area,
      'binary_values_at_valid_centers':values[:3].tolist(),'fourth_center_invalid':bool(not valid[3]),
      'cell_signal_means':cell['geometric__signal__mean'].tolist(),'cell_coverage':cell['geometric__signal__annotation_coverage'].tolist(),
      'not_tested':['SpatialData/AnnData roundtrip','actual pilot files','segmentation','scVI','GPU','mounted storage']}
    (output/'result.json').write_text(json.dumps(report,indent=2));return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True)
    print(json.dumps(run(p.parse_args().output),indent=2))
