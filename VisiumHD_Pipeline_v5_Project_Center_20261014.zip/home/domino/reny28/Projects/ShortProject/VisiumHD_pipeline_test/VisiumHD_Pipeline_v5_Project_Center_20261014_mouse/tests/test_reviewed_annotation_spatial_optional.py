"""Optional REAL tiny SpatialData write/readback, not a full pilot or mount test."""
import pytest
ad=pytest.importorskip('anndata')
sd=pytest.importorskip('spatialdata')
pytest.importorskip('pyarrow')
import numpy as np
import geopandas as gpd
from shapely.geometry import Polygon,box
from scipy import sparse
from spatialdata.models import ShapesModel
from spatialdata.transformations import Identity

def test_reviewed_polygon_holes_and_counts_spatial_roundtrip(tmp_path):
    g=gpd.GeoDataFrame({'name':['Tissue','Tumor'], 'annotation_id':['0','1'],
        'geometry':[Polygon([(0,0),(10,0),(10,10),(0,10)],holes=[[(2,2),(4,2),(4,4),(2,4)]]), box(0,0,5,5)]},index=['0','1'],crs=None)
    from vhd.annotations.reviewed_geometry import assert_closed_polygonal
    for x in g.geometry:assert_closed_polygonal(x)
    a=ad.AnnData(X=sparse.csr_matrix([[1,0],[0,2]],dtype=np.int32))
    a.obs_names=['bin1','bin2'];a.var_names=['G1','G2'];a.obsm['spatial']=np.array([[1.,1.],[3.,3.]])
    obj=sd.SpatialData(shapes={'reviewed_annotation':ShapesModel.parse(g,transformations={'global':Identity()})},tables={'bins_2um':a})
    path=tmp_path/'tiny.zarr';obj.write(path)
    loaded=sd.read_zarr(path)
    assert len(loaded.shapes['reviewed_annotation'].geometry.iloc[0].interiors)==1
    assert loaded.shapes['reviewed_annotation'].geometry.iloc[0].area==96
    np.testing.assert_array_equal(loaded.tables['bins_2um'].X.toarray(),a.X.toarray())
    np.testing.assert_array_equal(loaded.tables['bins_2um'].obsm['spatial'],a.obsm['spatial'])
