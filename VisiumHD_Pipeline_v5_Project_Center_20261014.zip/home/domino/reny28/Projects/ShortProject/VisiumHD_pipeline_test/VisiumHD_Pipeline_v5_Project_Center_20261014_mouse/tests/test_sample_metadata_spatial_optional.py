"""Real AnnData/SpatialData roundtrips; module skip does NOT count as validation."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
ad=pytest.importorskip('anndata')
sd=pytest.importorskip('spatialdata')
pytest.importorskip('zarr')
pytest.importorskip('pyarrow')
import geopandas as gpd
from spatialdata.models import ShapesModel
from spatialdata.transformations import Identity
from vhd.storage import parse_table
from vhd.sample_metadata import attach_sample_metadata,sync_sample_metadata
from vhd.persistence.transaction import inventory
from vhd.control.manifest import load_project,sample_layout
from vhd.control.runner import run_action
from vhd.io import load_table


def test_real_dual_table_metadata_update_counts_and_links_unchanged(tmp_path):
    index=pd.Index(['c0','c1'])
    obs=pd.DataFrame({'sample':['Study__A']*2,'qc_pass':[True,False]},index=index)
    a=ad.AnnData(sparse.csr_matrix([[3,7],[1,2]],dtype=np.int32),obs=obs)
    a.layers['counts']=a.X.copy();a.obsm['spatial']=np.array([[1.,2.],[3.,4.]])
    points=gpd.GeoDataFrame({'radius':[1.,1.]},geometry=gpd.points_from_xy([1,3],[2,4]),index=index)
    s=sd.SpatialData(shapes={'centroids':ShapesModel.parse(points,transformations={'fullres':Identity()})},
        tables={'cells':parse_table(a.copy(),'centroids',index),
                'bins_2um':parse_table(a.copy(),'centroids',index)})
    store=tmp_path/'master.zarr';s.write(store)
    work=tmp_path/'work';work.mkdir()
    spec={'sample':'Study__A','sample_id':'A','dataset_id':'Study','metadata':{'species':'mouse','condition':'one','amount':2.5,'missing':None},
        '_paths':{'store':str(store),'work':str(work),'report':str(tmp_path/'reports'),'proseg':str(work/'proseg')},'_row':{'goal':'cell_annotated'}}
    cfg={'storage':{'single_writer_ack':True},'storage_policy':{'approved_master_roots':[str(tmp_path)],
        'approved_work_roots':[str(tmp_path)],'min_free_master_gib':0}}
    before={(t,g):inventory(store/'tables'/t/g) for t in ('cells','bins_2um') for g in ('X','layers','obsm')}
    preview=sync_sample_metadata(cfg,spec,execute=False)
    assert all(x['status']=='preview' for x in preview['tables'])
    assert 'condition' not in load_table(store,'cells').obs
    sync_sample_metadata(cfg,spec,execute=True)
    for t in ('cells','bins_2um'):
        b=load_table(store,t)
        assert b.obs.condition.astype(str).tolist()==['one','one']
        assert b.obs['missing'].isna().all()
        assert b.obs.qc_pass.tolist()==[True,False]
        assert b.obs.instance_id.astype(str).tolist()==list(index)
        assert (b.X!=a.X).nnz==0
    assert all(inventory(store/'tables'/t/g)==stamp for (t,g),stamp in before.items())
    result=sync_sample_metadata(cfg,spec,execute=True)
    assert all(x['status']=='unchanged' for x in result['tables'])
    spec['metadata']['condition']='two'
    with pytest.raises(ValueError,match='conflicts'):sync_sample_metadata(cfg,spec,execute=True)
    sync_sample_metadata(cfg,spec,execute=True,replace_owned=True)
    assert load_table(store,'cells').obs.condition.astype(str).tolist()==['two','two']
    assert all(inventory(store/'tables'/t/g)==stamp for (t,g),stamp in before.items())


def test_real_csv_cell_import_and_assemble(tmp_path):
    from test_resume_optional import project_for,source_data
    source=tmp_path/'source.h5ad';original=source_data(source);before=source.read_bytes()
    project=project_for(tmp_path,source)
    settings=Path(project['settings_path']);config=json.loads(settings.read_text())
    config['sample_metadata']={'path':'metadata.csv','sample_id_column':'Sample','types':{'weight':'float'}}
    settings.write_text(json.dumps(config))
    (tmp_path/'metadata.csv').write_text('Sample,species,donor,weight,missing\none,mouse,001,2.5,\n')
    project=load_project(project['manifest_path'],settings)
    run_action(project,'tiny__one','import_cells');run_action(project,'tiny__one','assemble')
    path=sample_layout(project,project['rows'][0])['store'];result=load_table(path,'cells')
    assert result.obs.donor.astype(str).eq('001').all() and result.obs.weight.eq(2.5).all()
    assert result.obs['missing'].isna().all()
    assert (result.X!=original.layers['counts']).nnz==0 and source.read_bytes()==before
