"""Routes, review boundaries and lightweight product inventory (not biological validation)."""
from pathlib import Path
import json

LABELS={
 'ingest_raw':'Import Space Ranger bins','import_bins':'Import existing bins','measure_he':'Measure fixed H&E evidence',
 'bin_qc':'Classify bin QC','reuse_bin_qc':'Load accepted bin QC','review_bins':'Review bin QC / coordinates',
 'review_assets':'Review annotations and signals','transfer_assets':'Import approved sources and transfer metadata',
 'stardist':'Build StarDist prior','review_prior':'Review nuclear prior','proseg':'Run Proseg',
 'postprocess_cells':'Build and assess cells','import_cells':'Import existing cells','assemble':'Assemble / validate master',
 'refresh_cell_annotations':'Summarize annotations onto cells','review_cells':'Review cells',
 'cluster_individual':'Independent QC, normalization, PCA, Leiden and UMAP','review_clustering':'Review clustering',
 'publish':'Publish products','export_existing':'Export annotated input'}
REVIEW_STAGES={'review_bins','review_assets','review_prior','review_cells','review_clustering'}
PRODUCTS={
 'ingest_raw':('01_ingest_complete.json','bins_raw.h5ad','geometry.json'),
 'import_bins':('01_import_bins_complete.json','bins_raw.h5ad','geometry.json'),
 'measure_he':('he_fixed/complete.json','bins_he.parquet','he_fixed/measurement.json'),
 'bin_qc':('02_qc_complete.json','bins_qc_obs.parquet'),
 'reuse_bin_qc':('02_reuse_qc_complete.json','bins_qc_obs.parquet'),
 'stardist':('03_prior_complete.json','prior_qc.npy','prior_metadata.json'),
 'proseg':('04_proseg_complete.json',),
 'postprocess_cells':('05_cells_complete.json','cells_qc.h5ad','cells_fullres.parquet'),
 'import_cells':('05_import_cells_complete.json','cells_qc.h5ad'),
 'transfer_assets':('bins_annotated_obs.parquet',),
}


def route(row, endpoint=None):
    endpoint=endpoint or ('bins' if row['goal']=='bin_QCed' else 'cells')
    if endpoint not in ('bins','cells','clustered','publish'):raise ValueError('Endpoint: bins, cells, clustered, publish.')
    if row['goal']=='export_only':return ['export_existing','publish']
    entry=row['stage'];has_bins=entry=='raw' or bool(row.get('bin_input'))
    steps=[]
    if has_bins:
        steps += ['ingest_raw'] if entry=='raw' else ['import_bins']
        steps += ['measure_he','bin_qc'] if entry in ('raw','bin_imported') else ['reuse_bin_qc']
        steps += ['review_bins']
    if row.get('assets_manifest') and has_bins:steps+=['review_assets','transfer_assets']
    if endpoint=='bins':
        if not has_bins:raise ValueError('A cells-only entry cannot produce a bin endpoint.')
        return steps+['assemble']
    if entry in ('raw','bin_imported','bin_QCed'):steps+=['stardist','review_prior','proseg','postprocess_cells']
    else:steps+=['import_cells']
    steps+=['assemble']
    if row.get('assets_manifest') and has_bins:steps+=['refresh_cell_annotations']
    steps+=['review_cells']
    if endpoint=='clustered':steps+=['cluster_individual','review_clustering']
    if endpoint=='publish':steps+=['publish']
    return steps


def output_paths(project,row,action):
    from ..control.manifest import sample_layout
    p=sample_layout(project,row)
    paths=[p['work']/n for n in PRODUCTS.get(action,())]
    if action=='assemble':paths=[p['report']/'storage_manifest.json',p['report']/'master_sources.json',p['store']]
    if action=='transfer_assets':paths+=[p['report']/'assets_transfer.json']
    if action=='refresh_cell_annotations':paths=[p['report']/'cell_annotation_refresh.json']
    if action=='cluster_individual':paths=[p['report']/'individual_analysis/current.json']
    if action=='export_existing':paths=[p['report']/'export_existing.json']
    if action=='publish':paths=[p['root']/'PUBLICATION_RECEIPT.json']
    return paths


def observed(project,row,action):
    from ..control.manifest import sample_layout
    paths=output_paths(project,row,action);p=sample_layout(project,row)
    present=[str(q) for q in paths if q.exists()];missing=[str(q) for q in paths if not q.exists()]
    status=p['report']/f'status_{action}.json';record={}
    try:
        if status.is_file() and status.stat().st_size<1024**2:record=json.loads(status.read_text())
    except (OSError,ValueError):pass
    return {'action':action,'present':present,'missing':missing,'all_expected_present':bool(paths) and not missing,
            'worker_record':record,'interpretation':'File/status inventory only; not a fresh source-signature or biological validation.'}
