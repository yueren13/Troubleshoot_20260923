"""REAL HDF5/Parquet scalar I/O. Requires pyarrow; no SpatialData/GPU required."""
import hashlib
from pathlib import Path
import json
import h5py
import numpy as np
import pandas as pd
import pytest
pq = pytest.importorskip('pyarrow.parquet')
from vhd.he import qc_review as q
from vhd.core import file_stamp
from test_bin_qc_review import make_h5, project_fixture
from vhd.control.manifest import row_config, sample_layout


def inputs(tmp_path, order=None, validity=None, index_name='barcode'):
    ids=['b0','b1','b2','b3','b4']
    bins=make_h5(tmp_path/'bins.h5ad',ids,[0,1,3,16,10000])
    frame=pd.DataFrame({'he_tissue_score':np.array([0,.1,.3,.8,1],np.float32),
                        'he_tissue_score_valid':([True]*5 if validity is None else validity)},
                       index=pd.Index(ids if order is None else order,name=index_name))
    score=tmp_path/'he.parquet';frame.to_parquet(score,row_group_size=2)
    return bins,score


def test_real_parquet_scalar_scans_do_not_read_X(tmp_path,monkeypatch):
    bins,score=inputs(tmp_path)
    sha={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in (bins,score)}
    original=h5py.Dataset.__getitem__
    def guarded(self,key):
        if self.name.startswith('/X'):raise AssertionError('Read X!')
        return original(self,key)
    monkeypatch.setattr(h5py.Dataset,'__getitem__',guarded)
    factory=lambda:q.iter_metadata_batches(bins,score,chunk_size=2)
    result=q.summarize_batches(factory,thresholds=q._thresholds({}))
    assert result['summary']['n_bins']==5 and result['density'].sum()==5
    for p,d in sha.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==d


@pytest.mark.parametrize('index_name',[None,'barcode','arbitrary_index'])
def test_real_parquet_stored_index_names(tmp_path,index_name):
    bins,score=inputs(tmp_path,index_name=index_name)
    assert sum(len(x[0]) for x in q.iter_metadata_batches(bins,score,chunk_size=3))==5


def test_real_parquet_bad_order_stops(tmp_path):
    bins,score=inputs(tmp_path,order=['b1','b0','b2','b3','b4'])
    with pytest.raises(ValueError,match='identities/order'):list(q.iter_metadata_batches(bins,score))


def test_real_parquet_null_validity_stops(tmp_path):
    bins,score=inputs(tmp_path,validity=[True,True,None,True,True])
    with pytest.raises(ValueError,match='missing values'):list(q.iter_metadata_batches(bins,score))


def test_real_parquet_complete_project_report(tmp_path):
    project=project_fixture(tmp_path)
    row=project['rows'][0];cfg,_=row_config(project,row);p=sample_layout(project,row)
    work=p['work'];work.mkdir(parents=True);(work/'he_fixed').mkdir()
    bins,score=inputs(tmp_path)
    bins.rename(work/'bins_raw.h5ad');score.rename(work/'bins_he.parquet')
    meta=work/'he_fixed/measurement.json';meta.write_text(json.dumps({'signature':'fixture','parameters':cfg['he_score']}))
    complete=work/'he_fixed/complete.json';complete.write_text(json.dumps({'signature':'fixture','outputs':[file_stamp(meta),file_stamp(work/'bins_he.parquet')]}))
    result=q.generate_bin_qc_review(project,['S1'],execute=True)
    assert result.iloc[0].n_bins==5 and Path(result.iloc[0].summary_json).is_file()
