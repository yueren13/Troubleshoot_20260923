"""Jupyter-widget Project Center. Browser controls call the same tested controller API.

No custom JavaScript extension, public HTTP server, or external asset CDN is used.
The widget frontend itself must be enabled by the user's Jupyter installation.
"""
from __future__ import annotations
import html, json
from pathlib import Path


def validate_choice_form(edits):
    import re
    errors=[];names=[]
    reserved={'region','instance_id','qc_keep','qc_class','total_counts'}
    for ident,c in edits.items():
        if not c['include_in_obs']:continue
        name=c['obs_name']
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',name) or name in reserved:errors.append(ident+': use a unique letters/numbers/underscore output name starting with a letter (not a core QC column).')
        names.append(name)
        if c['qc_use']=='exclude' and c['coverage_mode']=='positive_only':errors.append(ident+': exclusions require assessed negatives; choose complete-domain or defined coverage.')
    if len(names)!=len(set(names)):errors.append('Selected output names are duplicated.')
    if errors:raise ValueError('\n'.join(errors))
    return edits


def show_center(center):
    try:import ipywidgets as W
    except ImportError as exc:
        raise ImportError('Project state and HTML are available, but the live interface needs ipywidgets in this kernel. '
             'Install ipywidgets with your environment manager; JupyterLab may also need jupyterlab_widgets in its server environment. '
             'See docs/START_HERE.md. No scientific jobs were launched.') from exc
    from IPython.display import display,HTML
    from ..control.manifest import row_config,sample_layout,as_bool
    from ..annotations.workflow import read_assets
    from .state import now
    from . import asset_report_navigation as report_nav
    navigation_state={}  # Paths only; never approval flags or scientific state.
    state=center.snapshot();rows=state['project']['rows']
    style={'description_width':'180px'}
    wide=W.Layout(width='98%')
    sample=W.Dropdown(options=[(r['sample_id'],r['sample_key']) for r in rows],description='Sample',style=style,layout=wide)
    reviewer=W.Text(value='',description='Reviewer',placeholder='Your name / audit identifier',style=style,layout=wide)
    banner=W.HTML();status=W.Output(layout=W.Layout(border='1px solid #dce3eb',padding='12px',max_height='500px',overflow='auto'))
    tabs=W.Tab();buttons=[];forms={};active={'revision':state['revision']}
    def message(text):
        status.clear_output(wait=True)
        with status:print(text)
    def callback(fn,refresh=True):
        def run(_):
            for b in buttons:b.disabled=True
            status.clear_output(wait=True)
            try:
                with status:
                    result=fn()
                    if result is not None:
                        if isinstance(result,dict) and result.get('schema')=='vhd-project-center-1':
                            print('Saved project revision',result['revision'])
                            if result.get('history'):print(result['history'][-1]['event'])
                        elif isinstance(result,dict) and result.get('status') in ('approved','already_approved'):
                            print('Review saved. Annotation transfer has not run in this save operation.')
                            print('Accepted sources:',len(result.get('entries',[])))
                        elif isinstance(result,(dict,list)):print(json.dumps(result,indent=2,default=str)[:18000])
                        else:print(result)
            except Exception as exc:
                with status:print('NOT COMPLETED:',type(exc).__name__+' — '+str(exc))
            finally:
                for b in buttons:b.disabled=False
                if refresh:build()
        return run
    def button(text,fn,*,refresh=True,kind=''):
        b=W.Button(description=text,button_style=kind,layout=W.Layout(width='auto',min_width='180px'))
        b.on_click(callback(fn,refresh));buttons.append(b);return b
    def open_stage(stage):
        return button('Open '+stage.replace('_',' ')+' report',lambda:center.view(sample.value,stage),refresh=False)
    def table_html(records,columns):
        if not records:return '<p>No entries.</p>'
        body='<table style="width:100%;font-size:13px"><tr>'+''.join('<th style="text-align:left">'+html.escape(c)+'</th>' for c in columns)+'</tr>'
        for r in records:body+='<tr>'+''.join('<td style="padding:6px;border-bottom:1px solid #eee">'+html.escape(str(r.get(c,'')))+'</td>' for c in columns)+'</tr>'
        return body+'</table>'
    def build(change=None):
        d=center.snapshot();project=d['project'];r=center.row(sample.value,project);key=r['sample_key'];cfg,spec=row_config(project,r)
        active['revision']=d['revision'];buttons.clear()
        banner.value='<div style="padding:22px;background:#15304c;color:white;border-radius:12px"><h2 style="color:white;margin:0">'+html.escape(d['title'])+'</h2><p>Project Center 0.5.0rc1 • Saved revision '+str(d['revision'])+' • '+html.escape(d['updated_at'])+'</p><p>View → save reviewed decisions → explicitly run. The HTML export is read-only.</p></div>'
        # Overview and route controls
        endpoint=W.Dropdown(options=[('QC bins only (no annotation transfer)','qc_bins'),('Bins with configured asset review','bins'),('QC cells','cells'),('Independent clustered cells','clustered'),('Publish cell products','publish')],value=d['endpoints'][key],description='Endpoint',style=style,layout=wide)
        select_many=W.SelectMultiple(options=sample.options,value=(key,),description='Run samples',style=style,layout=W.Layout(width='98%',height='110px'))
        run_ack=W.Checkbox(value=False,description='I reviewed this plan and want to run the ready work.',indent=False)
        store_ack=W.Checkbox(value=False,description='These are the intended masters; no other job/viewer is accessing the same stores.',indent=False)
        def run_ready():
            return center.run_until_review(list(select_many.value),confirmed=run_ack.value)
        route_records=center.plan([key])
        start=W.Dropdown(options=[('Automatic: engine verifies earlier results','auto')]+[(x['label'],x['action']) for x in route_records],description='Resume point',style=style,layout=wide)
        resume_ack=W.Checkbox(value=False,description='Existing prerequisites have been inspected; do not mark skipped steps newly complete.',indent=False)
        overview=W.VBox([
            W.HTML('<h3>Route and progress</h3><p>No job starts merely by opening this page. Existing results are inventoried, not silently certified.</p>'),
            W.HTML('<details><summary>Sample metadata and inputs</summary><pre>'+html.escape(json.dumps({'metadata':r.get('_sample_metadata',{}),'starting_material':r['stage'],'space_ranger':r.get('spaceranger_outs'),'image':r.get('segmentation_image'),'bin_input':r.get('bin_input'),'cell_input':r.get('cell_input')},indent=2))+'</pre></details>'),
            W.HTML(table_html(route_records,['label','status','reason'])),endpoint,
            button('Save endpoint',lambda:center.set_endpoint(key,endpoint.value)),start,resume_ack,
            button('Save resume selection',lambda:center.select_resume(key,start.value,acknowledge_existing=resume_ack.value)),
            W.HTML('<details><summary>Write destinations</summary><pre>'+html.escape(json.dumps({rr['sample_id']:str(sample_layout(project,rr)['store']) for rr in project['rows']},indent=2))+'</pre></details>'),store_ack,
            button('Confirm intended writers',lambda:center.acknowledge_writer(confirmed=store_ack.value)),select_many,run_ack,
            button('Run until next review',run_ready,kind='success'),
            W.HTML('<p>Runs are synchronous in this kernel. Use Jupyter Interrupt to stop your submitted action; do not delete incomplete files or lock files. Logs and state remain inspectable.</p>'),
            button('Refresh progress / reports',center.refresh),button('Test browser connection',center.frontend_check),
            W.HTML('<p>Frontend check: '+html.escape(str(d.get('frontend_check',{})))+'</p>')])
        # Bin QC
        q=cfg['bin_qc'];tissue=W.Text(value='' if q.get('tissue_score_threshold') is None else str(q['tissue_score_threshold']),description='Tissue-score cutoff',style=style,layout=wide)
        tx=W.Text(value='' if q.get('transcript_threshold') is None else str(q['transcript_threshold']),description='Transcript cutoff',style=style,layout=wide)
        cq=W.Checkbox(value=False,description='I reviewed bin-to-original-H&E alignment.',indent=False)
        bq=W.Checkbox(value=False,description='I reviewed the thresholds and resulting bin QC classes.',indent=False)
        bins=W.VBox([W.HTML('<h3>Bin QC</h3><p>Count cutoffs are in the configured metric units, not plot log coordinates. Both tissue-high transcript classes remain eligible.</p>'),
            open_stage('bin_qc'),button('Generate histograms / scatter',lambda:center.build_qc_distributions(key)),tissue,tx,
            button('Save cutoff values',lambda:center.save_bin_settings(key,tissue_score=float(tissue.value),transcripts=float(tx.value),expected_revision=active['revision'])),
            W.HTML('<p>A changed cutoff after completed QC is not force-overwritten in this release. Use a separate reviewed run for a new classification revision. Accepting unchanged cutoffs does not rerun H&E.</p>'),cq,bq,
            button('Save bin / coordinate review',lambda:center.accept_review(key,'review_bins',reviewer=reviewer.value,confirmed=cq.value and bq.value))])
        # Assets: exact generated category identities, friendly editable choices.
        try:assets=read_assets(r.get('assets_manifest'),r['dataset_id'],r['sample_id'])
        except Exception as exc:assets=[];message(str(exc))
        children=[W.HTML('<h3>Annotations and staining</h3><p>Geometry proposal → explicit acceptance → category discovery → H&amp;E gallery → reviewed usage → transfer. Discovery is an inventory, not a plot or import. Report preselection never grants approval.</p>')]
        if not assets:children.append(W.HTML('<p>No assets configured for this sample. This stage is not applicable.</p>'))
        else:
            nav=navigation_state.setdefault(key,{'gallery':None,'repair':{}})
            report_inventory=report_nav.inventory(center,key,assets=assets)
            def generate_he_gallery():
                before={x['summary'] for x in report_inventory['he']}
                nav['gallery_blocked']=True;nav['gallery']=None
                result=center.generate_asset_gallery(key)
                current=report_nav.inventory(center,key)
                new=[x for x in current['he'] if x['summary'] not in before]
                if not new:
                    raise RuntimeError('No newly completed current H&E gallery was indexed. Do not approve an older report. Details: '+json.dumps(current['unavailable'],default=str))
                nav['gallery']=new[0]['summary'];nav['gallery_blocked']=False
                print('H&E gallery prepared and selected, NOT approved:',nav['gallery'])
                return result
            children.extend([button('Discover category names',lambda:center.discover(key)),button('Generate H&E asset gallery',generate_he_gallery),open_stage('assets'),button('Refresh report selectors',center.refresh)])
            children.append(W.HTML(report_nav.status_html(report_inventory)))
            if nav.get('gallery_blocked'):children.append(W.HTML('<p><b>The last gallery request did not produce a new current report.</b> See Latest operation; regenerate or explicitly choose an existing matching report. Nothing was approved.</p>'))
            choices=center.choices(key);forms.clear();extent={};hints={};modes={}
            draft=d.get('drafts',{}).get(key,{})
            for c in choices:
                previous=draft.get('edits',{}).get(c['asset_id']+'/'+c['item_key'],{})
                c.update({k:str(v).lower() if isinstance(v,bool) else str(v) for k,v in previous.items()})
            galopts=report_nav.selector_options(report_inventory['he'])
            selected_gallery=None if nav.get('gallery_blocked') else report_nav.choose(report_inventory['he'],nav.get('gallery') or draft.get('gallery'))
            gallery=W.Dropdown(options=galopts,value=selected_gallery,description='Reviewed gallery',style=style,layout=wide)
            gallery_acknowledgements=[]
            def remember_gallery(change):
                nav['gallery']=change['new']
                if change['new']:nav['gallery_blocked']=False
                for control in gallery_acknowledgements:control.value=False
            gallery.observe(remember_gallery,names='value')
            children.append(gallery)
            gallery_info=W.HTML()
            def show_alignment_summary(change=None):
                try:
                    g=json.loads(Path(gallery.value).read_text()) if gallery.value else {}
                    details=[]
                    for source in g.get('sources',[]):
                        alignment=source.get('alignment',{});pix=source.get('pixel_summary',{})
                        details.append({'source':source['asset_id'],'shown':source['status'],
                            'source_to_reference':source.get('source_to_display_reference'),
                            'raw_range':[pix.get('min'),pix.get('max')],'raw_dtype':pix.get('dtype'),
                            'alignment_notes':alignment.get('warnings',[]),
                            'note':'This is the saved gallery; current hint/interpretation controls are checked when Save is pressed.'})
                    gallery_info.value='<details open><summary>Selected gallery: displayed transform and raw signal</summary><pre>'+html.escape(json.dumps(details,indent=2))+'</pre></details>'
                except Exception as exc:gallery_info.value='<p>'+html.escape(str(exc))+'</p>'
            gallery.observe(show_alignment_summary,names='value');show_alignment_summary();children.append(gallery_info)
            # Selecting a report displays it, but does not approve it.
            def gallery_show():
                return report_nav.show_report(center,key,gallery.value,kind='he')
            children.append(button('View selected full gallery',gallery_show,refresh=False))
            coverage_options=[('Positive regions only; elsewhere unassessed','positive_only'),('Complete assessed domain; unmarked is negative','exhaustive'),('Separate assessed-area polygon','polygon')]
            for a in assets:
                aid=a['asset_id'];children.append(W.HTML('<h4>'+html.escape(aid)+' • '+html.escape(a['kind'])+'</h4><p class="path">'+html.escape(a['path'])+'</p>'))
                if a['kind']=='signal':
                    hints[aid]=W.Text(value=str(draft.get('scale_hints',{}).get(aid,a.get('scale_hint')) or ''),description='Expected scale hint',style=style,layout=wide)
                    modes[aid]=W.Dropdown(options=[('Keep declared encoding','as_configured'),('Use stored numeric values (no threshold)','native'),('Exact binary codes 0 / 1','binary_01'),('Exact binary codes 0 / 255','binary_0255')],value=draft.get('signal_interpretations',{}).get(aid,'as_configured'),description='Signal interpretation',style=style,layout=wide)
                    selected_choices=[c for c in choices if c['asset_id']==aid]
                    active_choices=[c for c in selected_choices if as_bool(c['include_in_obs'])]
                    ext=bool(active_choices) and all(as_bool(c['same_extent_confirmed']) for c in active_choices)
                    ext=draft.get('extent_confirmations',{}).get(aid,ext)
                    extent[aid]=W.Checkbox(value=ext,description='I confirm the same physical field of view and orientation as H&E (auto-extent only).',indent=False)
                    children.extend([hints[aid],modes[aid],extent[aid]])
                for c in choices:
                    if c['asset_id']!=aid:continue
                    ident=aid+'/'+c['item_key']
                    use=W.Checkbox(value=as_bool(c['include_in_obs']),description='Save in bin .obs',indent=False)
                    qc=W.Dropdown(options=[('Analysis only','none'),('Segmentation inclusion','include'),('Segmentation exclusion','exclude')],value=c['qc_use'] or 'none',layout=W.Layout(width='240px'))
                    name=W.Text(value=c['obs_name'],description='Column',layout=W.Layout(width='330px'))
                    cov=W.Dropdown(options=coverage_options,value=c['coverage_mode'],layout=W.Layout(width='480px'))
                    methods=W.Text(value=c['signal_methods'],description='Bin summaries',placeholder='mean;median;sum;min;max',layout=wide)
                    cell=W.Text(value=c['cell_methods'],description='Cell summaries',placeholder='optional: fraction;majority for polygons',layout=wide)
                    forms[ident]=(use,qc,name,cov,methods,cell)
                    children.append(W.VBox([W.HTML('<b>'+html.escape(c['category'])+'</b>'),W.HBox([use,qc,name]),cov,
                                *( [methods] if a['kind']=='signal' else []),cell],layout=W.Layout(border='1px solid #dce3eb',padding='10px',margin='6px 0')))
            reviewed=W.Checkbox(value=False,description='I inspected this gallery and accept the selected category use / signal interpretation.',indent=False)
            gallery_acknowledgements.append(reviewed)
            def save_assets():
                if not gallery.value:raise ValueError('Choose the reviewed visual-first gallery.')
                edits={ident:{'include_in_obs':f[0].value,'qc_use':f[1].value,'obs_name':f[2].value,'coverage_mode':f[3].value,
                              'signal_methods':f[4].value,'cell_methods':f[5].value} for ident,f in forms.items()}
                validate_choice_form(edits)
                return center.save_asset_review(key,gallery_summary=gallery.value,edits=edits,
                    extent_confirmations={aid:v.value for aid,v in extent.items()},signal_interpretations={aid:v.value for aid,v in modes.items()},
                    scale_hints={aid:(float(v.value) if v.value.strip() else None) for aid,v in hints.items()},
                    reviewer=reviewer.value,confirmed=reviewed.value,expected_revision=active['revision'])
            children.extend([reviewed,button('Save reviewed asset usage',save_assets,kind='success')])
            if key in d['drafts']:children.append(W.HTML('<pre>Previous save draft / error:\n'+html.escape(json.dumps(d['drafts'][key],indent=2))+'</pre>'))
            # Existing geometry-review code is exposed through this same page.
            pol=[a['asset_id'] for a in assets if a['kind']=='polygons']
            if pol:
                ga=W.Dropdown(options=pol,description='Geometry source',style=style,layout=wide)
                repair_pick=W.Dropdown(options=[],description='Repair report',style=style,layout=wide)
                review_path=W.Text(description='Repair review JSON',placeholder='Generated / discovered report path; manual entry remains available',style=style,layout=wide)
                confirm_geo=W.Checkbox(description='I accept all listed polygon pieces, holes and negative regions.',indent=False)
                remove_lines=W.Checkbox(description='I explicitly allow removal of reviewed standalone line remnants.',indent=False)
                def remember_repair(change):
                    nav['repair'][ga.value]=change['new']
                    confirm_geo.value=False;remove_lines.value=False
                review_path.observe(remember_repair,names='value')
                def select_repair(change):
                    review_path.value=change['new'] or ''
                repair_pick.observe(select_repair,names='value')
                def refresh_repair_choice(change=None):
                    records=report_inventory['geometry'].get(ga.value,[])
                    selected=report_nav.choose(records,nav['repair'].get(ga.value))
                    repair_pick.options=[(x['label'],x['summary']) for x in records] or [('No matching proposal: generate repair review',None)]
                    repair_pick.value=selected
                    review_path.value=selected or ''
                    confirm_geo.value=False;remove_lines.value=False
                ga.observe(refresh_repair_choice,names='value');refresh_repair_choice()
                def generate_repair():
                    result=center.generate_geometry_review(key,ga.value)
                    path=str(Path(result['report_dir'])/'review_summary.json')
                    current=report_nav.inventory(center,key)
                    if path not in [x['summary'] for x in current['geometry'].get(ga.value,[])]:
                        raise RuntimeError('Generated proposal could not be selected; inspect: '+json.dumps(current['unavailable'],default=str))
                    nav['repair'][ga.value]=path
                    print('Repair report selected, NOT accepted:',path)
                    return result
                def accept_repair():
                    result=center.accept_geometry(key,ga.value,review_path.value,reviewer=reviewer.value,confirm_all=confirm_geo.value,remove_lines=remove_lines.value)
                    nav['gallery']=None
                    print('Geometry activated only. Next: Discover category names, then Generate H&E asset gallery. Alignment and usage are NOT approved.')
                    return result
                box=W.VBox([ga,button('Generate repair review',generate_repair),repair_pick,review_path,
                    button('View selected repair gallery',lambda:report_nav.show_report(center,key,review_path.value,kind='geometry',asset_id=ga.value),refresh=False),
                    W.HTML('<p>This repair report uses XML coordinates, not H&amp;E. After explicit acceptance, generate a separate H&amp;E gallery. All approval boxes stay unchecked.</p>'),confirm_geo,remove_lines,
                    button('Accept / activate derivative',accept_repair)])
                acc=W.Accordion(children=[box]);acc.set_title(0,'Optional invalid-geometry review (not required for an accepted derivative)');acc.selected_index=None;children.append(acc)
        asset_tab=W.VBox(children)
        # Later review reports
        later=[]
        for stage,gate,desc in [('segmentation','review_prior','I inspected the StarDist prior and its QC support.'),('cells','review_cells','I inspected cell QC / boundaries and accept these cells for further analysis.')]:
            check=W.Checkbox(description=desc,indent=False)
            later.extend([W.HTML('<h3>'+stage.title()+'</h3>'),open_stage(stage),check,
                          button('Save '+stage+' review',lambda g=gate,c=check:center.accept_review(key,g,reviewer=reviewer.value,confirmed=c.value))])
        cells_tab=W.VBox(later)
        # Analysis: independent default; opt-in group path separate.
        an=d['analysis_settings'];aid=W.Text(value=an['analysis_id'],description='Analysis revision',style=style,layout=wide)
        nh=W.IntText(value=int(an['n_hvg']),description='HVG count',style=style);np_=W.IntText(value=int(an['n_pcs']),description='PCA components',style=style)
        target=W.FloatText(value=float(an['target_sum']),description='Normalize target',style=style)
        analysis=[W.HTML('<h3>Independent clustering</h3><p>Endpoint "Independent clustered cells" uses one sample at a time: configured analysis QC → normalize/log1p → PCA → Leiden 0.1–1.0 → one UMAP colored for each resolution. No batch correction; the master counts are untouched. This is separate from scVI integration.</p>'),
            W.HTML('<details><summary>Effective analysis-QC settings</summary><pre>'+html.escape(json.dumps(cfg.get('analysis_qc',{}),indent=2))+'</pre></details>'),aid,nh,np_,target,
            button('Save independent settings',lambda:center.save_analysis_settings({'analysis_id':aid.value,'n_hvg':nh.value,'n_pcs':np_.value,'target_sum':target.value,'seed':an['seed']})),open_stage('clustering')]
        cluster_ack=W.Checkbox(description='I reviewed the clustering reports; clusters are not automatically cell types.',indent=False)
        analysis.extend([cluster_ack,button('Save clustering review',lambda:center.accept_review(key,'review_clustering',reviewer=reviewer.value,confirmed=cluster_ack.value))])
        group_name=W.Text(description='Integration group',style=style);group_samples=W.SelectMultiple(options=sample.options,description='Members',style=style,layout=wide)
        joint=W.Checkbox(description='I explicitly request joint scVI analysis of these compatible samples.',indent=False)
        groups=sorted({rr['integration_group'] for rr in project['rows'] if rr['integration_group']})
        gd=W.Dropdown(options=groups,description='Existing group',style=style)
        phase=W.Dropdown(options=['analysis_qc','prepare','train','cluster','diagnostics','writeback'],description='Phase',style=style)
        joint_run=W.Checkbox(description='Execute the selected group phase (not just preview).',indent=False)
        def group_view():
            if not gd.value:raise ValueError('No group configured.')
            file=center.workspace/'html/groups'/gd.value/'clustering.html'
            if not file.is_file():raise FileNotFoundError('No group summary generated yet.')
            display(HTML('<iframe sandbox="" style="width:100%;height:800px" srcdoc="'+html.escape(file.read_text(),quote=True)+'"></iframe>'))
        group_box=W.VBox([W.HTML('<p>Opt-in group scVI / RAPIDS route. Human3 groups remain blank unless deliberately assigned. Run phases in displayed order. Existing GPU policy and model handoff checks remain.</p>'),group_name,group_samples,joint,
               button('Define joint group',lambda:center.define_integration_group(group_name.value,list(group_samples.value),confirmed=joint.value)),gd,
               button('Preview group analysis',lambda:center.integration_plan(gd.value),refresh=False),phase,joint_run,
               button('Run selected group phase',lambda:center.run_integration(gd.value,phase.value,confirmed=joint_run.value)),button('Open group HTML',group_view,refresh=False)])
        group_acc=W.Accordion(children=[group_box]);group_acc.set_title(0,'Optional joint scVI integration');group_acc.selected_index=None;analysis.append(group_acc)
        # Resource / report controls
        lim=d.get('resource_limits',{});workers=W.IntText(value=int(lim.get('max_workers',project['settings']['execution']['cpu']['workers'])),description='Max sample workers',style=style)
        threads=W.IntText(value=int(lim.get('threads_per_job',8)),description='Threads per worker',style=style)
        resource_children=[W.HTML('<h3>Resources</h3><p>Detected eligible CPU, RAM and GPUs are used when launching. Unknown per-job RAM still limits the engine to one pilot. Allocation is not an OS reservation. Alternate worker environments receive import/GPU checks.</p>'),
             button('Detect available resources',center.hardware),W.HTML('<pre>'+html.escape(json.dumps(d.get('resources',{}),indent=2))+'</pre>'),workers,threads,
             button('Save resource caps',lambda:center.set_resource_limits({'max_workers':workers.value,'threads_per_job':threads.value})),
             W.HTML('<h3>Report location</h3><p>'+html.escape(str(center.workspace/'html/project_review.html'))+'</p><p>Fixed HTML summaries are refreshed after controller actions. Raw source folders are not served publicly.</p>'),
             button('Refresh all HTML summaries',center.refresh),button('Open project HTML',lambda:center.view(),refresh=False)]
        running_actions=[name for name,j in d['jobs'].get(key,{}).items() if j.get('status')=='running']
        if running_actions:
            stopped=W.Checkbox(description='I inspected this worker and confirm it has stopped. Do not kill or delete anything.',indent=False)
            recover_action=W.Dropdown(options=running_actions,description='Interrupted action',style=style)
            resource_children.extend([W.HTML('<h4>Interrupted-session recovery</h4>'),recover_action,stopped,button('Record that worker has stopped',lambda:center.acknowledge_stopped_job(key,recover_action.value,confirmed=stopped.value,reviewer=reviewer.value))])
        runtime_fields={k:W.Text(value=str(project['settings']['execution'].get(k,'current')),description=k,style=style,layout=wide) for k in ('python_spatial','python_stardist','python_scvi','python_rapids')}
        runtime_fields['proseg_executable']=W.Text(value=str(project['settings']['proseg']['executable']),description='Proseg executable',style=style,layout=wide)
        rt=W.Accordion(children=[W.VBox(list(runtime_fields.values())+[button('Save worker locations',lambda:center.save_runtime_settings({k:w.value for k,w in runtime_fields.items()}))])]);rt.set_title(0,'Advanced: executable environments');rt.selected_index=None
        resource_children.append(rt)
        from ..compute.startup_support import validate_startup_settings,RUNTIME_PATCH_ID
        startup_settings=validate_startup_settings(d.get('startup_settings',{}))
        startup_fields={
            'stardist_import_timeout_seconds':W.IntText(value=int(startup_settings['stardist_import_timeout_seconds']),description='StarDist startup seconds',style=style),
            'python_import_timeout_seconds':W.IntText(value=int(startup_settings['python_import_timeout_seconds']),description='Other imports seconds',style=style),
            'executable_timeout_seconds':W.IntText(value=int(startup_settings['executable_timeout_seconds']),description='Proseg CLI check seconds',style=style),
            'shared_cache_root':W.Text(value=startup_settings['shared_cache_root'],description='Startup cache directory',style=style,layout=wide),
        }
        startup_ack=W.Checkbox(value=False,description='Save startup settings; do not launch jobs or alter scientific parameters.',indent=False)
        def save_startup():
            return center.save_startup_settings({k:w.value for k,w in startup_fields.items()},confirmed=startup_ack.value)
        startup_box=W.Accordion(children=[W.VBox([
            W.HTML('<p>'+html.escape(RUNTIME_PATCH_ID)+': startup deadlines do not limit inference time. Blank cache directory uses each sample scratch; an explicit separate directory shares Matplotlib cache across samples. No import checks are skipped.</p>'),
            *startup_fields.values(),startup_ack,button('Save startup settings',save_startup)])])
        startup_box.set_title(0,'Advanced: startup checks and cache');startup_box.selected_index=None
        resource_children.append(startup_box)
        resources=W.VBox(resource_children)
        tabs.children=[overview,bins,asset_tab,cells_tab,W.VBox(analysis),resources]
        for i,title in enumerate(['Overview / Run','Bin QC','Annotations / Signals','Segmentation / Cells','Clustering','Resources / Reports']):tabs.set_title(i,title)
    sample.observe(build,names='value');build()
    app=W.VBox([banner,sample,reviewer,tabs,W.HTML('<h4>Latest operation / detailed messages</h4>'),status])
    display(app)
    return app


def launch_setup(root):
    """Display the one-time import / reopen form. Nothing writes until its button is clicked."""
    try:
        import ipywidgets as W
    except ImportError as exc:
        raise ImportError(
            'The live Project Center needs ipywidgets in the current notebook kernel. '
            'Use your approved environment manager to add ipywidgets>=8,<9. '
            'If JupyterLab runs in a separate environment, its server may need jupyterlab_widgets. '
            'No project was created or biological operation started. See docs/START_HERE.md.'
        ) from exc
    from IPython.display import display,HTML
    from .controller import ProjectCenter
    root=Path(root).resolve();old=root.parent/'VisiumHD_Pipeline_v4_1_1_human'/'config'
    default=old if old.is_dir() else root/'examples/current_human3/config'
    result={};style={'description_width':'190px'};layout=W.Layout(width='98%')
    mode=W.Dropdown(options=[('Open an existing Project Center','open'),('Import existing pipeline configuration (current pilot)','import'),
                             ('Create a new project from sample and asset sheets','sheets')],value='import',description='Operation',style=style,layout=layout)
    workspace=W.Text(value=str(root.parent/'VisiumHD_Project_Center'),description='Controller workspace',style=style,layout=layout)
    title=W.Text(value='Visium HD Project Center',description='Project title',style=style,layout=layout)
    manifest=W.Text(value=str(default/'samples.csv'),description='Existing samples.csv',style=style,layout=layout)
    settings=W.Text(value=str(default/'settings.json'),description='Existing settings.json',style=style,layout=layout)
    sample_sheet=W.Text(value=str(root/'examples/new_project/samples.csv'),description='Sample sheet',style=style,layout=layout)
    asset_sheet=W.Text(value=str(root/'examples/new_project/assets.csv'),description='Asset sheet (optional)',style=style,layout=layout)
    output_root=W.Text(value='',description='Approved output root',placeholder='Existing project directory; no mount is created',style=style,layout=layout)
    profile=W.Text(value='',description='Settings profile (optional)',style=style,layout=layout)
    run=W.Text(value='run01',description='New-project run ID',style=style,layout=layout)
    metadata=W.Text(value='',description='Metadata CSV (optional)',style=style,layout=layout)
    meta_id=W.Text(value='sample_id',description='Metadata ID column',style=style,layout=layout)
    import_box=W.VBox([manifest,settings]);new_box=W.VBox([sample_sheet,asset_sheet,metadata,meta_id,output_root,profile,run])
    consent=W.Checkbox(value=False,description='Create managed copies in this workspace; keep the original inputs unchanged.',indent=False)
    messages=W.Output();live=W.Output();button=W.Button(description='Open / create Project Center',button_style='primary',layout=W.Layout(width='auto'))
    def fields(change=None):
        import_box.layout.display='flex' if mode.value=='import' else 'none'
        new_box.layout.display='flex' if mode.value=='sheets' else 'none'
        consent.layout.display='none' if mode.value=='open' else 'flex'
    mode.observe(fields,names='value');fields()
    def start(_):
        button.disabled=True;messages.clear_output(wait=True)
        try:
            with messages:
                w=Path(workspace.value).expanduser()
                if not workspace.value.strip():raise ValueError('Choose the controller workspace.')
                if mode.value=='open':center=ProjectCenter.open(w)
                else:
                    if not consent.value:raise ValueError('Confirm creation of managed configuration copies first.')
                    if mode.value=='import':
                        center=ProjectCenter.import_config(manifest.value,settings.value,w,title=title.value)
                    else:
                        center=ProjectCenter.from_sheets(sample_sheet.value,asset_sheet.value or None,output_root.value,w,
                            profile=profile.value or None,run_id=run.value,title=title.value,
                            metadata_table=metadata.value or None,metadata_id_column=meta_id.value)
                result['center']=center
                print('Project opened:',center.workspace)
                print('No scientific job has been launched. Use Test browser connection, then inspect the project and reports.')
            live.clear_output(wait=True)
            with live:result['app']=center.show()
        except Exception as exc:
            with messages:print('NOT OPENED:',type(exc).__name__+' — '+str(exc))
        finally:button.disabled=False
    button.on_click(start)
    form=W.VBox([W.HTML('<h2>Open your Project Center</h2><p>Use the current pilot import once. Reopen the same workspace thereafter. '
        'Keep the controller state on a filesystem supporting file locks and atomic replacement (your fast local work drive is suitable to test). '
        'Scientific data and reports retain their configured destinations. No mount operations are performed.</p>'),mode,workspace,title,import_box,new_box,consent,button,messages,live])
    display(form);result['form']=form;return result
