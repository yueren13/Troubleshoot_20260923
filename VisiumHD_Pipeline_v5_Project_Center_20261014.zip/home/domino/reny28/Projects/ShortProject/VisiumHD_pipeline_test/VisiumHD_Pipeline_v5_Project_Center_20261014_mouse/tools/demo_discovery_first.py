"""Small non-biological demonstration of discovery and native signal summaries.

This does not create a SpatialData store, run segmentation, or approve real data.
It leaves the generated review CSV unselected and shows synthetic choices in a
separate file. Use a NEW output directory; no existing results are overwritten.
"""
from __future__ import annotations
import argparse,csv,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))


def run(output):
    import pandas as pd
    import tifffile
    from PIL import Image
    from vhd.annotations.workflow import read_assets,polygons,MeasurementRaster
    from vhd.annotations.discovery import discover_one,atomic_choices,read_choices,expand_choices,review_prior_settings
    from vhd.annotations.alignment import resolve_alignment
    from vhd.annotations.raster import open_raster
    from vhd.annotations.area_sampling import summarize_footprints
    from vhd.annotations.geometry import classify_polygons
    from vhd.annotations.transfer import segmentation_decisions
    out=Path(output).expanduser().absolute()
    if out.exists():raise FileExistsError(f'Choose a NEW demo folder: {out}')
    out.mkdir(parents=True)
    def region(points,negative=False):
        return '<Region NegativeROA="'+('1' if negative else '0')+'"><Vertices>'+''.join(f'<V X="{x}" Y="{y}"/>' for x,y in points)+'</Vertices></Region>'
    def annotation(name,points,extra=''):
        return f'<Annotation Name="{name}"><Regions>'+region(points)+extra+'</Regions></Annotation>'
    a=out/'sample.annotations'
    a.write_text('<Annotations>'+annotation('Tissue',[(-.5,-.5),(35.5,-.5),(35.5,35.5),(-.5,35.5)])+
        annotation('Necrosis',[(17.5,17.5),(35.5,17.5),(35.5,35.5),(17.5,35.5)])+
        annotation('Region name with comma, case A',[(-.5,-.5),(17.5,-.5),(17.5,35.5),(-.5,35.5)])+
        annotation('Keep spatially only',[(4,4),(8,4),(8,8),(4,8)])+'</Annotations>')
    native=np.array([[0,0,255,255],[0,255,255,0],[255,255,0,0],[0,0,0,255]],np.uint8)
    signal=out/'signal.tif';tifffile.imwrite(signal,native)
    reference=out/'reference.png';Image.fromarray(np.full((36,36,3),240,np.uint8)).save(reference)
    with Image.open(reference) as im:w,h=im.size
    geometry={'image':{'width':w,'height':h,'path':str(reference)},'tenx_to_image':np.eye(3).tolist(),
              'grid_index_to_fullres':[[2,0,.5],[0,2,.5],[0,0,1]]}
    sources=[{'sample_id':'Demo','asset_id':'pathology','kind':'polygons','path':str(a),'format':'imagescope_xml',
              'registration_mode':'reference_pixels','scale_hint':'','pixel_convention':'','axes':'','signal_type':'',
              'positive_value':'','negative_value':'','coverage_mode':'exhaustive'},
             {'sample_id':'Demo','asset_id':'stain','kind':'signal','path':str(signal),'format':'tiff',
              'registration_mode':'auto_extent','scale_hint':'9','pixel_convention':'edges','axes':'yx','signal_type':'binary',
              'positive_value':'255','negative_value':'0','coverage_mode':'exhaustive'}]
    with (out/'assets.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(sources[0]));writer.writeheader();writer.writerows(sources)
    assets=read_assets(out/'assets.csv','Project','Demo');choices=[];reports=[]
    for asset in assets:
        items,report=discover_one(asset,geometry,'Project__Demo');choices+=items;reports.append(report)
    atomic_choices(out/'asset_choices.csv',choices)
    # Simulated reviewer decisions are separate; no approval hash is fabricated.
    chosen=read_choices(out/'asset_choices.csv')
    for c in chosen:
        if c['category']=='Tissue':c.update(include_in_obs='true',qc_use='include',obs_name='is_tissue')
        elif c['category']=='Necrosis':c.update(include_in_obs='true',qc_use='exclude',obs_name='is_necrosis')
        elif c['category']=='Region name with comma, case A':c.update(include_in_obs='true',obs_name='region_A',cell_methods='fraction;majority')
        elif c['category']=='__signal__':c.update(include_in_obs='true',obs_name='stain',signal_methods='mean;median;sum;min;max',same_extent_confirmed='true')
    atomic_choices(out/'demo_selected_choices.csv',chosen)
    compiled=[]
    for asset in assets:
        asset['review_table']=str(out/'demo_selected_choices.csv')
        compiled+=expand_choices(resolve_alignment(asset,geometry),geometry,require_approval=False)
    prior=review_prior_settings(compiled,{'mode':'from_review','unknown_policy':'exclude'})
    y,x=np.mgrid[.5:36:2,.5:36:2];xy=np.c_[x.ravel(),y.ravel()]
    obs=pd.DataFrame({'pxl_col_in_fullres':xy[:,0],'pxl_row_in_fullres':xy[:,1],'qc_keep':True},index=[f'demo_bin_{i}' for i in range(len(xy))])
    for item in compiled:
        if item['kind']=='polygons':
            g=polygons(item);g=g[g.name.isin(item['categories'])]
            c=classify_polygons(xy,g,categories=item['categories'])
            obs[item['_output_column']]=c[item['categories'][0]].array
        else:
            with open_raster(item['path'],item['axes'],item['channel']) as field:
                measured=MeasurementRaster(field,item)
                results=summarize_footprints(measured,xy,source_to_fullres=item['source_to_fullres'],
                    bin_basis_fullres=np.diag([2,2]),methods=item['_signal_methods'])
            for name,value in results.items():obs['stain__'+name]=value
    decisions=segmentation_decisions(obs,prior)
    obs=obs.join(decisions);obs.to_csv(out/'demo_bin_obs.csv')
    expected_positive=float((native==255).sum());observed=float(obs['stain__sum'].sum())
    if not np.isclose(expected_positive,observed):raise AssertionError('Fractional sum failed source-pixel conservation.')
    if 'Keep spatially only' in obs:raise AssertionError('Ignored category unexpectedly transferred.')
    result={'demo':'synthetic only; no RNA/SpatialData/GPU execution', 'n_categories_discovered':4,
        'n_source_rows':2,'n_unselected_review_rows':len(choices),'n_synthetic_bins':len(obs),
        'fractional_binary_sum':observed,'expected_native_positive_pixels':expected_positive,
        'scale':reports[1]['alignment'],'observed_category_names':[c['category'] for c in choices if c['category']!='__signal__'],
        'actual_master_write_tested':False,'real_data_approved':False,'all_initial_choices_unselected':all(c['include_in_obs']=='false' for c in choices)}
    (out/'discovery_reports.json').write_text(json.dumps(reports,indent=2))
    (out/'demo_result.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2));print('Review CSV (unselected):',out/'asset_choices.csv');print('Illustrative bin obs:',out/'demo_bin_obs.csv')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    run(parser.parse_args().output)
