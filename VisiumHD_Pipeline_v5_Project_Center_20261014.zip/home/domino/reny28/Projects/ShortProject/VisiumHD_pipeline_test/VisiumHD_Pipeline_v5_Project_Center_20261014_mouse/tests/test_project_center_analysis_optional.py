"""Opt-in real scientific execution on a tiny synthetic stored AnnData cell table.
No full-scale dataset or GPU. Skipped when any required package is missing.
"""
from pathlib import Path
import pytest
ad=pytest.importorskip('anndata');sc=pytest.importorskip('scanpy');pytest.importorskip('pyarrow');pytest.importorskip('igraph');pytest.importorskip('zarr')
import numpy as np,pandas as pd
from scipy import sparse
from vhd.center import ProjectCenter
from vhd.center.state import file_fingerprint
from vhd.control.manifest import sample_layout
from vhd.center.single_sample import run_individual


def test_independent_analysis_preserves_source(tmp_path):
    from test_visual_approval_bridge import setup
    s=setup.__wrapped__(tmp_path);c=ProjectCenter.import_config(s['manifest'],s['settings'],tmp_path/'center')
    p=sample_layout(c.project,c.row('A'));store=p['store']/'tables/cells';store.parent.mkdir(parents=True)
    rng=np.random.default_rng(42);x=rng.poisson(2,(60,40));x[:,0]=0
    a=ad.AnnData(sparse.csr_matrix(x),obs=pd.DataFrame({'qc_pass':True},index=[f'c{i}' for i in range(60)]),
        var=pd.DataFrame({'gene_symbol':['MT-TEST']+[f'G{i}' for i in range(1,40)]},index=[f'ENSG{i}' for i in range(40)]))
    a.obsm['spatial']=rng.uniform(0,10,(60,2));a.write_zarr(store)
    before={str(f.relative_to(store)):file_fingerprint(f) for f in store.rglob('*') if f.is_file()}
    project=c.project;project['settings']['analysis_qc']['enabled']=True
    project['settings']['plots']['dpi']=65
    project['rows'][0]['_sample_metadata']['species']='human'
    result=run_individual(project,'Project__A',{'analysis_id':'tiny','n_hvg':40,'n_pcs':8,'target_sum':10000,'seed':42})
    assert result['batch_correction'] is False and result['master_modified'] is False
    out=ad.read_h5ad(result['embedding_output']);assert out.n_vars==0 and out.n_obs==60
    assert len([n for n in out.obs if n.startswith('leiden_')])==10
    assert before=={str(f.relative_to(store)):file_fingerprint(f) for f in store.rglob('*') if f.is_file()}
    assert len(list(Path(result['embedding_output']).parent.glob('UMAP_leiden_*.png')))==10
