"""Read-only VHD transfer implementation/configuration snapshot.

Run in a JupyterLab terminal while the controller kernel is busy:
    /path/to/your/python VHD_Collect_Transfer_Performance_Evidence.py

Reads small source/configuration/report files, NEVER images, Zarr arrays or count
matrices. Does not import vhd, call asset_specification, checksum the stain, launch
or attach to workers, stop a process, change config, or alter a lock/transaction.
Only a new timestamped diagnostic folder is written. Evidence is a live snapshot,
not a guarantee of a coherent completed store or a function-level profile.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shlex
import socket
import sys
import time
import uuid
import zipfile

DEFAULT_PACKAGE = Path('/home/domino/reny28/Projects/ShortProject/VisiumHD_pipeline_test/VisiumHD_Pipeline_v5_Project_Center_20261009_human')
DEFAULT_SAMPLE = 'Project__BM0164135A_s1_A1'
DEFAULT_REPORT = Path('/stash/results/dev/reny28/2026/VisiumHD_pipeline_test/work/vhd/Project/BM0164135A_s1_A1/run01/reports')
MAX_SMALL_BYTES = 8 * 1024**2
SOURCE_LIMIT = 48 * 1024**2
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')


def collect(package_root=DEFAULT_PACKAGE, report_dir=DEFAULT_REPORT,
            sample=DEFAULT_SAMPLE, output_root=None):
    package_root, report_dir = Path(package_root).expanduser().resolve(), Path(report_dir).expanduser().resolve()
    base = Path(output_root or (Path.cwd() / 'vhd_transfer_performance_evidence')).expanduser().resolve()
    forbidden = [report_dir.parent]
    for p in forbidden:
        if base == p or base.is_relative_to(p):
            raise ValueError('Write diagnostics in the code/notebook directory, not inside the sample work root.')
    if any('.zarr' in part or part.endswith('.vhd_transactions') for part in base.parts):
        raise ValueError('Diagnostic output must be outside any master store or transaction tree.')
    tag = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    out = base / tag
    out.mkdir(parents=True, exist_ok=False)
    report = dict(schema='vhd-transfer-performance-source-review-1', sample=sample,
                  package_root=str(package_root), report_dir=str(report_dir),
                  time_utc=tag, host=socket.gethostname(), collector_pid=os.getpid(),
                  python=sys.executable, records=[],
                  limitations=['Static source plus small live reports; not function-level timing.',
                               'Metadata can change during collection and may describe a previous attempt.',
                               'Local process information does not cover other hosts/containers.',
                               'No scientific array, image, expression matrix or source signal is read.',
                               'No process/state/configuration/transaction is modified.'])
    source_bytes = 0

    def small(path, dest, kind='source'):
        nonlocal source_bytes
        p = Path(path)
        entry = dict(path=str(p), kind=kind, archive_member=dest)
        report['records'].append(entry)
        try:
            st = p.stat()
            if not p.is_file():
                entry['status'] = 'not_a_regular_file'; return None
            if st.st_size > MAX_SMALL_BYTES or (kind == 'source' and source_bytes + st.st_size > SOURCE_LIMIT):
                entry.update(status='skipped_size_limit', size_bytes=st.st_size); return None
            with p.open('rb') as handle:
                data = handle.read(MAX_SMALL_BYTES + 1)
            if len(data) > MAX_SMALL_BYTES:
                entry['status'] = 'grew_beyond_limit'; return None
            end = p.stat()
            entry.update(status='read', size_bytes=len(data), mtime_ns=st.st_mtime_ns,
                         sha256=hashlib.sha256(data).hexdigest(),
                         stable_stat=(st.st_size, st.st_mtime_ns) == (end.st_size, end.st_mtime_ns))
            d = out / dest; d.parent.mkdir(parents=True, exist_ok=True); d.write_bytes(data)
            if kind == 'source': source_bytes += len(data)
            return data
        except Exception as exc:
            entry.update(status='unavailable', error=f'{type(exc).__name__}: {exc}')
            return None

    fixed = ['vhd/annotations/workflow.py', 'vhd/annotations/raster.py',
             'vhd/annotations/geometry.py', 'vhd/annotations/area_sampling.py',
             'vhd/annotations/projective_sampling.py', 'vhd/annotations/discovery.py',
             'vhd/he/fixed.py', 'vhd/master.py', 'vhd/core.py', 'vhd/io.py',
             'vhd/images.py', 'vhd/projective_grid.py', 'vhd/compact_images.py',
             'vhd/sample_metadata.py', 'vhd/adapters/assemble.py',
             'vhd/compute/launch.py', 'vhd/center/resources.py',
             'vhd/control/manifest.py', 'vhd/control/paths_v3.py', 'vhd/control/storage.py',
             'docs/STORAGE_POLICY.md']
    paths = set(fixed)
    for folder in ['vhd/annotations', 'vhd/he', 'vhd/persistence']:
        p = package_root / folder
        if p.is_dir():
            paths.update(str(f.relative_to(package_root)) for f in p.rglob('*.py') if f.is_file())
    for rel in sorted(paths): small(package_root / rel, 'sources/' + rel)

    # Read only a bounded tail of the live log, plus its first command line.
    log = report_dir / 'worker_transfer_assets.log'
    launch_command = []
    try:
        with log.open('rb') as f:
            first = f.readline(65536).decode('utf-8', errors='replace')
            f.seek(0, 2); size = f.tell(); f.seek(max(0, size - 96*1024))
            tail = f.read(96*1024).decode('utf-8', errors='replace')
        (out / 'worker_transfer_assets_log_tail.txt').write_text(ANSI.sub('', tail))
        report['log_snapshot'] = dict(path=str(log), size_bytes=size, tail_only=size>96*1024,
                                      mtime_ns=log.stat().st_mtime_ns, first_line=ANSI.sub('', first))
        launch_command = shlex.split(ANSI.sub('', first))
    except Exception as exc:
        report['log_snapshot_error'] = f'{type(exc).__name__}: {exc}'
    for name in ['status_transfer_assets.json', 'worker_transfer_assets.resources.json',
                 'assets_preview.json', 'assets_transfer.json', 'master_sources.json', 'he_master.json']:
        small(report_dir / name, 'reports/' + name, 'report')
    if report_dir.is_dir():
        for p in sorted(report_dir.glob('asset_*.json'))[:100]:
            small(p, 'reports/' + p.name, 'report')
    small(report_dir.parent / 'work' / 'geometry.json', 'reports/geometry.json', 'report')

    # The first worker-log line records its exact resolved project. No new plan is generated.
    try:
        if '--project' in launch_command:
            project_path = Path(launch_command[launch_command.index('--project') + 1])
            b = small(project_path, 'config/worker_resolved_project.json', 'config')
            if b:
                project = json.loads(b)
                rows = [r for r in project.get('rows', []) if r.get('sample_key') == sample]
                report['selected_project_rows'] = rows
                for row in rows:
                    if row.get('overrides_json'):
                        small(Path(row['overrides_json']), 'config/sample_overrides.json', 'config')
                    manifest = row.get('assets_manifest')
                    if manifest:
                        m = Path(manifest)
                        bb = small(m, 'config/assets_manifest.csv', 'config')
                        candidates = {m.parent / 'asset_choices.csv'}
                        if bb:
                            for asset in csv.DictReader(io.StringIO(bb.decode('utf-8-sig'))):
                                if asset.get('sample_id') != row.get('sample_id'): continue
                                if asset.get('dataset_id') and asset.get('dataset_id') != row.get('dataset_id'): continue
                                if asset.get('review_table'):
                                    q = Path(asset['review_table']); candidates.add(q if q.is_absolute() else m.parent/q)
                        for i, q in enumerate(sorted(candidates, key=str)):
                            small(q, f'config/asset_choices_{i:02d}.csv', 'config')
    except Exception as exc:
        report['config_inspection_error'] = f'{type(exc).__name__}: {exc}'

    # Optional short sampling of recognizable local worker processes. No attach/signals.
    try:
        import psutil
        matches = []
        for proc in psutil.process_iter(['pid', 'cmdline', 'create_time']):
            try:
                cmd = proc.info['cmdline'] or []
                if 'vhd.compute.worker' not in cmd: continue
                if '--sample' not in cmd or cmd[cmd.index('--sample')+1] != sample: continue
                if '--action' not in cmd or cmd[cmd.index('--action')+1] != 'transfer_assets': continue
                matches.append(proc)
            except (psutil.Error, IndexError): pass
        def snap(proc):
            data = dict(pid=proc.pid)
            try:
                data.update(create_time=proc.create_time(), status=proc.status(),
                            rss_bytes=proc.memory_info().rss, num_threads=proc.num_threads(),
                            cpu_time_seconds=proc.cpu_times().user+proc.cpu_times().system)
                try: data['io_counters']=proc.io_counters()._asdict()
                except psutil.Error: pass
            except psutil.Error as exc: data['error']=str(exc)
            return data
        first = [snap(p) for p in matches]
        begin = time.monotonic()
        if matches: time.sleep(3)
        elapsed = time.monotonic()-begin
        second = [snap(p) for p in matches]
        report['local_worker_samples'] = dict(interval_seconds=elapsed, first=first, second=second,
            note='Main worker only, not aggregate child/thread profiling. CPU seconds/elapsed is approximate cores used. '
                 'IO counters are OS counters, not necessarily network/mounted-object-store throughput.')
    except ImportError:
        report['local_worker_samples'] = {'status':'psutil_not_installed_in_collector_interpreter'}
    except Exception as exc:
        report['process_inspection_error'] = f'{type(exc).__name__}: {exc}'

    (out / 'collection_report.json').write_text(json.dumps(report, indent=2, default=str))
    archive = out / 'VHD_transfer_performance_evidence.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file() and p != archive:
                z.write(p, str(p.relative_to(out)))
    print('Created:', archive)
    print('No pipeline, scientific-store, configuration, journal, or lock changes were made.')
    print('Inspect archive before sharing; it contains code/configuration paths and report text, not image/count arrays.')
    return archive


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package-root', type=Path, default=DEFAULT_PACKAGE)
    ap.add_argument('--report-dir', type=Path, default=DEFAULT_REPORT)
    ap.add_argument('--sample', default=DEFAULT_SAMPLE)
    ap.add_argument('--output-root', type=Path)
    args = ap.parse_args()
    collect(args.package_root, args.report_dir, args.sample, args.output_root)
