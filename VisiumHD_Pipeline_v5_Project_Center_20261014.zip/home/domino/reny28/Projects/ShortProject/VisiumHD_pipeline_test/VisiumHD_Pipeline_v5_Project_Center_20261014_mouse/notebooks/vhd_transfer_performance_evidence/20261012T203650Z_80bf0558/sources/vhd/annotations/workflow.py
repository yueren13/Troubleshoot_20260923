"""Optional assets CSV, review barriers, and replacement of source-owned annotations."""
from __future__ import annotations
import csv,json,re
from xml.etree.ElementTree import ParseError
from pathlib import Path
import numpy as np
import pandas as pd
from .geometry import read_imagescope_annotation_xml,transform_polygons,classify_polygons,membership
from .raster import open_raster,spatial_image
from .transfer import segmentation_decisions
from ..core import sample_paths,file_stamp,digest,dump_json,affine,transform_xy
from ..control.manifest import path_value,as_bool

COLUMNS=['enabled','dataset_id','sample_id','asset_id','kind','path','format','axes','channel','category_column','categories','source_to_fullres','coverage_mode','coverage_path','bin_method','cell_methods','role','units','reviewed_signature']


OPTIONAL_ASSET_COLUMNS = ['signal_type','positive_value','negative_value','nodata_value','notes',
    'registration_mode','scale_hint','scale_tolerance','pixel_convention','landmarks_path',
    'max_landmark_error_px','review_table','min_valid_fraction']
ROLE_ALIASES = {'exclusion':'segmentation_qc','biological':'analysis','signal':'analysis'}
ROLES = ('segmentation_qc','analysis','both','reference_only','discover')


def read_assets(path,dataset,sample):
    """Read old v4 assets or discovery-first sources. dataset_id is optional.

    In the simple format only sample_id, asset_id, kind and path are required.
    Default role=discover means no transfer until per-item choices are approved.
    """
    if not path:return []
    path=Path(path);out=[]
    with path.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f);headers=reader.fieldnames
        required={'sample_id','asset_id','kind','path'}
        if not headers or len(headers)!=len(set(headers)) or not required<=set(headers) or set(headers)-set(COLUMNS)-set(OPTIONAL_ASSET_COLUMNS):
            raise ValueError('Asset sources need sample_id, asset_id, kind, path; use the v4.1 template for optional columns.')
        for line,raw in enumerate(reader,2):
            if None in raw or any(v is None for v in raw.values()):raise ValueError(f'Malformed asset CSV row {line}.')
            row={k:v.strip() for k,v in raw.items()}
            if not as_bool(row.get('enabled',''),True) or row['sample_id']!=sample or (row.get('dataset_id') and row['dataset_id']!=dataset):continue
            for key in COLUMNS+OPTIONAL_ASSET_COLUMNS:row.setdefault(key,'')
            row['dataset_id']=row['dataset_id'] or dataset
            row['role']=ROLE_ALIASES.get(row['role'],row['role']) or 'discover'
            if row['role'] not in ROLES:raise ValueError(f'role must be one of {ROLES}')
            if row['role']=='reference_only' and row['cell_methods']:raise ValueError('reference_only must have blank cell_methods.')
            if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',row['asset_id']):raise ValueError('asset_id must be a safe identifier.')
            if row['kind'] not in ('polygons','signal'):raise ValueError('kind describes data type: polygons or signal. Purpose is selected after discovery.')
            if row['source_to_fullres']:
                row['source_to_fullres']=affine([float(x) for x in row['source_to_fullres'].split(';')]).tolist()
                row['registration_mode']=row['registration_mode'] or 'explicit'
                if row['registration_mode']!='explicit':raise ValueError('Use source_to_fullres OR another registration_mode, not both.')
            else:
                row['registration_mode']=row['registration_mode'] or ''
                if row['registration_mode'] not in ('reference_pixels','auto','auto_extent','landmarks'):
                    raise ValueError('Declare registration_mode (e.g. reference_pixels or auto_extent), or an explicit source_to_fullres affine.')
            for k in ('path','coverage_path','landmarks_path','review_table'):row[k]=path_value(row[k],path.parent)
            if not row['path'] or row['path'].startswith('s3://'):raise ValueError('Use a mounted/staged asset path, not implicit object-store access.')
            row['_manifest_path']=str(path.resolve())
            if row['role']=='discover':row['review_table']=row['review_table'] or str(path.parent.resolve()/'asset_choices.csv')
            row['categories']=[x for x in row['categories'].split(';') if x];row['cell_methods']=[x for x in row['cell_methods'].split(';') if x]
            row['coverage_mode']=row['coverage_mode'] or ('positive_only' if row['kind']=='polygons' else 'exhaustive')
            if row['coverage_mode'] not in ('exhaustive','positive_only','polygon'):raise ValueError('coverage_mode must be explicit.')
            if row['coverage_mode']=='polygon' and not row['coverage_path']:raise ValueError('Explicit coverage polygon needed.')
            if row['kind']=='polygons':
                row['category_column']=row['category_column'] or 'name';row['bin_method']=row['bin_method'] or 'membership'
                if row['bin_method'] not in ('membership','categorical') or set(row['cell_methods'])-{'fraction','majority'}:raise ValueError('Polygon membership/categorical mode and fraction/majority cell methods required.')
            else:
                row['axes']=row['axes'] or 'yx'
                row['bin_method']=row['bin_method'] or 'area_mean'
                allowed=('center_nearest','center_linear','area_mean','area_median','area_sum','area_max','area_min')
                if row['bin_method'] not in allowed or set(row['cell_methods'])-{'sum','mean','median','max','min'}:raise ValueError('Invalid single-channel signal aggregation method.')
                if row['coverage_mode']=='positive_only':raise ValueError('Signal validity uses image/coverage extent, not pixel positivity.')
                row['signal_type']=row['signal_type'] or 'continuous'
                if row['signal_type'] not in ('continuous','binary'):raise ValueError('signal_type is continuous or binary.')
                if row['signal_type']=='binary':
                    if row['bin_method']=='center_linear':raise ValueError('Binary signals require center_nearest or explicit area summaries, not linear interpolation.')
                    for key in ('positive_value','negative_value'):
                        if row[key]=='':raise ValueError('Declare binary positive_value and negative_value (1/0 or 255/0).')
                        row[key]=float(row[key])
                    if row['positive_value']==row['negative_value'] or not np.isfinite([row['positive_value'],row['negative_value']]).all():raise ValueError('Invalid binary encoding.')
                if row['nodata_value']:
                    row['nodata_value']=float(row['nodata_value'])
                    if row['signal_type']=='binary' and row['nodata_value'] in (row['positive_value'],row['negative_value']):raise ValueError('NoData must differ from both binary codes.')
            row['channel']=int(row['channel']) if row['channel'] else None
            if row['min_valid_fraction']!='':
                row['min_valid_fraction']=float(row['min_valid_fraction'])
                if not 0<=row['min_valid_fraction']<=1:raise ValueError('min_valid_fraction must be in [0,1].')
            out.append(row)
    if len({r['asset_id'] for r in out})!=len(out):raise ValueError('Duplicate per-sample asset ID.')
    return out


def fingerprint(path):
    from ..persistence.transaction import inventory
    return {'path':str(Path(path).resolve()),'files':inventory(path)}


def alignment_signature(asset,geometry):
    if '_alignment' not in asset:
        from .alignment import resolve_alignment
        asset=resolve_alignment(asset,geometry)
    return digest({'source':fingerprint(asset['path']),'coverage':fingerprint(asset['coverage_path']) if asset['coverage_path'] else None,
        'transform':asset['source_to_fullres'],'axes':asset['axes'],'channel':asset['channel'],'category_column':asset['category_column'],'reference_geometry':geometry,
        'landmarks':fingerprint(asset['landmarks_path']) if asset.get('landmarks_path') else None,
        'alignment_policy':asset.get('_alignment',{}),
        'value_interpretation':{k:asset.get(k) for k in ('signal_type','positive_value','negative_value','nodata_value','units','min_valid_fraction')}})


def active_assets(assets):
    # Unselected discovery sources do not silently become computational inputs.
    from .discovery import has_active_choices
    return [a for a in assets if a['role']!='reference_only' and (a['role']!='discover' or has_active_choices(a))]


def asset_specification(cfg,spec):
    from .alignment import resolve_alignment
    from .discovery import expand_choices,review_prior_settings
    p=sample_paths(cfg,spec);geometry=json.loads(p['geometry'].read_text())
    sources=read_assets(spec['_row'].get('assets_manifest'),spec['dataset_id'],spec['sample_id'])
    assets=[];signatures=[]
    for source in active_assets(sources):
        source=resolve_alignment(source,geometry)
        source_sig=alignment_signature(source,geometry)
        items=expand_choices(source,geometry,source_signature=source_sig) if source['role']=='discover' else [source]
        assets.extend(items);signatures.extend([source_sig]*len(items))
    scientific=[{k:v for k,v in a.items() if k not in ('reviewed_signature','enabled','notes','_manifest_path','review_table')} for a in assets]
    prior=review_prior_settings(assets,cfg.get('prior_filter',{}))
    return (assets,digest({'algorithm':'annotations-v4.1-discovery-footprints','assets':scientific,'sources':signatures,
                          'base_qc':file_stamp(p['bin_obs']),'prior':prior}),signatures)


def validate_prior_sources(assets,settings):
    if not settings.get('enabled',False):return
    required=list(settings.get('tissue_columns',[])) or ([settings['tissue_column']] if settings.get('tissue_column') else [])
    required+=list(settings.get('exclude_columns',[]))
    for column in required:
        matches=[a for a in assets if column==a.get('_output_column') or (not a.get('_output_column') and column.startswith(a['asset_id']+'__'))]
        if len(matches)!=1 or matches[0]['role'] not in ('segmentation_qc','both'):
            raise ValueError(f'Prior column {column} is not owned by an active segmentation_qc/both category/source.')


def signal_values(value,asset):
    out=np.asarray(value,dtype=np.float32).copy()
    if asset.get('nodata_value','')!='':out[out==float(asset['nodata_value'])]=np.nan
    if asset.get('signal_type')=='binary':
        good=np.isfinite(out);pos=float(asset['positive_value']);neg=float(asset['negative_value'])
        if np.any(good & (out!=pos)&(out!=neg)):raise ValueError('Binary signal has undeclared measured pixel values. Fix encoding; do not threshold silently.')
        out[good]=(out[good]==pos).astype(np.float32)
    return out


class MeasurementRaster:
    """Convert declared binary/NoData values BEFORE interpolation, not afterward."""
    def __init__(self,raster,asset):self.raster=raster;self.asset=asset;self.shape=raster.shape
    def __getitem__(self,key):return signal_values(self.raster[key],self.asset)


def polygons(asset,coverage=False):
    import geopandas as gpd
    path=asset['coverage_path'] if coverage else asset['path']
    # Reviewed derivative: already composed within each XML Annotation; no geographic CRS.
    if str(path).endswith('.vhdpolygons.json') or (not coverage and asset.get('format') == 'reviewed_polygons_json'):
        from .reviewed_geometry import read_reviewed_polygons
        return read_reviewed_polygons(path)
    if str(path).lower().endswith(('.xml','.annotation','.annotations')) or (not coverage and asset['format']=='imagescope_xml'):return read_imagescope_annotation_xml(path)
    g=gpd.read_parquet(path) if str(path).endswith('.parquet') else gpd.read_file(path)
    if g.crs is not None:raise ValueError('Microscopy geometry has an unexpected geographic CRS. Review before explicitly removing it.')
    if not g.geometry.is_valid.all() or g.geometry.is_empty.any() or not g.geom_type.isin(['Polygon','MultiPolygon']).all():raise ValueError('Source has invalid/nonpolygon geometry.')
    g.index=g.index.astype(str);return g


def preview(asset,cfg,spec):
    from ..images import thumbnail
    import matplotlib.pyplot as plt
    from matplotlib.transforms import Affine2D
    p=sample_paths(cfg,spec);geometry=json.loads(p['geometry'].read_text()) if p['geometry'].exists() else json.loads((p['work']/'cell_geometry.json').read_text())['geometry'];image=geometry['image'];thumb=thumbnail(image,cfg['plots']['thumbnail_max_side'])
    transform=affine(geometry['tenx_to_image'])@affine(asset['source_to_fullres'])
    rois=[None]+list(cfg.get('annotations',{}).get('preview_rois_image_px',{}).values())
    for i,roi in enumerate(rois):
        fig,ax=plt.subplots(figsize=(11,9));ax.imshow(thumb,extent=(0,image['width'],image['height'],0))
        if asset['kind']=='polygons':
            g=transform_polygons(polygons(asset),transform)
            if len(g):g.boundary.plot(ax=ax,linewidth=.8)
        else:
            with open_raster(asset['path'],asset['axes'],asset['channel']) as r:
                h,w=r.shape;step=max(1,int(np.ceil(max(h,w)/1800)))
                ax.imshow(r[::step,::step],extent=(-.5,w-.5,h-.5,-.5),transform=Affine2D(transform)+ax.transData,alpha=.5)
        if 'grid_shape' in geometry:
            h,w=geometry['grid_shape'];corners=np.array([[-.5,-.5],[w-.5,-.5],[w-.5,h-.5],[-.5,h-.5],[-.5,-.5]])
            from ..projective_grid import project_xy
            corners=transform_xy(project_xy(corners,geometry['grid_index_to_fullres']),geometry['tenx_to_image'])
            ax.plot(corners[:,0],corners[:,1],linestyle='--',label='Capture grid');ax.legend()
        ax.set_xlim(0,image['width']);ax.set_ylim(image['height'],0)
        if roi is not None:ax.set_xlim(roi[0],roi[2]);ax.set_ylim(roi[3],roi[1])
        ax.set_title(f"{spec['sample']}: {asset['asset_id']} [{asset['role']}] — {'whole' if i==0 else 'ROI '+str(i)}")
        fig.savefig(p['report']/f"asset_{asset['asset_id']}_{i}.png",dpi=cfg['plots']['dpi'],bbox_inches='tight');plt.close(fig)


def import_assets(cfg,spec):
    import spatialdata as sd
    from spatialdata.models import ShapesModel
    from spatialdata.transformations import Affine
    from ..master import assemble_master
    from ..persistence import persist_changes
    from .raster import validate_signal_encoding
    p=sample_paths(cfg,spec)
    have_bins=p['bins'].exists()
    assemble_master(cfg,spec,bins_only=have_bins)
    geometry=json.loads(p['geometry'].read_text()) if p['geometry'].exists() else json.loads((p['work']/'cell_geometry.json').read_text())['geometry']
    assets=read_assets(spec['_row'].get('assets_manifest'),spec['dataset_id'],spec['sample_id']);records=[]
    for source in assets:
        from .alignment import resolve_alignment
        asset=source.copy()
        name='asset_'+asset['asset_id'];group='shapes' if asset['kind']=='polygons' else 'images'
        f=p['report']/f"asset_{asset['asset_id']}.json";old=json.loads(f.read_text()) if f.exists() else {}
        element=None
        # Catch ONLY source/parse errors for reference-only inputs. Persistence and
        # transaction errors below must always propagate, including ValueError.
        try:
            asset=resolve_alignment(source,geometry)
            sig=alignment_signature(asset,geometry)
            replace_needed=old.get('alignment_signature')!=sig or not (p['store']/group/name).exists()
            if replace_needed:
                if asset['kind']=='polygons':
                    parsed=polygons(asset)
                    if parsed.empty:raise ValueError('No polygon annotations found in source.')
                    element=ShapesModel.parse(parsed,transformations={'fullres':Affine(asset['source_to_fullres'],input_axes=('x','y'),output_axes=('x','y'))})
                else:
                    validate_signal_encoding(asset)
                    element=spatial_image(asset['path'],asset['axes'],asset['channel'],asset['source_to_fullres'],asset['asset_id'])
        except (ValueError,FileNotFoundError,ParseError) as exc:
            if asset['role']!='reference_only':raise
            record={**asset,'status':'reference_unparsed','element':None,'error':str(exc),
                    'previous_element_retained':name if (p['store']/group/name).exists() else None,
                    'downstream_enabled':False,'approval_at_import':False}
            dump_json(record,f);records.append(record);continue
        if replace_needed:
            sdata=sd.read_zarr(p['store'],selection=('images','labels','shapes','points'))
            getattr(sdata,group)[name]=element
            exists=(p['store']/group/name).exists()
            persist_changes(sdata,new_elements=[] if exists else [name],replace_elements=[name] if exists else [],policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=cfg['storage'].get('single_writer_ack',False))
        record={**asset,'alignment_signature':sig,'element':name,'status':'stored',
                'downstream_enabled':asset['role'] not in ('reference_only','discover'),'approval_at_import':asset['reviewed_signature']==sig}
        if 'image' in geometry:
            preview(asset,cfg,spec)
            if asset['kind']=='polygons' and asset['role']=='discover':
                from .preview_categories import preview_categories
                record['category_preview_files']=preview_categories(asset,cfg,spec,geometry)
            record['preview_status']='generated'
        else:
            record['preview_status']='unavailable_no_reference_image'
            if asset['role']!='reference_only':raise ValueError('Active assets require reference-image overlays for alignment review.')
        dump_json(record,f);records.append(record)
    # Registry lives in master attrs as well as reports. No raw expression is rewritten.
    from ..persistence.transaction import writer
    from ..persistence.spatial import open_group,refresh_metadata
    with writer(p['store'],cfg['storage_policy'],cfg['storage'].get('single_writer_ack',False)):
        root=open_group(p['store'],mode='a');root.attrs['vhd_assets']=records;refresh_metadata(p['store'])
    dump_json({'assets':records,'instruction':'Only active assets need source/transform-bound approval. reference_only is never used downstream.'},p['report']/'assets_preview.json')
    return records


def transfer_assets(cfg,spec):
    import shapely
    from ..he.fixed import sample_field
    from ..io import table_metadata
    from ..persistence import update_table_metadata
    from .discovery import review_prior_settings
    from .area_sampling import summarize_footprints
    p=sample_paths(cfg,spec);assets,sig,alignments=asset_specification(cfg,spec);receipt=p['report']/'assets_transfer.json';derived=p['work']/'bins_annotated_obs.parquet'
    old=json.loads(receipt.read_text()) if receipt.exists() else {}
    prior=review_prior_settings(assets,cfg.get('prior_filter',{}));validate_prior_sources(assets,prior)
    # A real visual-review approval may precede source storage. Complete/check the
    # actual import now; never manufacture 'stored' receipts merely to approve.
    from .visual_approval import ensure_transfer_sources
    ensure_transfer_sources(cfg,spec,assets,alignments,paths=p)
    if old.get('signature')==sig and derived.exists() and old.get('derived_stamp')==file_stamp(derived):return old
    geometry=json.loads(p['geometry'].read_text())
    out=pd.read_parquet(p['bin_obs']);xy=out[['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy();owned=[]
    specification={'categorical':{},'boolean':[],'continuous':{}}
    def add(key,values):
        if key in owned or key in out:raise ValueError(f'Annotation output collides with another output or source obs column: {key}')
        out[key]=values;owned.append(key)
    for a in assets:
        prefix=a['asset_id']+'__';coverage=None
        if a['coverage_path']:coverage=shapely.union_all(transform_polygons(polygons(a,True),a['source_to_fullres']).geometry.to_numpy())
        if a['kind']=='polygons':
            full=transform_polygons(polygons(a),a['source_to_fullres']);col=a['category_column'] or 'name'
            categories=a['categories'] or sorted(full[col].astype(str).unique())
            if set(categories)-set(full[col].astype(str)):raise ValueError('Selected category is absent from the source; rerun discovery.')
            g=full.loc[full[col].astype(str).isin(categories)].copy()
            if coverage is None and a['coverage_mode']=='positive_only':
                # Unselected categories must not silently define assessed negatives.
                coverage=shapely.union_all(g.geometry.to_numpy())
            classify_categories=categories
            if '_output_column' in a:
                # A discovered name such as 'assessed' must not overwrite an
                # internal coverage field. Source names remain unchanged on disk.
                g=g.copy();g[col]='__selected_category__';classify_categories=['__selected_category__']
            frame=classify_polygons(xy,g,category_column=col,categories=classify_categories,
                    coverage=coverage,exhaustive=a['coverage_mode']=='exhaustive',mode=a['bin_method'])
            for c in frame:
                safe=re.sub('[^A-Za-z0-9_]','_',str(c));key=prefix+safe
                if '_output_column' in a:key=a['_output_column']+('__assessed' if c=='assessed' else '')
                add(key,frame[c].array)
                if c!='assessed' and a['cell_methods']:
                    if a['bin_method']=='membership':
                        specification['boolean'].append(key);specification.setdefault('boolean_options',{})[key]={'methods':a['cell_methods']}
                    else:specification['categorical'][key]={'missing_values':['unassessed','unassigned']}
        else:
            modes=a.get('_signal_methods') or ([a['bin_method'][5:]] if a['bin_method'].startswith('area_') else [a['bin_method']])
            base=a.get('_output_column',a['asset_id'])
            new_style='_output_column' in a or a['bin_method'].startswith('area_')
            with open_raster(a['path'],a['axes'],a['channel']) as field:
                measured=MeasurementRaster(field,a)
                area_modes=[x for x in modes if x in ('mean','median','sum','min','max')]
                if area_modes:
                    if 'grid_index_to_fullres' not in geometry:raise ValueError('Area summaries require validated bin grid geometry; no guessed square footprint.')
                    coverage_source=None
                    if coverage is not None:
                        from shapely.affinity import affine_transform
                        m=np.linalg.inv(affine(a['source_to_fullres']));coverage_source=affine_transform(coverage,[m[0,0],m[0,1],m[1,0],m[1,1],m[0,2],m[1,2]])
                    from ..projective_grid import is_projective
                    options=dict(methods=area_modes,min_valid_fraction=float(a.get('min_valid_fraction') or 0),
                        coverage_source=coverage_source,**cfg.get('annotations',{}).get('area_sampling_options',{}))
                    if is_projective(geometry):
                        from .projective_sampling import summarize_projective_bins
                        summary=summarize_projective_bins(measured,out['array_row'].to_numpy(),out['array_col'].to_numpy(),
                            grid_index_to_fullres=geometry['grid_index_to_fullres'],
                            source_to_fullres=a['source_to_fullres'],**options)
                    else:
                        summary=summarize_footprints(measured,xy,source_to_fullres=a['source_to_fullres'],
                            bin_basis_fullres=affine(geometry['grid_index_to_fullres'])[:2,:2],**options)
                    for method in area_modes:
                        key=base+'__'+method;add(key,summary[method])
                        if a['cell_methods']:specification['continuous'][key]=a['cell_methods']
                    for key in ('in_bounds_fraction','valid_fraction','n_valid_pixels','valid'):add(base+'__'+key,summary[key])
                for mode in (x for x in modes if x.startswith('center_')):
                    value,inside,valid=sample_field(measured,xy,source_to_fullres=a['source_to_fullres'],interpolation=mode.split('_')[1])
                    if coverage is not None:valid &= membership(xy,coverage)
                    value[~valid]=np.nan
                    key=base+'__'+(mode if new_style else 'value');add(key,value)
                    for suffix,v in [('in_bounds',inside),('valid',valid)]:add(key+'__'+suffix if new_style else prefix+suffix,v)
                    if a['cell_methods']:specification['continuous'][key]=a['cell_methods']
    decisions=segmentation_decisions(out,prior)
    for key in decisions:
        if key in owned:raise ValueError('Category output collides with a segmentation decision column.')
        out[key]=decisions[key];owned.append(key)
    live,_=table_metadata(p['store'],'bins_2um');drop=[c for c in old.get('owned_columns',[]) if c not in owned and c in live]
    provenance={a['asset_id']:{k:v for k,v in a.items() if k!='reviewed_signature'} for a in assets}
    update_table_metadata(p['store'],'bins_2um',obs=out[owned],drop_obs=drop,uns={'vhd_annotation_sources_json':json.dumps(provenance,sort_keys=True)},
          policy=cfg['storage_policy'],staging_dir=p['work'],execute=True,single_writer_ack=cfg['storage'].get('single_writer_ack',False))
    out.to_parquet(derived)
    record={'signature':sig,'derived_stamp':file_stamp(derived),'owned_columns':owned,'transfer_spec':specification,
        'prior_filter':prior,'membership':'bin_centers',
        'continuous_measurement':'Per-field source provenance identifies center samples or exact pixel-overlap footprint summaries. Cell summaries aggregate those BIN measurements, not original image pixels.'}
    dump_json(record,receipt);return record
