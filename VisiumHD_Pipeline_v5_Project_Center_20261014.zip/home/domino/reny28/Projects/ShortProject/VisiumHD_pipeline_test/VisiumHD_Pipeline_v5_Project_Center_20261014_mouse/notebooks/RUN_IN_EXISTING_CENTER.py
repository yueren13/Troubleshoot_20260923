"""Run with %run -i RUN_IN_EXISTING_CENTER.py in the existing Center kernel.

Review CACHE_ROOT and ensure no concurrent launcher is using the selected GPU.
This file performs only runtime preparation; scientific execution is a separate
explicit call shown at the end. Do not reinitialize the Project Center here.
"""
from pathlib import Path
import vhd_stardist_startup as startup

SAMPLE = 'Project__BM0164135A_s1_A1'
CACHE_ROOT = Path(
    '/host_root/nethome/reny28/Projects/ShortProject/'
    'VisiumHD_pipeline_test/runtime_cache/stardist_startup'
)

if 'pc' not in globals():
    raise RuntimeError('Use the existing notebook kernel containing pc; do not create a new controller.')

STARTUP = startup.prepare(
    pc,
    sample=SAMPLE,
    cache_root=CACHE_ROOT,
    timeout_seconds=900,
    confirmed_no_other_launchers=True,
)

# After the above passes, separately authorize the actual StarDist action:
# result = startup.run_stardist(pc, STARTUP, confirmed=True)
