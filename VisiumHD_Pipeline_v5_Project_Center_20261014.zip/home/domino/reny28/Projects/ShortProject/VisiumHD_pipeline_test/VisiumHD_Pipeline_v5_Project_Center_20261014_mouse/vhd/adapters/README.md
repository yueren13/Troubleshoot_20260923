# adapters

Existing AnnData/SpatialData import with explicit count and coordinate selection.

See ../../docs/START_HERE.md and ../../docs/IMPLEMENTATION_STATUS.md. Source review and CPU tests are not target-environment validation.
