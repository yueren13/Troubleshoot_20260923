# v4.1 scope and validation limits

Implemented and exercised by CPU/numerical tests: discovery of real XML category
names, one-file mixed-use selection, category/source approval invalidation,
metadata mapping orchestration with explicitly stubbed scientific persistence,
overlap-safe independent memberships, QC union/exclusion rules, optional dataset
identity, actual dimension-based scale proposals, landmark fits, exact affine
pixel-overlap statistics and coverage, and cell summaries of bin metadata.

The new scalar writer targets bins_2um.obs through the existing metadata-only writer;
it does not write X. A real SpatialData roundtrip/count-byte-preservation test is
included but skipped here because the scientific dependencies are absent. Existing
v4 compact images, H&E scoring, resource launchers, scVI and persistence retain their
own validation requirements.

Not claimed: successful parsing of an unseen proprietary .annotations dialect;
actual calibration of the user's 1/9 signal; image-content auto-registration;
nonrigid warps; proof of correct crop/orientation from dimensions; automatic review;
independent resolution gained by assigning coarse pixels to smaller bins; physical
signal quantity from a unitless sum; pixel-pooled cell medians from bin medians;
automatic multi-channel multimodal data-layer design; arbitrary legacy store adoption;
full-slide speed or real GPU/model/approved-mount recovery validation.

The original historical Step03 bin-QC cutoffs and exact historical mismatch cause
remain unknown. New cutoffs are not invented. Missing boundaries do not become
whole-cell masks. A changed segmentation exclusion rule does not retroactively fix
an already accepted Proseg result.

Configuration examples are illustrative. CSV/settings validation under temporary
roots checks schema/routing only, not private filesystem visibility. Passing test
counts below refer to this exact source build, not a sum of earlier hotfix tests.
