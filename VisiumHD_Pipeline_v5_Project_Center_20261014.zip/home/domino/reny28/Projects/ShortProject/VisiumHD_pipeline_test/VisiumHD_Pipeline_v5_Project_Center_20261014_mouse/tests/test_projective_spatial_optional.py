"""Run on the target scientific environment BEFORE a large projective assembly.

Actual tiny AnnData, GeoParquet/SpatialData write/readback, compact-image assembly
and source-center/count preservation. No external source files or GPUs required.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
ad=pytest.importorskip('anndata')
sd=pytest.importorskip('spatialdata')
pytest.importorskip('pyarrow')
pytest.importorskip('dask')
from PIL import Image
from vhd.core import sample_paths,write_h5ad
from vhd.projective_grid import project_xy,fit_grid_model_checked,geometry_contract,grid_corners
from vhd.adapters.assemble import assemble,validate_product
from vhd.io import load_table,load_spatial_with_table


def test_actual_projective_compact_master_roundtrip(tmp_path):
    cfg={'work_root':str(tmp_path/'work'),'output_root':str(tmp_path/'output'),
         'cells':{'mode':'none'},'storage':{'image_policy':'compact','include_normalized_he':False,
          'include_nuclei_prior':False,'io_workers':1},'coordinates':{'grid_max_residual_px':.1}}
    image=tmp_path/'original.tif';Image.new('RGB',(64,64),'white').save(image)
    folder=tmp_path/'outs/binned_outputs/square_002um/spatial';folder.mkdir(parents=True)
    Image.new('RGB',(32,32),'white').save(folder/'tissue_hires_image.png')
    Image.new('RGB',(8,8),'white').save(folder/'tissue_lowres_image.png')
    (folder/'scalefactors_json.json').write_text(json.dumps({'tissue_hires_scalef':.5,'tissue_lowres_scalef':.125}))
    spec={'sample':'Fixture','dataset_id':'Test','sample_id':'Fixture','outs':str(tmp_path/'outs'),
          'image':str(image),'coordinates_reviewed':True,'metadata':{},'_row':{'stage':'raw','segmentation_image':str(image)}}
    p=sample_paths(cfg,spec)
    r,c=np.mgrid[:12,:15];r=r.ravel();c=c.ravel()
    h=np.array([[2,.2,1.5],[.1,2,1.5],[.007,-.005,1.]])
    xy=project_xy(np.c_[c,r],h);model,audit=fit_grid_model_checked(r,c,xy)
    assert audit['acceptance']=='validated_projective_polygons'
    obs=pd.DataFrame({'array_row':r,'array_col':c,'pxl_col_in_fullres':xy[:,0],
        'pxl_row_in_fullres':xy[:,1],'qc_keep':True},index=[f'bin{i}' for i in range(len(r))])
    counts=sparse.csr_matrix(np.tile([1,2,3],(len(r),1)),dtype=np.int32)
    a=ad.AnnData(X=counts,obs=obs.copy(),var=pd.DataFrame(index=['g1','g2','g3']))
    a.obsm['spatial']=xy.copy();a.obsm['spatial_image_px']=xy.copy()
    write_h5ad(a,p['bins']);obs.to_parquet(p['bin_obs'])
    geom={'grid_shape':[12,15],'grid_index_to_fullres':model.tolist(),'grid_fit':audit,
        'image':{'path':str(image),'width':64,'height':64,'mpp':[.25,.25]},
        'tenx_to_image':np.eye(3).tolist(),'source_mpp':.25,**geometry_contract(model)}
    p['geometry'].write_text(json.dumps(geom));(p['work']/'he_normalization.json').write_text('{}')
    original_counts=a.X.copy();original_xy=a.obsm['spatial'].copy()
    result=assemble(cfg,spec)
    assert result['bin_representation']=='projective_quadrilaterals'
    assert result['image_policy']=='compact' and result['n_bins']==len(r)
    b=load_table(p['store'],'bins_2um')
    assert (b.X!=original_counts).nnz==0
    np.testing.assert_array_equal(b.obsm['spatial'],original_xy)
    np.testing.assert_array_equal(b.obs[['pxl_col_in_fullres','pxl_row_in_fullres']],original_xy)
    s=load_spatial_with_table(p['store'],'bins_2um')
    assert 'bins_2um_polygons' in s.shapes and 'bins_2um_labels' not in s.labels
    assert set(s.images)=={'he_hires','he_lowres'}
    assert b.obs.region.astype(str).eq('bins_2um_polygons').all()
    assert validate_product(p['store'])['sampled_bin_vertex_max_error_px']<1e-7
