# GitHub record for this candidate

Repository: yueren13/Troubleshoot_20260923.
Foundation: pipeline/visiumhd-v2-foundation, f706a5bfb63f6256ddf8e08c1497725f37c50249.
The starting vhd/ implementation was taken from the supplied v2 archive; its git tree
is checked against e8ccb93e6323590aefe5c29b152474ec3def4c87 in the validation record.

Draft PR #3: fix/issue-2-scvi-handoff -> pipeline/visiumhd-v2-foundation.
It contains the state helper, worker integration, 12 CPU regression cases, and the CI
command update. It does not merge PR #1 or change main. Its real-model/GPU smoke test
remains required; issue #2 is not automatically closed.

The full v3 candidate is a separate deliverable in this ZIP, not a claim that every
v3 file is already uploaded to GitHub. This avoids mixing a broad untested storage
change into the narrow handoff fix. The package includes a helper-code git patch
against the foundation and a safe local repository preparation tool. Neither pushes,
merges, changes visibility, or rewrites Git history.

For a clean local copy of the foundation branch, create a new review branch first.
Run tools/prepare_repository_update.py with --repo and --source; it is preview-only
unless --apply is passed. It only adds/replaces files under visiumhd_pipeline and
refuses dirty repositories and protected/main branches. It never changes project_1.
Inspect git diff, run tests, and commit the review branch deliberately. Stale files
outside the new payload are preserved rather than automatically deleted.
