"""Small real filesystem fixtures for split image/JSON layouts; no user data."""
import copy
import json
from pathlib import Path
import sys
import types

import numpy as np
import pandas as pd
from PIL import Image
import pytest

from vhd.spaceranger_images import resolve_spaceranger_image, SPATIAL_SOURCE_PATCH
from vhd.he.source import resolve_he_source, diagnose_he_sources
from vhd.compact_images import compact_sources


def fixture(root, reverse=False):
    outs = root/'Sample01'/'outs'
    nested = outs/'binned_outputs/square_002um/spatial'
    outer = outs/'spatial'
    nested.mkdir(parents=True); outer.mkdir(parents=True)
    images, scales = (nested, outer) if reverse else (outer, nested)
    pixels = np.full((8, 10, 3), 220, np.uint8)
    pixels[2:5, 2:6] = [150, 90, 170]
    Image.fromarray(pixels).save(images/'tissue_hires_image.png')
    Image.fromarray(pixels[::2, ::2]).save(images/'tissue_lowres_image.png')
    scale_path = scales/'scalefactors_json.json'
    scale_path.write_text(json.dumps({'tissue_hires_scalef':0.25, 'tissue_lowres_scalef':0.125,
                                     'spot_diameter_fullres':7.91}))
    cfg = {'he_score': {'image_path':None, 'source_to_fullres':None, 'axes':'yxc',
                       'Io':255., 'intensity_range':[0,255], 'h_limit':1.9705, 'e_limit':1.0308,
                       'h_weight':1., 'e_weight':1., 'method':'soft_union', 'tile_size':3,
                       'interpolation':'linear', 'bin_chunk_size':2, 'alpha':'white'},
           'storage':{'image_policy':'compact'}, 'storage_policy':{'min_free_tmp_gib':0},
           'plots':{'dpi':40}}
    spec = {'sample':'P__Sample01', 'outs':str(outs),
            '_paths':{'work':str(root/'work'), 'report':str(root/'reports'),
                      'store':str(root/'master.zarr'), 'proseg':str(root/'proseg')}}
    return cfg, spec, images, scale_path, pixels


def snap(path):
    return {str(p.relative_to(path)):(p.read_bytes(), p.stat().st_mtime_ns)
            for p in path.rglob('*') if p.is_file()}


@pytest.mark.parametrize('reverse',[False,True])
@pytest.mark.parametrize('resolution,factor',[('hires',.25),('lowres',.125)])
def test_independent_resolution_both_directions(tmp_path, reverse, resolution, factor):
    cfg,spec,images,scales,_ = fixture(tmp_path,reverse)
    r = resolve_spaceranger_image(spec['outs'],resolution)
    assert r['image_path'] == str(images/f'tissue_{resolution}_image.png')
    assert r['scalefactors_path'] == str(scales)
    assert r['layout'] == 'split_spatial_layout' and not r['same_folder']
    assert r['selection_rule'] == 'split_files_within_same_outs'
    assert r['registration_verified'] is False
    np.testing.assert_array_equal(r['index_to_fullres'],np.diag([1/factor,1/factor,1]))
    json.dumps(r,allow_nan=False)


@pytest.mark.parametrize('reverse',[False,True])
def test_he_and_compact_share_same_hires_path_and_transform(tmp_path,reverse):
    cfg,spec,images,scales,_=fixture(tmp_path,reverse)
    path, matrix, origin = resolve_he_source(cfg,spec)
    records = compact_sources(cfg,spec)
    assert [r['name'] for r in records] == ['he_hires','he_lowres']
    assert records[0]['path'] == str(path)
    np.testing.assert_array_equal(records[0]['index_to_fullres'],matrix)
    for r in records:
        assert r['scalefactors']['path'] == str(scales)
        assert r['source_resolution']['implementation'] == SPATIAL_SOURCE_PATCH


def test_readonly_no_moving_copying_hashing_image_pixels_or_directory_creation(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    before=snap(tmp_path)
    conf=copy.deepcopy(cfg);sp=copy.deepcopy(spec)
    resolve_he_source(cfg,spec); compact_sources(cfg,spec)
    assert before == snap(tmp_path) and cfg==conf and spec==sp
    assert not (images/'scalefactors_json.json').exists()
    assert not (scales.parent/'tissue_hires_image.png').exists()
    assert not (tmp_path/'work').exists()


def test_independently_located_lowres(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    original=images/'tissue_lowres_image.png'
    original.rename(scales.parent/original.name)
    r=compact_sources(cfg,spec)
    assert Path(r[0]['path']).parent==images
    assert Path(r[1]['path']).parent==scales.parent
    assert r[0]['source_resolution']['layout']=='split_spatial_layout'
    assert r[1]['source_resolution']['layout']=='binned_002um'


def test_missing_lowres_blocks_compact_not_measurement(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    (images/'tissue_lowres_image.png').unlink()
    assert resolve_he_source(cfg,spec)[2]['layout']=='split_spatial_layout'
    with pytest.raises(FileNotFoundError,match='lowres'):
        compact_sources(cfg,spec)


def test_missing_lowres_scale_blocks_compact_not_measurement(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    scales.write_text('{"tissue_hires_scalef":0.25}')
    resolve_he_source(cfg,spec)
    with pytest.raises(ValueError,match='tissue_lowres_scalef'):
        compact_sources(cfg,spec)


@pytest.mark.parametrize('factor',[0,-.2,float('nan'),float('inf'),True,None,[],{},'unknown'])
def test_invalid_cross_folder_scale_rejected_without_guessing(tmp_path,factor):
    cfg,spec,images,scales,_=fixture(tmp_path)
    scales.write_text(json.dumps({'tissue_hires_scalef':factor}))
    with pytest.raises(ValueError,match='Invalid tissue_hires_scalef'):
        resolve_he_source(cfg,spec)


@pytest.mark.parametrize('text',['{','[]','{}','{"tissue_hires_scalef":0.25,"tissue_hires_scalef":0.2}'])
def test_invalid_cross_folder_json_rejected(tmp_path,text):
    cfg,spec,images,scales,_=fixture(tmp_path)
    scales.write_text(text)
    with pytest.raises(ValueError,match='Invalid tissue_hires_scalef'):
        resolve_he_source(cfg,spec)


def test_no_neighbor_sample_search(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    neighbor=Path(spec['outs']).parent.parent/'Sample02'/'outs'/'spatial'
    neighbor.mkdir(parents=True)
    scales.rename(neighbor/scales.name)
    with pytest.raises(FileNotFoundError):resolve_he_source(cfg,spec)


def test_no_lowres_substitution(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    (images/'tissue_hires_image.png').unlink()
    with pytest.raises(FileNotFoundError,match='No lowres/original-image substitution'):
        resolve_he_source(cfg,spec)


def test_broken_image_link_fallback_and_provenance(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    link=scales.parent/'tissue_hires_image.png'
    link.symlink_to('no_target.png')
    r=resolve_he_source(cfg,spec)[2]
    assert r['layout']=='split_spatial_layout' and link.is_symlink() and not link.exists()


def test_readable_image_symlink_is_not_rewritten(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    src=images/'tissue_hires_image.png';actual=images/'actual_hires.png'
    src.rename(actual);src.symlink_to('actual_hires.png')
    before=snap(tmp_path)
    assert resolve_he_source(cfg,spec)[0]==src
    assert src.is_symlink() and before==snap(tmp_path)


def test_explicit_image_does_not_use_automatic_scales(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    scales.write_text('not JSON')
    cfg['he_score'].update(image_path=str(images/'tissue_hires_image.png'),source_to_fullres=[2,0,5,0,3,7])
    _,matrix,r=resolve_he_source(cfg,spec)
    np.testing.assert_array_equal(matrix,[[2,0,5],[0,3,7],[0,0,1]])
    assert r['layout']=='explicit'


def test_explicit_compact_is_preserved(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    scales.write_text('not JSON')
    cfg['storage']['compact_images']={
        'he_'+suffix:{'path':str(images/f'tissue_{suffix}_image.png'),
                     'source_to_fullres':[2,0,5,0,3,7]}
        for suffix in ('hires','lowres')}
    records=compact_sources(cfg,spec)
    for r in records:np.testing.assert_array_equal(r['index_to_fullres'],[[2,0,5],[0,3,7],[0,0,1]])


def test_invalid_complete_pair_not_bypassed_by_other_folder(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    # A malformed paired root JSON must not be skipped in favor of binned scales.
    (images/'scalefactors_json.json').write_text('{"tissue_hires_scalef":-1}')
    with pytest.raises(ValueError,match='Invalid tissue_hires_scalef'):resolve_he_source(cfg,spec)


def test_split_diagnostic_reports_both_sources_ready_without_writes(tmp_path,monkeypatch):
    import vhd.control.manifest as m
    cfg,spec,images,scales,_=fixture(tmp_path)
    row={'sample_key':'P__Sample01','sample_id':'Sample01'}
    monkeypatch.setattr(m,'row_config',lambda project,row:(cfg,spec))
    monkeypatch.setattr(m,'sample_layout',lambda project,row:{'work':tmp_path/'work'})
    before=snap(tmp_path)
    r=diagnose_he_sources({'rows':[row]},['Sample01'])['P__Sample01']
    assert r['status']=='resolved'
    assert r['resolution']['scalefactors_path']==str(scales)
    assert r['resolution']['layout']=='split_spatial_layout'
    assert r['compact_master_source_check']['status']=='paths_resolved'
    assert not r['image_pixels_read'] and not r['expression_read'] and not r['data_or_config_written']
    assert before==snap(tmp_path) and not (tmp_path/'work').exists()


def test_split_measurement_real_png_npy_and_upstream_sentinels(tmp_path,monkeypatch):
    # Actual image calculation; H5 metadata and Parquet serialization are explicit stubs.
    from vhd.he.workflow import measure
    from vhd.he.fixed import extract_he_concentrations_reference, fixed_scale_he_tissue_score
    cfg,spec,images,scales,pixels=fixture(tmp_path)
    work=Path(spec['_paths']['work']);work.mkdir()
    (work/'bins_raw.h5ad').write_bytes(b'upstream matrix sentinel, not read')
    (work/'geometry.json').write_text('{"upstream":"not modified"}')
    old=snap(work)
    obs=pd.DataFrame({'pxl_col_in_fullres':[0.,4.,12.,200.],
                      'pxl_row_in_fullres':[0.,4.,12.,200.]},index=['b1','b2','b3','b4'])
    stub=types.ModuleType('vhd.io');stub.h5_metadata=lambda path:(obs.copy(),pd.DataFrame())
    monkeypatch.setitem(sys.modules,'vhd.io',stub)
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,path:self.to_pickle(path))
    r=measure(cfg,spec)
    h,e,_=extract_he_concentrations_reference(pixels,channel_axis=-1)
    score,_,_=fixed_scale_he_tissue_score(h,e)
    np.testing.assert_allclose(np.load(work/'he_fixed/he_tissue_score.npy'),score,atol=3e-7)
    assert r['source_resolution']['scalefactors_path']==str(scales)
    assert r['source_resolution']['layout']=='split_spatial_layout'
    for rel,val in old.items():assert (work/rel).read_bytes()==val[0]
    assert (work/'he_fixed/complete.json').is_file()
    bins=pd.read_pickle(work/'bins_he.parquet')
    assert list(bins.index)==list(obs.index)
    assert not bins.loc['b4','he_tissue_score_valid']


def test_recorded_scale_not_inferred_from_image_dimensions(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    scales.write_text('{"tissue_hires_scalef":0.03125,"tissue_lowres_scalef":0.015625}')
    _,matrix,_=resolve_he_source(cfg,spec)
    assert matrix[0,0]==32 and matrix[1,1]==32


def test_other_resolution_invalid_key_does_not_block_hires(tmp_path):
    cfg,spec,images,scales,_=fixture(tmp_path)
    scales.write_text('{"tissue_hires_scalef":0.25,"tissue_lowres_scalef":-2}')
    resolve_he_source(cfg,spec)
    with pytest.raises(ValueError,match='tissue_lowres_scalef'):compact_sources(cfg,spec)
