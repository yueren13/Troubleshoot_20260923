"""Plot-only review of existing fixed H&E/bin-count measurements.

No expression values or image pixels are read. Only selected obs datasets and
Parquet columns are scanned, twice, in chunks. Original bin order is checked.
This module does not choose/save thresholds or call the scientific classifier.
"""
from __future__ import annotations

from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import math
import numbers
import uuid

import numpy as np

PATCH = "bin-qc-review-plots-20261001-v1"
SCORE = "he_tissue_score"
VALID = "he_tissue_score_valid"
CLASSES = (
    "tissue-high_transcript-high", "tissue-high_transcript-low",
    "tissue-low_transcript-high", "tissue-low_transcript-low", "unassessed",
)


def _positive_int(value, name):
    if isinstance(value, bool) or not isinstance(value, numbers.Integral) or value < 1:
        raise ValueError(f"{name} must be a positive integer.")
    return int(value)


def _cutoff(value, name, upper=None):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        raise TypeError(f"{name} must be a number or None, not {value!r}.")
    value = float(value)
    if not math.isfinite(value) or value < 0 or (upper is not None and value > upper):
        raise ValueError(f"Invalid {name}: {value}.")
    return value


def _thresholds(settings, candidate=None):
    """Candidate values affect report overlays only, never PROJECT or JSON."""
    metric = settings.get("transcript_metric", "total_counts")
    transform = settings.get("transcript_transform", "identity")
    if not isinstance(metric, str) or not metric or "/" in metric:
        raise ValueError("transcript_metric must name a single obs column.")
    if transform not in ("identity", "log1p"):
        raise ValueError("The current classifier supports identity or log1p only.")
    chosen = dict(settings)
    if candidate is not None:
        if not isinstance(candidate, dict) or set(candidate) - {
            "tissue_score_threshold", "transcript_threshold"
        }:
            raise ValueError("candidate_thresholds accepts only the two bin-QC cutoff keys.")
        chosen.update(candidate)
    h = _cutoff(chosen.get("tissue_score_threshold"), "tissue_score_threshold", 1)
    t = _cutoff(chosen.get("transcript_threshold"), "transcript_threshold")
    raw = None
    if t is not None:
        if transform == "identity":
            raw = t
        else:
            if t >= math.log(np.finfo(float).max):
                raise ValueError("log1p transcript threshold has no finite raw equivalent.")
            raw = math.expm1(t)
    return {
        "metric": metric, "classifier_transform": transform,
        "tissue_score_threshold": h, "transcript_threshold": t,
        "transcript_threshold_raw_equivalent": raw,
        "origin": "plot_only_candidate" if candidate is not None else "effective_configuration",
        "comparison": ">=", "saved_to_configuration": False,
    }


def _validated_arrays(batch):
    if len(batch) != 3:
        raise ValueError("Each batch must contain score, score-valid and transcript arrays.")
    h, hv, tx = map(np.asarray, batch)
    if h.ndim != 1 or h.shape != hv.shape or h.shape != tx.shape:
        raise ValueError("Score, validity and transcript arrays must be aligned one-dimensional arrays.")
    if h.dtype.kind not in "fiu" or tx.dtype.kind not in "fiu":
        raise ValueError("Score and transcript measurements must be numeric, not text.")
    if hv.dtype.kind != "b":
        raise ValueError("he_tissue_score_valid must be a nonmissing Boolean column.")
    if np.any(hv & (~np.isfinite(h) | (h < 0) | (h > 1))):
        raise ValueError("A score marked valid is missing or outside [0,1]; inspect measurement metadata.")
    tx = tx.astype(np.float64, copy=False)  # Same metric conversion as classify().
    if np.any(np.isfinite(tx) & (tx < 0)):
        raise ValueError("Negative transcript metric found; do not silently clip or log it.")
    return h, hv, tx


class _PointSample:
    """Uniform random-priority subset without a full-data index allocation."""
    def __init__(self, size, seed):
        self.size = size
        self.rng = np.random.default_rng(seed)
        self.keys = np.empty(0)
        self.h = np.empty(0)
        self.t = np.empty(0)

    def add(self, h, t):
        keys = self.rng.random(len(h))
        if len(keys) > self.size:
            ix = np.argpartition(keys, self.size - 1)[:self.size]
            keys, h, t = keys[ix], h[ix], t[ix]
        keys = np.concatenate((self.keys, keys))
        h = np.concatenate((self.h, h))
        t = np.concatenate((self.t, t))
        if len(keys) > self.size:
            ix = np.argpartition(keys, self.size - 1)[:self.size]
            keys, h, t = keys[ix], h[ix], t[ix]
        self.keys, self.h, self.t = keys, h, t

    def result(self):
        ix = np.argsort(self.keys)
        return self.h[ix], self.t[ix]


def summarize_batches(batch_factory, *, thresholds, score_bins=100, transcript_bins=160,
                      scatter_max_points=100_000, seed=42, transcript_axis_max=None, progress=None):
    """Two complete scalar scans; histograms use ALL eligible rows, scatter is capped.

    batch_factory must return a NEW iterator over the SAME ordered measurements.
    This pure aggregation function is also used by the synthetic regression tests.
    """
    score_bins = _positive_int(score_bins, "score_bins")
    transcript_bins = _positive_int(transcript_bins, "transcript_bins")
    scatter_max_points = _positive_int(scatter_max_points, "scatter_max_points")
    floor = 1.0 if transcript_axis_max is None else _cutoff(transcript_axis_max, "transcript_axis_max")
    if floor <= 0:
        raise ValueError("transcript_axis_max must be positive; it is a display floor, not a cap.")
    he_edges = np.linspace(0.0, 1.0, score_bins + 1)
    he_hist = np.zeros(score_bins, dtype=np.int64)
    stat = {k: 0 for k in ("n_bins", "n_he_valid", "n_transcript_valid", "n_joint_valid",
                           "n_zero_transcripts", "n_zero_transcripts_joint", "n_he_exact_zero",
                           "n_he_exact_one")}
    max_tx = 0.0
    sums = np.zeros(2, dtype=np.float64)
    extrema = [math.inf, -math.inf, math.inf, -math.inf]
    quadrant = dict.fromkeys(CLASSES, 0)
    th, tt = thresholds["tissue_score_threshold"], thresholds["transcript_threshold"]
    complete_thresholds = th is not None and tt is not None
    keeper = _PointSample(scatter_max_points, seed)
    for batch in batch_factory():
        h, hv, tx = _validated_arrays(batch)
        tv = np.isfinite(tx)
        jv = hv & tv
        stat["n_bins"] += len(h)
        stat["n_he_valid"] += int(hv.sum())
        stat["n_transcript_valid"] += int(tv.sum())
        stat["n_joint_valid"] += int(jv.sum())
        stat["n_zero_transcripts"] += int((tv & (tx == 0)).sum())
        stat["n_zero_transcripts_joint"] += int((jv & (tx == 0)).sum())
        hh = h[hv]
        if hh.size:
            he_hist += np.histogram(hh, bins=he_edges)[0]
            stat["n_he_exact_zero"] += int((hh == 0).sum())
            stat["n_he_exact_one"] += int((hh == 1).sum())
            sums[0] += np.sum(hh, dtype=np.float64)
            extrema[0], extrema[1] = min(extrema[0], float(hh.min())), max(extrema[1], float(hh.max()))
        if tv.any():
            vv = tx[tv]
            max_tx = max(max_tx, float(vv.max()))
            sums[1] += np.sum(vv, dtype=np.float64)
            extrema[2], extrema[3] = min(extrema[2], float(vv.min())), max(extrema[3], float(vv.max()))
        if jv.any():
            keeper.add(h[jv], tx[jv])
        if complete_thresholds:
            # Preserve input score dtype for the same comparison as classify().
            high_h = h >= th
            if thresholds["classifier_transform"] == "log1p":
                with np.errstate(invalid="ignore"):
                    high_t = np.log1p(tx) >= tt
            else:
                high_t = tx >= tt
            masks = (jv & high_h & high_t, jv & high_h & ~high_t,
                     jv & ~high_h & high_t, jv & ~high_h & ~high_t, ~jv)
            for key, mask in zip(CLASSES, masks):
                quadrant[key] += int(mask.sum())
        if progress is not None:
            progress(1, stat["n_bins"])
    if stat["n_bins"] == 0:
        raise ValueError("The input contains no 2-micron bins.")
    axis_max = max(floor, max_tx)
    # Never hide a tail: extend the display if the observed maximum exceeds its floor.
    if max_tx > floor:
        power = math.ceil(math.log10(max_tx))
        axis_max = 10.0 ** power if power <= 308 else max_tx
    log_edges = np.linspace(0, np.log1p(axis_max) / np.log(10.0), transcript_bins + 1)
    tx_hist = np.zeros(transcript_bins, dtype=np.int64)
    tx_joint_hist = np.zeros_like(tx_hist)
    density = np.zeros((score_bins, transcript_bins), dtype=np.int64)
    checked_n = 0
    for batch in batch_factory():
        h, hv, tx = _validated_arrays(batch)
        tv = np.isfinite(tx)
        jv = hv & tv
        checked_n += len(h)
        transformed = np.log1p(tx[tv]) / np.log(10.0)
        tx_hist += np.histogram(transformed, bins=log_edges)[0]
        tj = np.log1p(tx[jv]) / np.log(10.0)
        tx_joint_hist += np.histogram(tj, bins=log_edges)[0]
        density += np.histogram2d(h[jv], tj, bins=(he_edges, log_edges))[0].astype(np.int64)
        if progress is not None:
            progress(2, checked_n)
    if checked_n != stat["n_bins"] or int(tx_hist.sum()) != stat["n_transcript_valid"]:
        raise RuntimeError("Scalar scans differed or the count histogram omitted values; no report accepted.")
    if int(density.sum()) != stat["n_joint_valid"] or int(he_hist.sum()) != stat["n_he_valid"]:
        raise RuntimeError("Histogram coverage mismatch; no report accepted.")
    hs, ts = keeper.result()
    stat.update({
        "n_he_invalid": stat["n_bins"] - stat["n_he_valid"],
        "n_transcript_invalid": stat["n_bins"] - stat["n_transcript_valid"],
        "n_unassessed_joint": stat["n_bins"] - stat["n_joint_valid"],
        "mean_he_score": float(sums[0] / stat["n_he_valid"]) if stat["n_he_valid"] else None,
        "mean_transcript_metric": float(sums[1] / stat["n_transcript_valid"]) if stat["n_transcript_valid"] else None,
        "he_min": extrema[0] if stat["n_he_valid"] else None,
        "he_max": extrema[1] if stat["n_he_valid"] else None,
        "transcript_min": extrema[2] if stat["n_transcript_valid"] else None,
        "transcript_max": extrema[3] if stat["n_transcript_valid"] else None,
        "transcript_axis_max": float(axis_max),
        "scatter_n": len(hs), "scatter_seed": int(seed),
        "candidate_class_counts": quadrant if complete_thresholds else None,
        "candidate_qc_keep_count": (quadrant[CLASSES[0]] + quadrant[CLASSES[1]]) if complete_thresholds else None,
        "candidate_warning": "Plot-only estimates; no labels or flags saved. Both tissue-high classes are retained.",
        "scope": "Every row in bins_raw.h5ad; no prefilter on in_tissue, qc_keep or count>0.",
        "histogram_scope": "All valid H&E scores; all finite nonnegative transcript metrics; joint density uses intersection.",
    })
    return {"summary": stat, "he_edges": he_edges, "he_hist": he_hist,
            "transcript_log10p1_edges": log_edges, "transcript_hist": tx_hist,
            "transcript_joint_hist": tx_joint_hist, "density": density,
            "scatter_he": hs, "scatter_tx": ts}


def _read_h5_obs_vector(obs, key, start, end, *, strings=False):
    """Narrow reader for standard AnnData obs arrays and nullable numeric arrays."""
    import h5py
    obj = obs[key]
    if isinstance(obj, h5py.Dataset):
        if obj.ndim != 1:
            raise ValueError(f"obs/{key} is not a one-dimensional column.")
        if strings:
            return np.asarray(obj.asstr()[start:end], dtype=object)
        if obj.dtype.kind not in "fiu":
            raise ValueError(f"obs/{key} must be numeric; found {obj.dtype}.")
        return np.asarray(obj[start:end], dtype=np.float64)
    encoding = obj.attrs.get("encoding-type", "")
    if isinstance(encoding, bytes):
        encoding = encoding.decode()
    if not strings and encoding in ("nullable-integer", "nullable-float"):
        arr = np.asarray(obj["values"][start:end], dtype=np.float64)
        arr[np.asarray(obj["mask"][start:end], dtype=bool)] = np.nan
        return arr
    raise ValueError(f"Unsupported obs/{key} encoding {encoding!r}; do not guess or read X.")


def iter_metadata_batches(bins_path, score_path, *, metric="total_counts", chunk_size=250_000):
    """Read ONLY obs/index, obs/metric and three Parquet columns. Never read X."""
    import h5py
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise ImportError("QC review needs pyarrow in this notebook kernel (already used by ingestion).") from exc
    chunk_size = _positive_int(chunk_size, "chunk_size")
    with h5py.File(bins_path, "r") as handle, closing(pq.ParquetFile(score_path)) as pf:
        obs = handle["obs"]
        index_name = obs.attrs.get("_index", "_index")
        if isinstance(index_name, bytes):
            index_name = index_name.decode()
        if index_name not in obs or metric not in obs:
            raise KeyError(f"Need obs index and {metric!r} in {bins_path}; no fallback to X.")
        if not isinstance(obs[index_name], h5py.Dataset):
            raise ValueError("A stored string obs index is required, not a guessed row number.")
        n = len(obs[index_name])
        if pf.metadata.num_rows != n:
            raise ValueError("Bin metadata and H&E Parquet have different row counts.")
        metadata = pf.schema_arrow.metadata or {}
        if b"pandas" not in metadata:
            raise ValueError("H&E Parquet lacks pandas index metadata; cannot verify bin identities.")
        idx = json.loads(metadata[b"pandas"])["index_columns"]
        if len(idx) != 1 or not isinstance(idx[0], str):
            raise ValueError("H&E Parquet must store its barcode index as one physical column.")
        cols = [SCORE, VALID, idx[0]]
        if len(set(cols)) != 3 or not set(cols).issubset(pf.schema_arrow.names):
            raise ValueError("H&E Parquet lacks distinct score, validity and barcode-index columns.")
        cursor = 0
        for batch in pf.iter_batches(batch_size=chunk_size, columns=cols, use_threads=False):
            end = cursor + batch.num_rows
            def column(name):
                return batch.column(batch.schema.get_field_index(name))
            ids = column(idx[0]).to_numpy(zero_copy_only=False)
            h5_ids = _read_h5_obs_vector(obs, index_name, cursor, end, strings=True)
            if not np.array_equal(ids, h5_ids):
                mismatch = next((i for i, (a, b) in enumerate(zip(ids, h5_ids)) if a != b), 0)
                raise ValueError(f"Bin identities/order differ at row {cursor + mismatch}; do not join by position blindly.")
            if column(VALID).null_count:
                raise ValueError("H&E validity column contains missing values.")
            h = column(SCORE).to_numpy(zero_copy_only=False)
            hv = column(VALID).to_numpy(zero_copy_only=False)
            tx = _read_h5_obs_vector(obs, metric, cursor, end)
            cursor = end
            yield h, hv, tx
        if cursor != n:
            raise ValueError("Incomplete H&E metadata read.")


def _stamp(path):
    path = Path(path)
    st = path.stat()
    return {"path": str(path.resolve()), "size": st.st_size, "mtime_ns": st.st_mtime_ns}


def _check_completed_measurement(work, cfg):
    work = Path(work)
    bins = work / "bins_raw.h5ad"
    scores = work / "bins_he.parquet"
    meta = work / "he_fixed" / "measurement.json"
    marker = work / "he_fixed" / "complete.json"
    for p in (bins, scores, meta, marker):
        if not p.is_file():
            raise FileNotFoundError(f"Complete measure_he before plotting; missing: {p}")
    record = json.loads(meta.read_text())
    receipt = json.loads(marker.read_text())
    if not record.get("signature") or record["signature"] != receipt.get("signature"):
        raise ValueError("H&E measurement signature and completion record differ.")
    if record.get("parameters") != cfg.get("he_score"):
        raise ValueError("Current he_score settings differ from the saved measurement. Review before plotting.")
    for p in (meta, scores):
        stamp = _stamp(p)
        if stamp not in receipt.get("outputs", []):
            raise ValueError(f"Completed H&E metadata changed: {p}. No remeasurement or overwrite attempted.")
    return (bins, scores, meta, marker), record


def threshold_locations(project, sample_keys=None):
    """Read-only table of where to edit defaults/overrides and their effective values."""
    import pandas as pd
    from ..control.manifest import resolve_sample_keys, row_config
    selected = set(resolve_sample_keys(project, sample_keys))
    rows = []
    for row in project["rows"]:
        if row["sample_key"] not in selected:
            continue
        cfg, _ = row_config(project, row)
        qc = cfg["bin_qc"]
        rows.append({
            "sample": row["sample_key"], "settings_file": project["settings_path"],
            "overrides_json": row.get("overrides_json") or "",
            "tissue_score_threshold": qc.get("tissue_score_threshold"),
            "transcript_threshold": qc.get("transcript_threshold"),
            "transcript_metric": qc.get("transcript_metric", "total_counts"),
            "transcript_transform": qc.get("transcript_transform", "identity"),
        })
    return pd.DataFrame(rows)


def _count_ticks(axis_max):
    values = [0.0, 1.0]
    for exponent in range(1, min(308, int(math.floor(math.log10(axis_max) + 1e-12))) + 1):
        values.append(10.0 ** exponent)
    return np.asarray(values)


def _format_ticks(ax, axis, axis_max):
    values = _count_ticks(axis_max)
    labels = [f"{v:,.0f}" if v < 1e9 else f"{v:.0e}" for v in values]
    pos = np.log1p(values) / np.log(10.0)
    if axis == "x":
        ax.set_xticks(pos, labels)
    else:
        ax.set_yticks(pos, labels)


def render_review(result, folder, *, sample, thresholds, dpi=300):
    """Four separate figures, using Matplotlib's default palette."""
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.colors import LogNorm
    folder = Path(folder)
    stat = result["summary"]
    th = thresholds["tissue_score_threshold"]
    tt = thresholds["transcript_threshold_raw_equivalent"]
    metric = thresholds["metric"]
    metric_label = "Raw UMI counts per 2-µm bin" if metric == "total_counts" else f"{metric} per 2-µm bin"
    te = result["transcript_log10p1_edges"]
    he = result["he_edges"]
    max_log = te[-1]
    paths = {}

    def figure(title, caption):
        fig = Figure(figsize=(10, 7.2))
        FigureCanvasAgg(fig)
        ax = fig.add_subplot(111)
        fig.subplots_adjust(left=.12, right=.94, top=.82, bottom=.18)
        fig.suptitle(str(sample), fontsize=15, y=.97)
        ax.set_title(title, fontsize=13, pad=12)
        ax.tick_params(labelsize=11)
        fig.text(.12, .045, caption, fontsize=10, va="bottom")
        return fig, ax

    def line(ax, axis, val, label):
        if val is not None:
            fn = ax.axvline if axis == "x" else ax.axhline
            fn(val, linestyle="--", linewidth=1.5, label=label)

    def save(fig, name):
        path = folder / name
        fig.savefig(path, dpi=dpi)
        paths[name] = str(path)
        fig.clear()

    fig, ax = figure("H&E tissue-score distribution",
        f"All {stat['n_he_valid']:,} valid bin-center scores; {stat['n_he_invalid']:,} invalid excluded.\n"
        "Linear score axis; no tissue/count prefilter. No cutoff selected automatically.")
    ax.stairs(result["he_hist"], he, fill=True, alpha=.65)
    line(ax, "x", th, f"Candidate H&E cutoff = {th:g}" if th is not None else "")
    if th is not None: ax.legend(fontsize=10)
    ax.set(xlabel="he_tissue_score (fixed 0–1 scale)", ylabel="Number of 2-µm bins", xlim=(0, 1))
    ax.ticklabel_format(axis="y", style="plain", useOffset=False)
    save(fig, "he_tissue_score_histogram.png")

    fig, ax = figure("Transcript-count distribution",
        f"All {stat['n_transcript_valid']:,} valid metrics; zero-count bins = {stat['n_zero_transcripts']:,}.\n"
        "Log10(1 + count) spacing; tick labels show original values. No zero-count removal.")
    ax.stairs(result["transcript_hist"], te, fill=True, alpha=.55, label="All bins with valid count metric")
    ax.stairs(result["transcript_joint_hist"], te, linewidth=1.4, linestyle=":", label="Also has a valid H&E score")
    line(ax, "x", np.log1p(tt)/np.log(10) if tt is not None else None,
         f"Candidate count cutoff = {tt:g}" if tt is not None else "")
    ax.set(xlabel=metric_label, ylabel="Number of 2-µm bins", xlim=(0, max_log))
    _format_ticks(ax, "x", stat["transcript_axis_max"])
    ax.ticklabel_format(axis="y", style="plain", useOffset=False)
    ax.legend(fontsize=10)
    save(fig, "transcripts_per_bin_histogram.png")

    def joint_axes(ax):
        ax.set(xlabel="he_tissue_score (fixed 0–1 scale)", ylabel=metric_label,
               xlim=(0,1), ylim=(0,max_log))
        _format_ticks(ax, "y", stat["transcript_axis_max"])
        line(ax, "x", th, f"Candidate H&E cutoff = {th:g}" if th is not None else "")
        line(ax, "y", np.log1p(tt)/np.log(10) if tt is not None else None,
             f"Candidate count cutoff = {tt:g}" if tt is not None else "")
        if th is not None or tt is not None: ax.legend(fontsize=9, loc="upper right")
        if th is not None and not 0 <= th <= 1: raise AssertionError("Invalid score cutoff.")

    fig, ax = figure("H&E score versus transcripts — point sample",
        f"Uniform seeded subset: {stat['scatter_n']:,} of {stat['n_joint_valid']:,} joint-valid bins.\n"
        "Counts use log10(1 + count) spacing. Use the full-data density for abundance comparisons.")
    ax.scatter(result["scatter_he"], np.log1p(result["scatter_tx"])/np.log(10),
               s=2, alpha=.15, linewidths=0, rasterized=True)
    joint_axes(ax)
    save(fig, "he_vs_transcripts_scatter.png")

    fig, ax = figure("H&E score versus transcripts — all-bin density",
        f"All {stat['n_joint_valid']:,} joint-valid bins; {stat['n_unassessed_joint']:,} excluded from this panel.\n"
        "Color shows bins per 2D histogram cell (log scale); count-axis labels are original values.")
    mat = np.ma.masked_equal(result["density"].T, 0)
    if stat["n_joint_valid"]:
        im = ax.pcolormesh(he, te, mat, shading="flat",
                          norm=LogNorm(vmin=1, vmax=max(2, int(result["density"].max()))))
        fig.colorbar(im, ax=ax, label="Number of bins (log color scale)")
    else:
        ax.text(.5, .5, "No jointly valid bins", transform=ax.transAxes, ha="center")
    joint_axes(ax)
    save(fig, "he_vs_transcripts_density.png")
    return paths


def _write_report(result, folder, *, sample, thresholds, provenance, dpi):
    import pandas as pd
    folder = Path(folder)
    # Parent existence is handled by the project entry point after path-policy checks.
    folder.mkdir(parents=True, exist_ok=False)
    images = render_review(result, folder, sample=sample, thresholds=thresholds, dpi=dpi)
    hs, ts = result["he_hist"], result["transcript_hist"]
    pd.DataFrame({"score_left": result["he_edges"][:-1], "score_right": result["he_edges"][1:],
                  "n_bins": hs, "fraction_of_valid_scores": hs / max(1, hs.sum())}).to_csv(
                      folder / "he_histogram.csv", index=False)
    edges = result["transcript_log10p1_edges"]
    pd.DataFrame({"log10p1_left": edges[:-1], "log10p1_right": edges[1:],
                  "raw_metric_left": np.expm1(edges[:-1] * np.log(10)),
                  "raw_metric_right": np.expm1(edges[1:] * np.log(10)),
                  "n_bins": ts, "n_also_he_valid": result["transcript_joint_hist"],
                  "fraction_of_valid_metrics": ts / max(1, ts.sum())}).to_csv(
                      folder / "transcript_histogram.csv", index=False)
    np.savez_compressed(folder / "joint_density.npz", he_edges=result["he_edges"],
                        transcript_log10p1_edges=edges, counts=result["density"])
    summary = {"implementation": PATCH, "sample": sample,
               "created_utc": datetime.now(timezone.utc).isoformat(), "thresholds": thresholds,
               **result["summary"], "provenance": provenance, "plots": images,
               "expression_values_read": False, "image_pixels_read": False,
               "scientific_data_or_config_modified": False,
               "report_files": [p.name for p in sorted(folder.iterdir())] + ["review_summary.json"]}
    (folder / "review_summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False))
    return summary


def generate_bin_qc_review(project, sample_keys=None, *, execute=False, candidate_thresholds=None,
                           chunk_size=250_000, score_bins=100, transcript_bins=160,
                           scatter_max_points=100_000, seed=42, transcript_axis_max=None):
    """Notebook entry point. Serial samples; plot-only execution, preview by default.

    execute=True writes NEW versioned folders below each configured reports/
    bin_qc_cutoff_review/. It never replaces previous figures or modifies settings.
    candidate_thresholds is an optional pair of temporary numeric plot cutoffs.
    Without it, configured cutoffs are drawn if present; None draws no line.
    """
    import pandas as pd
    from ..control.manifest import resolve_sample_keys, sample_layout, row_config, check_policy
    selected = set(resolve_sample_keys(project, sample_keys))
    _positive_int(chunk_size, "chunk_size")
    check_policy(project)
    plans = []
    for row in project["rows"]:
        if row["sample_key"] not in selected: continue
        if "bin_qc" not in row.get("_plan", []):
            raise ValueError(f"{row['sample_key']}: this report needs the fresh measure_he route, not legacy-only QC.")
        cfg, _ = row_config(project, row)
        p = sample_layout(project, row)  # Unlike sample_paths(), this does not create directories.
        thresholds = _thresholds(cfg["bin_qc"], candidate_thresholds)
        plans.append((row, cfg, p, thresholds))
    if not plans:
        raise ValueError("No samples selected for cutoff review.")
    if not execute:
        return pd.DataFrame([{
            "sample": r["sample_key"], "mode": "PREVIEW_ONLY",
            "bins_input": str(p["work"] / "bins_raw.h5ad"),
            "score_input": str(p["work"] / "bins_he.parquet"),
            "report_parent": str(p["report"] / "bin_qc_cutoff_review"),
            **t} for r, _, p, t in plans])
    # Validate all small receipts before scanning a batch of samples.
    for row, cfg, p, _ in plans:
        _check_completed_measurement(p["work"], cfg)
    outputs = []
    for row, cfg, p, thresholds in plans:
        print(f"[PLOT-ONLY] {row['sample_key']}: reading scalar metadata twice, not X or images.", flush=True)
        paths, record = _check_completed_measurement(p["work"], cfg)
        before = [_stamp(x) for x in paths]
        factory = lambda: iter_metadata_batches(paths[0], paths[1], metric=thresholds["metric"], chunk_size=chunk_size)
        milestones = {1: -1, 2: -1}
        def show_progress(pass_number, n):
            milestone = n // 1_000_000
            if milestones[pass_number] != milestone:
                print(f"  Scalar scan {pass_number}/2: {n:,} bins checked", flush=True)
                milestones[pass_number] = milestone
        result = summarize_batches(factory, thresholds=thresholds, score_bins=score_bins,
                                   transcript_bins=transcript_bins, scatter_max_points=scatter_max_points,
                                   seed=seed, transcript_axis_max=transcript_axis_max, progress=show_progress)
        if before != [_stamp(x) for x in paths]:
            raise RuntimeError("Input metadata changed during the review. Stop overlapping writers and retry.")
        identity = hashlib.sha256(json.dumps({"inputs": before, "thresholds": thresholds,
                    "patch": PATCH}, sort_keys=True).encode()).hexdigest()[:12]
        name = "review_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + identity + "_" + uuid.uuid4().hex[:6]
        folder = p["report"] / "bin_qc_cutoff_review" / name
        from ..control.paths_v3 import assert_target
        policy = project["settings"]["storage_policy"]
        assert_target(folder, policy.get("approved_work_roots", policy.get("approved_tmp_roots", [])),
                      [*map(str, paths), str(p["store"]), row.get("spaceranger_outs"), row.get("segmentation_image")])
        summary = _write_report(result, folder, sample=row["sample_key"], thresholds=thresholds,
            dpi=_positive_int(cfg.get("plots", {}).get("dpi", 300), "dpi"),
            provenance={"inputs": before, "he_measurement_signature": record["signature"],
                "settings_file": project["settings_path"], "manifest_file": project["manifest_path"],
                "overrides_json": row.get("overrides_json") or "", "chunk_size": chunk_size,
                "score_bins": score_bins, "transcript_bins": transcript_bins,
                "histogram_intervals": "left closed, right open; last interval also includes right edge",
                "histograms": "exact full-row tallies, not downsampled",
                "barcode_check": "all rows checked for exact H5/Parquet order in both passes; no fuzzy matching",
                "input_identity_check": "size/mtime plus original measurement receipt; not full count-file hashing"})
        print(f"[REPORTS] {folder}", flush=True)
        outputs.append({"sample": row["sample_key"], "status": "plots_complete",
                        "report_dir": str(folder), "n_bins": summary["n_bins"],
                        "n_he_valid": summary["n_he_valid"], "n_joint_valid": summary["n_joint_valid"],
                        "n_zero_transcripts": summary["n_zero_transcripts"],
                        "scatter_n": summary["scatter_n"],
                        "summary_json": str(folder / "review_summary.json")})
        del result
    return pd.DataFrame(outputs)


def validate_bin_qc_thresholds(project, sample_keys=None):
    """Print effective cutoff locations; raise once before launching any workers."""
    from ..control.manifest import resolve_sample_keys, row_config
    selected = set(resolve_sample_keys(project, sample_keys))
    table = threshold_locations(project, sample_keys)
    errors = []
    for row in project["rows"]:
        if row["sample_key"] not in selected:
            continue
        cfg, _ = row_config(project, row)
        if cfg["bin_qc"].get("mode") != "fresh":
            continue
        try:
            resolved = _thresholds(cfg["bin_qc"])
            for name in ("tissue_score_threshold", "transcript_threshold"):
                if resolved[name] is None:
                    errors.append(f"{row['sample_key']}: {name} is unset.")
        except (ValueError, TypeError) as exc:
            errors.append(f"{row['sample_key']}: {exc}")
    print(table.to_string(index=False))
    if errors:
        raise ValueError("No workers launched. Edit bin_qc in the printed active settings/overrides, then reload PROJECT:\n" + "\n".join(errors))
    return table
