# Changelog

## 0.3.0-review — 2026-09-28
Fixed-reference H&E quantitative branch, optional asset import/review/transfer,
coverage-aware cell summaries, pathology prior filtering, explicit stable-master
metadata/element operations, retained-work/scratch/cache routing, and scVI issue-2
handoff guards. 19 source-only notebooks. A real-environment pilot is still required.

Scientific differences are explicit: original reference OLS/clipping and fixed-score
mapping order are preserved; new QC thresholds are user-set, not guessed historical
values. Polygon holes now survive import; rerun annotation assignments replace rather
than accumulate membership. Legacy display-normalizer output contract is corrected
but display normalization is not the quantitative QC method.

One v2 unit test expecting a broad ancestor-output-root rejection was deliberately
replaced with the reviewed actual-target overlap policy. No tests were silently
marked passing or removed to claim end-to-end science validation.

## 0.2.0-csv-review
Supplied CSV/midway/compute foundation. Original source archive is retained separately;
this bundle contains a new candidate, not edits to the user's source files or data.
