# annotations

Source import, registration approval, fresh membership and coverage-aware transfer.

See ../../docs/START_HERE.md and ../../docs/IMPLEMENTATION_STATUS.md. Source review and CPU tests are not target-environment validation.
