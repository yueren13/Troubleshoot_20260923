"""Explicit source-bound adoption of visually reviewed polygon-repair candidates.

Never modifies the source XML, repairs unreviewed regions, or changes coordinates.
The output is a derived microscopy-geometry JSON, NOT geographic GeoJSON. Separate
activation changes one asset path/format; ordinary 02A alignment approval remains.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import csv
import hashlib
import json
import math
from pathlib import Path
import uuid

import numpy as np
import pandas as pd
import shapely
from shapely.geometry import MultiPolygon
from defusedxml import ElementTree as ET
from . import region_review as visual

SCHEMA = "vhd.reviewed_polygons.v1"
FORMAT = "reviewed_polygons_json"
PATCH = "reviewed-polygonal-import-20261002-v1"


def _bytes(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                       separators=(",", ":")) + "\n").encode("utf-8")


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _check_bool(value, name):
    if type(value) is not bool:
        raise TypeError(f"{name} must be a Boolean.")


def _same(actual, expected, label):
    """Compare recomputed numeric report data, allowing only floating-point noise."""
    if isinstance(actual, dict) and isinstance(expected, dict):
        if set(actual) != set(expected):
            raise ValueError(f"{label}: report fields differ; regenerate review.")
        for key in actual:
            _same(actual[key], expected[key], f"{label}.{key}")
    elif isinstance(actual, (list, tuple)) and isinstance(expected, (list, tuple)):
        if len(actual) != len(expected):
            raise ValueError(f"{label}: report lengths differ.")
        for i, (a, e) in enumerate(zip(actual, expected)):
            _same(a, e, f"{label}[{i}]")
    elif isinstance(actual, (float, int)) and not isinstance(actual, bool):
        if isinstance(expected, bool) or not isinstance(expected, (float, int)) or not math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-8):
            raise ValueError(f"{label}: recomputed candidate differs from review.")
    elif actual != expected:
        raise ValueError(f"{label}: recomputed value differs from review.")


def assert_closed_polygonal(geometry, label="geometry"):
    """Validate entire exterior AND interior rings; do not patch or round vertices."""
    if geometry.geom_type not in ("Polygon", "MultiPolygon"):
        raise ValueError(f"{label}: expected filled polygon(s), got {geometry.geom_type}.")
    if geometry.is_empty or not geometry.is_valid or not math.isfinite(geometry.area) or geometry.area <= 0:
        raise ValueError(f"{label}: empty, invalid or non-positive-area polygon(s).")
    polygons = list(geometry.geoms) if geometry.geom_type == "MultiPolygon" else [geometry]
    for p in polygons:
        if p.is_empty or p.area <= 0:
            raise ValueError(f"{label}: an empty/zero-area polygon part would be lost.")
        for ring in [p.exterior, *p.interiors]:
            xy = np.asarray(ring.coords)
            if xy.ndim != 2 or xy.shape[1] != 2 or len(xy) < 4 or not np.isfinite(xy).all() or not np.array_equal(xy[0], xy[-1]) or not ring.is_ring:
                raise ValueError(f"{label}: open, nonsimple or nonfinite ring; no output written.")
    return geometry


def polygonal_candidate(candidate):
    """Keep ALL already-closed polygon components; separate standalone lines.

    This is not deletion of edges from raw rings. Points and polygonless results
    remain blocked; no 'largest piece' or buffer/simplification option exists.
    """
    if not candidate.is_valid or candidate.is_empty:
        raise ValueError("Repair candidate must be valid and nonempty.")
    leaves = list(visual._leaves(candidate))
    polys = [g for g in leaves if g.geom_type == "Polygon"]
    other = [g for g in leaves if g.geom_type != "Polygon"]
    if not polys:
        raise ValueError("No positive-area polygon component; region cannot be silently removed.")
    if any(g.is_empty or g.geom_type != "LineString" for g in other):
        raise ValueError("Only reviewed standalone LineString remnants are supported; points/other/collapsed parts require review.")
    for poly in polys:
        assert_closed_polygonal(poly)
    kept = polys[0] if len(polys) == 1 else MultiPolygon(polys)
    assert_closed_polygonal(kept)
    if not math.isclose(kept.area, sum(p.area for p in polys), rel_tol=1e-12, abs_tol=1e-10):
        raise ValueError("Polygon component area changed during extraction.")
    # Component equality is stronger than area equality alone, particularly for holes.
    kept_parts = list(kept.geoms) if kept.geom_type == "MultiPolygon" else [kept]
    if [g.wkb_hex for g in kept_parts] != [g.wkb_hex for g in polys]:
        raise ValueError("Polygon coordinates or ring structure changed during extraction.")
    return kept, other


def _source_report(path, sample_key, asset_id):
    p = Path(path).expanduser()
    raw = p.read_bytes()
    report = json.loads(raw)
    if report.get("review_version") != visual.REVIEW_VERSION or report.get("status") != "report_complete_not_approved":
        raise ValueError("Use a completed candidate review_summary.json, not a failure or accepted-geometry file.")
    if report.get("shapely_version") != shapely.__version__ or report.get("geos_version") != shapely.geos_version_string:
        raise ValueError("Shapely/GEOS differ from the visual review. Regenerate the review in this environment before adoption.")
    sources = [s for s in report.get("sources", []) if s["sample_key"] == sample_key and s["asset_id"] == asset_id]
    if len(sources) != 1:
        raise ValueError("Expected exactly one reviewed sample/asset source.")
    if report.get("coordinate_frame") != "XML source coordinates only":
        raise ValueError("Unexpected review coordinate frame.")
    return p, _sha(raw), report, sources[0]


def compile_reviewed_source(review_json, *, sample_key, asset_id):
    """Read-only: reproduce the exact reported repair and category composition.

    No geometry is adopted here. The report has metrics/hashes, not the original
    vertices: the actual XML must still be accessible on the user's instance.
    """
    rp, rsha, report, source = _source_report(review_json, sample_key, asset_id)
    xml_path = Path(source["path"])
    sha, records = visual._read_snapshot(xml_path, source["source_sha256"])
    if len(records) != source["n_regions"]:
        raise ValueError("Source region count differs from review.")
    if any(r["status"] == "malformed" for r in records):
        raise ValueError("Malformed regions cannot be adopted by this policy.")
    invalid = [r for r in records if r["status"] == "invalid"]
    expected = {(r["annotation_index"], r["region_index"]): r for r in source["region_candidates"]}
    if len(expected) != len(source["region_candidates"]) or set(expected) != {(r["annotation_index"],r["region_index"]) for r in invalid} or len(invalid) != source["n_invalid"]:
        raise ValueError("Invalid region inventory differs from visual review.")
    repaired, ledger, table = {}, [], []
    for r in records:
        key = (r["annotation_index"], r["region_index"])
        entry = {k: r[k] for k in ("annotation_index", "annotation_id", "category", "region_index", "region_id", "negative_region", "region_type", "n_vertices", "coordinate_sequence_sha256")}
        if r["status"] == "valid":
            kept, removed = assert_closed_polygonal(r["_geometry"]), []
            entry["operation"] = "unchanged_valid_region"
        else:
            er = expected[key]
            for name in entry:
                _same(entry[name], er[name], f"region {key}.{name}")
            visual._propose(r, False)
            got = r["candidates"].get("linework", {})
            _same(got, er["candidates"]["linework"], f"region {key}.linework")
            kept, removed = polygonal_candidate(r["_candidate_geometries"]["linework"])
            entry.update(operation="reviewed_linework_keep_all_polygons", candidate_summary=got)
            table.append({"category":r["category"], "annotation_id":r["annotation_id"], "region_id":r["region_id"],
                          "negative_region":r["negative_region"], "kept_polygons":len(visual._polygon_parts(kept)),
                          "kept_holes":sum(len(p.interiors) for p in visual._polygon_parts(kept)),
                          "line_parts_to_remove":len(removed), "line_length_source_units":sum(g.length for g in removed),
                          "closed_valid_polygonal":True})
        repaired[key] = kept
        entry["retained_wkb_sha256"] = _sha(kept.wkb)
        entry["retained_area_source_units_squared"] = float(kept.area)
        entry["removed_lines"] = [{"type":g.geom_type, "length_source_units":float(g.length), "wkb_hex":g.wkb_hex} for g in removed]
        ledger.append(entry)
    # Recover visual metadata that the previous report did not enumerate.
    root = ET.fromstring(xml_path.read_bytes())
    for node in root.iter(): node.tag = node.tag.rsplit("}", 1)[-1]
    ann = list(root.iter("Annotation"))
    inventory = {c["annotation_index"]:c for c in source["category_inventory"]}
    if len(inventory) != len(source["category_inventory"]) or len(ann) != len(inventory):
        raise ValueError("Annotation inventory differs from reviewed file.")
    features = []
    for ai, annotation in enumerate(ann):
        rows = [r for r in records if r["annotation_index"] == ai]
        if not rows:
            raise ValueError("Empty XML Annotation needs explicit handling; not silently omitted.")
        pos = [repaired[(ai,r["region_index"])] for r in rows if not r["negative_region"]]
        neg = [repaired[(ai,r["region_index"])] for r in rows if r["negative_region"]]
        if not pos:
            raise ValueError("Negative-only annotation has no positive parent.")
        geom = shapely.union_all(pos)
        if neg: geom = geom.difference(shapely.union_all(neg))
        assert_closed_polygonal(geom, annotation.get("Name", "unnamed"))
        inv = inventory[ai]
        _same(annotation.get("Name", "unnamed"), inv["category"], "category name")
        _same(str(annotation.get("Id", ai)), inv["annotation_id"], "annotation ID")
        _same(len(rows), inv["n_regions"], "category region count")
        _same(sum(r["negative_region"] for r in rows), inv["n_negative"], "category negative count")
        if any(r["status"] == "invalid" for r in rows):
            _, _, _, stats = visual._compose_annotation(rows)
            declared = {k:v for k,v in inv["candidate_composition"].items() if k != "preview"}
            _same(stats, declared, f"annotation {ai}.composition")
        props = {"name":annotation.get("Name", "unnamed"), "annotation_id":str(annotation.get("Id",ai)),
                 "annotation_index":ai, "visible":annotation.get("Visible","True"), "linecolor":annotation.get("LineColor",""),
                 "source_xml_sha256":sha, "geometry_review_sha256":rsha, "geometry_policy":PATCH}
        features.append({"properties":props, "geometry_wkb_hex":geom.wkb_hex})
    if _sha(xml_path.read_bytes()) != sha:
        raise RuntimeError("XML changed during preparation; no output written.")
    payload = {"schema":SCHEMA, "implementation":PATCH, "coordinate_frame":"original_xml_source_xy", "crs":None,
               "source":{"path":str(xml_path),"sha256":sha,"n_regions":len(records)},
               "review":{"path":str(rp.resolve()),"sha256":rsha,"version":report["review_version"],
                         "shapely":shapely.__version__,"geos":shapely.geos_version_string},
               "policy":{"method":"linework", "keep_polygon_parts":"all", "preserve_holes":True,
                         "negative_regions":"subtract_within_parent_xml_annotation", "line_remnants":"exclude_from_filled_geometry_keep_in_audit",
                         "points_allowed":False, "registration_approved":False, "obs_categories_selected":False},
               "sample_key":sample_key,"asset_id":asset_id, "region_audit":ledger,"features":features}
    return payload, pd.DataFrame(table)


def _context(project, sample_key, asset_id):
    from ..control.manifest import check_policy, resolve_sample_keys, sample_layout
    from .workflow import read_assets
    check_policy(project)
    key = resolve_sample_keys(project,[sample_key])[0]
    row = next(r for r in project["rows"] if r["sample_key"] == key)
    assets = read_assets(row.get("assets_manifest"),row["dataset_id"],row["sample_id"])
    matches = [a for a in assets if a["asset_id"] == asset_id]
    if len(matches) != 1 or matches[0]["kind"] != "polygons":
        raise ValueError("Expected exactly one polygon asset in the active sample.")
    return key,row,matches[0],sample_layout(project,row)


def prepare_geometry_review(project, sample_key, asset_id, *, execute=False):
    """Formal report step. Preview has no writes; execute creates a new review folder."""
    _check_bool(execute,"execute")
    key,row,asset,paths = _context(project,sample_key,asset_id)
    if asset["format"] == FORMAT:
        raise ValueError("Already using a reviewed derivative; retain its original review or deliberately reactivate the XML.")
    from .region_inspection import inspect_project_annotations
    audit = inspect_project_annotations(project,[key],check_repair_candidates=True)
    if not execute:
        print("PREVIEW: would create candidate review under",paths["report"])
        return {"mode":"preview","audit":audit}
    # Normal path policy was checked above; sample reports are intentionally retained.
    Path(paths["report"]).mkdir(parents=True,exist_ok=True)
    return visual.write_candidate_review(audit,paths["report"],sample_key=key,asset_id=asset_id)


def reviewed_geometry_plan(project, sample_key, asset_id, review_json):
    key,row,asset,paths = _context(project,sample_key,asset_id)
    payload, frame = compile_reviewed_source(review_json,sample_key=key,asset_id=asset_id)
    original = Path(payload["source"]["path"]).resolve()
    active = Path(asset["path"]).resolve()
    if asset["format"] == FORMAT:
        old = _load_document(active)
        if old["payload"]["source"] != payload["source"]:
            raise ValueError("Active derivative belongs to another XML snapshot.")
    elif active != original:
        raise ValueError("Review source is not the active asset XML path.")
    from ..control.paths_v3 import assert_target
    parent = Path(paths["report"])/"reviewed_annotations"
    policy = project["settings"]["storage_policy"]
    assert_target(parent, policy.get("approved_work_roots", policy.get("approved_tmp_roots",[])), [str(original)])
    if parent.is_symlink():
        raise ValueError("Refuse a symlinked reviewed-annotation output folder.")
    return {"sample_key":key, "asset_id":asset_id,"review_json":str(Path(review_json).resolve()),
            "reviewed_source":payload["source"], "plan_digest":_sha(_bytes(payload)), "regions":frame,
            "n_categories":len(payload["features"]),
            "line_parts_to_remove":sum(len(r["removed_lines"]) for r in payload["region_audit"]),
            "output_parent":str(Path(paths["report"])/"reviewed_annotations"),
            "writes_source":False,"changes_obs":False,"alignment_approved":False,
            "_payload":payload}


def accept_reviewed_geometry(project,sample_key,asset_id,review_json, *, expected_plan_digest,
                             reviewer="", approve=False, allow_remove_lines=False, execute=False):
    """Explicit adoption of ALL reported region candidates, not future/unseen inputs.

    A deterministic derived file is written under the configured sample reports.
    Source XML and assets.csv are unchanged. Separate activation is required.
    """
    for name,value in [("approve",approve),("allow_remove_lines",allow_remove_lines),("execute",execute)]:_check_bool(value,name)
    plan = reviewed_geometry_plan(project,sample_key,asset_id,review_json)
    if plan["plan_digest"] != expected_plan_digest:
        raise ValueError("Plan changed since it was displayed; review the new plan before adoption.")
    if not execute:
        return {"status":"preview","plan_digest":plan["plan_digest"],"regions":plan["regions"]}
    if not approve or not isinstance(reviewer,str) or not reviewer.strip():
        raise PermissionError("Explicit approve=True and a reviewer name/identifier are required.")
    if plan["line_parts_to_remove"] and not allow_remove_lines:
        raise PermissionError("This reviewed plan has standalone line remnants; explicitly allow their removal from filled geometry.")
    payload=plan["_payload"]
    document={"payload":payload,"payload_sha256":plan["plan_digest"],
              "approval":{"reviewer":reviewer.strip(),"approved":True,"allow_remove_lines":allow_remove_lines,
                          "approved_utc":datetime.now(timezone.utc).isoformat(),
                          "scope":"geometry only; not H&E registration, .obs category selection or scientific validity"}}
    folder=Path(plan["output_parent"])/plan["plan_digest"]
    out=folder/"annotation.vhdpolygons.json"
    if folder.is_symlink() or out.is_symlink():
        raise ValueError("Refuse symlinked reviewed output targets.")
    if out.exists():
        existing=_load_document(out)
        if existing["payload_sha256"]!=plan["plan_digest"]:
            raise RuntimeError("Conflicting existing reviewed artifact; do not overwrite.")
        return {"status":"reused","path":str(out),"n_categories":plan["n_categories"],"line_parts_removed":plan["line_parts_to_remove"]}
    folder.mkdir(parents=True,exist_ok=True)
    if out.is_symlink():raise ValueError("Refuse symlinked derived output.")
    # Exclusive create; interrupted writes are retained and rejected by the reader.
    with out.open("xb") as handle:handle.write(_bytes(document))
    _load_document(out)
    return {"status":"written","path":str(out),"n_categories":plan["n_categories"],"line_parts_removed":plan["line_parts_to_remove"]}


def _load_document(path):
    p=Path(path)
    document=json.loads(p.read_bytes())
    payload=document["payload"]
    if document["payload_sha256"]!=_sha(_bytes(payload)):
        raise ValueError("Reviewed geometry checksum mismatch.")
    if payload.get("schema")!=SCHEMA or payload.get("crs") is not None or payload.get("coordinate_frame")!="original_xml_source_xy":
        raise ValueError("Not a supported microscopy reviewed-geometry document.")
    approval=document.get("approval",{})
    if approval.get("approved") is not True or not str(approval.get("reviewer","")).strip():
        raise PermissionError("Unapproved geometry document.")
    if any(r["removed_lines"] for r in payload["region_audit"]) and approval.get("allow_remove_lines") is not True:
        raise PermissionError("Missing explicit line-remnant removal approval.")
    if not payload.get("features"):raise ValueError("Empty accepted geometry.")
    return document


def read_reviewed_polygons(path):
    """Read a typed microscopy document without assigning a geographic CRS."""
    import geopandas as gpd
    doc=_load_document(path);payload=doc["payload"];rows=[]
    seen=set()
    for item in payload["features"]:
        properties=item["properties"].copy();key=properties["annotation_index"]
        if key in seen:raise ValueError("Duplicate XML annotation index in reviewed derivative.")
        seen.add(key)
        geom=shapely.from_wkb(bytes.fromhex(item["geometry_wkb_hex"]))
        assert_closed_polygonal(geom)
        rows.append({**properties,"geometry":geom})
    g=gpd.GeoDataFrame(rows,geometry="geometry",crs=None)
    g.index=pd.Index([str(i) for i in range(len(g))])
    g.attrs["vhd_geometry_review"]={k:payload[k] for k in ("source","review","policy")}
    g.attrs["vhd_geometry_review"]["approval"]=doc["approval"]
    return g


def activate_reviewed_geometry(project,sample_key,asset_id,derived_path, *, execute=False):
    """Back up and update only this asset's path, format and category_column.

    No alignment/QC flags or category choices are approved by this action.
    Existing choices become stale by the normal content/registration signature.
    """
    _check_bool(execute,"execute")
    key,row,asset,paths=_context(project,sample_key,asset_id)
    document=_load_document(derived_path);payload=document["payload"]
    read_reviewed_polygons(derived_path)
    if (payload["sample_key"],payload["asset_id"])!=(key,asset_id):
        raise ValueError("Derived source belongs to a different sample/asset.")
    destination=Path(derived_path).resolve()
    try:destination.relative_to(Path(paths["report"]).resolve())
    except ValueError:raise ValueError("Activate a derivative under this sample's configured reports directory.")
    if asset["format"]==FORMAT:
        if Path(asset["path"]).resolve()==destination:return {"status":"already_active","path":str(destination)}
        raise ValueError("A different derivative is active; deliberate revision/migration is required.")
    if Path(asset["path"]).resolve()!=Path(payload["source"]["path"]).resolve() or _sha(Path(asset["path"]).read_bytes())!=payload["source"]["sha256"]:
        raise ValueError("Original asset source changed after visual review.")
    manifest=Path(row["assets_manifest"])
    if manifest.is_symlink():raise ValueError("Refuse to rewrite a symlinked asset manifest.")
    original=manifest.read_bytes()
    import io
    reader=csv.DictReader(io.StringIO(original.decode("utf-8-sig")))
    headers=list(reader.fieldnames or []);rows=list(reader)
    if not headers or len(set(headers))!=len(headers) or any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError("Malformed asset CSV.")
    candidates=[r for r in rows if r.get("sample_id","").strip()==row["sample_id"] and r.get("asset_id","").strip()==asset_id and r.get("dataset_id","").strip() in ("",row["dataset_id"])]
    if len(candidates)!=1:raise ValueError("Expected one matching CSV asset row.")
    target=candidates[0]
    for col in ("format","category_column"):
        if col not in headers:headers.append(col)
    for r in rows:
        for col in headers:r.setdefault(col,"")
    target.update(path=str(destination),format=FORMAT,category_column="name")
    if not execute:return {"status":"preview","manifest":str(manifest),"new_path":str(destination),"changed_fields":["path","format","category_column"]}
    if manifest.read_bytes()!=original:raise RuntimeError("Asset manifest changed during activation.")
    stamp=uuid.uuid4().hex[:12];backup=manifest.with_name(manifest.name+".before_reviewed_geometry_"+stamp+".txt")
    with backup.open("xb") as handle:handle.write(original)
    temp=manifest.with_name(manifest.name+"."+stamp+".tmp")
    try:
        with temp.open("x",encoding="utf-8",newline="") as handle:
            writer=csv.DictWriter(handle,fieldnames=headers);writer.writeheader();writer.writerows(rows)
        temp.replace(manifest)
    finally:
        if temp.exists():temp.unlink()
    return {"status":"activated","manifest":str(manifest),"backup":str(backup),"path":str(destination),
            "next":"Reload PROJECT, rerun 02A discovery/import overlays, choose categories and approve alignment before 02B."}
