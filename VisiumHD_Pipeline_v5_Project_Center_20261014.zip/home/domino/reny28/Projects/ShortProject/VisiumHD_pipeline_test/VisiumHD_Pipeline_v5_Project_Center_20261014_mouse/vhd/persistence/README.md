# persistence

Explicit staged component/metadata operations with journals and retained backups.

See ../../docs/START_HERE.md and ../../docs/IMPLEMENTATION_STATUS.md. Source review and CPU tests are not target-environment validation.
