# v4.1.1 metadata-CSV validation — 2026-09-30

## Executed in this delivery environment

- Original supplied v4.1 bundle rechecked before editing: **214 passed, 7 skipped**.
- Updated full test collection: **264 passed, 8 skipped**.
- **50 new executed tests** cover CSV parsing, 72 samples in shuffled order,
  duplicate/blank keys, exact matching, leading zeros, arbitrary headers,
  Unicode/quoted fields, missing-value tokens, selected/renamed columns, declared
  numeric/Boolean types, composite keys, JSON compatibility/conflicts, stable worker
  snapshots, metadata ownership and in-memory count/coordinate identity.
- Original source validation: **78 Python files, 23 notebooks, 95 code cells,
  20 CSV files** passed strict source-mode validation.
- Default/raw/mixed starter configurations loaded and passed routing/static path
  policy checks with temporary approved roots. This does not check real source paths.

Raw outputs: METADATA_PYTEST_OUTPUT.txt, METADATA_STATIC_VALIDATION.json,
METADATA_STARTER_VALIDATION.json. Environment: METADATA_TEST_ENVIRONMENT.json.
Historical validation is preserved in VALIDATION_V41_BASELINE.md; do not combine
counts from different releases as one end-to-end run.

## Not executed

The eight skips are SIX whole optional scientific test modules gated by absent
AnnData/SpatialData dependencies and TWO opt-in scVI tests. A skipped module can
represent several unexecuted tests. The new optional module supplies a real CSV ->
cell import -> assembly test, and a two-table metadata-only write/readback test that
checks X, layers and coordinates. These tests were NOT run here.

The in-memory metadata tests use a lightweight AnnData-like object solely to test
obs/uns assignment and count/coordinate object identity. They do not exercise the
AnnData serializer, SpatialData writer or mounted-storage recovery. No real master,
image, biological expression object or private mount was accessed. GPU, Proseg,
StarDist, scVI/DDP and RAPIDS were not run. No installation or package upgrade was
performed in the user's environment.

## Input-example limitation

No new metadata-table attachment accompanied the visible request. Available files
were the earlier summaries/configurations. The new example CSV is the previous
generic starter metadata consolidated into one table; the 72-row example is
synthetic. No new study values or headings were invented as user-supplied facts.

## Target checks

Run notebook 00's join preview before processing. Run notebook 99 and confirm
whether optional scientific modules execute or skip. On a copied tiny master,
verify CSV values on bins/cells, preserved X/layers/coordinates, exact sample IDs,
missing-value readback and explicit ownership-aware refresh. Do not replace source
code beneath live workers or remove completion guards to force new metadata into
old processing artifacts.
