"""Targeted permanent fix for the r1 Proseg help parser (no scientific jobs).

Only the PROSEG_PROBE string in vhd/compute/startup_support.py is replaced.
The required flag list, launcher, scientific code and managed state are preserved.
Apply only during exclusive maintenance; restart every kernel using this package.
"""
from __future__ import annotations
import ast
import gc
import hashlib
import inspect
import json
import os
import stat
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).absolute().parent
PATCH_ID = 'vhd-v5-proseg-cli-help-20261013-r1'
DEFAULT_SAMPLES = ('Project__A1_CO571', 'Project__D1_LC1501A')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _state_hash(state):
    return _sha(json.dumps(state, sort_keys=True, default=str).encode())


def _context_hash(state):
    fields = {k: state.get(k) for k in ('project', 'startup_settings', 'resource_limits')}
    return _state_hash(fields)


def _manifest():
    m = json.loads((HERE/'hotfix_manifest.json').read_text())
    if m.get('patch_id') != PATCH_ID:
        raise ValueError('Wrong hotfix manifest')
    for which in ('before', 'after'):
        if _sha(m[which].encode()) != m[which+'_sha256']:
            raise ValueError('Hotfix manifest content/hash mismatch')
    if m['relative'] != 'vhd/compute/startup_support.py':
        raise ValueError('Unexpected patch target')
    return m


def _constant(text, name):
    matches = [n for n in ast.parse(text).body
               if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    if len(matches) != 1:
        raise ValueError(f'Expected one source assignment for {name}')
    return ast.literal_eval(matches[0].value), ast.get_source_segment(text, matches[0])


def find_center(namespace=None):
    """Find the existing controller, including a UI closure; never create one."""
    found = {}
    for obj in list((namespace or {}).values()) + gc.get_objects():
        try:
            if type(obj).__name__ == 'ProjectCenter' and type(obj).__module__ == 'vhd.center.controller':
                found[id(obj)] = obj
        except Exception:
            continue
    if len(found) != 1:
        raise RuntimeError(f'Found {len(found)} controllers. Pass the intended existing pc explicitly; do not create another project.')
    return next(iter(found.values()))


def _context(pc):
    if type(pc).__name__ != 'ProjectCenter' or not callable(getattr(pc, 'snapshot', None)):
        raise TypeError('Pass your existing ProjectCenter object as pc')
    source = Path(inspect.getfile(type(pc))).absolute()
    if source.name != 'controller.py' or source.parent.name != 'center' or source.parent.parent.name != 'vhd':
        raise RuntimeError(f'Unexpected controller source: {source}')
    return source.parents[2], pc.snapshot()


def _running(state):
    return [{'section': section, 'sample_or_group': key, 'action': action}
            for section in ('jobs', 'group_jobs')
            for key, jobs in state.get(section, {}).items()
            for action, job in jobs.items() if job.get('status') == 'running']


def _processes():
    import psutil
    found, inaccessible = [], []
    worker_modules = {'vhd.compute.worker', 'vhd.compute.scvi_worker',
                      'vhd.compute.integration_worker', 'vhd.center.single_sample'}
    for p in psutil.process_iter(['pid', 'cmdline']):
        try:
            args = p.info.get('cmdline') or p.cmdline()
            if worker_modules.intersection(args) or (args and Path(args[0]).name.lower() in ('proseg', 'proseg.exe')):
                found.append({'pid': p.pid, 'command': args})
        except (psutil.NoSuchProcess, psutil.ZombieProcess):
            pass
        except psutil.AccessDenied:
            inaccessible.append(p.pid)
    return {'visible_workers': found, 'inaccessible_pids': inaccessible,
            'scope': 'Local PID namespace only; cannot certify remote sessions.'}


def _idle(pc):
    root, state = _context(pc)
    active = _running(state)
    processes = _processes()
    if active or processes['visible_workers']:
        raise RuntimeError('Wait for active jobs before this maintenance operation:\n'+json.dumps({'running_records':active, **processes},indent=2))
    mod = sys.modules.get('vhd_stardist_startup')
    if mod is not None and getattr(mod, '_ACTIVE', False):
        raise RuntimeError('A temporary StarDist launch adapter is active.')
    return root, state, processes


def _plan(root):
    m = _manifest()
    path = root/m['relative']
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'Expected an installed regular r1 support module: {path}')
    data = path.read_bytes()
    text = data.decode('utf-8')
    if _constant(text, 'RUNTIME_PATCH_ID')[0] != m['runtime_base_id']:
        raise RuntimeError('This hotfix targets runtime patch r1, not a different pipeline revision.')
    if _constant(text, 'PROSEG_REQUIRED_FLAGS')[0] != m['required_flags']:
        raise RuntimeError('The required flag set differs from the reviewed r1 source; no overwrite allowed.')
    block = _constant(text, 'PROSEG_PROBE')[1]
    if block == m['after']:
        status, new = 'already_installed', data
    elif block == m['before'] and text.count(m['before']) == 1:
        status, new = 'ready_to_patch', text.replace(m['before'], m['after'], 1).encode()
    else:
        raise RuntimeError('The installed Proseg probe is not the reviewed old/new block. No blind replacement was made.')
    compile(new, str(path), 'exec')
    summary = {'patch_id': PATCH_ID, 'target': str(path), 'status': status,
               'before_sha256': _sha(data), 'after_sha256': _sha(new),
               'required_flag_count_unchanged': len(m['required_flags']),
               'unrelated_edits_preserved': _sha(data) not in (m['original_file_sha256'],m['corrected_reference_file_sha256'])}
    return path, data, new, summary


def preview(pc):
    """Read source/state and print the one-block change; no files are written."""
    root, state = _context(pc)
    _, _, _, plan = _plan(root)
    report = {**plan, 'package_root': str(root), 'workspace': str(pc.workspace),
              'running_controller_jobs': _running(state), **_processes(),
              'source_changed': False, 'scientific_jobs_started': False,
              'managed_config_changed': False}
    print(json.dumps(report, indent=2))
    return report


def _binary_stamp(path):
    # Stat follows the executable to detect ordinary replacement between steps.
    # Do not canonicalize the configured invocation or the worker venv Python.
    p = Path(path)
    if not p.is_absolute() or not p.is_file() or not os.access(p, os.X_OK):
        raise ValueError(f'Expected a verified absolute executable path: {p}')
    s = p.stat()
    return {'path': str(p), 'size': s.st_size, 'mtime_ns': s.st_mtime_ns,
            'ctime_ns': s.st_ctime_ns, 'dev': s.st_dev, 'inode': s.st_ino}


def _configured(pc, state, sample_keys):
    from vhd.control.manifest import row_config
    python_exe = str(state['project']['settings']['execution']['python_spatial'])
    _binary_stamp(python_exe)
    entries = {}
    for key in sample_keys:
        row = pc.row(key, state['project'])
        cfg, _ = row_config(state['project'], row)
        binary = str(cfg['proseg']['executable'])
        k = (python_exe, binary)
        if k not in entries:
            entries[k] = {'python': python_exe, 'proseg': binary, 'samples': [],
                          'python_stamp': _binary_stamp(python_exe), 'proseg_stamp': _binary_stamp(binary)}
        entries[k]['samples'].append(key)
    return list(entries.values())


def verify_configured_binary(pc, *, sample_keys=DEFAULT_SAMPLES, audit_root=None):
    """Test corrected help parsing against each configured binary BEFORE source changes.

    Launches only --version and --help in the configured Python. No input matrices,
    images or scientific jobs are involved. Writes logs in a new diagnostic folder.
    """
    keys = list(dict.fromkeys(map(str, sample_keys)))
    if not keys:
        raise ValueError('Select at least one sample for executable verification')
    root, state, processes = _idle(pc)
    _, old, _, plan = _plan(root)
    m = _manifest()
    new_probe = _constant(m['after'], 'PROSEG_PROBE')[0]
    from vhd.compute import startup_support as native
    if Path(native.__file__).absolute() != root/m['relative']:
        raise RuntimeError('The imported startup module belongs to a different package.')
    entries = _configured(pc, state, keys)
    base = Path(audit_root).expanduser().absolute() if audit_root is not None else Path.cwd()/'proseg_cli_hotfix_audits'
    # Keep the diagnostic directory outside the master/source stores.
    for row in state['project']['rows']:
        for field in ('master_store','spaceranger_outs','bin_input','cell_input'):
            protected = row.get(field)
            if protected and '://' not in str(protected):
                p = Path(protected).expanduser().absolute()
                if base == p or p in base.parents:
                    raise ValueError(f'Diagnostic output overlaps a scientific source/store: {p}')
    run = base/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'_'+uuid.uuid4().hex[:8])
    run.mkdir(parents=True, exist_ok=False)
    receipt = {'patch_id':PATCH_ID,'status':'checking','package_root':str(root),
               'workspace':str(pc.workspace),'context_sha256':_context_hash(state),
               'source_sha256':_sha(old),'sample_keys':keys,'executables':entries,
               'audit_directory':str(run),'results':[],
               'scientific_jobs_started':False,'source_changed':False,
               'environment_note':'Inherits notebook environment with CUDA_VISIBLE_DEVICES empty; native startup repeats checks in worker environment.'}
    _json(run/'verification.json',receipt)
    try:
        env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONUNBUFFERED='1')
        for i, entry in enumerate(entries):
            prefix = run/f'proseg_{i}'
            command = [entry['python'],'-B','-u','-c',new_probe,entry['proseg'],
                       json.dumps(m['required_flags']),str(prefix)]
            result = native.run_probe(command, env=env, cwd=root, timeout=120,
                                      log_path=run/f'check_{i}.log', heartbeat_seconds=15)
            audit = json.loads(prefix.with_name(prefix.name+'.help_audit.json').read_text())
            if result.get('status') != 'passed' or audit['missing_after_normalization']:
                raise RuntimeError('Corrected probe did not establish required CLI support.')
            receipt['results'].append(audit)
        _, now, _ = _idle(pc)
        if _context_hash(now) != receipt['context_sha256'] or _plan(root)[1] != old:
            raise RuntimeError('Source/configuration changed during the test. No patch was installed.')
        for entry in entries:
            if _binary_stamp(entry['python']) != entry['python_stamp'] or _binary_stamp(entry['proseg']) != entry['proseg_stamp']:
                raise RuntimeError('An executable changed during verification.')
        receipt['status'] = 'passed'
    except BaseException as exc:
        receipt.update(status='failed',error=repr(exc))
        raise
    finally:
        _json(run/'verification.json',receipt)
        print('Proseg CLI verification record:',run/'verification.json')
    print('Corrected help check passed; no segmentation was started.')
    return receipt


def _atomic(path, data, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp = path.with_name(path.name+'.tmp-'+uuid.uuid4().hex)
    try:
        with tmp.open('xb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp,mode)
        os.replace(tmp,path)
    finally:
        tmp.unlink(missing_ok=True)


def _json(path, record):
    _atomic(path,(json.dumps(record,indent=2,default=str)+'\n').encode())


def apply_patch(pc, verification, *, confirmed_all_pipeline_sessions_idle=False):
    """Install only the reviewed probe block; never mutate scientific/controller state."""
    if not confirmed_all_pipeline_sessions_idle:
        raise PermissionError('Confirm all sessions sharing this package are idle; installation changes one source file and requires kernel restart.')
    if verification.get('patch_id') != PATCH_ID or verification.get('status') != 'passed':
        raise ValueError('A successful verify_configured_binary() receipt is required.')
    with pc.store.exclusive():
        root, state, process_report = _idle(pc)
        path, old, new, plan = _plan(root)
        if plan['status'] == 'already_installed':
            print('Hotfix already installed. Restart pipeline kernels before using it.')
            return {**plan, 'restart_required':True}
        if str(root) != verification['package_root'] or _context_hash(state) != verification['context_sha256'] or _sha(old) != verification['source_sha256']:
            raise RuntimeError('Source/configuration changed since verification. Run preview and verify again.')
        if not verification.get('results') or any(r.get('missing_after_normalization') or r.get('help_check_id') != _manifest()['help_check_id'] for r in verification['results']):
            raise RuntimeError('Missing or invalid corrected-check evidence.')
        entries = _configured(pc,state,verification['sample_keys'])
        if entries != verification['executables']:
            raise RuntimeError('Executable mapping/identity changed since verification.')
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'_'+uuid.uuid4().hex[:8]
        backup = root.parent/(root.name+'.proseg_help_hotfix_backups')/stamp
        maintenance = root/'.vhd_proseg_help_hotfix_install.lock'
        # This is an installer-owned lock, not a scientific worker/transaction lock.
        fd = os.open(maintenance, os.O_CREAT|os.O_EXCL|os.O_WRONLY, 0o600)
        os.write(fd,json.dumps({'pid':os.getpid(),'patch_id':PATCH_ID}).encode());os.close(fd)
        audit = {**plan, 'status':'preparing', 'package_root':str(root), 'workspace':str(pc.workspace),
                 'backup_directory':str(backup),'target':str(path),'process_observation':process_report,
                 'verification_directory':verification['audit_directory'],'restart_required':True,
                 'managed_state_changed':False,'scientific_jobs_started':False}
        mode = stat.S_IMODE(path.stat().st_mode)
        written = False
        try:
            backup.mkdir(parents=True,exist_ok=False)
            _atomic(backup/'startup_support.py.before',old,mode)
            _json(backup/'controller_snapshot_before.json',state)
            _json(backup/'installation.json',audit)
            if path.read_bytes() != old:
                raise RuntimeError('Source changed immediately before replacement.')
            _atomic(path,new,mode);written=True
            if path.read_bytes() != new:
                raise IOError('Installed file does not match the reviewed result.')
            if _state_hash(pc.snapshot()) != _state_hash(state):
                raise RuntimeError('Controller state changed during source-only maintenance.')
            audit.update(status='installed',state_unchanged=True)
            _json(backup/'installation.json',audit)
        except BaseException as exc:
            restored = False
            if written and path.read_bytes() == new:
                _atomic(path,old,mode);restored=True
            audit.update(status='failed_restored' if restored else 'failed_inspect_backup',error=repr(exc))
            if backup.exists():_json(backup/'installation.json',audit)
            raise
        finally:
            maintenance.unlink(missing_ok=True)
    print('INSTALLED:',PATCH_ID)
    print('Backup:',backup)
    print('Restart all kernels importing this package, reopen the SAME workspace, then use the normal Run button.')
    return audit


def restore_backup(pc, backup_directory, *, confirmed_all_pipeline_sessions_idle=False):
    """Restore this code hotfix only. Does NOT restore old controller snapshots."""
    if not confirmed_all_pipeline_sessions_idle:
        raise PermissionError('Exclusive maintenance confirmation is required.')
    backup = Path(backup_directory).absolute()
    audit = json.loads((backup/'installation.json').read_text())
    if audit.get('patch_id') != PATCH_ID or audit.get('status') != 'installed':
        raise ValueError('Expected a successful installation audit from this hotfix.')
    with pc.store.exclusive():
        root,state,_ = _idle(pc)
        path,old,_,plan = _plan(root)
        original = (backup/'startup_support.py.before').read_bytes()
        if str(root) != audit['package_root'] or _sha(old) != audit['after_sha256'] or _sha(original) != audit['before_sha256']:
            raise RuntimeError('Source/backup mismatch; no blind restore allowed.')
        _atomic(path,original,stat.S_IMODE(path.stat().st_mode))
        if _state_hash(pc.snapshot()) != _state_hash(state):
            raise RuntimeError('Controller state changed during maintenance; inspect it.')
        _json(backup/'restore.json',{'patch_id':PATCH_ID,'status':'code_restored','restart_required':True,
                                    'managed_state_changed':False,'scientific_jobs_started':False})
    print('Original runtime-r1 support code restored; restart kernels. The original help-parsing bug is restored too.')
