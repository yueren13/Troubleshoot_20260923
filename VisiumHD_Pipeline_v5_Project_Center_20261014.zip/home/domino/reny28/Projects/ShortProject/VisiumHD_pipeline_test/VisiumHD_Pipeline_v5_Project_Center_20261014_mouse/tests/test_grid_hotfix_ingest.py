"""Exercise real ingest orchestration with explicitly stubbed count/image/parquet I/O.

The numeric fitter, barcode-file read, JSON, stage lock and completion receipts
are real. These are not AnnData/SpatialData storage roundtrip tests.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
from vhd import io
from vhd.core import affine, transform_xy
from vhd.grid_geometry import GridGeometryError


class CountFixture:
    def __init__(self, names):
        self.obs=pd.DataFrame(index=pd.Index(names))
        self.var=pd.DataFrame({'gene_symbol':['GENE_A','GENE_B','MT-CO1']},index=['id1','id2','id3'])
        self.X=sparse.csr_matrix(np.tile([1,2,3],(len(names),1)),dtype=np.int32)
        self.obsm={};self.uns={}
    @property
    def obs_names(self):return self.obs.index
    @property
    def n_obs(self):return len(self.obs)
    @property
    def n_vars(self):return len(self.var)


def fixture(tmp_path,monkeypatch,*,bad=False,reverse=False):
    base=tmp_path/'outs'/'binned_outputs'/'square_002um'
    (base/'spatial').mkdir(parents=True);(base/'raw_feature_bc_matrix').mkdir()
    r,c=np.mgrid[:12,:15];r=r.ravel();c=c.ravel()
    xy=np.rint(transform_xy(np.c_[c,r],affine([7.71,.11,300,.13,7.82,700])))
    if bad:xy[0,0]+=5.123
    names=[f'BC{i:04}' for i in range(len(r))]
    pos=pd.DataFrame({'barcode':names,'array_row':r,'array_col':c,
        'pxl_col_in_fullres':xy[:,0],'pxl_row_in_fullres':xy[:,1],'in_tissue':np.ones(len(r),dtype=int)})
    (base/'raw_feature_bc_matrix'/'barcodes.tsv').write_text('\n'.join(names)+'\n')
    (base/'spatial'/'tissue_positions.parquet').write_text('stub parquet bytes')
    (base/'spatial'/'scalefactors_json.json').write_text(json.dumps({'microns_per_pixel':.25}))
    img=tmp_path/'image.svs';img.write_text('stub image bytes')
    # Return shuffled parquet rows to ensure joining rather than row-position assumptions.
    monkeypatch.setattr(pd,'read_parquet',lambda *a,**k:pos.sample(frac=1,random_state=21).copy())
    calls=[];captured=[]
    def read_counts(path):
        calls.append(path)
        return CountFixture(list(reversed(names)) if reverse else names)
    def write_count_stub(a,path):
        captured.append({'obs':a.obs.copy(),'xy':a.obsm['spatial'].copy(),'X':a.X.copy()})
        Path(path).write_bytes(b'explicitly-stubbed-h5ad-not-a-real-object')
    monkeypatch.setattr(io,'read_raw_counts',read_counts)
    monkeypatch.setattr(io,'write_h5ad',write_count_stub)
    monkeypatch.setattr(io,'image_info',lambda *a,**k:{'mpp':[.25,.25],'width':1500,'height':1500})
    cfg={'work_root':str(tmp_path/'work'),'output_root':str(tmp_path/'output'),
         'coordinates':{'grid_max_residual_px':.1}}
    spec={'sample':'S','outs':str(tmp_path/'outs'),'image':str(img),'tenx_to_image_affine':np.eye(3).tolist()}
    return cfg,spec,calls,captured,pos


def test_ingest_checks_grid_before_reading_counts(tmp_path,monkeypatch):
    cfg,spec,calls,captured,pos=fixture(tmp_path,monkeypatch,bad=True)
    with pytest.raises(GridGeometryError):io.ingest(cfg,spec)
    assert calls==[] and captured==[]
    assert not (tmp_path/'work'/'S'/'bins_raw.h5ad').exists()
    assert not (tmp_path/'work'/'S'/'geometry.json').exists()
    assert not (tmp_path/'work'/'S'/'.ingest.lock').exists()
    rep=json.loads((tmp_path/'output'/'reports'/'S'/'grid_coordinate_diagnostic.json').read_text())
    assert rep['status']=='blocked' and rep['counts_loaded_for_this_check'] is False


def test_success_preserves_source_centers_counts_and_order(tmp_path,monkeypatch):
    cfg,spec,calls,captured,pos=fixture(tmp_path,monkeypatch)
    result=io.ingest(cfg,spec)
    assert result['grid_fit']['acceptance']=='verified_integer_pixel_rounding'
    assert len(calls)==len(captured)==1
    out=captured[0]
    np.testing.assert_array_equal(out['xy'],pos[['pxl_col_in_fullres','pxl_row_in_fullres']])
    np.testing.assert_array_equal(out['X'].toarray(),np.tile([1,2,3],(len(pos),1)))
    assert out['obs'].index.tolist()==pos.barcode.tolist()
    assert out['obs']['array_col'].tolist()==pos.array_col.tolist()
    assert result['input_total_umis']==len(pos)*6
    assert result['grid_fit']['source_microns_per_pixel']==.25


def test_successful_rerun_uses_verified_receipt(tmp_path,monkeypatch):
    cfg,spec,calls,captured,pos=fixture(tmp_path,monkeypatch)
    a=io.ingest(cfg,spec);b=io.ingest(cfg,spec)
    assert a==b and len(calls)==1


def test_changing_policy_invalidates_ingest_receipt(tmp_path,monkeypatch):
    cfg,spec,calls,captured,pos=fixture(tmp_path,monkeypatch)
    io.ingest(cfg,spec)
    cfg['coordinates']['grid_rounding_policy']='strict'
    with pytest.raises(RuntimeError,match='Stale/incomplete'):io.ingest(cfg,spec)


def test_reader_barcode_order_change_rejected(tmp_path,monkeypatch):
    cfg,spec,calls,captured,pos=fixture(tmp_path,monkeypatch,reverse=True)
    with pytest.raises(ValueError,match='barcode order'):io.ingest(cfg,spec)
    assert not captured


def test_partial_product_protection_is_preserved(tmp_path,monkeypatch):
    cfg,spec,calls,captured,pos=fixture(tmp_path,monkeypatch)
    work=tmp_path/'work'/'S';work.mkdir(parents=True)
    (work/'bins_raw.h5ad').write_bytes(b'preexisting-partial-do-not-delete')
    with pytest.raises(RuntimeError,match='Partial/untracked'):io.ingest(cfg,spec)
    assert not calls
    assert (work/'bins_raw.h5ad').read_bytes()==b'preexisting-partial-do-not-delete'
