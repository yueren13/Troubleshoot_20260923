# Start here — consolidated v4 review candidate

This is a complete source bundle, not another overlay hotfix. Extract it into a **new code directory**, preserve the working v3 tree and environments, and restart notebook kernels. Do not replace code underneath a live writer. Use a new run/master destination for the v4 pilot; v3 signatures are not automatically adopted or rewritten.

## 1. Edit configuration once

| File | What to enter |
|---|---|
| `config/project_paths.json` | Your source-project, fast-work and master roots. These must already exist. They may all be subdirectories of an approved home project. |
| `config/settings.json` | Actual worker Python executables, hardware limits, storage acknowledgement, fresh bin-QC cutoffs and analysis policy. `current` selects the notebook interpreter without resolving away its venv symlink. |
| `config/samples.csv` | One row per actual sample, correct source paths, entry stage, target master, metadata and optional asset manifest. |
| `config/assets.csv` | One row per annotation/signal, explicit purpose, format, transform, coverage and aggregation. |
| `config/metadata/*.json` | Sample metadata, including `species` for species-specific analysis QC. |
| `config/overrides/*.json` | Deliberate per-sample settings, such as enabling annotation-based prior filtering only for the sample with reviewed QC polygons. |

The three starter rows are **illustrative**, not guesses at the user's new selected samples. They show a trusted QC annotation, an unreliable reference-only layer, an analysis annotation and a binary 1:9 TIFF. `samples.raw_three.example.csv` starts all three from raw; `samples.mixed_entry.example.csv` demonstrates raw, existing QC bins and existing cells together. Copy the desired version to `samples.csv` and edit it. Do not use a historical manifest with different column names as a drop-in replacement.

Relative sidecar paths resolve from the CSV folder. The optional `path_variables_file` in settings is loaded before the CSV, so shell variables do not need to be set in every notebook. Explicit file values control those names in the current kernel. Do not leave `/EDIT/` paths in a real run. Existing v3 manifests without new asset columns remain readable; legacy role aliases are mapped explicitly.

`current` is convenient only when that kernel environment really contains the relevant packages. Separate CPU/StarDist/scVI/RAPIDS environments remain supported. The pipeline does not install packages or upgrade an environment. Test dependencies include pytest; the requirements files are guidance, not a verified GPU lockfile.

## 2. Mode and sample scope

Every notebook starts with:

```python
RUN_MODE = "preview"
SAMPLE_KEYS = None
ALLOW_ALL_SAMPLES = False
```

To execute all enabled **sample** rows, use `RUN_MODE="execute"`, `SAMPLE_KEYS=None`, `ALLOW_ALL_SAMPLES=True`. To select particular samples, list their `dataset_id__sample_id` values. Rerun controls and initialization after edits. `VHD_EXECUTE` is not the mode switch in these notebooks. Integration notebooks instead use all enabled rows in the explicit `GROUP`; a sample selection does not silently change a pooled group.

Two workers means a queue for the whole selected cohort with up to two concurrent samples, not a two-sample experiment. Unknown RAM/job intentionally restricts concurrency. Enter a reviewed estimate and mark its provenance; it is not an enforced RAM limit. Never use overlapping writers for the same master. No one-hour throughput guarantee is made.

## 3. Recommended route for the new end-to-end pilot

| Step | Notebook / review boundary |
|---|---|
| Setup | **00**: inspect resolved paths, sample actions, output index and scientific parameters. |
| Validate environment | **99**: working-mode validator and CPU tests, then actual scientific roundtrip tests in the appropriate environment. Inspect skips. |
| Prepare bins | **01** imports raw or supplied bins; **02** measures/reuses QC. Fresh H&E/transcript thresholds remain explicitly unset until selected. Review source registration and new QC before signing the CSV flags. |
| Import annotation/image sources | **02A** writes optional layers and previews; reference-only sources are retained but not consumed. Approve only specific inspected active asset IDs. |
| Assign bins | **02B** recomputes source-owned metadata, clears obsolete owned columns and derives the configured prior eligibility. |
| New segmentation | **03** StarDist → **04** Proseg → **05** cell reconstruction/QC. Prior exclusion and input-bin exclusion remain separate. |
| Master/readback | **06** adds/assembles cells; **07** reads selected table metadata or counts. Compact images are the new starter policy. |
| Cell annotation refresh | **05B**, after the cell table exists, transfers active bin metadata using real cell polygons without changing RNA counts. It is not necessary for sources with no cell transfer or for samples without assets. |
| Analysis QC | **07A**: species-aware MT threshold, raw counts per cell, gene detection among retained cells. Creates keyed sidecars, not a reduced master. |
| Model/clusters | **08 → 09 → 10 → 11**, explicit integration group, unchanged count input, Leiden 0.1–1.0 and one UMAP layout. |
| Optional | **07B** replot only; **12** publication; **13** deliberate master metadata update. |

For existing cells, use **00B → review → 06 → 07**, then **07A → 08–11**. No new StarDist/Proseg run is needed. For a cell-only source, active image/polygon-to-bin transfer still requires bin data; reference-only sources may be retained without bins. Bin/cell count-first migration is not an archival copy of every source layer/graph.

## 4. Approving an asset is not enabling all annotations

In 02A, first inspect its whole-field/ROI preview. Then list only accepted IDs in the explicit approval cell:

```python
APPROVE_ASSETS = {
    "StudyExample__Sample01": ["qc_regions", "tissue_regions"],
    "StudyExample__Sample02": ["binary_signal"],
}
```

This is an example, not a recommendation to approve unseen data. In execute mode, the helper checks that the source and transformation still match the imported preview, backs up the active asset CSV, and saves those signatures. It refuses to approve `reference_only`. Empty `{}` means no new approvals. No copy/paste of long fingerprints is required, but the same signature validation remains enforced.

`coordinates_reviewed` approves the sample/image registration. `reviewed_signature` approves a particular imported asset transform. `fresh_qc_reviewed` approves new bin QC. `storage.single_writer_ack` confirms the write destination and lack of concurrent readers/writers. They are distinct facts, not one generic run switch.

## 5. Finding outputs and recognizing completion

Run the output-index cell in 00 or `output_index(PROJECT, SAMPLE_KEYS, save=True)`. It records complete paths and current existence for master, work, reports, cell overlay and logs. Reports initially live under the retained working tree, not necessarily publication directories. A printed path or successful preview is **not** a built product.

Keep one manifest/settings/run identity through a stage sequence. Assembly needs prepared v4 inputs in that same workspace. Failures retain logs and partial objects for inspection. Never rename a bin table to cells, delete partial stores broadly, lower RAM estimates to bypass a scheduler check, or set unreviewed flags just to remove an error.
