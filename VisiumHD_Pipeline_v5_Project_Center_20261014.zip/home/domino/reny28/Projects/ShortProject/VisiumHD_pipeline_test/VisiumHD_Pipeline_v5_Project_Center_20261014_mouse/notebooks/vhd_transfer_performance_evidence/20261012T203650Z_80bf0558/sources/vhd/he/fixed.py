"""User-defined fixed H&E measurement with explicit numerical contracts.

Preserves reference OLS then clipping, fixed divisors, and combine-image-before-
center-sampling. Scores are tissue evidence, not probabilities or physical mass.
"""
from __future__ import annotations
import numpy as np
from scipy.ndimage import map_coordinates
from ..core import affine

HE_REFERENCE=np.array([[.5626,.2159],[.7201,.8012],[.4062,.5581]],dtype=np.float64)


def positive_int(value,name):
    if isinstance(value,bool) or not np.isfinite(value) or value<1 or int(value)!=value:
        raise ValueError(f'{name} must be a positive integer.')
    return int(value)


def rgb255(img,*,channel_axis=None,intensity_range=None,alpha='reject'):
    dims=getattr(img,'dims',())
    if channel_axis is None and dims:
        axes=[i for i,x in enumerate(dims) if x in ('c','channel','channels')]
        if len(axes)==1:channel_axis=axes[0]
    a=np.asarray(img)
    if a.ndim!=3:raise ValueError('RGB input must be 3-dimensional.')
    if channel_axis is None:
        axes=[i for i in (0,2) if a.shape[i] in (3,4)]
        if len(axes)!=1:raise ValueError('Ambiguous RGB dimensions; specify channel_axis.')
        channel_axis=axes[0]
    a=np.moveaxis(a,channel_axis,-1)
    if a.shape[-1] not in (3,4):raise ValueError('Need RGB/RGBA channels.')
    explicitly_declared=intensity_range is not None
    lo,hi=map(float,intensity_range if intensity_range is not None else (0,255))
    if not np.isfinite([lo,hi]).all() or hi<=lo:raise ValueError('Invalid intensity_range.')
    if not a.size or not np.isfinite(a).all() or np.any(a<lo) or np.any(a>hi):raise ValueError('Invalid values or values outside declared intensity range.')
    if np.issubdtype(a.dtype,np.floating) and not explicitly_declared and (lo,hi)==(0.,255.) and a.max()<=1:
        raise ValueError('Float 0..1 image is ambiguous under 0..255 convention; explicitly set intensity_range=(0,1).')
    a=(a.astype(np.float32)-lo)*np.float32(255/(hi-lo))
    if a.shape[-1]==4:
        if alpha=='white':a=a[...,:3]*(a[...,3:4]/255)+255*(1-a[...,3:4]/255)
        elif alpha=='opaque_only' and (a[...,3]==255).all():a=a[...,:3]
        else:raise ValueError('Select alpha="white" or opaque_only for RGBA.')
    return a


def estimate_background_Io_rgb(img_hwc,*,sat_max=.08,value_quantile=90,io_quantile=99.5,fallback=255,min_pixels=1000):
    """Call ONCE per source/calibration ROI, store result, never estimate per tile."""
    from matplotlib.colors import rgb_to_hsv
    a=rgb255(img_hwc,channel_axis=-1,intensity_range=(0,255))
    if not 0<=sat_max<=1 or not 0<=value_quantile<=100 or not 0<=io_quantile<=100:raise ValueError('Invalid background calibration parameters.')
    positive_int(min_pixels,'min_pixels')
    hsv=rgb_to_hsv(a/255)
    mask=(hsv[...,1]<=sat_max)&(hsv[...,2]>=np.percentile(hsv[...,2],value_quantile))
    if mask.sum()<min_pixels:return np.full(3,fallback,dtype=np.float32)
    io=np.percentile(a[mask],io_quantile,axis=0)
    return np.where(np.isfinite(io)&(io>10),io,fallback).astype(np.float32)


def extract_he_concentrations_reference(img,*,Io=255.,white_balance=False,clip_concentrations=True,
        lstsq_batch=200000,channel_axis=None,intensity_range=None,reference=HE_REFERENCE,alpha='reject'):
    a=rgb255(img,channel_axis=channel_axis,intensity_range=intensity_range,alpha=alpha)
    basis=np.asarray(reference,np.float64);batch=positive_int(lstsq_batch,'lstsq_batch')
    if basis.shape!=(3,2) or not np.isfinite(basis).all() or np.linalg.matrix_rank(basis)!=2:raise ValueError('Reference must be finite full-rank 3x2; columns are NOT silently renormalized.')
    io=estimate_background_Io_rgb(a) if white_balance else np.asarray(Io,dtype=np.float32)
    if io.ndim==0:io=np.full(3,float(io),dtype=np.float32)
    if io.shape!=(3,) or not np.isfinite(io).all() or np.any(io<=1):raise ValueError('Io must be scalar/RGB >1 in the canonical 0..255 convention.')
    flat=a.reshape(-1,3);c=np.empty((2,len(flat)),np.float32)
    for start in range(0,len(flat),batch):
        x=np.maximum(np.minimum(flat[start:start+batch],io-1),0)
        od=-np.log((x+1)/io)
        v=np.linalg.lstsq(basis,od.T,rcond=None)[0].astype(np.float32)
        if clip_concentrations:np.maximum(v,0,out=v)
        c[:,start:start+len(x)]=v
    return c[0].reshape(a.shape[:2]),c[1].reshape(a.shape[:2]),io


def combine_he_fixed_tissue_signal(H_fixed,E_fixed,*,method='soft_union',h_weight=1.,e_weight=1.,score_threshold=None,h_threshold=None,e_threshold=None):
    H=np.asarray(H_fixed,np.float32);E=np.asarray(E_fixed,np.float32)
    if H.shape!=E.shape:raise ValueError('H/E shapes must match exactly; broadcasting is forbidden.')
    if np.isinf(H).any() or np.isinf(E).any():raise ValueError('Infinite stain coefficients are invalid.')
    if not np.isfinite([h_weight,e_weight]).all() or min(h_weight,e_weight)<0 or h_weight+e_weight<=0:raise ValueError('Weights must be finite, nonnegative, and not both zero.')
    H=np.clip(H,0,1);E=np.clip(E,0,1);hw=np.clip(h_weight*H,0,1);ew=np.clip(e_weight*E,0,1)
    if method=='soft_union':score=1-(1-hw)*(1-ew)
    elif method=='max':score=np.maximum(hw,ew)
    elif method=='weighted_mean':score=(h_weight*H+e_weight*E)/(h_weight+e_weight)
    else:raise ValueError('Use soft_union, max, or weighted_mean.')
    if (h_threshold is None)!=(e_threshold is None):raise ValueError('Supply both stain thresholds or neither.')
    if score_threshold is not None and h_threshold is not None:raise ValueError('Choose score threshold OR stain thresholds, not both.')
    for t in (score_threshold,h_threshold,e_threshold):
        if t is not None and (not np.isfinite(t) or not 0<=t<=1):raise ValueError('Thresholds must be finite in [0,1].')
    mask=None
    if score_threshold is not None:mask=score>=score_threshold
    elif h_threshold is not None:mask=(H>=h_threshold)|(E>=e_threshold)
    if mask is not None:mask &= np.isfinite(H)&np.isfinite(E)
    return np.clip(score,0,1).astype(np.float32),mask


def fixed_scale_he_tissue_score(H_conc,E_conc,*,h_limit=1.9705,e_limit=1.0308,h_weight=1.,e_weight=1.,method='soft_union'):
    if not np.isfinite([h_limit,e_limit]).all() or min(h_limit,e_limit)<=0:raise ValueError('Fixed limits must be positive finite values.')
    H=np.asarray(H_conc,np.float32);E=np.asarray(E_conc,np.float32)
    if H.shape!=E.shape:raise ValueError('H/E shapes differ.')
    hn=np.clip(H/h_limit,0,1);en=np.clip(E/e_limit,0,1)
    score,_=combine_he_fixed_tissue_signal(hn,en,method=method,h_weight=h_weight,e_weight=e_weight)
    return score,hn,en


def combine_he_tissue_signal(H_u8,E_u8,**kwargs):
    """Legacy display-only wrapper. Do not feed per-image percentile-scaled maps."""
    kwargs.setdefault('h_weight',.6)
    return combine_he_fixed_tissue_signal(np.asarray(H_u8,np.float32)/255,np.asarray(E_u8,np.float32)/255,**kwargs)


def sample_field(field,xy,*,source_to_fullres,interpolation='linear',chunk_size=250000,tile_size=512):
    """Interpolate image pixel-CENTER indices at bin centers, not area averages.

    Supports sliceable numpy/memmap/Zarr arrays; groups points into bounded tile
    reads. NaN measurements remain invalid even when coordinates are in bounds.
    """
    n=positive_int(chunk_size,'chunk_size');tile=positive_int(tile_size,'tile_size')
    if len(field.shape)!=2:raise ValueError('Scalar field must be 2D.')
    if interpolation not in ('nearest','linear'):raise ValueError('Use nearest or linear.')
    xy=np.asarray(xy,np.float64)
    if xy.ndim!=2 or xy.shape[1]!=2:raise ValueError('Coordinates must be N x 2.')
    inv=np.linalg.inv(affine(source_to_fullres));height,width=field.shape
    value=np.full(len(xy),np.nan,np.float32);inside=np.zeros(len(xy),bool)
    for start in range(0,len(xy),n):
        uv=xy[start:start+n]@inv[:2,:2].T+inv[:2,2];x,y=uv.T
        ok=np.isfinite(uv).all(axis=1)&(x>=0)&(y>=0)&(x<=width-1)&(y<=height-1)
        ids=np.flatnonzero(ok)+start;inside[ids]=True
        if not len(ids):continue
        x=x[ok];y=y[ok];tx=(x//tile).astype(int);ty=(y//tile).astype(int)
        key=ty*((width+tile-1)//tile)+tx;order=np.argsort(key,kind='stable')
        cut=np.r_[0,np.flatnonzero(np.diff(key[order]))+1,len(order)]
        for l,r in zip(cut[:-1],cut[1:]):
            j=order[l:r];x0=int(tx[j[0]])*tile;y0=int(ty[j[0]])*tile
            patch=np.asarray(field[y0:min(height,y0+tile+1),x0:min(width,x0+tile+1)],np.float32)
            value[ids[j]]=map_coordinates(patch,np.vstack([y[j]-y0,x[j]-x0]),order=0 if interpolation=='nearest' else 1,mode='constant',cval=np.nan,prefilter=False)
    return value,inside,inside&np.isfinite(value)


def map_hires_image_to_visiumhd_bins(adata,image_2d,*,tissue_hires_scalef,out_key,spatial_key='spatial',interpolation='linear',chunk_size=1000000,show_progress=True):
    f=float(tissue_hires_scalef)
    if not np.isfinite(f) or f<=0:raise ValueError('Scale must be positive finite.')
    xy=np.asarray(adata.obsm[spatial_key])
    if xy.shape!=(adata.n_obs,2):raise ValueError('Require one x,y pair per observation.')
    v,inside,valid=sample_field(image_2d,xy,source_to_fullres=np.diag([1/f,1/f,1]),interpolation=interpolation,chunk_size=chunk_size)
    adata.obs[out_key]=v;adata.obs[out_key+'_in_bounds']=inside;adata.obs[out_key+'_valid']=valid
    adata.uns[out_key+'_mapping']={'definition':'image_score_then_bin_center_interpolation','tissue_hires_scalef':f,'interpolation':interpolation,'n_valid':int(valid.sum())}
    return v
