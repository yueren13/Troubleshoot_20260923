"""Visium HD review workflow; scientific stage version is in core.VERSION."""
__version__ = "0.4.1.1-review"
