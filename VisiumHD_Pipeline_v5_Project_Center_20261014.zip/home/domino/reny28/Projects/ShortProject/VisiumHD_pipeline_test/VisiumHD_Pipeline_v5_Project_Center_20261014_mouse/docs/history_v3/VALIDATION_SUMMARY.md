# V3 validation record — 2026-09-28

## What actually ran

| Check | Result |
|---|---|
| Available local test collection | **119 passed, 5 skipped** |
| Python syntax | **57 source/test/tool files passed** |
| Notebook format | **19 notebooks passed** |
| Notebook code-cell compilation | **56 cells passed** |
| JSON settings / CSV structural checks | Passed |
| V2 helper source identity | Exact git tree `e8ccb93e6323590aefe5c29b152474ec3def4c87` |
| Helper-only patch vs foundation | `git apply --check` passed (34 changed helper files) |
| Repository preparation tool | Preview did not modify files; apply left project_1 intact and did not commit; dirty repository was rejected |

The current test stdout is in PYTEST_OUTPUT.txt. Static results are in
STATIC_VALIDATION.json. Package versions are recorded in VALIDATION_ENVIRONMENT.json.
The helper baseline/handoff verification is in SOURCE_HANDOFF_VALIDATION.json.

The tests exercise the user-derived H&E equations against the supplied reference
transcription, same-patch/batch behavior, interpolation order, missing measurements,
XML negative-region holes, annotation replacement/coverage, bin-center prior decisions,
metadata aggregation, model receipt states, allowed paths, and injected interrupted
filesystem component replacement/rollback. Synthetic files are not real biological
objects or trained models. The existing source/output ancestor-root test was deliberately
updated to test the newly agreed actual-write-target behavior.

## What the five skips mean
Three are entire optional test modules that require AnnData/SpatialData/Zarr and related
packages, not three successful or pending assertions. Two are opt-in model-fitting
tests. Neither AnnData/SpatialData persistence nor actual scVI training was executed
in this environment. There is no installed scientific-stack lockfile validated here.

Not run: full-slide images, full biological samples, actual Space Ranger import,
SpatialData v2/v3 roundtrips, the institution's mounted storage, real StarDist/Proseg,
scVI single-GPU/DDP, RAPIDS/Dask, or S3 API publication. No speed/VRAM/clinical/biological
accuracy or regulatory-compliance claim follows from the CPU suite.

## GitHub validation is a separate scope
Draft PR #3 (`fix/issue-2-scvi-handoff` into `pipeline/visiumhd-v2-foundation`) contains
only the narrow scVI handoff fix and its CI tests. The checked head was
`6de1ffcfc2471b9f5125033493ab15a090f41be9`. GitHub Actions run `36417954852`
completed successfully on Python 3.11 and 3.12. That passing CI is NOT CI of this
entire local v3 candidate. The broad v3 candidate is delivered in the accompanying
ZIP and has not been merged or fully uploaded to GitHub.

## Pilot before updating valuable masters
Use a copied representative sample, run notebook 99 in the actual scientific
environments, then confirm image alignment, metadata readback, and unchanged counts.
Keep prior working environments and accepted products. Use explicit writer acknowledgement
only while no other process is reading/writing the master. Journaled component replacement
is recoverable, not an atomic multi-key transaction. Never delete a lock/journal merely
to bypass an error. Old/incoming component backups are retained deliberately.

Fresh bin-QC thresholds are intentionally unset: the original Step03 numerical decision
logic was not supplied. Set reviewed cutoffs explicitly or reuse accepted legacy QC.
