"""Run with `%run -i VHD_Center_ReadOnly_Diagnostic_v2.py` in the existing Center kernel.

Inspects existing objects, calls their snapshot() method, and reads installed
source. Never creates a controller, invokes recovery, starts/stops a worker,
deletes a lock, changes job state, or writes into the project.
"""
import ast
import gc
import inspect
import json
import os
import sys
from pathlib import Path

# Used ONLY for reading source when the module is not present in sys.modules.
# This path was supplied in the user's traceback; edit only if the package moved.
VHD_SOURCE_ROOT = Path(
    "/home/domino/reny28/Projects/ShortProject/VisiumHD_pipeline_test/"
    "VisiumHD_Pipeline_v5_Project_Center_20261009_human"
)


def _find_existing_centers():
    """Include objects held by closures/containers and subclasses/reloaded classes."""
    found = {}
    # get_objects() enumerates GC-tracked objects; no gc.collect() is requested.
    for obj in gc.get_objects():
        cls = type(obj)
        try:
            matches = any(
                base.__name__ == "ProjectCenter"
                and base.__module__.startswith("vhd.")
                for base in cls.__mro__
            )
        except (AttributeError, ReferenceError):
            continue
        if matches:
            found[id(obj)] = obj
    return list(found.values())


def _class_source(cls):
    try:
        return inspect.getsourcefile(cls) or inspect.getfile(cls)
    except (OSError, TypeError):
        return "source unavailable"


def _show_numbered(lines, first, last):
    first, last = max(1, first), min(len(lines), last)
    for number in range(first, last + 1):
        print(f"{number:4d}: {lines[number - 1]}")


def _show_recovery_source():
    """Read controller recovery methods and nearby UI controls without importing vhd."""
    words = ("recover", "interrupted", "stale", "abandon")
    for leaf in ("controller", "ui"):
        module = sys.modules.get(f"vhd.center.{leaf}")
        filename = vars(module).get("__file__") if module is not None else None
        path = Path(filename) if filename else VHD_SOURCE_ROOT / "vhd" / "center" / f"{leaf}.py"
        print(f"\n--- INSTALLED {leaf.upper()} SOURCE: {path} ---")
        if not path.is_file():
            print("Source not found here. This is not proof that another kernel has no controller.")
            continue
        try:
            text = path.read_text(encoding="utf-8")
            lines = text.splitlines()
            if leaf == "controller":
                tree = ast.parse(text)
                selected = [node for node in ast.walk(tree)
                            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                            and any(word in node.name.lower() for word in words)]
                if selected:
                    for node in sorted(selected, key=lambda item: item.lineno):
                        print(f"\nRecovery-related definition: {node.name}")
                        _show_numbered(lines, node.lineno, node.end_lineno)
                    continue
            # UI labels/callbacks, or fallback if recovery has an unexpected method name.
            hits = [i for i, line in enumerate(lines, 1)
                    if any(word in line.lower() for word in words)]
            selected_lines = set()
            for i in hits:
                selected_lines.update(range(max(1, i - 3), min(len(lines), i + 6) + 1))
            if not selected_lines:
                print("No recovery-related text found with these terms.")
            previous = None
            for i in sorted(selected_lines):
                if previous is not None and i != previous + 1:
                    print("    ...")
                print(f"{i:4d}: {lines[i - 1]}")
                previous = i
        except (OSError, SyntaxError, UnicodeError) as exc:
            print(f"Cannot read this source: {type(exc).__name__}: {exc}")


def inspect_existing_centers():
    print("KERNEL:", sys.executable)
    print("KERNEL PID:", os.getpid(), "(not necessarily a worker PID)")
    print("LOADED CENTER MODULE:", "vhd.center.controller" in sys.modules)
    candidates = _find_existing_centers()
    print("EXISTING CENTER CANDIDATES:", len(candidates))
    for index, obj in enumerate(candidates):
        print(f"\n=== CENTER [{index}] object_id={id(obj)} ===")
        print("Class:", f"{type(obj).__module__}.{type(obj).__name__}")
        print("Source:", _class_source(type(obj)))
        try:
            snap = obj.snapshot()
            if not isinstance(snap, dict):
                raise TypeError(f"Unexpected snapshot type: {type(snap).__name__}")
            running = []
            for sample, jobs in snap.get("jobs", {}).items():
                for step, job in jobs.items():
                    if isinstance(job, dict) and job.get("status") == "running":
                        running.append(dict(sample=sample, step=step, job=job))
            print("Samples recorded:", list(snap.get("jobs", {})))
            print("RUNNING JOB RECORDS:")
            print(json.dumps(running, indent=2, default=str))
        except Exception as exc:
            print(f"Snapshot inspection failed: {type(exc).__name__}: {exc}")
    if len(candidates) == 0:
        print("No candidate found in this kernel. Reading source anyway; no recovery is attempted.")
    elif len(candidates) > 1:
        print("Several candidates found. No controller has been chosen for recovery.")
    _show_recovery_source()
    print("\nInspection finished. No recovery, job launch, cancellation, or lock deletion was performed.")
    return candidates


VHD_CENTERS = inspect_existing_centers()
# Reference an existing object for later inspected recovery; never instantiate one.
pc = VHD_CENTERS[0] if len(VHD_CENTERS) == 1 else None
