"""Validated projective grid model and exact model-derived bin quadrilaterals.

This is deliberately separate from core.affine/transform_xy: a homography must
never be handed to SpatialData as an Affine. Original observed centers remain
unchanged; the model defines corners of array-index unit squares.
"""
from __future__ import annotations
import copy
import math
import numpy as np
from .grid_geometry import GridGeometryError, fit_grid_affine_checked

PROJECTIVE_GRID_PATCH = 'projective-grid-polygons-20261001-v2'


def homography(value):
    h = np.asarray(value, dtype=np.float64)
    if h.shape != (3, 3) or not np.isfinite(h).all():
        raise ValueError('Grid homography must be a finite 3x3 matrix.')
    if abs(h[2, 2]) <= 1e-15:
        raise ValueError('Grid homography must have a nonzero origin denominator.')
    h = h.copy() / h[2, 2]
    if not np.isfinite(h).all() or abs(np.linalg.det(h)) <= 1e-12:
        raise ValueError('Grid homography is singular or non-finite.')
    return h


def project_xy(xy, matrix):
    """Homogeneous divide, retaining arbitrary leading dimensions."""
    p = np.asarray(xy, dtype=np.float64)
    if p.ndim < 2 or p.shape[-1] != 2 or not np.isfinite(p).all():
        raise ValueError('Projective input coordinates must be finite (..., 2).')
    h = homography(matrix)
    den = p @ h[2, :2] + h[2, 2]
    if np.any(np.abs(den) < 1e-8):
        raise ValueError('Projective denominator is too close to zero.')
    out = (p @ h[:2, :2].T + h[:2, 2]) / den[..., None]
    if not np.isfinite(out).all():
        raise ValueError('Non-finite projected coordinates.')
    return out


def is_projective(geometry):
    """Detect matrix semantics, not just a possibly missing descriptive field."""
    h = homography(geometry['grid_index_to_fullres'])
    return bool(np.any(h[2, :2] != 0))


def grid_corners(rows, cols, matrix):
    r, c = np.asarray(rows), np.asarray(cols)
    if r.ndim != 1 or c.shape != r.shape or not np.isfinite(r).all() or not np.isfinite(c).all():
        raise ValueError('Rows and columns must be finite paired 1D arrays.')
    if np.any(r < 0) or np.any(c < 0) or not np.equal(r, np.rint(r)).all() or not np.equal(c, np.rint(c)).all():
        raise ValueError('Bin corner construction requires nonnegative integer grid indices.')
    offsets = np.array([[-.5, -.5], [.5, -.5], [.5, .5], [-.5, .5]])
    return project_xy(np.column_stack([c, r])[:, None, :] + offsets, matrix)


def _domain_audit(h, rows, cols):
    # Denominator is affine-linear: corner extrema certify the complete domain.
    w, height = int(np.max(cols)) + 1, int(np.max(rows)) + 1
    domain = np.array([[-.5, -.5], [w-.5, -.5], [w-.5, height-.5], [-.5, height-.5]])
    den = domain @ h[2, :2] + h[2, 2]
    if not np.isfinite(den).all() or not (np.all(den > 1e-8) or np.all(den < -1e-8)):
        raise ValueError('Projective denominator crosses or approaches zero within the grid footprint.')
    corners = project_xy(domain, h)
    # Invertibility + same-sign denominator maps this convex domain bijectively.
    det = float(np.linalg.det(h))
    if not np.isfinite(det) or abs(det) <= 1e-12:
        raise ValueError('Singular grid homography.')
    return {'grid_domain_index_bounds': [-.5, -.5, w-.5, height-.5],
            'denominator_range': [float(den.min()), float(den.max())],
            'denominator_nonzero_over_entire_domain': True,
            'grid_domain_fullres_corners': corners.tolist(),
            'jacobian_determinant_sign': int(np.sign(det / den[0]**3))}


def _projective_metrics(rows, cols, xy, h, chunk_size):
    maximum = 0.; sums = 0.; axis_max = np.zeros(2); worst = 0
    for start in range(0, len(rows), chunk_size):
        stop = min(len(rows), start + chunk_size)
        pred = project_xy(np.column_stack([cols[start:stop], rows[start:stop]]), h)
        diff = pred - xy[start:stop]; err = np.linalg.norm(diff, axis=1)
        k = int(np.argmax(err))
        if err[k] >= maximum:maximum = float(err[k]); worst = start + k
        sums += float(np.sum(err**2, dtype=np.float64))
        axis_max = np.maximum(axis_max, np.max(np.abs(diff), axis=0))
    return {'max_residual_px': maximum, 'rms_residual_px': math.sqrt(sums/len(rows)),
            'max_abs_axis_residual_px': axis_max.tolist(), 'validated_n_bins': int(len(rows)),
            'worst_bin': {'position_in_input': worst, 'array_row': int(rows[worst]),
                'array_col': int(cols[worst]), 'source_fullres_xy': xy[worst].tolist()}}


def fit_grid_model_checked(rows, cols, fullres_xy, tolerance_px=.1, seed=42, *,
                           rounding_policy='verified_integer', geometry_policy='auto_projective',
                           chunk_size=250_000):
    """Prefer existing affine behavior; otherwise validate a projective model.

    A projective candidate must fit ALL input centers within the unchanged strict
    tolerance, be nonsingular on the whole grid including half-bin corners, and
    contain at least eight input bins (not a four-point exact interpolation).
    It is used with materialized polygon coordinates, never an Affine raster.
    """
    if geometry_policy not in ('affine_only', 'auto_projective'):
        raise ValueError('grid_geometry_policy must be affine_only or auto_projective.')
    try:
        a, report = fit_grid_affine_checked(rows, cols, fullres_xy, tolerance_px, seed,
            rounding_policy=rounding_policy, chunk_size=chunk_size, diagnose_projective=True)
        report.update(geometry_model='affine', bin_representation='affine_raster',
                      model_implementation=PROJECTIVE_GRID_PATCH)
        return a, report
    except GridGeometryError as exc:
        report = copy.deepcopy(exc.report)
        report.update(model_implementation=PROJECTIVE_GRID_PATCH, geometry_policy=geometry_policy)
        if geometry_policy == 'affine_only':
            raise GridGeometryError(str(exc), report) from exc
        candidate = report.get('projective_diagnostic', {})
        try:
            r, c, xy = np.asarray(rows), np.asarray(cols), np.asarray(fullres_xy, dtype=np.float64)
            if len(r) < 8:raise ValueError('Projective fallback needs at least eight bins.')
            if candidate.get('status') != 'diagnostic_only_not_applied':
                raise ValueError('A valid nonsingular projective candidate could not be fitted.')
            h = homography(candidate['matrix'])
            domain = _domain_audit(h, r, c)
            metrics = _projective_metrics(r, c, xy, h, chunk_size)
            if metrics['max_residual_px'] > tolerance_px:
                raise ValueError(f"Projective maximum residual {metrics['max_residual_px']:.6g} px exceeds {tolerance_px} px.")
        except (ValueError, KeyError, np.linalg.LinAlgError) as cause:
            report['projective_rejection'] = str(cause)
            report['reason'] = 'Affine and validated-projective models were rejected: ' + str(cause)
            raise GridGeometryError(report['reason'], report) from cause
        report.update(metrics)
        # Old affine-grid pitch fields refer to the rejected affine, not H's local Jacobian.
        for key in ('grid_pitch_px_column_row', 'smallest_grid_singular_value_px',
                    'conservative_max_residual_in_bins'):
            report.pop(key, None)
        report.update(status='passed', acceptance='validated_projective_polygons',
            geometry_model='projective', bin_representation='projective_quadrilaterals',
            raster_geometry='not_used_for_fullres_registration', projective_domain=domain,
            reason='Projective model verified over every supplied center; bin geometry uses transformed corners.',
            original_coordinates_preserved=True, image_registration_verified=False,
            interpretation='Fits the supplied position table, not an independent validation of image registration.',
            footprint_note='Unit array-bin corners are transformed with the full homogeneous divide. These are model-derived footprints, not independently measured physical boundaries.')
        report['projective_diagnostic'] = {**candidate, 'status': 'validated_for_polygon_geometry',
            'interpretation': 'Validated against all supplied centers and the complete grid domain; not a SpatialData Affine.'}
        return h, report


def geometry_contract(matrix):
    h = homography(matrix)
    projective = np.any(h[2, :2] != 0)
    return {'grid_geometry_model': 'projective' if projective else 'affine',
            'bin_representation': 'projective_quadrilaterals' if projective else 'affine_raster',
            'grid_model_implementation': PROJECTIVE_GRID_PATCH}
