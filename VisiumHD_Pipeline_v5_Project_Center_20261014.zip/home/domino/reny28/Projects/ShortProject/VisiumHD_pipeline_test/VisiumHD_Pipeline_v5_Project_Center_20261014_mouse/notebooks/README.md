# VHD v5: post-transfer observed-metadata review and StarDist status

## Quick diagnostic in your current Center notebook
Put `vhd_posttransfer_review.py` beside that notebook, then run:

```python
import vhd_posttransfer_review as pr
star_report = pr.diagnose_stardist(pc, sample="Project__BM0164135A_s1_A1")
```

This prints the stored StarDist job error, worker status, and bounded log tail. It does not
start another StarDist attempt. The saved ZIP includes the installed segmentation/launch/report
source for diagnosis, but not scientific arrays. If a log is absent, the code reports absence;
it does not call the absence proof of a specific failure.

## Review the completed transfer
Open `VHD_PostTransfer_Obs_Review_and_StarDist_Status.ipynb` in the existing spatial Python
environment. Check package/sample paths, confirm quiescent access, then run the review cells.
No additional R/GPU/DESeq2/segmentation work is performed. Required on-server packages are those
already used by the pipeline: numpy, pandas, matplotlib, anndata, zarr, and its H&E reader
(OpenSlide/tifffile as appropriate). PyArrow is needed only for optional sidecar parity checking.

The metadata is read directly from `tables/bins_2um/obs`, not from X and not from a source-preview
image. Select fields in `FIELDS_TO_PLOT`; use `ROIS` for original-H&E pixel rectangles.
Default whole-view display samples 300,000 bin centers; numerical summaries include all bins.
Missing/nonfinite values remain missing and the display subset is documented. No interpolation,
signal extraction, annotation propagation, QC change, or automatic approval occurs.

Reading 11 million observation rows is much less work than signal remeasurement but is not
instantaneous or zero-memory. Allow several GB for the metadata and index. The optional all-row
sidecar parity check reads the selected parquet columns once in chunks and uses exact bin IDs.

Output defaults to `vhd_posttransfer_reviews/` in the notebook directory, with a unique new
review folder and a settings-specific plots/index.html. Keep the gallery together with the PNGs.
The existing Center HTML does not automatically register this additional review.

## Important safety/interpretation notes
- Never run this master review while a reader/writer of the sample master is active. Explicit
  confirmation supplements controller/lock checks; other hosts cannot be certified here.
- No helper patches or managed configuration changes are applied.
- Do not rerun completed transfer just because a StarDist attempt failed.
- A prior-review checkbox is not a substitute for executing StarDist.
- This package does not fix a currently unknown StarDist exception; it exposes the actual record.
- Empty transfer_spec in the supplied receipt means no selected asset summaries were requested
  for cell-level aggregation. This notebook does not silently enable them.
- The source audit separates verified code behavior from possible performance bottlenecks.

See VALIDATION.md for executed tests and untested real-backend limitations.
