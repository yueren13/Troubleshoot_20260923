"""Quantitative fixed-reference H&E; display normalization is kept separate."""
from .fixed import extract_he_concentrations_reference, fixed_scale_he_tissue_score, combine_he_fixed_tissue_signal, sample_field
