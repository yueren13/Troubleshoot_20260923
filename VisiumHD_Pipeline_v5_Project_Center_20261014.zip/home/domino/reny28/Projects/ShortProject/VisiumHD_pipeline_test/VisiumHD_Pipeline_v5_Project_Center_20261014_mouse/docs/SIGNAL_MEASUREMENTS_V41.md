# Single-channel signal measurement and scale review — v4.1

## One native image, selected scalar measurements in obs

Register a single-channel TIFF/NPY/Zarr image as `kind=signal`. The master retains
its native pixel values and resolution in `.images`. Only after review, chosen
summaries appear in `tables['bins_2um'].obs`, for example:

```text
stain__mean  stain__median  stain__sum  stain__min  stain__max
stain__valid_fraction  stain__in_bounds_fraction
stain__n_valid_pixels  stain__valid
```

The scalar source is not inserted into an RNA expression layer. X and its gene
axis stay unchanged. Multiple-channel organization is deferred: a channel can be
selected explicitly, but this version does not design a new multimodal matrix.

Example source row (source pixel values 0/255):

```csv
sample_id,asset_id,kind,path,format,registration_mode,scale_hint,pixel_convention,axes,signal_type,positive_value,negative_value
Sample02,stain,signal,/approved/project/signal.tif,tiff,auto_extent,9,edges,yx,binary,255,0
```

For a 0/1 mask use positive=1, negative=0. For actual numeric intensity data use
`signal_type=continuous` rather than silently thresholding or converting it. All
native binary pixels are checked on import; invalid codes stop. NoData is optional
and must differ from both binary codes. Stored native pixels are not recoded;
only the measurement adapter maps the declared binary codes to 0/1. NaNs and
out-of-image regions are not assessed zeros.

## 1/9 resolution: enter 9 as a guide, then inspect the estimate

With `registration_mode=auto_extent`, the code reads the actual single-channel
array dimensions and the **named original H&E image** dimensions. It proposes
separate X/Y scale ratios:

```text
scale_x = reference_width / signal_width
scale_y = reference_height / signal_height
```

The `scale_hint=9` is a check, not a forced rescaling. Integer rounding can yield
values such as 9.005 and 8.99, which are retained and reported. A hint mismatch or
strong axis-ratio mismatch is shown during discovery and blocks active transfer
until corrected; default relative tolerance is 0.05, configurable explicitly.

The named H&E is NOT the extent of all objects/polygons combined. If that H&E is
itself registered to Space Ranger, the proposed signal-to-H&E transform is composed
with the inverse H&E registration to obtain source-to-fullres coordinates.

**Dimension matching cannot prove co-registration.** It assumes the same full
physical field of view, orientation and absence of an unaccounted crop. A binary
positivity pattern is not necessarily an anatomical image that can be safely
matched to H&E. No content-based optimization, crop detection or automatic
rotation/reflection inference is claimed. Review the overlay and set
`same_extent_confirmed=true` only for genuinely shared extents. The actual
cross-source calibration and its evidence are saved in the report.

### Choose the coordinate convention; it is not inferred from dimensions

Array-index coordinates refer to pixel centers at integers.

| pixel_convention | Scale | Offset |
|---|---|---|
| `edges` (starter) | W_ref/W_src, H_ref/H_src | (scale_x-1)/2, (scale_y-1)/2 |
| `origin_centers` | W_ref/W_src, H_ref/H_src | 0,0 |
| `endpoint_centers` | (W_ref-1)/(W_src-1), likewise Y | 0,0 |

For exact 9x downsampling, `edges` maps the first coarse pixel center to the center
of a nine-pixel source block, with offset 4. `origin_centers` instead maps centers
0 to 0. Neither is a universal fact about your TIFF. Match the registration/export
convention or provide a measured affine. An apparently small offset can matter
at the 2-micrometer bin scale.

### Crops, rotations, offsets, or other registration

`registration_mode=explicit` uses `source_to_fullres=a;b;c;d;e;f`, meaning:
`x'=a*x+b*y+c`, `y'=d*x+e*y+f`. This maps source pixel centers directly to
Space Ranger full-resolution x/y and is not Shapely's coefficient ordering.

`registration_mode=landmarks` fits an affine to a supplied CSV:

```csv
source_x,source_y,reference_x,reference_y
0,0,4,4
10,0,94,4
0,10,4,94
10,10,94,94
```

Coordinates labeled reference refer to the named original H&E. At least three
finite non-collinear pairs are required. Residuals are recorded and an excessive
fit residual stops use (default max 2 reference pixels). Three exact fitting
points do not independently validate registration; inspect additional landmarks
and overlays. Nonrigid registration is outside this implementation.

## Choose statistics after seeing the signal

Discovery generates one `__signal__` choice row. This is a technical item label,
not a category you need to invent. Set `include_in_obs=true`, edit `obs_name`, and
choose `signal_methods=mean;median;sum;min;max` (or just the needed methods).
For auto-extent mode also confirm shared extent after review, then approve in 02A.
Signal intensity is not automatically converted into a pathology/QC exclusion;
explicit image-threshold-to-prior design remains separate.

## What the footprint statistics mean

The actual bin footprint is defined by the prepared grid affine, transformed into
the signal's native pixel frame. Pixels are piecewise constant unit squares. The
calculation uses exact positive overlap areas w_i in source-pixel-squared units;
rotated affine footprints are handled by polygon intersection. Only finite,
assessed pixel values v_i contribute:

| Statistic | Definition |
|---|---|
| mean | sum(w_i * v_i) / sum(valid w_i) |
| median | Weighted median using overlap weights; a half-weight tie averages its two boundary values. |
| sum | sum(w_i * v_i): fractional-source-pixel sum. |
| max / min | Largest / smallest valid value with strictly positive footprint overlap. |

The sum conserves a source-pixel sum when disjoint bins partition that pixel. It
is NOT an ordinary sum of upsampled replicas, an independent molecule count, or a
physical-area integral. Physical integration would require multiplying by a
validated source-pixel physical area and interpreting the units accordingly.

Example: a 2x2 native block [1,3;5,7] wholly covered by one bin yields mean=4,
median=4, sum=16, min=1 and max=7. A single native pixel of value 8 divided into
four equal bins yields mean=8 in each bin, but fractional sum=2 in each, totaling
8. It does not fabricate 32 units of integrated signal.

For a binary image, the mean is the positive fraction of the valid covered area
under this piecewise-constant pixel model. It differs from the earlier v4 mean
of nearest-center binary samples. Explicit `center_nearest` and `center_linear`
remain available for continuous legacy-compatible readouts; binary linear
interpolation is rejected. Output names/provenance distinguish the methods.

A coarse image may give the same value to several bins; those values are not
independent measurements and do not acquire 2-micrometer imaging resolution.

## Coverage and memory

The denominator for valid_fraction is the complete transformed bin footprint.
`in_bounds_fraction` includes the native image footprint and any explicitly
specified coverage polygon; valid_fraction additionally excludes NoData/NaNs.
`n_valid_pixels` counts contributing native pixels, not independent observations.
No valid overlap means NaN for every statistic, including sum. Optional
`min_valid_fraction` enforces a reviewed coverage threshold before a bin's result
is considered usable.

Reads use bounded native-image tiles and bounded candidate-intersection batches;
the source is not expanded to full resolution. Limits on candidate pixels per bin
stop implausible scale/memory requests. PNG or compressed TIFF access may depend
on the existing raster backend and installed packages. This is not a claim that
every upstream data structure or expression operation is out of core.

## Cell summaries are a second operation

`cell_methods` chooses mean/median/sum/min/max over the resulting bin metadata,
with valid-bin counts and coverage. These are summaries of bin measurements:
mean of bin means need not equal a coverage-weighted pixel mean; median of bin
medians need not equal the underlying pixel median. Name and interpret each
operation explicitly. Summing conserved bin sums can be meaningful over selected
nonoverlapping bin footprints, but does not repair missing coverage or make the
whole-cell polygon identical to their union.

Real cell polygons are required for the current bin-to-cell assignment. The new
image-to-bin writer updates obs and provenance only; count-preservation across a
real SpatialData store is supplied as an optional scientific test, not a test
executed in the delivery environment.
