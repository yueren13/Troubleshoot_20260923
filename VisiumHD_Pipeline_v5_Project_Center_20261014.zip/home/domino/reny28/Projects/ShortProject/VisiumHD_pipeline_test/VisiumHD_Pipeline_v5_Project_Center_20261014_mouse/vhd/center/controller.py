"""One persistent project interface; scientific work delegates to the uploaded engine.

Opening/refreshing reads small config and registered report files only. Explicit
Run/Save buttons invoke writes. Managed CSVs are compatibility exports, never a
second set of user approval forms. Original imported configuration is read-only.
"""
from __future__ import annotations
from pathlib import Path
from copy import deepcopy
from contextlib import contextmanager
import csv, io, json, os, re, runpy, traceback, uuid
from .state import StateStore, atomic_write, file_fingerprint, fingerprint, now, stamp
from .importers import clone_project, csv_text, read_csv
from .stages import route, observed, output_paths, LABELS, REVIEW_STAGES


class ProjectCenter:
    def __init__(self, workspace):
        self.workspace=Path(workspace).expanduser().absolute();self.store=StateStore(self.workspace)
        self._stop_requested=False

    @classmethod
    def import_config(cls, manifest, settings, workspace, *, title='Visium HD Project Center'):
        from ..control.manifest import load_project,check_policy
        w=Path(workspace).expanduser().absolute()
        if w.exists() and any(w.iterdir()):raise FileExistsError('Use a new empty workspace, or ProjectCenter.open() for an existing one.')
        project=load_project(manifest,settings);check_policy(project)
        # No state inside original source/store/config roots; no username/mount guessing.
        cls._check_workspace(w,project)
        managed,sources=clone_project(project,w)
        center=cls(w)
        data={'title':title,'release':'0.5.0rc1','project':managed,'input_sources':sources,
              'endpoints':{r['sample_key']:('bins' if r['goal']=='bin_QCed' else 'cells') for r in managed['rows']},
              'jobs':{},'reviews':{},'drafts':{},'resume':{},'inventory':{},'artifacts':{},'resources':{},
              'resource_limits':{},'analysis_settings':{'analysis_id':'analysis01','n_hvg':3000,'n_pcs':30,'target_sum':10000,'seed':42},
              'managed_hashes':center._managed_hashes(),'history':[]}
        center.store.initialize(data);center.refresh()
        return center

    @classmethod
    def from_sheets(cls,samples,assets,output_root,workspace,*,profile=None,run_id='run01',namespace='Project',title='Visium HD Project Center',metadata_table=None,metadata_id_column='sample_id'):
        from .importers import project_from_sheets
        w=Path(workspace).expanduser().absolute()
        if w.exists() and any(w.iterdir()):raise FileExistsError('Use a new empty workspace.')
        project=project_from_sheets(samples,assets,output_root,profile=profile,run_id=run_id,namespace=namespace,metadata_table=metadata_table,metadata_id_column=metadata_id_column)
        from ..control.manifest import check_policy
        check_policy(project);cls._check_workspace(w,project)
        # Supply defaults as an import snapshot without requiring user JSON entry.
        if not profile:
            temporary=w/'inputs'/'initial_profile.json';atomic_write(temporary,json.dumps(project['settings'],indent=2))
            project['settings_path']=str(temporary)
        managed,sources=clone_project(project,w);center=cls(w)
        center.store.initialize({'title':title,'release':'0.5.0rc1','project':managed,'input_sources':sources,
             'endpoints':{r['sample_key']:('bins' if r['goal']=='bin_QCed' else 'cells') for r in managed['rows']},
             'jobs':{},'reviews':{},'drafts':{},'resume':{},'inventory':{},'artifacts':{},'resources':{},'resource_limits':{},
             'analysis_settings':{'analysis_id':'analysis01','n_hvg':3000,'n_pcs':30,'target_sum':10000,'seed':42},
             'managed_hashes':center._managed_hashes(),'history':[]})
        center.refresh();return center

    @classmethod
    def open(cls,workspace):
        obj=cls(workspace);obj.snapshot();return obj

    @staticmethod
    def _check_workspace(workspace,project):
        from ..control.manifest import sample_layout
        for row in project['rows']:
            paths=[row.get(k) for k in ('spaceranger_outs','segmentation_image','bin_input','cell_input')]
            paths.append(str(sample_layout(project,row)['store']))
            for path in filter(None,paths):
                if str(path).startswith('s3://'):continue
                src=Path(path).resolve();w=workspace.resolve()
                if w==src or src in w.parents or w in src.parents:raise ValueError('Controller workspace overlaps a biological source or master.')
        for path in (project['manifest_path'],project.get('settings_path')):
            if path and workspace.resolve()==Path(path).resolve().parent:raise ValueError('Use a separate workspace, not the input config folder.')

    def _managed_hashes(self):
        return {str(p.relative_to(self.workspace)):file_fingerprint(p)
                for p in sorted((self.workspace/'engine').rglob('*')) if p.is_file() and p.suffix in ('.json','.csv')}

    def snapshot(self):
        d=self.store.read()
        if self._managed_hashes()!=d['managed_hashes']:
            raise RuntimeError('Managed configuration changed outside the Project Center or a save was interrupted. '
                               'Do not copy old CSVs over it. Open the saved revisions/inputs for recovery; no jobs will run.')
        return d

    @property
    def project(self):return self.snapshot()['project']

    def key(self,sample,project=None):
        from ..control.manifest import resolve_sample_keys
        return resolve_sample_keys(project or self.project,[sample])[0]

    def row(self,sample,project=None):
        p=project or self.project;k=self.key(sample,p)
        return next(r for r in p['rows'] if r['sample_key']==k)

    def _write_project_exports(self,d):
        from ..control.manifest import COLUMNS,OPTIONAL_COLUMNS
        p=d['project']
        atomic_write(p['manifest_path'],csv_text(COLUMNS+OPTIONAL_COLUMNS,p['rows']))
        atomic_write(p['settings_path'],json.dumps(p['settings'],indent=2,default=str))

    def _commit(self,d,event,*,export=False):
        if export:self._write_project_exports(d)
        d['managed_hashes']=self._managed_hashes()
        from .reports import list_reports,write_center_reports
        for row in d['project']['rows']:d['artifacts'][row['sample_key']]=list_reports(d['project'],row)
        saved=self.store.save_locked(d,d['revision'],event)
        try:write_center_reports(saved,self.workspace,refresh_samples=[])
        except Exception as exc:
            # Do not claim the scientific action failed solely because report rendering did.
            atomic_write(self.workspace/'report_render_error.txt',type(exc).__name__+': '+str(exc))
        return saved

    def refresh(self):
        with self.store.exclusive():
            d=self.snapshot()
            for row in d['project']['rows']:
                key=row['sample_key'];d['inventory'][key]={}
                for action in route(row,d['endpoints'][key]):
                    if action not in REVIEW_STAGES:d['inventory'][key][action]=observed(d['project'],row,action)
            return self._commit(d,'Refreshed known report/product locations; no scientific arrays read.')

    def hardware(self):
        from .resources import detect_resources
        result=detect_resources()
        with self.store.exclusive():
            d=self.snapshot();d['resources']=result;self._commit(d,'Refreshed available hardware snapshot.')
        return result

    def set_resource_limits(self,limits):
        allowed={'max_workers','threads_per_job','reserve_cpus','reserve_ram_gib','gpu_ids'}
        if set(limits)-allowed:raise ValueError('Unknown resource limit.')
        from .resources import runtime_project
        runtime_project(self.project,limits)
        with self.store.exclusive():
            d=self.snapshot();d['resource_limits']=deepcopy(limits);self._commit(d,'Saved optional resource caps.')

    def save_startup_settings(self,values,*,confirmed=False):
        """Save runtime-only startup settings; scientific contracts are unchanged."""
        if not confirmed:raise PermissionError('Confirm saving startup settings; no jobs are launched.')
        from ..compute.startup_support import validate_startup_settings,validate_cache_root
        with self.store.exclusive():
            d=self.snapshot()
            running=[(k,a) for section in ('jobs','group_jobs') for k,jobs in d.get(section,{}).items()
                     for a,j in jobs.items() if j.get('status')=='running']
            if running:raise RuntimeError('Wait for/inspect running jobs before changing startup settings: '+str(running))
            merged=deepcopy(d.get('startup_settings',{}));merged.update(values)
            cleaned=validate_startup_settings(merged)
            validate_cache_root(d['project'],cleaned['shared_cache_root'])
            d['startup_settings']=cleaned
            self._commit(d,'Saved startup deadlines/cache; no scientific settings or results changed.')
            return cleaned

    def set_endpoint(self,sample,endpoint):
        with self.store.exclusive():
            d=self.snapshot();r=self.row(sample,d['project']);route(r,endpoint)
            d['endpoints'][r['sample_key']]=endpoint
            d['resume'].pop(r['sample_key'],None)
            self._commit(d,f"Selected endpoint {endpoint} for {r['sample_key']}.")

    def select_resume(self,sample,start_action,*,acknowledge_existing=False):
        """Skip earlier route positions only after inventory; backend still validates its dependencies.

        This does not create a completion or approval for skipped actions.
        """
        with self.store.exclusive():
            d=self.snapshot();row=self.row(sample,d['project']);steps=route(row,d['endpoints'][row['sample_key']])
            if start_action=='auto':d['resume'].pop(row['sample_key'],None)
            else:
                if start_action not in steps:raise ValueError('Resume point is not on this sample route.')
                if not acknowledge_existing:raise ValueError('Explicitly confirm reviewed existing prerequisites to choose a midway resume point.')
                missing=[]
                for action in steps[:steps.index(start_action)]:
                    if action in REVIEW_STAGES:continue
                    inventory=observed(d['project'],row,action);missing+=inventory['missing']
                if missing:raise FileNotFoundError('Earlier expected products are unavailable; resume was not changed:\n'+'\n'.join(missing))
                d['resume'][row['sample_key']]={'action':start_action,'at':now(),'note':'User-selected resume; earlier actions not newly certified.'}
            self._commit(d,'Updated resume selection.')

    def _contract(self,d,row,action):
        """Controller cache contract; the scientific engine retains its own signature checks."""
        from ..control.manifest import row_config,sample_layout
        if action=='assemble_bins':
            from ..bin_master import center_contract
            return center_contract(d['project'],row)
        cfg,_=row_config(d['project'],row);p=sample_layout(d['project'],row)
        blocks={'ingest_raw':['coordinates'],'import_bins':['coordinates'],'measure_he':['he_score'],
          'bin_qc':['bin_qc'],'reuse_bin_qc':['bin_qc'],'stardist':['stardist','prior_filter'],
          'proseg':['proseg'],'postprocess_cells':['cells','metadata_transfer','cell_cycle'],
          'import_cells':['cells'],'assemble':['storage'],'cluster_individual':['analysis_qc','clustering']}
        inputs={k:stamp(row[k]) for k in ('segmentation_image','bin_input','cell_input','cell_boundaries') if row.get(k)}
        # Raw Space Ranger source paths have explicit per-file checks in the importer.
        if row.get('spaceranger_outs'):
            b=Path(row['spaceranger_outs'])/'binned_outputs/square_002um'
            for f in ('spatial/tissue_positions.parquet','spatial/scalefactors_json.json','raw_feature_bc_matrix.h5'):
                inputs['sr_'+f]=stamp(b/f)
        deps={'measure_he':['geometry.json','bins_raw.h5ad'],'bin_qc':['bins_raw.h5ad','bins_he.parquet'],
              'stardist':['geometry.json','bins_qc_obs.parquet','bins_annotated_obs.parquet'],
              'proseg':['prior_qc.npy','prior_metadata.json','bins_qc_obs.parquet','bins_annotated_obs.parquet'],
              'postprocess_cells':['04_proseg_complete.json','bins_qc_obs.parquet','bins_annotated_obs.parquet'],
              'assemble':['bins_raw.h5ad','bins_qc_obs.parquet','bins_annotated_obs.parquet','cells_qc.h5ad']}
        inputs.update({f:stamp(p['work']/f) for f in deps.get(action,[])})
        extra={}
        if action in ('transfer_assets','refresh_cell_annotations','review_assets','stardist','proseg'):
            for f in ('assets.csv','asset_choices.csv'):extra[f]=file_fingerprint(self.workspace/'engine'/f)
        return fingerprint({'action':action,'input':inputs,'settings':{k:cfg[k] for k in blocks.get(action,[])},
                            'extra':extra,'stage':row['stage'],'analysis':d.get('analysis_settings') if action=='cluster_individual' else None})

    def _done(self,d,row,action):
        job=d['jobs'].get(row['sample_key'],{}).get(action,{})
        if job.get('status')!='complete':return False
        if job.get('contract')!=self._contract(d,row,action):return False
        if action=='assemble_bins':
            from ..bin_master import center_done
            if not center_done(d['project'],row):return False
        return all(stamp(x['path'])==x for x in job.get('output_stamps',[])) and bool(job.get('output_stamps'))

    def _review_ready(self,d,row,gate):
        from ..control.manifest import as_bool,row_config,sample_layout
        key=row['sample_key'];p=sample_layout(d['project'],row);review=d['reviews'].get(key,{}).get(gate,{})
        if gate=='review_assets':
            try:
                from ..annotations.discovery import preview_selected_plan
                plans=preview_selected_plan(d['project'],[key])
                if not plans:return True,'No configured active asset choices.'
                plan=plans[0]
                if plan['active_outputs']==0 and not review:
                    return False,'Sources are present. Review their gallery and explicitly save no selected outputs, or select measurements.'
                if plan['choice_approvals_complete']:
                    return True,'Current choices are approved or no measurements are selected; actual source checks remain at transfer.'
                return False,'Review overlays and save usage in the Annotations panel.'
            except Exception as exc:return False,str(exc)
        if gate=='review_bins':
            cfg,_=row_config(d['project'],row)
            # Imported flags remain recognizable but only with extant classification evidence.
            needed=p['report']/'bins_qc_class.png'
            if not needed.exists():needed=p['report']/'bins_qc_class_on_HE.png'
            if as_bool(row['coordinates_reviewed']) and (row['stage'] not in ('raw','bin_imported') or as_bool(row['fresh_qc_reviewed'])) and needed.is_file():
                if review and any(stamp(x['path'])!=x for x in review.get('evidence',[])):return False,'QC evidence changed since center approval.'
                return True,'Coordinate/QC acknowledgement is set; evidence exists (not an automatic biological assessment).'
            return False,'Inspect bin/H&E overlay and save coordinate and QC review.'
        if not review:return False,'Inspect the corresponding reports and save this review.'
        if any(stamp(x['path'])!=x for x in review.get('evidence',[])):return False,'Review evidence changed.'
        return True,'Review saved.'

    def plan(self,samples=None):
        from ..control.manifest import resolve_sample_keys,row_config
        d=self.snapshot();project=d['project'];keys=resolve_sample_keys(project,samples);out=[]
        for key in keys:
            row=self.row(key,project);steps=route(row,d['endpoints'][key]);start=d['resume'].get(key,{}).get('action')
            blocked=False
            for i,action in enumerate(steps):
                if start and i<steps.index(start):status='resume_skipped_not_certified';reason='Before explicitly selected resume point.'
                elif action in REVIEW_STAGES:
                    ready,reason=self._review_ready(d,row,action);status='review_saved' if ready else 'needs_review'
                    if not ready:blocked=True
                elif self._done(d,row,action):status='complete';reason='Center contract and output stamps unchanged.'
                else:
                    status='waiting' if blocked else 'ready';reason='Scientific engine rechecks reuse/input signatures on execution.'
                    if action=='bin_qc':
                        q=row_config(project,row)[0]['bin_qc']
                        if q.get('tissue_score_threshold') is None or q.get('transcript_threshold') is None:
                            status='needs_settings';reason='Select tissue-score and transcript cutoffs in the Bin QC panel.'
                    previous=d['jobs'].get(key,{}).get(action,{})
                    if status=='ready' and previous.get('status')=='failed':
                        detail=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',str(previous.get('error','')))
                        reason='Ready to retry; previous execution FAILED. '+detail[-1200:]
                    # Only the first unresolved computational step can run next.
                    blocked=True
                out.append({'sample':key,'action':action,'label':LABELS[action],'status':status,'reason':reason})
        return out

    def save_bin_settings(self,sample,*,tissue_score,transcripts,expected_revision=None):
        import math
        if isinstance(tissue_score,bool) or not math.isfinite(float(tissue_score)) or not 0<=float(tissue_score)<=1:raise ValueError('Tissue threshold must be in [0,1].')
        if isinstance(transcripts,bool) or not math.isfinite(float(transcripts)) or float(transcripts)<0:raise ValueError('Transcript threshold must be nonnegative, in configured metric units.')
        with self.store.exclusive():
            d=self.snapshot()
            if expected_revision is not None and d['revision']!=expected_revision:raise RuntimeError('Refresh stale form before saving.')
            r=self.row(sample,d['project']);key=r['sample_key'];from ..control.manifest import row_config
            old=row_config(d['project'],r)[0]['bin_qc']
            if old.get('tissue_score_threshold')==float(tissue_score) and old.get('transcript_threshold')==float(transcripts):return d
            # Never automatically overwrite existing derived QC or dependent segmentation.
            from ..control.manifest import sample_layout
            marker=sample_layout(d['project'],r)['work']/'02_qc_complete.json'
            if marker.exists():raise RuntimeError('A completed QC revision exists. This release does not automatically replace its dependent products. '
                'Use a separate run/workspace for different cutoffs; the present review can accept the existing settings without rewriting them.')
            path=self.workspace/'engine/overrides'/(key+'.json');extra=json.loads(Path(r['overrides_json']).read_text()) if r.get('overrides_json') else {}
            extra.setdefault('bin_qc',{}).update(tissue_score_threshold=float(tissue_score),transcript_threshold=float(transcripts))
            atomic_write(path,json.dumps(extra,indent=2));r['overrides_json']=str(path)
            r['fresh_qc_reviewed']='false';d['reviews'].setdefault(key,{}).pop('review_bins',None)
            return self._commit(d,'Saved bin QC cutoff values (classification not run).',export=True)

    def accept_review(self,sample,gate,*,reviewer,confirmed=False):
        if gate not in REVIEW_STAGES-{'review_assets'}:raise ValueError('Use the Annotations save control for assets.')
        if not confirmed or not str(reviewer).strip():raise ValueError('Explicit confirmation and reviewer name are required.')
        from ..control.manifest import sample_layout
        with self.store.exclusive():
            d=self.snapshot();r=self.row(sample,d['project']);key=r['sample_key'];p=sample_layout(d['project'],r)
            names={'review_bins':['bins_qc_class.png','bins_qc_class_on_HE.png'],
              'review_prior':['stardist_prior_ROI.png'],'review_cells':['cells_qc_pass_on_HE.png','cells_qc_on_HE.png','cells_boundaries_whole.png'],
              'review_clustering':['individual_analysis/current.json']}[gate]
            evidence=[stamp(p['report']/x) for x in names if (p['report']/x).is_file()]
            if not evidence:raise FileNotFoundError('The required report has not been generated. A candidate path alone is not review evidence.')
            d['reviews'].setdefault(key,{})[gate]={'reviewer':str(reviewer).strip(),'at':now(),'evidence':evidence,'decision':'accepted'}
            if gate=='review_bins':r['coordinates_reviewed']='true';r['fresh_qc_reviewed']='true'
            return self._commit(d,f'Saved {gate} review for {key}; no processing launched.',export=True)

    def acknowledge_writer(self,*,confirmed=False):
        if not confirmed:raise ValueError('Confirm intended masters and no concurrent access to those stores.')
        with self.store.exclusive():
            d=self.snapshot();d['project']['settings']['storage']['single_writer_ack']=True
            # Clear contrary per-sample storage override only after explicit project-wide consent.
            for r in d['project']['rows']:
                if r.get('overrides_json'):
                    path=Path(r['overrides_json']);extra=json.loads(path.read_text())
                    if 'single_writer_ack' in extra.get('storage',{}):
                        extra['storage']['single_writer_ack']=True;atomic_write(path,json.dumps(extra,indent=2))
            return self._commit(d,'Confirmed intended stores and exclusive writing; external processes are not automatically detected.',export=True)

    def choices(self,sample):
        from ..annotations.discovery import read_choices
        key=self.key(sample)
        return [r for r in read_choices(self.workspace/'engine/asset_choices.csv') if r['sample_key']==key]

    def galleries(self,sample):
        from ..annotations.visual_approval import list_visual_reviews
        return list_visual_reviews(self.project,[self.key(sample)])

    def discover(self,sample):
        from ..annotations.discovery import discover_assets
        with self.store.exclusive():
            d=self.snapshot();key=self.key(sample,d['project'])
            try:result=discover_assets(d['project'],[key],execute=True)
            finally:self._commit(d,'Refreshed category inventory; selections preserved, no automatic approval.')
            return result

    def generate_asset_gallery(self,sample,*,alpha=.85):
        with self.store.exclusive():
            d=self.snapshot();key=self.key(sample,d['project'])
            viewer=runpy.run_path(str(Path(__file__).resolve().parents[2]/'tools/preview_assets_on_he.py'))
            result=viewer['preview_assets_on_he'](d['project'],[key],signal_alpha=alpha,signal_zero_transparent=True,show=False)
            self._commit(d,'Generated visual-first asset gallery; no master write or approval.');return result

    def save_asset_review(self,sample,*,gallery_summary,edits,extent_confirmations,signal_interpretations=None,
                          scale_hints=None,reviewer='',confirmed=False,expected_revision=None):
        """One UI operation: refresh changed discovery, restore form choices/extent, validate, approve.

        Original input CSVs are never edited. A failure restores managed CSV values;
        a draft remains in the state for correction. No receipt is forged.
        """
        from ..annotations.discovery import discover_assets,read_choices,atomic_choices
        from ..annotations.visual_approval import approve_visual_choices
        if any(not isinstance(v,bool) for v in extent_confirmations.values()):raise TypeError('Extent confirmations must be Boolean values, not text.')
        if not confirmed or not reviewer.strip():raise ValueError('Review the displayed gallery and enter a reviewer before saving.')
        allowed={'include_in_obs','qc_use','obs_name','signal_methods','cell_methods','coverage_mode','notes'}
        with self.store.exclusive():
            d=self.snapshot();key=self.key(sample,d['project'])
            if expected_revision is not None and d['revision']!=expected_revision:raise RuntimeError('Stale review form; refresh before saving.')
            before={p:p.read_bytes() for p in (self.workspace/'engine').rglob('*') if p.is_file() and p.suffix in ('.csv','.json')}
            draft={'gallery':str(gallery_summary),'edits':edits,'extent_confirmations':extent_confirmations,
                   'signal_interpretations':signal_interpretations or {},'scale_hints':scale_hints or {}}
            d['drafts'][key]=deepcopy(draft)
            try:
                assetfile=self.workspace/'engine/assets.csv';fields,rows=read_csv(assetfile)
                r=self.row(key,d['project'])
                for a in rows:
                    if a['dataset_id']!=r['dataset_id'] or a['sample_id']!=r['sample_id']:continue
                    if a['asset_id'] in (scale_hints or {}):
                        value=scale_hints[a['asset_id']]
                        if value is not None and float(value)<=0:raise ValueError('Scale hint must be positive.')
                        a['scale_hint']='' if value is None else str(value)
                new=csv_text(fields,rows).encode()
                if new!=assetfile.read_bytes():atomic_write(assetfile,new)
                discover_assets(d['project'],[key],execute=True)
                choices=read_choices(self.workspace/'engine/asset_choices.csv');found=set();selected=set()
                from ..control.manifest import as_bool
                for c in choices:
                    if c['sample_key']!=key:continue
                    identity=c['asset_id']+'/'+c['item_key']
                    if identity in edits:
                        change=edits[identity]
                        if set(change)-allowed:raise ValueError('Unsupported or protected choice field.')
                        for field,value in change.items():c[field]=str(value).lower() if isinstance(value,bool) else str(value)
                        found.add(identity)
                    if c['asset_id'] in extent_confirmations:c['same_extent_confirmed']=str(bool(extent_confirmations[c['asset_id']])).lower()
                    if as_bool(c['include_in_obs']):selected.add(c['asset_id'])
                if set(edits)!=found:raise ValueError('A category identity changed; review the refreshed discovery.')
                atomic_choices(self.workspace/'engine/asset_choices.csv',choices)
                if selected:
                    kwargs=dict(review_reports={key:str(gallery_summary)},signal_interpretations={key:signal_interpretations or {}})
                    plan=approve_visual_choices(d['project'],{key:sorted(selected)},execute=False,**kwargs)
                    if plan['status']=='blocked':raise ValueError('\n'.join(plan['errors']))
                    result=approve_visual_choices(d['project'],{key:sorted(selected)},execute=True,reviewer=reviewer,confirm_plan=plan['plan_id'],**kwargs)
                else:result={'status':'no_selected_outputs','master_opened_or_written':False}
                d['reviews'].setdefault(key,{})['review_assets']={'at':now(),'reviewer':reviewer,'decision':result['status'],'gallery':str(gallery_summary)}
                d['drafts'].pop(key,None);self._commit(d,'Saved reviewed category/signal usage; transfer has NOT run.')
                return result
            except Exception as exc:
                for p,b in before.items():
                    if p.read_bytes()!=b:atomic_write(p,b)
                d['drafts'][key]['last_error']=type(exc).__name__+': '+str(exc)
                self._commit(d,'Asset review was NOT approved. Draft preserved; managed configuration restored.')
                raise

    def generate_geometry_review(self,sample,asset_id):
        from ..annotations.reviewed_geometry import prepare_geometry_review
        with self.store.exclusive():
            d=self.snapshot();result=prepare_geometry_review(d['project'],self.key(sample,d['project']),asset_id,execute=True)
            self._commit(d,'Generated unapproved annotation geometry review.');return result

    def accept_geometry(self,sample,asset_id,review_json,*,reviewer,confirm_all=False,remove_lines=False):
        from ..annotations.reviewed_geometry import reviewed_geometry_plan,accept_reviewed_geometry,activate_reviewed_geometry
        if not confirm_all:raise ValueError('Review all repaired pieces, holes and negative roles before accepting.')
        with self.store.exclusive():
            d=self.snapshot();key=self.key(sample,d['project'])
            plan=reviewed_geometry_plan(d['project'],key,asset_id,review_json)
            result=accept_reviewed_geometry(d['project'],key,asset_id,review_json,expected_plan_digest=plan['plan_digest'],
                    reviewer=reviewer,approve=True,allow_remove_lines=remove_lines,execute=True)
            # Activation key follows the reviewed-geometry helper contract, checked in tests.
            path=result.get('path')
            if not path:raise RuntimeError('Accepted report lacks a derived path; original source remains active.')
            activate_reviewed_geometry(d['project'],key,asset_id,path,execute=True)
            self._commit(d,'Accepted and activated reviewed derivative; H&E alignment remains a separate review.')
            return result

    def build_qc_distributions(self,sample):
        from ..he.qc_review import generate_bin_qc_review
        with self.store.exclusive():
            d=self.snapshot();result=generate_bin_qc_review(d['project'],sample_keys=[self.key(sample,d['project'])],execute=True)
            self._commit(d,'Generated bin-QC histograms/scatter/density without classification.');return result

    def stop_after_current(self):
        self._stop_requested=True

    def run_until_review(self,samples=None,*,confirmed=False,max_actions=30):
        """Blocking notebook operation; releases resources at review barriers.

        Can be interrupted through Jupyter. No background service is installed. A
        stopped kernel leaves running state for explicit inspection, not auto-complete.
        """
        if not confirmed:raise ValueError('Explicit Run confirmation is required.')
        from ..control.manifest import resolve_sample_keys,sample_layout,row_config
        from ..compute.launch import launch_samples
        from .resources import runtime_project
        selected=resolve_sample_keys(self.project,samples);self._stop_requested=False;events=[]
        if any(job.get('status')=='running' for k in selected for job in self.snapshot()['jobs'].get(k,{}).values()):
            raise RuntimeError('A previous controller job is still marked running. Inspect its worker/status before retrying; use the recovery acknowledgement, not deletion.')
        # One controller operation at a time. Scientific workers retain their own locks.
        with self.store.exclusive():
            for _ in range(max_actions):
                if self._stop_requested:break
                d=self.snapshot();project=d['project'];plans=self.plan(selected)
                ready=[p for p in plans if p['status']=='ready']
                if not ready:break
                action=ready[0]['action'];keys=[x['sample'] for x in ready if x['action']==action]
                running,inventory=runtime_project(project,d.get('resource_limits'))
                running['_center_startup_settings']=deepcopy(d.get('startup_settings',{}))
                d['resources']=inventory
                for key in keys:
                    row=self.row(key,project)
                    d['jobs'].setdefault(key,{})[action]={'status':'running','started_at':now(),'contract':self._contract(d,row,action)}
                    # Controller route can request an endpoint beyond legacy row goal, explicitly.
                    rr=self.row(key,running)
                    if action not in rr['_plan']:rr['_plan'].append(action)
                    if d['endpoints'][key] in ('qc_bins','bins'):rr['goal']='bin_QCed'
                d=self._commit(d,f'Started {action} for '+', '.join(keys))
                try:
                    if action=='cluster_individual':
                        from .single_sample import launch_individual
                        for key in keys:launch_individual(running,key,d['analysis_settings'],execute=True)
                    elif action=='publish':
                        from ..control.runner import publish_sample
                        for key in keys:publish_sample(running,self.row(key,running),execute=True)
                    else:launch_samples(running,action,execute=True,sample_keys=keys)
                    failed=[]
                except BaseException as exc:
                    failed=[type(exc).__name__+': '+str(exc)]
                    if isinstance(exc,(KeyboardInterrupt,SystemExit)):
                        d=self.snapshot()
                        for key in keys:d['jobs'][key][action].update(status='interrupted',error=failed[0],finished_at=now())
                        self._commit(d,'Operation interrupted; partial results retained for inspection.')
                        raise
                d=self.snapshot()
                for key in keys:
                    row=self.row(key,d['project']);obs=observed(d['project'],row,action)
                    j=d['jobs'][key][action]
                    worker_ok=obs['worker_record'].get('status')=='complete'
                    # No certification of a failed new invocation from an old worker status.
                    okay=not failed and obs['all_expected_present']
                    j.update(status='complete' if okay else 'failed',finished_at=now(),
                        output_stamps=[stamp(x) for x in obs['present']],error=failed[0] if failed else ('' if okay else 'Expected output missing after worker returned.'),
                        contract=self._contract(d,row,action))
                    event={'sample':key,'action':action,'status':j['status']}
                    if j['status']=='failed':
                        event['error']=j.get('error','')
                        print(f"FAILED {key} / {action}\n{event['error']}",flush=True)
                    events.append(event)
                self._commit(d,f'Finished {action}; reports refreshed.')
                if failed:break
        return events

    def view(self,sample=None,stage='bin_qc'):
        from IPython.display import HTML,display
        key=self.key(sample) if sample else None
        path=self.workspace/'html'/('samples/'+key+'/'+stage+'.html' if key else 'project_review.html')
        if not path.is_file():self.refresh()
        if not path.is_file():raise FileNotFoundError(path)
        # srcdoc in a sandbox avoids allowing scripts from an imported report to run in notebook context.
        import html
        content=path.read_text()
        if sample is None:
            content=re.sub(r'<a href="samples/[^"]+">(.*?)</a>',r'<span>\1 — open through the corresponding live tab</span>',content)
        text='<iframe sandbox="" style="width:100%;height:850px;border:0" srcdoc="'+html.escape(content,quote=True)+'"></iframe>'
        display(HTML(text));return path

    def export_report(self,destination):
        import zipfile
        target=Path(destination)
        if target.exists():raise FileExistsError(target)
        with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
            for f in (self.workspace/'html').rglob('*.html'):z.write(f,f.relative_to(self.workspace/'html'))
        return target

    def show(self):
        from .ui import show_center
        return show_center(self)

    def save_analysis_settings(self,settings):
        allowed={'analysis_id','n_hvg','n_pcs','target_sum','seed'}
        if set(settings)-allowed:raise ValueError('Unsupported analysis field.')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',str(settings.get('analysis_id',''))):raise ValueError('Safe nonempty analysis ID required.')
        for k in ('n_hvg','n_pcs'):
            if isinstance(settings.get(k),bool) or int(settings[k])!=float(settings[k]) or int(settings[k])<(3 if k=='n_hvg' else 2):raise ValueError('HVG count must be >=3 and PCA components >=2.')
        if not __import__('math').isfinite(float(settings['target_sum'])) or float(settings['target_sum'])<=0:raise ValueError('Normalization target must be positive.')
        with self.store.exclusive():
            d=self.snapshot();d['analysis_settings']=deepcopy(settings)
            self._commit(d,'Saved independent-analysis settings; no analysis launched.')

    def define_integration_group(self,name,samples,*,confirmed=False):
        from ..control.manifest import resolve_sample_keys
        if not confirmed:raise ValueError('Joint analysis must be explicitly requested.')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',name):raise ValueError('Use a safe integration group name.')
        with self.store.exclusive():
            d=self.snapshot();keys=resolve_sample_keys(d['project'],samples)
            if len(keys)<2:raise ValueError('Choose at least two compatible samples; independent PCA is separate.')
            species={self.row(k,d['project']).get('_sample_metadata',{}).get('species','') for k in keys}-{''}
            if len(species)>1:raise ValueError('Human/mouse joint integration is not supported without a separate ortholog workflow.')
            for key in keys:
                r=self.row(key,d['project'])
                if r['goal']=='bin_QCed':raise ValueError('An integration member needs a cell endpoint.')
                if r['integration_group'] not in ('',name):raise ValueError('A selected sample belongs to another group. Re-import a reviewed grouping instead of silently moving it.')
            for key in keys:self.row(key,d['project'])['integration_group']=name
            self._commit(d,'Explicitly selected joint-analysis group '+name,export=True)

    def integration_plan(self,group):
        from ..control.runner import integration_config
        d=self.snapshot();cfg=integration_config(d['project'],group)
        return {'group':group,'samples':[s['sample'] for s in cfg['samples']],
                'phases':['analysis_qc','prepare','train','cluster','diagnostics'],
                'analysis_qc':cfg.get('analysis_qc',{}),'scvi':cfg['scvi'],'clustering':cfg['clustering'],
                'work':cfg['_integration_work'],'execution':False}

    def run_integration(self,group,phase,*,confirmed=False):
        if not confirmed:raise ValueError('Explicit run confirmation required.')
        if phase not in ('analysis_qc','prepare','train','cluster','diagnostics','writeback'):raise ValueError('Unknown analysis phase.')
        from ..control.runner import integration_config
        from ..compute.launch import launch_integration
        from .resources import runtime_project
        from .reports import write_group_report
        with self.store.exclusive():
            d=self.snapshot();project,hardware=runtime_project(d['project'],d['resource_limits']);cfg=integration_config(project,group)
            for spec in cfg['samples']:
                row=self.row(spec['sample'],project);okay,why=self._review_ready(d,row,'review_cells')
                if not okay:raise RuntimeError(spec['sample']+': '+why)
            d.setdefault('group_jobs',{}).setdefault(group,{})[phase]={'status':'running','started_at':now()}
            d['resources']=hardware;d=self._commit(d,'Started integration '+group+' / '+phase)
            try:
                result=launch_integration(project,group,phase,execute=True)
                d=self.snapshot();d['group_jobs'][group][phase].update(status='complete',finished_at=now())
            except BaseException as exc:
                d=self.snapshot();d['group_jobs'][group][phase].update(status='failed',finished_at=now(),error=type(exc).__name__+': '+str(exc))
                self._commit(d,'Integration phase failed; outputs retained.')
                write_group_report(cfg,group,self.workspace,d['group_jobs'][group]);raise
            self._commit(d,'Completed integration '+group+' / '+phase)
            write_group_report(cfg,group,self.workspace,d['group_jobs'][group]);return result

    def frontend_check(self):
        with self.store.exclusive():
            d=self.snapshot();d['frontend_check']={'at':now(),'status':'python_callback_received'}
            self._commit(d,'Browser-to-kernel callback check received (scientific execution not tested).')
        return 'Browser callback received and saved. Refresh/reopen to verify persistence.'

    def acknowledge_stopped_job(self,sample,action,*,confirmed=False,reviewer=''):
        """Acknowledge externally checked interruption; never kills workers or removes locks/products."""
        if not confirmed or not reviewer.strip():raise ValueError('Inspect the worker/log first and confirm it is no longer running; provide your name.')
        with self.store.exclusive():
            d=self.snapshot();key=self.key(sample,d['project']);job=d['jobs'].get(key,{}).get(action,{})
            if job.get('status')!='running':raise ValueError('This controller action is not marked running.')
            job.update(status='interrupted',recovery_reviewer=reviewer,recovery_at=now(),
                       recovery_note='User confirmed worker stopped. Existing scientific locks/products not modified.')
            self._commit(d,'Recorded stopped-job acknowledgement; scientific reuse/partial-output checks remain active.')

    def save_runtime_settings(self,values):
        """Change explicit worker locations through the UI; no environment installation or process launch."""
        import sys,shutil
        allowed={'python_spatial','python_stardist','python_scvi','python_rapids','proseg_executable'}
        if set(values)-allowed:raise ValueError('Unknown runtime field.')
        converted={}
        for k,value in values.items():
            value=str(value).strip()
            if k=='proseg_executable':
                target=shutil.which(value) if '/' not in value else str(Path(value).expanduser().absolute())
            else:target=sys.executable if value=='current' else str(Path(value).expanduser().absolute())
            if not target or not Path(target).is_file() or not os.access(target,os.X_OK):raise ValueError(f'{k}: executable not accessible: {value}')
            converted[k]=target
        with self.store.exclusive():
            d=self.snapshot()
            for k,v in converted.items():
                if k=='proseg_executable':d['project']['settings']['proseg']['executable']=v
                else:d['project']['settings']['execution'][k]=v
            self._commit(d,'Saved worker executable locations; imports/GPU compatibility still checked at launch.',export=True)
