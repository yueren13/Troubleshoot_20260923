# Visium HD pipeline v3 — review candidate

Version: 0.3.0-review, generated 2026-09-28. Start with [docs/START_HERE.md](docs/START_HERE.md).
This is an implemented review/pilot candidate, not a production-validated pipeline.
Read [validation](docs/VALIDATION_SUMMARY.md) and [scope](docs/IMPLEMENTATION_STATUS.md) before real writes.

The v2 processing/compute framework is retained. New `vhd/he`, `vhd/annotations`, and
`vhd/persistence` packages provide fixed-reference H&E, source-reviewed annotations,
and selective master updates. `vhd/master.py` connects these to the existing controller.
One row per sample remains the setup contract. Paths are data, not hard-coded users.

## Entry points
- `00`: CSV/settings, stage plan, actual storage roots and permissions.
- `99`: CPU and target-environment tests before processing data.
- `00B`: midway bin/cell migration, never resegmentation.
- `01`: Space Ranger or existing-bin import.
- `02`: accepted-QC reuse OR fixed-reference H&E measurement and explicit classification.
- `02A`: optional polygon/signal import and alignment previews.
- `02B`: approved assets to bin metadata and explicit pathology decisions.
- `03` / `04`: StarDist sample-per-GPU / Proseg CPU parallel samples.
- `05` / `05B`: cell import/postprocessing / metadata-only annotation refresh.
- `06`: create or selectively extend a stable canonical master.
- `07`: selective table loading.
- `08`–`11`: scVI preparation, training, ten Leiden resolutions, UMAP, writeback.
- `12`: explicit export/snapshot/publication, not compulsory whole-store versioning.
- `13`: deliberate metadata/element update and recovery workbench for existing masters.

## Important boundaries
Fresh bin QC requires user-specified tissue-score and transcript cutoffs. Original
Step03 thresholds were not supplied; they are not guessed. Already accepted QC can
be reused without supplying new cutoffs.

Updates require approved roots and explicit single-writer acknowledgement. Mounted
S3 is accessed as a filesystem, without any mount-management commands. Backups and
failed-transaction journals are retained; there is no automatic data cleanup.

Image-to-bin signal and nuclear exclusion fractions use BIN CENTERS, not physical
area integrals. Pixel-level/area-weighted signal aggregation is a distinct extension.
No conventional Macenko percentile-normalized map is used for quantitative tissue QC.

## GitHub state
The scVI handoff fix is committed separately in draft PR #3, based on the unmerged
foundation branch. The full v3 candidate is delivered as this bundle, not silently
merged into PR #1 or main. See [GitHub handoff](docs/GITHUB_HANDOFF.md).

No software license is selected by this candidate. Preserve source/third-party attribution.
