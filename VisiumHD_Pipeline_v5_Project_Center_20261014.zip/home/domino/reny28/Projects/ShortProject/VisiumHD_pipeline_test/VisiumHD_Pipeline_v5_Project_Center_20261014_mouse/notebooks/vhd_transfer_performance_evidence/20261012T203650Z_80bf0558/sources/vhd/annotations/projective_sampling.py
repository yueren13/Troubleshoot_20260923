"""Source-pixel overlap for model-derived projective bin quadrilaterals.

No common affine footprint basis is assumed. Source pixels remain piecewise
constant unit squares; area weights are measured in source-pixel units.
"""
from __future__ import annotations
import numpy as np
from ..core import affine
from ..projective_grid import grid_corners
from .area_sampling import METHODS, _read_pairs


def summarize_projective_bins(field, rows, cols, *, grid_index_to_fullres,
        source_to_fullres, methods=('mean',), min_valid_fraction=0., chunk_size=20000,
        max_pairs=1000000, max_pixels_per_bin=4096, tile_size=512, coverage_source=None):
    import shapely
    methods = list(methods)
    if not methods or set(methods)-set(METHODS) or len(set(methods)) != len(methods):
        raise ValueError('Choose unique mean/median/sum/max/min methods.')
    if not np.isfinite(min_valid_fraction) or not 0 <= min_valid_fraction <= 1:
        raise ValueError('min_valid_fraction must be in [0,1].')
    for v in (chunk_size, max_pairs, max_pixels_per_bin, tile_size):
        if not isinstance(v, (int, np.integer)) or isinstance(v, bool) or v < 1:
            raise ValueError('Chunk/pixel limits must be positive integers.')
    if len(field.shape) != 2:raise ValueError('A single 2D signal channel is required.')
    rows, cols = np.asarray(rows), np.asarray(cols)
    if rows.ndim != 1 or rows.shape != cols.shape:raise ValueError('Paired grid indices required.')
    inv = np.linalg.inv(affine(source_to_fullres)); n = len(rows)
    result = {m:np.full(n, np.nan, float) for m in methods}
    result.update(in_bounds_fraction=np.zeros(n), valid_fraction=np.zeros(n),
                  n_valid_pixels=np.zeros(n,np.int32),valid=np.zeros(n,bool))
    height,width = field.shape
    for start in range(0,n,chunk_size):
        end=min(n,start+chunk_size)
        vertices=grid_corners(rows[start:end],cols[start:end],grid_index_to_fullres)
        uv=vertices@inv[:2,:2].T+inv[:2,2]
        if np.max(np.abs(uv),initial=0)>2**50:raise ValueError('Signal coordinates exceed safe pixel-index range; review registration.')
        footprints=shapely.polygons(uv);areas=shapely.area(footprints)
        if not shapely.is_valid(footprints).all() or np.any(areas<=1e-15):raise ValueError('Degenerate signal-space bin footprint.')
        lo=uv.min(axis=1);hi=uv.max(axis=1)
        nx=int(np.ceil((hi[:,0]-lo[:,0]).max()))+2
        ny=int(np.ceil((hi[:,1]-lo[:,1]).max()))+2;k=nx*ny
        if k>max_pixels_per_bin or k>max_pairs:
            raise ValueError(f'{k} candidate pixels/bin exceeds max_pixels_per_bin or max_pairs; inspect registration before increasing limits.')
        dy,dx=np.mgrid[:ny,:nx];dx=dx.ravel();dy=dy.ravel()
        batch=max(1,max_pairs//k)
        for l in range(0,end-start,batch):
            u=min(end-start,l+batch);area=areas[l:u]
            xx=np.floor(lo[l:u,0]+.5).astype(np.int64)[:,None]+dx
            yy=np.floor(lo[l:u,1]+.5).astype(np.int64)[:,None]+dy
            bounds=(xx>=0)&(xx<width)&(yy>=0)&(yy<height)
            intersections=shapely.intersection(footprints[l:u,None],shapely.box(xx-.5,yy-.5,xx+.5,yy+.5))
            weights=shapely.area(intersections)
            inbounds=np.where(bounds & (weights>area[:,None]*1e-12),weights,0.)
            if coverage_source is not None:
                weights=shapely.area(shapely.intersection(intersections,coverage_source))
            weights=np.where(bounds & (weights>area[:,None]*1e-12),weights,0.)
            active=weights>0;values=np.full(weights.shape,np.nan)
            if active.any():values[active]=_read_pairs(field,yy[active],xx[active],tile_size)
            if np.isinf(values).any():raise ValueError('Infinite measured signal values are not valid.')
            vw=np.where(np.isfinite(values),weights,0.);den=vw.sum(axis=1)
            ids=slice(start+l,start+u)
            result['in_bounds_fraction'][ids]=np.clip(inbounds.sum(axis=1)/area,0,1)
            result['valid_fraction'][ids]=np.clip(den/area,0,1)
            result['n_valid_pixels'][ids]=(vw>0).sum(axis=1)
            keep=(den>area*1e-12)&(den/area+1e-12>=min_valid_fraction);result['valid'][ids]=keep
            totals=(np.where(vw>0,values,0)*vw).sum(axis=1)
            for method in methods:
                if method=='sum':v=totals
                elif method=='mean':v=np.divide(totals,den,out=np.full(len(den),np.nan),where=den>0)
                elif method=='max':v=np.where(vw>0,values,-np.inf).max(axis=1)
                elif method=='min':v=np.where(vw>0,values,np.inf).min(axis=1)
                else:
                    order=np.argsort(np.where(vw>0,values,np.inf),axis=1,kind='stable')
                    val=np.take_along_axis(values,order,axis=1);ww=np.take_along_axis(vw,order,axis=1);cum=np.cumsum(ww,axis=1)
                    mid=den/2;index=(cum>=mid[:,None]).argmax(axis=1);rr=np.arange(len(den));v=val[rr,index]
                    tied=(den>0)&np.isclose(cum[rr,index],mid,atol=area*1e-12,rtol=1e-10)
                    nxt=np.minimum(index+1,val.shape[1]-1);tied&=(nxt>index)&(ww[rr,nxt]>0)
                    v=np.where(tied,(v+val[rr,nxt])/2,v)
                result[method][ids]=np.where(keep,v,np.nan)
    result['in_bounds']=result['in_bounds_fraction']>0
    return result
