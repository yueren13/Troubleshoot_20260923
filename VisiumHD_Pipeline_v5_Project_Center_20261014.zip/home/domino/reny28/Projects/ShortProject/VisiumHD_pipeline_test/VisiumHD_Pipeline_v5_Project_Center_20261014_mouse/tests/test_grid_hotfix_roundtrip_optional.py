"""Optional real AnnData H5AD roundtrip; original microscope/count loading is stubbed.

Not a full Space Ranger or SpatialData import validation. No GPU dependency.
"""
import json
import numpy as np
import pandas as pd
import pytest
from scipy import sparse
ad=pytest.importorskip('anndata')
pytest.importorskip('pyarrow')
from vhd import io
from vhd.core import affine,transform_xy


def test_quantized_grid_real_h5ad_roundtrip(tmp_path,monkeypatch):
    r,c=np.mgrid[:20,:25];r=r.ravel();c=c.ravel()
    xy=np.rint(transform_xy(np.c_[c,r],affine([7.71,.11,333,.13,7.82,713])))
    names=pd.Index([f'BC{i:04}' for i in range(len(r))])
    base=tmp_path/'outs'/'binned_outputs'/'square_002um'
    (base/'spatial').mkdir(parents=True);(base/'raw_feature_bc_matrix').mkdir()
    (base/'raw_feature_bc_matrix'/'barcodes.tsv').write_text('\n'.join(names)+'\n')
    pos=pd.DataFrame({'barcode':names,'array_row':r,'array_col':c,
        'pxl_col_in_fullres':xy[:,0],'pxl_row_in_fullres':xy[:,1]})
    pos.sample(frac=1,random_state=1).to_parquet(base/'spatial'/'tissue_positions.parquet')
    (base/'spatial'/'scalefactors_json.json').write_text(json.dumps({'microns_per_pixel':.25}))
    img=tmp_path/'image.svs';img.write_text('explicitly stubbed image')
    counts=sparse.csr_matrix(np.tile([1,2,3],(len(r),1)),dtype=np.int32)
    def source(path):return ad.AnnData(X=counts.copy(),obs=pd.DataFrame(index=names),
        var=pd.DataFrame({'gene_symbol':['DUP','DUP','MT-CO1']},index=['id1','id2','id3']))
    monkeypatch.setattr(io,'read_raw_counts',source)
    monkeypatch.setattr(io,'image_info',lambda *a,**k:{'mpp':[.25,.25],'width':2000,'height':2000})
    cfg={'work_root':str(tmp_path/'work'),'output_root':str(tmp_path/'output'),'coordinates':{'grid_max_residual_px':.1}}
    spec={'sample':'S','outs':str(tmp_path/'outs'),'image':str(img),'tenx_to_image_affine':np.eye(3).tolist()}
    geom=io.ingest(cfg,spec)
    a=ad.read_h5ad(tmp_path/'work'/'S'/'bins_raw.h5ad')
    assert (a.X!=counts).nnz==0
    np.testing.assert_array_equal(a.obsm['spatial'],xy)
    assert a.obs_names.equals(names)
    assert a.var_names.tolist()==['id1','id2','id3']
    assert a.var['gene_symbol'].tolist()==['DUP','DUP','MT-CO1']
    assert geom['grid_fit']['acceptance']=='verified_integer_pixel_rounding'
