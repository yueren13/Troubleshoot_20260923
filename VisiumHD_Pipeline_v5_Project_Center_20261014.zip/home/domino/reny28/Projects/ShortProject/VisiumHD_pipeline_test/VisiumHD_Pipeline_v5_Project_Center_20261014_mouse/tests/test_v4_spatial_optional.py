"""Real tiny scientific read/write tests; a module skip is NOT a passing roundtrip."""
from pathlib import Path
import copy,json
import numpy as np
import pandas as pd
import pytest
ad=pytest.importorskip('anndata')
sd=pytest.importorskip('spatialdata')
pytest.importorskip('zarr')
from PIL import Image
from scipy import sparse
from vhd.compact_images import build_images,validate_images
from vhd.analysis_qc import run_analysis_qc,require_analysis_qc,analysis_mask


def test_compact_roundtrip(tmp_path):
    out=tmp_path/'outs/spatial';out.mkdir(parents=True)
    Image.fromarray(np.full((12,18,3),240,np.uint8)).save(out/'tissue_hires_image.png')
    Image.fromarray(np.full((4,6,3),240,np.uint8)).save(out/'tissue_lowres_image.png')
    (out/'scalefactors_json.json').write_text(json.dumps({'tissue_hires_scalef':.1,'tissue_lowres_scalef':1/30}))
    cfg={'storage':{'image_policy':'compact'}};geom={'tenx_to_image':np.eye(3).tolist()}
    images,record=build_images(cfg,{'outs':str(out.parent)},geom)
    s=sd.SpatialData(images=images,attrs={'image_storage':record,'geometry':geom})
    path=tmp_path/'compact.zarr';s.write(path)
    live=sd.read_zarr(path,selection=('images',));result=validate_images(live)
    assert result['image_policy']=='compact' and set(live.images)=={'he_hires','he_lowres'}
    assert not (path/'images/he_original').exists()


def test_actual_qc_sidecars_gene_rule_and_master_unchanged(tmp_path):
    from vhd.core import file_stamp
    specs=[]
    for name in ('A','B'):
        root=tmp_path/name;store=root/'master.zarr';(store/'tables').mkdir(parents=True)
        # G1 is detected in 4 retained cells across the group; G2 in exactly 2.
        x=sparse.csr_matrix([[0,3,0],[0,3,1],[2,1,0]],dtype=np.int32)
        obs=pd.DataFrame({'qc_pass':True},index=[name+str(i) for i in range(3)])
        var=pd.DataFrame({'gene_symbol':['MT-A','G1','G2']},index=['mt','g1','g2'])
        a=ad.AnnData(x,obs=obs,var=var);a.write_zarr(store/'tables/cells')
        specs.append({'sample':name,'metadata':{'species':'mouse'},'_paths':{'work':str(root/'work'),'report':str(root/'reports'),
                      'proseg':str(root/'proseg'),'store':str(store)}})
    cfg={'samples':specs,'_integration_work':str(tmp_path/'integration'),'plots':{'dpi':60},'analysis_qc':{'enabled':True,'min_counts':3,'min_cells_per_gene':3},'scvi':{'run_name':'qc'}}
    before=[file_stamp(Path(s['_paths']['store'])/'tables/cells') for s in specs]
    rec=run_analysis_qc(cfg);require_analysis_qc(cfg)
    assert all(s['n_pass']==2 for s in rec['summary'])
    genes=pd.read_csv(tmp_path/'integration/analysis_qc/gene_detection.csv',index_col=0)
    assert genes.loc['g1','pass_min_cells'] and not genes.loc['g2','pass_min_cells']
    assert [file_stamp(Path(s['_paths']['store'])/'tables/cells') for s in specs]==before
    assert run_analysis_qc(cfg)['signature']==rec['signature']
