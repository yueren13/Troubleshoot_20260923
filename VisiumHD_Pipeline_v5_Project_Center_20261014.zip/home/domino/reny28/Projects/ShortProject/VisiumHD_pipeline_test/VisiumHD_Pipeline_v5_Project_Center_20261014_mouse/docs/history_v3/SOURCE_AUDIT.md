# Source audit and intentionally explicit limits

Snapshot repository: `yueren13/Troubleshoot_20260923`  
Directory: `project_1`  
Retrieved tree commit: `9e68dce8fb4acef46fc6d1071c363a25d9e6eec1`  
Review date: September 23, 2026.

## What was and was not inspected

The complete recursive tree returned ten notebooks plus repository metadata/README. The two named helper modules, `cfs_spatialdata_202412.py` and `cfs_normhe_202605.py`, were not in that tree. Searches of available attached/Library file content did not recover them. Their implementation was not inferred from their names.

| Notebook | Access/review status |
|---|---|
| 00_TBIO8110_Config_Preflight.ipynb | Code ranges inspected for study paths, sample IDs, canonical QC classes, registration and preflight metadata |
| 01_TBIO8110_StarDist_SVS_QCprior.ipynb | Code ranges inspected for model thresholds, crop/resize, image reading and prior paths |
| 02_TBIO8110_Proseg_ROBUST.ipynb | Code ranges inspected for raw input selection, coordinate order, CLI arguments, recovery, counts and polygons |
| TBIO8110_03_CellQC_ObsTransfer_CellCycle_h5ad_uns_fix.ipynb | Code ranges inspected for transfer configuration, eligibility and serialization fixes |
| Step01_DatasetPreProcessing_SpatialobjectGeneration_20260615.ipynb | Large file (~67 MB); readable source was not returned by attempted connector retrieval |
| Step02_DatasetPreProcessing_h&eNorm_20260825.ipynb | Large file (~9 MB); full code not reviewed |
| Step03_DataProcess_QCFitler_VisiumHD.20260826.ipynb | Large file (~11 MB); fetch returned empty content |
| TBIO8110_02_Proseg_ROBUST_parallel4_CPU.ipynb | Large file (~13 MB); complete code not reviewed |
| TBIO8110_02b_Postprocess_Existing_Proseg_NoRerun.ipynb | Present, but not fully reviewed; no claim of a line-for-line port |
| 03_TBIO8110_CellQC_ObsTransfer_CellCycle.ipynb | Present; fixed later variant was partially inspected instead |

This is a **partial source review**, not a claim to have read every code cell or executed the original notebooks. The new shared package was authored explicitly and does not execute old notebooks or import absent custom helpers.

## Findings based on actual inspected code

1. Both `tissue-high_transcript-high` and `tissue-high_transcript-low` are retained. Both tissue-low classes are excluded. The raw spelling `trancript` is normalized.
2. The original Proseg input `obsm["spatial"]` uses **Space Ranger row × source MPP first, column × source MPP second**. A column named `centroid_x` therefore cannot simply be treated as canonical image x. The migration mode declares and converts this convention.
3. The StarDist study settings are model `2D_versatile_he`, probability threshold **0.02**, NMS **0.30**, target MPP **0.3**, crop buffer **50 µm**, and minimum **one retained bin center** supporting a nucleus.
4. The inspected Proseg runner uses 2-µm burn-in/final voxels, a single z layer, ignored z coordinates and diffusion scales 2/8 µm. It writes durable point-count MTX, cell/gene metadata and polygons. Expected fractional counts are disabled.
5. The old count-recovery routine infers a transpose from matrix shape. For a square cell-by-gene matrix that inference is ambiguous. This release requires an explicit orientation; the official current Proseg README describes its counts output as **cell-by-gene**.
6. The old gzip recovery can consume only the first complete gzip member and ignore trailing bytes. This release uses strict gzip reading rather than silently discarding data; existing repaired cell H5ADs can be imported directly.
7. The fixed cell-QC notebook uses inclusive technical eligibility (≥1 count and ≥1 gene), with the 25% mt cutoff inactive by default. It also fixes heterogeneous list-of-dictionaries serialization in `.uns`.
8. The image MPP and Space Ranger source MPP can differ. For the inspected Sample01 output, the two reported values were approximately 0.263129 and 0.26358845. The new example does not hardcode these values across samples.

## New implementation choices, not claims of historical equivalence

- Direct Space Ranger coordinate ingestion rather than relying on a particular `spatialdata_io.visium_hd` version's local element coordinates.
- Compact bin labels with a validated affine rather than millions of individual bin polygons.
- A known original-image coordinate frame and explicit crop/resampling center transformation.
- Optional standalone **Reinhard LAB** H&E normalization, not a reconstructed implementation of the missing normalization helper.
- A transparent **thumbnail foreground OD + UMI threshold** fresh QC baseline, not a claim to duplicate Step03's classifier or tissue morphology handling. Migration mode preserves accepted classes instead.
- Strict shape and ID checks; no fabricated boundaries or automatic geometry repairs.
- Separate geometric annotation transfer and authoritative Proseg molecule-count output.
- Stable gene-ID intersection and an explicitly described per-sample HVG consensus for scVI.
- A zero-gene `cells_scvi` annotation table for safe writeback, avoiding expression duplication.

## Public primary references checked

- SpatialData container and element models: https://spatialdata.scverse.org/en/stable/api/SpatialData.html and https://spatialdata.scverse.org/en/stable/api/models.html
- SpatialData read selection: https://spatialdata.scverse.org/en/stable/api/io.html
- AnnData Zarr-format settings: https://anndata.readthedocs.io/en/stable/generated/anndata.settings.html
- AnnData on-disk concatenation: https://anndata.readthedocs.io/en/stable/generated/anndata.experimental.concat_on_disk.html
- scVI setup/training/model saving: https://docs.scvi-tools.org/en/stable/api/reference/scvi.model.SCVI.html
- Proseg input transforms and point/expected counts: https://github.com/dcjones/proseg
- microViz palette documentation: https://david-barnett.github.io/microViz/reference/distinct_palette.html
- microViz color values: https://github.com/david-barnett/microViz/blob/main/R/distinct_palette.R

The current public documentation does not establish that your exact historical coordinate discrepancy has been fixed in a particular release. A smaller coordinate range can also be a valid intrinsic coordinate system with a scale transform. The new implementation avoids relying on that ambiguity and tests stored transforms directly.
