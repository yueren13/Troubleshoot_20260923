"""Synthetic numerical/filesystem checks, not scientific GPU or mounted-store validation."""
import os,json,importlib.util
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest
import geopandas as gpd
from shapely.geometry import box
from vhd.he.fixed import *
from vhd.he.workflow import classify
from vhd.annotations.geometry import read_imagescope_annotation_xml,classify_polygons
from vhd.annotations.transfer import aggregate_annotations,segmentation_decisions,gate_pathology
from vhd.persistence.transaction import apply_replacements,recover_transaction,inventory
from vhd.persistence.spatial import aligned
from vhd.control.paths_v3 import assert_target,require_roots,expand_path,storage_profile


def reference():
    spec=importlib.util.spec_from_file_location('reference',Path(__file__).parent/'fixtures/user_fixed_reference.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


@pytest.mark.parametrize('batch',[17,200000])
def test_extractor_matches_user_numerical_contract(batch):
    rgb=np.random.default_rng(42).integers(20,255,(20,30,3),dtype=np.uint8)
    H,E,_=extract_he_concentrations_reference(rgb,channel_axis=-1,lstsq_batch=batch)
    h,e,_=reference().extract_he_concentrations_reference(rgb,lstsq_batch=batch)
    np.testing.assert_allclose(H,h,atol=2e-7);np.testing.assert_allclose(E,e,atol=2e-7)


@pytest.mark.parametrize('method',['soft_union','max','weighted_mean'])
@pytest.mark.parametrize('weight',[.6,1.])
def test_scores_match_user_contract(method,weight):
    h=np.linspace(0,3,600).reshape(20,30).astype(np.float32);e=h[::-1]
    v=fixed_scale_he_tissue_score(h,e,method=method,h_weight=weight)
    ref=reference().fixed_scale_he_tissue_score(h,e,method=method,h_weight=weight)
    for a,b in zip(v,ref):np.testing.assert_allclose(a,b,atol=2e-7)


def test_patch_and_batch_invariance():
    h=np.full((12,13),.3);e=np.full_like(h,.2)
    rgb=(255*np.exp(-(HE_REFERENCE@np.stack([h,e]).reshape(2,-1)))-1).T.reshape(12,13,3).astype(np.float32)
    H,E,_=extract_he_concentrations_reference(rgb,channel_axis=-1)
    np.testing.assert_allclose(H,h,atol=5e-7);np.testing.assert_allclose(E,e,atol=5e-7)
    large=np.full((50,60,3),255.,np.float32);large[2:14,3:16]=rgb
    lh,le,_=extract_he_concentrations_reference(large,channel_axis=-1,lstsq_batch=11)
    np.testing.assert_allclose(lh[2:14,3:16],H);np.testing.assert_allclose(le[2:14,3:16],E)


def test_white_and_explicit_float_range():
    h,e,_=extract_he_concentrations_reference(np.full((7,8,3),255,np.uint8),channel_axis=-1)
    assert not h.any() and not e.any()
    with pytest.raises(ValueError):extract_he_concentrations_reference(np.full((7,8,3),.8,np.float32),channel_axis=-1)
    H,E,_=extract_he_concentrations_reference(np.full((7,8,3),.8,np.float32),channel_axis=-1,intensity_range=(0,1))
    a,b,_=extract_he_concentrations_reference(np.full((7,8,3),204,np.uint8),channel_axis=-1)
    np.testing.assert_allclose(H,a);np.testing.assert_allclose(E,b)


def test_vector_io_layout_and_alpha():
    _,_,io=extract_he_concentrations_reference(np.full((7,8,3),200,np.uint8),channel_axis=-1,Io=[245,250,255])
    assert io.tolist()==[245,250,255]
    with pytest.raises(ValueError):extract_he_concentrations_reference(np.full((3,8,3),200,np.uint8))
    rgba=np.zeros((7,8,4),np.uint8)
    with pytest.raises(ValueError):extract_he_concentrations_reference(rgba,channel_axis=-1)
    h,e,_=extract_he_concentrations_reference(rgba,channel_axis=-1,alpha='white');assert not h.any() and not e.any()


@pytest.mark.parametrize('kw',[{'h_weight':-1},{'h_weight':np.nan},{'h_weight':0,'e_weight':0}, {'h_threshold':.5},{'score_threshold':.5,'h_threshold':.2,'e_threshold':.2},{'score_threshold':2}])
def test_bad_combinations(kw):
    with pytest.raises(ValueError):combine_he_fixed_tissue_signal(np.ones((4,5)),np.ones((4,5)),**kw)


@pytest.mark.parametrize('value',[0,-1,np.nan,np.inf])
def test_bad_limits(value):
    with pytest.raises(ValueError):fixed_scale_he_tissue_score(np.ones((4,5)),np.ones((4,5)),h_limit=value)


def test_no_broadcasting():
    with pytest.raises(ValueError):fixed_scale_he_tissue_score(np.ones((4,1)),np.ones((4,5)))


@pytest.mark.parametrize('interpolation',['linear','nearest'])
def test_mapping_matches_legacy_and_tile_boundaries(interpolation):
    field=np.random.default_rng(42).random((37,55)).astype(np.float32);xy=np.random.default_rng(2).uniform(-3,110,(1000,2));scale=.5
    def obj():return SimpleNamespace(n_obs=len(xy),obs=pd.DataFrame(index=[str(i) for i in range(len(xy))]),obsm={'spatial':xy},uns={})
    old=reference().map_hires_image_to_visiumhd_bins(obj(),field,tissue_hires_scalef=scale,out_key='s',interpolation=interpolation,show_progress=False)
    new,_,_=sample_field(field,xy,source_to_fullres=np.diag([2,2,1]),interpolation=interpolation,tile_size=7,chunk_size=23)
    np.testing.assert_allclose(new,old,equal_nan=True,atol=2e-7)


def test_combine_before_sample():
    H=np.array([[1,0],[1,0]],np.float32);E=1-H
    score,_=combine_he_fixed_tissue_signal(H,E)
    s,_,_=sample_field(score,[[.5,.5]],source_to_fullres=np.eye(3))
    h,_,_=sample_field(H,[[.5,.5]],source_to_fullres=np.eye(3));e,_,_=sample_field(E,[[.5,.5]],source_to_fullres=np.eye(3))
    other,_=combine_he_fixed_tissue_signal(h,e);assert s[0]==1 and other[0]==.75


def test_affine_and_invalid_mapping():
    a=np.arange(20,dtype=np.float32).reshape(4,5);m=[[2,0,10],[0,3,20],[0,0,1]]
    v,i,ok=sample_field(a,[[12,23],[8,20],[np.nan,20]],source_to_fullres=m)
    assert v[0]==6 and i.tolist()==[True,False,False]
    a[1,1]=np.nan;v,i,ok=sample_field(a,[[12,23]],source_to_fullres=m);assert i[0] and not ok[0]
    for kw in [{'chunk_size':0},{'interpolation':'cubic'},{'tile_size':0}]:
        with pytest.raises(ValueError):sample_field(a,[[1,1]],source_to_fullres=np.eye(3),**kw)


def xml(path,multi=False):
    def region(xy,negative=False):return '<Region NegativeROA="'+('1' if negative else '0')+'"><Vertices>'+''.join(f'<V X="{x}" Y="{y}"/>' for x,y in xy)+'</Vertices></Region>'
    text='<Annotations><Annotation Name="Tissue"><Regions>'+region([(0,0),(10,0),(10,10),(0,10)])+region([(4,4),(6,4),(6,6),(4,6)],True)
    if multi:text+=region([(20,0),(22,0),(22,2),(20,2)])
    path.write_text(text+'</Regions></Annotation></Annotations>');return path


@pytest.mark.parametrize('multi',[False,True])
def test_xml_holes_preserved(tmp_path,multi):
    g=read_imagescope_annotation_xml(xml(tmp_path/'a.xml',multi))
    assert g.geometry.area.sum()==(100 if multi else 96)
    assert classify_polygons([[5,5],[1,1]],g,exhaustive=True).Tissue.tolist()==[False,True]


def test_xml_malformed_is_not_silently_dropped(tmp_path):
    p=tmp_path/'bad.xml';p.write_text('<Annotations><Annotation><Regions><Region/></Regions></Annotation></Annotations>')
    with pytest.raises(ValueError):read_imagescope_annotation_xml(p)


def test_reassignment_unknown_and_overlap():
    g=gpd.GeoDataFrame({'name':['Tissue']},geometry=[box(0,0,4,4)]);xy=[[1,1],[3,1],[8,1]]
    a=classify_polygons(xy,g,exhaustive=True);g.geometry=[box(0,0,2,2)];b=classify_polygons(xy,g,exhaustive=True)
    assert a.Tissue.tolist()==[True,True,False] and b.Tissue.tolist()==[True,False,False]
    assert pd.isna(classify_polygons(xy,g).Tissue.iloc[1])
    g=gpd.GeoDataFrame({'name':['Tissue','Necrosis']},geometry=[box(0,0,4,4),box(0,0,2,2)])
    flags=classify_polygons([[1,1]],g,exhaustive=True);assert flags.Tissue[0] and flags.Necrosis[0]
    assert classify_polygons([[1,1]],g,mode='categorical')['class'][0]=='mixed'


def test_aggregation_coverage_ties_and_missing_sum():
    o=pd.DataFrame({'class':['tumor','stroma',None,None],'value':[1,3,np.nan,np.nan],'flag':pd.array([True,False,pd.NA,pd.NA],dtype='boolean')})
    r=aggregate_annotations(o,np.array([0,0,0,1]),2,{'categorical':['class'],'boolean':['flag'],'continuous':{'value':['sum','mean','median']}})
    assert r['geometric__class__dominant'][0]=='mixed' and r['geometric__class__dominant_fraction'][0]==.5
    assert r['geometric__class__annotation_coverage'][0]==pytest.approx(2/3)
    assert r['geometric__value__sum'][0]==4 and np.isnan(r['geometric__value__sum'][1])


def test_pathology_preserves_base_and_unknown():
    o=pd.DataFrame({'qc_keep':[True,True,True,False],'Tissue':pd.array([True,True,pd.NA,True],dtype='boolean'),'Necrosis':pd.array([False,True,False,False],dtype='boolean')})
    r=segmentation_decisions(o,{'enabled':True,'tissue_column':'Tissue','exclude_columns':['Necrosis']})
    assert r.segmentation_keep.tolist()==[True,False,False,False];assert r.base_bin_qc_keep.tolist()==o.qc_keep.tolist()


def test_prior_gate_majority_exclusion(tmp_path):
    mask=np.array([[1,1,2,2],[1,1,2,2]],np.uint32);xy=np.array([[0,0],[1,0],[2,0],[3,0]])
    o=pd.DataFrame({'segmentation_keep':[True,False,True,True]})
    a=gate_pathology(mask,xy,o,tmp_path/'prior.npy',{'minimum_support_bins':1,'max_excluded_bin_fraction':0})
    assert a.retain_for_proseg.tolist()==[False,True]
    assert np.load(tmp_path/'prior.npy').tolist()==[[0,0,1,1],[0,0,1,1]]


def test_qc_thresholds_explicit_and_low_transcript_tissue_retained():
    o=pd.DataFrame({'total_counts':[1]},index=['b']);m=pd.DataFrame({'he_tissue_score':[.7],'he_tissue_score_valid':[True]},index=o.index)
    with pytest.raises(ValueError):classify(o,m,{})
    r=classify(o,m,{'tissue_score_threshold':.5,'transcript_threshold':5})
    assert r.qc_keep.iloc[0] and r.qc_class.iloc[0]=='tissue-high_transcript-low'
    m.he_tissue_score_valid=False;assert classify(o,m,{'tissue_score_threshold':.5,'transcript_threshold':5}).qc_class.iloc[0]=='unassessed'


def test_explicit_roots_and_env(tmp_path,monkeypatch):
    monkeypatch.setenv('VHD_TEST_ROOT',str(tmp_path));assert expand_path('${VHD_TEST_ROOT}/x')==str(tmp_path/'x')
    monkeypatch.delenv('VHD_UNSET',raising=False)
    with pytest.raises(ValueError):expand_path('${VHD_UNSET}/x')
    with pytest.raises(FileNotFoundError):require_roots({'required_existing_roots':[str(tmp_path/'absent')]})
    assert not (tmp_path/'absent').exists()
    assert_target(tmp_path/'data/new.zarr',[tmp_path],[tmp_path/'data/old.zarr'])
    with pytest.raises(ValueError):assert_target(tmp_path/'data/old.zarr/tables',[tmp_path],[tmp_path/'data/old.zarr'])
    with pytest.raises(PermissionError):assert_target(tmp_path/'other',[tmp_path/'allowed'])


def store(tmp_path):
    p=tmp_path/'a.zarr';(p/'tables/cells/obs').mkdir(parents=True);(p/'tables/cells/obs/data').write_bytes(b'old')
    (p/'tables/cells/X').mkdir();(p/'tables/cells/X/data').write_bytes(b'counts')
    incoming=tmp_path/'new';incoming.mkdir();(incoming/'data').write_bytes(b'new')
    return p,incoming,{'approved_master_roots':[str(tmp_path)]}


def test_metadata_component_dry_run_and_count_preservation(tmp_path):
    p,src,pol=store(tmp_path);before=inventory(p/'tables/cells/X')
    apply_replacements(p,{'tables/cells/obs':src},pol);assert (p/'tables/cells/obs/data').read_bytes()==b'old'
    r=apply_replacements(p,{'tables/cells/obs':src},pol,execute=True,single_writer_ack=True)
    assert r['state']=='committed' and inventory(p/'tables/cells/X')==before
    assert (Path(r['journal']).parent/'backup/tables/cells/obs/data').read_bytes()==b'old'


def test_interruption_rollback_and_block_followup(tmp_path):
    p,src,pol=store(tmp_path)
    def fault(phase):
        if phase.startswith('promoted:'):raise RuntimeError('injected')
    with pytest.raises(RuntimeError,match='incomplete'):apply_replacements(p,{'tables/cells/obs':src},pol,execute=True,single_writer_ack=True,_fault=fault)
    with pytest.raises(RuntimeError,match='Unresolved'):apply_replacements(p,{'tables/cells/obs':src},pol,execute=True,single_writer_ack=True)
    j=next((tmp_path/'a.zarr.vhd_transactions').glob('*/journal.json'));recover_transaction(j,pol,execute=True,single_writer_ack=True)
    assert (p/'tables/cells/obs/data').read_bytes()==b'old' and (p/'tables/cells/X/data').read_bytes()==b'counts'


def test_metadata_guards(tmp_path):
    p,src,pol=store(tmp_path)
    with pytest.raises(PermissionError):apply_replacements(p,{'tables/cells/obs':src},pol,execute=True)
    with pytest.raises(ValueError):apply_replacements(p,{'../other':src},pol)
    f=pd.DataFrame({'a':[2,1]},index=['b','a']);assert aligned(f,pd.Index(['a','b'])).a.tolist()==[1,2]
    with pytest.raises(ValueError):aligned(f,pd.Index(['a','c']))


def test_optional_display_normalizer_return_contract():
    from vhd.he.display_legacy import macenko_normalize_visiumhd
    h=np.linspace(.1,.8,400);e=np.linspace(.05,.5,400)
    rgb=(255*np.exp(-(HE_REFERENCE@np.stack([h,e]))).T-1).reshape(20,20,3)
    options=dict(Io=255,basis_mode='reference',stain_mode='both',return_concentrations=True)
    both=macenko_normalize_visiumhd(rgb,return_HE_H_E=True,concentration_output='both',**options)
    raw=macenko_normalize_visiumhd(rgb,concentration_output='raw',**options)
    normalized=macenko_normalize_visiumhd(rgb,concentration_output='normalized',**options)
    assert len(both)==8 and len(raw)==len(normalized)==3
    np.testing.assert_allclose(both[4],raw[1]);np.testing.assert_allclose(both[6],normalized[1])
    assert not np.allclose(raw[1],normalized[1])


def test_xml_source_can_use_geojson_coverage(monkeypatch):
    from vhd.annotations.workflow import polygons
    import geopandas as gpd
    from shapely.geometry import box
    called=[]
    def read(path):
        called.append(path)
        return gpd.GeoDataFrame({'name':['coverage']},geometry=[box(0,0,3,3)],crs=None)
    monkeypatch.setattr(gpd,'read_file',read)
    g=polygons({'path':'source.annotations','coverage_path':'coverage.geojson','format':'imagescope_xml'},coverage=True)
    assert called==['coverage.geojson'] and g.area.iloc[0]==9


def test_downstream_rejects_changed_derived_annotation_file(tmp_path,monkeypatch):
    from vhd.master import current_annotations
    from vhd.core import file_stamp
    import vhd.core as core
    import vhd.annotations.workflow as workflow
    work=tmp_path/'work';report=tmp_path/'report';work.mkdir();report.mkdir()
    derived=work/'bins_annotated_obs.parquet';derived.write_bytes(b'synthetic metadata')
    monkeypatch.setattr(core,'sample_paths',lambda cfg,spec:{'work':work,'report':report})
    monkeypatch.setattr(workflow,'asset_specification',lambda cfg,spec:([],'signed',[]))
    (report/'assets_transfer.json').write_text(json.dumps({'signature':'signed','derived_stamp':file_stamp(derived)}))
    spec={'_row':{'assets_manifest':'reviewed.csv'}}
    current_annotations({},spec)
    derived.write_bytes(b'changed transferred metadata')
    with pytest.raises(RuntimeError,match='changed or are incomplete'):current_annotations({},spec)
