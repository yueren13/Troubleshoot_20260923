"""Collect evidence for the exact unresolved VHD transaction; never recover it.

Run beside the Project Center notebook:
    %run -i VHD_Inspect_Unresolved_Transaction.py

Only a NEW diagnostics directory/ZIP is written. This module does not import
VHD, open the Zarr with a scientific library, run workers, alter journals,
remove locks, replay/rollback transactions, or edit configuration.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import socket
import sys
import tempfile
from datetime import datetime, timezone
import zipfile

SAMPLE = "Project__BM0164135A_s1_A1"
BASE = Path("/stash/results/dev/reny28/2026/VisiumHD_pipeline_test")
STORE = BASE / "zarr_files" / "BM0164135A_s1_A1.zarr"
JOURNAL = Path(str(STORE) + ".vhd_transactions") / "205fba82de114df797fe0dae6f1ae222" / "journal.json"
PACKAGE_ROOT = Path(
    "/home/domino/reny28/Projects/ShortProject/VisiumHD_pipeline_test/"
    "VisiumHD_Pipeline_v5_Project_Center_20261009_human"
)
WORKER_LOG = BASE / "work/vhd/Project/BM0164135A_s1_A1/run01/reports/worker_transfer_assets.log"


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _small_file(path: Path, limit: int = 4 * 1024 * 1024):
    """Bounded read. Oversized files are reported, not partly represented as complete."""
    try:
        with path.open('rb') as handle:
            data = handle.read(limit + 1)
        if len(data) > limit:
            return None, {'path': str(path), 'status': 'over_size_limit', 'limit_bytes': limit}
        return data, {'path': str(path), 'status': 'read', 'bytes': len(data), 'sha256': _sha(data)}
    except Exception as exc:
        return None, {'path': str(path), 'status': 'read_error',
                      'error': f'{type(exc).__name__}: {exc}'}


def _path_status(path: Path) -> dict:
    """Metadata only. Never enumerate contents recursively or follow a final symlink."""
    import stat
    try:
        s = path.lstat()
        kind = ('symlink' if stat.S_ISLNK(s.st_mode) else
                'directory' if stat.S_ISDIR(s.st_mode) else
                'file' if stat.S_ISREG(s.st_mode) else 'other')
        return {'path': str(path), 'exists': True, 'kind': kind,
                'size_bytes': int(s.st_size), 'mtime_ns': int(s.st_mtime_ns)}
    except FileNotFoundError:
        return {'path': str(path), 'exists': False}
    except Exception as exc:
        return {'path': str(path), 'exists': None, 'error': f'{type(exc).__name__}: {exc}'}


def _journal_references(value, key='$', result=None, limit=80):
    """Inventory explicit absolute path values; relative paths are NOT resolved by guesswork."""
    result = [] if result is None else result
    if len(result) >= limit:
        return result
    if isinstance(value, dict):
        for k, v in value.items():
            if len(result) >= limit:
                break
            # Replacement destinations may be dictionary keys rather than values.
            if isinstance(k, str) and k.startswith('/') and '\n' not in k:
                result.append({'json_location': key + ' [absolute key]', **_path_status(Path(k))})
            _journal_references(v, f'{key}.{k}', result, limit)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            if len(result) >= limit:
                break
            _journal_references(v, f'{key}[{i}]', result, limit)
    elif isinstance(value, str) and value.startswith('/') and '\n' not in value and len(value) < 4096:
        result.append({'json_location': key, **_path_status(Path(value))})
    return result[:limit]


def _definitions(text: str, filename: str) -> list[dict]:
    """Find definitions with relevant names by AST, without importing or executing source."""
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return [{'file': filename, 'parse_error': str(exc)}]
    results = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and any(
            word in node.name.lower() for word in ('recover', 'rollback', 'roll_back', 'resume', 'repair')
        ):
            results.append({'file': filename, 'line': node.lineno, 'name': node.name,
                            'signature_arguments': ast.unparse(node.args),
                            'docstring': ast.get_docstring(node)})
    return results


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def collect_transaction_evidence(
    journal=JOURNAL, package_root=PACKAGE_ROOT, worker_log=WORKER_LOG,
    output_parent=None, controller=None, sample=SAMPLE,
) -> Path:
    """Collect raw journal bytes, source code and status metadata into a NEW ZIP.

    Source paths are read only. No store/transaction recovery decision is made.
    Optional controller.snapshot() is used only for a read of its current records.
    """
    journal, package_root, worker_log = map(Path, (journal, package_root, worker_log))
    transaction_root = journal.parent.parent
    suffix = '.vhd_transactions'
    if not transaction_root.name.endswith(suffix):
        raise ValueError('Expected a journal under <store>.vhd_transactions/<id>/journal.json.')
    store = transaction_root.with_name(transaction_root.name[:-len(suffix)])
    if output_parent is None:
        output_parent = Path.cwd() / 'vhd_transaction_diagnostics'
    output_parent = Path(output_parent).expanduser()
    # Keep generated reports away from scientific data and managed input/source directories.
    prohibited = [store, transaction_root, package_root / 'vhd', package_root / 'docs']
    if any(_inside(output_parent, path) for path in prohibited) or any(
        part.lower() in {'inputs', 'engine'} for part in output_parent.resolve().parts
    ):
        raise ValueError('Choose a diagnostic output directory outside the store, transactions, '
                         'managed inputs/engine, and vhd source directory.')

    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    blobs: dict[str, bytes] = {}
    report = {
        'schema': 'vhd-unresolved-transaction-inspection-1',
        'inspection_time_utc': stamp, 'sample': sample, 'store': str(store),
        'journal': str(journal), 'package_root_used': str(package_root),
        'host': socket.gethostname(), 'kernel_pid_not_worker_pid': os.getpid(),
        'python': sys.executable, 'python_version': platform.python_version(),
        'recovery_executed': False, 'scientific_files_modified': False,
        'limitations': [
            'An inventory is not a validation of Zarr data or backup integrity.',
            'No worker-termination or exclusive-writer assertion is made.',
            'Only explicit absolute journal path values/keys are inspected; relative paths are not guessed.',
            'Source definitions are parsed as text; no recovery function is invoked.',
        ],
    }

    original, journal_info = _small_file(journal)
    report['journal_read'] = journal_info
    parsed = None
    if original is not None:
        blobs['journal.json'] = original
        try:
            parsed = json.loads(original.decode('utf-8-sig'))
            report['journal_state'] = parsed.get('state', '(no state key)') if isinstance(parsed, dict) else '(non-object JSON)'
            report['referenced_path_status'] = _journal_references(parsed)
        except Exception as exc:
            report['journal_parse_error'] = f'{type(exc).__name__}: {exc}'

    try:
        report['transaction_directory_entries'] = [_path_status(p) for p in
            sorted(journal.parent.iterdir(), key=lambda p: p.name)[:60]]
    except Exception as exc:
        report['transaction_directory_error'] = f'{type(exc).__name__}: {exc}'

    # Inventory all direct journal siblings, so one unresolved transaction is not
    # mistaken for the only unresolved transaction. No backup data is opened.
    siblings = []
    try:
        for i, path in enumerate(sorted(transaction_root.glob('*/journal.json'))):
            if i >= 200:
                siblings.append({'status': 'remaining_journals_not_inventoried', 'limit': 200})
                break
            data, info = _small_file(path)
            if data is not None:
                try:
                    body = json.loads(data.decode('utf-8-sig'))
                    state = body.get('state') if isinstance(body, dict) else None
                    info['state'] = state
                    info['terminal_under_reported_writer_rule'] = state in ('committed', 'rolled_back')
                except Exception as exc:
                    info['parse_error'] = f'{type(exc).__name__}: {exc}'
                blobs[f'sibling_journals/{path.parent.name}/journal.json'] = data
            siblings.append(info)
    except Exception as exc:
        report['sibling_inventory_error'] = f'{type(exc).__name__}: {exc}'
    report['journal_inventory'] = siblings

    fixed_sources = [
        'vhd/persistence/transaction.py', 'vhd/persistence/spatial.py',
        'vhd/master.py', 'vhd/core.py', 'vhd/annotations/workflow.py',
        'vhd/annotations/visual_approval.py', 'vhd/control/runner.py',
        'vhd/control/manifest.py', 'vhd/compute/launch.py',
        'vhd/center/controller.py', 'vhd/center/ui.py', 'docs/STORAGE_POLICY.md',
    ]
    try:
        extras = [str(p.relative_to(package_root)) for p in
                  sorted((package_root/'vhd/persistence').glob('*.py'))[:30]]
    except OSError:
        extras = []
    sources, recovery_definitions = [], []
    for rel in dict.fromkeys(fixed_sources + extras):
        data, info = _small_file(package_root / rel, limit=2*1024*1024)
        info['archive_member'] = 'sources/' + rel
        sources.append(info)
        if data is not None:
            blobs[info['archive_member']] = data
            if rel.endswith('.py'):
                recovery_definitions.extend(_definitions(data.decode('utf-8-sig', errors='replace'), rel))
    report['sources'] = sources
    report['recovery_definitions_NOT_EXECUTED'] = recovery_definitions

    try:
        with worker_log.open('rb') as handle:
            handle.seek(0, 2)
            size = handle.tell()
            offset = max(0, size - 512*1024)
            handle.seek(offset)
            data = handle.read()
        cleaned = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', data.decode('utf-8', errors='replace'))
        blobs['worker_transfer_assets_log_tail.txt'] = cleaned.encode('utf-8')
        report['log_tail'] = {'path': str(worker_log), 'start_byte': offset,
                              'original_size_bytes': size, 'tail_only': offset > 0}
    except Exception as exc:
        report['log_tail'] = {'path': str(worker_log), 'error': f'{type(exc).__name__}: {exc}'}

    if controller is not None:
        try:
            snap = controller.snapshot()
            report['controller_excerpt'] = {
                'revision': snap.get('revision'),
                'selected_sample_jobs': snap.get('jobs', {}).get(sample, {}),
            }
        except Exception as exc:
            report['controller_read_error'] = f'{type(exc).__name__}: {exc}'

    # Detect changes during this inspection; this does not replace a writer lock.
    after, after_info = _small_file(journal)
    report['journal_unchanged_during_inspection'] = (
        original is not None and after is not None and _sha(original) == _sha(after)
    )
    report['journal_end_read'] = after_info
    blobs['inspection_report.json'] = json.dumps(report, indent=2, default=str).encode('utf-8')
    blobs['README.txt'] = (
        'Diagnostic evidence only. NO recovery was executed.\n'
        'Do not remove/rename the original transaction journal or its backup/staging files.\n'
        'Do not edit a state to committed or rolled_back just to bypass the writer guard.\n'
        'Review the raw journal, installed transaction.py/spatial.py, referenced paths,\n'
        'and worker log before selecting an actual recovery operation.\n'
        'This archive includes project paths and source code; share it only as intended.\n'
    ).encode('utf-8')

    output_parent.mkdir(parents=True, exist_ok=True)
    output_dir = Path(tempfile.mkdtemp(prefix='inspection_' + stamp + '_', dir=output_parent))
    bundle = output_dir / 'VHD_transaction_evidence.zip'
    with zipfile.ZipFile(bundle, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in blobs.items():
            archive.writestr(name, data)
    (output_dir / 'inspection_report.json').write_bytes(blobs['inspection_report.json'])

    print('Transaction:', journal.parent.name)
    print('Journal state:', report.get('journal_state', report.get('journal_parse_error', journal_info['status'])))
    print('Journal unchanged during inspection:', report['journal_unchanged_during_inspection'])
    if parsed is not None:
        formatted = json.dumps(parsed, indent=2, default=str)
        print('\nJOURNAL CONTENT (full bytes retained in ZIP):')
        print(formatted[:24000])
        if len(formatted) > 24000:
            print('[Notebook display truncated; full journal is in ZIP.]')
    print('\nJournal inventory:')
    for item in siblings:
        print(item.get('path', ''), '| state:', item.get('state'), '| read:', item.get('status'))
    print('\nRecovery-related definitions found (not executed):')
    print(json.dumps(recovery_definitions, indent=2, default=str))
    missing = [r['path'] for r in sources if r['status'] != 'read']
    if missing:
        print('\nSource files missing/unreadable (listed, not substituted):')
        print('\n'.join(missing))
    print('\nDiagnostic ZIP:', bundle)
    print('This report does not certify the worker stopped or the data are consistent.')
    print('No jobs, lock changes, journal changes, replay, rollback, or store writes were performed.')
    return bundle


if __name__ == '__main__':
    VHD_TRANSACTION_EVIDENCE = collect_transaction_evidence(
        controller=globals().get('pc')
    )
