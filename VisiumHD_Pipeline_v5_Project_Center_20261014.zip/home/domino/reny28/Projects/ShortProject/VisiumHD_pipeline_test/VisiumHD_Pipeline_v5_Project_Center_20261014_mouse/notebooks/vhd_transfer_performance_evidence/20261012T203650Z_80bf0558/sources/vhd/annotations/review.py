"""Explicit user-selected approvals with source/transform revalidation and CSV backup."""
from pathlib import Path
import csv,json,shutil,uuid
from .workflow import read_assets,alignment_signature
from ..control.manifest import row_config,sample_layout


def approve_assets(project,selections,execute=False):
    """selections={sample_key:[asset_ids]}; empty means no approval, not all."""
    if not selections:return {'status':'nothing_selected'}
    changes={};plans=[]
    for sample,ids in selections.items():
        if isinstance(ids,str):raise ValueError('Use a list of explicit asset IDs.')
        rows=[r for r in project['rows'] if r['sample_key']==sample]
        if len(rows)!=1:raise KeyError(sample)
        row=rows[0];cfg,spec=row_config(project,row);paths=sample_layout(project,row)
        geom_file=paths['work']/'geometry.json'
        geometry=json.loads(geom_file.read_text()) if geom_file.exists() else json.loads((paths['work']/'cell_geometry.json').read_text())['geometry']
        sources={a['asset_id']:a for a in read_assets(row['assets_manifest'],row['dataset_id'],row['sample_id'])}
        for name in ids:
            if name not in sources:raise KeyError(name)
            from .alignment import resolve_alignment
            a=resolve_alignment(sources[name],geometry)
            if a['role']=='discover':raise ValueError('Use approve_choices for per-category discovery sources.')
            if a['role']=='reference_only':raise ValueError('Reference-only sources cannot be approved for computation.')
            receipt=json.loads((paths['report']/f'asset_{name}.json').read_text())
            sig=alignment_signature(a,geometry)
            if receipt.get('alignment_signature')!=sig or receipt.get('status')!='stored':raise RuntimeError('Source changed/not imported; regenerate previews before approval.')
            changes.setdefault(Path(row['assets_manifest']),{})[(row['dataset_id'],row['sample_id'],name)]=sig
            plans.append({'sample':sample,'asset':name,'signature':sig})
    if execute:
        for path,updates in changes.items():
            with path.open(newline='',encoding='utf-8-sig') as f:r=csv.DictReader(f);headers=r.fieldnames;rows=list(r)
            for r in rows:
                keys=[k for k in updates if k[1:]==(r['sample_id'],r['asset_id']) and (not r.get('dataset_id') or r['dataset_id']==k[0])]
                if len(keys)>1:raise ValueError('Ambiguous asset identity.')
                if keys:r['reviewed_signature']=updates[keys[0]]
            backup=path.with_name(path.name+'.before_approval_'+uuid.uuid4().hex[:8]+'.txt');shutil.copy2(path,backup)
            temp=path.with_name(path.name+'.approval_'+uuid.uuid4().hex+'.tmp')
            with temp.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(rows)
            temp.replace(path);print('Approval backup:',backup)
    return {'execute':execute,'approvals':plans}
