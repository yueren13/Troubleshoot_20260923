"""Read-only installation inventory. Does not run data processing or install packages."""
from __future__ import annotations
import importlib.util, importlib.metadata, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))


def check():
    names=['numpy','pandas','scipy','psutil','ipywidgets','IPython','nbformat','pytest',
           'anndata','spatialdata','h5py','pyarrow','tifffile','geopandas','shapely','defusedxml',
           'scanpy','igraph','stardist','scvi','rapids_singlecell']
    modules={}
    for name in names:
        spec=importlib.util.find_spec(name)
        try:version=importlib.metadata.version({'igraph':'igraph','IPython':'ipython'}.get(name,name))
        except importlib.metadata.PackageNotFoundError:version=None
        modules[name]={'import_location':None if spec is None else spec.origin,'distribution_version':version}
    from vhd.center.resources import detect_resources
    return {'python':sys.executable,'pipeline_root':str(ROOT),'center_version':'0.5.0rc1',
            'modules':modules,'hardware':detect_resources(),
            'frontend_callback_tested':False,'scientific_execution_tested':False,
            'next':'Open 00_Project_Center.ipynb. Test browser connection there. Missing optional scientific modules matter only for their selected worker roles.'}


if __name__=='__main__':print(json.dumps(check(),indent=2))
