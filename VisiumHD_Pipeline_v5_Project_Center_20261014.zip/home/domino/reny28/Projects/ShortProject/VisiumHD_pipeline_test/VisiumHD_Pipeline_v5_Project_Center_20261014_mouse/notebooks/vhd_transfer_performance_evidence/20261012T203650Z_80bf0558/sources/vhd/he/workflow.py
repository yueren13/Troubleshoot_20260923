"""Separate fixed image measurement, bin-center sampling, and explicit QC classification."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from .fixed import extract_he_concentrations_reference,fixed_scale_he_tissue_score,sample_field,HE_REFERENCE
from ..annotations.raster import open_raster
from ..core import sample_paths,file_stamp,digest,dump_json,reusable,completed,KEEP_CLASSES,affine


def measure(cfg,spec):
    from ..io import h5_metadata
    from ..control.storage import free_space_gate
    from .source import resolve_he_source
    s=cfg['he_score']
    path,matrix,source_resolution=resolve_he_source(cfg,spec)
    p=sample_paths(cfg,spec)
    if s.get('white_balance',False):raise ValueError('Estimate RGB Io ONCE, record it in he_score.Io, then use white_balance=False. Per-tile estimation is prohibited.')
    folder=p['work']/'he_fixed';folder.mkdir(exist_ok=True)
    names=('H_raw','E_raw','H_fixed','E_fixed','he_tissue_score');maps={n:folder/(n+'.npy') for n in names};meta=folder/'measurement.json';binfile=p['work']/'bins_he.parquet'
    sig=digest({'source':file_stamp(path,full_hash=True),'matrix':matrix,'settings':s,'algorithm':'fixed-he-v3'})
    if reusable(folder/'complete.json',sig,[*maps.values(),meta,binfile]):return json.loads(meta.read_text())
    size=int(s.get('tile_size',512))
    if size<1:raise ValueError('Positive H&E tile size required.')
    with open_raster(path,s.get('axes','yxc')) as image:
        h,w=image.shape;free_space_gate(folder,h*w*4*len(names),cfg['storage_policy'].get('min_free_tmp_gib',20))
        arrays={n:np.lib.format.open_memmap(f,mode='w+',dtype=np.float32,shape=(h,w)) for n,f in maps.items()}
        for y in range(0,h,size):
            for x in range(0,w,size):
                H,E,io=extract_he_concentrations_reference(image[y:y+size,x:x+size],Io=s.get('Io',255),channel_axis=-1,
                    intensity_range=s.get('intensity_range',[0,255]),alpha=s.get('alpha','white'),reference=s.get('reference',HE_REFERENCE),lstsq_batch=s.get('lstsq_batch',200000))
                score,hn,en=fixed_scale_he_tissue_score(H,E,**{k:s[k] for k in ('h_limit','e_limit','h_weight','e_weight','method')})
                for n,v in zip(names,(H,E,hn,en,score)):arrays[n][y:y+len(v),x:x+v.shape[1]]=v
        for a in arrays.values():a.flush()
    obs,_=h5_metadata(p['bins']);xy=obs[['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy();df=pd.DataFrame(index=obs.index)
    for n in ('he_tissue_score','H_fixed','E_fixed'):
        value,inside,valid=sample_field(arrays[n],xy,source_to_fullres=matrix,interpolation=s.get('interpolation','linear'),chunk_size=s.get('bin_chunk_size',250000))
        df[n]=value;df[n+'_in_bounds']=inside;df[n+'_valid']=valid
    df.to_parquet(binfile)
    report={'signature':sig,'source':str(path),'source_to_fullres':matrix.tolist(),'source_resolution':source_resolution,'Io_used':io.tolist(),'parameters':s,'maps':{n:str(f) for n,f in maps.items()},'measurement':'image score FIRST, then bin-center sample; not area mean or probability'}
    dump_json(report,meta)
    import matplotlib.pyplot as plt
    step=max(1,int(np.ceil(max(h,w)/1800)))
    for name in ('H_fixed','E_fixed','he_tissue_score'):
        fig,ax=plt.subplots(figsize=(9,7));im=ax.imshow(arrays[name][::step,::step],vmin=0,vmax=1);fig.colorbar(im,ax=ax)
        ax.set_title(f"{spec['sample']}: {name}, fixed 0–1 scale");fig.savefig(p['report']/(name+'_fixed.png'),dpi=cfg['plots']['dpi'],bbox_inches='tight');plt.close(fig)
    completed(folder/'complete.json',sig,[*maps.values(),meta,binfile]);return report


def classify(obs,measurement,settings):
    if not obs.index.equals(measurement.index):raise ValueError('Bin identities/order do not match score metadata.')
    cutoff=settings.get('tissue_score_threshold');txcut=settings.get('transcript_threshold')
    if cutoff is None or txcut is None:raise ValueError('Set explicit tissue_score_threshold and transcript_threshold. Historical Step03 cutoffs were not provided and are not guessed.')
    if not np.isfinite([cutoff,txcut]).all() or not 0<=cutoff<=1 or txcut<0:raise ValueError('Invalid classification thresholds.')
    out=obs.copy()
    for col in measurement:out[col]=measurement[col]
    tx=pd.to_numeric(out[settings.get('transcript_metric','total_counts')],errors='raise').to_numpy(float)
    transform=settings.get('transcript_transform','identity')
    if transform=='log1p':tx=np.log1p(tx)
    elif transform!='identity':raise ValueError('transcript_transform must be identity or log1p.')
    valid=measurement.he_tissue_score_valid.to_numpy(bool)&np.isfinite(tx);tissue=measurement.he_tissue_score.to_numpy()>=cutoff
    classes=np.char.add(np.where(tissue,'tissue-high_','tissue-low_'),np.where(tx>=txcut,'transcript-high','transcript-low')).astype(object);classes[~valid]='unassessed'
    out['qc_class']=pd.Categorical(classes);out['qc_class_raw']=out.qc_class;out['qc_keep']=out.qc_class.isin(KEEP_CLASSES)
    out['qc_method']='fixed_reference_he_with_explicit_thresholds';return out


def classify_stage(cfg,spec):
    from ..io import h5_metadata
    from ..plots import standard_qc_plots,scatter_categorical
    from ..images import thumbnail
    from ..core import transform_xy
    p=sample_paths(cfg,spec);settings=cfg['bin_qc'];score=p['work']/'bins_he.parquet';norm=p['work']/'he_normalization.json'
    sig=digest({'bins':file_stamp(p['bins']),'score':file_stamp(score),'settings':settings})
    if reusable(p['work']/'02_qc_complete.json',sig,[p['bin_obs'],norm]):return
    obs,_=h5_metadata(p['bins']);out=classify(obs,pd.read_parquet(score),settings)
    out.to_parquet(p['bin_obs']);dump_json({},norm)
    standard_qc_plots(out,p['report'],'bins',cfg['plots']['dpi'])
    geo=json.loads(p['geometry'].read_text());info=geo['image'];xy=transform_xy(out[['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy(),geo['tenx_to_image'])
    scatter_categorical(xy,out.qc_class,'Fixed H&E bin QC',p['report']/'bins_qc_class.png',thumb=thumbnail(info,cfg['plots']['thumbnail_max_side']),image_size=(info['width'],info['height']),dpi=cfg['plots']['dpi'])
    dump_json({'settings':settings,'class_counts':{str(k):int(v) for k,v in out.qc_class.value_counts().items()},'historical_step03_equivalence':False},p['report']/'bin_qc_report.json')
    completed(p['work']/'02_qc_complete.json',sig,[p['bin_obs'],norm])
