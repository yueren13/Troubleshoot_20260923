"""Exact source-pixel overlap summaries for affine bin footprints.

Pixel values are piecewise constant on [x-.5,x+.5] x [y-.5,y+.5].
mean/median are overlap-weighted. sum is the fractional-source-pixel sum,
NOT a count of molecules or a sum of duplicated upsampled intensities.
Reads are bounded tiles; candidate intersections are bounded batches.
"""
from __future__ import annotations
import numpy as np
from ..core import affine

METHODS=('mean','median','sum','max','min')


def _read_pairs(field, ys, xs, tile_size):
    """Read pairs through the slice-only Raster interface, not a full image."""
    out=np.empty(len(xs),float)
    width=field.shape[1];keys=(ys//tile_size)*((width+tile_size-1)//tile_size)+xs//tile_size
    order=np.argsort(keys,kind='stable');edges=np.r_[0,np.flatnonzero(np.diff(keys[order]))+1,len(order)]
    for l,r in zip(edges[:-1],edges[1:]):
        i=order[l:r];x0=int(xs[i[0]]//tile_size)*tile_size;y0=int(ys[i[0]]//tile_size)*tile_size
        patch=np.asarray(field[y0:min(y0+tile_size,field.shape[0]),x0:min(x0+tile_size,width)],float)
        if patch.ndim!=2:raise ValueError('A single signal channel must be selected.')
        out[i]=patch[ys[i]-y0,xs[i]-x0]
    return out


def summarize_footprints(field, xy_fullres, *, source_to_fullres, bin_basis_fullres,
                         methods=('mean',), min_valid_fraction=0., chunk_size=20000,
                         max_pairs=1000000, max_pixels_per_bin=4096, tile_size=512,
                         coverage_source=None):
    """Return metric arrays plus in-bounds/valid coverage for the actual bins.

    bin_basis_fullres is the two linear columns of the canonical grid affine;
    not an assumed axis-aligned square. Arbitrary nonsingular affine transforms
    use exact vectorized polygon intersections; aligned rectangles use arithmetic.
    """
    methods=list(methods)
    if not methods or set(methods)-set(METHODS) or len(set(methods))!=len(methods):raise ValueError('Choose unique mean/median/sum/max/min methods.')
    if not 0<=min_valid_fraction<=1:raise ValueError('min_valid_fraction must be in [0,1].')
    if min(chunk_size,max_pairs,max_pixels_per_bin,tile_size)<1:raise ValueError('Chunk/pixel limits must be positive.')
    if len(field.shape)!=2:raise ValueError('A single 2D channel is required.')
    xy=np.asarray(xy_fullres,float);basis=np.asarray(bin_basis_fullres,float)
    if xy.ndim!=2 or xy.shape[1]!=2 or basis.shape!=(2,2) or not np.isfinite(basis).all():raise ValueError('Invalid coordinate array or 2x2 bin basis.')
    inv=np.linalg.inv(affine(source_to_fullres));b=inv[:2,:2]@basis
    area=abs(np.linalg.det(b))
    if not np.isfinite(area) or area<=1e-15:raise ValueError('Degenerate footprint.')
    offsets=np.array([[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]])@b.T
    lo=offsets.min(axis=0);hi=offsets.max(axis=0)
    nx=int(np.ceil(hi[0]-lo[0]))+2;ny=int(np.ceil(hi[1]-lo[1]))+2;k=nx*ny
    if k>max_pixels_per_bin:raise ValueError(f'{k} candidate pixels/bin exceeds max_pixels_per_bin={max_pixels_per_bin}; inspect scale before increasing the explicit limit.')
    n=len(xy);result={m:np.full(n,np.nan,float) for m in methods}
    result.update(in_bounds_fraction=np.zeros(n),valid_fraction=np.zeros(n),n_valid_pixels=np.zeros(n,np.int32),valid=np.zeros(n,bool))
    rectangular=((abs(b[0,1])+abs(b[1,0])<1e-10) or (abs(b[0,0])+abs(b[1,1])<1e-10)) and coverage_source is None
    dy,dx=np.mgrid[0:ny,0:nx];dx=dx.ravel();dy=dy.ravel()
    batch=max(1,min(int(chunk_size),int(max_pairs)//k))
    height,width=field.shape
    for start in range(0,n,batch):
        stop=min(n,start+batch);uv=xy[start:stop]@inv[:2,:2].T+inv[:2,2];finite=np.isfinite(uv).all(axis=1)
        good_ids=np.flatnonzero(finite)
        if not len(good_ids):continue
        q=uv[finite];bblo=q+lo;bbhi=q+hi
        # First pixel with strictly positive possible intersection; zero weights
        # on boundaries are removed explicitly below.
        xstart=np.floor(bblo[:,0]+.5).astype(np.int64);ystart=np.floor(bblo[:,1]+.5).astype(np.int64)
        xx=xstart[:,None]+dx;yy=ystart[:,None]+dy
        bounds=(xx>=0)&(xx<width)&(yy>=0)&(yy<height)
        if rectangular:
            weights=np.maximum(0,np.minimum(bbhi[:,0,None],xx+.5)-np.maximum(bblo[:,0,None],xx-.5))*np.maximum(0,np.minimum(bbhi[:,1,None],yy+.5)-np.maximum(bblo[:,1,None],yy-.5))
        else:
            import shapely
            footprints=shapely.polygons(q[:,None,:]+offsets[None,:,:])
            boxes=shapely.box(xx-.5,yy-.5,xx+.5,yy+.5)
            intersections=shapely.intersection(footprints[:,None],boxes)
            if coverage_source is not None:intersections=shapely.intersection(intersections,coverage_source)
            weights=shapely.area(intersections)
        weights=np.where(bounds&(weights>area*1e-12),weights,0.)
        active=weights>0;values=np.full(weights.shape,np.nan)
        if active.any():values[active]=_read_pairs(field,yy[active],xx[active],int(tile_size))
        if np.isinf(values).any():raise ValueError('Infinite measured image values are not valid signal.')
        vw=np.where(np.isfinite(values),weights,0);den=vw.sum(axis=1)
        ids=start+good_ids;result['in_bounds_fraction'][ids]=np.clip(weights.sum(axis=1)/area,0,1)
        result['valid_fraction'][ids]=np.clip(den/area,0,1);result['n_valid_pixels'][ids]=(vw>0).sum(axis=1)
        keep=(den>area*1e-12)&(den/area+1e-12>=min_valid_fraction);result['valid'][ids]=keep
        totals=(np.where(vw>0,values,0)*vw).sum(axis=1)
        for method in methods:
            if method=='sum':v=totals
            elif method=='mean':v=np.divide(totals,den,out=np.full(len(q),np.nan),where=den>0)
            elif method=='max':v=np.where(vw>0,values,-np.inf).max(axis=1)
            elif method=='min':v=np.where(vw>0,values,np.inf).min(axis=1)
            else:
                order=np.argsort(np.where(vw>0,values,np.inf),axis=1,kind='stable')
                val=np.take_along_axis(values,order,axis=1);ww=np.take_along_axis(vw,order,axis=1);cum=np.cumsum(ww,axis=1)
                mid=den/2;index=(cum>=mid[:,None]).argmax(axis=1);row=np.arange(len(q));v=val[row,index]
                # A half-weight tie uses the midpoint of the two boundary values;
                # equal pixel weights therefore match the ordinary median.
                tied=(den>0)&np.isclose(cum[row,index],mid,atol=area*1e-12,rtol=1e-10)
                nxt=np.minimum(index+1,val.shape[1]-1)
                tied &= (nxt>index)&(ww[row,nxt]>0)
                v=np.where(tied,(v+val[row,nxt])/2,v)
            result[method][ids]=np.where(keep,v,np.nan)
    result['in_bounds']=result['in_bounds_fraction']>0
    return result
