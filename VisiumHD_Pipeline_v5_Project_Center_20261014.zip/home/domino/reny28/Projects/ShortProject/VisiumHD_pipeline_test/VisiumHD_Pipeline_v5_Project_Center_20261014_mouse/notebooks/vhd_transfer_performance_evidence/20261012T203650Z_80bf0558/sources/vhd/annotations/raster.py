"""Lazy TIFF/NPY/Zarr access; explicit axes and channels. PNG is a small in-memory input."""
from contextlib import contextmanager
from pathlib import Path
import numpy as np


class Raster:
    def __init__(self,arr,axes,channel):
        if axes not in ('yx','yxc','cyx') or not hasattr(arr,'shape') or len(arr.shape)!=len(axes):raise ValueError('Explicit axes must identify a single yx/yxc/cyx ARRAY, not a pyramid/group.')
        self.arr=arr;self.axes=axes;self.channel=channel;self.shape=(arr.shape[axes.index('y')],arr.shape[axes.index('x')]);self.dtype=arr.dtype
        if channel is not None and ('c' not in axes or not 0<=int(channel)<arr.shape[axes.index('c')]):raise ValueError('Invalid channel index.')
    def __getitem__(self,key):
        y,x=key;sl=[slice(None)]*len(self.axes);sl[self.axes.index('y')]=y;sl[self.axes.index('x')]=x
        if 'c' in self.axes and self.channel is not None:sl[self.axes.index('c')]=int(self.channel)
        a=np.asarray(self.arr[tuple(sl)])
        return np.moveaxis(a,0,-1) if self.axes=='cyx' and self.channel is None else a


@contextmanager
def open_raster(path,axes,channel=None):
    p=Path(path);resource=None
    try:
        if p.suffix.lower()=='.npy':arr=np.load(p,mmap_mode='r',allow_pickle=False)
        elif p.suffix.lower() in ('.tif','.tiff'):
            import tifffile
            try:
                arr=tifffile.memmap(p,mode='r')
            except ValueError:
                import zarr
                resource=tifffile.imread(p,aszarr=True);arr=zarr.open(resource,mode='r')
        elif p.is_dir():
            import zarr
            arr=zarr.open(str(p),mode='r')
        else:
            from PIL import Image
            with Image.open(p) as im:arr=np.asarray(im)
        yield Raster(arr,axes,channel)
    finally:
        if resource is not None:resource.close()


def _tile(path,axes,channel,y,x,h,w):
    with open_raster(path,axes,channel) as image:
        a=image[y:y+h,x:x+w]
        if a.ndim!=2:raise ValueError('Scalar image requires a selected channel.')
        return a[None,...]


def spatial_image(path,axes,channel,index_to_fullres,channel_name,tile_size=512):
    import dask.array as da
    from dask import delayed
    from spatialdata.models import Image2DModel
    from spatialdata.transformations import Identity,Affine,set_transformation
    from ..core import affine
    with open_raster(path,axes,channel) as image:h,w=image.shape;dtype=image.dtype
    rows=[]
    for y in range(0,h,tile_size):
        chunks=[]
        for x in range(0,w,tile_size):
            hh,ww=min(h-y,tile_size),min(w-x,tile_size)
            chunks.append(da.from_delayed(delayed(_tile)(str(path),axes,channel,y,x,hh,ww),shape=(1,hh,ww),dtype=dtype))
        rows.append(da.concatenate(chunks,axis=2))
    element=Image2DModel.parse(da.concatenate(rows,axis=1),dims=('c','y','x'),c_coords=[channel_name],transformations={'fullres':Identity()})
    # Account explicitly for the parser's center-coordinate convention (e.g. 0 vs 0.5).
    first_x=float(element.coords['x'][0]);first_y=float(element.coords['y'][0])
    sx=float(element.coords['x'][1]-element.coords['x'][0]) if w>1 else 1.
    sy=float(element.coords['y'][1]-element.coords['y'][0]) if h>1 else 1.
    coord_to_index=np.array([[1/sx,0,-first_x/sx],[0,1/sy,-first_y/sy],[0,0,1.]])
    set_transformation(element,Affine(affine(index_to_fullres)@coord_to_index,input_axes=('x','y'),output_axes=('x','y')),to_coordinate_system='fullres')
    return element


def validate_signal_encoding(asset,tile_size=512):
    """Inspect ALL native pixels tile-wise; preserve raw values in stored image."""
    from .workflow import signal_values
    with open_raster(asset['path'],asset['axes'],asset['channel']) as field:
        h,w=field.shape
        for y in range(0,h,tile_size):
            for x in range(0,w,tile_size):
                block=field[y:y+tile_size,x:x+tile_size]
                if block.ndim!=2:raise ValueError('A scalar signal needs a single explicit channel.')
                signal_values(block,asset)
    return {'shape_yx':[h,w],'signal_type':asset.get('signal_type','continuous')}
