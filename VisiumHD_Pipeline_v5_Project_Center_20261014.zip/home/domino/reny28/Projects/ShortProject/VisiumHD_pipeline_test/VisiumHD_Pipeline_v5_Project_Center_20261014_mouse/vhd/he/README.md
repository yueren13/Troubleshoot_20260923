# he

Fixed quantitative H&E versus explicitly separate display compatibility.

See ../../docs/START_HERE.md and ../../docs/IMPLEMENTATION_STATUS.md. Source review and CPU tests are not target-environment validation.
