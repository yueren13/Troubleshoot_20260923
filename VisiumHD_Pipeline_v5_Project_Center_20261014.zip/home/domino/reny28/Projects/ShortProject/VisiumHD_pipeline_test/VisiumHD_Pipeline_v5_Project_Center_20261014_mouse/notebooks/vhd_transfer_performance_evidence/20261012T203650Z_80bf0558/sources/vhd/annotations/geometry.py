"""Source-preserving ImageScope polygons and fresh bin-center memberships."""
from __future__ import annotations
import numpy as np
import pandas as pd
import geopandas as gpd
import shapely
from shapely.geometry import Polygon
from ..core import affine


def read_imagescope_annotation_xml(path,um_per_px_x=None,um_per_px_y=None,dissolve_by_annotation=True,*,repair_invalid=False):
    from defusedxml import ElementTree as ET
    if (um_per_px_x is None)!=(um_per_px_y is None):raise ValueError('Supply both pixel sizes or neither.')
    scale=np.ones(2) if um_per_px_x is None else np.array([um_per_px_x,um_per_px_y],float)
    if not np.isfinite(scale).all() or (scale<=0).any():raise ValueError('Pixel sizes must be finite and positive.')
    root=ET.parse(path).getroot()
    for el in root.iter():el.tag=el.tag.rsplit('}',1)[-1]
    if root.tag not in ('Annotations','Annotation'):raise ValueError('Unsupported annotation XML root. Expected ImageScope Annotations/Annotation; file extension alone is not a format.')
    if not list(root.iter('Annotation')):raise ValueError('No ImageScope Annotation elements found; unsupported or empty source.')
    rows=[];audit=[]
    for ai,a in enumerate(root.iter('Annotation')):
        positive=[];negative=[]
        for ri,r in enumerate(a.findall('./Regions/Region')):
            v=r.find('Vertices')
            if v is None:raise ValueError(f'Annotation {ai}, region {ri}: no vertices.')
            vs=list(v.findall('V')) or list(v.findall('Vertex'))
            xy=np.asarray([[float(x.get('X')),float(x.get('Y'))] for x in vs])
            if xy.ndim!=2 or xy.shape[1]!=2 or len(xy)<3 or not np.isfinite(xy).all():raise ValueError('Malformed polygon vertices.')
            poly=Polygon(xy*scale)
            if not poly.is_valid:
                if not repair_invalid:raise ValueError('Invalid source polygon. Geometry repair requires explicit approval.')
                old=poly.area;poly=shapely.make_valid(poly)
                if poly.geom_type not in ('Polygon','MultiPolygon'):raise ValueError('Repair produced nonpolygon components; inspect manually.')
                audit.append({'annotation':ai,'region':ri,'repair':'make_valid','area_before':old,'area_after':poly.area})
            if poly.is_empty or poly.area<=0:raise ValueError('Degenerate polygon is not silently dropped.')
            neg=r.get('NegativeROA','0').lower() in ('1','true','t','yes')
            (negative if neg else positive).append(poly)
            if not dissolve_by_annotation:
                rows.append({'name':a.get('Name','unnamed'),'annotation_id':str(a.get('Id',ai)),
                  'region_id':str(r.get('Id',ri)),'neg':neg,'visible':a.get('Visible','True'),
                  'linecolor':a.get('LineColor',''),'geometry':poly})
        if dissolve_by_annotation:
            if negative and not positive:raise ValueError('Negative regions without a positive parent region.')
            if not positive:continue
            geom=shapely.union_all(positive)
            if negative:geom=geom.difference(shapely.union_all(negative))
            geom=shapely.force_2d(geom)  # PRESERVE interiors; never rebuild Polygon(exterior).
            if not geom.is_empty:rows.append({'name':a.get('Name','unnamed'),'annotation_id':str(a.get('Id',ai)),
                   'visible':a.get('Visible','True'),'linecolor':a.get('LineColor',''),'geometry':geom})
    g=gpd.GeoDataFrame(rows if rows else {'name':[],'geometry':[]},geometry='geometry',crs=None)
    g.index=pd.Index([str(i) for i in range(len(g))]);g.attrs['repair_audit']=audit
    return g


def transform_polygons(g,matrix):
    from shapely.affinity import affine_transform
    a=affine(matrix);par=[a[0,0],a[0,1],a[1,0],a[1,1],a[0,2],a[1,2]]
    out=g.copy();out.crs=None;out.geometry=out.geometry.map(lambda x:affine_transform(x,par));return out


def membership(xy,polygon,chunk_size=250000):
    xy=np.asarray(xy,float)
    if xy.ndim!=2 or xy.shape[1]!=2 or chunk_size<1:raise ValueError('Invalid coordinates/chunk_size.')
    out=np.zeros(len(xy),bool)
    for start in range(0,len(xy),chunk_size):
        uv=xy[start:start+chunk_size];valid=np.isfinite(uv).all(axis=1);part=np.zeros(len(uv),bool)
        part[valid]=shapely.intersects_xy(polygon,uv[valid,0],uv[valid,1]);out[start:start+len(part)]=part
    return out


def classify_polygons(xy,g,*,category_column='name',categories=None,coverage=None,exhaustive=False,mode='membership'):
    """Always return fresh values. Positive-only coverage leaves outside unknown.

    Independent membership flags allow Tissue AND Necrosis. Categorical overlap
    between distinct labels is mixed, not dependent on polygon input ordering.
    Boundary points are included; fractions elsewhere are bin-center fractions.
    """
    xy=np.asarray(xy,float);names=g[category_column].astype(str)
    cats=list(categories) if categories is not None else sorted(names.unique())
    if len(cats)!=len(set(cats)) or set(names)-set(cats):raise ValueError('Duplicate or undeclared annotation categories.')
    hit=np.column_stack([membership(xy,shapely.union_all(g.geometry[names==c].to_numpy())) for c in cats]) if cats else np.zeros((len(xy),0),bool)
    assessed=(np.isfinite(xy).all(axis=1) if exhaustive else hit.any(axis=1)) if coverage is None else membership(xy,coverage)
    assessed &= np.isfinite(xy).all(axis=1);result=pd.DataFrame({'assessed':assessed})
    if mode=='membership':
        for i,c in enumerate(cats):
            values=pd.array(hit[:,i],dtype='boolean');values[~assessed]=pd.NA;result[c]=values
    elif mode=='categorical':
        values=np.full(len(xy),'unassigned',object);values[~assessed]='unassessed'
        for i,c in enumerate(cats):values[assessed&hit[:,i]]=c
        values[assessed&(hit.sum(axis=1)>1)]='mixed';result['class']=pd.Categorical(values)
    else:raise ValueError('mode must be membership or categorical.')
    return result
