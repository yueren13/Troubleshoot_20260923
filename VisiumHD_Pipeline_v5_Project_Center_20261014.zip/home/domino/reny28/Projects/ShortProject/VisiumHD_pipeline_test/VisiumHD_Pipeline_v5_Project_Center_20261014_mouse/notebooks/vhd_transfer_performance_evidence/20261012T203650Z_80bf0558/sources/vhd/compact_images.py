"""Explicit master-image policies. Display pixels never redefine fullres coordinates."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .core import affine, file_stamp, transform_xy


def compact_sources(cfg, spec):
    explicit = cfg['storage'].get('compact_images', {})
    if explicit:
        records = []
        for name in ('he_hires', 'he_lowres'):
            s = explicit.get(name)
            if not s or not s.get('path') or s.get('source_to_fullres') is None:
                raise ValueError(f'Explicit compact_images requires {name}: path and source_to_fullres.')
            records.append({'name':name,'path':str(Path(s['path'])),
                            'index_to_fullres':affine(s['source_to_fullres']).tolist()})
        return records
    outs = spec.get('outs') or spec.get('_row',{}).get('spaceranger_outs')
    if not outs:
        raise ValueError('Compact images need Space Ranger outs or storage.compact_images with explicit transforms. '
                         'Use image_policy=reference_only deliberately when no display images are available.')
    from .spaceranger_images import resolve_spaceranger_image
    records = []
    for suffix in ('hires', 'lowres'):
        selected = resolve_spaceranger_image(outs, suffix)
        records.append({
            'name': 'he_' + suffix,
            'path': selected['image_path'],
            'index_to_fullres': selected['index_to_fullres'],
            'scalefactors': file_stamp(selected['scalefactors_path']),
            'source_resolution': selected,
        })
    return records



def build_images(cfg, spec, geometry):
    from spatialdata.models import Image2DModel
    from .storage import set_fullres_transform
    from .images import lazy_rgb
    import dask.array as da
    from PIL import Image
    policy=cfg['storage'].get('image_policy','original') # old settings retain their explicit legacy behavior
    if policy not in ('compact','original','reference_only'):raise ValueError('image_policy: compact, original, reference_only.')
    record={'policy':policy,'elements':{},'original_reference':dict(geometry.get('image',{})),
            'tenx_to_original_image':geometry.get('tenx_to_image'),'self_contained_original':False}
    path=record['original_reference'].get('path')
    declared=spec.get('_row',{}).get('segmentation_image')
    if declared and declared!=path:
        record['original_reference']['resolved_read_path']=path
        record['original_reference']['path']=declared
    if policy=='compact' and cfg['storage'].get('include_normalized_he',False):raise ValueError('Compact mode does not embed a full-resolution display-normalized image. Keep include_normalized_he=false; fixed quantitative maps are separate.')
    if path and Path(path).is_file():record['original_reference']['file_identity']=file_stamp(path)
    if policy=='reference_only':return {},record
    images={}
    if policy=='original':
        if 'image' not in geometry:return images,record
        g=geometry['image'];matrix=np.linalg.inv(affine(geometry['tenx_to_image']))
        img=Image2DModel.parse(lazy_rgb(g,cfg['storage']['image_tile_size']),dims=('c','y','x'),
             c_coords=['r','g','b'],scale_factors=cfg['storage']['image_scale_factors'])
        images['he_original']=set_fullres_transform(img,matrix)
        record['elements']['he_original']={'shape_yx':[g['height'],g['width']],'index_to_fullres':matrix.tolist(),'source':file_stamp(g['path'])}
        record['self_contained_original']=True
    else:
        for source in compact_sources(cfg,spec):
            p=Path(source['path'])
            if not p.is_file():raise FileNotFoundError(p)
            with Image.open(p) as im:
                if im.mode not in ('RGB','RGBA'):raise ValueError(f'Expected RGB display image, got {im.mode}: {p}')
                rgb=np.asarray(im.convert('RGB')).copy()
            arr=da.from_array(np.moveaxis(rgb,-1,0),chunks=(3,512,512))
            img=Image2DModel.parse(arr,dims=('c','y','x'),c_coords=['r','g','b'])
            images[source['name']]=set_fullres_transform(img,source['index_to_fullres'])
            record['elements'][source['name']]={**source,'shape_yx':list(rgb.shape[:2]),'source':file_stamp(p,full_hash=True)}
    return images,record


def validate_images(sdata):
    from spatialdata.transformations import get_transformation
    from .storage import scale0
    rec=sdata.attrs.get('image_storage')
    if rec is None: # legacy master
        if 'he_original' not in sdata.images:raise ValueError('Missing legacy he_original.')
        geom=sdata.attrs['geometry'];rec={'elements':{'he_original':{
            'shape_yx':[geom['image']['height'],geom['image']['width']],
            'index_to_fullres':np.linalg.inv(affine(geom['tenx_to_image'])).tolist()}}}
    for name,info in rec['elements'].items():
        if name not in sdata.images:raise ValueError(f'Missing recorded image {name}.')
        img=scale0(sdata.images[name]);h,w=info['shape_yx']
        if (img.sizes['y'],img.sizes['x'])!=(h,w):raise ValueError(f'Image shape changed: {name}')
        native=[[float(img.coords['x'][0]),float(img.coords['y'][0])],
                [float(img.coords['x'][-1]),float(img.coords['y'][-1])]]
        matrix=get_transformation(sdata.images[name],to_coordinate_system='fullres').to_affine_matrix(input_axes=('x','y'),output_axes=('x','y'))
        if not np.allclose(transform_xy(native,matrix),transform_xy([[0,0],[w-1,h-1]],info['index_to_fullres']),atol=1e-6):
            raise ValueError(f'Image/fullres registration mismatch: {name}')
    if rec.get('policy')=='compact' and 'he_original' in sdata.images:raise ValueError('Compact master unexpectedly embeds original H&E.')
    return {'image_policy':rec.get('policy','legacy_original'),'validated_images':list(rec['elements'])}
