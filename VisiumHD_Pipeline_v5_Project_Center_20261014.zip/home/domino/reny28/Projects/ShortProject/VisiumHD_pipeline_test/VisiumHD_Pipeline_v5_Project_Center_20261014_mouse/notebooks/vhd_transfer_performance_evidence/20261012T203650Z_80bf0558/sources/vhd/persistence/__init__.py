"""Explicit master updates with retained recovery data; no mount management."""
from .spatial import persist_changes, update_table_metadata, refresh_metadata
from .transaction import recover_transaction
