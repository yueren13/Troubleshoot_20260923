"""Count-display transforms only. Never modify biological matrices or QC flags."""
import numpy as np


def transform(values,base=10):
    if base not in (10,2,'e'):raise ValueError('Count display base: 10, 2, e.')
    values=np.asarray(values,float)
    if np.any(np.isfinite(values)&(values<0)):raise ValueError('Count display requires nonnegative values.')
    return np.log1p(values)/(1. if base=='e' else np.log(base))


def ticks(maximum,base=10):
    maximum=float(maximum)
    if not np.isfinite(maximum) or maximum<0:raise ValueError('Invalid display maximum.')
    # Original units, independent of mathematical logarithm base.
    end=max(1,int(np.ceil(np.log10(max(maximum,1)))))
    values=np.r_[0.,10.**np.arange(1,end+1)]
    return transform(values,base),[f'{int(x):,}' for x in values]


def label_axis(ax,axis,maximum,label,base=10):
    locations,labels=ticks(maximum,base)
    getattr(ax,f'set_{axis}ticks')(locations,labels)
    getattr(ax,f'set_{axis}label')(f'{label} (original units; log{base}(1 + value) spacing)')
    getattr(ax,f'set_{axis}lim')(0,float(locations[-1]))
