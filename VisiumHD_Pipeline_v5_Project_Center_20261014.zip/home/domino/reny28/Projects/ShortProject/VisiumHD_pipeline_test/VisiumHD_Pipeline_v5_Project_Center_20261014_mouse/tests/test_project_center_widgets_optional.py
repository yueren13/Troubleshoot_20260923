"""Real Python widget construction and callbacks; still not a browser/comm transport test."""
import pytest
W=pytest.importorskip('ipywidgets',reason='ipywidgets unavailable; run in intended Jupyter kernel')
from pathlib import Path
from vhd.center import ProjectCenter
from vhd.center.ui import show_center,launch_setup


def descend(widget):
    yield widget
    for item in getattr(widget,'children',[]):yield from descend(item)


def test_actual_widget_construction_and_callback(tmp_path,monkeypatch):
    from test_visual_approval_bridge import setup
    s=setup.__wrapped__(tmp_path)
    c=ProjectCenter.import_config(s['manifest'],s['settings'],tmp_path/'center')
    monkeypatch.setattr('IPython.display.display',lambda *a,**k:None)
    app=show_center(c)
    target=next(w for w in descend(app) if isinstance(w,W.Button) and w.description=='Test browser connection')
    target.click()
    assert ProjectCenter.open(c.workspace).snapshot()['frontend_check']['status']=='python_callback_received'
    app.close()


def test_actual_setup_form_constructs_without_writes(tmp_path,monkeypatch):
    monkeypatch.setattr('IPython.display.display',lambda *a,**k:None)
    before=list(tmp_path.rglob('*'));form=launch_setup(tmp_path)
    assert list(tmp_path.rglob('*'))==before
    assert isinstance(form['form'],W.VBox)
    form['form'].close()
