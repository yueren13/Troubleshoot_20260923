"""One physical source, category-labelled previews; no expression is loaded."""
from __future__ import annotations
import re
import matplotlib.pyplot as plt
from ..core import sample_paths,affine
from ..images import thumbnail
from .geometry import transform_polygons
from .discovery import choice_key


def preview_categories(asset,cfg,spec,geometry):
    from .workflow import polygons
    p=sample_paths(cfg,spec);image=geometry['image'];thumb=thumbnail(image,cfg['plots']['thumbnail_max_side'])
    g=transform_polygons(polygons(asset),affine(geometry['tenx_to_image'])@affine(asset['source_to_fullres']))
    col=asset['category_column'];names=g[col].astype(str);files=[]
    for category in sorted(names.unique()):
        fig,ax=plt.subplots(figsize=(11,9));ax.imshow(thumb,extent=(0,image['width'],image['height'],0))
        subset=g.loc[names==category]
        if len(subset):subset.boundary.plot(ax=ax,linewidth=1)
        ax.set_xlim(0,image['width']);ax.set_ylim(image['height'],0)
        ax.set_title(f"{spec['sample']}: {asset['asset_id']} / {category}\nReference geometry only; use is chosen in asset_choices.csv")
        name=p['report']/f"asset_{asset['asset_id']}_category_{choice_key(category)}.png"
        fig.savefig(name,dpi=cfg['plots']['dpi'],bbox_inches='tight');plt.close(fig);files.append({'category':category,'path':str(name)})
    return files
