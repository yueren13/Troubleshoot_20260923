"""CPU numeric/metadata tests; no biological inputs or remote storage."""
import gzip
import json
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import pytest

from vhd.core import affine, transform_xy, fit_grid_affine
from vhd.grid_geometry import GridGeometryError, fit_grid_affine_checked
from vhd.grid_diagnostics import (read_matrix_barcodes, positions_for_matrix,
                                  fit_and_report, report_summary)


def grid(nr=80, nc=90):
    r,c=np.mgrid[:nr,:nc];r=r.ravel();c=c.ravel()
    a=affine([7.712345,.1134,1023.414,.1267,7.821343,2019.1])
    return r,c,transform_xy(np.c_[c,r],a),a


def test_exact_affine_contract():
    r,c,xy,a=grid();before=xy.copy()
    result,report=fit_grid_affine(r,c,xy,tolerance_px=1e-8)
    np.testing.assert_allclose(result,a,atol=1e-9)
    np.testing.assert_array_equal(xy,before)
    assert report['acceptance']=='strict_affine'


def test_rounded_fullres_reproduces_old_failure_and_new_bounded_acceptance():
    r,c,xy,a=grid(130,140);xy=np.rint(xy);original=xy.copy()
    with pytest.raises(GridGeometryError,match='not sufficiently affine'):
        fit_grid_affine(r,c,xy,rounding_policy='strict')
    matrix,report=fit_grid_affine(r,c,xy)
    assert report['acceptance']=='verified_integer_pixel_rounding'
    assert report['max_residual_px']>.1
    assert report['max_residual_px']<=np.sqrt(.5**2+.5**2)+2e-7
    assert max(report['max_abs_axis_residual_px'])<=.5+1e-7
    assert report['validated_n_bins']==len(xy)
    assert any(r['status']=='verified_all_bins' for r in report['rounding_witness_axes'])
    np.testing.assert_array_equal(xy,original)
    assert not np.array_equal(transform_xy(np.c_[c,r],matrix),xy)


@pytest.mark.parametrize('chunk',[1,73,10000])
def test_chunk_invariance_and_no_input_mutation(chunk):
    r,c,xy,_=grid(12,15);xy=np.rint(xy)
    before=[a.tobytes() for a in (r,c,xy)]
    a,rep=fit_grid_affine_checked(r,c,xy,chunk_size=chunk)
    b,_=fit_grid_affine_checked(r,c,xy,chunk_size=51)
    np.testing.assert_allclose(a,b,atol=1e-6)
    assert before==[v.tobytes() for v in (r,c,xy)]
    assert rep['original_coordinates_preserved'] is True


def test_subpixel_warp_not_automatically_passed_under_one_pixel():
    r,c,xy,_=grid()
    xy[:,0]+=.4*np.sin(c/15)
    with pytest.raises(GridGeometryError) as error:
        fit_grid_affine(r,c,xy)
    rep=error.value.report
    assert .1<rep['max_residual_px']<1
    assert not rep['all_source_coordinates_integer']
    assert rep['status']=='blocked'


def test_integer_nonaffine_outlier_rejected():
    r,c,xy,_=grid();xy=np.rint(xy);xy[len(xy)//2,0]+=3
    with pytest.raises(GridGeometryError) as error:fit_grid_affine(r,c,xy)
    assert error.value.report['status']=='blocked'


def test_integer_small_radial_error_is_not_sufficient():
    # A non-affine integer step whose best fit is <1 pixel in Euclidean distance
    # but cannot fit ALL +/-0.5 intervals is not blindly accepted.
    r,c=np.mgrid[:7,:7];r=r.ravel();c=c.ravel()
    xy=np.c_[8*c,8*r].astype(float);xy[len(xy)//2,0]+=2
    with pytest.raises(GridGeometryError):fit_grid_affine(r,c,xy)


def test_unsampled_outlier_is_validated():
    r,c,xy,_=grid(340,340)
    sample=np.random.default_rng(42).choice(len(r),100000,replace=False)
    outlier=np.setdiff1d(np.arange(len(r)),sample)[0]
    xy[outlier,0]+=3
    with pytest.raises(GridGeometryError) as error:fit_grid_affine(r,c,xy)
    assert error.value.report['max_residual_px']>2.9
    assert error.value.report['validated_n_bins']==len(xy)


def test_projective_fit_is_only_diagnostic():
    r,c,_,_=grid(70,75);h=np.array([[8,.2,1200],[.1,7.8,1400],[2e-5,-1e-5,1.]])
    design=np.c_[c,r,np.ones(len(c))]@h.T;xy=design[:,:2]/design[:,[2]]
    with pytest.raises(GridGeometryError) as error:fit_grid_affine(r,c,xy)
    rep=error.value.report
    assert rep['acceptance']=='none'
    assert rep['projective_diagnostic']['status']=='diagnostic_only_not_applied'
    assert rep['projective_diagnostic']['max_residual_px']<1e-7


@pytest.mark.parametrize('tolerance',[-1,float('inf'),float('nan')])
def test_bad_tolerance(tolerance):
    r,c,xy,_=grid()
    with pytest.raises(ValueError):fit_grid_affine(r,c,xy,tolerance_px=tolerance)


@pytest.mark.parametrize('chunk',[0,-1,False,2.5])
def test_bad_chunk_size(chunk):
    r,c,xy,_=grid()
    with pytest.raises(ValueError):fit_grid_affine_checked(r,c,xy,chunk_size=chunk)


def test_bad_policy():
    r,c,xy,_=grid()
    with pytest.raises(ValueError,match='policy'):fit_grid_affine(r,c,xy,rounding_policy='ignore')


@pytest.mark.parametrize('problem',['nan','inf','negative_index','fractional_index','shape','collinear','singular','too_few'])
def test_invalid_geometry(problem):
    r,c,xy,_=grid(3,4);r=r.astype(float)
    if problem=='nan':xy[0,0]=np.nan
    if problem=='inf':xy[0,1]=np.inf
    if problem=='negative_index':r[0]=-1
    if problem=='fractional_index':r[0]=.3
    if problem=='shape':xy=xy[:,:1]
    if problem=='collinear':r=c.copy()
    if problem=='singular':xy[:,1]=xy[:,0]
    if problem=='too_few':r=r[:2];c=c[:2];xy=xy[:2]
    with pytest.raises(ValueError):fit_grid_affine(r,c,xy)


def test_strict_policy_does_not_add_allowance():
    r,c,xy,_=grid();xy=np.rint(xy)
    with pytest.raises(GridGeometryError):fit_grid_affine(r,c,xy,rounding_policy='strict')


def test_diagnostic_json_written_on_failure(tmp_path):
    r,c,xy,_=grid();xy[0,0]+=5;dest=tmp_path/'reports'/'grid.json'
    with pytest.raises(GridGeometryError,match='Diagnostic:'):
        fit_and_report(r,c,xy,{'grid_max_residual_px':.1},report_path=dest,source_mpp=.25)
    report=json.loads(dest.read_text())
    assert report['status']=='blocked'
    assert report['max_residual_um_using_scalar_source_mpp']==report['max_residual_px']*.25


def test_diagnostic_no_write_and_scalar_units(tmp_path):
    r,c,xy,_=grid();a,report=fit_and_report(r,c,xy,{},source_mpp=.5)
    assert not list(tmp_path.iterdir())
    assert report['counts_loaded_for_this_check'] is False
    assert report['max_residual_um_using_scalar_source_mpp']==report['max_residual_px']*.5


def test_h5_barcodes_only(tmp_path):
    f=tmp_path/'matrix.h5'
    with h5py.File(f,'w') as h:
        h.create_dataset('matrix/barcodes',data=np.array([b'001',b'002']))
        # No matrix/data exists. This proves counts are not required by this reader.
    assert read_matrix_barcodes(f).tolist()==['001','002']


@pytest.mark.parametrize('compressed',[False,True])
def test_mtx_barcodes(tmp_path,compressed):
    file=tmp_path/('barcodes.tsv.gz' if compressed else 'barcodes.tsv')
    if compressed:
        with gzip.open(file,'wt') as stream:stream.write('001\n002\n')
    else:file.write_text('001\n002\n')
    assert read_matrix_barcodes(tmp_path).tolist()==['001','002']


@pytest.mark.parametrize('text',['a\na\n','a\n\n','a\tb\n',''])
def test_bad_barcodes(tmp_path,text):
    (tmp_path/'barcodes.tsv').write_text(text)
    with pytest.raises(ValueError):read_matrix_barcodes(tmp_path)


def test_ambiguous_barcodes(tmp_path):
    (tmp_path/'barcodes.tsv').write_text('a\n')
    with gzip.open(tmp_path/'barcodes.tsv.gz','wt') as s:s.write('a\n')
    with pytest.raises(ValueError,match='exactly one'):read_matrix_barcodes(tmp_path)


def test_positions_join_preserves_barcode_order(monkeypatch,tmp_path):
    (tmp_path/'barcodes.tsv').write_text('b\na\n')
    pos=pd.DataFrame({'barcode':['a','b','c'],'array_row':[0,0,1],'array_col':[0,1,0],
                      'pxl_col_in_fullres':[3,7,3],'pxl_row_in_fullres':[4,4,8], 'in_tissue':[1,1,0]})
    monkeypatch.setattr(pd,'read_parquet',lambda *args,**kwargs:pos.copy())
    selected=positions_for_matrix({'matrix':tmp_path,'positions':tmp_path/'positions.parquet'})
    assert selected.index.tolist()==['b','a']
    assert selected.pxl_col_in_fullres.tolist()==[7,3]
    assert selected.in_tissue.tolist()==[1,1]


@pytest.mark.parametrize('problem',['missing_barcode','duplicate_barcode','duplicate_grid','missing_coordinate'])
def test_positions_bad_join(monkeypatch,tmp_path,problem):
    (tmp_path/'barcodes.tsv').write_text('a\nb\n')
    p=pd.DataFrame({'barcode':['a','b'],'array_row':[0,0],'array_col':[0,1],
                    'pxl_col_in_fullres':[3,7],'pxl_row_in_fullres':[4,4]})
    if problem=='missing_barcode':p.loc[1,'barcode']='c'
    if problem=='duplicate_barcode':p.loc[1,'barcode']='a'
    if problem=='duplicate_grid':p.loc[1,'array_col']=0
    if problem=='missing_coordinate':p.loc[0,'pxl_col_in_fullres']=np.nan
    monkeypatch.setattr(pd,'read_parquet',lambda *args,**kwargs:p.copy())
    with pytest.raises(ValueError):positions_for_matrix({'matrix':tmp_path,'positions':tmp_path/'pos'})


def test_report_summary_returns_small_table():
    _,rep=fit_grid_affine(*grid()[:3])
    table=report_summary({'sample':rep})
    assert len(table)==1 and table.iloc[0]['status']=='passed'
