"""Read-only ImageScope XML region diagnostics for the v4.1.1 pipeline.

This is NOT a replacement parser and does not approve, drop, repair, or transfer
pipeline annotations. Optional make_valid results are summarized in memory only.
Use the installed pipeline's read_assets/resolve_sample_keys for source routing.
No sample_paths(), writers, image readers, expression readers or workers are used.
"""
from __future__ import annotations

import hashlib
import math
from collections import Counter
from pathlib import Path
from typing import Any

import pandas as pd
import shapely
from defusedxml import ElementTree as ET
from shapely.geometry import Polygon

DIAGNOSTIC_VERSION = "annotation-region-inspection-20261001-v1"
XML_SUFFIXES = (".xml", ".annotation", ".annotations")

REGION_COLUMNS = [
    "sample_key", "asset_id", "source_kind", "path", "category",
    "annotation_index", "annotation_id", "region_index", "region_id",
    "region_type", "negative_region", "n_vertices", "vertex_tag",
    "mixed_vertex_tags", "status", "reason", "bounds_xy",
    "area_before_unreliable_if_invalid", "candidate_status", "candidate_type",
    "candidate_component_types", "candidate_is_valid", "candidate_is_empty",
    "candidate_area", "candidate_error",
]
SUMMARY_COLUMNS = [
    "sample_key", "asset_id", "source_kind", "path", "status", "n_annotations",
    "n_regions", "n_valid_regions", "n_invalid_regions", "n_malformed_regions",
    "n_categories", "categories", "structural_warnings", "error_type", "error",
    "source_sha256", "diagnostic_version", "shapely_version", "geos_version",
    "repair_candidates_requested", "source_or_pipeline_modified",
]


def _leaf_types(geometry: Any) -> dict[str, int]:
    """Count all candidate leaf types; never discard lines/points/empty parts."""
    counts: Counter[str] = Counter()
    stack = [geometry]
    while stack:
        geom = stack.pop()
        if hasattr(geom, "geoms") and not geom.is_empty:
            stack.extend(geom.geoms)
        else:
            counts[geom.geom_type + (" (empty)" if geom.is_empty else "")] += 1
    return dict(sorted(counts.items()))


def _number(value: Any) -> float | None:
    number = float(value)
    return number if math.isfinite(number) else None


def inspect_xml_regions(
    path: str | Path,
    *,
    sample_key: str = "",
    asset_id: str = "",
    source_kind: str = "annotation",
    check_repair_candidates: bool = False,
) -> dict[str, Any]:
    """Inspect every XML Region, not just the first invalid one.

    Mirrors the installed parser's source-region construction: namespace removal,
    V tags preferred over Vertex tags, X/Y numeric coordinates in source units,
    Polygon closure performed by Shapely, NegativeROA preserved as metadata.
    It does NOT dissolve positives, subtract negative regions or test registration.
    File/format failures are reported separately from invalid polygons.
    Reads one annotation file into memory; no original slide/count matrix is read.
    """
    if not isinstance(check_repair_candidates, bool):
        raise TypeError("check_repair_candidates must be Boolean.")
    path = Path(path).expanduser()
    common = dict(sample_key=sample_key, asset_id=asset_id,
                  source_kind=source_kind, path=str(path))
    summary = {
        **common, "status": "not_checked", "n_annotations": 0, "n_regions": 0,
        "n_valid_regions": 0, "n_invalid_regions": 0, "n_malformed_regions": 0,
        "n_categories": 0, "categories": [], "structural_warnings": [],
        "error_type": "", "error": "", "source_sha256": "",
        "diagnostic_version": DIAGNOSTIC_VERSION,
        "shapely_version": shapely.__version__,
        "geos_version": getattr(shapely, "geos_version_string", "unknown"),
        "repair_candidates_requested": check_repair_candidates,
        "source_or_pipeline_modified": False,
    }
    records: list[dict[str, Any]] = []
    try:
        # Hash and parse the same byte snapshot, never a rewritten XML file.
        payload = path.read_bytes()
        summary["source_sha256"] = hashlib.sha256(payload).hexdigest()
        root = ET.fromstring(payload)
        del payload
        for element in root.iter():
            element.tag = element.tag.rsplit("}", 1)[-1]
        if root.tag not in ("Annotations", "Annotation"):
            raise ValueError("Unsupported XML root; expected ImageScope Annotations/Annotation.")
        annotations = list(root.iter("Annotation"))
        if not annotations:
            raise ValueError("No ImageScope Annotation elements found.")
        summary["n_annotations"] = len(annotations)
        summary["categories"] = list(dict.fromkeys(a.get("Name", "unnamed") for a in annotations))
        summary["n_categories"] = len(summary["categories"])
        for ai, annotation in enumerate(annotations):
            regions = annotation.findall("./Regions/Region")
            category = annotation.get("Name", "unnamed")  # Preserve exact spelling.
            if not regions:
                summary["structural_warnings"].append(
                    f"Annotation index {ai} ({category!r}) contains no Regions/Region entries."
                )
            n_positive = 0
            for ri, region in enumerate(regions):
                negative = region.get("NegativeROA", "0").lower() in ("1", "true", "t", "yes")
                n_positive += int(not negative)
                record = {
                    **common, "category": category, "annotation_index": ai,
                    "annotation_id": str(annotation.get("Id", ai)),
                    "region_index": ri, "region_id": str(region.get("Id", ri)),
                    "region_type": region.get("Type", ""), "negative_region": negative,
                    "n_vertices": 0, "vertex_tag": "", "mixed_vertex_tags": False,
                    "status": "not_checked", "reason": "", "bounds_xy": None,
                    "area_before_unreliable_if_invalid": None,
                    "candidate_status": "not_requested", "candidate_type": "",
                    "candidate_component_types": None, "candidate_is_valid": None,
                    "candidate_is_empty": None, "candidate_area": None, "candidate_error": "",
                }
                try:
                    vertices = region.find("Vertices")
                    if vertices is None:
                        raise ValueError("No Vertices element.")
                    short = list(vertices.findall("V"))
                    long = list(vertices.findall("Vertex"))
                    chosen = short or long
                    record["n_vertices"] = len(chosen)
                    record["vertex_tag"] = "V" if short else "Vertex" if long else ""
                    record["mixed_vertex_tags"] = bool(short and long)
                    if len(chosen) < 3:
                        raise ValueError("Fewer than three source vertices.")
                    xy = [(float(v.get("X")), float(v.get("Y"))) for v in chosen]
                    if not all(math.isfinite(z) for pair in xy for z in pair):
                        raise ValueError("Nonfinite X/Y value in source vertices.")
                    poly = Polygon(xy)
                    valid = bool(poly.is_valid)
                    record["reason"] = str(shapely.is_valid_reason(poly))
                    record["bounds_xy"] = [_number(v) for v in poly.bounds]
                    record["area_before_unreliable_if_invalid"] = _number(poly.area)
                    if valid and not poly.is_empty and poly.area > 0:
                        record["status"] = "valid"
                    else:
                        record["status"] = "invalid"
                        if valid:
                            record["reason"] = "Empty or zero-area polygon; not a usable filled region."
                        if check_repair_candidates:
                            try:
                                # Candidate only; not returned as accepted geometry or written.
                                candidate = shapely.make_valid(poly)
                                record.update(
                                    candidate_status="candidate_only_not_applied",
                                    candidate_type=candidate.geom_type,
                                    candidate_component_types=_leaf_types(candidate),
                                    candidate_is_valid=bool(candidate.is_valid),
                                    candidate_is_empty=bool(candidate.is_empty),
                                    candidate_area=_number(candidate.area),
                                )
                            except Exception as exc:
                                record.update(candidate_status="candidate_error",
                                              candidate_error=f"{type(exc).__name__}: {exc}")
                except Exception as exc:
                    record.update(status="malformed", reason=f"{type(exc).__name__}: {exc}")
                records.append(record)
            if regions and n_positive == 0:
                summary["structural_warnings"].append(
                    f"Annotation index {ai} ({category!r}) has negative regions but no positive parent."
                )
        counts = Counter(record["status"] for record in records)
        summary.update(n_regions=len(records), n_valid_regions=counts["valid"],
                       n_invalid_regions=counts["invalid"], n_malformed_regions=counts["malformed"])
        if not records:
            summary["status"] = "no_regions"
        elif counts["invalid"] or counts["malformed"]:
            summary["status"] = "region_issues"
        elif summary["structural_warnings"]:
            summary["status"] = "source_review_needed"
        else:
            summary["status"] = "source_regions_valid_not_alignment_approved"
    except Exception as exc:
        summary.update(status="source_error", error_type=type(exc).__name__, error=str(exc))
    return {"summary": summary, "regions": records}


def inspect_project_annotations(
    project: dict[str, Any], sample_keys: list[str] | None = None,
    *, check_repair_candidates: bool = False,
) -> dict[str, Any]:
    """Inspect selected samples' enabled ImageScope sources and XML coverage files.

    No calls to sample_paths, discovery, import, persistence, or approval helpers.
    Uses the CURRENT loaded PROJECT and asset CSVs. Non-XML polygon sources and
    signal images are not inspected; non-XML polygon sources are listed separately.
    Any source-file error appears in `files`; it is not reported as a geometry pass.
    """
    from vhd.control.manifest import resolve_sample_keys
    from vhd.annotations.workflow import read_assets

    selected = set(resolve_sample_keys(project, sample_keys))
    files: list[dict[str, Any]] = []
    regions: list[dict[str, Any]] = []
    not_inspected: list[dict[str, Any]] = []
    for row in project["rows"]:
        if row["sample_key"] not in selected:
            continue
        assets = read_assets(row.get("assets_manifest"), row["dataset_id"], row["sample_id"])
        for asset in assets:
            targets = []
            if asset["kind"] == "polygons":
                targets.append(("annotation", asset["path"], asset.get("format") == "imagescope_xml"))
            if asset.get("coverage_path"):
                targets.append(("coverage", asset["coverage_path"], False))
            for kind, path, force_xml in targets:
                if not force_xml and not str(path).lower().endswith(XML_SUFFIXES):
                    not_inspected.append({"sample_key": row["sample_key"], "asset_id": asset["asset_id"],
                                          "path": str(path), "reason": "Not an ImageScope XML source."})
                    continue
                result = inspect_xml_regions(
                    path, sample_key=row["sample_key"], asset_id=asset["asset_id"],
                    source_kind=kind, check_repair_candidates=check_repair_candidates,
                )
                files.append(result["summary"])
                regions.extend(result["regions"])
    frame = pd.DataFrame(regions, columns=REGION_COLUMNS)
    issues = frame.loc[frame["status"] != "valid"].copy()
    return {
        "files": pd.DataFrame(files, columns=SUMMARY_COLUMNS),
        "regions": frame, "issues": issues,
        "not_inspected": pd.DataFrame(not_inspected, columns=["sample_key", "asset_id", "path", "reason"]),
        "limitations": [
            "Source coordinates and category strings are unchanged.",
            "Candidates are mathematical proposals, not reviewer approvals or stored repairs.",
            "Different-category overlap is not flagged as invalid.",
            "No dissolve/difference operations, registration or intended tissue classification were validated.",
            "The original area of an invalid polygon is not a reliable measure of the intended region.",
        ],
    }


def print_diagnostic_summary(audit: dict[str, Any], max_issues: int | None = 30) -> None:
    """Print source identity, counts and full validity reasons without truncating cells."""
    if max_issues is not None and (isinstance(max_issues, bool) or not isinstance(max_issues, int) or max_issues < 1):
        raise ValueError("max_issues must be a positive integer or None.")
    print("READ-ONLY ANNOTATION INSPECTION:", DIAGNOSTIC_VERSION)
    if audit['files'].empty:
        print("No enabled ImageScope annotation/coverage sources were inspected for the selection.")
    for record in audit['files'].to_dict(orient='records'):
        print(f"\n{record['sample_key']} | {record['asset_id']} | {record['source_kind']}")
        print("Source:", record['path'])
        print("Status:", record['status'])
        print(f"Regions: {record['n_regions']} total; {record['n_valid_regions']} valid; "
              f"{record['n_invalid_regions']} invalid; {record['n_malformed_regions']} malformed")
        print("Shapely / GEOS:", record['shapely_version'], '/', record['geos_version'])
        if record['error']:
            print("Source error:", record['error_type'], record['error'])
        for warning in record['structural_warnings']:
            print("Source warning:", warning)
    issues = audit['issues'] if max_issues is None else audit['issues'].head(max_issues)
    print(f"\nREGION ISSUES: showing {len(issues)} of {len(audit['issues'])}")
    for row in issues.to_dict(orient='records'):
        print(f"\n{row['sample_key']} | {row['asset_id']} | category={row['category']!r}")
        print(f"Annotation id={row['annotation_id']!r}, zero-based index={row['annotation_index']}; "
              f"region id={row['region_id']!r}, zero-based index={row['region_index']}")
        print(f"NegativeROA={row['negative_region']} | Type={row['region_type']!r} | vertices={row['n_vertices']}")
        print("Reason:", row['reason'])
        if row['candidate_status'] == 'candidate_only_not_applied':
            print("Candidate ONLY (not applied):", row['candidate_type'], row['candidate_component_types'])
            print("Candidate validity:", row['candidate_is_valid'], "| empty:", row['candidate_is_empty'])
        elif row['candidate_status'] == 'candidate_error':
            print("Candidate error:", row['candidate_error'])
    if not audit['not_inspected'].empty:
        print("\nOTHER SOURCES NOT INSPECTED:")
        print(audit['not_inspected'].to_string(index=False))
    print("\nNo annotation repairs were applied; no source, configuration, or data product was written.")
    print("Valid source regions do not establish registration, valid dissolved categories, or biological accuracy.")
