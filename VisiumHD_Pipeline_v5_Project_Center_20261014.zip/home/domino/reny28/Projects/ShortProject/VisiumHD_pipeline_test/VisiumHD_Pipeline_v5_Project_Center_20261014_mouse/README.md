# Visium HD Project Center v5 — 0.5.0rc1

A full candidate bundle based on the owner's uploaded patched v4.1.1 scientific engine, with a persistent Project Center, review controls, route/resume planning, and HTML reports for bin QC, assets, segmentation, cell QC and clustering.

**Start:** `notebooks/00_Project_Center.ipynb` → import the current config once → reopen the same workspace thereafter. Read **[docs/START_HERE.md](docs/START_HERE.md)**.

No scientific jobs start merely by opening the interface. Original configuration and biological inputs remain untouched on import; compatibility CSVs are generated managed copies. Original output paths and scientific version stamps are preserved. The project controller uses a separate small state store.

**This is a target-environment release candidate.** Controller/filesystem/real-small-image tests and static HTML rendering were exercised locally. The live Jupyter frontend, actual SpatialData/AnnData/Scanpy roundtrips, biological slides and GPUs were not tested in this environment. See **[VALIDATION.md](VALIDATION.md)** and the boundaries in Start Here. A passing import/package test is not scientific validation.

## Contents

- `vhd/`: preserved scientific modules plus the new `center/` package.
- `notebooks/00_Project_Center.ipynb`: normal launcher; `99_Project_Center_Environment_Check.ipynb`: optional small smoke checks.
- `notebooks/advanced/`: historical stage notebooks, output-free, for reference/advanced use—not concurrent operation on the same stores.
- `tools/`: retained visual/diagnostic tools and a synthetic HTML demonstration generator.
- `examples/new_project/`: minimal sample and asset sheets.
- `examples/current_human3/config/`: supplied private pilot settings/paths for migration reference.
- `examples/html_report_demo/`: self-contained **synthetic** report-layout example. No clustering or segmentation algorithm was run for those illustrative figures.
- `docs/UPLOADED_ENGINE_SHA256.json`, `SOURCE_PROVENANCE.json`: source lineage and byte-preservation checks.
- `tests/`: inherited and new tests, with optional dependency-gated scientific/UI tests.

## Installation

Extract to a **new** folder. No hotfix installers are required. Select your scientific Jupyter kernel; add `ipywidgets>=8,<9` with your approved environment manager if needed. Separate JupyterLab server environments may need `jupyterlab_widgets`. The package does not install or update scientific frameworks automatically.

## Privacy / Git

No GitHub changes were made. This study-specific bundle retains deployment paths and sample IDs in configuration examples. **Review/exclude them, all report exports, and original notebook outputs before publishing publicly.** No corporate template, images from the user's slides, font files, raw biological data or virtual environment is bundled.

## Scientific behavior

The fixed H&E scoring, projective source coordinates, split Space Ranger image lookup, independent overlapping polygon memberships, reviewed line-remnant handling, native signal statistics, master persistence guards, and group scVI engine are retained. No biological thresholds or annotation approvals are granted automatically.

Independent sample clustering is a separate new optional PCA/Leiden route, not an implicit scVI integration. All analysis remains opt-in beyond the imported endpoint.
