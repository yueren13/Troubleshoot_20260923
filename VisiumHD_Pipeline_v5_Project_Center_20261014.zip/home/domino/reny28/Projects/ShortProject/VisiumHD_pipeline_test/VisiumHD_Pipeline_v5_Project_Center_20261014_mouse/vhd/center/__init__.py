"""Persistent, review-first interface over the uploaded Visium HD scientific engine."""
__version__ = '0.5.0rc1'
from .controller import ProjectCenter

__all__ = ['ProjectCenter', '__version__']
