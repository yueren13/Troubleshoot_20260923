"""Persistent startup controls, isolated probes, and executable checks.

No scientific arrays are read here. Settings are runtime-only: they do not alter
segmentation algorithms, reviews, controller cache contracts or storage policies.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shlex
import signal
import subprocess
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

RUNTIME_PATCH_ID = 'vhd-v5-runtime-20261013-r1'
DEFAULTS = {
    'python_import_timeout_seconds': 300,
    'stardist_import_timeout_seconds': 900,
    'executable_timeout_seconds': 120,
    'stack_dump_interval_seconds': 60,
    'heartbeat_seconds': 30,
    'shared_cache_root': '',
}

# This is deliberately the same mandatory set as native segmentation.check_proseg.
PROSEG_REQUIRED_FLAGS = [
    '--anndata', '--anndata-coordinate-key', '--cellpose-masks',
    '--cellpose-x-transform', '--cellpose-y-transform', '--output-counts',
    '--output-cell-polygons', '--output-cell-metadata', '--output-gene-metadata',
    '--output-spatialdata', '--exclude-spatialdata-transcripts', '--nthreads',
    '--ignore-z-coord', '--voxel-layers', '--diffusion-sigma-near',
    '--diffusion-sigma-far',
]


def validate_startup_settings(values=None):
    values = dict(values or {})
    unknown = set(values).difference(DEFAULTS)
    if unknown:
        raise ValueError(f'Unknown startup fields: {sorted(unknown)}')
    result = dict(DEFAULTS, **values)
    for key in DEFAULTS:
        if key == 'shared_cache_root':
            continue
        value = result[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f'{key} must be a number, not {value!r}')
        if not math.isfinite(value) or not 1 <= value <= 7200:
            raise ValueError(f'{key} must be finite and between 1 and 7200 seconds')
        result[key] = float(value)
    root = result['shared_cache_root']
    if not isinstance(root, str):
        raise TypeError('shared_cache_root must be a path string or an empty string')
    if root:
        root = os.path.expanduser(root)
        if not Path(root).is_absolute() or any(c in root for c in ('\n', '\r', '\0', '*', '?')) or '://' in root:
            raise ValueError('shared_cache_root must be an explicit absolute local filesystem path')
    result['shared_cache_root'] = root
    return result


def settings_for_project(project):
    return validate_startup_settings(project.get('_center_startup_settings', {}))


def validate_cache_root(project, root):
    """Allow a separate runtime cache, never a scientific source/master or code root."""
    if not root:
        return
    cache = Path(root).expanduser().resolve()
    code = Path(__file__).resolve().parents[2]
    protected = [code]
    for row in project.get('rows', []):
        for key in ('spaceranger_outs', 'segmentation_image', 'bin_input', 'cell_input',
                    'cell_boundaries', 'master_store'):
            value = row.get(key)
            if value and '://' not in str(value):
                protected.append(Path(value).expanduser().resolve())
    for key in ('manifest_path', 'settings_path'):
        value = project.get(key)
        if value and '://' not in str(value):
            protected.append(Path(value).expanduser().resolve().parent)
    for source in protected:
        if cache == source or source in cache.parents or cache in source.parents:
            raise ValueError(f'Runtime cache overlaps a protected source/master/configuration/code path: {source}')


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp-' + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(value, indent=2, default=str, allow_nan=False) + '\n')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def startup_directory(report_dir, action):
    if not re.fullmatch(r'[A-Za-z0-9_]+', action):
        raise ValueError('Invalid startup action name')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    p = Path(report_dir) / 'startup' / action / (stamp + '_' + uuid.uuid4().hex[:8])
    p.mkdir(parents=True, exist_ok=False)
    return p


def prepare_environment(env, executable, scratch, settings, *, create=True):
    """Change only MPLCONFIGDIR; preserve GPU visibility and scientific caches.

    Blank shared_cache_root uses each sample's already-approved scratch. An
    explicit root shares one environment-keyed cache across samples and stages.
    """
    settings = validate_startup_settings(settings)
    out = dict(env)
    base = Path(settings['shared_cache_root']) if settings['shared_cache_root'] else Path(scratch)/'runtime'/'shared_startup'
    invocation = str(Path(executable).expanduser().absolute())  # do NOT dereference a venv Python symlink
    try:
        st = Path(invocation).stat()
        version_key = [invocation, st.st_size, st.st_mtime_ns]
    except OSError:
        version_key = [invocation]
    key = hashlib.sha256(json.dumps(version_key).encode()).hexdigest()[:16]
    cache = base / ('mpl_' + key)
    previous = out.get('MPLCONFIGDIR')
    if previous and Path(previous).absolute() != cache.absolute():
        old_rc = Path(previous)/'matplotlibrc'
        new_rc = cache/'matplotlibrc'
        if old_rc.is_file() and (not new_rc.is_file() or old_rc.read_bytes() != new_rc.read_bytes()):
            raise RuntimeError(f'Existing custom matplotlibrc would be lost: {old_rc}. Review cache configuration; no file was copied or removed.')
    if create:
        cache.mkdir(parents=True, exist_ok=True, mode=0o700)
        test = cache / ('.write_test_' + uuid.uuid4().hex)
        try:
            with test.open('x') as f:
                f.write('')
        finally:
            test.unlink(missing_ok=True)
    out['MPLCONFIGDIR'] = str(cache.absolute())
    return out


def _tail(path, nbytes=24000):
    with Path(path).open('rb') as f:
        size = f.seek(0, os.SEEK_END)
        f.seek(max(0, size - nbytes))
        return f.read(nbytes).decode('utf-8', errors='replace')


def _stop_probe(process):
    """Stop only this newly created probe/session, never an existing worker."""
    if os.name == 'posix':
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    elif process.poll() is None:
        process.terminate()
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        if os.name == 'posix':
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        else:
            process.kill()
        process.wait()
    # A child might have survived its parent receiving TERM.
    if os.name == 'posix':
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def run_probe(command, *, env, cwd, timeout, log_path, heartbeat_seconds=30):
    """Run bounded startup only, stream output and retain a per-attempt receipt."""
    if isinstance(timeout, bool) or not math.isfinite(float(timeout)) or timeout <= 0:
        raise ValueError('Probe timeout must be positive and finite')
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    report_path = log_path.with_suffix('.json')
    started = time.monotonic()
    record = {'runtime_patch_id': RUNTIME_PATCH_ID,
              'started_at': datetime.now(timezone.utc).isoformat(),
              'command': list(map(str, command)), 'log': str(log_path),
              'timeout_seconds': float(timeout), 'status': 'starting',
              'scientific_execution_tested': False,
              'safe_environment': {k: (env or os.environ).get(k) for k in
                                   ('MPLCONFIGDIR', 'CUDA_VISIBLE_DEVICES', 'TMPDIR')}}
    atomic_json(report_path, record)
    process = None
    pending = ''
    last_print = time.monotonic()
    print(f'Startup probe log: {log_path} | deadline: {timeout:g} seconds', flush=True)
    try:
        with log_path.open('xb') as output:
            process = subprocess.Popen(list(map(str, command)), env=env, cwd=cwd,
                                       stdout=output, stderr=subprocess.STDOUT,
                                       start_new_session=(os.name == 'posix'))
            record.update(status='running', pid=process.pid)
            atomic_json(report_path, record)
            with log_path.open('r', encoding='utf-8', errors='replace') as stream:
                while True:
                    text = stream.read(65536)
                    if text:
                        pending += text
                        while '\n' in pending:
                            line, pending = pending.split('\n', 1)
                            print(line, flush=True)
                        last_print = time.monotonic()
                    elif process.poll() is not None:
                        # A second read after poll accounts for writes immediately before exit.
                        final = stream.read()
                        if final:
                            pending += final
                        if pending:
                            print(pending, flush=True)
                        break
                    now = time.monotonic()
                    if now - started >= timeout:
                        raise TimeoutError(f'Startup exceeded {timeout:g} seconds')
                    if now - last_print >= heartbeat_seconds:
                        print(f'Startup probe PID {process.pid}: still waiting ({now-started:.0f} s). This is not inference progress.', flush=True)
                        last_print = now
                    time.sleep(0.1)
            code = process.wait()
        record.update(returncode=code)
        if code:
            raise RuntimeError(f'Startup subprocess exited {code}')
        record['status'] = 'passed'
    except BaseException as exc:
        if process is not None:
            _stop_probe(process)
            record['returncode'] = process.poll()
        record.update(status='interrupted' if isinstance(exc, (KeyboardInterrupt, SystemExit)) else 'failed',
                      error=f'{type(exc).__name__}: {exc}')
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        text = _tail(log_path) if log_path.exists() else ''
        raise RuntimeError(f'{exc}. No sample jobs were submitted by this startup attempt.\nFull startup log: {log_path}\n{text}') from exc
    finally:
        record['elapsed_seconds'] = time.monotonic()-started
        record['finished_at'] = datetime.now(timezone.utc).isoformat()
        atomic_json(report_path, record)
    return record


PROSEG_PROBE = r'''
import hashlib, json, os, re, subprocess, sys
from pathlib import Path
HELP_CHECK_ID = 'vhd-proseg-help-ansi-20261013-r1'
exe = sys.argv[1]
flags = json.loads(sys.argv[2])
if not os.path.isabs(exe):
    raise ValueError('Save an absolute Proseg executable path under Resources / Reports > Advanced: executable environments. A bare command name is not accepted by this startup check.')
if not os.path.isfile(exe) or not os.access(exe, os.X_OK):
    raise FileNotFoundError('Configured Proseg executable is missing or not executable: '+exe)
print('PROSEG_EXECUTABLE '+exe, flush=True)
version = subprocess.check_output([exe, '--version'], stderr=subprocess.STDOUT, text=True, timeout=45).strip()
print('PROSEG_VERSION '+version, flush=True)
raw_help = subprocess.check_output([exe, '--help'], stderr=subprocess.STDOUT, text=True, timeout=45)
# Strip terminal presentation before testing exact option boundaries. Never
# relax the mandatory flag set or accept a longer flag as a shorter flag.
# OSC (e.g. hyperlinks) and CSI (e.g. bold/colour), in 7-bit/8-bit forms.
osc = re.compile(r'(?:\x1b\]|\x9d)[^\x07\x1b\x9c]*(?:\x07|\x1b\\|\x9c)')
csi = re.compile(r'(?:\x1b\[|\x9b)[0-?]*[ -/]*[@-~]')
plain_help, osc_removed = osc.subn('', raw_help)
plain_help, csi_removed = csi.subn('', plain_help)
def missing_in(text):
    return [flag for flag in flags
            if re.search(r'(?<![\w-])'+re.escape(flag)+r'(?![\w-])', text) is None]
raw_missing = missing_in(raw_help)
missing = missing_in(plain_help)
summary = {
    'help_check_id': HELP_CHECK_ID,
    'raw_help_characters': len(raw_help),
    'plain_help_characters': len(plain_help),
    'raw_help_sha256_utf8': hashlib.sha256(raw_help.encode('utf-8')).hexdigest(),
    'terminal_sequences_removed': osc_removed+csi_removed,
    'required_flag_count': len(flags),
    'legacy_raw_missing': raw_missing,
    'missing_after_normalization': missing,
    'segmentation_started': False,
}
# Optional audit prefix used by the one-time installer only. Normal native
# launches need no new argument and continue using their existing logs.
if len(sys.argv) > 3:
    prefix = Path(sys.argv[3])
    if not prefix.is_absolute() or not prefix.parent.is_dir():
        raise ValueError('The diagnostic prefix must have an existing absolute parent directory.')
    for suffix, content in (
        ('.raw_help.txt', raw_help),
        ('.plain_help.txt', plain_help),
        ('.help_audit.json', json.dumps(summary,indent=2)+'\n'),
    ):
        with prefix.with_name(prefix.name+suffix).open('x',encoding='utf-8') as f:
            f.write(content)
print('PROSEG_HELP_AUDIT '+json.dumps(summary), flush=True)
if missing:
    print('PROSEG_HELP_PLAIN_EXCERPT '+repr(plain_help[:6000]), flush=True)
    raise RuntimeError(version+': required CLI flags missing after terminal-format normalization: '+str(missing)+'. No flag requirement was bypassed; inspect the captured help.')
print('VHD_PROSEG_CLI_OK '+json.dumps({'executable':exe,'version':version,'required_flags':flags,'help_check_id':HELP_CHECK_ID,'segmentation_started':False}), flush=True)
'''


def preflight_proseg(python_executable, proseg_executable, *, env, cwd, settings, log_path):
    """Check the exact configured binary in the actual worker Python environment."""
    settings = validate_startup_settings(settings)
    value = str(proseg_executable)
    command = [str(python_executable), '-B', '-u', '-c', PROSEG_PROBE, value,
               json.dumps(PROSEG_REQUIRED_FLAGS)]
    return run_probe(command, env=env, cwd=cwd,
                     timeout=settings['executable_timeout_seconds'], log_path=log_path,
                     heartbeat_seconds=settings['heartbeat_seconds'])
