"""Visible, local notebook controls and non-destructive output inspection."""
from __future__ import annotations

import json
from pathlib import Path


def describe_run(project, *, execute, sample_keys=None, allow_all=False, kind='sample'):
    if type(execute) is not bool:
        raise TypeError('EXECUTE must be a Boolean; set RUN_MODE to preview or execute.')
    if sample_keys is not None and not isinstance(sample_keys, (list, tuple)):
        raise TypeError('SAMPLE_KEYS must be a list of sample keys or None; not a string.')
    keys = [r['sample_key'] for r in project['rows']]
    from .manifest import resolve_sample_keys
    chosen = resolve_sample_keys(project,sample_keys)
    if len(chosen) != len(set(chosen)):
        raise ValueError('Duplicate SAMPLE_KEYS.')
    if set(chosen) - set(keys):
        raise KeyError(f'Unknown SAMPLE_KEYS: {sorted(set(chosen)-set(keys))}')
    mode = 'EXECUTE: processing/writes enabled for explicitly run action cells' if execute else 'PREVIEW: compute launchers will not run sample jobs'
    print('\n' + '='*72 + '\n' + mode + '\n' + '='*72, flush=True)
    print('Manifest:', project['manifest_path'])
    print('Settings:', project['settings_path'])
    print('Run ID:', project['settings']['run_id'])
    print('Spatial worker Python:', project['settings']['execution']['python_spatial'])
    if kind == 'integration':
        print('Integration scope: all enabled rows in the GROUP selected below. SAMPLE_KEYS does not subset integration.')
        print('Use a separate, matching pilot CSV/settings pair for a two-sample integration.')
    elif kind == 'sample':
        print(f'Selected sample jobs ({len(chosen)}):', chosen)
        if execute and sample_keys is None and not allow_all:
            raise ValueError('Explicit selection required for the first run. Set SAMPLE_KEYS=["dataset__sample"] '
                             'in the Run controls cell, or set ALLOW_ALL_SAMPLES=True to deliberately run all enabled samples.')
        if execute and not chosen:
            raise ValueError('No selected samples. Set SAMPLE_KEYS explicitly.')
    else:
        print('This notebook contains setup/inspection/test cells. See each cell for its local effects.')
    print('RUN_MODE in this notebook is authoritative; VHD_EXECUTE is not read by the patched control cell.')
    print('Re-run controls + initialization after edits. A mode change is not a live global switch.')
    print('Reuse/partial-output safeguards remain active. Nothing is deleted or force-overwritten.\n', flush=True)
    return chosen


def output_status(project, sample_keys=None):
    """Read small receipts and check paths; do not read matrices or change files."""
    from .manifest import sample_layout
    selected = None if sample_keys is None else set(sample_keys)
    results = []
    for row in project['rows']:
        if row['goal'] == 'export_only' or (selected is not None and row['sample_key'] not in selected):
            continue
        p = sample_layout(project, row)
        table = 'bins_2um' if row['goal'] == 'bin_QCed' else 'cells'
        store = Path(p['store'])
        record = {'sample': row['sample_key'], 'store': str(store), 'expected_table': table,
                  'store_exists': store.is_dir(), 'table_exists': (store/'tables'/table).is_dir(),
                  'partial_exists': store.with_name(store.name+'.partial').exists(),
                  'prepared_cells_exist': (p['work']/'cells_qc.h5ad').is_file(),
                  'import_receipt_exists': (p['work']/'05_import_cells_complete.json').is_file(),
                  'storage_receipt_exists': (p['report']/'storage_manifest.json').is_file()}
        f = p['report']/'status_assemble.json'
        if f.is_file():
            try:
                saved = json.loads(f.read_text())
                record['last_assemble_status'] = saved.get('status')
                if saved.get('error'):
                    record['last_assemble_error'] = saved['error']
            except (OSError, ValueError) as exc:
                record['status_read_error'] = str(exc)
        else:
            record['last_assemble_status'] = 'no status record'
        print(json.dumps(record, indent=2), flush=True)
        results.append(record)
    print('Path existence is not scientific validation. A preview does not create missing products.', flush=True)
    return results


def output_index(project,sample_keys=None,save=False):
    """Expected and existing paths; optional small CSV under the approved control root."""
    from .manifest import sample_layout,check_policy
    import pandas as pd
    records=[]
    for row in project['rows']:
        if sample_keys is not None and row['sample_key'] not in sample_keys:continue
        p=sample_layout(project,row)
        items={'master':p['store'],'work':p['work'],'reports':p['report'],
               'cell_overlay':p['report']/'cells_qc_on_HE.png','assets_preview':p['report']/'assets_preview.json',
               'import_log':p['report']/'worker_import_cells.log','assembly_log':p['report']/'worker_assemble.log'}
        for label,path in items.items():records.append({'sample':row['sample_key'],'item':label,'path':str(path),'exists':path.exists()})
    table=pd.DataFrame(records)
    if save:
        check_policy(project);root=Path(project['settings']['integration']['control_dir'])/project['settings']['run_id']
        root.mkdir(parents=True,exist_ok=True);table.to_csv(root/'output_index.csv',index=False)
        print('Output index:',root/'output_index.csv')
    return table
