"""Read-only resource observations and conservative worker caps; never reserves devices."""
from __future__ import annotations
from pathlib import Path
import csv, io, math, os, shutil, subprocess


def cgroup_limits(cgroup_file='/proc/self/cgroup', mount='/sys/fs/cgroup'):
    """Read visible v2 ancestor constraints plus common v1 root constraints.

    Hidden host ancestors cannot be measured from a restricted namespace; return
    the inspected paths instead of implying complete host visibility.
    """
    root = Path(mount); cpu=[]; memory=[]; inspected=[]
    dirs={root}
    try:
        for line in Path(cgroup_file).read_text().splitlines():
            ident, controllers, rel = line.split(':', 2)
            if ident == '0' and not controllers:
                target = root / rel.lstrip('/')
                if target.is_relative_to(root):
                    dirs.add(target)
                    dirs.update(p for p in target.parents if p == root or root in p.parents)
    except (OSError, ValueError):
        pass
    for d in sorted(dirs, key=str):
        try:
            q, period = (d/'cpu.max').read_text().split()
            inspected.append(str(d/'cpu.max'))
            if q != 'max':cpu.append(int(q)/int(period))
        except (OSError, ValueError, ZeroDivisionError):pass
        try:
            limit=(d/'memory.max').read_text().strip()
            current=int((d/'memory.current').read_text())
            inspected.append(str(d/'memory.max'))
            if limit != 'max':memory.append(max(0,int(limit)-current))
        except (OSError, ValueError):pass
    try:
        q=int((root/'cpu/cpu.cfs_quota_us').read_text()); period=int((root/'cpu/cpu.cfs_period_us').read_text())
        if q>0 and period>0:cpu.append(q/period)
    except (OSError,ValueError):pass
    try:
        limit=int((root/'memory/memory.limit_in_bytes').read_text());current=int((root/'memory/memory.usage_in_bytes').read_text())
        if limit<2**60:memory.append(max(0,limit-current))
    except (OSError,ValueError):pass
    return {'cpu_quota_cores':min(cpu) if cpu else None,
            'memory_headroom_bytes':min(memory) if memory else None,
            'inspected':inspected,'scope':'visible cgroup ancestors; no kernel settings changed'}


def parse_gpu_csv(text, visible=None):
    devices=[]
    for r in csv.reader(io.StringIO(text)):
        if len(r)!=5:continue
        try:
            devices.append(dict(index=int(r[0].strip()), uuid=r[1].strip(), name=r[2].strip(),
                                total_gib=float(r[3])/1024,free_gib=float(r[4])/1024))
        except ValueError:continue
    if visible is None:return devices
    ids=[x.strip() for x in visible.split(',') if x.strip()]
    result=[]
    for token in ids:
        found=[d for d in devices if token==str(d['index']) or d['uuid'].startswith(token)]
        if len(found)==1 and found[0] not in result:result.append(found[0])
    return result


def detect_resources():
    import psutil
    affinity=len(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else (os.cpu_count() or 1)
    limits=cgroup_limits();cpu=min(affinity,limits['cpu_quota_cores'] or affinity)
    vm=psutil.virtual_memory();available=vm.available
    if limits['memory_headroom_bytes'] is not None:available=min(available,limits['memory_headroom_bytes'])
    devices=[];problem=None;exe=shutil.which('nvidia-smi')
    if exe:
        try:
            p=subprocess.run([exe,'--query-gpu=index,uuid,name,memory.total,memory.free','--format=csv,noheader,nounits'],
                             capture_output=True,text=True,timeout=12,check=False)
            if p.returncode:problem=p.stderr.strip() or 'nvidia-smi failed'
            else:devices=parse_gpu_csv(p.stdout,os.environ.get('CUDA_VISIBLE_DEVICES'))
        except (OSError,subprocess.TimeoutExpired) as exc:problem=str(exc)
    else:problem='nvidia-smi unavailable; no GPU inferred'
    return {'cpu_affinity_threads':affinity,'eligible_cpu_cores':cpu,'ram_total_gib':vm.total/2**30,
            'ram_available_gib':available/2**30,'gpus':devices,'gpu_probe_note':problem,
            'cgroup':limits,'framework_compatibility_tested':False,
            'note':'Availability snapshot, not a resource reservation. GPU framework checks occur before execution.'}


def runtime_project(project, limits=None, inventory=None):
    """Produce a worker-config copy, honoring detected capacity and explicit caps.

    Unknown job memory remains one pilot. No automatic DDP selection. Detection is
    from the controller's resource namespace; alternate worker namespaces need review.
    """
    from copy import deepcopy
    p=deepcopy(project);caps=limits or {};inv=inventory or detect_resources();e=p['settings']['execution']
    cpus=max(1,int(math.floor(inv['eligible_cpu_cores'])))
    keep=int(caps.get('reserve_cpus',min(8,max(0,cpus//10))))
    usable=max(1,cpus-keep)
    reserve=float(caps.get('reserve_ram_gib',min(40,inv['ram_available_gib']*.1)))
    if reserve>=inv['ram_available_gib']:raise MemoryError('No memory remains after the selected reserve.')
    # Existing launcher subtracts this reserve from host available. Include cgroup restriction.
    import psutil
    host_available=psutil.virtual_memory().available/2**30
    e['reserve_cpus']=max(0,inv['cpu_affinity_threads']-usable)
    e['reserve_ram_gib']=max(0,host_available-inv['ram_available_gib'])+reserve
    e['host_ram_budget_gib']=min(float(e.get('host_ram_budget_gib',1e9)),inv['ram_available_gib']-reserve)
    detected=[g['uuid'] for g in inv['gpus']]
    chosen=caps.get('gpu_ids')
    if chosen is not None:
        tokens={str(x) for x in chosen};detected=[g['uuid'] for g in inv['gpus'] if g['uuid'] in tokens or str(g['index']) in tokens]
        matched={t for t in tokens if any(t in (g['uuid'],str(g['index'])) for g in inv['gpus'])}
        if matched!=tokens:raise ValueError('Requested GPU limit includes an unavailable device.')
    e['gpu_ids']=detected
    for mode in ('cpu','stardist','proseg'):
        item=e[mode];threads=int(caps.get('threads_per_job',min(int(item['threads_per_worker']),usable)))
        if not 1<=threads<=usable:raise ValueError('Threads per job exceed detected usable CPU capacity.')
        item['threads_per_worker']=threads
        requested=int(caps.get('max_workers',item['workers']))
        if requested<1:raise ValueError('Worker limit must be positive.')
        item['workers']=min(requested,max(1,usable//threads))
        if mode=='stardist':item['workers']=min(item['workers'],max(1,len(detected)))
    e['integration_threads']=min(int(e.get('integration_threads',8)),usable)
    p['_center_resource_observation']=inv
    return p,inv
