"""Read one project metadata CSV; join by explicit IDs, never file/row order.

This module uses the standard library for CSV parsing. Identifiers and text are
not coerced into numbers or NA tokens. No per-sample JSON files are generated.
Resolved values travel in the existing project snapshot to worker processes.
"""
from __future__ import annotations
import copy
import csv
import hashlib
import io
import json
import math
import re
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 'sample-metadata-csv-v1'
OPTIONS = {
    'path', 'sample_id_column', 'dataset_id_column', 'sample_key_column',
    'columns', 'rename', 'types', 'default_type', 'missing_values',
    'require_all_samples', 'allow_extra_samples', 'json_conflicts',
}
PROTECTED = {
    'sample', 'sample_id', 'sample_key', 'dataset_id', 'region', 'instance_id',
    'qc_pass', 'qc_keep', 'qc_class', 'total_counts', 'n_genes_by_counts',
    'pct_counts_mt', 'pct_counts_ribo', 'cell_area_um2', 'counts_per_um2',
    'cell_boundary_available', 'image_in_bounds', 'centroid_x', 'centroid_y',
    'local_cell_id', 'source_obs_name', 'equivalent_2um_bins',
    'pxl_row_in_fullres', 'pxl_col_in_fullres', 'array_row', 'array_col',
    'he_tissue_score', 'resolvi_eligible', 'S_score', 'G2M_score', 'phase',
    'total_counts_mt', 'total_counts_ribo',
}
PROTECTED_PREFIXES = ('vhd_', 'input__', 'analysis_', 'geometric__', 'leiden_')
TYPES = {'string', 'int', 'float', 'bool', 'auto'}


def value_digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False).encode('utf-8')).hexdigest()


def validate_field_name(name: str) -> None:
    if (not isinstance(name, str) or not name or name != name.strip() or
            name in {'.', '..'} or '/' in name or '\\' in name or
            any(ord(c) < 32 for c in name)):
        raise ValueError(f'Invalid metadata output column {name!r}; use an explicit rename.')
    if name in PROTECTED or name.startswith(PROTECTED_PREFIXES):
        raise ValueError(f'Metadata column {name!r} is reserved by the pipeline. '
                         'Select another column name with sample_metadata.rename.')


def validate_values(values: dict) -> dict:
    if not isinstance(values, dict):
        raise ValueError('Sample metadata must be a mapping of column names to scalar values.')
    for name, value in values.items():
        validate_field_name(name)
        if value is not None and type(value) not in (str, int, float, bool):
            raise ValueError(f'Metadata {name!r} must be a scalar or null, not {type(value).__name__}.')
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError(f'Metadata {name!r} contains a nonfinite value.')
        if isinstance(value, int) and not isinstance(value, bool) and not -(2**63) <= value < 2**63:
            raise ValueError(f'Metadata integer {name!r} exceeds signed int64; declare it as string.')
    return values


def _boolean_option(config, name, default):
    value = config.get(name, default)
    if not isinstance(value, bool):
        raise ValueError(f'sample_metadata.{name} must be JSON true or false, not text.')
    return value


def _identifier(value, column, line):
    # Do not trim, case-fold or infer a dataset from a directory.
    if not value or value != value.strip():
        raise ValueError(f'Metadata CSV line {line}: {column!r} must contain a nonempty '
                         'exact identifier without surrounding whitespace.')
    return value


def _parse_value(text, kind, missing, column, line):
    if text in missing:
        return None
    if kind == 'string':
        return text
    try:
        stripped = text.strip()
        if kind == 'int':
            if not re.fullmatch(r'[+-]?\d+', stripped):
                raise ValueError('expected an integer, without thousands separators')
            result = int(stripped)
            if not -(2**63) <= result < 2**63:
                raise ValueError('outside signed int64; use string for large identifiers')
            return result
        if kind == 'float':
            result = float(stripped)
            if not math.isfinite(result):
                raise ValueError('nonfinite value; explicitly declare a missing token or use string')
            return result
        if kind == 'bool':
            values = {'true': True, 'false': False, '1': True, '0': False,
                      'yes': True, 'no': False}
            if stripped.lower() not in values:
                raise ValueError('expected true/false, yes/no or 1/0')
            return values[stripped.lower()]
    except (ValueError, OverflowError) as error:
        raise ValueError(f'Metadata CSV line {line}, column {column!r}: cannot parse '
                         f'{text!r} as {kind}: {error}') from error
    raise ValueError(f'Unsupported metadata type: {kind!r}')


def _infer_type(texts):
    """Opt-in conservative whole-column inference; dates/leading zeros stay text."""
    if not texts:
        return 'string'
    if any(text != text.strip() for text in texts):
        return 'string'
    if all(t.lower() in ('true', 'false') for t in texts):
        return 'bool'
    if any(re.match(r'^[+-]?0\d', t) for t in texts):
        return 'string'
    if all(re.fullmatch(r'[+-]?(0|[1-9]\d*)', t) for t in texts):
        return 'int' if all(-(2**63) <= int(t) < 2**63 for t in texts) else 'string'
    try:
        if all(math.isfinite(float(t)) for t in texts):
            return 'float'
    except (ValueError, OverflowError):
        pass
    return 'string'


def read_metadata_csv(path, config=None):
    """Read and validate a table, retaining original headings unless renamed.

    Defaults: sample_id key, all non-key columns, string values, only empty cells
    considered missing. Explicit column types are keyed by the SOURCE heading.
    """
    config = copy.deepcopy(config or {})
    unknown = set(config) - OPTIONS
    if unknown:
        raise ValueError(f'Unknown sample_metadata options: {sorted(unknown)}')
    sid = config.get('sample_id_column', 'sample_id')
    did = config.get('dataset_id_column')
    skey = config.get('sample_key_column')
    if skey and (did or ('sample_id_column' in config and sid)):
        raise ValueError('Use sample_key_column OR sample_id_column (+ optional dataset_id_column).')
    keys = [skey] if skey else ([did, sid] if did else [sid])
    if any(not isinstance(k, str) or not k for k in keys) or len(set(keys)) != len(keys):
        raise ValueError('Supply distinct nonempty metadata join-column names.')
    raw_bytes = Path(path).read_bytes()
    if b'\x00' in raw_bytes:
        raise ValueError('Metadata CSV contains NUL bytes; export as CSV UTF-8, not UTF-16/Excel binary.')
    try:
        text = raw_bytes.decode('utf-8-sig')
    except UnicodeDecodeError as error:
        raise ValueError('Metadata CSV must be UTF-8 (Excel CSV UTF-8 is supported).') from error
    reader = csv.reader(io.StringIO(text, newline=''), strict=True)
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError('Metadata CSV is empty.') from None
    if (not header or any(not h or h != h.strip() for h in header) or
            len(header) != len(set(header))):
        raise ValueError('Metadata CSV requires unique, nonblank headers without surrounding whitespace.')
    if set(keys) - set(header):
        raise ValueError(f'Metadata join columns absent: {sorted(set(keys)-set(header))}; '
                         f'available headers: {header}. Set sample_id_column to the supplied header.')
    columns = config.get('columns')
    if columns is None:
        columns = [h for h in header if h not in keys]
    if (not isinstance(columns, list) or any(not isinstance(c, str) for c in columns) or
            len(set(columns)) != len(columns) or set(columns) - set(header)):
        raise ValueError('sample_metadata.columns must be null or a unique list of existing source headings.')
    if set(columns) & set(keys):
        raise ValueError('Join columns cannot also be metadata outputs; identifiers already exist in the master.')
    rename, declared = config.get('rename', {}), config.get('types', {})
    if not isinstance(rename, dict) or not isinstance(declared, dict):
        raise ValueError('sample_metadata.rename and types must be JSON objects.')
    if (set(rename) | set(declared)) - set(columns):
        raise ValueError('rename/types must refer to selected SOURCE columns, not output names.')
    outputs = [rename.get(c, c) for c in columns]
    for name in outputs:
        validate_field_name(name)
    if len(set(outputs)) != len(outputs):
        raise ValueError('Metadata column renaming creates duplicate output names.')
    default_type = config.get('default_type', 'string')
    if default_type not in TYPES or any(v not in TYPES for v in declared.values()):
        raise ValueError(f'Metadata types must be one of {sorted(TYPES)}.')
    missing = config.get('missing_values', [''])
    if not isinstance(missing, list) or any(not isinstance(v, str) for v in missing):
        raise ValueError('missing_values must be a list of exact text tokens.')
    rows, seen = [], set()
    for fields in reader:
        line = reader.line_num
        if not fields:  # empty physical line, not a row of empty fields
            continue
        if len(fields) != len(header):
            raise ValueError(f'Metadata CSV line {line}: expected {len(header)} fields, got '
                             f'{len(fields)}. Quote embedded commas; do not add an unnamed index.')
        row = dict(zip(header, fields))
        key = tuple(_identifier(row[k], k, line) for k in keys)
        if key in seen:
            raise ValueError(f'Duplicate metadata key {key!r} at CSV line {line}; no first/last-row guessing.')
        seen.add(key)
        rows.append((key, row, line))
    selected_types = {}
    for column in columns:
        kind = declared.get(column, default_type)
        if kind == 'auto':
            kind = _infer_type([r[column] for _, r, _ in rows if r[column] not in missing])
        selected_types[column] = kind
    values, line_map = {}, {}
    for key, row, line in rows:
        values[key] = validate_values({rename.get(c, c): _parse_value(
            row[c], selected_types[c], missing, c, line) for c in columns})
        line_map[key] = line
    report = {
        'schema': SCHEMA_VERSION, 'path': str(Path(path).absolute()),
        'sha256': hashlib.sha256(raw_bytes).hexdigest(), 'n_rows': len(rows),
        'join_columns': keys, 'source_columns': columns,
        'column_map': {c: rename.get(c, c) for c in columns},
        'types': {rename.get(c, c): selected_types[c] for c in columns},
        'missing_values': missing, 'default_type': default_type,
    }
    return values, line_map, report


def _json_metadata(path):
    if not path:
        return {}, None
    raw = Path(path).read_bytes()
    value = json.loads(raw.decode('utf-8-sig'))
    validate_values(value)
    return value, {'path': str(Path(path).absolute()), 'sha256': hashlib.sha256(raw).hexdigest()}


def metadata_for_row(row):
    """Use the immutable values in a project snapshot; legacy constructed rows work too."""
    if '_sample_metadata' in row:
        return copy.deepcopy(row['_sample_metadata'])
    return _json_metadata(row.get('metadata_json', ''))[0]


def resolve_project_metadata(rows, config, base):
    """Resolve all enabled samples once; no filesystem writes or expression reads."""
    config = copy.deepcopy(config or {})
    path = config.get('path')
    report = {'enabled': bool(path), 'n_enabled_samples': len(rows), 'matched_samples': [],
              'missing_samples': [], 'unused_metadata_keys': [], 'n_json_samples': 0}
    values, lines, source = {}, {}, None
    if path:
        from .manifest import path_value, is_remote
        path = path_value(path, Path(base))
        if is_remote(path):
            raise ValueError('sample_metadata.path requires an accessible local/mounted CSV, not s3://.')
        values, lines, source = read_metadata_csv(path, config)
        report.update(source)
    elif config and set(config) - {'path'}:
        raise ValueError('sample_metadata.path is empty but metadata options were supplied.')
    require = _boolean_option(config, 'require_all_samples', True)
    allow_extra = _boolean_option(config, 'allow_extra_samples', True)
    conflict = config.get('json_conflicts', 'error')
    if conflict not in ('error', 'csv_wins', 'json_wins'):
        raise ValueError('json_conflicts must be error, csv_wins or json_wins.')
    key_kind = ('sample_key' if config.get('sample_key_column') else
                'composite' if config.get('dataset_id_column') else 'sample_id')
    used, out = set(), []
    simple_ids = [r['sample_id'] for r in rows]
    if path and key_kind == 'sample_id' and len(simple_ids) != len(set(simple_ids)):
        raise ValueError('Enabled samples repeat sample_id across datasets. Configure dataset_id_column '
                         'or sample_key_column, or use unique sample IDs; path names are not join keys.')
    for row in rows:
        key = ((row['sample_key'],) if key_kind == 'sample_key' else
               (row['dataset_id'], row['sample_id']) if key_kind == 'composite' else (row['sample_id'],))
        legacy, json_source = _json_metadata(row.get('metadata_json', ''))
        csv_values = values.get(key, {})
        overrides = []
        if path:
            if key in values:
                used.add(key); report['matched_samples'].append(row['sample_key'])
            else:
                report['missing_samples'].append(row['sample_key'])
        merged = dict(legacy)
        for name, value in csv_values.items():
            if name in merged and (merged[name] != value or
                    (isinstance(merged[name], bool) != isinstance(value, bool))):
                if conflict == 'error':
                    raise ValueError(f"{row['sample_key']}: metadata conflict for {name!r} between CSV "
                                     "and metadata_json. Remove the duplicate source or explicitly set "
                                     "json_conflicts.")
                overrides.append(name)
                if conflict == 'json_wins':
                    continue
            merged[name] = value
        validate_values(merged)
        if json_source:
            report['n_json_samples'] += 1
        provenance = {
            'schema': SCHEMA_VERSION, 'sample_key': row['sample_key'],
            'metadata_signature': value_digest(merged), 'matched_csv_row': key in values,
            'csv': None if source is None else {**source, 'line': lines.get(key), 'join_value': list(key)},
            'json': json_source, 'json_conflicts': conflict, 'conflict_columns': overrides,
        }
        new = dict(row)
        new['_sample_metadata'] = merged
        new['_sample_metadata_provenance'] = provenance
        out.append(new)
    report['unused_metadata_keys'] = [list(k) for k in values if k not in used]
    report['n_matched_samples'] = len(report['matched_samples'])
    if require and report['missing_samples']:
        raise ValueError('Metadata rows missing for enabled samples: ' + ', '.join(report['missing_samples']) +
                         '. Match IDs exactly; the table row order does not matter.')
    if not allow_extra and report['unused_metadata_keys']:
        raise ValueError(f"Metadata has unmatched rows: {report['unused_metadata_keys']}. "
                         "Set allow_extra_samples=true for a subset pilot.")
    return out, report


def metadata_preview(project):
    """Small per-sample table, not a bin/cell matrix; suitable for notebook 00."""
    import pandas as pd
    return pd.DataFrame([{'sample_key': r['sample_key'], 'sample_id': r['sample_id'],
                          **metadata_for_row(r)} for r in project['rows']])
