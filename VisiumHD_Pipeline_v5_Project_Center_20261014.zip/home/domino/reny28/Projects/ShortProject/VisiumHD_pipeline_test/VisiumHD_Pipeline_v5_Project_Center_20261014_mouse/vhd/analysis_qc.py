"""Non-destructive analysis QC on declared raw counts before feature selection.

Masters remain unmodified. Keyed sidecars are consumed by integration preparation.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from .core import digest,file_stamp,dump_json,integer_csr,sample_paths,stage_lock


def profile(cfg,spec):
    p=dict(cfg.get('analysis_qc',{}));p.update(spec.get('_analysis_qc',{}))
    species=p.get('species') or spec.get('metadata',{}).get('species')
    aliases={'homo_sapiens':'human','homo sapiens':'human','mus_musculus':'mouse','mus musculus':'mouse'}
    species=aliases.get(str(species).lower(),str(species).lower()) if species else None
    if p.get('enabled',False):
        for key,default in [('min_counts',3),('min_genes',1)]:
            value=p.get(key,default)
            if isinstance(value,bool) or not np.isfinite(float(value)) or int(value)!=float(value):raise ValueError(f'{key} must be an integer.')
            p[key]=int(value)
        if p['min_counts']<1 or p['min_genes']<1:raise ValueError('Analysis count/gene cell minima must be positive.')
        if p.get('max_pct_mt') is None:
            if species not in ('human','mouse'):raise ValueError('Set analysis_qc.species or metadata species to human/mouse, or give explicit max_pct_mt.')
            p['max_pct_mt']=20. if species=='human' else 10.
        if not 0<float(p['max_pct_mt'])<=100:raise ValueError('Invalid max_pct_mt percentage.')
        if p.get('missing_mt_policy','error') not in ('error','skip_explicit'):raise ValueError('missing_mt_policy: error or skip_explicit.')
    p['species']=species
    return p


def cell_metrics(counts,obs,var,p):
    x=integer_csr(counts)
    if not obs.index.is_unique or not var.index.is_unique:raise ValueError('QC requires unique cell/feature IDs.')
    symbols=var[p.get('gene_symbol_column','gene_symbol')] if p.get('gene_symbol_column','gene_symbol') in var else pd.Series(var.index,index=var.index)
    mt=symbols.astype('string').str.upper().str.startswith('MT-').fillna(False).to_numpy(bool)
    if p.get('mt_genes'):
        mt=np.asarray(symbols.astype(str).isin(p['mt_genes'])|var.index.isin(p['mt_genes']),bool)
    n_mt=int(mt.sum())
    if not n_mt and p.get('missing_mt_policy','error')=='error':
        raise ValueError('No mitochondrial features recognized. Supply correct gene symbols/mt_genes; true zero cannot be inferred from absent features. Explicit skip_explicit is available for known panels.')
    total=np.asarray(x.sum(axis=1,dtype=np.int64)).ravel();genes=np.asarray((x>0).sum(axis=1)).ravel()
    mt_counts=np.asarray(x[:,mt].sum(axis=1,dtype=np.int64)).ravel()
    percent=np.divide(100.*mt_counts,total,out=np.full(len(obs),np.nan),where=total>0) if n_mt else np.full(len(obs),np.nan)
    if p.get('respect_existing_qc',True):
        if 'qc_pass' not in obs or not pd.api.types.is_bool_dtype(obs['qc_pass']):raise ValueError('Expected stored Boolean qc_pass for existing eligibility.')
        legacy=obs.qc_pass.fillna(False).to_numpy(bool)
    else:legacy=np.ones(len(obs),bool)
    out=pd.DataFrame(index=obs.index)
    out['analysis_total_counts']=total;out['analysis_n_genes']=genes;out['analysis_pct_counts_mt']=percent
    out['analysis_mt_features_recognized']=n_mt;out['analysis_mt_filter_applied']=bool(n_mt)
    out['analysis_fail_existing_qc']=~legacy
    out['analysis_fail_counts']=total<int(p.get('min_counts',3))
    out['analysis_fail_genes']=genes<int(p.get('min_genes',1))
    out['analysis_fail_mito']=(percent>=float(p['max_pct_mt'])) if n_mt else False
    out['analysis_invalid_metrics']=(total<=0)|((~np.isfinite(percent)) if n_mt else False)
    failures=[c for c in out if c.startswith('analysis_fail_') or c=='analysis_invalid_metrics']
    out['analysis_qc_pass']=~out[failures].any(axis=1)
    return out,{'n_cells':len(obs),'n_pass':int(out.analysis_qc_pass.sum()),'n_mt_features':n_mt,
                'mt_filter_applied':bool(n_mt),'mt_comparison':'strictly_less_than','full_feature_count':len(var),
                **{c:int(out[c].sum()) for c in failures}}


def gene_minimum(cfg):
    value=cfg.get('analysis_qc',{}).get('min_cells_per_gene',3)
    if isinstance(value,bool) or not np.isfinite(float(value)) or int(value)!=float(value) or int(value)<1:
        raise ValueError('min_cells_per_gene must be a positive integer.')
    return int(value)


def source_signature(cfg):
    profiles={s['sample']:profile(cfg,s) for s in cfg['samples']}
    species={p.get('species') for p in profiles.values() if p.get('species')}
    if len(species)>1:raise ValueError('Do not integrate human and mouse under one group; ortholog mapping is not implemented.')
    return digest({'algorithm':'analysis-qc-v4-full-counts','profiles':profiles,
       'sources':{s['sample']:file_stamp(sample_paths(cfg,s)['store']/'tables/cells') for s in cfg['samples']},
       'gene_min_cells':gene_minimum(cfg)})


def run_analysis_qc(cfg):
    from .integration import integration_dir
    from .io import load_table
    p=integration_dir(cfg)/'analysis_qc';p.mkdir(exist_ok=True)
    sig=source_signature(cfg);receipt=p/'complete.json'
    if receipt.exists():
        old=json.loads(receipt.read_text())
        if old.get('signature')==sig and all(file_stamp(Path(f))==stamp for f,stamp in old['outputs'].items()):return old
        raise RuntimeError('Analysis QC inputs/profile changed. Use a new integration.analysis_id; master objects need no rebuild.')
    summaries=[];detection=None;outputs=[]
    with stage_lock(p,'analysis_qc'):
        for spec in cfg['samples']:
            rules=profile(cfg,spec)
            if not rules.get('enabled'):raise ValueError('analysis_qc must be enabled for this stage.')
            a=load_table(sample_paths(cfg,spec)['store'],'cells')
            obs,summary=cell_metrics(a.X,a.obs,a.var,rules)
            f=p/(spec['sample']+'.parquet')
            if f.exists():raise FileExistsError(f'Untracked partial QC sidecar; inspect or select new analysis_id: {f}')
            obs.to_parquet(f);outputs.append(f)
            mask=obs.analysis_qc_pass.to_numpy(bool)
            counts=pd.Series(np.asarray((a.X[mask]>0).sum(axis=0)).ravel().astype(np.int64),index=a.var_names.astype(str))
            detection=counts if detection is None else detection.add(counts,fill_value=0)
            bysample=p/(spec['sample']+'_gene_detection.csv');counts.rename('n_retained_cells_detecting').to_csv(bysample);outputs.append(bysample)
            summaries.append({'sample':spec['sample'],**summary})
            from .plots import standard_qc_plots
            display=obs.rename(columns={'analysis_total_counts':'total_counts','analysis_n_genes':'n_genes_by_counts','analysis_pct_counts_mt':'pct_counts_mt'})
            standard_qc_plots(display,p/'plots',spec['sample'],dpi=cfg['plots']['dpi'])
            del a
            import gc;gc.collect()
        minimum=gene_minimum(cfg)
        genes=detection.astype(np.int64).rename('n_retained_cells_detecting').to_frame()
        genes['pass_min_cells']=genes.n_retained_cells_detecting>=minimum;genes.index.name='gene_id'
        f=p/'gene_detection.csv';genes.to_csv(f);outputs.append(f)
        f=p/'sample_summary.csv';pd.DataFrame(summaries).to_csv(f,index=False);outputs.append(f)
        record={'signature':sig,'profiles':{s['sample']:profile(cfg,s) for s in cfg['samples']},
            'gene_min_cells':minimum,'gene_scope':'retained cells within integration group; assayed-gene intersection still applies for HVGs',
            'master_modified':False,'outputs':{str(f):file_stamp(f) for f in outputs},'summary':summaries}
        dump_json(record,receipt)
    return record


def require_analysis_qc(cfg):
    from .integration import integration_dir
    if not cfg.get('analysis_qc',{}).get('enabled',False):return None
    p=integration_dir(cfg)/'analysis_qc';f=p/'complete.json'
    if not f.exists():raise RuntimeError('Run notebook 07A Analysis QC before integration preparation.')
    rec=json.loads(f.read_text())
    if rec.get('signature')!=source_signature(cfg):raise RuntimeError('Analysis QC signature is stale. Use a new analysis_id and rerun 07A.')
    for filename,stamp in rec['outputs'].items():
        if file_stamp(filename)!=stamp:raise RuntimeError(f'Analysis QC sidecar changed: {filename}')
    return rec


def analysis_mask(cfg,sample,index):
    from .integration import integration_dir
    frame=pd.read_parquet(integration_dir(cfg)/'analysis_qc'/(sample+'.parquet'))
    if not frame.index.equals(index):raise ValueError('Analysis QC sidecar IDs/order do not match the master.')
    return frame.analysis_qc_pass.to_numpy(bool)
