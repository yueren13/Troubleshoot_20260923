# Implementation scope and remaining validation

## Implemented in this candidate
- Fixed-reference H&E extraction/scaling/combination, pixel-center sampling, strict
  numerical inputs, explicit missingness, fixed-scale maps/previews and provenance.
- Configurable new QC thresholds; accepted legacy QC reuse without resegmentation.
- Optional polygon/scalar-image asset CSV, explicit transforms, previews, source-bound
  approval, fresh assignment, source-owned column replacement and coverage reporting.
- ImageScope negative-region holes retained for Polygon and MultiPolygon; invalid
  geometry fails unless deliberate parser-level repair is requested and audited.
- Independent tissue/exclusion memberships versus mutually exclusive categories.
- Bin-center prior filtering, explicit optional Proseg input-bin filtering, separate
  base QC, reason flags, whole-nucleus decision records.
- Bin-to-cell voting/ties/dominant fractions/coverage, Boolean fractions and per-variable
  sum/mean/median, without replacing RNA counts with geometric aggregation.
- Mutable canonical master, selective element/transform/metadata persistence,
  retained old/incoming backups and explicit interrupted-write recovery.
- Separate retained work/cache and scratch paths, named approved roots, optional
  existing-root/sentinel checks, no username or mount manipulation.
- Verified scVI saved-model handoff, fingerprinted receipts, no silent partial reuse.
- Existing CPU/GPU/DDP/RAPIDS/Dask launchers and Leiden 0.1–1.0/UMAP/palette behavior.
- Optional primary-cell metadata writeback versus a count-free cells_scvi companion.
- Optional legacy display-normalizer return-contract fixes (raw/normalized/both).

## Not claimed / not silently substituted
- Exact historical Step03 classification: full original cutoffs/call settings were
  unavailable. Fresh cutoffs remain null until explicitly selected.
- Physical-area-weighted image aggregation, image-pixel pooled median, or integrated
  protein quantity: current image→bin readout is nearest/linear CENTER sampling.
  Summing center values is not an area integral. New measurement types need explicit
  implementation and validation, not a misleading method alias.
- Nuclear area-overlap gating or hard Proseg growth barriers: prior gating uses sampled
  bin-center support/fractions. Mask clipping is not claimed.
- Automatic registration of adjacent sections, arbitrary nonrigid warps, automatic
  biological annotation, or proof that every slide shares a valid tissue threshold.
- Reusing an arbitrary legacy master as canonical without review; changing counts or
  populations through the metadata-only API; automatic cleanup or crash-proof atomicity.
- Fully out-of-core import/scVI training, pooled GPU memory, one-slide multi-GPU
  StarDist, GPU Proseg, or distributed multi-GPU UMAP. Existing launcher limitations
  remain explicit. PNG input is in-memory; TIFF/NPY/Zarr use bounded raster access.
- Quantitative Macenko display normalization: the display compatibility helper is
  intentionally not the QC source and remains eager.

## Target pilot still needed
Real AnnData/SpatialData roundtrips, legacy-format stores, fullres/hires/asset overlays,
mounted-path recovery/capacity behavior, one real scVI train→infer run, then independent
DDP and RAPIDS/Dask resource tests. CPU synthetic tests do not establish biological
accuracy, GPU speed, clinical validity, or institutional storage compliance.
