# Validation

- PASS: Selected obs-only loading invokes read-only unconsolidated Zarr access (explicit backend substitute).
- PASS: Quiescence acknowledgement required.
- PASS: Saved fullres-to-image transform applied (not silently assumed identity).
- PASS: Existing writer locks and unresolved transaction journals block metadata review without alteration.
- PASS: ID-aligned sidecar parity detects changed values and missing bins in shuffled/chunked data (Arrow stand-in).
- PASS: Generated original-coordinate overview/ROI/HE-only plots and sampling audit with synthetic H&E reader.
- PASS: StarDist diagnostic tolerates absent worker status/log and creates a separate evidence ZIP without a launch.
- PASS: Unrelated count-file sentinel preserved; no expression payload access during mocked metadata read.
- PASS: Notebook schema and all code-cell syntax validated.

## Limitations
The actual source reports/code were inspected, but no user-server data or running process was accessed.
No StarDist or transfer execution, pipeline change, or native review approval was performed.
Zarr, AnnData, PyArrow and OpenSlide are unavailable in this authoring runtime. Tests use explicitly
identified in-memory backend substitutes for the selected metadata API, Arrow batches, and H&E image
reader. Real Zarr/AnnData/Parquet I/O and real SVS/registration behavior remain on-server checks.
The plotted summary/selection/transform routines and Matplotlib figure generation were exercised.
Synthetic renders use 80 dpi for validation speed; the delivered notebook defaults to 300 dpi.
