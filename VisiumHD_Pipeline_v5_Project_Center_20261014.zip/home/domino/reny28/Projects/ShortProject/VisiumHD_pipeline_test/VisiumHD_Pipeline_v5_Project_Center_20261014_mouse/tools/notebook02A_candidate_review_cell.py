# Requires the existing `audit`, `PROJECT`, and `ROOT` in notebook 02A.
# Explicitly writes only a NEW report directory; no accepted repairs are applied.
from pathlib import Path
import runpy
from vhd.control.manifest import sample_layout

reviewer = runpy.run_path(
    str(Path(ROOT) / "tools" / "review_annotation_candidates.py")
)
row = next(r for r in PROJECT["rows"] if r["sample_id"] == "BM0164135A_s1_A1")
paths = sample_layout(PROJECT, row)

review = reviewer["write_candidate_review"](
    audit,
    output_parent=Path(paths["report"]),
    sample_key=row["sample_key"],
    asset_id="pathology",
    compare_structure=False,
)
print("Candidate-only report:", review["report_dir"])

# Display the two categories likely to matter first for the user's QC review.
# This DISPLAY selection neither approves these categories nor excludes others.
from IPython.display import Image, display
folder = Path(review["report_dir"])
for source in review["sources"]:
    for region in source["region_candidates"]:
        if region["category"] in {"Tissue", "Anthropotic"}:
            print(region["category"], "region", region["region_id"],
                  "NegativeROA:", region["negative_region"])
            for filename in region["previews"]:
                display(Image(filename=str(folder / filename), width=1000))
