"""One-time Navli-82 destination correction; not a pipeline source patch.

preview(): read-only. save_destination(): managed config/history only.
initialize_bin_master(): explicitly launches the native assemble_bins worker at
an empty NEW destination. Neither operation writes to or renames the old master.
Read README.md. Use the existing idle ProjectCenter; no new controller is made.
"""
from __future__ import annotations

import ast
from copy import deepcopy
from datetime import datetime, timezone
import gc
import hashlib
import importlib
import inspect
import json
from pathlib import Path
import textwrap
import uuid

VERSION = 'vhd-navli-master-destination-20261015-r1'
SAMPLE = 'Project__Navli-82'
OLD_SAMPLE = 'Project__BM0164135A_s1_A1'
PRE = {'ingest_raw', 'measure_he', 'bin_qc'}


def _digest(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


def _file(path):
    p = Path(path)
    s = p.stat()
    return {'path': str(p), 'size': s.st_size, 'mtime_ns': s.st_mtime_ns}


def _json(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, default=str)
        f.write('\n')


def _center(pc):
    if pc is None:
        found = {id(x): x for x in gc.get_objects()
                 if type(x).__name__ == 'ProjectCenter'
                 and type(x).__module__ == 'vhd.center.controller'}
        if len(found) != 1:
            raise RuntimeError('Pass the intended existing pc; could not identify exactly one Center.')
        pc = next(iter(found.values()))
    if type(pc).__name__ != 'ProjectCenter' or type(pc).__module__ != 'vhd.center.controller':
        raise TypeError('Expected the existing vhd.center.controller.ProjectCenter.')
    return pc


def _modules():
    return {name: importlib.import_module(name) for name in (
        'vhd.control.manifest', 'vhd.center.resources', 'vhd.compute.launch',
        'vhd.annotations.discovery')}


def _guard(pc):
    guards = json.loads(Path(__file__).with_name('source_guards.json').read_text())
    bad = []
    for name, expected in guards.items():
        if name.startswith('ProjectCenter.'):
            fn = getattr(type(pc), name.split('.', 1)[1])
        else:
            module, attr = name.rsplit('.', 1)
            fn = getattr(importlib.import_module(module), attr)
        src = ast.dump(ast.parse(textwrap.dedent(inspect.getsource(fn))), include_attributes=False)
        actual = hashlib.sha256(src.encode()).hexdigest()
        if actual != expected:
            bad.append(name)
    if bad:
        raise RuntimeError('Relevant installed code differs from reviewed source; no change: ' + ', '.join(bad))


def _idle(d):
    active = []
    for slot in ('jobs', 'group_jobs'):
        for key, records in d.get(slot, {}).items():
            for name, record in records.items():
                if record.get('status') == 'running':
                    active.append(f'{key}/{name}')
    if active:
        raise RuntimeError('Recorded running jobs; inspect them, do not clear them: ' + ', '.join(active))
    import psutil
    found = []
    for p in psutil.process_iter(['pid', 'cmdline']):
        try:
            args = p.info['cmdline'] or []
            if 'vhd.compute.worker' in args:
                found.append(p.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    if found:
        raise RuntimeError('Visible VHD workers remain active: ' + str(found))
    # A local check cannot establish inactivity on other hosts or PID namespaces.


def _no_overlap(a, b):
    a, b = Path(a).resolve(), Path(b).resolve()
    if a == b or a in b.parents or b in a.parents:
        raise ValueError(f'Overlapping paths are not allowed: {a} versus {b}')


def _new_target(path):
    p = Path(path)
    if not p.is_absolute() or p.suffix != '.zarr':
        raise ValueError('Use an absolute, new .zarr destination.')
    if not p.parent.is_dir():
        raise FileNotFoundError(f'Destination parent must already exist: {p.parent}')
    for q in (p, *p.parents):
        if q.is_symlink():
            raise ValueError(f'Refuse symlinked destination components: {q}')
    for suffix in ('', '.partial', '.vhd_writer.lock', '.vhd_transactions'):
        q = p.with_name(p.name + suffix)
        if q.exists() or q.is_symlink():
            raise FileExistsError(f'Destination or recovery evidence exists; do not overwrite/adopt/delete it: {q}')


def _identity(store):
    p = Path(store)
    if (p / 'zarr.json').is_file():
        f = p / 'zarr.json'
        raw = f.read_bytes()
        attrs = json.loads(raw).get('attributes', {})
    elif (p / '.zattrs').is_file():
        f = p / '.zattrs'
        raw = f.read_bytes()
        attrs = json.loads(raw)
    else:
        raise FileNotFoundError(f'No readable root identity metadata: {p}')
    return {'sample': attrs.get('sample'), 'metadata_path': str(f),
            'metadata_sha256': hashlib.sha256(raw).hexdigest()}


def _prerequisites(pc, d, modules):
    m = modules['vhd.control.manifest']
    row = pc.row(SAMPLE, d['project'])
    if row['sample_id'] != 'Navli-82' or row['stage'] != 'raw':
        raise ValueError('This helper is scoped to the raw-input Navli-82 sample.')
    paths = m.sample_layout(d['project'], row)
    jobs = d.get('jobs', {}).get(SAMPLE, {})
    for action in PRE:
        if jobs.get(action, {}).get('status') != 'complete' or not pc._done(d, row, action):
            raise RuntimeError(f'Required native completion check did not pass: {action}')
    unexpected = {a: j.get('status') for a, j in jobs.items()
                  if a not in PRE | {'transfer_assets'} }
    if unexpected:
        raise RuntimeError(f'Unexpected stage history; no automatic migration: {unexpected}')
    if jobs.get('transfer_assets', {}).get('status') not in (None, 'failed'):
        raise RuntimeError('Transfer is not an uncompleted stage; no automatic migration.')
    if d.get('reviews', {}).get(SAMPLE, {}).get('review_assets', {}).get('decision') != 'no_selected_outputs':
        raise RuntimeError('Expected the already-saved no_selected_outputs review.')
    plan = modules['vhd.annotations.discovery'].preview_selected_plan(d['project'], [SAMPLE], require_approval=False)
    if len(plan) != 1 or plan[0]['active_outputs'] != 0 or plan[0]['prior_filter'].get('enabled', False):
        raise RuntimeError('Expected no external measurements and no annotation-derived prior.')
    for name in ('master_sources.json', 'storage_manifest.json', 'assets_transfer.json'):
        if (paths['report'] / name).exists():
            raise RuntimeError(f'Existing master/transfer receipt needs separate review: {name}')
    for name in ('bins_annotated_obs.parquet', 'prior_raw.npy', 'prior_qc.npy',
                 'cells_qc.h5ad', '03_stardist_complete.json', '04_proseg_complete.json'):
        if (paths['work'] / name).exists():
            raise RuntimeError(f'Downstream output exists; no automatic migration: {name}')
    if list(paths['work'].glob('.*lock*')):
        raise RuntimeError('A work lock exists; inspect ownership rather than deleting it.')
    for q in ('bins_raw.h5ad', 'bins_qc_obs.parquet', 'geometry.json'):
        if not (paths['work'] / q).is_file():
            raise FileNotFoundError(paths['work'] / q)
    return row, paths


def _complete_contracts(pc, d):
    out = {}
    for row in d['project']['rows']:
        for action, job in d.get('jobs', {}).get(row['sample_key'], {}).items():
            if job.get('status') == 'complete':
                out[row['sample_key'] + '/' + action] = pc._contract(d, row, action)
    return out


def _plan(pc, new_master, modules):
    d = pc.snapshot()
    _idle(d)
    row, paths = _prerequisites(pc, d, modules)
    old = paths['store']
    old_id = _identity(old)
    if old_id['sample'] != OLD_SAMPLE:
        raise ValueError('Old master identity is not the reviewed BM0164135A_s1_A1 case; stop.')
    new = Path(new_master) if new_master else old.with_name('Navli-82.zarr')
    _new_target(new)
    _no_overlap(old, new)
    _no_overlap(pc.workspace, new)
    m = modules['vhd.control.manifest']
    proposed = deepcopy(d)
    target = pc.row(SAMPLE, proposed['project'])
    target['master_store'] = str(new)
    for other in d['project']['rows']:
        if other['sample_key'] != SAMPLE:
            _no_overlap(new, m.sample_layout(d['project'], other)['store'])
        for field in ('spaceranger_outs', 'segmentation_image', 'bin_input', 'cell_input', 'cell_boundaries'):
            if other.get(field):
                _no_overlap(new, other[field])
    m.check_policy(proposed['project'])
    after_paths = m.sample_layout(proposed['project'], target)
    if any(after_paths[k] != paths[k] for k in paths if k != 'store'):
        raise RuntimeError('Destination change unexpectedly changed working paths.')
    before_contracts = _complete_contracts(pc, d)
    if before_contracts != _complete_contracts(pc, proposed):
        raise RuntimeError('Destination correction affects completed-stage contracts; stop.')
    result = dict(schema=VERSION, sample=SAMPLE, workspace=str(pc.workspace), revision=d['revision'],
                  state_digest=_digest(d), old_master=str(old), old_identity=old_id,
                  new_master=str(new), old_row_master_store=row.get('master_store'),
                  changed_field='master_store', work=str(paths['work']), report=str(paths['report']),
                  source_stamps=[_file(paths['work']/x) for x in ('bins_raw.h5ad','bins_qc_obs.parquet','geometry.json')],
                  completed_contracts=before_contracts, scientific_files_written=False,
                  configuration_changed=False)
    result['plan_digest'] = _digest(result)
    return result, d, proposed


def preview(controller=None, *, new_master=None):
    """Validate the NEW destination without modifying code, config, or stores."""
    pc = _center(controller)
    _guard(pc)
    plan, _, _ = _plan(pc, new_master, _modules())
    print(json.dumps(plan, indent=2, default=str))
    print('PREVIEW ONLY. Old master is not moved, renamed, or modified.')
    return plan


def save_destination(controller, plan, *, confirmed_all_sessions_idle=False,
                     confirmed_new_destination=False, reviewer=''):
    """Save only the reviewed per-sample destination through the native commit."""
    if confirmed_all_sessions_idle is not True or confirmed_new_destination is not True or not str(reviewer).strip():
        raise PermissionError('Confirm idle sessions/new destination and supply reviewer.')
    pc = _center(controller)
    _guard(pc)
    if plan.get('plan_digest') != _digest({k:v for k,v in plan.items() if k!='plan_digest'}):
        raise ValueError('Preview was edited; regenerate it.')
    with pc.store.exclusive():
        fresh, before, after = _plan(pc, plan['new_master'], _modules())
        if fresh != plan:
            raise RuntimeError('State, files, or proposal changed since preview; regenerate preview.')
        audit = Path(pc.workspace) / 'master_destination_corrections'
        if audit.is_symlink():
            raise ValueError('Refuse symlinked audit directory.')
        audit = audit / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'_'+uuid.uuid4().hex[:8])
        audit.mkdir(parents=True, exist_ok=False)
        _json(audit/'plan.json', plan)
        _json(audit/'state_before.json', before)
        for field, basename in (('manifest_path','sample_manifest_before.txt'), ('settings_path','settings_before.txt')):
            (audit/basename).write_bytes(Path(before['project'][field]).read_bytes())
        receipt = {'schema':VERSION, 'phase':'prepared', 'sample':SAMPLE,
                   'workspace':str(pc.workspace), 'old_master':plan['old_master'], 'new_master':plan['new_master'],
                   'source_stamps':plan['source_stamps'], 'old_identity':plan['old_identity'],
                   'reviewer':str(reviewer).strip(), 'audit_dir':str(audit)}
        _json(audit/'prepared.json', receipt)
        try:
            pc._commit(after, f"{VERSION}: {reviewer} corrected {SAMPLE} master destination; old master retained; no data migration.", export=True)
            saved = pc.snapshot()
            if saved['project'] != after['project']:
                raise RuntimeError('Saved project differs from the proposed project.')
            for field in ('jobs','group_jobs','reviews','drafts','resume','endpoints','analysis_settings','resource_limits'):
                if before.get(field) != saved.get(field):
                    raise RuntimeError(f'Unexpected protected-state change: {field}')
            if _complete_contracts(pc, saved) != plan['completed_contracts']:
                raise RuntimeError('Completed-stage contracts changed unexpectedly.')
            if _identity(plan['old_master']) != plan['old_identity']:
                raise RuntimeError('Old master root metadata changed concurrently; inspect separately.')
            if Path(plan['new_master']).exists():
                raise RuntimeError('New destination appeared before initialization; stop.')
            receipt.update(phase='destination_saved', revision=saved['revision'],
                           state_digest=_digest(saved), pipeline_code_changed=False,
                           master_created=False, scientific_jobs_launched=False)
            receipt['receipt_digest'] = _digest(receipt)
            _json(audit/'receipt.json', receipt)
        except BaseException as exc:
            _json(audit/'save_error.json', {'error':repr(exc), 'note':'No store was written by this helper. Do not restore an old controller snapshot blindly.'})
            raise RuntimeError(f'Destination save did not verify cleanly. Preserve {audit}; do not retry or restore state blindly.') from exc
    print(json.dumps(receipt, indent=2, default=str))
    return receipt


def initialize_bin_master(controller, receipt, *, confirmed_no_other_readers_or_writers=False):
    """Launch ONE native CPU assemble_bins worker at the verified, empty new path.

    This creates a real SpatialData master from existing prepared Navli bins/H&E;
    it may be expensive. It neither imports external annotation assets nor runs
    StarDist/Proseg. Native storage policy, worker locks and validation remain.
    On failure, retain partial products and logs; this method refuses blind retry.
    """
    if confirmed_no_other_readers_or_writers is not True:
        raise PermissionError('Explicitly confirm exclusive access before creating a new master.')
    pc = _center(controller)
    _guard(pc)
    if receipt.get('phase') != 'destination_saved' or receipt.get('receipt_digest') != _digest({k:v for k,v in receipt.items() if k!='receipt_digest'}):
        raise ValueError('Pass the unchanged successful save_destination receipt.')
    with pc.store.exclusive():
        d = pc.snapshot()
        _idle(d)
        if str(pc.workspace) != receipt['workspace']:
            raise RuntimeError('Wrong workspace.')
        # UI refresh may advance revision; inspect current prerequisites rather than
        # requiring an exact revision for this separately confirmed scientific step.
        mods = _modules()
        row, paths = _prerequisites(pc, d, mods)
        if str(paths['store']) != receipt['new_master']:
            raise RuntimeError('Active destination differs from the saved correction.')
        _new_target(paths['store'])
        _no_overlap(paths['store'], receipt['old_master'])
        if [_file(paths['work']/x) for x in ('bins_raw.h5ad','bins_qc_obs.parquet','geometry.json')] != receipt['source_stamps']:
            raise RuntimeError('Prepared sources changed; no initialization.')
        if _identity(receipt['old_master']) != receipt['old_identity']:
            raise RuntimeError('Old master root metadata changed since correction; inspect separately.')
        mods['vhd.control.manifest'].check_policy(d['project'])
        cfg, _ = mods['vhd.control.manifest'].row_config(d['project'], row)
        if cfg['storage'].get('single_writer_ack') is not True:
            raise PermissionError('The native storage single_writer_ack is not set. Review the existing Center write-destination acknowledgement first.')
        runtime, _ = mods['vhd.center.resources'].runtime_project(deepcopy(d['project']), d.get('resource_limits',{}))
        rr = next(r for r in runtime['rows'] if r['sample_key']==SAMPLE)
        if 'assemble_bins' not in rr['_plan']:
            raise RuntimeError('Native sample plan does not include assemble_bins; no implicit plan edit.')
        audit = Path(receipt['audit_dir'])
        intent = audit/'initialization_intent.json'
        if intent.exists():
            raise RuntimeError('An initialization was already attempted. Inspect its worker status and partial outputs before any retry.')
        _json(intent, {'action':'assemble_bins','sample':SAMPLE,'store':str(paths['store']), 'started_at':datetime.now(timezone.utc).isoformat()})
        print('Creating a NEW Navli-82 bin master; no original master modification. This can take time.')
        print('Native worker log:', paths['report']/'worker_assemble_bins.log')
        try:
            result = mods['vhd.compute.launch'].launch_samples(runtime, 'assemble_bins', execute=True, sample_keys=[SAMPLE])
            identity = _identity(paths['store'])
            if identity['sample'] != SAMPLE:
                raise RuntimeError('New master identity does not match Navli-82.')
            worker = json.loads((paths['report']/'status_assemble_bins.json').read_text())
            if worker.get('status') != 'complete':
                raise RuntimeError('Native worker did not record a completed bin assembly.')
            sources = json.loads((paths['report']/'master_sources.json').read_text())
            if sources.get('bin_source',{}).get('path') != str(paths['work']/'bins_raw.h5ad'):
                raise RuntimeError('Master receipt does not name Navli prepared bins.')
            if not (paths['report']/'storage_manifest.json').is_file():
                raise RuntimeError('Native validated storage receipt is absent.')
            if _identity(receipt['old_master']) != receipt['old_identity']:
                raise RuntimeError('Old master root metadata changed concurrently.')
            end = {'phase':'native_bin_master_complete','sample':SAMPLE,'store':str(paths['store']),
                   'native_result':result,'identity':identity,'note':'Native worker status/receipts, not a fabricated controller completion. Run transfer via the normal controller next.'}
            _json(audit/'initialization_complete.json', end)
        except BaseException as exc:
            _json(audit/'initialization_error.json', {'error':repr(exc),'preserve_partial_outputs':True})
            raise
    print(json.dumps(end, indent=2, default=str))
    return end
