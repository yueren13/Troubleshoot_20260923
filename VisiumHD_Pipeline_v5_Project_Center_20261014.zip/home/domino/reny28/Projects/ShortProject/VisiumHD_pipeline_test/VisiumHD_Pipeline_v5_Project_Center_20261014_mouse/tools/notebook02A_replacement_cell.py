# Use this INSTEAD OF launch_samples(..., "import_assets", ...) to inspect alignment.
# The existing initialization cell must already have defined ROOT and PROJECT.
# This writes only a new visual-review report; it does NOT write/import to a master.
from pathlib import Path
import runpy

viewer = runpy.run_path(str(Path(ROOT) / "tools" / "preview_assets_on_he.py"))
review = viewer["preview_assets_on_he"](
    PROJECT,
    sample_keys=["BM0164135A_s1_A1"],  # Or your existing SAMPLE_KEYS.
    max_side=2000,
    show=True,
)
display(review)
