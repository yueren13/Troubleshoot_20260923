"""Explicit annotation geometry, coverage, and metadata transfer. No RNA reaggregation."""
from .geometry import read_imagescope_annotation_xml, classify_polygons
from .transfer import aggregate_annotations, segmentation_decisions
