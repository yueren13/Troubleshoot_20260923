"""SpatialData-compatible geometry for non-affine grids: fullres quadrilaterals.

Polygons are created in bounded batches, but the final GeoDataFrame is eager.
No homography is represented as SpatialData Affine; its vertices are materialized.
"""
from __future__ import annotations
import numpy as np
from .projective_grid import grid_corners, homography, is_projective, _domain_audit, project_xy

REGION = 'bins_2um_polygons'


def bin_instance_ids(obs, geometry):
    height, width = map(int, geometry['grid_shape'])
    if height < 1 or width < 1 or height * width >= np.iinfo(np.uint32).max:
        raise ValueError('Capture grid cannot use unique positive uint32 bin IDs.')
    r0, c0 = np.asarray(obs['array_row']), np.asarray(obs['array_col'])
    if not len(r0) or len(r0) != len(c0):raise ValueError('Empty or mismatched bin indices.')
    if not np.isfinite(r0).all() or not np.isfinite(c0).all() or not np.equal(r0, np.rint(r0)).all() or not np.equal(c0, np.rint(c0)).all():
        raise ValueError('Bin indices must be finite integers.')
    r, c = r0.astype(np.int64), c0.astype(np.int64)
    if np.any(r < 0) or np.any(c < 0) or np.any(r >= height) or np.any(c >= width):
        raise ValueError('Bin indices outside the declared grid.')
    ids = (r * width + c + 1).astype(np.uint32)
    if len(np.unique(ids)) != len(ids):raise ValueError('Duplicate bin instance IDs.')
    return r, c, ids


def make_projective_bin_shapes(obs, geometry, chunk_size=100000):
    import geopandas as gpd
    import shapely
    from spatialdata.models import ShapesModel
    from spatialdata.transformations import Identity
    if not is_projective(geometry):raise ValueError('Expected a non-affine grid.')
    if not isinstance(chunk_size, int) or isinstance(chunk_size, bool) or chunk_size < 1:
        raise ValueError('Polygon batch size must be a positive integer.')
    r, c, ids = bin_instance_ids(obs, geometry)
    h = homography(geometry['grid_index_to_fullres'])
    _domain_audit(h, np.array([0, geometry['grid_shape'][0]-1]),
                     np.array([0, geometry['grid_shape'][1]-1]))
    print(f'Building {len(r):,} model-derived projective bin quadrilaterals in fullres pixels. '
          'The final GeoDataFrame is eager and uses more RAM/storage than an affine label raster.', flush=True)
    polygons = np.empty(len(r), dtype=object)
    for start in range(0, len(r), chunk_size):
        stop = min(len(r), start + chunk_size)
        batch = shapely.polygons(grid_corners(r[start:stop], c[start:stop], h))
        if not shapely.is_valid(batch).all() or np.any(shapely.area(batch) <= 0):
            raise ValueError('Invalid/degenerate projected bin polygon.')
        polygons[start:stop] = batch
    # ShapesModel's public index contract is string; reuse exact barcode IDs.
    shape_ids = obs.index.astype(str).to_numpy(dtype=object)
    if not obs.index.is_unique or len(set(shape_ids)) != len(shape_ids) or any(not v for v in shape_ids):
        raise ValueError('Projective bin shapes require unique nonempty barcode identities.')
    frame = gpd.GeoDataFrame(geometry=polygons, index=shape_ids, crs=None)
    frame.index.name = 'instance_id'
    return ShapesModel.parse(frame, transformations={'fullres': Identity()}), shape_ids


def validate_projective_bin_shapes(element, obs, geometry, sample_indices):
    """Full ID relation check and sampled vertex/model check; no expression read."""
    import shapely
    from spatialdata.transformations import get_transformation
    from .core import transform_xy, affine
    r, c, ids = bin_instance_ids(obs, geometry)
    if len(element) != len(obs) or not element.index.is_unique:
        raise ValueError('Projective bin polygon count/IDs are invalid.')
    expected_ids = obs.index.astype(str).to_numpy(dtype=object)
    if not np.array_equal(np.asarray(obs['instance_id']), expected_ids):
        raise ValueError('Bin table instance IDs differ from barcode identities.')
    if not np.array_equal(np.asarray(element.index), expected_ids):
        raise ValueError('Projective bin polygon IDs/order differ from the table.')
    chosen = np.asarray(sample_indices, dtype=int)
    polygons = element.geometry.iloc[chosen].to_numpy()
    if not shapely.is_valid(polygons).all() or np.any(shapely.area(polygons) <= 0):
        raise ValueError('Stored projective bin polygons are invalid.')
    native = shapely.get_coordinates(polygons)
    lengths = shapely.get_num_coordinates(polygons)
    if np.any(lengths != 5):raise ValueError('Expected four-corner closed bin polygons.')
    transform = get_transformation(element, to_coordinate_system='fullres')
    m = affine(transform.to_affine_matrix(input_axes=('x','y'), output_axes=('x','y')))
    # No image registration is hidden here: stored vertices must be fullres.
    if not np.array_equal(m, np.eye(3)):raise ValueError('Projective bins must have materialized fullres vertices with Identity transform.')
    actual = shapely.polygons(transform_xy(native, m).reshape(-1, 5, 2)[:, :4])
    expected = shapely.polygons(grid_corners(r[chosen], c[chosen], geometry['grid_index_to_fullres']))
    error = float(shapely.hausdorff_distance(actual, expected).max(initial=0))
    if error > 1e-7:raise ValueError(f'Stored projective bin vertices changed: {error:g} px.')
    predicted = project_xy(np.column_stack([c[chosen], r[chosen]]), geometry['grid_index_to_fullres'])
    target = obs.iloc[chosen][['pxl_col_in_fullres','pxl_row_in_fullres']].to_numpy(float)
    center_error = float(np.linalg.norm(predicted-target, axis=1).max(initial=0))
    if center_error > geometry['grid_fit']['max_residual_px'] + 1e-7:
        raise ValueError('Projective model no longer matches stored source coordinates.')
    return {'sampled_bin_center_max_error_px': center_error,
            'sampled_bin_vertex_max_error_px': error,
            'bin_representation': 'projective_quadrilaterals',
            'bin_region': REGION}
