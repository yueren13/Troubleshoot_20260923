"""Read-only report navigation for VHD v5; no scientific approvals or transfer.

Only current sample/run directories are inspected. Choosing a report populates a
form, not an approval. Native acceptance/usage-save validation remains unchanged.
Plots are displayed from local bytes, not relative URLs inside an HTML srcdoc.
"""
from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path

PATCH_ID = 'vhd-asset-report-navigation-20261016-r1'
VISUAL_VERSIONS = {'visual-first-assets-on-he-20261002-v1',
                   'visual-first-assets-on-he-20261005-opacity-v2'}
MAX_JSON_BYTES = 64 * 1024**2
MAX_REPORTS = 1000
MAX_IMAGE_BYTES = 80 * 1024**2


def _read_json(path):
    p = Path(path)
    if p.is_symlink() or not p.is_file():
        raise ValueError(f'Expected a regular report/source file: {p}')
    if p.stat().st_size > MAX_JSON_BYTES:
        raise ValueError(f'Report exceeds {MAX_JSON_BYTES} byte inspection limit: {p}')
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError(f'Expected a JSON object: {p}')
    return data


def _in_directory(path, parent):
    p, root = Path(path), Path(parent).resolve()
    if p.is_symlink() or not p.resolve().is_relative_to(root):
        raise ValueError(f'Report path escapes the current report directory: {p}')
    q = p
    while q != root and q != q.parent:
        if q.is_symlink():
            raise ValueError(f'Symlinked report component: {q}')
        q = q.parent
    return p


def _image_path(directory, relative):
    rel = Path(str(relative))
    if rel.is_absolute() or '..' in rel.parts or rel.suffix.lower() not in ('.png', '.jpg', '.jpeg'):
        raise ValueError(f'Not a permitted report-image path: {relative}')
    p = _in_directory(Path(directory) / rel, directory)
    if not p.is_file() or not p.stat().st_size:
        raise FileNotFoundError(f'Report image missing/empty: {p}')
    return p


def _sha_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()


def _stamp_matches(record, path):
    p = Path(path)
    if not isinstance(record, dict) or not p.is_file():
        return False
    st = p.stat()
    return (Path(record.get('path', '')).resolve() == p.resolve()
            and record.get('size_bytes') == st.st_size
            and record.get('mtime_ns') == st.st_mtime_ns)


def _context(center, sample, assets=None):
    from ..control.manifest import sample_layout
    from ..annotations.workflow import read_assets
    project = center.snapshot()['project']
    key = center.key(sample, project)
    row = center.row(key, project)
    paths = sample_layout(project, row)
    if assets is None:
        assets = read_assets(row.get('assets_manifest'), row['dataset_id'], row['sample_id'])
    geometry = None
    for name in ('geometry.json', 'cell_geometry.json'):
        p = Path(paths['work']) / name
        if p.is_file():
            geometry = _read_json(p)
            if name == 'cell_geometry.json':
                geometry = geometry.get('geometry', geometry)
            break
    return key, Path(paths['report']), list(assets), geometry


def image_entries(summary, kind):
    """Return every report-declared image; no scientific rasters are enumerated."""
    result = []
    if kind == 'he':
        for rec in summary.get('images', []):
            if not isinstance(rec, dict) or 'file' not in rec:
                raise ValueError('Unsupported image record in H&E summary')
            result.append((str(rec.get('title') or rec.get('label') or rec['file']), str(rec['file'])))
    elif kind == 'geometry':
        for source in summary.get('sources', []):
            for region in source.get('region_candidates', []):
                for rel in region.get('previews', []):
                    result.append((str(rel), str(rel)))
            for category in source.get('category_inventory', []):
                rel = category.get('candidate_composition', {}).get('preview')
                if rel:
                    result.append((str(category.get('category', '')) + ' | composition', str(rel)))
    else:
        raise ValueError('kind must be he or geometry')
    # Do not duplicate an image that is referenced by more than one report field.
    seen = set()
    return [(label, rel) for label, rel in result if not (rel in seen or seen.add(rel))]


def inspect_he_report(path, *, sample_key, assets, geometry):
    """Cheap freshness checks, not a replacement for native source approval.

    Matching uses source/reference paths, size/mtime and the declared transform.
    Full native hash/geometry/coverage checks still execute on usage save.
    """
    from ..annotations.alignment import resolve_alignment
    import numpy as np
    p = Path(path)
    s = _read_json(p)
    if s.get('version') not in VISUAL_VERSIONS or s.get('sample_key') != sample_key:
        raise ValueError('Not this sample\'s supported H&E gallery summary')
    if s.get('purpose') != 'visual review only, not an import/transfer receipt':
        raise ValueError('Unsupported H&E gallery purpose/schema')
    if s.get('status') not in ('report_complete_unapproved', 'report_with_source_errors'):
        raise ValueError('H&E gallery is incomplete/failed')
    if not (p.parent/'index.html').is_file():
        raise FileNotFoundError('H&E gallery index.html is absent')
    images = image_entries(s, 'he')
    if not images:
        raise ValueError('H&E summary contains no completed images')
    for _, rel in images:
        _image_path(p.parent, rel)
    shown = s.get('sources', [])
    if len({x.get('asset_id') for x in shown}) != len(shown):
        raise ValueError('Duplicate source identity in gallery')
    if {x.get('asset_id') for x in shown} != {a['asset_id'] for a in assets}:
        raise ValueError('Configured source set differs from gallery; generate a current gallery')
    by_id = {x['asset_id']: x for x in shown}
    for a in assets:
        prev = by_id[a['asset_id']]
        if prev.get('kind') != a.get('kind') or not _stamp_matches(prev.get('source_stamp'), a['path']):
            raise ValueError(f"Source path/size/time differs: {a['asset_id']}")
    if geometry is None:
        raise ValueError('No prepared image geometry record available for freshness check')
    ref = geometry.get('image', {})
    if not ref.get('path') or not _stamp_matches(s.get('reference_stamp'), ref['path']):
        raise ValueError('H&E reference path/size/time differs; regenerate gallery')
    if any(s.get('reference_image', {}).get(k) != ref.get(k) for k in ('width', 'height')):
        raise ValueError('H&E reference dimensions differ')
    for a in assets:
        resolved = resolve_alignment(a, geometry)
        previous = np.asarray(by_id[a['asset_id']].get('source_to_display_reference'), float)
        current = np.asarray(geometry.get('tenx_to_image', np.eye(3)), float) @ np.asarray(resolved['source_to_fullres'], float)
        if previous.shape != (3, 3) or current.shape != (3, 3) or not np.allclose(previous, current, rtol=1e-12, atol=1e-7):
            raise ValueError(f"Displayed transform differs: {a['asset_id']}")
    return {'summary': str(p), 'kind': 'he', 'status': s['status'], 'n_images': len(images),
            'label': p.parent.name + (' | SOURCE ERRORS: inspect' if s['status'] == 'report_with_source_errors' else ''),
            'approval': 'NOT approved by selection; native checks remain on Save',
            'source_errors': [{'asset_id': x.get('asset_id'), 'status': x.get('status'),
                              'error': x.get('error', '')} for x in shown
                              if x.get('status') not in ('shown', 'shown_with_encoding_warning')]}


def inspect_repair_report(path, *, sample_key, asset, digest_cache=None):
    p = Path(path)
    s = _read_json(p)
    if s.get('status') != 'report_complete_not_approved' or s.get('coordinate_frame') != 'XML source coordinates only':
        raise ValueError('Not a complete unapproved geometry proposal')
    matching = [x for x in s.get('sources', []) if x.get('sample_key') == sample_key and x.get('asset_id') == asset['asset_id']]
    if len(s.get('sources', [])) != 1 or len(matching) != 1:
        raise ValueError('Repair report does not uniquely describe this sample/source')
    recorded = matching[0]
    active = Path(asset['path'])
    accepted = str(active).endswith('.vhdpolygons.json') or asset.get('format') == 'reviewed_polygons_json'
    if accepted:
        d = _read_json(active)
        if d.get('approval', {}).get('approved') is not True:
            raise ValueError('Active derivative has no approval')
        payload = d.get('payload', {})
        if payload.get('sample_key') != sample_key or payload.get('asset_id') != asset['asset_id']:
            raise ValueError('Active derivative belongs to another sample/source')
        origin = payload.get('source', {})
        xml = Path(origin.get('path', ''))
        expected_digest = origin.get('sha256')
    else:
        xml = active
        expected_digest = None
    if not xml.is_file() or Path(recorded.get('path', '')).resolve() != xml.resolve():
        raise ValueError('Repair report is for a different or unavailable XML source')
    cache = digest_cache if digest_cache is not None else {}
    stat = xml.stat()
    key = (str(xml.resolve()), stat.st_size, stat.st_mtime_ns)
    if key not in cache:
        cache[key] = _sha_file(xml)
    if cache[key] != recorded.get('source_sha256') or (expected_digest and expected_digest != cache[key]):
        raise ValueError('XML source digest differs from report; regenerate review')
    if not (p.parent/'index.html').is_file():
        raise FileNotFoundError('Repair gallery index.html missing')
    images = image_entries(s, 'geometry')
    for _, rel in images:
        _image_path(p.parent, rel)
    return {'summary': str(p), 'kind': 'geometry', 'status': s['status'],
            'asset_id': asset['asset_id'], 'label': p.parent.name,
            'n_images': len(images), 'active_source_is_derivative': accepted,
            'approval': 'Report selection is not acceptance; native geometry checks remain'}


def inventory(center, sample, assets=None):
    """Inventory only this run's report directory; never import another run's evidence."""
    key, root, assets, geometry = _context(center, sample, assets)
    result = {'sample_key': key, 'report_root': str(root), 'he': [], 'geometry': {}, 'unavailable': []}
    cache = {}
    for kind, pattern in [('he', 'assets_on_he_*/summary.json'),
                          ('geometry', 'annotation_geometry_review_*/review_summary.json')]:
        paths = sorted(root.glob(pattern), reverse=True) if root.is_dir() else []
        if len(paths) > MAX_REPORTS:
            result['unavailable'].append({'kind': kind, 'reason': 'More than 1000 candidate reports; inspect history explicitly'})
            continue
        for p in paths:
            try:
                _in_directory(p, root)
                if kind == 'he':
                    result['he'].append(inspect_he_report(p, sample_key=key, assets=assets, geometry=geometry))
                else:
                    doc = _read_json(p)
                    ids = {x.get('asset_id') for x in doc.get('sources', []) if x.get('sample_key') == key}
                    candidate_assets = [a for a in assets if a['kind'] == 'polygons' and a['asset_id'] in ids]
                    if len(candidate_assets) != 1:
                        raise ValueError('No unique current sample/source match')
                    a = candidate_assets[0]
                    rec = inspect_repair_report(p, sample_key=key, asset=a, digest_cache=cache)
                    result['geometry'].setdefault(a['asset_id'], []).append(rec)
            except (OSError, ValueError, KeyError, TypeError) as exc:
                result['unavailable'].append({'kind': kind, 'path': str(p), 'reason': f'{type(exc).__name__}: {exc}'})
    return result


def choose(records, preferred=None):
    """Preselect a still-current previous choice, else newest candidate; no approval."""
    values = [r['summary'] for r in records]
    return str(preferred) if preferred and str(preferred) in values else (values[0] if values else None)


def selector_options(records):
    return ([('Choose a current gallery (selection is not approval)', None)] +
            [(r['label'], r['summary']) for r in records]) if records else [('No current gallery: generate H&E asset gallery', None)]


def status_html(found):
    n = len(found['he'])
    text = ('<p><b>H&E galleries ready for inspection: '+str(n)+'.</b> '
            'Preselection is a navigation convenience, never approval.</p>' if n else
            '<p><b>No current H&E overlay gallery is available.</b> Category discovery is an inventory, '
            'not a plot generator. Click <b>Generate H&amp;E asset gallery</b>; a geometry repair report '
            'cannot populate Reviewed gallery.</p>')
    if found['unavailable']:
        text += '<details><summary>Unavailable/stale reports: inspect reasons</summary><pre>'+html.escape(json.dumps(found['unavailable'], indent=2))+'</pre></details>'
    return text


def show_report(center, sample, summary_path, *, kind, asset_id=None):
    """Show all report-declared images via a selector. Only selected image bytes load.

    Does not render external HTML, rewrite evidence, run a web server, or bless
    source alignment. It also exposes the complete saved numerical report.
    """
    import ipywidgets as W
    from IPython.display import display
    key, root, assets, geometry = _context(center, sample)
    if not summary_path:
        raise ValueError('Generate or select the appropriate report first')
    p = _in_directory(Path(summary_path).expanduser(), root)
    if kind == 'he':
        inspect_he_report(p, sample_key=key, assets=assets, geometry=geometry)
    elif kind == 'geometry':
        matches = [a for a in assets if a['asset_id'] == asset_id]
        if len(matches) != 1:
            raise ValueError('Select the intended geometry source')
        inspect_repair_report(p, sample_key=key, asset=matches[0])
    else:
        raise ValueError('Unsupported report kind')
    s = _read_json(p)
    entries = image_entries(s, kind)
    intro = ('H&E source overlay — NOT an import/transfer receipt; examine alignment before choosing usage.'
             if kind == 'he' else 'Geometry proposal — XML coordinates, NOT H&E alignment; selecting does not accept it.')
    header = W.HTML('<h3>'+html.escape(intro)+'</h3><p>'+html.escape(str(p))+'</p><p>Original gallery: '
                    +html.escape(str(p.parent/'index.html'))+'</p>')
    info = W.HTML()
    image = W.Image(layout=W.Layout(max_width='100%', width='100%', height='auto'))
    picker = W.Dropdown(options=[(f'{i+1}/{len(entries)} | {label}', rel) for i,(label,rel) in enumerate(entries)],
                        description='Plot', layout=W.Layout(width='98%'), style={'description_width':'60px'})
    def render(change=None):
        image.value = b''
        if not picker.value:
            info.value = '<p>No preview images were generated; inspect the report inventory.</p>'
            return
        try:
            img = _image_path(p.parent, picker.value)
            if img.stat().st_size > MAX_IMAGE_BYTES:
                raise ValueError('This image exceeds the bounded inline viewer limit; open the original locally: '+str(img))
            raw = img.read_bytes()
            if not (raw.startswith(b'\x89PNG\r\n\x1a\n') or raw.startswith(b'\xff\xd8\xff')):
                raise ValueError('Not a PNG/JPEG report image')
            image.format = 'png' if raw.startswith(b'\x89PNG') else 'jpeg'
            image.value = raw
            info.value = '<p>'+html.escape(str(img))+'</p>'
        except (OSError, ValueError) as exc:
            info.value = '<p><b>Image not displayed:</b> '+html.escape(str(exc))+'</p>'
    picker.observe(render, names='value')
    render()
    source_details = W.HTML('<details open><summary>Saved source statuses and declared transforms</summary><pre>'+
        html.escape(json.dumps([{'asset_id':x.get('asset_id'), 'path':x.get('path'), 'status':x.get('status'),
                               'error':x.get('error'), 'source_to_display_reference':x.get('source_to_display_reference'),
                               'alignment':x.get('alignment'), 'n_invalid':x.get('n_invalid')}
                              for x in s.get('sources', [])], indent=2))+'</pre></details>')
    data = W.Textarea(value=json.dumps(s, indent=2), disabled=True, layout=W.Layout(width='98%', height='350px'))
    details = W.Accordion(children=[data]); details.set_title(0, 'Complete saved report (read-only)'); details.selected_index=None
    box = W.VBox([header, source_details, picker, info, image, details])
    display(box)
    return None
