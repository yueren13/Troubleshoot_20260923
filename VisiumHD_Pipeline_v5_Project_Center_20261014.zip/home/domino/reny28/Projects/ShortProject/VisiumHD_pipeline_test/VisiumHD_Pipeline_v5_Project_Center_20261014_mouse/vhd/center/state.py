"""Small controller state on a user-selected filesystem. Never stores expression arrays.

A POSIX advisory lock serializes participating controllers. It is not a lock on
external notebook readers or an assertion that an object-store mount is POSIX.
The target filesystem must support flock and same-directory atomic replacement.
"""
from __future__ import annotations
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, socket, tempfile, threading

SCHEMA = 'vhd-project-center-1'


def now():
    return datetime.now(timezone.utc).isoformat()


def stable(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, default=str)


def fingerprint(value):
    return hashlib.sha256(stable(value).encode()).hexdigest()


def file_fingerprint(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for b in iter(lambda: stream.read(8 * 1024**2), b''):
            h.update(b)
    return h.hexdigest()


def stamp(path):
    p = Path(path)
    if not p.exists():
        return {'path': str(p), 'exists': False}
    s = p.stat()
    return {'path': str(p.resolve()), 'exists': True, 'is_dir': p.is_dir(),
            'size': s.st_size, 'mtime_ns': s.st_mtime_ns}


def atomic_write(path, content):
    p = Path(path)
    if p.is_symlink():
        raise ValueError(f'Refuse to replace a symlink: {p}')
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.' + p.name + '.', dir=p.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(content if isinstance(content, bytes) else content.encode('utf-8'))
            f.flush(); os.fsync(f.fileno())
        os.replace(name, p)
    finally:
        Path(name).unlink(missing_ok=True)


class StateStore:
    def __init__(self, directory):
        self.directory = Path(directory).expanduser().absolute()
        self.path = self.directory / 'project_state.json'
        self._mutex = threading.RLock()

    @contextmanager
    def exclusive(self):
        import fcntl
        self.directory.mkdir(parents=True, exist_ok=True)
        with self._mutex:
            lock = self.directory / '.controller.lock'
            if lock.is_symlink():
                raise ValueError('Controller lock must not be a symlink.')
            with lock.open('a+b') as f:
                try:
                    fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    raise RuntimeError('Another Project Center operation is active. Wait; do not delete the lock.') from None
                try:
                    yield
                finally:
                    fcntl.flock(f, fcntl.LOCK_UN)

    def read(self):
        d = json.loads(self.path.read_text())
        if d.get('schema') != SCHEMA:
            raise ValueError('Unsupported Project Center state schema.')
        return d

    def initialize(self, data):
        with self.exclusive():
            if self.path.exists():
                raise FileExistsError('This Project Center already exists. Use ProjectCenter.open(), not another import.')
            d = deepcopy(data)
            d.update(schema=SCHEMA, revision=0, created_at=now(), updated_at=now())
            d.setdefault('history', [])
            atomic_write(self.path, json.dumps(d, indent=2, allow_nan=False, default=str))
        return d

    def save_locked(self, data, expected_revision, event):
        """Caller holds exclusive(). Revision prevents silent stale-page overwrites."""
        current = self.read()
        if current['revision'] != expected_revision:
            raise RuntimeError('The project changed in another session. Refresh this page before saving.')
        revisions = self.directory / 'revisions'
        revisions.mkdir(exist_ok=True)
        old = revisions / f"state_{current['revision']:06d}.json"
        if not old.exists():
            atomic_write(old, self.path.read_bytes())
        d = deepcopy(data)
        d['revision'] = expected_revision + 1; d['updated_at'] = now()
        d['history'] = current['history'] + [{'at': now(), 'event': event, 'revision': d['revision']}]
        atomic_write(self.path, json.dumps(d, indent=2, allow_nan=False, default=str))
        return d
