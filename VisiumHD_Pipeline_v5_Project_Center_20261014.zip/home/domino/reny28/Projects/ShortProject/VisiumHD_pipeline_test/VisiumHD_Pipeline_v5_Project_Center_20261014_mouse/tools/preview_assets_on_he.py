"""Preview registered annotation sources on H&E BEFORE scientific import.

No SpatialData read/write, count matrices, bin-polygon construction, approval
changes, or binary-value conversion. Only new, uniquely named report files are
written. Imports the installed v4.1.1 readers to retain the configured transforms
and reviewed geometry. Run with runpy from a notebook with PROJECT initialized.
"""
from __future__ import annotations

import base64
import copy
from contextlib import contextmanager
from datetime import datetime, timezone
import html
import json
import math
from pathlib import Path
import re
import uuid

import numpy as np

VERSION = "visual-first-assets-on-he-20261005-opacity-v2"


def _stamp(path):
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"Source file is unavailable: {p}")
    st = p.stat()
    return {"path": str(p), "size_bytes": st.st_size, "mtime_ns": st.st_mtime_ns}


def _matrix(a):
    a = np.asarray(a, dtype=float)
    if a.shape != (3, 3) or not np.isfinite(a).all() or not np.allclose(a[2], [0, 0, 1]):
        raise ValueError("Asset/reference transform must be a finite 3x3 affine.")
    if abs(np.linalg.det(a[:2, :2])) < 1e-15:
        raise ValueError("Singular asset/reference transform.")
    return a


def _xy(a, matrix):
    xy = np.asarray(a, float)
    return np.c_[xy[:, :2], np.ones(len(xy))] @ _matrix(matrix)[:2].T


def _safe_stem(value):
    return re.sub(r"[^A-Za-z0-9_.-]", "_", str(value))[:72] or "unnamed"


class _Field:
    """Explicit yx / yxc / cyx scalar selection; no casting or thresholding."""
    def __init__(self, array, axes, channel):
        if axes not in ("yx", "yxc", "cyx") or len(array.shape) != len(axes):
            raise ValueError(f"Declared axes {axes!r} do not identify array shape {array.shape}.")
        if "c" in axes:
            if channel is None:
                raise ValueError("Select a channel explicitly for a multi-channel signal.")
            if not 0 <= int(channel) < array.shape[axes.index("c")]:
                raise ValueError("Signal channel is out of range.")
        elif channel is not None:
            raise ValueError("A yx image must not also specify a channel.")
        self.array, self.axes, self.channel = array, axes, channel
        self.shape = tuple(int(array.shape[axes.index(d)]) for d in "yx")
        self.dtype = np.dtype(array.dtype)
        if self.dtype.kind not in "buif":
            raise ValueError(f"Expected scalar real-valued signal, not {self.dtype}.")
        if min(self.shape) < 1:
            raise ValueError("Signal dimensions must be positive.")

    def __getitem__(self, key):
        y, x = key
        slices = [slice(None)] * len(self.axes)
        slices[self.axes.index("y")] = y
        slices[self.axes.index("x")] = x
        if "c" in self.axes:
            slices[self.axes.index("c")] = int(self.channel)
        out = np.asarray(self.array[tuple(slices)])
        if out.ndim != 2:
            raise ValueError(f"Expected selected 2D scalar plane; got {out.shape}.")
        return out


@contextmanager
def _open_field(asset, max_eager_bytes=256 * 1024**2):
    """Read-only base-level TIFF/NPY/PNG. Bounded eager fallback, never a temp mmap."""
    p = Path(asset["path"])
    axes, channel = asset.get("axes") or "yx", asset.get("channel")
    channel = None if channel in (None, "") else int(channel)
    resource = tif = mapped = None
    try:
        if p.suffix.lower() == ".npy":
            arr = mapped = np.load(p, mmap_mode="r", allow_pickle=False)
            info = {"backend": "npy_readonly_memmap"}
        elif p.suffix.lower() in (".tif", ".tiff"):
            import tifffile
            tif = tifffile.TiffFile(p)
            series = tif.series[0].levels[0]
            nbytes = math.prod(series.shape) * np.dtype(series.dtype).itemsize
            info = {"series": 0, "level": 0, "native_axes": series.axes,
                    "native_shape": list(series.shape), "decoded_array_bytes": nbytes}
            try:
                arr = mapped = tifffile.memmap(p, series=0, level=0, mode="r")
                info["backend"] = "tiff_readonly_memmap"
            except ValueError:
                try:
                    import zarr
                    resource = series.aszarr()
                    arr = zarr.open(resource, mode="r")
                    if not hasattr(arr, "shape"):
                        raise ValueError("Base-level TIFF reader returned a group, not an array.")
                    info["backend"] = "tiff_base_level_zarr_readonly"
                except ImportError:
                    if nbytes > max_eager_bytes:
                        raise RuntimeError(
                            f"Compressed TIFF requires zarr for bounded reads ({nbytes:,} decoded bytes). "
                            "Other sources will still be plotted; no large eager fallback was attempted.")
                    arr = series.asarray()
                    info["backend"] = "tiff_small_eager_readonly_fallback"
        elif p.is_dir():
            import zarr
            arr = zarr.open(str(p), mode="r")
            if not hasattr(arr, "shape"):
                raise ValueError("Choose a signal array, not a Zarr group/pyramid.")
            info = {"backend": "zarr_array_readonly"}
        else:
            from PIL import Image
            with Image.open(p) as im:
                # Supported PNG modes here have <= 8 bytes per pixel.
                if im.width * im.height * 8 > max_eager_bytes:
                    raise ValueError("PNG is above the bounded preview decode limit.")
                arr = np.asarray(im)
            info = {"backend": "small_image_readonly"}
        field = _Field(arr, axes, channel)
        info.update(declared_axes=axes, channel=channel, shape_yx=list(field.shape), dtype=str(field.dtype))
        yield field, info
    finally:
        if resource is not None:
            resource.close()
        if mapped is not None and getattr(mapped, "_mmap", None) is not None:
            mapped._mmap.close()
        if tif is not None:
            tif.close()


def _native_valid(block, asset):
    finite = np.isfinite(block)
    nodata = asset.get("nodata_value")
    missing = np.zeros(block.shape, bool)
    if nodata not in (None, ""):
        nodata = float(nodata)
        missing = np.isnan(block) if np.isnan(nodata) else block == nodata
    return finite, missing, finite & ~missing


def _signal_scan(asset, max_side=1800, tile_size=512, unique_limit=512):
    """Exact one-pass native-plane inventory + uniform nearest-neighbor display.

    Returns raw-valued preview (not 0/1), scan summary and display geometry.
    No mismatch throws: a binary declaration is assessed, not enforced for viewing.
    """
    with _open_field(asset) as (field, io_info):
        h, w = field.shape
        factor = max(1., max(h, w) / float(max_side))
        nh, nw = max(1, int(math.ceil(h/factor))), max(1, int(math.ceil(w/factor)))
        yy = np.minimum(np.floor((np.arange(nh) + .5) * h/nh).astype(np.int64), h-1)
        xx = np.minimum(np.floor((np.arange(nw) + .5) * w/nw).astype(np.int64), w-1)
        preview = np.empty((nh, nw), dtype=field.dtype)
        nfinite = nvalid = nmissing = nbinary_other = 0
        vmin, vmax = None, None
        uniques, unique_complete = {}, True
        examples = []
        binary = asset.get("signal_type") == "binary"
        pos = float(asset["positive_value"]) if binary else None
        neg = float(asset["negative_value"]) if binary else None
        for y in range(0, h, tile_size):
            for x in range(0, w, tile_size):
                a = field[y:min(h,y+tile_size), x:min(w,x+tile_size)]
                yi = np.flatnonzero((yy >= y) & (yy < y+a.shape[0]))
                xi = np.flatnonzero((xx >= x) & (xx < x+a.shape[1]))
                if len(yi) and len(xi):
                    preview[np.ix_(yi, xi)] = a[np.ix_(yy[yi]-y, xx[xi]-x)]
                finite, missing, valid = _native_valid(a, asset)
                nfinite += int(finite.sum()); nmissing += int(missing.sum()); nvalid += int(valid.sum())
                if not valid.any():
                    continue
                v = a[valid]
                lo, hi = v.min().item(), v.max().item()
                vmin = lo if vmin is None else min(lo, vmin)
                vmax = hi if vmax is None else max(hi, vmax)
                if unique_complete:
                    u, n = np.unique(v, return_counts=True)
                    if len(u) > unique_limit or len(set(uniques).union(u.tolist())) > unique_limit:
                        unique_complete = False; uniques = {}
                    else:
                        for k, count in zip(u.tolist(), n.tolist()):
                            uniques[k] = uniques.get(k, 0) + count
                if binary:
                    bad = valid & (a != pos) & (a != neg)
                    nbinary_other += int(bad.sum())
                    if bad.any() and len(examples) < 20:
                        for iy, ix in np.argwhere(bad)[:20-len(examples)]:
                            examples.append({"x": int(x+ix), "y": int(y+iy), "value": a[iy,ix].item()})
            if h > tile_size*3 and (y == 0 or (y//tile_size) % 16 == 0 or y+tile_size >= h):
                print(f"  raw signal scan: {min(y+tile_size,h):,}/{h:,} rows", flush=True)
        report = {**io_info, "scan": "all pixels in selected native plane", "n_pixels": h*w,
                  "n_finite": nfinite, "n_nodata": nmissing, "n_measured_valid": nvalid,
                  "n_nonfinite": h*w-nfinite, "min": vmin, "max": vmax,
                  "unique_values_complete": unique_complete,
                  "unique_values_and_counts": [{"value": k, "count": uniques[k]} for k in sorted(uniques)],
                  "unique_limit": unique_limit,
                  "declared_signal_type": asset.get("signal_type", "continuous"),
                  "declared_positive": pos, "declared_negative": neg,
                  "undeclared_value_count": nbinary_other if binary else None,
                  "undeclared_examples": examples,
                  "binary_encoding_status": ("mismatch" if nbinary_other else "matches_declared_codes") if binary else "not_binary",
                  "raw_values_preserved": True, "threshold_applied": False,
                  "display_resampling": "nearest source-pixel sample on uniform edge-aligned preview grid",
                  "display_shape_yx": [nh,nw], "display_range": [vmin,vmax],
                  "note": "Native-value check for review. It does not establish signal meaning, registration, or .obs transfer."}
        finite, missing, valid = _native_valid(preview, asset)
        return np.ma.array(preview, mask=~valid), report


def _polygon_rings(geom):
    if geom.geom_type == "Polygon":
        yield np.asarray(geom.exterior.coords)[:, :2], False
        for ring in geom.interiors:
            yield np.asarray(ring.coords)[:, :2], True
    elif geom.geom_type == "MultiPolygon":
        for part in geom.geoms:
            yield from _polygon_rings(part)
    else:
        raise ValueError(f"Unexpected filled geometry {geom.geom_type}.")


def _raw_xml_layers(asset, transform):
    """Unrepaired outlines only; useful errors may not hide the rest of the file."""
    from defusedxml import ElementTree as ET
    root = ET.parse(asset["path"]).getroot()
    for el in root.iter():
        el.tag = el.tag.rsplit("}", 1)[-1]
    if root.tag not in ("Annotations", "Annotation"):
        raise ValueError("Unsupported XML root; cannot label an unrecognized format as ImageScope.")
    layers, issues = {}, []
    import shapely
    for ai, annot in enumerate(root.iter("Annotation")):
        name = annot.get("Name", "unnamed")
        entry = layers.setdefault(name, {"category": name, "rings": [], "n_features": 0, "mode": "raw_unrepaired_outlines"})
        for ri, region in enumerate(annot.findall("./Regions/Region")):
            vertices = region.find("Vertices")
            try:
                if vertices is None:
                    raise ValueError("No Vertices element.")
                vs = list(vertices.findall("V")) or list(vertices.findall("Vertex"))
                xy = np.asarray([[float(v.get("X")), float(v.get("Y"))] for v in vs], float)
                if xy.ndim != 2 or xy.shape[1] != 2 or len(xy) < 3 or not np.isfinite(xy).all():
                    raise ValueError("Malformed/nonfinite polygon vertices.")
                valid_reason = str(shapely.is_valid_reason(shapely.Polygon(xy)))
                neg = region.get("NegativeROA", "0").lower() in ("1", "true", "yes", "t")
                if not np.array_equal(xy[0], xy[-1]):
                    xy = np.vstack([xy, xy[0]])  # close the DISPLAY path only
                entry["rings"].append((_xy(xy, transform), neg)); entry["n_features"] += 1
                if valid_reason != "Valid Geometry":
                    issues.append({"category": name, "annotation_id": annot.get("Id", str(ai)),
                                   "region_id": region.get("Id", str(ri)), "reason": valid_reason})
            except (ValueError, TypeError) as exc:
                issues.append({"category": name, "annotation_id": annot.get("Id", str(ai)),
                               "region_id": region.get("Id", str(ri)), "reason": str(exc)})
    if not layers:
        raise ValueError("No annotation categories were found in XML.")
    return list(layers.values()), issues


def _load_polygon_layers(asset, transform):
    from vhd.annotations.workflow import polygons
    try:
        frame = polygons(asset)
    except ValueError as exc:
        if str(asset["path"]).lower().endswith((".xml", ".annotation", ".annotations")):
            layers, issues = _raw_xml_layers(asset, transform)
            return layers, {"geometry_status": "raw_outlines_only_not_importable",
                            "reader_error": str(exc), "region_issues": issues,
                            "warning": "NO repair or negative-region composition applied in these raw outline views."}
        raise
    column = asset.get("category_column") or "name"
    if column not in frame:
        raise ValueError(f"Missing category column {column!r}; available: {list(frame.columns)}.")
    layers = []
    names = frame[column].astype(str)
    for category in sorted(names.unique()):
        rings = []
        sub = frame.loc[names == category]
        for geom in sub.geometry:
            for coords, inner in _polygon_rings(geom):
                rings.append((_xy(coords, transform), inner))
        layers.append({"category": category, "rings": rings, "n_features": len(sub), "mode": "parsed_polygon_boundaries"})
    return layers, {"geometry_status": "parsed", "category_column": column,
                    "note": "Separate categories remain independent; interior boundaries are retained. No fill, union across labels, or simplification is applied by this viewer."}


def _background(geometry, max_side):
    from vhd.images import thumbnail
    image = geometry["image"]
    if Path(image["path"]).suffix.lower() in (".png", ".jpg", ".jpeg"):
        from PIL import Image
        with Image.open(image["path"]) as im:
            if im.size != (int(image["width"]), int(image["height"])):
                raise ValueError("H&E dimensions do not match the prepared geometry metadata.")
            if im.width * im.height > 64_000_000:
                raise ValueError("Ordinary H&E PNG/JPEG exceeds the bounded decode size; use the named slide thumbnail reader.")
            im = im.convert("RGB"); im.thumbnail((max_side,max_side))
            a = np.asarray(im)
    else:
        a = thumbnail(image, max_side)
    if a.ndim != 3 or a.shape[2] != 3:
        raise ValueError(f"Expected RGB H&E thumbnail, got {a.shape}.")
    return a


def _resolve_for_preview(asset, geometry):
    """Same configured convention as v4.1; bounded reader for auto-extent shape."""
    from vhd.annotations.alignment import resolve_alignment, extent_affine
    if asset.get("registration_mode") not in ("auto", "auto_extent"):
        return resolve_alignment(asset, geometry)
    if asset["kind"] != "signal":
        raise ValueError("Auto-extent applies to raster sources, not polygon bounds.")
    image=geometry["image"]; ref_shape=(int(image["height"]),int(image["width"]))
    with _open_field(asset) as (r,_):shape=r.shape
    convention=asset.get("pixel_convention") or "edges"
    m=extent_affine(shape,ref_shape,pixel_convention=convention)
    tol=float(asset.get("scale_tolerance") or .05)
    if not np.isfinite(tol) or not 0<tol<1:raise ValueError("Invalid scale tolerance.")
    sx,sy=float(m[0,0]),float(m[1,1]); warnings=[]
    report={"method":asset["registration_mode"],"reference_path":image["path"],
        "reference_shape_yx":list(ref_shape),"source_shape_yx":list(shape),
        "scale_x":sx,"scale_y":sy,"offset_x":float(m[0,2]),"offset_y":float(m[1,2]),
        "pixel_convention":convention,"requires_same_extent_confirmation":True,
        "source_to_reference_image":m.tolist(),"visual_review_only":True}
    hint=asset.get("scale_hint")
    if hint not in (None,""):
        hint=float(hint)
        if not np.isfinite(hint) or hint<=0:raise ValueError("scale_hint must be positive.")
        diff=max(abs(sx/hint-1),abs(sy/hint-1))
        report.update(scale_hint=hint,max_relative_hint_difference=diff)
        if diff>tol:warnings.append(f"Dimension scales ({sx:g}, {sy:g}) differ from hint {hint:g} by {diff:.1%}.")
    if abs(sx/sy-1)>tol:warnings.append("Different x/y scale ratios: verify crop/field of view.")
    report["scale_checks_passed"]=not warnings
    report["warnings"]=warnings+["Dimension matching assumes the same field of view/orientation; it is not registration verification."]
    out=copy.deepcopy(asset);out["_alignment"]=report
    out["source_to_fullres"]=(np.linalg.inv(_matrix(geometry.get("tenx_to_image",np.eye(3))))@m).tolist()
    return out


def _capture_outline(geometry):
    if "grid_shape" not in geometry:
        return None
    h, w = geometry["grid_shape"]
    corners = np.array([[-.5,-.5],[w-.5,-.5],[w-.5,h-.5],[-.5,h-.5],[-.5,-.5]])
    matrix = geometry.get("grid_index_to_fullres")
    if matrix is None:
        # Current projective hotfix stores the explicit projective matrix separately.
        model = geometry.get("grid_geometry", {})
        matrix = model.get("index_to_fullres") if isinstance(model, dict) else None
    if matrix is None:
        return None
    uvw = np.c_[corners, np.ones(len(corners))] @ np.asarray(matrix, float).T
    if not np.isfinite(uvw).all() or (np.abs(uvw[:,2]) < 1e-12).any():
        return None
    return _xy(uvw[:,:2] / uvw[:,2,None], geometry.get("tenx_to_image", np.eye(3)))


def _signal_display_options(signal_alpha, signal_zero_transparent):
    """Validate display-only options before reading inputs or creating reports."""
    if (isinstance(signal_alpha, (bool, np.bool_))
            or not isinstance(signal_alpha, (int, float, np.integer, np.floating))
            or not np.isfinite(signal_alpha) or not 0 <= signal_alpha <= 1):
        raise ValueError("signal_alpha must be a finite number in [0, 1]: 0 invisible, 1 opaque.")
    if not isinstance(signal_zero_transparent, (bool, np.bool_)):
        raise ValueError("signal_zero_transparent must be True or False.")
    return {"signal_alpha": float(signal_alpha),
            "signal_zero_transparent": bool(signal_zero_transparent),
            "color_limits": "native measured minimum/maximum; unchanged from v1",
            "meaning": "Display only. Exact-zero transparency is not a biological positivity threshold."}


def _signal_display_array(array, zero_transparent):
    """Independent display copy: never mutate source values or its validity mask."""
    out = np.ma.array(array, copy=True)
    mask = np.ma.getmaskarray(out) | ~np.isfinite(out.data)
    if zero_transparent:
        mask |= out.data == 0  # exact comparison; do not hide weak nonzero signal
    out.mask = mask
    return out


def _plot(thumb, geometry, layers, signals, path, title, *, roi=None, dpi=160,
          signal_alpha=0.85, signal_zero_transparent=False):
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection
    from matplotlib.lines import Line2D
    from matplotlib.transforms import Affine2D
    from matplotlib.colors import Normalize
    options = _signal_display_options(signal_alpha, signal_zero_transparent)
    fig, ax = plt.subplots(figsize=(11, 9))
    try:
        image = geometry["image"]
        h,w = int(image["height"]), int(image["width"])
        ax.imshow(thumb, extent=(-.5,w-.5,h-.5,-.5), origin="upper", interpolation="nearest")
        colorbars = []
        for sig in signals:
            arr = _signal_display_array(sig["array"], options["signal_zero_transparent"])
            raw_h, raw_w = sig["summary"]["shape_yx"]
            lo, hi = sig["summary"]["min"], sig["summary"]["max"]
            if lo is None:
                continue
            if lo == hi:
                d = max(abs(float(lo))*0.01, .5); lo,hi = float(lo)-d,float(hi)+d
            # A private copy preserves the user's global colormap while ensuring
            # missing/hidden display pixels reveal the H&E beneath them.
            cmap = plt.get_cmap().copy()
            cmap.set_bad(alpha=0)
            obj=ax.imshow(arr, extent=(-.5,raw_w-.5,raw_h-.5,-.5), origin="upper",
                     transform=Affine2D(sig["matrix"])+ax.transData,
                     alpha=options["signal_alpha"], cmap=cmap,
                     interpolation="nearest", norm=Normalize(vmin=lo,vmax=hi))
            colorbars.append((obj, sig["asset_id"]+" raw values (display only)"))
        if signals:
            note = f"Signal opacity: {options['signal_alpha']:.0%}"
            if options["signal_zero_transparent"]:
                note += "; exact zeros transparent (display only)"
            ax.text(0, 1.005, note, transform=ax.transAxes, fontsize=8, va="bottom")
        handles = []
        for layer in layers:
            # Use the ordinary matplotlib cycle, with a stable per-source/category position.
            cycle = plt.rcParams["axes.prop_cycle"].by_key().get("color", [])
            color = cycle[layer["color_index"] % len(cycle)] if cycle else None
            for inner, style in ((False,"solid"),(True,"dashed")):
                segs=[r for r,i in layer["rings"] if i == inner]
                if segs:
                    kw={"linewidths": .8, "linestyles": style}
                    if color is not None:kw["colors"]=color
                    ax.add_collection(LineCollection(segs, **kw))
            kw = {"label":layer["asset_id"]+" / "+layer["category"],"linewidth":1.5}
            if color is not None:kw["color"]=color
            handles.append(Line2D([], [], **kw))
        capture = _capture_outline(geometry)
        if capture is not None:
            cap,=ax.plot(capture[:,0],capture[:,1],linestyle=":",linewidth=1.3,label="Capture perimeter (model)")
            handles.append(cap)
        ax.set_xlim(-.5,w-.5);ax.set_ylim(h-.5,-.5);ax.set_aspect("equal")
        if roi is not None:
            ax.set_xlim(roi[0],roi[2]);ax.set_ylim(roi[3],roi[1])
        ax.set_xlabel("Original H&E reference x (pixels)");ax.set_ylabel("Original H&E reference y (pixels)")
        ax.set_title(title,fontsize=12,pad=12)
        if handles:
            ax.legend(handles=handles,loc="upper left",bbox_to_anchor=(0,-.13),fontsize=9, ncol=2 if len(handles)>1 else 1)
        if len(colorbars)==1:
            fig.colorbar(colorbars[0][0],ax=ax,fraction=.035,pad=.035,label=colorbars[0][1])
        fig.savefig(path,dpi=dpi,bbox_inches="tight")
    finally:
        plt.close(fig)


def _render_html(summary, images, root):
    e = html.escape
    out=["<!doctype html><html><head><meta charset='utf-8'><title>Assets on H&E</title></head><body>",
         "<div class='vhd-preview' style='font:16px sans-serif;max-width:1250px;margin:auto'>",
         f"<h1>{e(summary['sample_key'])}: annotation and signal review</h1>",
         "<p><b>Review only. No master store or expression matrix was opened, created or updated; no approvals were set.</b></p>",
         f"<p>H&E: {e(summary.get('reference_image',{}).get('path','unavailable'))}<br>Report: {e(str(root))}</p>",
         "<p>All readable categories are shown irrespective of selection. Outlines may overlap. "
         "Signal colors show raw values; opacity/stretch are display settings, not thresholded measurements. "
         "Dashed polygon boundaries denote interior/exclusion outlines. Whole-image thumbnails cannot establish subpixel alignment.</p>"]
    if summary.get("display_settings"):
        settings = summary["display_settings"]
        out.append(f"<p><b>Signal opacity:</b> {settings['signal_alpha']:.0%}; "
                   f"<b>exact-zero transparency:</b> {settings['signal_zero_transparent']}. "
                   "Nonzero is not automatically a biological positive call. The native min/max, "
                   "pixel counts and scientific validity are unchanged by these display settings.</p>")
    if summary.get("fatal_error"):
        out.append(f"<h2>Reference error</h2><pre>{e(summary['fatal_error'])}</pre>")
    out.append("<h2>Sources and interpretation</h2>")
    for s in summary.get("sources",[]):
        out.append(f"<h3>{e(s['asset_id'])} — {e(s['status'])}</h3><p>{e(s['path'])}</p>")
        if s.get("error"):out.append(f"<pre style='white-space:pre-wrap'>{e(s['error'])}</pre>")
        if s.get("alignment"):
            if s["alignment"].get("scale_checks_passed") is False:
                out.append("<p><b>Alignment warning: scale checks failed. The proposed extent mapping is shown for inspection only, not accepted.</b></p>")
            out.append("<details><summary>Proposed/configured transform (not automatically approved)</summary><pre>"+
                       e(json.dumps(s['alignment'],indent=2))+"</pre></details>")
        if s.get("pixel_summary"):
            p=s['pixel_summary']
            vals=p['unique_values_and_counts']
            displayed=vals[:24]
            out.append("<p>Pixel scan: <b>"+e(p['scan'])+"</b><br>dtype: "+e(p['dtype'])+
                       "; shape: "+e(str(p['shape_yx']))+"; valid range: "+e(str([p['min'],p['max']]))+
                       "; binary declaration: <b>"+e(p['binary_encoding_status'])+"</b>"+
                       "; undeclared pixels: "+e(str(p['undeclared_value_count']))+".</p>")
            if vals:
                out.append("<p>Native values and counts"+(" (first 24; full list in JSON)" if len(vals)>24 else "")+": "+e(str(displayed))+"</p>")
            else:
                out.append("<p>Too many distinct values to list exactly within the configured inventory cap; min/max and mismatch counts are from the full scan.</p>")
            if p['binary_encoding_status']=='mismatch':
                out.append("<p><b>Shown for alignment despite the binary mismatch.</b> Decide the intended encoding from the source meaning before quantitative import. "
                           "This viewer has not changed binary to continuous or applied a threshold.</p>")
        if s.get("geometry_info"):
            out.append("<details><summary>Geometry status and category inventory</summary><pre>"+e(json.dumps(s['geometry_info'],indent=2))+"</pre></details>")
    for index,item in enumerate(images):
        b64=base64.b64encode((root/item['file']).read_bytes()).decode('ascii')
        if index == 0:
            out.append(f"<h2>{e(item['title'])}</h2>")
        else:
            out.append(f"<details><summary style='font-size:19px;padding:.6em 0'>{e(item['title'])}</summary>")
        out.append(f"<img style='max-width:100%' alt='{e(item['title'])}' src='data:image/png;base64,{b64}'>")
        if index != 0:out.append("</details>")
    out.append("<h2>Next decision</h2><p>Inspect the combined and per-category views, resolve any encoding/registration warnings, then choose categories for scientific use. "
               "Do not rerun the old import_assets cell merely to view these images. This report is not a stored-asset receipt and does not itself unblock .obs transfer.</p></div></body></html>")
    return "\n".join(out)


def preview_assets_on_he(project, sample_keys=None, *, max_side=2000, dpi=160,
                         individual_categories=True, show=True,
                         signal_alpha=0.85, signal_zero_transparent=False):
    """Render all enabled source categories and raw single-channel signals on H&E.

    signal_alpha: opacity, 0 invisible / 1 opaque (default 0.85, previously 0.4).
    signal_zero_transparent: optional exact-zero DISPLAY masking (default False).
        Use True for a zero-background signal; it does not declare zero to be nodata
        or turn every nonzero value into a biological positive. Fractional values,
        native min/max, raw-value inventory and scientific configuration are unchanged.

    No approval prerequisites. Writes ONLY a new review folder under each selected
    sample's configured reports directory. Reads source images/annotations and small
    geometry metadata; NEVER invokes import_assets/assemble or reads .tables.
    Binary mismatches are visible warnings, not blockers to display. No configuration
    is modified, no signals are thresholded, and no geometries are repaired.
    """
    display_options = _signal_display_options(signal_alpha, signal_zero_transparent)
    from vhd.control.manifest import resolve_sample_keys, sample_layout, row_config, check_policy
    from vhd.annotations.discovery import source_geometry
    from vhd.annotations.workflow import read_assets
    from vhd.annotations.alignment import resolve_alignment
    import pandas as pd
    if not isinstance(max_side,int) or max_side < 64 or max_side > 8000:
        raise ValueError("max_side must be an integer in [64,8000].")
    if not isinstance(dpi,int) or not 50 <= dpi <= 600:
        raise ValueError("dpi must be an integer in [50,600].")
    # Only storage-path safety is checked, never scientific review acknowledgements.
    check_policy(project)
    keys=set(resolve_sample_keys(project,sample_keys));results=[]
    for row in project['rows']:
        if row['sample_key'] not in keys:continue
        cfg,spec=row_config(project,row);paths=sample_layout(project,row)
        name='assets_on_he_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
        root=Path(paths['report'])/name
        # Refuse to place reports inside a biological source/store.
        from vhd.control.paths_v3 import assert_target
        sources=[v for v in (row.get('segmentation_image'),row.get('spaceranger_outs'),str(paths['store'])) if v]
        policy=cfg['storage_policy']
        assert_target(root,policy.get('approved_work_roots',policy.get('approved_tmp_roots',[])),sources)
        root.mkdir(parents=True,exist_ok=False)
        summary={'version':VERSION,'sample_key':row['sample_key'],'report_dir':str(root),
                 'display_settings':display_options,
                 'purpose':'visual review only, not an import/transfer receipt','sources':[],
                 'source_pixels_read':True,'expression_read':False,'master_opened':False,'master_written':False,
                 'config_or_approvals_changed':False,'bin_polygons_built':False,'sources_thresholded':False,
                 'master_path_not_opened':str(paths['store']),'master_directory_present':Path(paths['store']).is_dir()}
        images=[];layers=[];signals=[]
        print('\nVISUAL REVIEW ONLY:',row['sample_key'],flush=True)
        print('New report directory:',root,flush=True)
        try:
            geometry=source_geometry(project,row)
            if not geometry.get('image'):raise ValueError('No named original H&E reference metadata.')
            refstamp=_stamp(geometry['image']['path'])
            summary['reference_image']=geometry['image'];summary['reference_stamp']=refstamp
            A=_matrix(geometry.get('tenx_to_image',np.eye(3)))
            print('Reading H&E thumbnail (not building a master)…',flush=True)
            thumb=_background(geometry,max_side)
            summary['reference_display_shape']=list(thumb.shape)
            assets=read_assets(row.get('assets_manifest'),row['dataset_id'],row['sample_id'])
            for original in assets:
                s={'asset_id':original['asset_id'],'kind':original['kind'],'path':original['path'],'status':'pending'}
                summary['sources'].append(s)
                print('Reading',s['asset_id'],s['path'],flush=True)
                try:
                    initial=_stamp(original['path']);s['source_stamp']=initial
                    asset=_resolve_for_preview(original,geometry)
                    s['alignment']=asset.get('_alignment',{})
                    matrix=A@_matrix(asset['source_to_fullres']);s['source_to_display_reference']=matrix.tolist()
                    if asset['kind']=='polygons':
                        local,info=_load_polygon_layers(asset,matrix)
                        for layer in local:
                            layer.update(asset_id=asset['asset_id'],color_index=len(layers));layers.append(layer)
                        s['geometry_info']={**info,'categories':[{'name':l['category'],'features':l['n_features'],
                            'bounds_reference_xy':(np.r_[np.concatenate([a for a,_ in l['rings']]).min(axis=0),
                                                          np.concatenate([a for a,_ in l['rings']]).max(axis=0)].tolist()
                                                          if l['rings'] else None)} for l in local]}
                        s['status']='shown' if info['geometry_status']=='parsed' else 'shown_raw_outlines_warning'
                    else:
                        a,ps=_signal_scan(asset,max_side=max_side)
                        s['pixel_summary']=ps
                        signals.append({'array':a,'summary':ps,'matrix':matrix,'asset_id':asset['asset_id']})
                        s['status']='shown_with_encoding_warning' if ps['binary_encoding_status']=='mismatch' else 'shown'
                        print('  Native range:',[ps['min'],ps['max']], '| binary check:',ps['binary_encoding_status'],
                              '| unexpected pixels:',ps['undeclared_value_count'],flush=True)
                        if ps['unique_values_complete']:
                            print('  Raw values/counts:',ps['unique_values_and_counts'][:24],flush=True)
                    if _stamp(original['path']) != initial:
                        raise RuntimeError('Source changed during reading; do not use this report for review.')
                except Exception as exc:
                    s['status']='not_shown';s['error']=type(exc).__name__+': '+str(exc)
                    # A failed source cannot suppress other successfully read sources.
                    layers[:]=[l for l in layers if l['asset_id']!=s['asset_id']]
                    signals[:]=[v for v in signals if v['asset_id']!=s['asset_id']]
                    print('  SOURCE NOT SHOWN:',s['error'],flush=True)
            if _stamp(geometry['image']['path'])!=refstamp:
                raise RuntimeError('H&E reference changed during preview generation.')
            def save(filename,title,ls=layers,ss=signals,roi=None):
                _plot(thumb,geometry,ls,ss,root/filename,row['sample_key']+'\n'+title,roi=roi,dpi=dpi,
                      signal_alpha=display_options['signal_alpha'],
                      signal_zero_transparent=display_options['signal_zero_transparent'])
                images.append({'file':filename,'title':title})
            save('all_sources_on_HE.png','All readable categories and raw signals on H&E — not approved')
            if signals:
                save('all_categories_on_HE.png','All annotation categories on H&E',ss=[])
            save('HE_reference.png','Original H&E reference thumbnail',ls=[],ss=[])
            if individual_categories:
                for k,layer in enumerate(layers):
                    save(f'category_{k:03d}_{_safe_stem(layer["category"])}.png',
                         layer['asset_id']+' / '+layer['category']+' ['+layer['mode']+']',ls=[layer],ss=[])
            for sig in signals:
                save('signal_'+_safe_stem(sig['asset_id'])+'_raw_on_HE.png',
                     sig['asset_id']+' — RAW values on H&E; no binary conversion',ls=[],ss=[sig])
            rois=cfg.get('annotations',{}).get('preview_rois_image_px',{})
            for name,roi in rois.items():
                r=np.asarray(roi,float)
                if r.shape!=(4,) or not np.isfinite(r).all() or r[2]<=r[0] or r[3]<=r[1]:
                    raise ValueError(f'Invalid configured preview ROI {name!r}.')
                save('roi_'+_safe_stem(name)+'.png',str(name)+' — thumbnail zoom (not a new high-resolution crop)',roi=r)
            summary['status']='report_with_source_errors' if any(s['status']=='not_shown' for s in summary['sources']) else 'report_complete_unapproved'
        except Exception as exc:
            summary['status']='report_failed';summary['fatal_error']=type(exc).__name__+': '+str(exc)
            print('PREVIEW ERROR:',summary['fatal_error'],flush=True)
        summary['images']=images
        (root/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False),encoding='utf-8')
        text=_render_html(summary,images,root)
        (root/'index.html').write_text(text,encoding='utf-8')
        print('Self-contained gallery:',root/'index.html',flush=True)
        if show:
            from IPython.display import HTML, display
            display(HTML(text))
        results.append({'sample_key':row['sample_key'],'status':summary['status'],'report_dir':str(root),
                        'gallery':str(root/'index.html'),'summary':str(root/'summary.json'),
                        'sources_not_shown':sum(s['status']=='not_shown' for s in summary['sources']),
                        'signal_encoding_warnings':sum(s['status']=='shown_with_encoding_warning' for s in summary['sources'])})
    return pd.DataFrame(results)
