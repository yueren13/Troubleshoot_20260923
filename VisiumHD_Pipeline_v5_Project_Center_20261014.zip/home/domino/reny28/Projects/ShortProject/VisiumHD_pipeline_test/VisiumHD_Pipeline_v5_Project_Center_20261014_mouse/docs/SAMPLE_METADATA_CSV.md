# One project metadata CSV — v4.1.1

## Minimal setup

Use one UTF-8 CSV with one row per sample. This is separate from the routing
`samples.csv`: the routing file tells the pipeline which inputs to process and
where outputs belong; the metadata file describes those samples. A metadata
row does not enable a sample, choose a batch, move a path or launch a job.

```text
config/
    settings.json
    samples.csv
    sample_metadata.csv
    project_paths.json
    assets.csv
    asset_choices.csv
```

Add this top-level block to the existing settings (do not replace the whole file):

```json
"sample_metadata": {
  "path": "sample_metadata.csv",
  "sample_id_column": "sample_id"
}
```

The path is relative to `settings.json`, not the notebook. Absolute and configured
`${VARIABLE}` mounted paths work too. Native `s3://` metadata is not implemented;
use the mounted path already readable by your process. No per-sample JSON files
are generated, even internally. Resolved scalar values are carried in the existing
project snapshot sent to workers.

Example (illustrative, not the user's missing new attachment):

```csv
sample_id,species,condition,donor_id
Sample01,mouse,control,001
Sample02,mouse,treated,002
Sample03,human,control,003
```

These rows illustrate metadata only; they are not a recommendation to integrate
human and mouse. Integration groups are still set explicitly in the routing CSV.

The key may instead be called `Sample`, `Sample ID` or any other exact header.
Set `sample_id_column` accordingly. Column names and cell text otherwise remain
unchanged. Do not add the whole metadata table to `samples.csv`, whose schema is
for routing and does not accept arbitrary metadata columns.

## Existing collaborator table: select, rename or type columns once

```json
"sample_metadata": {
  "path": "/approved/project/collaborator_metadata.csv",
  "sample_id_column": "Sample",
  "columns": ["Species", "Treatment", "Donor ID", "Age", "Tumor weight"],
  "rename": {"Species": "species", "Tumor weight": "tumor_weight"},
  "types": {"Age": "int", "Tumor weight": "float"}
}
```

`columns` omitted/null imports every non-key column. Renames and types refer to
SOURCE headers; columns not explicitly renamed keep their original headings.
Spaces in ordinary obs names are allowed; use `adata.obs["Donor ID"]`. Reserved
pipeline fields (for example `qc_pass`, `region`, `sample`, counts, spatial links)
and unsafe names must be renamed or excluded. No values or units are inferred from
column names. Unrecognized species remain the supplied values; downstream species
validation still applies.

**Default: text is text.** IDs such as `001`, patient/donor codes and dates remain
strings. Literal `NA`, `null` and `NaN` remain text by default. Only an empty cell
is missing. Numeric/Boolean types can be declared once per column (`int`, `float`,
`bool`, `string`); opt-in `auto` applies conservative whole-column inference.
Invalid declared values stop with row/column context, not silent coercion. Use
`missing_values: ["", "NA"]` only when those exact tokens really mean missing in
this project. CSV export cannot repair leading zeros or dates already altered in
an upstream workbook. Choose CSV UTF-8 when exporting from Excel.

In per-bin/per-cell tables, text metadata is stored as categorical values to avoid
repeating long strings in every observation. Missing values remain missing, not
zero or the literal text `nan`. Numeric and Boolean values remain their declared
kinds where nonmissing; an all-missing per-sample column can have a floating
missing-value representation.

## Matching and cohort subsets

Matches are exact, case-sensitive identifiers, never row order or directory names.
Leading zeros are preserved. Duplicate keys, blank identifiers, surrounding ID
whitespace, duplicate headers and malformed row lengths are rejected. A table with
70+ rows can describe a whole project while the routing CSV enables only a subset.

By default every enabled routing sample must match; extra metadata rows are allowed
and listed as unused in the preview. To change this deliberately:

```json
"require_all_samples": true,
"allow_extra_samples": true
```

There is no default invented species/condition for unmatched samples.
`require_all_samples=false` allows an explicitly incomplete table; it does not
satisfy a downstream species requirement.

If two studies reuse the same sample ID, either use globally unique sample IDs or
configure a composite key:

```json
"sample_id_column": "Sample",
"dataset_id_column": "Study"
```

The Study column must match the configured namespace, not the parent directory.
Alternatively configure `sample_key_column` containing the full internal key and
omit `sample_id_column`/`dataset_id_column`. Dataset IDs remain optional for unique
sample IDs; this feature does not reintroduce a mandatory dataset folder scheme.

## Compatibility with JSON

Old `metadata_json` entries remain supported. For a CSV-only workflow, remove the
optional `metadata_json` column from `samples.csv` or clear its values. Existing
JSON files do not need to be deleted. If both sources are supplied, their fields
are merged; conflicting values stop by default. Identical values are accepted.
The optional `json_conflicts` policy can explicitly be `csv_wins` or `json_wins`,
and any conflict is recorded. These policies concern CSV versus JSON, NOT permission
to overwrite an existing cell-level annotation.

`load_project` resolves metadata once before workers start. Changing the CSV while
a job is running does not mix new values into that worker's snapshot. Rerun the
initialization cell to load a later revision. Notebook 00 now shows the match report,
selected headings/types, missing/unused keys and resolved per-sample values.

## Where the information goes

Existing-cell import and new-cell reconstruction attach the selected values to
cell `.obs`. Assembly also attaches them to `tables['bins_2um'].obs` when bins are
present, and to `tables['cells'].obs` when cells are present. Metadata is constant
within a sample, not a geometric bin-to-cell aggregation. Original expression,
counts, coordinates, QC labels and source objects are not replaced.

The table's `uns['vhd_sample_metadata_json']` records the resolved sample values,
owned columns and source provenance as a JSON STRING; this is not a separate file
for each sample. The control snapshot retains the source CSV path/checksum and
selected row/column mappings. Only selected values from the matching row affect
that sample's metadata payload. Editing a different sample's row does not by itself
change this payload. Metadata remains private within the project outputs; this
release does not upload it to GitHub.

## Changing metadata after a master already exists

Use optional notebook **14 — Refresh Sample Metadata Only**, not segmentation or
a forced re-import. It previews all selected masters, then uses the existing
recoverable metadata writer for obs/uns. It never writes RNA `X`, layers or spatial
coordinates. `obs` itself can be large; this is metadata-only, not zero-cost I/O.

Identical existing metadata is a no-op. Differing pre-existing unowned fields always
stop; rename the incoming field or reconcile it deliberately. Explicit
`REPLACE_OWNED=True` allows changes only to columns previously created by this
mechanism. Removed owned columns require explicit `PRUNE_REMOVED_OWNED=True`.
No automatic deletion of other annotations is permitted. Matching source fields
that were already present before attachment are not retroactively claimed as owned.

Single-writer acknowledgement, approved paths, recovery journals and no overlapping
writers remain required. Updates across multiple samples/tables are not one atomic
transaction. Reloading metadata is not permission to alter active model outputs:
updated analysis metadata or table components may invalidate previous QC/integration
signatures; use a new `integration.analysis_id` when rerunning analysis.

## Version and testing boundary

This additive v4.1.1 release retains the v4.1 scientific algorithms and core stage
version. The package version and checksum manifest identify the metadata extension.
Cell reconstruction/assembly now include metadata in their signatures; changed
metadata does not silently validate old prepared outputs. Use notebook 14 for
metadata-only changes to existing masters, or new run/output destinations when a
rebuild is actually intended. Do not remove old completion markers to force reuse.

The new attachment mentioned in the request was not available at development time.
Examples are synthetic (or the previous generic starter values), not a transcription
of that missing table. See VALIDATION_SUMMARY.md for precisely which checks ran.
