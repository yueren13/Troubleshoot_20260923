# Visium HD pipeline v4 — consolidated review candidate

**Version 0.4.0-review | September 30, 2026.** Complete downloadable source: notebooks, shared helpers, example CSV/JSON configuration, tests and migration guidance. This bundle incorporates the v3 review code and the delivered execution/validator corrections. Do **not** apply the old v3 hotfix installers on top of it.

Start with **[START_HERE](docs/START_HERE.md)**. Read **[annotation/signal roles](docs/ASSETS_V4.md)** and **[compact images / analysis QC](docs/IMAGE_AND_ANALYSIS_V4.md)** before executing the new sample pilot. See **[implemented vs unvalidated](docs/IMPLEMENTATION_STATUS.md)** and **[actual validation](docs/VALIDATION_SUMMARY.md)**.

## What is new

- Explicit per-source roles: `segmentation_qc`, `analysis`, `both`, `reference_only`. Keep an unreliable source for inspection without allowing it to influence bin assignments, prior filtering or cell transfer.
- ImageScope-style `.annotations` XML, preserved NegativeROA holes, and explicit source/transform-bound review. The extension does not guarantee a particular file schema.
- Binary TIFF measurement with declared 0/1 or 0/255 encoding, nearest bin-center sampling, NoData/coverage, native image storage and explicit source-to-fullres affine. The 1:9 example assumes a smaller signal image; its actual transform still needs review.
- Compact `he_hires` / `he_lowres` master images, fullres coordinate preservation, and an external original-image reference. Optional original embedding remains available; existing masters are not compacted automatically.
- New 07A analysis-QC stage: species-aware strict mitochondrial thresholds, cell raw-count minima, gene detection in retained cells, keyed sidecars and integration enforcement. Master counts/cells stay intact.
- Readable count plots: log10(1+count) spacing with original-unit ticks. New 07B replot-only notebook reads table metadata rather than expression matrices.
- One local `project_paths.json` setup, explicit worker interpreters (or `current`), visible run controls, worker-import checks, batch prerequisite checks, output index, and preserved venv symlink invocation paths.

## Folder layout

```text
config/       sample routes, source assets, sample metadata, analysis/execution settings
notebooks/    21 ordered source-only review and execution notebooks
vhd/
  control/    configuration, storage policy, routing and output inspection
  compute/    isolated workers, CPU/GPU scheduling and integration launchers
  adapters/   existing AnnData/bin/cell import and SpatialData assembly
  he/         fixed-reference quantitative tissue-evidence workflow
  annotations/ geometry, rasters, per-source review and metadata transfer
  persistence/ selective updates with explicit recovery protections
  analysis_qc.py, compact_images.py, count_display.py
  ...         inherited scientific engines and shared helpers
scripts/      optional command-line entry
tools/        static validation, source hygiene, synthetic XML/TIFF contract demo
tests/        control/numerical tests and separately gated real scientific smoke tests
env/          environment guidance; not verified GPU lockfiles
docs/         current instructions, limitations, change log and scoped test evidence
```

## First start

Extract into a new code directory. Keep your working v3 environment and results. Edit `config/project_paths.json`, `settings.json` and `samples.csv`; then edit only the metadata/asset/override files relevant to the chosen samples. The supplied three samples are illustrative. New starter notebooks read the local config pair directly; they do not depend on a stale `VHD_MANIFEST` environment variable.

Use a new run/master destination for this v4 pilot. Open 00, then 99 in the intended environment. New notebooks default to preview and do not silently approve alignment or writes. The same Python executable can serve multiple roles only when its installed packages support them. See START_HERE for the raw and midway routes.

A minimal synthetic demonstration, unrelated to biological data:

```bash
python tools/demo_annotation_signal_contract.py --output /path/to/NEW/demo_folder
```

It checks the actual XML parser, a tiny TIFF with 9x coordinate scaling, reference-role exclusion, binary coverage/aggregation, and count labels. It does not run SpatialData, segmentation, scVI or GPUs.

## Preserve the scientific contract

Counts remain raw; selected bins and cells stay separate tables. Full-resolution positions do not become hires coordinates. Geometric bin-to-cell transfer is not Proseg transcript assignment. Unknown annotation coverage is not negative tissue. Reference-only sources are not active filters. Quantitative H&E uses the supplied fixed-reference method, not per-image display normalization. scVI uses sample batches and explicit compatible integration groups, not treatment as batch or automatic cross-species mapping.

Existing native-coordinate cell-only sources remain possible; absent polygons yield centroid display glyphs, not inferred whole-cell masks. Active bin-mediated annotation transfer requires bins. Quantitative summaries of sampled bin centers are not physical-area integrals.

## Validation and operational limits

This is a review candidate for the user's target environment, not a production-certified or biological end-to-end result. No real files from the new hand-picked pilot have been processed here. Scientific roundtrip modules and actual StarDist, Proseg, scVI/DDP and RAPIDS/GPU work require the designated environment. The exact test counts, skips and scope are in the current validation record; historical counts under `docs/history_v3/` are not cumulative evidence.

No user-specific path, live mount, existing data, GitHub branch or corporate template was changed by creating this download. There is no automatic deletion, permissive overwrite or mutation of infrastructure. Reuse checks do not mean arbitrary partial jobs are automatically resumable. Keep per-store single-writer discipline and review partial states explicitly.
