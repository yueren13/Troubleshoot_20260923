# Documentation index

For this release, begin with **START_HERE.md**, **RELEASE_NOTES_V5.md**, and the top-level **VALIDATION.md**.

Other documents were retained from the supplied v4.1.1 engine for reference. Their notebook-by-notebook approval instructions describe the advanced/legacy interface, not the normal v5 Project Center interaction. Do not follow an old hotfix installer on top of this consolidated bundle.
