# v4 validation summary — September 30, 2026

## Executed for this exact source bundle

| Check | Result |
|---|---|
| Available pytest collection | **179 passed, 6 skipped** |
| Static Python syntax | **67 files passed** |
| Notebook format / code compilation | **21 notebooks, 85 code cells passed** |
| Root configuration CSV structure | **13 files passed** |
| New raw/mixed-entry sample configurations | **3 manifests passed schema/routing/static path-policy checks with isolated temporary roots** |
| Tiny synthetic XML/TIFF demonstration | **Passed**; see `synthetic_demo/result.json` |

Raw test output: `PYTEST_OUTPUT.txt`. Environment: `VALIDATION_ENVIRONMENT.json`. Static and configuration records: `STATIC_VALIDATION.json`, `CONFIG_VALIDATION.json`. Machine-readable summary: `validation_report.json`.

The 41 new v4 test cases include role parsing and compatibility aliases, forbidden reference/analysis prior sources, no scientific-signature change from reference edits, real tiny TIFF sampling with both 0/1 and 0/255 codes and a 9x transform, valid-coverage denominators, undeclared binary-code errors, XML namespaces/V/Vertex tags and preserved holes, mitochondrial strict boundaries at 10/20, minimum counts 3/16, missing-MT handling, preserved existing QC, plot tick math, compact source scale selection and no silent original-image fallback. Explicitly stubbed orchestration checks show reference-only sources do not write bin annotation columns and that a reference-layer persistence error is not swallowed.

The separate demo runs the real XML/TIFF numerical helpers and writes a small original-count-axis plot. Its coordinates, counts and annotations are synthetic, not the user's files. The plot was rendered and visually inspected. It is not a SpatialData roundtrip or segmentation run.

## What the skips mean

Four complete optional modules were skipped because AnnData is not installed here: resume, SpatialData, v3 scientific storage, and v4 scientific storage tests. A module skip can conceal multiple test cases. Two additional scVI tests require explicit opt-in and the model environment. The new optional tests exercise actual compact-image SpatialData readback and actual AnnData-Zarr analysis-QC sidecars/count preservation, but **they did not execute here**.

The build environment also lacks SpatialData, Zarr, Dask, Scanpy and scVI. An attempted package install failed because external package-index DNS access was unavailable; the delivery does not depend on that attempt and does not modify the user's environment. Do not interpret the passing CPU suite as approval to skip notebook99's target scientific checks.

## Not performed

No new pilot files, expression matrices, original slides or institutional mounts were accessed. No StarDist, Proseg, scVI/GPU/DDP or RAPIDS/Dask scientific run, biological accuracy assessment, performance benchmark or whole-cohort test was performed. No fixed one-hour completion is claimed. Actual annotation schema, binary encoding, scale direction and registration must be checked on the selected samples.

Packaging preserves the original uploaded archives. The new code was generated in a separate directory, not applied to an active pipeline or GitHub repository. Historical records under `history_v3/` are labeled provenance and are not combined with this run's pass counts.

## Reproduce

In the extracted bundle's intended environment:

```bash
python tools/validate_repository.py --mode working
python -m pytest -q -ra
python tools/demo_annotation_signal_contract.py --output /path/to/NEW/demo_folder
```

Read skips and use notebook99 for the separate scientific environment. Keep raw counts, IDs, coordinate overlays, source roles, per-sample QC losses and reopened products as explicit end-to-end acceptance checks.
