"""Real CSV/JSON/XML/TIFF approval tests. Storage dispatch is explicitly stubbed.

No mocked persistence is represented as a real SpatialData roundtrip.
"""
import copy
import csv
import json
from pathlib import Path
import numpy as np
import pytest
import tifffile
from PIL import Image

from vhd.annotations import visual_approval as va
from vhd.annotations import workflow as wf
from vhd.annotations.discovery import discover_one, atomic_choices, read_choices, preview_selected_plan
from vhd.control.manifest import COLUMNS, OPTIONAL_COLUMNS, load_project, sample_layout, row_config

ROOT = Path(__file__).resolve().parents[1]


def write_csv(p, rows, fields=None):
    with Path(p).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0])); w.writeheader(); w.writerows(rows)
    return p


@pytest.fixture
def setup(tmp_path):
    ref = tmp_path/'he.png'; Image.fromarray(np.full((90,90,3),200,np.uint8)).save(ref)
    xml = tmp_path/'source.annotations'
    xml.write_text('<Annotations>'+''.join(f'<Annotation Name="{n}"><Regions><Region><Vertices><V X="0" Y="0"/><V X="80" Y="0"/><V X="80" Y="80"/><V X="0" Y="80"/></Vertices></Region></Regions></Annotation>' for n in ('Tissue','Necrosis','Unused'))+'</Annotations>')
    tif = tmp_path/'signal.tif';tifffile.imwrite(tif, np.tile(np.array([0,.25,.5,1,0,.25,.5,1,0,1],np.float32),(10,1)))
    sources = [dict(sample_id='A',asset_id='pathology',kind='polygons',path=str(xml),format='imagescope_xml',registration_mode='reference_pixels',axes='',signal_type='',positive_value='',negative_value='',coverage_mode='exhaustive'),
               dict(sample_id='A',asset_id='stain',kind='signal',path=str(tif),format='tiff',registration_mode='auto_extent',axes='yx',signal_type='binary',positive_value='255',negative_value='0',coverage_mode='exhaustive')]
    assets = write_csv(tmp_path/'assets.csv', sources)
    row = dict.fromkeys(COLUMNS+list(OPTIONAL_COLUMNS),'')
    row.update(enabled='true',sample_id='A',stage='raw',goal='bin_QCed',spaceranger_outs=str(tmp_path/'outs'),segmentation_image=str(ref),
        output_object_dir=str(tmp_path/'objects'),output_plot_dir=str(tmp_path/'plots'),output_data_dir=str(tmp_path/'tables'),
        work_dir=str(tmp_path/'work'),tmp_dir=str(tmp_path/'scratch'),master_store=str(tmp_path/'masters/A.zarr'),assets_manifest=str(assets))
    manifest = write_csv(tmp_path/'samples.csv',[row]); cfg = json.loads((ROOT/'config/settings.json').read_text())
    cfg.pop('path_variables_file',None);cfg.pop('sample_metadata',None);cfg['run_id']='bridge_test'
    cfg['storage']['single_writer_ack']=True;cfg['prior_filter']['mode']='from_review'
    for k in ('python_spatial','python_stardist','python_scvi','python_rapids'):cfg['execution'][k]='current'
    cfg['proseg']['executable']='/unused/proseg'
    cfg['storage_policy'].update(required_existing_roots=[],required_sentinels=[],locations=[])
    for k in ('approved_tmp_roots','approved_work_roots','approved_object_roots','approved_plot_roots','approved_data_roots','approved_master_roots','approved_cache_roots'):cfg['storage_policy'][k]=[str(tmp_path)]
    for k in ('control_dir','work_dir','tmp_dir','output_object_dir','output_plot_dir','output_data_dir'):cfg['integration'][k]=str(tmp_path/'integration'/k)
    settings=tmp_path/'settings.json';settings.write_text(json.dumps(cfg));project=load_project(manifest,settings);row=project['rows'][0]
    paths=sample_layout(project,row);paths['work'].mkdir(parents=True);paths['report'].mkdir(parents=True)
    geom={'image':{'path':str(ref),'width':90,'height':90,'mpp':[.25,.25]},'tenx_to_image':np.eye(3).tolist()}
    (paths['work']/'geometry.json').write_text(json.dumps(geom))
    (paths['work']/'bins_qc_obs.parquet').write_bytes(b'metadata fixture, not real parquet')
    sources=wf.read_assets(assets,'Project','A');choices=[]
    for a in sources:
        cc,_=discover_one(a,geom,'Project__A')
        for c in cc:
            if c['category']!='Unused':c['include_in_obs']='true'
            if c['category']=='Tissue':c['qc_use']='include'
            if c['category']=='Necrosis':c['qc_use']='exclude'
            c['same_extent_confirmed']='true'
        choices+=cc
    choices_path=Path(sources[0]['review_table']);atomic_choices(choices_path,choices)
    folder=paths['report']/'assets_on_he_test';folder.mkdir()
    Image.fromarray(np.zeros((3,3,3),np.uint8)).save(folder/'all_sources_on_HE.png')
    (folder/'index.html').write_text('<html>Synthetic preview fixture</html>')
    summary={'version':'visual-first-assets-on-he-20261005-opacity-v2','sample_key':'Project__A',
      'purpose':'visual review only, not an import/transfer receipt','status':'report_complete_unapproved',
      'reference_stamp':va._stamp(ref),'reference_image':geom['image'],'images':[{'file':'all_sources_on_HE.png'}], 'sources':[]}
    for a in sources:
        ar=wf.resolve_alignment(a,geom) if hasattr(wf,'resolve_alignment') else None
        from vhd.annotations.alignment import resolve_alignment
        ar=resolve_alignment(a,geom)
        src={'asset_id':a['asset_id'],'kind':a['kind'],'path':a['path'],'source_stamp':va._stamp(a['path']),
            'source_to_display_reference':ar['source_to_fullres'],'status':'shown'}
        if a['kind']=='polygons':src['geometry_info']={'geometry_status':'parsed','categories':[{'name':x} for x in ('Tissue','Necrosis','Unused')]}
        else:
            src['status']='shown_with_encoding_warning'
            src['pixel_summary']={'declared_axes':'yx','channel':None,'scan':'all pixels in selected native plane','n_measured_valid':100,
              'unique_values_complete':True,'unique_values_and_counts':[{'value':v,'count':n} for v,n in zip([0,.25,.5,1],[30,20,20,30])],
              'binary_encoding_status':'mismatch','declared_positive':255.,'declared_negative':0.}
        summary['sources'].append(src)
    report=folder/'summary.json';report.write_text(json.dumps(summary))
    return dict(root=tmp_path,project=project,paths=paths,geom=geom,sources=sources,assets=assets,choices=choices_path,
                summary=report,settings=settings,xml=xml,tif=tif,ref=ref,manifest=manifest)


def preview(s, **kw):
    return va.approve_visual_choices(s['project'],{'A':['pathology','stain']},review_reports={'A':str(s['summary'])},
                                     signal_interpretations={'A':{'stain':'native'}},**kw)


def approve(s):
    p=preview(s)
    assert not p['errors'],p['errors']
    return preview(s,execute=True,reviewer='Synthetic reviewer',confirm_plan=p['plan_id'])


def reload(s):
    s['project']=load_project(s['manifest'],s['settings']);return s['project']


def snapshots(root):
    return {str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()}


def test_preview_is_readonly_and_no_old_receipts_needed(setup):
    before=snapshots(setup['root']);p=preview(setup)
    assert p['status']=='ready_for_explicit_approval' and len(p['entries'])==2
    assert p['proposed_source_setting_changes'][0]['changes']['signal_type']=={'old':'binary','new':'continuous'}
    assert snapshots(setup['root'])==before


def test_as_configured_encoding_mismatch_is_reported_without_writes(setup):
    before=snapshots(setup['root'])
    p=va.approve_visual_choices(setup['project'],{'A':['pathology','stain']},review_reports={'A':setup['summary']})
    assert p['status']=='blocked' and any('Binary declaration' in x for x in p['errors'])
    assert snapshots(setup['root'])==before


def test_explicit_native_approval_preserves_pixels_and_unselected_choices(setup):
    tif=setup['tif'].read_bytes();xml=setup['xml'].read_bytes();old=read_choices(setup['choices'])
    result=approve(setup);reload(setup)
    assert result['status']=='approved' and result['backups']
    assert setup['tif'].read_bytes()==tif and setup['xml'].read_bytes()==xml
    sources=wf.read_assets(setup['assets'],'Project','A');assert sources[1]['signal_type']=='continuous'
    rows=read_choices(setup['choices'])
    assert len([r for r in rows if r['reviewed_signature']])==3
    assert next(r for r in rows if r['category']=='Unused')==next(r for r in old if r['category']=='Unused')
    assert not (setup['paths']['report']/'asset_pathology.json').exists()
    assert not (setup['paths']['report']/'asset_stain.json').exists()
    for e in result['entries']:
        r=json.loads(Path(e['receipt']).read_text());assert r['status']=='approved_visual_review_not_import_receipt' and not r['master_written']


def test_repeated_approval_reuses_and_preserves_bytes(setup):
    approve(setup);reload(setup);before=snapshots(setup['root']);r=approve(setup)
    assert r['status']=='already_approved';assert snapshots(setup['root'])==before


@pytest.mark.parametrize('kwargs,match', [({'execute':True},'reviewer'),({'execute':True,'reviewer':'Reviewer'},'plan'),({'execute':'true'},'Boolean')])
def test_explicit_confirmation_required(setup,kwargs,match):
    before=snapshots(setup['root'])
    with pytest.raises((ValueError,RuntimeError,TypeError),match=match):preview(setup,**kwargs)
    assert snapshots(setup['root'])==before


@pytest.mark.parametrize('change', ['source','reference','transform','raw_outlines','missing_category','axes','missing_image','wrong_sample','wrong_report','failed_report','coverage'])
def test_stale_or_inadequate_visual_evidence_blocked(setup,change):
    s=setup;summary=json.loads(s['summary'].read_text())
    if change=='source':s['xml'].write_text(s['xml'].read_text()+' ')
    elif change=='reference':s['ref'].write_bytes(s['ref'].read_bytes()+b' ')
    elif change=='transform':summary['sources'][0]['source_to_display_reference'][0][2]=4
    elif change=='raw_outlines':summary['sources'][0]['status']='shown_raw_outlines_warning'
    elif change=='missing_category':summary['sources'][0]['geometry_info']['categories']=[]
    elif change=='axes':summary['sources'][1]['pixel_summary']['declared_axes']='cyx'
    elif change=='missing_image':(s['summary'].parent/'all_sources_on_HE.png').unlink()
    elif change=='wrong_sample':summary['sample_key']='Project__B'
    elif change=='wrong_report':summary['version']='annotation-candidate-visual-review-20261002-v1'
    elif change=='failed_report':summary['status']='report_failed'
    elif change=='coverage':
        old,fields,rows=va._read_csv(s['assets']);fields.append('coverage_path')
        for r in rows:r['coverage_path']=str(s['xml']) if r['kind']=='polygons' else ''
        write_csv(s['assets'],rows,fields)
    s['summary'].write_text(json.dumps(summary));before=snapshots(s['root']);p=preview(s)
    assert p['status']=='blocked' and p['errors'];assert snapshots(s['root'])==before


def test_changed_plan_refused(setup):
    p=preview(setup);rows=read_choices(setup['choices']);rows[0]['obs_name']='renamed';atomic_choices(setup['choices'],rows)
    before=snapshots(setup['root'])
    with pytest.raises(RuntimeError,match='plan'):preview(setup,execute=True,reviewer='Reviewer',confirm_plan=p['plan_id'])
    assert snapshots(setup['root'])==before


def test_preview_reports_pending_not_exception(setup):
    p=preview_selected_plan(setup['project'],['A'])[0]
    assert len(p['pending_choices'])==3 and not p['choice_approvals_complete']
    with pytest.raises(RuntimeError,match='Unapproved'):preview_selected_plan(setup['project'],['A'],require_approval=True)
    approve(setup);reload(setup)
    p=preview_selected_plan(setup['project'],['A'])[0]
    assert p['choice_approvals_complete'] and p['active_outputs']==3


def test_new_receipt_checks_each_current_choice(setup):
    approve(setup);reload(setup);cfg,spec=row_config(setup['project'],setup['project']['rows'][0])
    assets,sig,align=wf.asset_specification(cfg,spec)
    for sid in ('pathology','stain'):
        items=[a for a in assets if a['_source_asset_id']==sid]
        record=va.validate_visual_receipt(setup['paths'],sid,items[0]['reviewed_signature'],items)
        assert record['asset']==sid
        items[0]['_choice_signature']='tampered'
        with pytest.raises(RuntimeError,match='current choice'):va.validate_visual_receipt(setup['paths'],sid,items[0]['reviewed_signature'],items)


def test_missing_native_validation_does_not_approve_bad_data(setup,monkeypatch):
    import vhd.annotations.raster as raster
    def fail(*args,**kwargs):raise ValueError('native encoding changed')
    monkeypatch.setattr(raster,'validate_signal_encoding',fail)
    p=preview(setup);before=snapshots(setup['root'])
    with pytest.raises(ValueError,match='native encoding'):preview(setup,execute=True,reviewer='Reviewer',confirm_plan=p['plan_id'])
    assert snapshots(setup['root'])==before


def test_storage_dispatch_imports_then_reuses_real_record_contract_stub(setup,monkeypatch):
    # Storage is a deliberately stubbed backend here, not a SpatialData roundtrip.
    approve(setup);reload(setup);cfg,spec=row_config(setup['project'],setup['project']['rows'][0])
    assets,sig,align=wf.asset_specification(cfg,spec);calls=[]
    def importer(c,s):
        calls.append('real_import_requested')
        for sid in ('pathology','stain'):
            a=next(a for a in assets if a['_source_asset_id']==sid);g='shapes' if a['kind']=='polygons' else 'images';element='asset_'+sid
            (setup['paths']['store']/g/element).mkdir(parents=True,exist_ok=True)
            (setup['paths']['report']/f'asset_{sid}.json').write_text(json.dumps({'kind':a['kind'],'status':'stored','preview_status':'generated','element':element,'alignment_signature':a['reviewed_signature']}))
    monkeypatch.setattr(wf,'import_assets',importer)
    va.ensure_transfer_sources(cfg,spec,assets,align);assert len(calls)==1
    va.ensure_transfer_sources(cfg,spec,assets,align);assert len(calls)==1


def test_failed_import_never_passes_as_stored(setup,monkeypatch):
    approve(setup);reload(setup);cfg,spec=row_config(setup['project'],setup['project']['rows'][0]);assets,_,align=wf.asset_specification(cfg,spec)
    monkeypatch.setattr(wf,'import_assets',lambda *args:None)
    with pytest.raises(RuntimeError,match='Actual source import'):va.ensure_transfer_sources(cfg,spec,assets,align)
    assert not (setup['paths']['report']/'asset_pathology.json').exists()


def test_missing_visual_approval_never_triggers_import(setup,monkeypatch):
    approve(setup);reload(setup);cfg,spec=row_config(setup['project'],setup['project']['rows'][0]);assets,_,align=wf.asset_specification(cfg,spec)
    (setup['paths']['report']/'asset_pathology_visual_approval.json').unlink()
    monkeypatch.setattr(wf,'import_assets',lambda *args:pytest.fail('Import must not run without review'))
    with pytest.raises(RuntimeError,match='No current stored'):va.ensure_transfer_sources(cfg,spec,assets,align)


def test_list_galleries_is_readonly(setup):
    before=snapshots(setup['root']);table=va.list_visual_reviews(setup['project'],['A'])
    assert len(table)==1 and table.iloc[0]['summary']==str(setup['summary'])
    assert snapshots(setup['root'])==before


def test_write_failure_restores_configuration(setup,monkeypatch):
    p=preview(setup);before_choices=setup['choices'].read_bytes();before_assets=setup['assets'].read_bytes();original=va._atomic_bytes;called=[]
    def intermittent(path,data):
        called.append(str(path))
        if len(called)==4:raise OSError('synthetic write failure')
        return original(path,data)
    monkeypatch.setattr(va,'_atomic_bytes',intermittent)
    with pytest.raises(OSError,match='synthetic'):preview(setup,execute=True,reviewer='Reviewer',confirm_plan=p['plan_id'])
    assert setup['choices'].read_bytes()==before_choices and setup['assets'].read_bytes()==before_assets
    assert not list(setup['paths']['report'].glob('*_visual_approval.json'))


def test_actual_visual_viewer_gallery_roundtrip(setup):
    import runpy
    tool=ROOT/'tools/preview_assets_on_he.py'
    if not tool.exists():pytest.skip('Existing Visual-First helper not installed in this checkout.')
    viewer=runpy.run_path(str(tool))
    table=viewer['preview_assets_on_he'](setup['project'],sample_keys=['A'],max_side=64,dpi=60,show=False)
    setup['summary']=Path(table.iloc[0]['summary'])
    summary=json.loads(setup['summary'].read_text())
    assert summary['sources'][1]['status']=='shown_with_encoding_warning'
    p=preview(setup);assert p['status']=='ready_for_explicit_approval',p['errors']
    assert approve(setup)['status']=='approved'


def test_compact_printer_does_not_change_files(setup,capsys):
    p=preview(setup);before=snapshots(setup['root']);va.print_approval_plan(p)
    text=capsys.readouterr().out
    assert 'Tissue' in text and 'No approval has been saved' in text
    assert snapshots(setup['root'])==before


def test_both_qc_classes_remain_independent_after_compilation(setup):
    approve(setup);reload(setup);cfg,spec=row_config(setup['project'],setup['project']['rows'][0])
    items,_,_=wf.asset_specification(cfg,spec)
    assert {tuple(x['categories']) for x in items if x['kind']=='polygons'}=={('Tissue',),('Necrosis',)}
    assert {x['_qc_use'] for x in items if x['kind']=='polygons'}=={'include','exclude'}
    with wf.open_raster(str(setup['tif']),'yx') as r:
        signal=next(x for x in items if x['kind']=='signal')
        values=wf.signal_values(r[:,:],signal)
        np.testing.assert_allclose(np.unique(values),[0,.25,.5,1])


def test_actual_transfer_numerics_with_explicit_stub_storage(setup,monkeypatch):
    import pandas as pd
    import vhd.persistence as persistence
    import vhd.io as vhd_io
    from vhd.annotations.alignment import resolve_alignment
    # Prepare tiny canonical geometry and refresh only synthetic discovery signatures.
    setup['geom']['grid_index_to_fullres']=np.eye(3).tolist()
    (setup['paths']['work']/'geometry.json').write_text(json.dumps(setup['geom']))
    rows=read_choices(setup['choices'])
    sources=wf.read_assets(setup['assets'],'Project','A')
    for a in sources:
        sig=wf.alignment_signature(resolve_alignment(a,setup['geom']),setup['geom'])
        for r in rows:
            if r['asset_id']==a['asset_id']:r['source_signature']=sig
    atomic_choices(setup['choices'],rows)
    approve(setup);reload(setup);cfg,spec=row_config(setup['project'],setup['project']['rows'][0])
    assets,_,_=wf.asset_specification(cfg,spec)
    base=pd.DataFrame({'pxl_col_in_fullres':[13.,22.],'pxl_row_in_fullres':[13.,13.],
                       'qc_keep':[True,True],'qc_class':['tissue-high_transcript-low','tissue-high_transcript-high']}, index=['bin1','bin2'])
    calls=[]
    def fake_import(c,s):
        calls.append('import')
        for sid in ('pathology','stain'):
            a=next(a for a in assets if a['_source_asset_id']==sid);group='shapes' if a['kind']=='polygons' else 'images';element='asset_'+sid
            (setup['paths']['store']/group/element).mkdir(parents=True,exist_ok=True)
            (setup['paths']['report']/f'asset_{sid}.json').write_text(json.dumps({'kind':a['kind'],'status':'stored','preview_status':'generated','element':element,'alignment_signature':a['reviewed_signature']}))
    def fake_update(store,table,**kwargs):
        calls.append('metadata_update');assert table=='bins_2um' and 'X' not in kwargs and 'layers' not in kwargs
        out=kwargs['obs'];col=next(a['_output_column'] for a in assets if a['kind']=='signal')+'__mean'
        np.testing.assert_allclose(out[col],[.25,.5])
        tissue=next(a['_output_column'] for a in assets if a['categories']==['Tissue'])
        necrosis=next(a['_output_column'] for a in assets if a['categories']==['Necrosis'])
        assert out[tissue].all() and out[necrosis].all()
    monkeypatch.setattr(wf,'import_assets',fake_import)
    monkeypatch.setattr(pd,'read_parquet',lambda *args,**kw:base.copy())
    monkeypatch.setattr(vhd_io,'table_metadata',lambda *args:(base.copy(),pd.DataFrame()))
    monkeypatch.setattr(persistence,'update_table_metadata',fake_update)
    monkeypatch.setattr(pd.DataFrame,'to_parquet',lambda self,path:Path(path).write_bytes(b'synthetic derived marker'))
    result=wf.transfer_assets(cfg,spec)
    assert calls==['import','metadata_update'] and result['membership']=='bin_centers'
