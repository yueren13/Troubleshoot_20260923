> Inherited technical reference. For the v4.1 source/category interface, start with START_HERE.md, ASSETS_V41_DISCOVERY.md and SIGNAL_MEASUREMENTS_V41.md. Older file-level role examples remain compatibility-only.

# Compact images, analysis QC and plot display

## Master image policy

The new starter settings use `storage.image_policy="compact"`. The master stores `he_hires` and `he_lowres` using the actual Space Ranger files and recorded scale factors, without a full-resolution `he_original` raster or an added original pyramid. Bins/cells remain in the same full-resolution coordinate system. Asset images and fixed quantitative H&E maps remain separate optional elements; compact does not mean discarding those measurements.

Discovery checks `outs/binned_outputs/square_002um/spatial` and `outs/spatial`. Both PNGs and `scalefactors_json.json` are required as a consistent set. A missing set stops; there is no silent fallback to embedding a full slide. Explicit `storage.compact_images` may instead specify both named images' paths and pixel-center `source_to_fullres` matrices. Those paths are relative to the settings/override JSON. Space Ranger hires pixels already reference Space Ranger fullres; do not apply a separate original-segmentation-image transform twice.

Other explicit choices are `original` (legacy full raster/pyramid) and `reference_only` (no H&E display array). Old configurations lacking image_policy retain legacy behavior; new examples choose compact. A changed image policy for an existing tracked master stops and requests a new master. This release **does not compact an existing large master in place**. Never delete or replace its image arrays while a writer or lazy reader is active.

The attrs `image_storage` record original path, dimensions, pixel size, registration and file identity plus each stored image's transform. An external path is provenance, not a guaranteed clickable link or self-contained image. Original H&E may still be read for segmentation and high-resolution overlays. Selected table loading does not need to read the image arrays or another table, but the selected matrix still loads into RAM. No cloud latency or speedup is guaranteed.

## Analysis QC before notebook 08

The explicit 07A stage reads each cell count table, computes metrics from its complete declared raw-feature set, and creates keyed sidecars under `<integration work>/<run>/<analysis_id>/analysis_qc/`. It does not remove rows or rewrite counts in the master.

New starter `analysis_qc` settings are enabled, with `min_counts=3`, `min_genes=1`, `min_cells_per_gene=3`, `respect_existing_qc=true`, and `missing_mt_policy=error`. Set species in each metadata JSON (`human` or `mouse`) or an explicit analysis profile. The default strict MT upper bound is <20% for human and <10% for mouse; an explicit `max_pct_mt` overrides it. These are the user's starting criteria, not universal validated thresholds. Change min_counts to16 when intended; this is NOT min_genes16.

Mitochondrial features are recognized by uppercased symbols beginning `MT-` or an explicit `mt_genes` list. If none are recognized, default error prevents treating lack of recognition as a biological zero. `skip_explicit` deliberately skips the mitochondrial filter for a known unsupported panel, records that fact and leaves the percentage missing. Zero-total cells and invalid metrics do not pass. The metrics precede gene filtering and HVG selection.

QC intersects the existing Boolean `qc_pass` by default. Counts per cell, genes per cell and cells detecting a gene are separate settings. Detection is evaluated across retained cells in the explicit group and per sample is reported. The existing assayed-gene **intersection** still determines compatible HVG candidates; no unassayed genes are silently zero-filled. Human/mouse mixtures are rejected; ortholog mapping is not implemented. Biological compatibility across studies must still be reviewed.

The current per-sample profile is copied into each integration spec, so sample overrides work without changing global labels. Group-level gene detection uses the group's `min_cells_per_gene`. 08 verifies the complete QC signature and consumes the sidecar pass mask and gene-detection rule before HVG selection. It retains the final nonzero-HVG-count check. scVI receives raw counts, not normalized/log10 plotting values.

Changing thresholds requires a new **integration.analysis_id**, not a new segmentation, master or sample run. Rerunning an identical complete analysis-QC stage validates and reuses its sidecars. Partial/conflicting sidecars stop rather than being deleted. The stage is one-sample-in-RAM; the whole analysis is NOT fully out-of-core. Sidecar flags are not automatically copied into master obs in this version; they can be joined by cell ID or written deliberately using the metadata-update workbench.

## Count displays

Count plots now default to log10(1+value) spacing and original-unit ticks at0,10,100,1,000,10,000 (extended as needed). `plots.count_log_base` controls replot-only output through07B; primary QC helpers use the new log10 default. Natural-log optical density, model likelihoods and scientific count values are not changed. Percentages, 0–1 H&E scores and coordinate axes stay on their appropriate scales. The plot labels explicitly distinguish spacing from values.

07B reads obs/var metadata, generates reports in `replot_counts/` and leaves master data unchanged. Some plots use independently computed ranges; a guaranteed shared range across every sample is not implemented. Colorbars omit ticks outside their plotted range. Cluster palette logic remains the existing microViz brewerPlus implementation with explicit extensions beyond41 colors.

## API references consulted

- Space Ranger image scale conventions: https://www.10xgenomics.com/support/software/space-ranger/latest/analysis/spatial-outputs
- SpatialData image elements, writes and transforms: https://spatialdata.scverse.org/en/stable/api/SpatialData.html
- AnnData component metadata and consolidation: https://anndata.readthedocs.io/en/latest/tutorials/zarr-v3.html

API documentation is not evidence that the target environment executed the new stages. See VALIDATION_SUMMARY.md for the actual tests.
