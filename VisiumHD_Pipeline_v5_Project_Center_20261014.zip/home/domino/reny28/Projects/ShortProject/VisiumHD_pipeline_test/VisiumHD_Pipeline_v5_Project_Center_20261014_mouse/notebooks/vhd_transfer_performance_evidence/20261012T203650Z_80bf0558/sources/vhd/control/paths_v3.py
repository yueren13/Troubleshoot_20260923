"""Portable mounted-path routing; never mount, unmount, discover usernames, or repair roots."""
from __future__ import annotations
import os,re,json,shutil
from pathlib import Path
from ..core import digest,dump_json


def expand_path(value):
    value=str(value).strip()
    for a,b in re.findall(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)',value):
        if (a or b) not in os.environ:raise ValueError(f'Unset path variable: {a or b}')
    return os.path.expanduser(os.path.expandvars(value))


def under(child,root):
    if str(child).startswith('s3://') or str(root).startswith('s3://'):
        return str(child).rstrip('/')==str(root).rstrip('/') or str(child).startswith(str(root).rstrip('/')+'/')
    c=Path(child).resolve();r=Path(root).resolve()
    return c==r or r in c.parents


def require_roots(policy):
    for path in policy.get('required_existing_roots',[]):
        if not Path(path).is_dir():raise FileNotFoundError(f'Required mounted/project root missing: {path}. STOP; it will not be created or remounted.')
    for entry in policy.get('required_sentinels',[]):
        p=Path(entry['path'])
        if not p.is_file() or p.read_text().strip()!=entry['value']:raise RuntimeError('Storage sentinel is missing or differs; no repair attempted.')


def assert_target(path,roots,sources=()):
    if not roots or not any(under(path,x) for x in roots):raise PermissionError(f'Write outside configured approved roots: {path}')
    for source in sources:
        if source and (under(path,source) or under(source,path)):raise ValueError(f'Actual write target overlaps source: {path} vs {source}')


def storage_profile(path,policy):
    matches=[x for x in policy.get('locations',[]) if under(path,x['root'])]
    return max(matches,key=lambda x:len(x['root'])) if matches else {'backend':'unspecified','access':'object_url' if str(path).startswith('s3://') else 'filesystem'}


def actual_layout(row,run):
    root=Path(row.get('work_dir') or row['tmp_dir'])/'vhd'/row['dataset_id']/row['sample_id']/run
    scratch=Path(row['tmp_dir'])/'vhd_scratch'/row['dataset_id']/row['sample_id']/run
    master=Path(row.get('master_store') or root/'objects'/f"{row['sample_id']}.zarr")
    return root,scratch,master


def stage_mounted(source,cache,policy):
    """Opt-in retained copy, source SHA256 plus readback. Expensive by design, no eviction."""
    from .storage import inventory,sha256,free_space_gate
    if not policy.get('allow_mounted_staging',False):return str(source)
    src=Path(source);cache=Path(cache)
    assert_target(cache,policy.get('approved_cache_roots',[]),[src])
    if not src.exists():raise FileNotFoundError(src)
    if src.is_symlink():raise ValueError('No symlinked source caching.')
    entries=inventory(src) if src.is_dir() else [{'path':src.name,'bytes':src.stat().st_size,'sha256':sha256(src)}]
    sig=digest({'source':str(src.resolve()),'files':entries});folder=cache/sig;dest=folder/src.name;receipt=folder/'cache_receipt.json'
    def check():return inventory(dest) if src.is_dir() else [{'path':src.name,'bytes':dest.stat().st_size,'sha256':sha256(dest)}]
    if receipt.exists():
        if json.loads(receipt.read_text()).get('signature')!=sig or not dest.exists() or check()!=entries:raise RuntimeError('Retained cache changed; no silent reuse.')
        return str(dest)
    if folder.exists():raise FileExistsError('Partial cache exists; inspect before retrying.')
    free_space_gate(cache,sum(e['bytes'] for e in entries),policy.get('min_free_tmp_gib',20))
    folder.mkdir(parents=True)
    shutil.copytree(src,dest) if src.is_dir() else shutil.copy2(src,dest)
    if check()!=entries:raise IOError('Cache checksum mismatch.')
    dump_json({'source':str(src),'signature':sig,'files':entries},receipt)
    return str(dest)
