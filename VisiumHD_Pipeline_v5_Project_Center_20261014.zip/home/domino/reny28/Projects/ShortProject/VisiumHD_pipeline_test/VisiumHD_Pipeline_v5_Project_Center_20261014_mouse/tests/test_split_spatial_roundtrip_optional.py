"""Actual image-only SpatialData write/read test; tiny synthetic split sources."""
import json
import numpy as np
import pytest
from PIL import Image
sd=pytest.importorskip('spatialdata')
pytest.importorskip('anndata')
pytest.importorskip('dask.array')
from vhd.compact_images import build_images, validate_images


def test_split_compact_images_real_spatialdata_roundtrip(tmp_path):
    outs=tmp_path/'outs';nested=outs/'binned_outputs/square_002um/spatial';outer=outs/'spatial'
    nested.mkdir(parents=True);outer.mkdir()
    hires=np.full((8,10,3),220,np.uint8);hires[2:5,2:6]=[150,90,170]
    lowres=hires[::2,::2].copy()
    Image.fromarray(hires).save(outer/'tissue_hires_image.png')
    Image.fromarray(lowres).save(outer/'tissue_lowres_image.png')
    scales=nested/'scalefactors_json.json'
    scales.write_text(json.dumps({'tissue_hires_scalef':.25,'tissue_lowres_scalef':.125}))
    cfg={'storage':{'image_policy':'compact','include_normalized_he':False}}
    images,record=build_images(cfg,{'outs':str(outs)}, {})
    assert set(images)=={'he_hires','he_lowres'}
    data=sd.SpatialData(images=images,attrs={'image_storage':record})
    dest=tmp_path/'tiny.zarr';data.write(dest)
    reopened=sd.read_zarr(dest)
    assert validate_images(reopened)['image_policy']=='compact'
    from vhd.storage import scale0
    for name,pixels in [('he_hires',hires),('he_lowres',lowres)]:
        np.testing.assert_array_equal(scale0(reopened.images[name]).values,np.moveaxis(pixels,-1,0))
        assert reopened.attrs['image_storage']['elements'][name]['source_resolution']['scalefactors_path']==str(scales)
    assert 'he_original' not in reopened.images
