"""Candidate registration against a named H&E image, never the whole object extent.

Dimension matching proposes a same-field-of-view transform. It is not image-content
registration and requires explicit same-extent confirmation before transfer.
"""
from __future__ import annotations
import copy
from pathlib import Path
import numpy as np
from ..core import affine
from .raster import open_raster


def extent_affine(source_shape, reference_shape, *, pixel_convention='edges'):
    """Shapes are (height, width); coordinates are array-index pixel centers."""
    sh, sw = map(int, source_shape); rh, rw = map(int, reference_shape)
    if min(sh,sw,rh,rw) <= 0:
        raise ValueError('Image dimensions must be positive.')
    if pixel_convention == 'edges':
        sx, sy = rw/sw, rh/sh
        tx, ty = (sx-1)/2, (sy-1)/2
    elif pixel_convention == 'origin_centers':
        sx, sy = rw/sw, rh/sh; tx=ty=0.
    elif pixel_convention == 'endpoint_centers':
        if min(sh,sw,rh,rw)<=1:raise ValueError('Endpoint alignment needs at least two pixels on each axis.')
        sx,sy=(rw-1)/(sw-1),(rh-1)/(sh-1);tx=ty=0.
    else:raise ValueError('pixel_convention: edges, origin_centers, endpoint_centers.')
    return np.array([[sx,0,tx],[0,sy,ty],[0,0,1.]],float)


def fit_landmarks(path, max_error_px=2.):
    import pandas as pd
    f=pd.read_csv(path)
    cols=['source_x','source_y','reference_x','reference_y']
    if not set(cols)<=set(f):raise ValueError('Landmarks need '+', '.join(cols))
    a=f[cols].to_numpy(float)
    if len(a)<3 or not np.isfinite(a).all():raise ValueError('Need at least three finite, non-collinear landmark pairs.')
    x=np.c_[a[:,:2],np.ones(len(a))]
    if np.linalg.matrix_rank(x)!=3:raise ValueError('Source landmarks are collinear.')
    coeff=np.linalg.lstsq(x,a[:,2:],rcond=None)[0]
    transform=affine(np.vstack([coeff.T,[0,0,1]]))
    residual=np.linalg.norm(x@coeff-a[:,2:],axis=1)
    if not np.isfinite(max_error_px) or max_error_px<=0:raise ValueError('max_landmark_error_px must be positive.')
    if residual.max()>max_error_px:raise ValueError(f'Landmark residual {residual.max():.3f}px exceeds {max_error_px}px.')
    return transform, {'n_landmarks':len(a),'max_fit_residual_px':float(residual.max()),
        'rms_fit_residual_px':float(np.sqrt(np.mean(residual**2))),
        'warning':'Fit residual is not independent validation; inspect withheld landmarks and overlays.'}


def resolve_alignment(asset, geometry):
    """Return a copy with resolved source-index -> Space Ranger fullres affine."""
    out=copy.deepcopy(asset);mode=asset.get('registration_mode') or 'explicit'
    if mode=='explicit':
        out['source_to_fullres']=affine(asset['source_to_fullres']).tolist()
        out['_alignment']={'method':'explicit','requires_same_extent_confirmation':False}
        return out
    image=geometry.get('image')
    if not image:raise ValueError('A named original H&E reference is required to estimate this asset transform.')
    ref_shape=(int(image['height']),int(image['width']))
    inv=np.linalg.inv(affine(geometry.get('tenx_to_image',np.eye(3))))
    report={'method':mode,'reference_path':image.get('path',''), 'reference_shape_yx':list(ref_shape),
            'requires_same_extent_confirmation':False}
    if mode=='reference_pixels':
        if asset['kind']!='polygons':raise ValueError('reference_pixels is for polygons drawn in the named original H&E image.')
        m=np.eye(3)
    elif mode=='landmarks':
        if not asset.get('landmarks_path'):raise ValueError('landmarks_path is required.')
        m,fit=fit_landmarks(asset['landmarks_path'],float(asset.get('max_landmark_error_px') or 2));report.update(fit)
    elif mode in ('auto','auto_extent'):
        if asset['kind']!='signal':raise ValueError('Extent scaling needs a raster; polygon bounds are NOT an image extent.')
        with open_raster(asset['path'],asset['axes'],asset['channel']) as r:shape=r.shape
        convention=asset.get('pixel_convention') or 'edges'
        m=extent_affine(shape,ref_shape,pixel_convention=convention)
        sx,sy=float(m[0,0]),float(m[1,1]);tol=float(asset.get('scale_tolerance') or .05)
        if not np.isfinite(tol) or not 0<tol<1:raise ValueError('scale_tolerance must be between zero and one.')
        hint=asset.get('scale_hint')
        errors=[]
        if hint not in ('',None):
            hint=float(hint)
            if not np.isfinite(hint) or hint<=0:raise ValueError('scale_hint must be a positive source-to-H&E pixel ratio, e.g. 9, not a percentage.')
            difference=max(abs(sx/hint-1),abs(sy/hint-1))
            report.update(scale_hint=hint,max_relative_hint_difference=difference)
            if difference>tol:
                errors.append(f'Actual dimension scales ({sx:.6g}, {sy:.6g}) differ from hint {hint:g} by {difference:.1%}. Check crop, scale direction and reference image.')
        aspect=abs(sx/sy-1)
        if aspect>tol:errors.append(f'Axis scale discrepancy {aspect:.1%}; an anisotropic image/crop needs an explicit reviewed transform or landmarks.')
        report.update(source_shape_yx=list(shape),scale_x=sx,scale_y=sy,offset_x=float(m[0,2]),offset_y=float(m[1,2]),
            pixel_convention=convention,requires_same_extent_confirmation=True,scale_checks_passed=not errors,
            warnings=errors+['Dimension fit assumes identical physical field of view and orientation. It is not automatic content registration.'])
    else:raise ValueError('registration_mode: explicit, reference_pixels, auto_extent, landmarks.')
    report['source_to_reference_image']=m.tolist()
    out['source_to_fullres']=affine(inv@m).tolist();out['_alignment']=report
    return out
