"""Synthetic checks for invocation-path preservation and visible run controls.
No installed packages are changed and no biological data are used.
"""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import venv

import pytest
from vhd.control.manifest import COLUMNS, load_project, path_value
from vhd.compute.runtime_checks import executable_path, preflight_python, action_imports
from vhd.control.notebook_runtime import describe_run, output_status


@pytest.fixture
def isolated_venv(tmp_path):
    root = tmp_path/'space in name'/'.venv'
    venv.EnvBuilder(with_pip=False, symlinks=True).create(root)
    exe = root/'bin/python'
    if not exe.is_file():
        pytest.skip('POSIX bin/python fixture required')
    return root, exe


def test_real_symlink_invocation_keeps_venv(isolated_venv, tmp_path):
    root, exe = isolated_venv
    fixed = executable_path(str(exe), tmp_path)
    assert fixed == str(exe)
    code = 'import sys,json;print(json.dumps({"prefix":sys.prefix,"base":sys.base_prefix}))'
    good = json.loads(subprocess.check_output([fixed, '-c', code], text=True))
    old = json.loads(subprocess.check_output([path_value(str(exe), tmp_path), '-c', code], text=True))
    assert Path(good['prefix']).samefile(root)
    assert good['prefix'] != good['base']
    assert old['prefix'] == old['base']


def test_preflight_uses_requested_venv(isolated_venv):
    root, exe = isolated_venv
    result = preflight_python(exe, ['json'], timeout=30)
    assert Path(result['prefix']).samefile(root)


def test_preflight_reports_import_failure_once(isolated_venv):
    _, exe = isolated_venv
    with pytest.raises(RuntimeError, match='No sample jobs for this action were submitted') as error:
        preflight_python(exe, ['this_module_does_not_exist_vhd_test'], timeout=30)
    assert 'No module named' in str(error.value)


def test_environment_and_relative_executable_path(tmp_path, monkeypatch):
    monkeypatch.setenv('VHD_FIX_TEST_ROOT', str(tmp_path))
    assert executable_path('${VHD_FIX_TEST_ROOT}/.venv/bin/python', tmp_path) == str(tmp_path/'.venv/bin/python')
    assert executable_path('env/bin/python', tmp_path) == str(tmp_path/'env/bin/python')


@pytest.mark.parametrize('bad', ['', 's3://bucket/python', '/root/*/python', '/root/?/python', 'http://x/python'])
def test_invalid_executables_rejected(bad, tmp_path):
    with pytest.raises(ValueError):
        executable_path(bad, tmp_path)


def test_unset_variable_still_errors(tmp_path, monkeypatch):
    monkeypatch.delenv('VHD_UNDEFINED_FIX_TEST', raising=False)
    with pytest.raises(ValueError, match='Unset executable path variable'):
        executable_path('${VHD_UNDEFINED_FIX_TEST}/bin/python', tmp_path)


def test_data_paths_still_canonicalize_symlinks(tmp_path):
    actual = tmp_path/'actual'
    actual.mkdir()
    alias = tmp_path/'alias'
    alias.symlink_to(actual, target_is_directory=True)
    assert path_value(str(alias/'data.zarr'), tmp_path) == str(actual/'data.zarr')


def test_load_project_preserves_all_executable_paths(isolated_venv, tmp_path):
    _, exe = isolated_venv
    base = Path(__file__).parents[1]
    settings = json.loads((base/'config/settings.g5_24xlarge.example.json').read_text())
    for key in ('python_spatial', 'python_stardist', 'python_scvi', 'python_rapids'):
        settings['execution'][key] = str(exe)
    settings['proseg']['executable'] = str(exe)
    sp = tmp_path/'settings.json'
    sp.write_text(json.dumps(settings))
    row = dict.fromkeys(COLUMNS, '')
    row.update(enabled='true', dataset_id='example', sample_id='s1', stage='cell_segmented',
               goal='cell_annotated', cell_input=str(tmp_path/'source/cells.h5ad'), counts_source='X',
               cell_coordinate_mode='unregistered', output_object_dir=str(tmp_path/'objects'),
               output_plot_dir=str(tmp_path/'plots'), output_data_dir=str(tmp_path/'data'),
               tmp_dir=str(tmp_path/'scratch'))
    manifest = tmp_path/'samples.csv'
    with manifest.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerow(row)
    project = load_project(manifest, sp)
    assert all(project['settings']['execution'][key] == str(exe)
               for key in ('python_spatial', 'python_stardist', 'python_scvi', 'python_rapids'))
    assert project['settings']['proseg']['executable'] == str(exe)


def simple_project():
    return {'manifest_path': '/example/samples.csv', 'settings_path': '/example/settings.json',
            'settings': {'run_id': 'example01', 'execution': {'python_spatial': '/example/.venv/bin/python'}},
            'rows': [{'sample_key': 'study__one'}, {'sample_key': 'study__two'}]}


def test_preview_mode_visible(capsys):
    describe_run(simple_project(), execute=False)
    assert 'PREVIEW' in capsys.readouterr().out


def test_execute_requires_explicit_selection():
    with pytest.raises(ValueError, match='Explicit selection'):
        describe_run(simple_project(), execute=True)
    assert describe_run(simple_project(), execute=True, sample_keys=['study__one']) == ['study__one']
    assert len(describe_run(simple_project(), execute=True, allow_all=True)) == 2


def test_selection_must_not_be_string():
    with pytest.raises(TypeError):
        describe_run(simple_project(), execute=True, sample_keys='study__one')


def test_integration_banner_does_not_claim_sample_subset(capsys):
    describe_run(simple_project(), execute=True, sample_keys=['study__one'], kind='integration')
    assert 'SAMPLE_KEYS does not subset integration' in capsys.readouterr().out


def test_route_h_preflight_does_not_import_segmentation_tools():
    modules = action_imports('assemble')
    assert 'numpy' in modules and 'spatialdata' in modules
    assert not {'tensorflow', 'stardist', 'scvi', 'torch'} & set(modules)


def test_launcher_preview_never_probes_or_launches(tmp_path, monkeypatch, capsys):
    import vhd.compute.launch as launch
    import vhd.compute.runtime_checks as runtime
    base = Path(__file__).parents[1]
    settings = json.loads((base/'config/settings.g5_24xlarge.example.json').read_text())
    project = {'settings': settings, 'rows': [{'sample_key': 's1', '_plan': ['assemble']}]}
    monkeypatch.setattr(launch, 'check_policy', lambda p: True)
    monkeypatch.setattr(launch, 'concurrency_budget', lambda *a, **k: {'workers': 1})
    def never(*a, **k):
        raise AssertionError('Preview must not call this')
    monkeypatch.setattr(runtime, 'preflight_python', never)
    monkeypatch.setattr(launch, 'save_plan', never)
    monkeypatch.setattr(launch, 'run_logged', never)
    launch.launch_samples(project, 'assemble', execute=False)
    assert 'PREVIEW ONLY' in capsys.readouterr().out


def test_launcher_preflight_failure_prevents_all_sample_jobs(tmp_path, monkeypatch):
    import vhd.compute.launch as launch
    import vhd.compute.runtime_checks as runtime
    base = Path(__file__).parents[1]
    settings = json.loads((base/'config/settings.g5_24xlarge.example.json').read_text())
    project = {'settings': settings, 'rows': [{'sample_key': f's{i}', '_plan': ['assemble']} for i in range(12)]}
    monkeypatch.setattr(launch, 'check_policy', lambda p: True)
    monkeypatch.setattr(launch, 'concurrency_budget', lambda *a, **k: {'workers': 1})
    monkeypatch.setattr(launch, 'sample_layout', lambda *a: {'scratch': tmp_path})
    monkeypatch.setattr(launch, 'worker_env', lambda *a: {})
    calls = []
    def probe(*a, **k):
        calls.append('probe')
        raise RuntimeError('test probe failed')
    def never(*a, **k):
        raise AssertionError('No jobs or plan writes after failed preflight')
    monkeypatch.setattr(runtime, 'preflight_python', probe)
    monkeypatch.setattr(launch, 'save_plan', never)
    monkeypatch.setattr(launch, 'run_logged', never)
    with pytest.raises(RuntimeError, match='test probe failed'):
        launch.launch_samples(project, 'assemble', execute=True)
    assert calls == ['probe']
