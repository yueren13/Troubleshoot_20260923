# v4 change log and boundaries

## Consolidated September 30, 2026

1. Incorporated the v3 review source, execution hotfix (venv-path preservation, worker import preflight, visible notebook controls) and corrected working/repository validator.
2. Added optional JSON path variables loaded before sample CSVs; new starter configs use local files, explicit sample metadata and generic paths.
3. Added active vs reference-only asset roles, active-source ownership checks for prior filtering, explicit asset approval helper and source-owned transfer refresh.
4. Added binary encoding/NoData checks, nearest-center requirement, `.annotations` XML-root validation and tested 9x signal mapping. Source XML holes remain preserved.
5. Added compact image assembly and coordinated validators, source-reference metadata, and safe refusal to silently change an existing master's image policy.
6. Added pre-integration analysis-QC sidecars, strict species-aware MT thresholds, minimum cell counts and group-level gene-detection rules, then integration-mask/feature enforcement.
7. Added readable count ticks and a metadata-only replot path. Display transformations do not replace raw counts or H&E optical-density calculations.
8. Added earlier prerequisite checks, expected/actual output index and safeguards against silently retaining changed prepared bin expression. Integration analysis IDs separate QC/model attempts and publication destinations.
9. Added focused v4 unit/contract tests plus optional real AnnData/SpatialData tests and a synthetic demo.

## Intentionally not changed

Reference H&E matrix/limits and combine-before-interpolate order, raw-count requirements, legacy QC preservation, explicit transforms, Proseg counts, sample batch semantics, ten Leiden resolutions (0.1–1.0), single common UMAP, microViz-based palette, safety allowlists and no-automatic-overwrite policy.

Model hyperparameters, StarDist/Proseg scientific engines, DDP/RAPIDS device limitations and exact old Step03 thresholds are not guessed or newly benchmarked. Fresh bin-QC cutoffs remain unset until reviewed. This is not an environment-upgrade or full-resolution-master compaction utility.
