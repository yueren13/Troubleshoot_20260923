# compute

CPU/sample-per-GPU/DDP/RAPIDS launchers with resource gates and verified handoff.

See ../../docs/START_HERE.md and ../../docs/IMPLEMENTATION_STATUS.md. Source review and CPU tests are not target-environment validation.
